Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=[1];
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",16,0x000000,false];
		Random.init(semilla,100);
		
		Motor.lOperaciones = new Array();

		this.lPregsSPRITE=new Array();
		this.lPregSTRING=new Array();
		this.lRespNUM=new Array();
		this.lRespSTRING=new Array();
		this.lRespsSPRITE=new Array();
		this.lVariaciones=new Array();

		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			//console.log(this.lTiposVariaciones);
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
		//console.log(this.lVariaciones);
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {

			this.enunciar();
	
			Motor.co_pizarra.addChild(this.lPregsSPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].pregSPR=this.lPregsSPRITE[this.nOp];
			Motor.lOperaciones[this.nOp].pregSPR.x=75;
			Motor.lOperaciones[this.nOp].pregSPR.y=20;
			Motor.lOperaciones[this.nOp].respNum=this.lRespNUM[this.nOp];
			
			Motor.lOperaciones[this.nOp].respuestaString=this.lRespSTRING[this.nOp];
			Motor.lOperaciones[this.nOp].entrada=["","",""];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			
			//console.log( Motor.lOperaciones[this.nOp]);
		}

	}
	
	this.enunciar = function()
	{
			while(true){
				var denom=Random.integer(3,9);
				var entero=Random.integer(-5,9,[0]);
				var numer=Random.integer(1,denom-1);

				//console.log("denom : " + denom + " entero : " + entero + " numer : " + numer);

				if(entero*denom+numer%denom!=0){
					break;
				}
			}
			//console.log((entero*denom+numer)+" - "+denom);
			var pos_rayaUSU=0;
			switch(this.lVariaciones[this.nOp]){
				case 1://de gráfico a fracción
					EA._formatoBase=["Arial",16,"#000000",false];
					var contenedor = new createjs.Container(); 
					var recta = new createjs.Shape();
					contenedor.addChild(recta);
					recta.x=20;
					recta.y=20;
					recta.graphics.setStrokeStyle(2).beginStroke("#000");
					recta.graphics.drawRoundRect(-10,10,520,50,10);
					recta.graphics.setStrokeStyle(2);
					recta.graphics.moveTo(-10,30);
					recta.graphics.lineTo(510,30);
					recta.graphics.setStrokeStyle(1);
					for(var xx=10;xx<500;xx+=10){
						recta.graphics.moveTo(xx,27);
						recta.graphics.lineTo(xx,33);
					}
					
					recta.graphics.setStrokeStyle(2);
					var posEntero=Random.integer(2,Math.floor(50/denom));
					var valorInicial=entero-posEntero+1;
					for(xx=10;xx<500;xx+=10*denom){
						recta.graphics.moveTo(xx,25);
						recta.graphics.lineTo(xx,35);
						var eaN=EA.ini(JL.num2str(valorInicial++,0));
						contenedor.addChild(eaN);
						eaN.x=xx-eaN.getBounds().width/2+21;
						eaN.y=42;
					}
					recta.graphics.beginStroke("red").setStrokeStyle(2);
					recta.graphics.moveTo(10+10*denom*(posEntero-1)+10*numer,16);
					recta.graphics.lineTo(10+10*denom*(posEntero-1)+10*numer,44).endStroke();
					this.lPregsSPRITE.push(contenedor);
					
					this.lRespNUM.push([(entero>=0)?'+':'-',(Math.abs(entero*denom+numer)).toString(),(denom).toString()]);
					//console.log("ABC"+this.lRespNUM[this.nOp][1]);
					EA._formatoBase=["Arial",24,"red",false];
					var ea=EA.ini(this.lRespNUM[this.nOp][0]);
					EA.adfStatic(EA.fra("  "+this.lRespNUM[this.nOp][1]+"  ","  "+this.lRespNUM[this.nOp][2]+"  "),ea,0,20);
					this.lRespSTRING.push(ea);
				break;
			}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}