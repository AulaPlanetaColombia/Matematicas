function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;

    this.contenedor = new createjs.Container();

    this.contenedor.addChild(operacio.pregSPR);
    
    this.solucio = operacio.respuestaString;
	this.contenedor.addChild(this.solucio);
	this.solucio.x= 300;
	this.solucio.y= 300;
	this.solucio.alpha = 0;
	 
	this.signo ="";
	this.numerador ="";
	this.denominador ="";
	 
	this.osigno = new CajaTexto();
	this.osigno.contenedor.x = 225;
	this.osigno.contenedor.y = 295-118;
	
	this.onumerador = new CajaTexto();
	this.onumerador.contenedor.x = 320;
	this.onumerador.contenedor.y = 265-118;
	
	this.odenominador = new CajaTexto();
	this.odenominador.contenedor.x = 320;
	this.odenominador.contenedor.y = 325-118;
	
	this.contenedor.addChild( this.osigno.contenedor  );
	this.contenedor.addChild( this.onumerador.contenedor  );
	this.contenedor.addChild( this.odenominador.contenedor  );
	
	this.lineaDivision = new createjs.Shape();
	this.lineaDivision.graphics.beginStroke("#000").setStrokeStyle(1).moveTo(300, 315-118);
	this.lineaDivision.graphics.lineTo(410, 315-118);
	
	this.contenedor.addChild( this.lineaDivision  );
	
	this.validacio = false;
}

function CajaTexto()
{
	this.contenedor = new createjs.Container();
	
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 65, 40, 3);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 3);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 3);

	
}
CajaTexto.prototype.error = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 3);
}

CajaTexto.prototype.correct = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 3);
}
