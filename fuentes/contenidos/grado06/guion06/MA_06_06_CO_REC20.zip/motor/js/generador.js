Generador = new function()
{
	this.nOp;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones = new Array();

	this.lPreguntas=new Array();
	this.lRespuestas=new Array();
	this.lRespuestasString=new Array();
	this.lFiguras=new Array();

	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.plano = "";
	this.co_pizarra = "";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,"#000000",false];
		Random.init(semilla,100);
		//this.tiposOP = ["+","-","x",":"];
		
		this.lVariaciones3 = new Array();
		this.indice;

        for ( var numOp = 0 ; numOp < Motor.qOperaciones; numOp++ ) {
            this.indice = numOp % Motor.lTiposVariaciones3.length;
            this.lVariaciones3[numOp] = Motor.lTiposVariaciones3[this.indice];
        }
				
		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();
		}
		//console.log(Motor.lOperaciones);
		
	}
	
	this.enunciar = function()
	{

        var hayEnteroA = false;
        var hayEnteroB = false;
        this.lPreguntas=new Array();
        this.lRespuestas=new Array();
        this.lRespuestasString=new Array();
        this.lPreguntasVar = new Array();
        this.lValoresReales = new Array();
        this.lEl = new Array();
        this.lVal = new Array();
   
   
        if(Motor.nVariacion==0){//op. binaria
            var tipoOP = this.lVariaciones3[this.nOp] - 1;//suma/resta/multi/div
            //DECIDE COMBINACIÓN DE ENTEROS Y FRACCIONES SEGÚN PARÁMETROS:
            //---
            if(Motor.permitirEnteros==0){//no hay enteros
                hayEnteroA = false;
                hayEnteroB = false;
            }else{//hay enteros
                if(Motor.permitirDosFracciones==0){//solo hay mixtos E+F
                    if(tipoOP==1){//resta
                        hayEnteroA=true;
                        hayEnteroB=false;
                    }else{//otra op.
                        if(Random.boolean(0.5)){
                            hayEnteroA=true;hayEnteroB=false;
                        }else{
                            hayEnteroA=false;hayEnteroB=true;
                        }
                    }
                }else{//hay mixtos E+F alternados con F+F
                    if(Random.boolean(0.5)){//mixto E+F
                        if(tipoOP==1){//resta
                            hayEnteroA=true;hayEnteroB=false;
                        }else{//otra op.
                            if(Random.boolean(0.5)){
                                hayEnteroA=true;hayEnteroB=false;
                            }else{
                                hayEnteroA=false;hayEnteroB=true;
                            }
                        }
                    }else{//F+F
                        hayEnteroA=hayEnteroB=false;
                    }
                }
            }
            
            //primer término:
            if(hayEnteroA){
                var entero = Random.integer(2,7);
                var valorA = entero;
                var elemA = [entero];
            }else{
                var denomA = Random.integer(2,20);
                var numerA = Random.integer(1,denomA-1);
                valorA=numerA/denomA;
                elemA=[numerA,denomA];
            }
            //segundo término:
            if(tipoOP!=1){//suma,prod ó divi   (NO es resta)
                if(hayEnteroB){
                    entero=Random.integer(2,7);
                    var valorB = entero;
                    var elemB = [entero];
                }else{
                    var denomB = Random.integer(2,20);
                    var numerB = Random.integer(1,denomB-1);
                    valorB=numerB/denomB;
                    elemB=[numerB,denomB];
                }
            }else{//resta
                if(hayEnteroB){
                    while(true){
                        entero=Random.integer(1,6);
                        valorB=entero;
                        if(valorB<valorA){
                            break;
                        }
                    }
                    elemB=[entero];
                }else{
                    while(true){
                        denomB=Random.integer(2,20);
                        numerB=Random.integer(1,denomB-1);
                        valorB=numerB/denomB;
                        if(valorB<valorA){
                            break;
                        }
                    }
                    elemB=[numerB,denomB];
                }
            }
            this.lPreguntas.push([elemA,elemB,tipoOP]);
            if(tipoOP==0){
                var valorRes = valorA+valorB;
            }else if(tipoOP==1){
                var valorRes=valorA-valorB;
            }else if(tipoOP==2){
                var valorRes=valorA*valorB;
            }else{
                var valorRes=valorA/valorB;
            }
            this.lRespuestas.push(valorRes);
            
            this.lRespuestasString.push(this.operacionBinFrac(elemA,elemB,tipoOP));
        }else{//op. combinada
            lEl = new Array();
            lVal = new Array();
            for(var i = 0;i<4;i++){
                if(Motor.permitirEnteros==1){
                    if(Random.boolean(0.8)){//este elemento es fracción
                        denomA=Random.integer(2,10);
                        numerA=Random.integer(1,denomA-1);
                        valorA=numerA/denomA;
                        elemA=[numerA,denomA];
                    }else{//este elemento es entero
                        elemA=[Random.integer(1,6)];
                        valorA=elemA[0];
                    }
                }else{//este elemento es fracción
                    denomA=Random.integer(2,10);
                    numerA=Random.integer(1,denomA-1);
                    valorA=numerA/denomA;
                    elemA=[numerA,denomA];
                }
                this.lEl.push(elemA);
                this.lVal.push(valorA);
            }
            while(true){
                var lSignos = ['+','−','x',':'];
                var lOp = [lSignos[Random.integer(3)],lSignos[Random.integer(3)],lSignos[Random.integer(3)]];
                var combinacion = Random.integer(10);
                //var combinacion:int=r.integer(2);
                //combinacion=5;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                var tiraPreg = new Array();
                var valorPreg;
                var frac;
                var frac2;
                //var combinacion2 = 2;
                switch(combinacion){
                    default://sin paréntesis  N*N*N*N
                        var tiraPreg=[this.lEl[0],lOp[0],this.lEl[1],lOp[1],this.lEl[2],lOp[2],this.lEl[3]];
                        var array = [this.lVal[0],lOp[0],this.lVal[1],lOp[1],this.lVal[2],lOp[2],this.lVal[3]];
                        var valorPreg=VN.valor(array);
                        if((lOp[0]=='x')||(lOp[0]==':')){// NxN*N*N
                           var frac=this.operacionBinFrac(this.lEl[0],this.lEl[1],lSignos.indexOf(lOp[0]));
                            if((lOp[1]=='x')||(lOp[1]==':')){// NxNxN*N
                                frac=this.operacionBinFrac(frac,this.lEl[2],lSignos.indexOf(lOp[1]));
                                frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                            }else{// NxN+N*N
                                if((lOp[2]=='x')||(lOp[2]==':')){// NxN+NxN
                                    var frac2=this.operacionBinFrac(this.lEl[2],this.lEl[3],lSignos.indexOf(lOp[2]));
                                    frac=this.operacionBinFrac(frac,frac2,lSignos.indexOf(lOp[1]));
                                }else{// NxN+N+N
                                    frac=this.operacionBinFrac(frac,this.lEl[2],lSignos.indexOf(lOp[1]));
                                    frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                                }
                            }
                        }else{// N+N*N*N
                            if((lOp[2]=='x')||(lOp[2]==':')){// N+N*NxN
                                if((lOp[1]=='x')||(lOp[1]==':')){// N+NxNxN
                                    frac=this.operacionBinFrac(this.lEl[1],this.lEl[2],lSignos.indexOf(lOp[1]));
                                    frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                                    frac=this.operacionBinFrac(this.lEl[0],frac,lSignos.indexOf(lOp[0]));
                                }else{//N+N+NxN
                                    frac=this.operacionBinFrac(this.lEl[0],this.lEl[1],lSignos.indexOf(lOp[0]));
                                    frac2=this.operacionBinFrac(this.lEl[2],this.lEl[3],lSignos.indexOf(lOp[2]));
                                    frac=this.operacionBinFrac(frac,frac2,lSignos.indexOf(lOp[1]));
                                }
                            }else{// N+N*N+N
                                if((lOp[1]=='x')||(lOp[1]==':')){// N+NxN+N
                                    frac=this.operacionBinFrac(this.lEl[1],this.lEl[2],lSignos.indexOf(lOp[1]));
                                    frac=this.operacionBinFrac(this.lEl[0],frac,lSignos.indexOf(lOp[0]));
                                    frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                                }else{// N+N+N+N
                                    frac=this.operacionBinFrac(this.lEl[0],this.lEl[1],lSignos.indexOf(lOp[0]));
                                    frac=this.operacionBinFrac(frac,this.lEl[2],lSignos.indexOf(lOp[1]));
                                    frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                                }
                            }   
                        }
                        break;
                    case 0:// (N*N)*N*N
                        var tiraPreg=['(',this.lEl[0],lOp[0],this.lEl[1],')',lOp[1],this.lEl[2],lOp[2],this.lEl[3]];
                        var array2 = ['(',this.lVal[0],lOp[0],this.lVal[1],')',lOp[1],this.lVal[2],lOp[2],this.lVal[3]];
                        var valorPreg=VN.valor(array2);
                        var frac=this.operacionBinFrac(this.lEl[0],this.lEl[1],lSignos.indexOf(lOp[0]));
                        if((lOp[1]=='x')||(lOp[1]==':')){//(N*N)xN*N
                            frac=this.operacionBinFrac(frac,this.lEl[2],lSignos.indexOf(lOp[1]));
                            frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                        }else{//(N*N)+N*N
                            if((lOp[2]=='x')||(lOp[2]==':')){// (N*N)+NxN
                                var frac2=this.operacionBinFrac(this.lEl[2],this.lEl[3],lSignos.indexOf(lOp[2]));
                                frac=this.operacionBinFrac(frac,frac2,lSignos.indexOf(lOp[1]));
                            }else{// (N*N)+N+N
                                frac=this.operacionBinFrac(frac,this.lEl[2],lSignos.indexOf(lOp[1]));
                                frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                            }
                        }
                        break;
                    case 1:// N*(N*N)*N
                        var tiraPreg=[this.lEl[0],lOp[0],'(',this.lEl[1],lOp[1],this.lEl[2],')',lOp[2],this.lEl[3]];
                        var array3 = [this.lVal[0],lOp[0],'(',this.lVal[1],lOp[1],this.lVal[2],')',lOp[2],this.lVal[3]];
                        var valorPreg=VN.valor(array3);
                        var frac=this.operacionBinFrac(this.lEl[1],this.lEl[2],lSignos.indexOf(lOp[1]));
                        if((lOp[2]=='x')||(lOp[2]==':')){// N*(N*N)xN
                            frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                            frac=this.operacionBinFrac(this.lEl[0],frac,lSignos.indexOf(lOp[0]));
                        }else{// N*(N*N)+N
                            frac=this.operacionBinFrac(this.lEl[0],frac,lSignos.indexOf(lOp[0]));
                            frac=this.operacionBinFrac(frac,this.lEl[3],lSignos.indexOf(lOp[2]));
                        }
                        break;
                    case 2:// N*N*(N*N)
                        var tiraPreg=[this.lEl[0],lOp[0],this.lEl[1],lOp[1],'(',this.lEl[2],lOp[2],this.lEl[3],')'];
                        var array4 = [this.lVal[0],lOp[0],this.lVal[1],lOp[1],'(',this.lVal[2],lOp[2],this.lVal[3],')'];
                        var valorPreg=VN.valor(array4);
                        var frac = this.operacionBinFrac(this.lEl[2],this.lEl[3],lSignos.indexOf(lOp[2]));
                        if((lOp[1]=='x')||(lOp[1]==':')){
                            frac=this.operacionBinFrac(this.lEl[1],frac,lSignos.indexOf(lOp[1]));
                            frac=this.operacionBinFrac(this.lEl[0],frac,lSignos.indexOf(lOp[0]));
                        }else{
                            var frac2=this.operacionBinFrac(this.lEl[0],this.lEl[1],lSignos.indexOf(lOp[0]));
                            frac=this.operacionBinFrac(frac2,frac,lSignos.indexOf(lOp[1]));
                        }
                        break;
                }
                var auxPreg = Math.abs(valorPreg);
                if((auxPreg<100)&&(auxPreg!=0)&&(auxPreg<Infinity)){
                    for(var nn = 0;nn<tiraPreg.length;nn++){
                        if(tiraPreg[nn]=='x'){
                            tiraPreg[nn]='·';  
                        }
                        if(tiraPreg[nn]=='-'){
                            tiraPreg[nn]='−';
                        }
                    }
                    this.lPreguntas.push(tiraPreg);
                    this.lRespuestas.push(valorPreg);
                    this.lRespuestasString.push([JL.num2str(frac[0]),JL.num2str(frac[1])]);

                    break;
                }
            }
        }

        Motor.lOperaciones[this.nOp]=new Object();
        Motor.lOperaciones[this.nOp].pregunta=this.lPreguntas;
        Motor.lOperaciones[this.nOp].respuesta=this.lRespuestas;
        Motor.lOperaciones[this.nOp].respuestaString=this.lRespuestasString;
        Motor.lOperaciones[this.nOp].variacion=Motor.nVariacion;
        Motor.lOperaciones[this.nOp].tipoOP=tipoOP;
        Motor.lOperaciones[this.nOp].in_entero="";
        Motor.lOperaciones[this.nOp].in_numerador="";
        Motor.lOperaciones[this.nOp].in_denominador="";
        Motor.lOperaciones[this.nOp].estaListo=false;///cuando sus datos estan llenos -> true
        Motor.lOperaciones[this.nOp].correcto=false;
        Motor.lOperaciones[this.nOp].in_num="";
        Motor.lOperaciones[this.nOp].in_den="";
        
	}
	this.operacionBinFrac = function (fracA,fracB,op){
        var numer;
        var denom;
        if(fracA.length==1){
            fracA.push(1);
        }
        if(fracB.length==1){
            fracB.push(1);
        }
        switch(op){
            case 0://suma
                numer=fracA[0]*fracB[1]+fracA[1]*fracB[0];
                denom=fracA[1]*fracB[1];
                break;
            case 1://resta
                numer=fracA[0]*fracB[1]-fracA[1]*fracB[0];
                denom=fracA[1]*fracB[1];
                break;
            case 2://multi
                numer=fracA[0]*fracB[0];
                denom=fracA[1]*fracB[1];
                break;
            case 3://divi
                numer=fracA[0]*fracB[1];
                denom=fracA[1]*fracB[0];
                break;
        }
        return JL.simplificar([numer,denom]);
    }
}