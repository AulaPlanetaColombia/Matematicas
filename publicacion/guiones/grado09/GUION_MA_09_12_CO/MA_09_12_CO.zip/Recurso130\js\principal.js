(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titolintro']);


        this.instance_1 = new lib._88019257();
        this.instance_1.setTransform(250.5, 100.8, 0.862, 0.862);

        this.textbtn2 = new cjs.Text(txt['textbtn2'], "bold 16px Verdana");
        this.textbtn2.textAlign = "center";
        this.textbtn2.lineHeight = 18;
        this.textbtn2.lineWidth = 141;
        this.textbtn2.setTransform(156.6, 264.8 + incremento);

        this.mc_botons2 = new lib.mc_botons2();
        this.mc_botons2.setTransform(160.3, 275.1, 1, 1, 0, 0, 0, 105.4, 22.6);
        new cjs.ButtonHelper(this.mc_botons2, 0, 1, 2, false, new lib.mc_botons2(), 3);

        this.textbtn4 = new cjs.Text(txt['textbtn4'], "bold 16px Verdana");
        this.textbtn4.textAlign = "center";
        this.textbtn4.lineHeight = 18;
        this.textbtn4.lineWidth = 141;
        this.textbtn4.setTransform(157.3, 498.7 + incremento);

        this.mc_botons4 = new lib.mc_botons4();
        this.mc_botons4.setTransform(160.1, 509.1, 1, 1, 0, 0, 0, 105.4, 22.6);
        new cjs.ButtonHelper(this.mc_botons4, 0, 1, 2, false, new lib.mc_botons4(), 3);

        this.textbtn1 = new cjs.Text(txt['textbtn1'], "bold 16px Verdana");
        this.textbtn1.textAlign = "center";
        this.textbtn1.lineHeight = 18;
        this.textbtn1.lineWidth = 141;
        this.textbtn1.setTransform(156.6, 160.4 + incremento);

        this.mc_botons = new lib.mc_botons();
        this.mc_botons.setTransform(159.3, 170.1, 1, 1, 0, 0, 0, 105.4, 22.6);
        new cjs.ButtonHelper(this.mc_botons, 0, 1, 2, false, new lib.mc_botons(), 3);

        this.textbtn3 = new cjs.Text(txt['textbtn3'], "bold 16px Verdana");
        this.textbtn3.textAlign = "center";
        this.textbtn3.lineHeight = 18;
        this.textbtn3.lineWidth = 141;
        this.textbtn3.setTransform(157.5, 388.6 + incremento);

        this.mc_botons3 = new lib.mc_botons3();
        this.mc_botons3.setTransform(160.3, 399, 1, 1, 0, 0, 0, 105.4, 22.6);
        new cjs.ButtonHelper(this.mc_botons3, 0, 1, 2, false, new lib.mc_botons3(), 3);

        this.mc_botons.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.mc_botons2.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.mc_botons3.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.mc_botons4.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.mc_botons3, this.textbtn3, this.mc_botons, this.textbtn1, this.mc_botons4, this.textbtn4, this.mc_botons2, this.textbtn2, this.instance_1, this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['titol1_scn1']);
      this.instance_1 = new lib.Symbol3();
	this.instance_1.setTransform(607.5,317.5,1,1,0,0,0,60.6,44.2);

	this.instance_2 = new lib.Symbol2();
	this.instance_2.setTransform(449.1,317.5,1,1,0,0,0,70.2,44.2);

	this.instance_3 = new lib.Symbol1();
	this.instance_3.setTransform(261.1,317.5,1,1,0,0,0,60.1,44.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("Eg0jAAAMBpHAAA");
	this.shape.setTransform(484,315.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto, this.siguiente, this.home, this.shape,this.instance_3,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        texto(this, txt['texto1_scn1'],0,0);
        
      this.instance_1 = new lib.animacon01_scn1();
	this.instance_1.setTransform(475.9,392.4,1,1,0,0,0,336.4,44.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.siguiente, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        texto(this, txt['texto2_scn1'],0,0);
        
    
	this.instance_1 = new lib.animacion02_scn1();
	this.instance_1.setTransform(355.3,483.6,1,1,0,0,0,399.8,40);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
    
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['titol1_scn2']);
     this.instance_1 = new lib.Symbol15();
	this.instance_1.setTransform(632.8,296.5,1,1,0,0,0,54.1,44.2);

	this.instance_2 = new lib.Symbol14();
	this.instance_2.setTransform(499.8,296.5,1,1,0,0,0,54.1,44.2);

	this.instance_3 = new lib.Symbol13();
	this.instance_3.setTransform(368.3,296.5,1,1,0,0,0,55.6,44.2);

	this.instance_4 = new lib.Symbol12();
	this.instance_4.setTransform(239.3,296.5,1,1,0,0,0,54.6,44.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("Eg0jAAAMBpHAAA");
	this.shape.setTransform(470.7,294.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto, this.siguiente, this.home, this.shape,this.instance_4 ,this.instance_3,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        texto(this, txt['texto1_scn2'],0,0);
        
      this.instance_1 = new lib.animacon01_scn2();
	this.instance_1.setTransform(475.9,402.4,1,1,0,0,0,336.4,44.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.siguiente, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        texto(this, txt['texto2_scn2'],0,0);
        
    
	this.instance_1 = new lib.animacion02_scn2();
	this.instance_1.setTransform(455.3,383.6,1,1,0,0,0,399.8,40);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
    
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['titol1_scn3']);
    this.instance_1 = new lib.Symbol26();
	this.instance_1.setTransform(765.8,290.5,1,1,0,0,0,42.1,44.2);

	this.instance_2 = new lib.Symbol25();
	this.instance_2.setTransform(527.3,290.5,1,1,0,0,0,45.6,44.2);

	this.instance_3 = new lib.Symbol24();
	this.instance_3.setTransform(443.5,290.5,1,1,0,0,0,44.8,44.2);

	this.instance_4 = new lib.Symbol23();
	this.instance_4.setTransform(359.6,290.5,1,1,0,0,0,43.9,44.2);

	this.instance_5 = new lib.Symbol22();
	this.instance_5.setTransform(275.7,290.5,1,1,0,0,0,43,44.2);

	this.instance_6 = new lib.Symbol21();
	this.instance_6.setTransform(191.8,290.5,1,1,0,0,0,42.1,44.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("AdcAAIBaAAAf8AAIBQAAEAiXAAAIBaAAEAk3AAAIPtAAARDAAIBdAAAWGAAIBQAAAYhAAIBaAAATmAAIBaAAEg0jAAAMBD4AAAAbBAAIBQAA");
	this.shape.setTransform(476.7,288.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto, this.siguiente, this.home, this.shape,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        texto(this, txt['texto1_scn3'],0,0);
        
      this.instance_1 = new lib.animacon01_scn3();
	this.instance_1.setTransform(475.9,392.4,1,1,0,0,0,336.4,44.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.siguiente, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        texto(this, txt['texto2_scn3'],0,0);
        
    
	this.instance_1 = new lib.animacion02_scn3();
	this.instance_1.setTransform(485.3,383.6,1,1,0,0,0,399.8,40);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
    
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['titol1_scn4']);
     this.instance_1 = new lib.Symbol42();
	this.instance_1.setTransform(771.9,290.5,1,1,0,0,0,34.2,44.2);

	this.instance_2 = new lib.Symbol41();
	this.instance_2.setTransform(451.1,290.5,1,1,0,0,0,35.9,44.2);

	this.instance_3 = new lib.Symbol40();
	this.instance_3.setTransform(386,290.5,1,1,0,0,0,36.2,44.2);

	this.instance_4 = new lib.Symbol39();
	this.instance_4.setTransform(320.9,290.5,1,1,0,0,0,36.5,44.2);

	this.instance_5 = new lib.Symbol38();
	this.instance_5.setTransform(255.9,290.5,1,1,0,0,0,36.8,44.2);

	this.instance_6 = new lib.Symbol37();
	this.instance_6.setTransform(190.8,290.5,1,1,0,0,0,37.1,44.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("AdcAAIBaAAAf8AAIBQAAEAiXAAAIBaAAEAk3AAAIPtAAAOmAAIBQAAARDAAIBdAAAWGAAIBQAAAYhAAIBaAAATmAAIBaAAAEwAAIBQAAAJrAAIBQAAAMGAAIBaAAAHLAAIBaAAEg0jAAAMA4NAAAAbBAAIBQAA");
	this.shape.setTransform(480.7,288.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto, this.siguiente, this.home, this.shape,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        texto(this, txt['texto1_scn4'],0,0);
        
      this.instance_1 = new lib.animacon01_scn4();
	this.instance_1.setTransform(475.9,392.4,1,1,0,0,0,336.4,44.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.siguiente, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        texto(this, txt['texto2_scn4'],0,0);
        
    
	this.instance_1 = new lib.animacion02_scn4();
	this.instance_1.setTransform(485.3,383.6,1,1,0,0,0,399.8,40);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
    
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.anterior, this.texto, this.home, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -512);
        else
            escena.texto.setTransform(130 + ancho, -512);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

    
(lib.Tween4 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("4", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-56.8,-0.9);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(36.2,-35.2,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(37.7,0.1,1.245,1.245);

	this.text_3 = new cjs.Text("K = 4 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-75.4,-19,1.245,1.245);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjGAAIGNAA");
	this.shape.setTransform(49,0.4-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-75.4,-35.2,148.7,70.7);


(lib.Tween3 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("4", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(-53.8,-0.9);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(36.2,-35.2,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(37.7,0.1,1.245,1.245);

	this.text_3 = new cjs.Text("Q = 4 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-75.4,-19,1.245,1.245);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjGAAIGNAA");
	this.shape.setTransform(49,0.4-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-75.4,-35.2,151,70.7);


(lib.Tween2 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("k = 4", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(1.7,-12.4,0.882,0.882);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>4</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-27.4,-12.4,54.9,25);

    (lib.Symbol19b = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("4", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(17.2,34);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(111.7,0,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(113.2,35.4,1.245,1.245);

	this.text_3 = new cjs.Text("K =    ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,16.2,1.245,1.245);
	this.text_3b = new cjs.Text("      4       ", "bold 20px Verdana","#B30218");
	this.text_3b.lineHeight = 20;
	this.text_3b.setTransform(0,16.2,1.245,1.245);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjGAAIGNAA");
	this.shape.setTransform(124.5,35.7-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text,this.text_3b);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,148.7,70.7);

(lib.Symbol19 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("3", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(17.2,34);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(111.7,0,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(113.2,35.4,1.245,1.245);

	this.text_3 = new cjs.Text("K =    ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,16.2,1.245,1.245);
        this.text_3b = new cjs.Text("      3       ", "bold 20px Verdana","#B30218");
	this.text_3b.lineHeight = 20;
	this.text_3b.setTransform(0,16.2,1.245,1.245);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjGAAIGNAA");
	this.shape.setTransform(124.5,35.7-incremento);

	this.addChild(this.shape,this.text_3,this.text_3b,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,148.7,70.7);


(lib.Symbol18 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("2", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(16.9,33.6);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(111.6,0,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(112.4,35.4,1.245,1.245);

	this.text_3 = new cjs.Text("K =    ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,16.2,1.245,1.245);
        this.text_3b = new cjs.Text("      2       ", "bold 20px Verdana","#B30218");
	this.text_3b.lineHeight = 20;
	this.text_3b.setTransform(0,16.2,1.245,1.245);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjGAAIGNAA");
	this.shape.setTransform(124,35.7-incremento);

	this.addChild(this.shape,this.text_3,this.text_3b,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,148.7,70.7);


(lib.Symbol17 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("1", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(17.9,33.2);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(111,0,1.245,1.245);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(112.5,35.4,1.245,1.245);

	this.text_3 = new cjs.Text("K =    ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,16.2,1.245,1.245);
               this.text_3b = new cjs.Text("      1       ", "bold 20px Verdana","#B30218");
	this.text_3b.lineHeight = 20;
	this.text_3b.setTransform(0,16.2,1.245,1.245);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjEAAIGJAA");
	this.shape.setTransform(123.7,35.7-incremento);

	this.addChild(this.shape,this.text_3,this.text_3b,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,148.7,70.7);
    (lib.Symbol15 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(90.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABZBYIAAgeIg1AAIAAgRIA2g7IAMAAIAABAIARAAIAAAMIgRAAIAAAegAAuAuIArAAIAAgvgAgIBOIg0hLIgXATIgNA4IgWAAIAnilIAWAAIgUBWIBghWIAcAAIhaBQIA7BVg");
	this.shape_1.setTransform(93.5,72.6);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(81.6,63.8,23.9,17.8);


(lib.Symbol14 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(90.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AA7BXIgOgFIAAgPIACAAQAFAEAJADQAJADAHAAIAKgCQAFgCADgDIAGgHQABgDAAgHQAAgFgCgEQgCgEgDgCIgIgDIgKgBIgGAAIAAgMIAEAAQALAAAHgFQAGgEABgJQgBgEgBgBQgCgDgDgCIgHgDIgIAAQgGgBgIADQgIADgHAEIgBAAIAAgPIAOgFQAJgCAIAAQAIAAAGACQAGABAFADQAFAEADAEQACAFAAAFQABAKgHAGQgGAHgJABIAAABIAIADIAIAEQAEAEABAFQADAEAAAIQAAAHgDAHQgCAGgFAEQgGAFgIADQgHADgJgBQgIABgKgDgAgGBNIg0hLIgXATIgNA4IgWAAIAnimIAWAAIgUBXIBghXIAcAAIhZBQIA6BWg");
	this.shape_1.setTransform(92.9,72.1);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(81.1,63.1,23.5,18);


(lib.Symbol13 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(93.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAsBYIAAgPIAegaQAOgOAFgIQAFgIAAgJQAAgIgFgDQgGgFgKAAQgHAAgHACQgIADgIADIAAAAIAAgOIAOgFQAIgCAIAAQARAAAJAIQAKAIAAAMQAAAGgCAGQgBAFgDAFIgHAJIgpAmIA7AAIAAAMgAgHBOIg0hLIgXATIgMA4IgXAAIAnilIAWAAIgUBWIBghWIAdAAIhaBQIA6BVg");
	this.shape_1.setTransform(95.9,72.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(84.1,63.6,23.7,17.8);


(lib.Symbol12 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(91.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AA4BYIAAgLIAWAAIAAhJIgWAAIAAgIIAKAAIAIgDQADgBACgDQACgDAAgFIALAAIAABgIAWAAIAAALgAgEBOIg0hLIgWATIgNA4IgWAAIAmilIAXAAIgVBWIBghWIAdAAIhaBQIA7BVg");
	this.shape_1.setTransform(93.3,72.6);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(81.8,63.8,23,17.8);

(lib.mc_k9 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 9", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>9</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);


(lib.mc_k5 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 5", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
 var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>5</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(15, -690);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);


(lib.mc_k4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 4", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
 var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>4</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(15, -690);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);


(lib.mc_k3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 3", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
 var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>3</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(15, -690);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);


(lib.mc_k2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 2", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
 var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>2</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(15, -690);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);


(lib.mc_k1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("k = 1", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
 var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>1</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(15, -690);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.1,0,62.2,28.3);

(lib.animacon01_scn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.Symbol42();
	this.instance.setTransform(627.7,44.2,1,1,0,0,0,34.2,44.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90).to({_off:false},0).to({alpha:1},14).wait(1));

	// Layer 2
	this.instance_1 = new lib.Symbol41();
	this.instance_1.setTransform(306.8,44.2,1,1,0,0,0,35.9,44.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).to({alpha:1},14).wait(17));

	// Symbol 15
	this.instance_2 = new lib.Symbol40();
	this.instance_2.setTransform(241.7,44.2,1,1,0,0,0,36.2,44.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(58).wait(1).to({_off:false},0).to({alpha:1},14).wait(32));

	// Symbol 14
	this.instance_3 = new lib.Symbol39();
	this.instance_3.setTransform(176.7,44.2,1,1,0,0,0,36.5,44.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({_off:false},0).to({alpha:1},14).wait(47));

	// Symbol 13
	this.instance_4 = new lib.Symbol38();
	this.instance_4.setTransform(111.6,44.2,1,1,0,0,0,36.8,44.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({alpha:1},14).wait(62));

	// Symbol 12
	this.instance_5 = new lib.Symbol37();
	this.instance_5.setTransform(46.6,44.2,1,1,0,0,0,37.1,44.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(14).to({_off:false},0).to({alpha:1},14).wait(77));

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("EAiXAAAIBaAAAf8AAIBQAAAbBAAIBQAAAYhAAIBaAAAdcAAIBaAAARDAAIBdAAATmAAIBaAAAWGAAIBQAAAMGAAIBaAAAOmAAIBQAAAEwAAIBQAAAHLAAIBaAAAJrAAIBQAAEg0jAAAMA4NAAAEAk3AAAIPtAA");
	this.shape.setTransform(336.5,42.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(1050000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacon01_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.Symbol26();
	this.instance.setTransform(625.6,44.2,1,1,0,0,0,42.1,44.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90).to({_off:false},0).to({alpha:1},14).wait(1));

	// Layer 2
	this.instance_1 = new lib.Symbol25();
	this.instance_1.setTransform(387.1,44.2,1,1,0,0,0,45.6,44.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).to({alpha:1},14).wait(17));

	// Symbol 15
	this.instance_2 = new lib.Symbol24();
	this.instance_2.setTransform(303.3,44.2,1,1,0,0,0,44.8,44.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(58).wait(1).to({_off:false},0).to({alpha:1},14).wait(32));

	// Symbol 14
	this.instance_3 = new lib.Symbol23();
	this.instance_3.setTransform(219.4,44.2,1,1,0,0,0,43.9,44.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(44).to({_off:false},0).to({alpha:1},14).wait(47));

	// Symbol 13
	this.instance_4 = new lib.Symbol22();
	this.instance_4.setTransform(135.5,44.2,1,1,0,0,0,43,44.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({_off:false},0).to({alpha:1},14).wait(62));

	// Symbol 12
	this.instance_5 = new lib.Symbol21();
	this.instance_5.setTransform(51.6,44.2,1,1,0,0,0,42.1,44.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(14).to({_off:false},0).to({alpha:1},14).wait(77));

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("Af8AAIBQAAEAiXAAAIBaAAAYhAAIBaAAAbBAAIBQAAAdcAAIBaAAARDAAIBdAAAWGAAIBQAAATmAAIBaAAEg0jAAAMBD4AAAEAk3AAAIPtAA");
	this.shape.setTransform(336.5,42.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(1050000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacon01_scn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 15
	this.instance = new lib.Symbol15();
	this.instance.setTransform(498.6,44.2,1,1,0,0,0,54.1,44.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).to({alpha:1},14).wait(16));

	// Symbol 14
	this.instance_1 = new lib.Symbol14();
	this.instance_1.setTransform(365.6,44.2,1,1,0,0,0,54.1,44.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).to({alpha:1},14).wait(31));

	// Symbol 13
	this.instance_2 = new lib.Symbol13();
	this.instance_2.setTransform(234.1,44.2,1,1,0,0,0,55.6,44.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).to({alpha:1},14).wait(46));

	// Symbol 12
	this.instance_3 = new lib.Symbol12();
	this.instance_3.setTransform(105.1,44.2,1,1,0,0,0,54.6,44.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).to({alpha:1},14).wait(61));

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("Eg0jAAAMBpHAAA");
	this.shape.setTransform(336.5,42.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(890000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);



(lib.animacion02_scn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.instance = new lib.Symbol49();
	this.instance.setTransform(764.8,102.7,1,1,0,0,0,69.7,27.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(300).to({_off:false},0).to({alpha:1},14).wait(1));

	// Layer 7
	this.instance_1 = new lib.Symbol50();
	this.instance_1.setTransform(702.1,-83.9,0.754,0.754,0,0,0,43.1,10.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(286).to({_off:false},0).to({alpha:1},14).wait(15));

	// Layer 6
	this.instance_2 = new lib.Symbol34();
	this.instance_2.setTransform(655.9,95.2,1,1,0,0,0,15.2,16.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(255).to({_off:false},0).to({alpha:1},14).wait(46));

	// Layer 5
	this.instance_3 = new lib.Symbol48();
	this.instance_3.setTransform(555.9,102.3,1,1,0,0,0,62.4,27.9);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(224).to({_off:false},0).to({alpha:1},14).wait(77));

	// Layer 4
	this.instance_4 = new lib.mc_k5();
	this.instance_4.setTransform(557.1,-45.3,0.754,0.754,0,0,0,43.1,10.7);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(210).to({_off:false},0).to({alpha:1},14).wait(91));

	// Layer 3
	this.instance_5 = new lib.Symbol47();
	this.instance_5.setTransform(418,102.7,1,1,0,0,0,62.4,27.9);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(179).to({_off:false},0).to({alpha:1},13).wait(123));

	// Layer 2
	this.instance_6 = new lib.mc_k4("synched",0);
	this.instance_6.setTransform(375.2,-53.3,0.754,0.754);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(166).to({startPosition:0,_off:false},0).to({alpha:1},13).wait(136));

	// Symbol 8
	this.instance_7 = new lib.Symbol46();
	this.instance_7.setTransform(282.2,102.3,1,1,0,0,0,62.4,27.9);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(134).to({_off:false},0).to({alpha:1},12).wait(169));

	// Symbol 11
	this.instance_8 = new lib.mc_k3();
	this.instance_8.setTransform(279.8,-43.5,0.754,0.754,0,0,0,57.1,14.1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(119).to({_off:false},0).to({x:281.1,alpha:1},12).wait(184));

	// Symbol 7
	this.instance_9 = new lib.Symbol45();
	this.instance_9.setTransform(144.1,102.3,1,1,0,0,0,62.4,27.9);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(88).to({_off:false},0).to({alpha:1},12).wait(215));

	// Symbol 10
	this.instance_10 = new lib.mc_k2();
	this.instance_10.setTransform(142,-43.5,0.754,0.754,0,0,0,57.1,14.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(72).to({_off:false},0).to({x:143.3,alpha:1},12).wait(231));

	// Symbol 6
	this.instance_11 = new lib.Symbol44();
	this.instance_11.setTransform(1.3,102.3,1,1,0,0,0,62.4,27.9);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(44).to({_off:false},0).to({alpha:1},12).wait(259));

	// Symbol 9
	this.instance_12 = new lib.mc_k1();
	this.instance_12.setTransform(1.4,-43.5,0.754,0.754,0,0,0,55.6,14.1);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({x:2.7,alpha:1},12).wait(274));

	// Symbol 5
	this.instance_13 = new lib.Symbol43();
	this.instance_13.setTransform(402.4,-106,1,1,0,0,0,82.5,37.2);
	this.instance_13.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({alpha:1},12).wait(3030000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(319.9,-143.3,162.4,74.5);


(lib.animacion02_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 8
	this.instance = new lib.Symbol36();
	this.instance.setTransform(764,104,1,1,0,0,0,62.4,29.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(300).to({_off:false},0).to({alpha:1},14).wait(1));

	// Layer 7
	this.instance_1 = new lib.mc_k9();
	this.instance_1.setTransform(743.2,-90.1,0.754,0.754,0,0,0,43.1,10.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(286).to({_off:false},0).to({alpha:1},14).wait(15));

	// Layer 6
	this.instance_2 = new lib.Symbol34();
	this.instance_2.setTransform(658.5,95.2,1,1,0,0,0,15.2,16.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(255).to({_off:false},0).to({alpha:1},14).wait(46));

	// Layer 5
	this.instance_3 = new lib.Symbol33();
	this.instance_3.setTransform(554.6,103.6,1,1,0,0,0,62.4,29.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(224).to({_off:false},0).to({alpha:1},14).wait(77));

	// Layer 4
	this.instance_4 = new lib.mc_k5();
	this.instance_4.setTransform(555.8,-43.5,0.754,0.754,0,0,0,57.1,14.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(210).to({_off:false},0).to({alpha:1},14).wait(91));

	// Layer 3
	this.instance_5 = new lib.Symbol31();
	this.instance_5.setTransform(416.7,104,1,1,0,0,0,62.4,29.2);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(179).to({_off:false},0).to({alpha:1},13).wait(123));

	// Layer 2
	this.instance_6 = new lib.Tween2("synched",0);
	this.instance_6.setTransform(347.2,-90,0.754,0.754);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(166).to({startPosition:0,_off:false},0).to({alpha:1},13).wait(136));

	// Symbol 8
	this.instance_7 = new lib.Symbol30();
	this.instance_7.setTransform(280.9,103.6,1,1,0,0,0,62.4,29.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(134).to({_off:false},0).to({alpha:1},12).wait(169));

	// Symbol 11
	this.instance_8 = new lib.mc_k3();
	this.instance_8.setTransform(279.8,-43.5,0.754,0.754,0,0,0,57.1,14.1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(119).to({_off:false},0).to({alpha:1},12).wait(184));

	// Symbol 7
	this.instance_9 = new lib.Symbol29();
	this.instance_9.setTransform(142.8,103.6,1,1,0,0,0,62.4,29.2);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(88).to({_off:false},0).to({alpha:1},12).wait(215));

	// Symbol 10
	this.instance_10 = new lib.mc_k2();
	this.instance_10.setTransform(142,-43.5,0.754,0.754,0,0,0,57.1,14.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(72).to({_off:false},0).to({alpha:1},12).wait(231));

	// Symbol 6
	this.instance_11 = new lib.Symbol28();
	this.instance_11.setTransform(0,103.6,1,1,0,0,0,62.4,29.2);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(44).to({_off:false},0).to({alpha:1},12).wait(259));

	// Symbol 9
	this.instance_12 = new lib.mc_k1();
	this.instance_12.setTransform(1.4,-43.5,0.754,0.754,0,0,0,55.6,14.1);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(29).to({_off:false},0).to({alpha:1},12).wait(274));

	// Symbol 5
	this.instance_13 = new lib.Symbol27();
	this.instance_13.setTransform(402.4,-103.5,1,1,0,0,0,82.5,38.9);
	this.instance_13.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({alpha:1},12).wait(3030000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(319.9,-142.5,164.4,77.8);


(lib.animacion02_scn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	/* Layers with classic tweens must contain only a single symbol instance. */

	// Symbol 8
	this.instance_1b = new lib.Symbol19b();
	this.instance_1b.setTransform(673.7,117.8,1,1,0,0,0,75.5,35.3);
	this.instance_1b.alpha = 0;
	this.instance_1b._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1b).wait(188).to({_off:false},0).to({alpha:1},12).wait(14));
	// Layer 2
	this.instance = new lib.mc_k4();
	this.instance.setTransform(633.9,33.9,0.882,0.882);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(166).to({startPosition:0,_off:false},0).to({alpha:1},13).wait(14));

	// Symbol 8
	this.instance_1 = new lib.Symbol19();
	this.instance_1.setTransform(489.7,117.8,1,1,0,0,0,75.5,35.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(134).to({_off:false},0).to({alpha:1},12).wait(47));

	// Symbol 11
	this.instance_2 = new lib.mc_k3();
	this.instance_2.setTransform(490.1,46.3,0.882,0.882,0,0,0,57.1,14.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(119).to({_off:false},0).to({alpha:1},12).wait(62));

	// Symbol 7
	this.instance_3 = new lib.Symbol18();
	this.instance_3.setTransform(305.1,117.8,1,1,0,0,0,75.5,35.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(88).to({_off:false},0).to({alpha:1},12).wait(93));

	// Symbol 10
	this.instance_4 = new lib.mc_k2();
	this.instance_4.setTransform(305.5,46.3,0.882,0.882,0,0,0,57.1,14.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(72).to({_off:false},0).to({alpha:1},12).wait(109));

	// Symbol 6
	this.instance_5 = new lib.Symbol17();
	this.instance_5.setTransform(118.6,117.8,1,1,0,0,0,75.5,35.3);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(44).to({_off:false},0).to({alpha:1},12).wait(137));

	// Symbol 9
	this.instance_6 = new lib.mc_k1();
	this.instance_6.setTransform(117.7,46.3,0.882,0.882,0,0,0,55.6,14.1);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(29).to({_off:false},0).to({alpha:1},12).wait(152));

	// Symbol 5
	this.instance_7 = new lib.Symbol20();
	this.instance_7.setTransform(402.4,-101.9,1,1,0,0,0,82.5,38.9);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({alpha:1},12).wait(1810000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(319.9,-147.8,162.5,77.8);


(lib.Symbol50 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("k = 99", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.8,0,0.754,0.754);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>99</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(19.7,0,57.6,21.4);


(lib.Symbol49 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("99", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(9,30.3);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(105.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(112.6,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P  = 99 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-4.3,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> &nbsp;= <span class='rojo_1'>99</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(115.8,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-4.3,0,142.8,55.9);


(lib.Symbol48 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("5", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(9.7,30.3);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.3,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(99.6,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P = 5 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> = <span class='rojo_1'>5</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.9,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,122,55.9);


(lib.Symbol47 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("4", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(11.7,29.8);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(99.6,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P = 4 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> = <span class='rojo_1'>4</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.8,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,122,55.9);


(lib.Symbol46 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("3", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(9.8,30.2);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.3,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(99.6,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P = 3 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> = <span class='rojo_1'>3</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.9,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,122,55.9);


(lib.Symbol45 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("2", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(9.6,29.5);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(99,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P = 2 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> = <span class='rojo_1'>2</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.4,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,121.4,55.9);


(lib.Symbol44 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("1", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(9.5,27.5);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(91.7,0,1.029,1.029);

	this.text_2 = new cjs.Text("100", "18px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(99,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("P = 1 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>P</i></b> = <span class='rojo_1'>1</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AiiAAIFFAA");
	this.shape.setTransform(102.2,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,121.4,55.9);


(lib.Symbol43 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(123.1,0,1.37,1.37);

	this.text_1 = new cjs.Text("100", "18px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.setTransform(126.9,39,1.37,1.37);

	this.text_2 = new cjs.Text("P =    ·      ", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(0,17.8,1.37,1.37);
this.text_2b = new cjs.Text("      k       ", "italic 20px Verdana","#B30218");
	this.text_2b.lineHeight = 20;
	this.text_2b.setTransform(0,17.8,1.37,1.37);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjaAAIG1AA");
	this.shape.setTransform(136.9,39.2-incremento);

	this.addChild(this.shape,this.text_2,this.text_1,this.text,this.text_2b);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,162.4,74.5);


(lib.Symbol42 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(16.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABcBZIgGgBIAAgOIAAAAIAGACIAJABQAQAAAJgKQAJgKACgRQgHAFgGABQgGACgHAAQgHAAgFgBQgGgCgFgDQgHgFgDgHQgDgHAAgJQAAgPALgKQALgLAQAAQAIAAAGADQAHACAFAFQAGAGAEAIQADAJAAAPQAAAPgDALQgEAMgGAIQgHAIgKAFQgKAEgNAAgABggDQgGAEAAAMQAAAHACAFQACAEAEADQAEADAEAAIAIABQAGAAAGgBQAGgCAFgDIAAgDIAAgEQAAgLgCgHQgCgFgFgEQgDgDgEgBQgEgCgEAAQgLAAgGAHgAADBZIgEgBIAAgOIAAAAIAEACIAJABQAQAAAJgKQAJgKACgRQgHAFgGABQgGACgHAAQgHAAgFgBQgGgCgEgDQgGgFgDgHQgDgHAAgJQAAgPALgKQAJgLAQAAQAIAAAGADQAHACAFAFQAGAGAEAIQADAJAAAPQAAAPgDALQgEAMgGAIQgHAIgKAFQgKAEgNAAgAAHgDQgGAEAAAMQAAAHACAFQACAEAEADQAEADAEAAIAIABQAGAAAGgBQAGgCAFgDIAAgDIAAgEQAAgLgCgHQgCgFgFgEQgDgDgEgBQgEgCgEAAQgLAAgGAHgAiXBNIAnilIAsAAQAPAAAKACQAKADAGAFQAHAFAEAHQADAIAAAKQAAANgGANQgGAMgLAJQgKAHgNAEQgMAEgSAAIgZAAIgOA/gAhugCIAUAAQAOAAAJgCQAJgDAGgFQAIgHAEgIQADgIAAgJQAAgGgCgFQgCgFgEgDQgEgEgHgBQgHgCgKAAIgVAAg");
	this.shape_1.setTransform(23,72.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(7.8,63.5,30.5,18);


(lib.Symbol41 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(53.9,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAyBYIgOgFIAAgQIABAAQAGAEAIADQAIACAIAAIAKgBQAFgCAEgDQADgDACgEQABgFAAgFQAAgGgCgEQgBgEgEgDQgEgCgFgBQgGgCgGAAIgNACIgKACIAAg2IBBAAIAAAMIgzAAIAAAbIAMgBQAJABAHABQAGACAFADQAGAEADAGQAEAHAAAKQAAAHgDAHQgDAHgFAFQgEAFgIADQgHADgKAAQgIAAgJgCgAhqBMIAnikIAsAAQAPgBAIADQAKADAGAEQAHAGADAHQAEAIAAAJQAAAOgGAMQgGANgLAJQgJAHgMAEQgMAEgTAAIgYAAIgPA+gAhBgCIAUAAQANAAAKgDQAIgCAHgGQAHgGADgIQADgIAAgJQAAgHgCgEQgCgGgCgCQgFgEgGgCQgHgBgLAAIgUAAg");
	this.shape_1.setTransform(57.6,73.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(46.8,64.3,21.5,18);


(lib.Symbol40 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(54.6,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABOBYIAAgeIg0AAIAAgRIA1g7IANAAIAABAIARAAIAAAMIgRAAIAAAegAAkAuIAqAAIAAgvgAhsBOIAnilIAsAAQAPAAAKACQAIADAGAFQAHAFAEAHQADAIAAAKQAAANgGANQgGAMgLAJQgIAHgNAEQgMAEgSAAIgZAAIgOA/gAhDgBIAUAAQAOAAAJgCQAJgDAGgFQAIgHACgIQADgIAAgJQAAgGgCgFQgCgFgCgDQgEgEgHgBQgHgCgKAAIgVAAg");
	this.shape_1.setTransform(57.7,73.1);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(46.8,64.3,21.9,17.8);


(lib.Symbol39 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(55.2,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAxBXIgOgFIAAgPIABAAQAGAEAJADQAIACAIAAIAKgBQAFgBADgDIAFgHQACgFAAgFQAAgGgCgEQgCgEgDgCIgIgDIgKgBIgHAAIAAgMIAFAAQALAAAHgEQAGgFAAgJQAAgEgBgBQgCgDgDgCIgHgCIgIgBQgHAAgHACQgIADgHAEIgBAAIAAgPIAOgFQAJgCAIAAQAIAAAGABQAGACAFADQAFAEADAFQACAEAAAFQAAAJgGAHQgGAHgJACIAAAAIAIADIAIAFQADADACAFQADAEAAAIQAAAHgDAHQgDAFgFAGQgFAEgIADQgHACgJABQgJgBgJgCgAhqBMIAnikIAsAAQAPgBAIADQAKADAGAEQAHAGAEAHQADAIAAAJQAAAOgGAMQgGANgLAJQgIAHgNAEQgMAEgSAAIgZAAIgOA+gAhBgCIAUAAQAOAAAJgDQAJgCAGgGQAHgGADgIQADgIAAgJQAAgHgCgEQgCgGgCgCQgEgEgHgCQgHgBgKAAIgVAAg");
	this.shape_1.setTransform(57.5,73.3);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(46.8,64.3,21.5,18);


(lib.Symbol38 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(55.8,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAiBYIAAgPIAegaQANgOAGgIQAFgIAAgJQAAgIgFgDQgHgFgKAAQgGAAgIACQgHADgIADIAAAAIAAgOIANgFQAJgCAIAAQARAAAJAIQAJAIAAAMQAAAGgBAGQgBAFgEAFIgGAJIgJAKIggAcIA7AAIAAAMgAhqBOIAmilIAsAAQAPAAAJACQAJADAGAFQAIAFADAHQADAIABAKQAAANgHANQgFAMgMAJQgIAHgMAEQgNAEgSAAIgYAAIgPA/gAhCgBIAUAAQAOAAAJgCQAJgDAHgFQAHgHACgIQAEgIgBgJQAAgGgCgFQgBgFgDgDQgEgEgHgBQgHgCgKAAIgUAAg");
	this.shape_1.setTransform(55.4,72.9);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(44.6,64.1,21.6,17.8);


(lib.Symbol37 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(56.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAuBYIAAgLIAWAAIAAhJIgWAAIAAgIIAJAAIAIgDQAEgBACgDQACgDAAgFIALAAIAABgIAWAAIAAALgAhnBOIAmilIAsAAQAQAAAIACQAKADAGAFQAHAFADAHQAEAIAAAKQAAANgGANQgGAMgLAJQgKAHgLAEQgNAEgSAAIgYAAIgPA/gAg+gBIAUAAQANAAAJgCQAJgDAHgFQAFgHAEgIQAEgIAAgJQAAgGgCgFQgCgFgEgDQgDgEgGgBQgHgCgLAAIgUAAg");
	this.shape_1.setTransform(57.3,73.1);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(46.8,64.3,21,17.8);


(lib.Symbol36 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("9", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(14.5,29.6);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.7,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 9 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>9</span> &nbspp;.", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.8,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol34 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("...", "italic 25px Verdana");
	this.text.lineHeight = 25;
	this.text.setTransform(0,0,0.966,0.966);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,30.5,33.3);


(lib.Symbol33 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("5", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(13.4,29.6);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.3,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.8,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 5 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>5</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.9,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol31 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("4", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(14.9,29.3);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.7,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 4 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>4</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.8,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol30 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("3", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(14.6,29.3);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.3,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.8,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 3 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>3</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.9,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol29 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("2", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(15,29.3);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(92.2,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.1,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 2 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>2</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AijAAIFHAA");
	this.shape.setTransform(102.4,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol28 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("1", "13px Verdana");
	this.text.lineHeight = 13;
	this.text.setTransform(15.6,29.1);

	this.text_1 = new cjs.Text("N", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(91.7,0,1.029,1.029);

	this.text_2 = new cjs.Text("10", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(99.2,29.2,1.029,1.029);

	this.text_3 = new cjs.Text("D = 1 ·      ", "italic 20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(0,13.4,1.029,1.029);
var html = createDiv("<b class='rojo_1'><i>D</i></b> = <span class='rojo_1'>1</span> ·", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
 this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(0, 5-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AiiAAIFFAA");
	this.shape.setTransform(102.2,29.5-incremento);

	this.addChild(this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,124.3,58.4);


(lib.Symbol27 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(123.1,0,1.37,1.37);

	this.text_1 = new cjs.Text("10", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(128.5,39,1.37,1.37);

	this.text_2 = new cjs.Text("D =    ·      ", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(0,17.8,1.37,1.37);
this.text_2b = new cjs.Text("       k        ", "bold italic 20px Verdana","#B30218");
	this.text_2b.lineHeight = 20;
	this.text_2b.setTransform(0,17.8,1.37,1.37);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjaAAIG1AA");
	this.shape.setTransform(136.9,39.2-incremento);

	this.addChild(this.shape,this.text_2,this.text_1,this.text,this.text_2b);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,164.4,77.8);


(lib.Symbol26 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(16.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABCBZIgGgBIAAgOIABAAIAFACIAJABQAQAAAJgKQAKgKABgRQgHAFgFABQgHACgHAAQgHAAgFgBQgFgCgGgDQgGgFgDgHQgEgHAAgJQAAgPALgKQALgLAQAAQAIAAAGADQAHACAGAFQAGAGADAIQADAJAAAPQAAAPgDALQgEAMgGAIQgHAIgJAFQgKAEgOAAgABGgDQgGAEAAAMQAAAHACAFQACAEAEADQAEADAEAAIAJABQAFAAAGgBQAGgCAFgDIAAgDIAAgEQAAgLgCgHQgCgFgFgEQgDgDgDgBQgFgCgEAAQgKAAgHAHgAh9BNIAmilIAnAAQATAAAOACQAPADALAIQAMAIAGANQAHANAAARQgBAZgOAZQgOAYgWANQgOAIgPADQgQADgUAAgAhiA6IAWAAQARAAANgCQAMgDALgGQATgLAGgTQAKgSAAgVQAAgNgEgJQgFgKgHgGQgJgGgLgCQgKgCgQAAIgTAAg");
	this.shape_1.setTransform(17.9,72.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(5.3,63.8,25.3,18);


(lib.Symbol25 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(73.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABFBXIgOgEIAAgQIABAAQAGAEAIADQAIADAIgBQAFABAFgCQAFgCADgDQAEgDABgEQACgFAAgGQAAgFgCgEQgCgEgDgCQgEgDgGgBQgFgBgHgBIgMABIgKACIAAg2IBBAAIAAANIgzAAIAAAbIAMAAQAJgBAGACQAHACAFADQAGAEADAHQAEAGAAAJQAAAIgDAHQgDAHgFAEQgFAGgHACQgHADgKABQgJgBgIgCgAh9BMIAnikIAnAAQASAAAPACQAOADALAHQAMAJAHAMQAGANAAASQAAAZgOAYQgOAZgWANQgPAIgPADQgQADgUgBgAhiA6IAXAAQAQAAANgCQAMgDALgGQATgLAHgTQAJgSAAgVQAAgNgEgKQgFgJgHgGQgJgGgKgCQgLgCgQAAIgSAAg");
	this.shape_1.setTransform(74.1,72.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(61.5,63.5,25.3,18);


(lib.Symbol24 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(71.6,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABhBYIAAgeIg0AAIAAgRIA1g7IANAAIAABAIARAAIAAAMIgRAAIAAAegAA3AuIAqAAIAAgvgAh/BOIAnilIAnAAQASAAAPACQAPADALAIQAMAIAGANQAGANAAARQAAAZgOAZQgOAYgWANQgPAIgPADQgPADgVAAgAhkA7IAXAAQAQAAANgCQANgDALgGQASgLAHgTQAKgSAAgVQgBgNgEgJQgEgKgHgGQgKgGgKgCQgLgCgPAAIgTAAg");
	this.shape_1.setTransform(73.1,72.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(60.3,63.5,25.6,17.8);


(lib.Symbol23 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(69.9,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABEBXIgPgFIAAgPIACAAQAGAEAJADQAIACAIAAIAKgBQAEgBAEgDIAFgIQABgEAAgFQAAgGgCgEQgBgEgDgCIgIgDIgKgBIgHAAIAAgMIAFAAQALAAAGgEQAHgFAAgJQAAgEgCgBQgBgDgDgCIgHgCIgIgBQgHAAgIACQgHADgHAEIgBAAIAAgPIANgFQAJgCAJAAQAHAAAGABQAGACAGADQAEAEAEAFQACAEAAAFQAAAJgHAHQgFAHgKACIAAAAIAIADIAIAFQAEADACAFQADAEgBAIQAAAHgCAHQgDAFgFAGQgFAEgIADQgIACgIABQgJgBgJgCgAh9BMIAnikIAnAAQASgBAPADQAOADALAHQANAJAGANQAGANAAAQQAAAagOAZQgOAYgWANQgOAIgQADQgQACgUAAgAhiA6IAXAAQAQAAANgDQANgCAKgHQATgKAHgTQAKgSAAgWQAAgNgFgIQgFgKgGgGQgKgHgKgCQgKgBgRAAIgSAAg");
	this.shape_1.setTransform(70.8,72.8);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(58.2,63.8,25.2,18);


(lib.Symbol22 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(68.1,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AA1BYIAAgPIAdgaQAOgOAFgIQAGgIAAgJQAAgIgGgDQgGgFgKAAQgGAAgIACQgIADgHADIgBAAIAAgOIAOgFQAJgCAIAAQARAAAJAIQAJAIAAAMQAAAGgBAGQgCAFgDAFIgGAJIgpAmIA6AAIAAAMgAh9BOIAmilIAnAAQASAAAPACQAPADALAIQAMAIAGANQAGANAAARQAAAZgOAZQgOAYgWANQgOAIgQADQgPADgUAAgAhjA7IAXAAQAQAAANgCQANgDALgGQASgLAHgTQAKgSAAgVQAAgNgFgJQgEgKgHgGQgKgGgKgCQgKgCgQAAIgTAAg");
	this.shape_1.setTransform(67.5,72.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(54.9,63.8,25.4,17.8);


(lib.Symbol21 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAiAIAAEC");
	this.shape.setTransform(66.4,41.3);

	// Capa 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABBBYIAAgLIAWAAIAAhJIgWAAIAAgIIAJAAIAIgDQAEgBABgDQADgDAAgFIALAAIAABgIAWAAIAAALgAh6BOIAmilIAoAAQARAAAPACQANADANAIQAMAIAGANQAHANgBARQAAAZgOAZQgOAYgWANQgOAIgPADQgQADgUAAgAhfA7IAWAAQARAAANgCQAMgDALgGQATgLAGgTQAKgSAAgVQAAgNgEgJQgFgKgHgGQgKgGgKgCQgKgCgQAAIgTAAg");
	this.shape_1.setTransform(67.2,72.7);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(54.9,63.8,24.7,17.8);


(lib.Symbol20 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(123.1,-6.9,1.37,1.37);

	this.text_1 = new cjs.Text("5", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(124.4,32,1.37,1.37);

	this.text_2 = new cjs.Text("K =    ·      ", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(0,10.8,1.37,1.37);
this.text_2b = new cjs.Text("       k       ", "bold italic 20px Verdana",'#B30218');
	this.text_2b.lineHeight = 20;
	this.text_2b.setTransform(0,10.8,1.37,1.37);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjaAAIG1AA");
	this.shape.setTransform(136.9,32.2-incremento);

	this.addChild(this.shape,this.text_2,this.text_2b,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-6.9,162.5,77.8);


(lib.Symbol11 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("k = 3", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>3</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.8,0,60.7,28.3);


(lib.Symbol10 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("k = 2", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>2</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.8,0,60.7,28.3);


(lib.Symbol9 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("k = 1", "italic bold 20px Verdana", "#CC191F");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(55.2,0);
var html = createDiv("<b class='rojo_1'><i>k</i></b> = <span class='rojo_1'>1</span>", "Verdana", "20px", '100px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(55, -640);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(26.8,0,60.7,28.3);


(lib.Symbol8 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(148.2,0.6,1.412,1.412);

	this.text_1 = new cjs.Text("4", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(149.6,40.7,1.412,1.412);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjgAAIHCAA");
	this.shape.setTransform(162.5,41-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC191F").s().p("AgnBmQgRgEgKgFIAAgcIACAAQAMAHAPAFQAQAGAPAAQAHAAAKgDQAJgDAGgGQAHgGADgIQADgHAAgLQAAgLgEgHQgDgIgGgDQgHgFgIgCQgJgBgIAAIgNAAIAAgVIAKAAQATAAAMgJQANgIAAgRQAAgHgDgGQgEgGgFgEQgGgDgHgBIgNgCQgNAAgPAFQgPAFgNAIIgBAAIAAgdQAJgEARgFQAQgDAPAAQAOgBALADQALADAKAGQAKAHAFAJQAFAKAAAMQAAARgMANQgMANgRADIAAACQAHABAIADQAJAEAGADQAGAGAFAJQAEAJAAAOQAAAPgFALQgFAMgJAIQgLAKgOAFQgOAEgOABQgSgBgQgEg");
	this.shape_1.setTransform(97.7,39.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Am9B5QgMgLAAgTIABgKIgNABQglAAgUgUQgVgUAAglQAAgaAIgZQAJgZAPgTQAQgSAVgLQAXgLAbAAQAkAAAVAUQAVAUAAAlQAAArgVAjQgWAkgkANIgBAKQAAAOAGAFQAIAGANAAIANgCIAMgDIAEAAIgFAYIgRADIgQAAQgWAAgLgKgAnUhjQgPAJgMAQQgLAPgGAUQgGAUAAATQAAAdAOAPQAOAPAaAAQATAAAQgJQAPgJAMgOQALgQAGgSQAGgTAAgYQAAgcgOgPQgOgPgaAAQgTAAgQAJgAk2BcQgLgCgHgDIAAgTIABAAQAIAFAKADQAKAEAKAAQAGAAAGgCQAGgCAFgEQADgEACgFQADgEAAgIQAAgHgDgEQgCgFgEgDQgEgDgGgBIgMgBIgIAAIAAgPIAGAAQANAAAJgFQAIgGAAgJQAAgFgCgDQgCgEgEgCQgEgDgEgBIgKAAQgJAAgJADQgKADgJAFIAAAAIAAgTQAGgDALgCQALgDAKAAQAJAAAHACQAIACAGAEQAGAEAEAGQADAGAAAIQAAAKgHAIQgIAIgLACIAAABIAKADIAJAGQAEAEADAGQADAFAAAKQAAAJgEAHQgDAIgGAGQgHAGgIADQgKADgLAAQgKAAgLgDgAhdAbIAAgWIChAAIAAAWgAIDAHIAAglIAhAAIAAAlgAhdgdIAAgWIChAAIAAAWg");
	this.shape_2.setTransform(68.5,42.2);

	this.addChild(this.shape_2,this.shape_1,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(13.6,0.6,171.5,80.1);


(lib.Symbol7 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(141.8,1,1.412,1.412);

	this.text_1 = new cjs.Text("4", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(143.1,41.1,1.412,1.412);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjgAAIHBAA");
	this.shape.setTransform(156,41.4-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC191F").s().p("AhEBoIAAgdIA5gxQAYgaAKgNQAJgPABgRQAAgQgLgJQgKgJgSAAQgMAAgPAEQgOAEgPAJIAAAAIAAgdQAJgEARgEQAQgEAPAAQAdAAATAPQARAPABAaQAAAMgEAKQgDAKgFAJQgFAHgIAIIhMBIIBtAAIAAAXg");
	this.shape_1.setTransform(91.4,40);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Am9B5QgMgLAAgTIABgKIgNABQglAAgVgUQgUgUAAglQAAgaAIgZQAJgZAPgTQAPgSAXgLQAWgLAbAAQAkAAAVAUQAVAUAAAlQAAArgVAjQgWAkglANIAAAKQgBAOAIAFQAGAGAOAAIANgCIAMgDIAEAAIgFAYIgQADIgRAAQgWAAgLgKgAnUhjQgQAJgLAQQgLAPgGAUQgGAUAAATQAAAdAOAPQAOAPAZAAQAUAAAQgJQAPgJAMgOQALgQAGgSQAGgTAAgYQAAgcgOgPQgOgPgZAAQgUAAgQAJgAlJBcIAAgSIAlghQARgQAHgKQAGgKAAgJQAAgLgHgGQgHgFgMAAQgIAAgKACQgJADgJAGIgBAAIAAgTQAGgDALgCQALgDAKAAQAUAAALAKQAMAKAAARQAAAFgCAHQgBAHgEAFIgIALIgMAMIgnAjIBIAAIAAAPgAhdAbIAAgWICiAAIAAAWgAIDAHIAAglIAhAAIAAAlgAhdgdIAAgWICiAAIAAAWg");
	this.shape_2.setTransform(62,42.7);

	this.addChild(this.shape_2,this.shape_1,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(7.2,1.1,171.5,80.1);


(lib.Symbol6 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(140.4,-0.3,1.412,1.412);

	this.text_1 = new cjs.Text("4", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(141.8,39.7,1.412,1.412);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjgAAIHBAA");
	this.shape.setTransform(154.7,40-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC191F").s().p("Ag2BmIAAgUIAqAAIAAiIIgqAAIAAgTIATgBQAJgBAFgDQAHgEADgFQAEgFABgKIATAAIAAC4IAqAAIAAAUg");
	this.shape_1.setTransform(90.3,38.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Am9B5QgMgLAAgTIABgKIgNABQglAAgVgUQgUgUAAglQAAgaAIgZQAJgZAPgTQAPgSAXgLQAWgLAbAAQAkAAAVAUQAVAUAAAlQAAArgVAjQgWAkglANIAAAKQgBAOAIAFQAGAGAOAAIANgCIAMgDIAEAAIgFAYIgQADIgRAAQgWAAgLgKgAnUhjQgPAJgMAQQgLAPgGAUQgGAUAAATQAAAdAOAPQAOAPAZAAQAUAAAQgJQAPgJALgOQAMgQAGgSQAGgTAAgYQAAgcgOgPQgOgPgZAAQgUAAgQAJgAk+BcIAAgNIAbAAIAAhYIgbAAIAAgMIAMgBQAHgBADgCQAEgCADgDQABgEABgGIAOAAIAAB3IAbAAIAAANgAhdAbIAAgWICiAAIAAAWgAIDAHIAAglIAhAAIAAAlgAhdgdIAAgWICiAAIAAAWg");
	this.shape_2.setTransform(60.7,41.3);

	this.addChild(this.shape_2,this.shape_1,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(5.8,-0.3,171.5,80.1);


(lib.Symbol5 = function() {
	this.initialize();

	// Layer 1
	this.text = new cjs.Text("N", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(126.8,0,1.412,1.412);

	this.text_1 = new cjs.Text("4", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(128.1,40.1,1.412,1.412);

	this.text_2 = new cjs.Text("Q =   ·      ", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(0,18.3,1.412,1.412);
	this.text_2b = new cjs.Text("      k       ", "bold italic 20px Verdana","#B30218");
	this.text_2b.lineHeight = 20;
	this.text_2b.setTransform(0,18.3,1.412,1.412);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjgAAIHBAA");
	this.shape.setTransform(141,40.4-incremento);

	this.addChild(this.shape,this.text_2,this.text_2b,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,170.1,80.1);

(lib.animacion02_scn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 8
	this.instance = new lib.Symbol8();
	this.instance.setTransform(695,41.2,0.97,0.97,0,0,0,84.5,40);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(134).to({_off:false},0).to({alpha:1},12).wait(1));

	// Symbol 11
	this.instance_1 = new lib.Symbol11();
	this.instance_1.setTransform(696.5,-37.3,0.97,0.97,0,0,0,57.1,14.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(119).to({_off:false},0).to({alpha:1},12).wait(16));

	// Symbol 7
	this.instance_2 = new lib.Symbol7();
	this.instance_2.setTransform(492,41.2,0.97,0.97,0,0,0,84.5,40);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).to({alpha:1},12).wait(47));

	// Symbol 10
	this.instance_3 = new lib.Symbol10();
	this.instance_3.setTransform(493.4,-37.3,0.97,0.97,0,0,0,57.1,14.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(72).to({_off:false},0).to({alpha:1},12).wait(63));

	// Symbol 6
	this.instance_4 = new lib.Symbol6();
	this.instance_4.setTransform(286.7,41.2,0.97,0.97,0,0,0,84.5,40);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({alpha:1},12).wait(91));

	// Symbol 9
	this.instance_5 = new lib.Symbol9();
	this.instance_5.setTransform(286.7,-37.3,0.97,0.97,0,0,0,55.6,14.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(29).to({_off:false},0).to({alpha:1},12).wait(106));

	// Symbol 5
	this.instance_6 = new lib.Symbol5();
	this.instance_6.setTransform(499.4,-187.7,0.97,0.97,0,0,0,83.9,40);
	this.instance_6.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({alpha:1},12).wait(1350000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(418,-226.5,165,77.7);

(lib.animacon01_scn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Symbol 3
	this.instance = new lib.Symbol3();
	this.instance.setTransform(460,44.2,1,1,0,0,0,60.6,44.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({alpha:1},14).wait(16));

	// Symbol 2
	this.instance_1 = new lib.Symbol2();
	this.instance_1.setTransform(301.6,44.2,1,1,0,0,0,70.2,44.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({_off:false},0).to({alpha:1},14).wait(31));

	// Symbol 1
	this.instance_2 = new lib.Symbol1();
	this.instance_2.setTransform(113.6,44.2,1,1,0,0,0,60.1,44.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).to({_off:false},0).to({alpha:1},14).wait(46));

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC191F").ss(3,1,1).p("Eg0jAAAMBpHAAA");
	this.shape.setTransform(336.5,42.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(69000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);

    (lib._88019257 = function () {
        this.initialize(img._88019257);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 749, 550);


    (lib.Symbol3 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 1, 1).p("AAAiAIAAEC");
        this.shape.setTransform(105.9, 41.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgsBrQgLgJAAgSIABgJIgLABQghAAgSgSQgSgRAAghQAAgWAHgWQAHgWAOgRQANgRAUgJQAUgKAYAAQAeAAATARQASASAAAhQAAAngTAeQgTAggfAMIAAAEIAAAEQAAANAGAEQAGAFAMAAIAKgBIAKgDIAEAAIgFAVIgbADQgTAAgKgJgAhAhXQgOAIgKANQgKAOgGASQgFARAAARQAAAZANAOQAMANAXAAQARAAAOgIQAOgHAKgOQAIgOAFgPQAFgRAAgVQAAgZgMgNQgLgNgWAAQgRAAgOAIgABJBPQgJgCgGgDIAAgRIABAAQAGAFAKADQAJACAIAAIALgBQAFgCAEgDQAEgEABgEQACgEAAgGQAAgHgCgEQgCgEgDgCQgEgDgFgBIgLgBIgHAAIAAgNIAFAAQAMAAAIgFQAHgDAAgKQAAgEgCgDQgCgDgDgCQgEgDgDAAIgJgBQgIAAgIADQgJACgHAFIgBAAIAAgQQAGgDAJgCQAJgDAJAAQAJAAAGACQAHABAFAEQAGAEADAFQADAFAAAIQAAAJgHAGQgHAHgJACIAAABIAIADQAFACAEADQADADADAFQACAGAAAIQAAAIgDAHQgDAGgFAFQgGAGgIADQgIACgKAAQgJAAgKgCg");
        this.shape_1.setTransform(107.3, 74.1);

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(93.8, 28.3, 27.2, 57.5);


    (lib.Symbol2 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 1, 1).p("AAAiAIAAEC");
        this.shape.setTransform(103.4, 41.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgtBrQgLgJAAgSIABgJIgLABQghAAgSgSQgSgRAAghQAAgWAHgWQAHgWAOgRQANgRAUgJQAUgKAYAAQAeAAATARQASASAAAhQAAAngTAeQgSAgggAMIAAAEIAAAEQAAANAGAEQAGAFAMAAIAKgBIAKgDIAEAAIgFAVIgbADQgTAAgKgJgAhBhXQgOAIgKANQgKAOgGASQgFARAAARQAAAZANAOQAMANAXAAQARAAAOgIQAOgHAKgOQAIgOAFgPQAFgRAAgVQAAgZgLgNQgMgNgWAAQgRAAgOAIgAA4BPIAAgRIAggcQAQgPAFgJQAGgIAAgJQAAgJgGgFQgGgFgLAAQgHAAgJACQgIADgIAFIgBAAIAAgQQAGgDAJgDQAJgCAJAAQASAAALAJQAKAJAAAPQAAAGgCAEQgBAGgEAFIgHAKIgtApIBAAAIAAAOg");
        this.shape_1.setTransform(104.4, 74.1);

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(90.8, 28.3, 27.4, 57.5);


    (lib.Symbol1 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 1, 1).p("AAAiAIAAEC");
        this.shape.setTransform(114.4, 41.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AgqBrQgKgJAAgSIABgJIgMABQggAAgTgSQgSgRAAghQAAgWAHgWQAIgWAOgRQANgRAUgJQAUgKAXAAQAfAAASARQATASAAAhQAAAngTAeQgTAggfAMIAAAEIgBAEQAAANAGAEQAHAFALAAIAKgBIALgDIADAAIgEAVIgcADQgSAAgLgJgAg+hXQgOAIgKANQgKAOgFASQgFARAAARQAAAZAMAOQANANAWAAQARAAAOgIQAPgHAJgOQAIgOAGgPQAFgRAAgVQAAgZgNgNQgKgNgWAAQgSAAgOAIgABFBPIAAgMIAYAAIAAhNIgYAAIAAgLIALgBQAFgBADgCQAEgCACgDQACgDAAgFIANAAIAABpIAYAAIAAAMg");
        this.shape_1.setTransform(114.9, 75.3);

        this.addChild(this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(101.6, 28.3, 26.7, 58.7);

    (lib.mc_botons4 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // fons
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape.setTransform(105.4, 22.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_1.setTransform(105.4, 22.6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_2.setTransform(105.4, 22.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#666666").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape_3.setTransform(105.4, 22.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#666666").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_4.setTransform(105.4, 22.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).to({state: [{t: this.shape_2}, {t: this.shape}]}, 1).to({state: [{t: this.shape_4}, {t: this.shape_3}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(24.8, 3.6, 161.2, 38.1);


    (lib.mc_botons3 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // fons
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape.setTransform(105.4, 22.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_1.setTransform(105.4, 22.6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_2.setTransform(105.4, 22.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#666666").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape_3.setTransform(105.4, 22.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#666666").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_4.setTransform(105.4, 22.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).to({state: [{t: this.shape_2}, {t: this.shape}]}, 1).to({state: [{t: this.shape_4}, {t: this.shape_3}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(24.8, 3.6, 161.2, 38.1);


    (lib.mc_botons2 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // fons
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape.setTransform(105.4, 22.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_1.setTransform(105.4, 22.6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_2.setTransform(105.4, 22.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#666666").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape_3.setTransform(105.4, 22.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#666666").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_4.setTransform(105.4, 22.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).to({state: [{t: this.shape_2}, {t: this.shape}]}, 1).to({state: [{t: this.shape_4}, {t: this.shape_3}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(24.8, 3.6, 161.2, 38.1);


    (lib.mc_botons = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // fons
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape.setTransform(105.4, 22.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_1.setTransform(105.4, 22.6);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_2.setTransform(105.4, 22.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#666666").ss(1, 1, 1).p("AMmCCIAAkDQAAg8g8AAI3TAAQg8AAAAA8IAAEDQAAA8A8AAIXTAAQA8AAAAg8g");
        this.shape_3.setTransform(105.4, 22.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#666666").s().p("AroC+Qg9AAAAg8IAAkDQAAg8A9AAIXRAAQA9AAgBA8IAAEDQABA8g9AAg");
        this.shape_4.setTransform(105.4, 22.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).to({state: [{t: this.shape_2}, {t: this.shape}]}, 1).to({state: [{t: this.shape_4}, {t: this.shape_3}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(24.8, 3.6, 161.2, 38.1);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}