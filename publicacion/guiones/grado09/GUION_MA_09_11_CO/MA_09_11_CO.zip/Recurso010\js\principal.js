(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titol']);
this.btn_03 = new lib.btn_01();
	this.btn_03.setTransform(774,283.4,1.096,7.533,0,0,0,95,15);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_02 = new lib.btn_01();
	this.btn_02.setTransform(474.5,280.4,1.217,7.871,0,0,0,95,15);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_01(), 3);

	this.btn_01 = new lib.btn_01();
	this.btn_01.setTransform(179.5,280.5,1.154,8.043,0,0,0,95,15);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);

	this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "bold 16px Arial");
	this.txt_selecciona.textAlign = "center";
	this.txt_selecciona.lineHeight = 16;
	this.txt_selecciona.lineWidth = 233;
	this.txt_selecciona.setTransform(473.2,506.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AygCDIAAkEMAlBAAAIAAEEg");
	this.shape.setTransform(475.3,514.6);

	this.txt_boto_01 = new cjs.Text(txt['txt_boto_01'], "20px Verdana");
	this.txt_boto_01.textAlign = "center";
	this.txt_boto_01.lineHeight = 22;
	this.txt_boto_01.lineWidth = 162;
	this.txt_boto_01.setTransform(175.5,415.7);

	this.txt_boto_03 = new cjs.Text(txt['txt_boto_03'], "20px Verdana");
	this.txt_boto_03.textAlign = "center";
	this.txt_boto_03.lineHeight = 22;
	this.txt_boto_03.lineWidth = 161;
	this.txt_boto_03.setTransform(773.8,415.7);

	this.txt_boto_02 = new cjs.Text(txt['txt_boto_02'], "20px Verdana");
	this.txt_boto_02.textAlign = "center";
	this.txt_boto_02.lineHeight = 22;
	this.txt_boto_02.lineWidth = 165;
	this.txt_boto_02.setTransform(472,415.7);
     this.btn_01.on("click", function (evt) {
            putStage(new lib.frame2());
        });
   
     this.btn_02.on("click", function (evt) {
            putStage(new lib.frame3());
        });
     this.btn_03.on("click", function (evt) {
            putStage(new lib.frame4());
        });
	this.instance = new lib.Imatge_Intro();
	this.instance.setTransform(78.2,152,0.644,0.644);
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance,this.txt_boto_02,this.txt_boto_03,this.txt_boto_01,this.shape,this.txt_selecciona,this.btn_01,this.btn_02,this.btn_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_e1']);
this.mc_cilindroComplet = new lib.mc_cilindroComplet();
	this.mc_cilindroComplet.setTransform(475.5,342,1,1,0,0,0,77.6,167.8);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.mc_cilindroComplet);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e1_01'],"20px");
this.instance=new lib.cilindro1();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e1_07'],"20px");
this.instance=new lib.cilindro2();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e1_08'],"20px");
this.instance=new lib.cilindro2("single",60);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e1_09'],"20px");

 var html = createDiv(txt['e1_09b'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 120-608);
html = createDiv(txt['e1_10'], "Verdana", "20px", '800px', '100px', "20px", "185px", "center");
    this.texto2 = new lib.fadeText(html, 20);
    this.texto2.setTransform(90, 178-608);
    html = createDiv(txt['e1_09c'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto3 = new lib.fadeText(html, 60);
    this.texto3.setTransform(90, 120-608);
    html = createDiv(txt['e1_11'], "Verdana", "20px", '800px', '100px', "20px", "185px", "center");
    this.texto4 = new lib.fadeText(html, 80);
    this.texto4.setTransform(90, 380-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.texto1,this.texto2,this.texto3,this.texto4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e1_12'],"20px");
this.instance=new lib.cilindro3();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['e1_130'],"20px","810px");

 var html = createDiv(txt['e1_13'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 120-608);
html = createDiv(txt['e1_14'], "Verdana", "20px", '800px', '100px', "20px", "185px", "center");
    this.texto2 = new lib.fadeText(html, 20);
    this.texto2.setTransform(90, 190-608);
    html = createDiv(txt['e1_13b'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto3 = new lib.fadeText(html, 60);
    this.texto3.setTransform(90, 120-608);
    html = createDiv(txt['e1_15'], "Verdana", "20px", '800px', '100px', "20px", "185px", "center");
    this.texto4 = new lib.fadeText(html, 80);
    this.texto4.setTransform(90, 300-608);
      html = createDiv(txt['e1_13c'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto5 = new lib.fadeText(html, 120);
    this.texto5.setTransform(90, 120-608);
    html = createDiv(txt['e1_22'], "Verdana", "20px", '800px', '100px', "20px", "185px", "center");
    this.texto6 = new lib.fadeText(html, 160);
    this.texto6.setTransform(90, 390-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.texto1,this.texto2,this.texto3,this.texto4,this.texto5,this.texto6 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_e2']);
this.mc_Cono = new lib.mc_Cono();
	this.mc_Cono.setTransform(475.5,340.6,1,1,0,0,0,135.8,157.8);
 this.instance = new lib.fadeElement(this.mc_Cono, 0);
   
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_e2'],"20px");
	this.instance = new lib.mc_Cono_1();
	this.instance.setTransform(479,334.7,1,1,0,0,0,-45.2,66.5);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e2_01'],"20px");
this.instance=new lib.cono1();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e2_02'],"20px");
this.mc_Cono = new lib.mc_Cono();
	this.mc_Cono.setTransform(475.5,340.6,1,1,0,0,0,135.8,157.8);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.mc_Cono);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e2_03'],"20px");
	this.instance = new lib.mc_Formula();
	this.instance.setTransform(520.3,234.6,1,1,0,0,0,253.3,21.6);
 this.instance = new lib.fadeElement(this.instance, 25);
   
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.instance,this.texto2,this.texto3,this.texto4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e2_04'],"20px");
this.instance=new lib.cono2();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       // titulo2(this, txt['e2_05'],"19px","820px");
          var html = createDiv(txt['e2_05'], "Verdana", "19px", "820px", '100px', "20px", "185px", "left");
          html.style.zIndex=-1;
        this.titulo = new cjs.DOMElement(html);
        this.titulo.setTransform(90, -588);
        this.instance=new lib.mascara();
        this.instance.setTransform(90,20,2);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.texto1,this.texto2,this.texto3,this.texto4,this.texto5,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_e3']);
this.mc_Esfera = new lib.mc_Esfera();
	this.mc_Esfera.setTransform(473.7,339.7,1,1,0,0,0,191.6,187);
 this.instance = new lib.fadeElement(this.mc_Esfera, 0);
   
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e3_01'],"20px");
		this.text = new cjs.Text("r = 12 cm", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 108;
	this.text.setTransform(490.9,313.4);

	this.mc_Esfera = new lib.mc_Esfera();
	this.mc_Esfera.setTransform(475.3,339.7,1,1,0,0,0,191.6,187);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.mc_Esfera,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e3_02'],"20px");
this.instance=new lib.esfera1();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e3_03'],"20px");
this.instance = new lib.mc_Formula_1();
	this.instance.setTransform(473.9,227.8,1,1,0,0,0,74,27.4);
        this.instance = new lib.fadeElement(this.instance, 5);
 
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e3_04'],"20px");
	this.instance = new lib.mc_Formula_2();
	this.instance.setTransform(474.5,242.6,1,1,0,0,0,191.6,27.4);

 this.instance = new lib.fadeElement(this.instance, 5);
   
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.instance,this.texto2,this.texto3,this.texto4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['e3_05'],"20px");
this.instance=new lib.esfera2();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame4_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['e3_06'],"20px");
        
        	this.instance = new lib.mc_Formula_3();
	this.instance.setTransform(474.8,232.3,1,1,0,0,0,222.5,14);
this.instance = new lib.fadeElement(this.instance, 5);
  
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,  this.texto1,this.texto2,this.texto3,this.texto4,this.texto5,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size,ancho) {
        size = size || '25px';
        ancho = ancho || '790px';
        var html = createDiv(texto, "Verdana", size, ancho, '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.esfera2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{h5:0});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EgN1ArLIAAj+MBDpAAAIAAD+g");
	var mask_graphics_21 = new cjs.Graphics().p("Egh0ADnIAAnNMBDpAAAIAAHNg");
	var mask_graphics_22 = new cjs.Graphics().p("Egh0AFPIAAqdMBDpAAAIAAKdg");
	var mask_graphics_23 = new cjs.Graphics().p("Egh0AG3IAAttMBDpAAAIAANtg");
	var mask_graphics_24 = new cjs.Graphics().p("Egh0AIfIAAw9MBDpAAAIAAQ9g");
	var mask_graphics_25 = new cjs.Graphics().p("Egh0AKHIAA0NMBDpAAAIAAUNg");
	var mask_graphics_26 = new cjs.Graphics().p("Egh0ALvIAA3dMBDpAAAIAAXdg");
	var mask_graphics_27 = new cjs.Graphics().p("Egh0ANYIAA6vMBDpAAAIAAavg");
	var mask_graphics_28 = new cjs.Graphics().p("Egh0APAIAA9/MBDpAAAIAAd/g");
	var mask_graphics_29 = new cjs.Graphics().p("Egh0AQoMAAAghPMBDpAAAMAAAAhPg");
	var mask_graphics_30 = new cjs.Graphics().p("Egh0ASQMAAAgkfMBDpAAAMAAAAkfg");
	var mask_graphics_31 = new cjs.Graphics().p("Egh0AT4MAAAgnvMBDpAAAMAAAAnvg");
	var mask_graphics_32 = new cjs.Graphics().p("Egh0AVgMAAAgq/MBDpAAAMAAAAq/g");
	var mask_graphics_33 = new cjs.Graphics().p("Egh0AXIMAAAguPMBDpAAAMAAAAuPg");
	var mask_graphics_34 = new cjs.Graphics().p("Egh0AYwMAAAgxfMBDpAAAMAAAAxfg");
	var mask_graphics_35 = new cjs.Graphics().p("Egh0AaYMAAAg0vMBDpAAAMAAAA0vg");
	var mask_graphics_36 = new cjs.Graphics().p("Egh0AcBMAAAg4BMBDpAAAMAAAA4Bg");
	var mask_graphics_37 = new cjs.Graphics().p("Egh0AdpMAAAg7RMBDpAAAMAAAA7Rg");
	var mask_graphics_38 = new cjs.Graphics().p("EgN1ArMMAAAg+hMBDpAAAMAAAA+hg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:344.5,y:276.4}).wait(1).to({graphics:mask_graphics_21,x:472.4,y:529.7}).wait(1).to({graphics:mask_graphics_22,x:472.4,y:519.3}).wait(1).to({graphics:mask_graphics_23,x:472.4,y:508.8}).wait(1).to({graphics:mask_graphics_24,x:472.4,y:498.4}).wait(1).to({graphics:mask_graphics_25,x:472.4,y:488}).wait(1).to({graphics:mask_graphics_26,x:472.4,y:477.6}).wait(1).to({graphics:mask_graphics_27,x:472.4,y:467.2}).wait(1).to({graphics:mask_graphics_28,x:472.4,y:456.8}).wait(1).to({graphics:mask_graphics_29,x:472.4,y:446.4}).wait(1).to({graphics:mask_graphics_30,x:472.4,y:436}).wait(1).to({graphics:mask_graphics_31,x:472.4,y:425.6}).wait(1).to({graphics:mask_graphics_32,x:472.4,y:415.1}).wait(1).to({graphics:mask_graphics_33,x:472.4,y:404.7}).wait(1).to({graphics:mask_graphics_34,x:472.4,y:394.3}).wait(1).to({graphics:mask_graphics_35,x:472.4,y:383.9}).wait(1).to({graphics:mask_graphics_36,x:472.4,y:373.5}).wait(1).to({graphics:mask_graphics_37,x:472.4,y:363.1}).wait(1).to({graphics:mask_graphics_38,x:344.5,y:276.4}).wait(2));

	// Capa 7
	this.instance = new lib.mc_Llenado();
	this.instance.setTransform(475,339.2,1,1,0,0,0,192,186.6);
	this.instance._off = true;
this.instance.alpha=.5;
	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).wait(20));

	// FlashAICB
	this.mc_Esfera = new lib.mc_Esfera();
	this.mc_Esfera.setTransform(475.3,339.7,1,1,0,0,0,191.6,187);
	this.mc_Esfera.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.mc_Esfera).wait(1).to({regY:186.9,y:339.6,alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(283.7,152.7,383.3,373.9);

   
   (lib.esfera1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{h2:0});

	
	// Capa 5
	this.text = new cjs.Text("7.234,56 cm³", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 190;
	this.text.setTransform(672.8,325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},19).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgN1ArLIAAj+MBDpAAAIAAD+g");
	var mask_graphics_1 = new cjs.Graphics().p("Egh0ADnIAAnNMBDpAAAIAAHNg");
	var mask_graphics_2 = new cjs.Graphics().p("Egh0AFPIAAqdMBDpAAAIAAKdg");
	var mask_graphics_3 = new cjs.Graphics().p("Egh0AG3IAAttMBDpAAAIAANtg");
	var mask_graphics_4 = new cjs.Graphics().p("Egh0AIfIAAw9MBDpAAAIAAQ9g");
	var mask_graphics_5 = new cjs.Graphics().p("Egh0AKHIAA0NMBDpAAAIAAUNg");
	var mask_graphics_6 = new cjs.Graphics().p("Egh0ALvIAA3dMBDpAAAIAAXdg");
	var mask_graphics_7 = new cjs.Graphics().p("Egh0ANYIAA6vMBDpAAAIAAavg");
	var mask_graphics_8 = new cjs.Graphics().p("Egh0APAIAA9/MBDpAAAIAAd/g");
	var mask_graphics_9 = new cjs.Graphics().p("Egh0AQoMAAAghPMBDpAAAMAAAAhPg");
	var mask_graphics_10 = new cjs.Graphics().p("Egh0ASQMAAAgkfMBDpAAAMAAAAkfg");
	var mask_graphics_11 = new cjs.Graphics().p("Egh0AT4MAAAgnvMBDpAAAMAAAAnvg");
	var mask_graphics_12 = new cjs.Graphics().p("Egh0AVgMAAAgq/MBDpAAAMAAAAq/g");
	var mask_graphics_13 = new cjs.Graphics().p("Egh0AXIMAAAguPMBDpAAAMAAAAuPg");
	var mask_graphics_14 = new cjs.Graphics().p("Egh0AYwMAAAgxfMBDpAAAMAAAAxfg");
	var mask_graphics_15 = new cjs.Graphics().p("Egh0AaYMAAAg0vMBDpAAAMAAAA0vg");
	var mask_graphics_16 = new cjs.Graphics().p("Egh0AcBMAAAg4BMBDpAAAMAAAA4Bg");
	var mask_graphics_17 = new cjs.Graphics().p("Egh0AdpMAAAg7RMBDpAAAMAAAA7Rg");
	var mask_graphics_18 = new cjs.Graphics().p("EgN1ArMMAAAg+hMBDpAAAMAAAA+hg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:344.5,y:276.4}).wait(1).to({graphics:mask_graphics_1,x:472.4,y:529.7}).wait(1).to({graphics:mask_graphics_2,x:472.4,y:519.3}).wait(1).to({graphics:mask_graphics_3,x:472.4,y:508.8}).wait(1).to({graphics:mask_graphics_4,x:472.4,y:498.4}).wait(1).to({graphics:mask_graphics_5,x:472.4,y:488}).wait(1).to({graphics:mask_graphics_6,x:472.4,y:477.6}).wait(1).to({graphics:mask_graphics_7,x:472.4,y:467.2}).wait(1).to({graphics:mask_graphics_8,x:472.4,y:456.8}).wait(1).to({graphics:mask_graphics_9,x:472.4,y:446.4}).wait(1).to({graphics:mask_graphics_10,x:472.4,y:436}).wait(1).to({graphics:mask_graphics_11,x:472.4,y:425.6}).wait(1).to({graphics:mask_graphics_12,x:472.4,y:415.1}).wait(1).to({graphics:mask_graphics_13,x:472.4,y:404.7}).wait(1).to({graphics:mask_graphics_14,x:472.4,y:394.3}).wait(1).to({graphics:mask_graphics_15,x:472.4,y:383.9}).wait(1).to({graphics:mask_graphics_16,x:472.4,y:373.5}).wait(1).to({graphics:mask_graphics_17,x:472.4,y:363.1}).wait(1).to({graphics:mask_graphics_18,x:344.5,y:276.4}).wait(2).to({graphics:null,x:0,y:0}).wait(1));

	// Capa 7
	this.instance = new lib.mc_Llenado();
	this.instance.setTransform(475,339.2,1,1,0,0,0,192,186.6);
this.instance.alpha=.5;
	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Capa 8
	this.text_1 = new cjs.Text("r = 12 cm", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 108;
	this.text_1.setTransform(490.9,313.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1}]}).wait(1));

	// FlashAICB
	this.mc_Esfera = new lib.mc_Esfera();
	this.mc_Esfera.setTransform(475.3,339.7,1,1,0,0,0,191.6,187);

	this.timeline.addTween(cjs.Tween.get(this.mc_Esfera).wait(1).to({regY:186.9,y:339.6},0).wait(18).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(82.1,57.1,658.4,469.5);

     (lib.mascara = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 1 (mask)
        var mask = new cjs.Shape();
       mask.graphics.beginFill("#FFFFFF");
        //mask.graphics.p("A5EdSMAAAg6jMAyJAAAMAAAA6jg");
        //mask.setTransform(160.6,187.5);
        mask.graphics.drawRect(0, 0, 430, 600);
        // Capa 2
      
        this.timeline.addTween(cjs.Tween.get(mask).wait(1).to({y: 110}, 44).wait(40).to({y: 210}, 44).wait(40).to({y: 320}, 44).wait(40).to({y: 450}, 44).wait(30).to({y: 630}, 44).wait(30));
        
    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 531.3, 374.9);
    
   (lib.cono2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{f5:0});

	// FlashAICB
	this.instance = new lib.mc_DesarrolloCono();
	this.instance.setTransform(475.3,340.1,1,1,0,0,0,258.5,190);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// FlashAICB
	this.instance_1 = new lib.mc_ConoComplet();
	this.instance_1.setTransform(475.1,348.5,1,1,0,0,0,135.8,166);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:161.7,y:344.2,alpha:0.067},0).wait(1).to({alpha:0.133},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.267},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.467},0).wait(1).to({alpha:0.533},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.733},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.867},0).wait(1).to({alpha:0.933},0).wait(1).to({alpha:1},0).wait(24).wait(1).to({alpha:0.938},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(339.3,174,271.6,340.5);


   (lib.cono1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{f2:0});
// FlashAICB
	this.instance_1 = new lib.mc_BaseCono();
	this.instance_1.setTransform(468.5,426.9,1,1,0,0,0,135.8,28.6);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:142.4,regY:70.2,x:475.1,y:468.5,alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(28));
	// Capa 40 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_11 = new cjs.Graphics().p("A68A0IAAhnMA15AAAIAABng");
	var mask_1_graphics_12 = new cjs.Graphics().p("A68BtIAAjZMA15AAAIAADZg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A68CmIAAlLMA15AAAIAAFLg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A68DeIAAm7MA15AAAIAAG7g");
	var mask_1_graphics_15 = new cjs.Graphics().p("A68EXIAAotMA15AAAIAAItg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A68FQIAAqfMA15AAAIAAKfg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A68GJIAAsRMA15AAAIAAMRg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A68HCIAAuDMA15AAAIAAODg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A68H6IAAvzMA15AAAIAAPzg");
	var mask_1_graphics_20 = new cjs.Graphics().p("A68IzIAAxlMA15AAAIAARlg");
	var mask_1_graphics_21 = new cjs.Graphics().p("A68JsIAAzXMA15AAAIAATXg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A68KlIAA1JMA15AAAIAAVJg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A68LeIAA27MA15AAAIAAW7g");
	var mask_1_graphics_24 = new cjs.Graphics().p("A68MWIAA4rMA15AAAIAAYrg");
	var mask_1_graphics_25 = new cjs.Graphics().p("A68NPIAA6dMA15AAAIAAadg");
	var mask_1_graphics_26 = new cjs.Graphics().p("A68OIIAA8PMA15AAAIAAcPg");
	var mask_1_graphics_27 = new cjs.Graphics().p("A68PBIAA+BMA15AAAIAAeBg");
	var mask_1_graphics_28 = new cjs.Graphics().p("A68P6IAA/zMA15AAAIAAfzg");
	var mask_1_graphics_29 = new cjs.Graphics().p("A68QyMAAAghkMA15AAAMAAAAhkg");
	var mask_1_graphics_30 = new cjs.Graphics().p("A68RrMAAAgjVMA15AAAMAAAAjVg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A68SkMAAAglHMA15AAAMAAAAlHg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A68TdMAAAgm5MA15AAAMAAAAm5g");
	var mask_1_graphics_33 = new cjs.Graphics().p("A68UWMAAAgorMA15AAAMAAAAorg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A68VPMAAAgqdMA15AAAMAAAAqdg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A68WHMAAAgsNMA15AAAMAAAAsNg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A68XAMAAAgt/MA15AAAMAAAAt/g");
	var mask_1_graphics_37 = new cjs.Graphics().p("A68X5MAAAgvxMA15AAAMAAAAvxg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgD+AltMAAAgxjMA14AAAMAAAAxjg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_1_graphics_11,x:466.4,y:477.4}).wait(1).to({graphics:mask_1_graphics_12,x:466.4,y:471.7}).wait(1).to({graphics:mask_1_graphics_13,x:466.4,y:466}).wait(1).to({graphics:mask_1_graphics_14,x:466.4,y:460.3}).wait(1).to({graphics:mask_1_graphics_15,x:466.4,y:454.6}).wait(1).to({graphics:mask_1_graphics_16,x:466.4,y:448.9}).wait(1).to({graphics:mask_1_graphics_17,x:466.4,y:443.3}).wait(1).to({graphics:mask_1_graphics_18,x:466.4,y:437.6}).wait(1).to({graphics:mask_1_graphics_19,x:466.4,y:431.9}).wait(1).to({graphics:mask_1_graphics_20,x:466.4,y:426.2}).wait(1).to({graphics:mask_1_graphics_21,x:466.4,y:420.5}).wait(1).to({graphics:mask_1_graphics_22,x:466.4,y:414.9}).wait(1).to({graphics:mask_1_graphics_23,x:466.4,y:409.2}).wait(1).to({graphics:mask_1_graphics_24,x:466.4,y:403.5}).wait(1).to({graphics:mask_1_graphics_25,x:466.4,y:397.8}).wait(1).to({graphics:mask_1_graphics_26,x:466.4,y:392.1}).wait(1).to({graphics:mask_1_graphics_27,x:466.4,y:386.5}).wait(1).to({graphics:mask_1_graphics_28,x:466.4,y:380.8}).wait(1).to({graphics:mask_1_graphics_29,x:466.4,y:375.1}).wait(1).to({graphics:mask_1_graphics_30,x:466.4,y:369.4}).wait(1).to({graphics:mask_1_graphics_31,x:466.4,y:363.7}).wait(1).to({graphics:mask_1_graphics_32,x:466.4,y:358.1}).wait(1).to({graphics:mask_1_graphics_33,x:466.4,y:352.4}).wait(1).to({graphics:mask_1_graphics_34,x:466.4,y:346.7}).wait(1).to({graphics:mask_1_graphics_35,x:466.4,y:341}).wait(1).to({graphics:mask_1_graphics_36,x:466.4,y:335.3}).wait(1).to({graphics:mask_1_graphics_37,x:466.4,y:329.7}).wait(1).to({graphics:mask_1_graphics_38,x:319.5,y:241.3}).wait(1));

	// FlashAICB
	this.instance = new lib.mc_AlturaCono();
	this.instance.setTransform(475.3,325.3,1,1,0,0,0,135.6,143.2);
	this.instance._off = true;

	this.instance.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).wait(28));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(339.4,440,271.6,57.2);


   (lib.cilindro3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{p5:0});

	// FlashAICB
	this.instance = new lib.mc_desarrollo();
	this.instance.setTransform(487,365.1,1,1,0,0,0,134.2,166.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

	// Cilindro
	this.instance_1 = new lib.mc_cilindroComplet();
	this.instance_1.setTransform(474.5,364.5,1,1,0,0,0,77.6,167.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).wait(1).to({alpha:0.941},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(396.9,196.7,155.2,335.6);

   (lib.cilindro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{p2:0,p3:58});

	// FlashAICB
	this.instance_1 = new lib.mc_BaseCilindro();
	this.instance_1.setTransform(477.2,487.1,1,1,0,0,0,77.2,34.2);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:-5.5,regY:35.6,x:394.4,y:488.5,alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(138));
	// FlashAICB (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	var mask_8_graphics_18 = new cjs.Graphics().p("EARHAqSIAAi4Ia/AAIAAC4g");
	var mask_8_graphics_19 = new cjs.Graphics().p("AteCaIAAkzIa9AAIAAEzg");
	var mask_8_graphics_20 = new cjs.Graphics().p("AteDYIAAmvIa9AAIAAGvg");
	var mask_8_graphics_21 = new cjs.Graphics().p("AteEXIAAotIa9AAIAAItg");
	var mask_8_graphics_22 = new cjs.Graphics().p("AteFVIAAqpIa9AAIAAKpg");
	var mask_8_graphics_23 = new cjs.Graphics().p("AteGUIAAsnIa9AAIAAMng");
	var mask_8_graphics_24 = new cjs.Graphics().p("AteHSIAAujIa9AAIAAOjg");
	var mask_8_graphics_25 = new cjs.Graphics().p("AteIQIAAwfIa9AAIAAQfg");
	var mask_8_graphics_26 = new cjs.Graphics().p("AteJPIAAydIa9AAIAASdg");
	var mask_8_graphics_27 = new cjs.Graphics().p("AteKNIAA0ZIa9AAIAAUZg");
	var mask_8_graphics_28 = new cjs.Graphics().p("AteLLIAA2VIa9AAIAAWVg");
	var mask_8_graphics_29 = new cjs.Graphics().p("AteMKIAA4TIa9AAIAAYTg");
	var mask_8_graphics_30 = new cjs.Graphics().p("AteNIIAA6PIa9AAIAAaPg");
	var mask_8_graphics_31 = new cjs.Graphics().p("AteOGIAA8LIa9AAIAAcLg");
	var mask_8_graphics_32 = new cjs.Graphics().p("AtePFIAA+JIa9AAIAAeJg");
	var mask_8_graphics_33 = new cjs.Graphics().p("AteQDMAAAggFIa9AAMAAAAgFg");
	var mask_8_graphics_34 = new cjs.Graphics().p("AteRBMAAAgiBIa9AAMAAAAiBg");
	var mask_8_graphics_35 = new cjs.Graphics().p("AteSAMAAAgj/Ia9AAMAAAAj/g");
	var mask_8_graphics_36 = new cjs.Graphics().p("AteS+MAAAgl7Ia9AAMAAAAl7g");
	var mask_8_graphics_37 = new cjs.Graphics().p("AteT9MAAAgn5Ia9AAMAAAAn5g");
	var mask_8_graphics_38 = new cjs.Graphics().p("AteU7MAAAgp1Ia9AAMAAAAp1g");
	var mask_8_graphics_39 = new cjs.Graphics().p("AteV5MAAAgrxIa9AAMAAAArxg");
	var mask_8_graphics_40 = new cjs.Graphics().p("AteW4MAAAgtvIa9AAMAAAAtvg");
	var mask_8_graphics_41 = new cjs.Graphics().p("AteX2MAAAgvrIa9AAMAAAAvrg");
	var mask_8_graphics_42 = new cjs.Graphics().p("AteY0MAAAgxnIa9AAMAAAAxng");
	var mask_8_graphics_43 = new cjs.Graphics().p("AteZzMAAAgzlIa9AAMAAAAzlg");
	var mask_8_graphics_44 = new cjs.Graphics().p("AteaxMAAAg1hIa9AAMAAAA1hg");
	var mask_8_graphics_45 = new cjs.Graphics().p("AtebvMAAAg3dIa9AAMAAAA3dg");
	var mask_8_graphics_46 = new cjs.Graphics().p("EARHAqSMAAAg5bIa/AAMAAAA5bg");

	this.timeline.addTween(cjs.Tween.get(mask_8).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_8_graphics_18,x:282.3,y:270.7}).wait(1).to({graphics:mask_8_graphics_19,x:478.2,y:525.8}).wait(1).to({graphics:mask_8_graphics_20,x:478.2,y:519.6}).wait(1).to({graphics:mask_8_graphics_21,x:478.2,y:513.4}).wait(1).to({graphics:mask_8_graphics_22,x:478.2,y:507.1}).wait(1).to({graphics:mask_8_graphics_23,x:478.2,y:500.9}).wait(1).to({graphics:mask_8_graphics_24,x:478.2,y:494.7}).wait(1).to({graphics:mask_8_graphics_25,x:478.2,y:488.4}).wait(1).to({graphics:mask_8_graphics_26,x:478.2,y:482.2}).wait(1).to({graphics:mask_8_graphics_27,x:478.2,y:476}).wait(1).to({graphics:mask_8_graphics_28,x:478.2,y:469.7}).wait(1).to({graphics:mask_8_graphics_29,x:478.2,y:463.5}).wait(1).to({graphics:mask_8_graphics_30,x:478.2,y:457.2}).wait(1).to({graphics:mask_8_graphics_31,x:478.2,y:451}).wait(1).to({graphics:mask_8_graphics_32,x:478.2,y:444.8}).wait(1).to({graphics:mask_8_graphics_33,x:478.2,y:438.5}).wait(1).to({graphics:mask_8_graphics_34,x:478.2,y:432.3}).wait(1).to({graphics:mask_8_graphics_35,x:478.2,y:426.1}).wait(1).to({graphics:mask_8_graphics_36,x:478.2,y:419.8}).wait(1).to({graphics:mask_8_graphics_37,x:478.2,y:413.6}).wait(1).to({graphics:mask_8_graphics_38,x:478.2,y:407.4}).wait(1).to({graphics:mask_8_graphics_39,x:478.2,y:401.1}).wait(1).to({graphics:mask_8_graphics_40,x:478.2,y:394.9}).wait(1).to({graphics:mask_8_graphics_41,x:478.2,y:388.7}).wait(1).to({graphics:mask_8_graphics_42,x:478.2,y:382.4}).wait(1).to({graphics:mask_8_graphics_43,x:478.2,y:376.2}).wait(1).to({graphics:mask_8_graphics_44,x:478.2,y:369.9}).wait(1).to({graphics:mask_8_graphics_45,x:478.2,y:363.7}).wait(1).to({graphics:mask_8_graphics_46,x:282.3,y:270.7}).wait(1).to({graphics:null,x:0,y:0}).wait(101));

	// Capa 16
	this.instance = new lib.mc_CuerpoCilindro();
	this.instance.setTransform(477.6,353,1,1,0,0,0,77.4,167.2);

	this.text = new cjs.Text("h = 14 cm", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 100;
	this.text.setTransform(559.6,328.3);

	this.instance.mask = this.text.mask = mask_8;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},18).to({state:[{t:this.instance},{t:this.text}]},39).wait(91));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(311.2,471.6,165.8,34);


   (lib.cilindro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{p1:0});

	// Txts
	this.e1_01 = new cjs.Text("", "20px Verdana");
	this.e1_01.lineHeight = 22;
	this.e1_01.lineWidth = 782;
	this.e1_01.setTransform(82.6,50.5);

	this.e1_06 = new cjs.Text(txt['e1_06'], "18px Verdana");
	this.e1_06.textAlign = "center";
	this.e1_06.lineHeight = 20;
	this.e1_06.lineWidth = 69;
	this.e1_06.setTransform(637.3,466.5+incremento);

	this.e1_05 = new cjs.Text(txt['e1_05'], "18px Verdana");
	this.e1_05.textAlign = "center";
	this.e1_05.lineHeight = 20;
	this.e1_05.lineWidth = 69;
	this.e1_05.setTransform(637.3,239.5+incremento);

	this.e1_04 = new cjs.Text(txt['e1_04'], "18px Verdana");
	this.e1_04.textAlign = "center";
	this.e1_04.lineHeight = 20;
	this.e1_04.lineWidth = 69;
	this.e1_04.setTransform(374.3,483.4+incremento);

	this.e1_03 = new cjs.Text("Altura", "18px Verdana");
	this.e1_03.lineHeight = 20;
	this.e1_03.lineWidth = 62;
	this.e1_03.setTransform(421.6,355.5+incremento);

	this.e1_02 = new cjs.Text(txt['e1_02'], "18px Verdana");
	this.e1_02.textAlign = "center";
	this.e1_02.lineHeight = 20;
	this.e1_02.lineWidth = 129;
	this.e1_02.setTransform(505.3,181.5+incremento);

	this.text = new cjs.Text("r", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 22;
	this.text.setTransform(553.1,454+incremento);

	this.text_1 = new cjs.Text("h", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 22;
	this.text_1.setTransform(608.1,354+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text},{t:this.e1_02},{t:this.e1_03},{t:this.e1_04},{t:this.e1_05},{t:this.e1_06},{t:this.e1_01}]},118).wait(1));

	// FlashAICB
	this.instance = new lib.mc_Flechas();
	this.instance.setTransform(507.9,211,1,1,0,0,0,92.4,3.6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(97).to({_off:false},0).wait(1).to({alpha:0.083},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.417},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.583},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.917},0).wait(1).to({alpha:1},0).wait(10));

	// Eje
	this.instance_1 = new lib.mc_EjeGiro();
	this.instance_1.setTransform(474.6,370.5,1,1,0,0,0,13,155);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(54).wait(1).to({x:469.9},0).wait(1).to({x:465.3},0).wait(1).to({x:460.6},0).wait(1).to({x:456},0).wait(1).to({x:451.3},0).wait(1).to({x:446.7},0).wait(1).to({x:442},0).wait(1).to({x:437.4},0).wait(1).to({x:432.7},0).wait(1).to({x:428.1},0).wait(1).to({x:423.4},0).wait(1).to({x:418.8},0).wait(1).to({x:414.2},0).wait(33));

	// Cuadrado
	this.instance_2 = new lib.mc_Cuadrado();
	this.instance_2.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:177.7,regY:142,x:437.5,y:369.5,alpha:0.111},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:1},0).wait(10).wait(1).to({scaleX:0.93,x:439.9},0).wait(1).to({scaleX:0.86,x:442.4},0).wait(1).to({scaleX:0.79,x:444.9},0).wait(1).to({scaleX:0.72,x:447.4},0).wait(1).to({scaleX:0.66,x:449.9},0).wait(1).to({scaleX:0.59,x:452.3},0).wait(1).to({scaleX:0.52,x:454.8},0).wait(1).to({scaleX:0.45,x:457.3},0).wait(1).to({scaleX:0.38,x:459.8},0).wait(1).to({scaleX:0.31,x:462.3},0).wait(1).to({scaleX:0.24,x:464.8},0).wait(1).to({scaleX:0.17,x:467.3},0).wait(1).to({scaleX:0.1,x:469.8},0).wait(1).to({scaleX:0.03,x:472.3},0).wait(1).to({skewY:180,x:474.7},0).wait(1).to({scaleX:0.1,x:477.2},0).wait(1).to({scaleX:0.17,x:479.7},0).wait(1).to({scaleX:0.24,x:482.2},0).wait(1).to({scaleX:0.31,x:484.7},0).wait(1).to({scaleX:0.38,x:487.2},0).wait(1).to({scaleX:0.45,x:489.7},0).wait(1).to({scaleX:0.52,x:492.2},0).wait(1).to({scaleX:0.59,x:494.7},0).wait(1).to({scaleX:0.66,x:497.1},0).wait(1).to({scaleX:0.72,x:499.6},0).wait(1).to({scaleX:0.79,x:502.1},0).wait(1).to({scaleX:0.86,x:504.6},0).wait(1).to({scaleX:0.93,x:507.1},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.88,x:505},0).wait(1).to({scaleX:0.75,x:500.6},0).wait(1).to({scaleX:0.63,x:496},0).wait(1).to({scaleX:0.5,x:491.5},0).wait(1).to({scaleX:0.38,x:487},0).wait(1).to({scaleX:0.25,x:482.5},0).wait(1).to({scaleX:0.13,x:478},0).wait(1).to({scaleX:0,skewY:0,x:256},0).wait(1).to({scaleX:0.13,x:469},0).wait(1).to({scaleX:0.25,x:464.5},0).wait(1).to({scaleX:0.38,x:460},0).wait(1).to({scaleX:0.5,x:455.5},0).wait(1).to({scaleX:0.63,x:451},0).wait(1).to({scaleX:0.75,x:446.5},0).wait(1).to({scaleX:0.88,x:442},0).wait(1).to({scaleX:1,x:437.5},0).wait(9).wait(1).to({x:432.8},0).wait(1).to({x:428.2},0).wait(1).to({x:423.5},0).wait(1).to({x:418.9},0).wait(1).to({x:414.2},0).wait(1).to({x:409.6},0).wait(1).to({x:404.9},0).wait(1).to({x:400.3},0).wait(1).to({x:395.6},0).wait(1).to({x:391},0).wait(1).to({x:386.3},0).wait(1).to({x:381.7},0).wait(1).to({x:377.1},0).wait(33));

	// Mask
	this.instance_3 = new lib.mc_Cuadrado();
	this.instance_3.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(22).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).wait(1).to({scaleX:0.56,x:493.6},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,x:512},0).wait(1).to({scaleX:0.11,skewY:0,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).wait(1).to({scaleX:0.33,x:461.5},0).wait(1).to({scaleX:0.44,x:457.5},0).wait(1).to({scaleX:0.56,x:453.5},0).wait(1).to({scaleX:0.67,x:449.5},0).wait(1).to({scaleX:0.78,x:445.5},0).wait(1).to({scaleX:0.89,x:441.5},0).wait(1).to({scaleX:1,x:437.5},0).wait(3).to({_off:true},1).wait(56));

	// Mask
	this.instance_4 = new lib.mc_Cuadrado();
	this.instance_4.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).wait(1).to({scaleX:0.56,x:493.6},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,x:512},0).wait(1).to({scaleX:0.11,skewY:0,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).wait(1).to({scaleX:0.33,x:461.5},0).wait(1).to({scaleX:0.44,x:457.5},0).wait(1).to({scaleX:0.56,x:453.5},0).wait(1).to({scaleX:0.67,x:449.5},0).wait(1).to({scaleX:0.78,x:445.5},0).wait(1).to({scaleX:0.89,x:441.5},0).wait(1).to({scaleX:1,x:437.5},0).wait(1).to({_off:true},1).wait(56));

	// Mask
	this.instance_5 = new lib.mc_Cuadrado();
	this.instance_5.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(26).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.5},0).wait(1).to({scaleX:0.78,x:501.5},0).wait(1).to({scaleX:0.67,x:497.5},0).wait(1).to({scaleX:0.56,x:493.5},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,skewY:0,x:473.5},0).wait(1).to({scaleX:0.11,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).wait(1).to({scaleX:0.33,x:461.5},0).wait(1).to({scaleX:0.44,x:457.5},0).wait(1).to({scaleX:0.56,x:453.4},0).wait(1).to({scaleX:0.67,x:449.4},0).wait(1).to({scaleX:0.78,x:445.4},0).wait(1).to({scaleX:0.89,x:441.4},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_6 = new lib.mc_Cuadrado();
	this.instance_6.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(28).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.5},0).wait(1).to({scaleX:0.78,x:501.5},0).wait(1).to({scaleX:0.67,x:497.5},0).wait(1).to({scaleX:0.56,x:493.5},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,skewY:0,x:473.5},0).wait(1).to({scaleX:0.11,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).wait(1).to({scaleX:0.33,x:461.5},0).wait(1).to({scaleX:0.44,x:457.5},0).wait(1).to({scaleX:0.56,x:453.4},0).wait(1).to({scaleX:0.67,x:449.4},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_7 = new lib.mc_Cuadrado();
	this.instance_7.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(30).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).wait(1).to({scaleX:0.56,x:493.6},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,x:473.5},0).wait(1).to({scaleX:0.11,skewY:0,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).wait(1).to({scaleX:0.33,x:461.5},0).wait(1).to({scaleX:0.44,x:457.5},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_8 = new lib.mc_Cuadrado();
	this.instance_8.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(32).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).wait(1).to({scaleX:0.56,x:493.6},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,x:473.5},0).wait(1).to({scaleX:0.11,skewY:0,x:469.5},0).wait(1).to({scaleX:0.22,x:465.5},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_9 = new lib.mc_Cuadrado();
	this.instance_9.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(34).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).wait(1).to({scaleX:0.56,x:493.6},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).wait(1).to({scaleX:0.11,x:477.5},0).wait(1).to({scaleX:0,x:512},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_10 = new lib.mc_Cuadrado();
	this.instance_10.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(36).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.5},0).wait(1).to({scaleX:0.78,x:501.5},0).wait(1).to({scaleX:0.67,x:497.5},0).wait(1).to({scaleX:0.56,x:493.5},0).wait(1).to({scaleX:0.44,x:489.5},0).wait(1).to({scaleX:0.33,x:485.5},0).wait(1).to({scaleX:0.22,x:481.5},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_11 = new lib.mc_Cuadrado();
	this.instance_11.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(38).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.5},0).wait(1).to({scaleX:0.78,x:501.5},0).wait(1).to({scaleX:0.67,x:497.5},0).wait(1).to({scaleX:0.56,x:493.5},0).wait(1).to({scaleX:0.44,x:489.5},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_12 = new lib.mc_Cuadrado();
	this.instance_12.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(40).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).wait(1).to({scaleX:0.78,x:501.6},0).wait(1).to({scaleX:0.67,x:497.6},0).to({_off:true},1).wait(56));

	// FlashAICB
	this.instance_13 = new lib.mc_Cuadrado();
	this.instance_13.setTransform(473.6,370.5,1,1,0,0,0,213.8,143);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(42).to({_off:false},0).wait(1).to({regX:177.7,regY:142,scaleX:0.9,x:441.3,y:369.5},0).wait(1).to({scaleX:0.79,x:445.1},0).wait(1).to({scaleX:0.68,x:448.9},0).wait(1).to({scaleX:0.58,x:452.7},0).wait(1).to({scaleX:0.47,x:456.4},0).wait(1).to({scaleX:0.37,x:460.2},0).wait(1).to({scaleX:0.26,x:464},0).wait(1).to({scaleX:0.16,x:467.8},0).wait(1).to({scaleX:0.05,x:471.6},0).wait(1).to({skewY:180,x:475.4},0).wait(1).to({scaleX:0.16,x:479.2},0).wait(1).to({scaleX:0.26,x:483},0).wait(1).to({scaleX:0.37,x:486.8},0).wait(1).to({scaleX:0.47,x:490.6},0).wait(1).to({scaleX:0.58,x:494.4},0).wait(1).to({scaleX:0.68,x:498.2},0).wait(1).to({scaleX:0.79,x:502},0).wait(1).to({scaleX:0.9,x:505.8},0).wait(1).to({scaleX:1,x:509.6},0).wait(1).to({scaleX:0.89,x:505.6},0).to({_off:true},1).wait(56));

	// FlashAICB (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	var mask_9_graphics_19 = new cjs.Graphics().p("AltR0MAAAgjnILbAAMAAAAjng");
	var mask_9_graphics_20 = new cjs.Graphics().p("AlGNJIArpIQAAhwgMhzQgMjDgRjKQgRjNgMjSQgMiCAAiEIARAAIKkgyIAAN8IAmIOIAALQIq0Azg");
	var mask_9_graphics_21 = new cjs.Graphics().p("AkeM/IBVonQgBhjgYhnQgYizgii/QgijCgYjMQgXiAgBiEIASAAIJ+hiIAAMAIBNHxIAALbIqNBlg");
	var mask_9_graphics_22 = new cjs.Graphics().p("Aj3M1IB/oHQAAhVgkhcQgkijgzizQgzi3gkjFQgkh+gBiEIASAAIJZiUIAAKEIB0HUIAALnIpnCYg");
	var mask_9_graphics_23 = new cjs.Graphics().p("AjQMqICqnmQgBhIgvhPQgwiVhFimQhEirgwi/Qgvh8gBiEIASAAIIzjGIAAIJICaG3IAALyIpADLg");
	var mask_9_graphics_24 = new cjs.Graphics().p("AipMgIDTnGQgCg6g5hEQg8iEhVicQhVifg8i5Qg8h5gBiEIATAAIINj4IAAGOIDBGbIAAL9IoaD9g");
	var mask_9_graphics_25 = new cjs.Graphics().p("AiCMWID9mlQgBgthHg5QhGh0hniSQhmiShIiyQhHh4gBiEIASAAIHokoIAAESIDnF+IAAMIInzEvg");
	var mask_9_graphics_26 = new cjs.Graphics().p("AhbMMIEomFQgCgfhSgtQhVhkh1iHQh3iGhVisQhSh2gCiEIATAAIHClaIAACXIEOFgIAAMUInNFig");
	var mask_9_graphics_27 = new cjs.Graphics().p("Ag0MCIFTllQgCgRhfgiQhghTiGh8QiJh9hgikQhfhzgBiEIATAAIGcmMIAAAbIE0FDIAAMgImmGVg");
	var mask_9_graphics_28 = new cjs.Graphics().p("AgML/IEPlDIABAAQBqAWACAEIl8FEgAAAEJQiZhyhtieQhqhxgCiEIAUAAIF2m9IAAhgIFbElIAAMrIhwCFQhshDiXhwg");
	var mask_9_graphics_29 = new cjs.Graphics().p("AgML+IC/kbQA8AfAzAWQBjAJASgGImjEhgAGbIZQAAAAgBAAQAAABAAAAQgBAAgBABQAAAAgBAAgAAAGAQiphnh4iZQh2hvgDiCIAUAAIFTnuIAAjcIGAEIIAAM3IiaDfQhRgphig6g");
	var mask_9_graphics_30 = new cjs.Graphics().p("AgOL9IB1jXQB6A1BeAYQBFAAAhgHImzDygAHEJbQgBALgeAGgAAAH3Qi6hbiEiTQiChtgDiEIAUAAIEuoeIAAlXIGmDrIAANCIi+FWQgxgVg2gag");
	var mask_9_graphics_31 = new cjs.Graphics().p("AgPL8IA2h/QCzBBCCARIAugFImZC2gAHtKeQgCAehhAOgAAAJuQjLhQiQiMQiOhrgDiEIAUAAIEIpPIAAnTIHNDNIAANOIjWHhIgngPg");
	var mask_9_graphics_32 = new cjs.Graphics().p("AgRL6IAJgYIAIADQC8A5CNAKIlaB7gAFJMoIDNhIQgDAziZAXIgxgCgAl5IbQiZhqgDiEIAVAAIDhqAIAApPIH0CxIAANaIjdJ5QjXhEiaiDg");
	var mask_9_graphics_33 = new cjs.Graphics().p("AgSNXIASAFQB4AcBmALIjwBCgADeODIFhhhQgDBBilAjQgiADglAAQg2AAg8gGgAmWKkQilhogDiEIAVAAIC8qyIAArKIIaCTIAANmIi/LEIAABeQjig5iih6g");
	var mask_9_graphics_34 = new cjs.Graphics().p("AApPWII/h1QgDBOixAvQhJAMhVAAQhtAAiAgUgAgTPMIATADIApAHIg8ANgAmzMpQixhlgDiEIAVAAICWrkIAAtFIJBB1IAAN0IiYL1IAADXQjygviuh0g");
	var mask_9_graphics_35 = new cjs.Graphics().p("AAAQiQkPgijBhzQi9hjgEiEIAWAAIBxsUIAAvBIJnBYIAAN/IhyMnIAAESIKnhhQgEBbi9A6QhwAbiLAAQhkAAhygOg");
	var mask_9_graphics_36 = new cjs.Graphics().p("AAARzQkggXjNhsQjJhhgEiEIAWAAIBMtGIAAw9IKNA7IAAOLIhLNaIAAE0ILRhAQgEBojJBGQiXAvjFAAQhGAAhMgGg");
	var mask_9_graphics_37 = new cjs.Graphics().p("AAATCQkxgMjZhmQjVhfgEiEIAWAAIAmt3IAAy4IK0AdIAAOXIglOMIAAFYIL8ggQgEB2jVBSQi+BFkDAAIhKgBg");
	var mask_9_graphics_38 = new cjs.Graphics().p("AonSwQjhhegEiDIAXAAMAAAgjdILcAAMAAAAjdIMmAAQgFCDjgBeQjlBflDAAQlCAAjlhfg");
	var mask_9_graphics_39 = new cjs.Graphics().p("AonSwQjhhegEiDIAXAAMAAAgjdILcAAMAAAAjdIMmAAQgFCDjgBeQjlBflDAAQlCAAjlhfg");
	var mask_9_graphics_40 = new cjs.Graphics().p("AgGUPQk/gBjiheIgDgBQjehdgFiDIAAAAIAXAAMAAAgjMIABgRIKlAAIAHAAIAxAAIBCLmIAAW0ILbBDIAJAAIgDAOQgPB7jUBXIgMAFQjhBbk7AAIgGAAg");
	var mask_9_graphics_41 = new cjs.Graphics().p("AgGUQQk/gBjjhfIgDgBQjehdgEiDIAAAAIAWAAMAAAgjNIADgPIKlAAIAGgCIAxAAICGKjIAAW1IKZCGIAHAAIgEANQgOB7jTBYIgMAFQjhBbk8ABIgGAAg");
	var mask_9_graphics_42 = new cjs.Graphics().p("AgGUQQlAgBjiheIgDgBQjehdgFiDIAAgBIAXAAMAAAgjPIAEgNIKlAAIAGgCIAxAAIDKJfIAAW2IJXDJIAFAAIgFAMQgNB8jUBYIgMAFQjhBck8AAIgGAAg");
	var mask_9_graphics_43 = new cjs.Graphics().p("AgGUQQlAAAjjhfIgCgBQjfhdgEiDIAAAAIAWAAMAAAgjRIAGgMIKmAAIAFgCIAxAAIEOIbIAAW3IIUENIAEAAIgHAKQgMB8jUBZIgLAFQjiBck8AAIgGAAg");
	var mask_9_graphics_44 = new cjs.Graphics().p("AgGURQlAgBjjhfIgDgBQjehdgFiDIAAAAIAWAAMAAAgjSIAIgKIKmAAIAFgEIAxAAIFSHZIAAW4IHRFPIACAAIgHAJQgLB9jUBZIgMAFQjiBck8ABIgGAAg");
	var mask_9_graphics_45 = new cjs.Graphics().p("AgGURQlAgBjjheIgDgBQjfhdgFiDIAAgBIAXAAMAAAgjTIAJgJIKmAAIAEgEIAxAAIGWGVIAAW5IGQGSIAAAAIgIAIQgLB9jUBaIgMAFQjhBck9ABIgGAAg");
	var mask_9_graphics_46 = new cjs.Graphics().p("AgHURQlAAAjjhfIgDgBQjfhdgFiDIAAAAIAWAAMAAAgjVIALgIIKnAAIADgEIAyAAIHaFRIAAW6IFMHWIgBAAIgKAGQgJB+jUBaIgMAFQjiBdk8AAIgHAAg");
	var mask_9_graphics_47 = new cjs.Graphics().p("AgIUSQlAgBjkheIgCgBQjghdgEiDIAAgBIAWAAMAAAgjXIAMgFIKoAAIACgGIAyAAIIdEOIAAW7IELIZIgEAAIgKAFQgIB+jUBbIgNAFQjhBdk8ABIgIAAg");
	var mask_9_graphics_48 = new cjs.Graphics().p("AgIUSQlBAAjkhfIgDgBQjfhdgFiDIAAgBIAXAAMAAAgjYIANgEIKoAAIACgGIAxAAIJiDLIAAW8IDIJbIgFAAIgLAEQgIB/jUBbIgMAFQjiBdk7ABIgIAAg");
	var mask_9_graphics_49 = new cjs.Graphics().p("AgJUSQlBAAjkhfIgDgBQjfhdgFiDIAAAAIAWAAMAAAgjaIAPgDIKpAAIABgGIAxAAIKmCHIAAW9ICFKfIgGAAIgNACQgGCAjUBaIgMAFQjiBek8ABIgIAAg");
	var mask_9_graphics_50 = new cjs.Graphics().p("AgKUSQlBAAjkheIgDgBQjghdgFiDIAAgBIAXAAMAAAgjbIAQgCIKpAAIABgGIAxAAILqBDIAAW+IBDLiIgIAAIgOABQgFCAjVBbIgMAFQjiBfk8AAIgIAAg");
	var mask_9_graphics_51 = new cjs.Graphics().p("AozSzQjhhdgEiEIAWAAMAAAgjcIK8AAIAAgIINfAAMAAAAjkIgYAAQgFCEjgBdQjlBglCAAQlDAAjlhgg");
	var mask_9_graphics_52 = new cjs.Graphics().p("AozSzQjhhdgEiEIAWAAMAAAgjcIK8AAIAAgIINfAAMAAAAjkIgYAAQgFCEjgBdQjlBglCAAQlDAAjlhgg");
	var mask_9_graphics_53 = new cjs.Graphics().p("AgwUlQkrgFjXhZIgOgGQjUhcgEiAIAAAAIAVAAIABAAMAAAgiAIABgHIgBg1IABgqQCBgLCSgIQDPgIDUgBIABgHIBpgBQETAAEJAKQBwAGBpAGQAEA5AAA5IgBAwIACAVMAAAAg0IgWADQgBAdgKAcQgFAKgHAJQguBWicBCQgfANggAMQjSBJkXABIgFAAIglgBg");
	var mask_9_graphics_54 = new cjs.Graphics().p("AgsU4QksgEjYhaIgPgGQjVhcgEiAIAAAAIAVAAIABAAMAAAgiKIACgHQgCgaAAgbIABgrQB3gVCWgQQDMgQDZgDIABgGIBqAAQEYAAEFATQByALBjANQAIA4AAA5QAAAYgBAYIAEATMAAAAg/IgTAFQgBAdgJAcQgGAJgIAIQgpBYicBFQgfANghAMQjSBLkZABIgIAAIgiAAg");
	var mask_9_graphics_55 = new cjs.Graphics().p("AgoVLQktgEjZhZIgPgGQjWhcgFiBIAAAAIAWAAIAAgBMAAAgiUIADgFQgDgbAAgbQAAgWABgVQBsggCbgYQDKgXDcgFIADgFIBqgBQEdAAEAAdQB0AQBeAVQANA3AAA5QAAAYgDAYIAHAQMAAAAhJIgRAHQgBAegIAcIgPAPQgkBbidBHQgeANgiANQjSBMkcACIgLAAIgeAAg");
	var mask_9_graphics_56 = new cjs.Graphics().p("AgkVeQkvgEjahZIgPgGQjXhcgFiBIAAAAIAWAAIAAgBMAAAgieIAEgFQgFgbAAgbQAAgWADgVQBggrChggQDHgfDggGIADgEIBqgCQEjAAD8AnQB2AWBYAbQARA2AAA5QAAAZgDAYIAJAOMAAAAhSIgOAKQgBAegHAcIgQANQggBeidBJQgfAOghAMQjTBOkeADIgPAAIgaAAg");
	var mask_9_graphics_57 = new cjs.Graphics().p("AggVxQkwgDjbhZIgQgHQjYhcgFiBIAAgBIAWAAIAAAAMAAAgipIAFgEQgGgbAAgbQAAgWADgVQBWg2ClgoQDFgnDjgHIAEgEQA2gCA1AAQEnAAD5AwQB4AcBTAiQAUA2AAA5QAAAYgDAYIALAMMAAAAhcIgMANQgBAegFAdIgSAKQgbBhidBKQgfAPgiAMQjTBRkgADIgTAAIgWAAg");
	var mask_9_graphics_58 = new cjs.Graphics().p("AgbWDQkygCjdhZIgPgGQjahcgFiCIAAgBIAWAAIAAAAMAAAgizIAFgDQgGgbAAgcQAAgWAEgVQBKhBCrgwQDCguDmgJIAFgDQA2gCA2AAQEsAAD0A5QB7AhBNApQAZA1AAA5QAAAZgFAYIAOAJMAAAAhnIgKAPQAAAdgFAeIgTAIQgWBkieBMQgeAPgjANQjTBSkhADIgYAAIgRAAg");
	var mask_9_graphics_59 = new cjs.Graphics().p("AgXWWQk0gBjdhaIgQgGQjbhcgFiCIAAgBIAWAAIAAgBMAAAgi9IAGgCQgHgbAAgdQAAgVAEgVQBAhMCvg4QC/g2DrgLIAFgCQA3gCA1AAQEyAADwBDQB8AmBIAwQAdA0AAA6QAAAZgFAXIAQAHMAAAAhxIgHARQAAAegEAeIgUAGQgSBnieBOQgfAPgiANQjUBUkjAEIgcAAIgNAAg");
	var mask_9_graphics_60 = new cjs.Graphics().p("AgTWpQk1gBjehZIgQgHQjdhcgFiDIAAAAIAWAAIAAgBMAAAgjHIAHgCQgIgbAAgdQAAgVAEgVQA1hXC0hAQC9g+DugMIAHgBQA2gDA2AAQE3AADsBNQB+AsBDA2QAhA0AAA5QAAAZgHAYIATAFMAAAAh6IgFAUQAAAegCAeIgWAEQgNBqifBQQgeAPgjANQjUBWkkAFIgiAAIgIAAg");
	var mask_9_graphics_61 = new cjs.Graphics().p("AgPW8Qk2gBjghZIgQgGQjehdgFiDIAAgBIAWAAIAAAAMAAAgjSIAIgBQgKgbAAgdQAAgWAGgVQAphhC6hIQC6hGDygNIAHgBQA2gDA3AAQE8AADoBWQCAAyA9A9QAlAzAAA6QAAAZgHAYIAVACMAAAAiEIgCAXIgBA8IgYACQgIBsifBSQgeAQgkAOQjUBXkmAGIglAAIgFAAg");
	var mask_9_graphics_62 = new cjs.Graphics().p("AozVvQjhhdgEiEIAWAAMAAAgjcIAJAAQgLgcAAgdQAAiHDjhgQDjhgFAAAQFBAADjBgQDkBgAACHQAAAZgIAYIAXAAMAAAAjkIgYAAQgFCEjgBdQjlBglCAAQlDAAjlhgg");

	this.timeline.addTween(cjs.Tween.get(mask_9).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_9_graphics_19,x:436.7,y:369.5}).wait(1).to({graphics:mask_9_graphics_20,x:436.7,y:371.9}).wait(1).to({graphics:mask_9_graphics_21,x:436.6,y:374.4}).wait(1).to({graphics:mask_9_graphics_22,x:436.5,y:376.9}).wait(1).to({graphics:mask_9_graphics_23,x:436.5,y:379.4}).wait(1).to({graphics:mask_9_graphics_24,x:436.4,y:381.8}).wait(1).to({graphics:mask_9_graphics_25,x:436.4,y:384.3}).wait(1).to({graphics:mask_9_graphics_26,x:436.3,y:386.8}).wait(1).to({graphics:mask_9_graphics_27,x:436.3,y:389.3}).wait(1).to({graphics:mask_9_graphics_28,x:436.2,y:388.3}).wait(1).to({graphics:mask_9_graphics_29,x:440,y:386.4}).wait(1).to({graphics:mask_9_graphics_30,x:444,y:384.4}).wait(1).to({graphics:mask_9_graphics_31,x:448,y:382.5}).wait(1).to({graphics:mask_9_graphics_32,x:452,y:380.6}).wait(1).to({graphics:mask_9_graphics_33,x:456,y:378.6}).wait(1).to({graphics:mask_9_graphics_34,x:460,y:377}).wait(1).to({graphics:mask_9_graphics_35,x:464,y:378.7}).wait(1).to({graphics:mask_9_graphics_36,x:468,y:380.6}).wait(1).to({graphics:mask_9_graphics_37,x:472,y:382.7}).wait(1).to({graphics:mask_9_graphics_38,x:476,y:385}).wait(1).to({graphics:mask_9_graphics_39,x:476,y:385}).wait(1).to({graphics:mask_9_graphics_40,x:476.1,y:384.9}).wait(1).to({graphics:mask_9_graphics_41,x:476.1,y:384.9}).wait(1).to({graphics:mask_9_graphics_42,x:476.2,y:384.9}).wait(1).to({graphics:mask_9_graphics_43,x:476.3,y:384.8}).wait(1).to({graphics:mask_9_graphics_44,x:476.3,y:384.8}).wait(1).to({graphics:mask_9_graphics_45,x:476.4,y:384.8}).wait(1).to({graphics:mask_9_graphics_46,x:476.5,y:384.7}).wait(1).to({graphics:mask_9_graphics_47,x:476.7,y:384.7}).wait(1).to({graphics:mask_9_graphics_48,x:476.8,y:384.7}).wait(1).to({graphics:mask_9_graphics_49,x:476.9,y:384.6}).wait(1).to({graphics:mask_9_graphics_50,x:477.1,y:384.6}).wait(1).to({graphics:mask_9_graphics_51,x:477.2,y:384.6}).wait(1).to({graphics:mask_9_graphics_52,x:477.2,y:384.6}).wait(1).to({graphics:mask_9_graphics_53,x:477.2,y:382.7}).wait(1).to({graphics:mask_9_graphics_54,x:477.2,y:380.8}).wait(1).to({graphics:mask_9_graphics_55,x:477.2,y:378.9}).wait(1).to({graphics:mask_9_graphics_56,x:477.2,y:377}).wait(1).to({graphics:mask_9_graphics_57,x:477.2,y:375.2}).wait(1).to({graphics:mask_9_graphics_58,x:477.2,y:373.3}).wait(1).to({graphics:mask_9_graphics_59,x:477.2,y:371.4}).wait(1).to({graphics:mask_9_graphics_60,x:477.2,y:369.5}).wait(1).to({graphics:mask_9_graphics_61,x:477.2,y:367.7}).wait(1).to({graphics:mask_9_graphics_62,x:477.2,y:365.8}).wait(1).to({graphics:null,x:0,y:0}).wait(56));

	// FlashAICB
	this.instance_14 = new lib.mc_Cilindro();
	this.instance_14.setTransform(476.3,367,1,1,0,0,0,77.2,165.6);
	this.instance_14._off = true;

	this.instance_14.mask = mask_9;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(19).to({_off:false},0).wait(54).wait(1).to({x:486.1},0).wait(1).to({x:495.9},0).wait(1).to({x:505.7},0).wait(1).to({x:515.5},0).wait(1).to({x:525.3},0).wait(1).to({x:535.1},0).wait(1).to({x:544.9},0).wait(1).to({x:554.7},0).wait(1).to({x:564.5},0).wait(1).to({x:574.3},0).wait(1).to({x:584.1},0).wait(1).to({x:593.9},0).wait(1).to({x:603.7},0).wait(33));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(399.3,215.5,88.3,310);


   (lib.AlturaCono = function() {
	this.initialize(img.AlturaCono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,678,716);


(lib.BaseCilindro = function() {
	this.initialize(img.BaseCilindro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,171);


(lib.BaseCono = function() {
	this.initialize(img.BaseCono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,143);
(lib.BaseCono2 = function() {
	this.initialize(img.BaseCono2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,143);


(lib.Bloque = function() {
	this.initialize(img.Bloque);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,253);


(lib.Bloque_01_ok = function() {
	this.initialize(img.Bloque_01_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,259);


(lib.Bloque_02_ok = function() {
	this.initialize(img.Bloque_02_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,553,225);


(lib.Bloque_03_ok = function() {
	this.initialize(img.Bloque_03_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,437,201);


(lib.Bloque_04_ok = function() {
	this.initialize(img.Bloque_04_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,331,179);


(lib.Bloque_05_ok = function() {
	this.initialize(img.Bloque_05_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,217,158);


(lib.Bloque_06_ok = function() {
	this.initialize(img.Bloque_06_ok);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,107,128);


(lib.Cilindro = function() {
	this.initialize(img.Cilindro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,828);


(lib.CilindroComplet = function() {
	this.initialize(img.CilindroComplet);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,388,839);


(lib.circulo = function() {
	this.initialize(img.circulo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,563,155);


(lib.Circulo_abajo = function() {
	this.initialize(img.Circulo_abajo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,561,282);


(lib.Circulo_arriba = function() {
	this.initialize(img.Circulo_arriba);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,561,282);


(lib.Cono = function() {
	this.initialize(img.Cono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,789);


(lib.ConoComplet = function() {
	this.initialize(img.ConoComplet);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,830);


(lib.ConoComplet_1 = function() {
	this.initialize(img.ConoComplet_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,679,830);


(lib.CorteAlto = function() {
	this.initialize(img.CorteAlto);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,848,242);


(lib.CorteMedio = function() {
	this.initialize(img.CorteMedio);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,247);


(lib.cuadrado = function() {
	this.initialize(img.cuadrado);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,191,576);


(lib.CuerpoCilindro = function() {
	this.initialize(img.CuerpoCilindro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,387,836);


(lib.cupula = function() {
	this.initialize(img.cupula);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,264,89);


(lib.Desarrollo = function() {
	this.initialize(img.Desarrollo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,616,765);


(lib.desarrolloCono = function() {
	this.initialize(img.desarrolloCono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,940,691);


(lib.EjeGiro = function() {
	this.initialize(img.EjeGiro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,65,775);


(lib.elipse = function() {
	this.initialize(img.elipse);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,473,884);


(lib.Esfera = function() {
	this.initialize(img.Esfera);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,614,599);


(lib.Flechas = function() {
	this.initialize(img.Flechas);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,414,16);


(lib.hiperbola = function() {
	this.initialize(img.hiperbola);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,951,807);


(lib.Imatge_Intro = function() {
	this.initialize(img.Imatge_Intro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1235,399);


(lib.info_02 = function() {
	this.initialize(img.info_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,889,866);


(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,26,310);


(lib.parabola = function() {
	this.initialize(img.parabola);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,588,794);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s("rgba(255,255,255,0.502)").ss(1,1,1).rr(-95,-15,190,30,6);
	this.shape.setTransform(95,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-95,-15,190,30,6);
	this.shape_1.setTransform(95,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_Cupula = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cupula();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,132,44.5);


(lib.mc_CorteMedio = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.CorteMedio();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,450,123.5);


(lib.mc_CorteArriba = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.CorteAlto();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,424,121);


(lib.mc_circuloArriba = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Circulo_arriba();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,280.5,141);


(lib.mc_CirculoAbajo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Circulo_abajo();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,280.5,141);


(lib.mc_Circulo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.circulo();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,281.5,77.5);


(lib.mc_Llenado = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CC33").s().p("A1MUnQoyoiAAsFQAAsDIyojQIzoiMZAAQMaAAIyIiQIzIjAAMDQAAMFozIiQoyIjsaAAQsZAAozojg");
	this.shape.setTransform(192,186.6);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,383.9,373.2);


(lib.mc_Formula_3 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF6600").s().p("AhsBlIAThKIAmAAIgjBKgAjSBBQgMgDgHgGQgHgGgEgIQgEgIAAgIQAAgLAHgJQAGgGAQgGIAAgBQgNgGgGgJQgGgIAAgMQAAgSAQgKQAQgMAaAAQAbAAAPALQAQAJAAARQAAALgHAIQgGAHgOAGIAAABQAQAFAHAJQAHAJAAANQAAAUgQAMQgRAMgcAAQgQABgMgEgAjLAJQgEAGAAAGQAAAKAIAHQAHAFAMABIAHgCIAHgDQAEgCACgDQACgDAAgFQAAgHgEgEQgDgDgLgFIgJgEIgLgDQgEADgDAGgAi9g4QgEAAgDADQgDABgCADQgBADAAADQAAAGADADQADADAIADIAHADIAMAEQAEgGACgEQACgDAAgHQAAgHgGgEQgFgFgKAAIgHABgAnuBBQgMgDgHgGQgHgGgEgIQgEgIAAgIQAAgLAHgJQAGgGAQgGIAAgBQgNgGgGgJQgGgIAAgMQAAgSAQgKQAQgMAaAAQAbAAAPALQAQAJAAARQAAALgHAIQgGAHgOAGIAAABQAQAFAHAJQAHAJAAANQAAAUgQAMQgRAMgcAAQgQABgMgEgAnnAJQgEAGAAAGQAAAKAIAHQAHAFAMABIAHgCIAHgDQAEgCACgDQACgDAAgFQAAgHgEgEQgDgDgLgFIgJgEIgLgDQgEADgDAGgAnZg4QgEAAgDADQgDABgCADQgBADAAADQAAAGADADQADADAIADIAHADIAMAEQAEgGACgEQACgDAAgHQAAgHgGgEQgFgFgKAAIgHABgAFnBBQgMgEgIgHQgJgHgFgLQgFgLAAgOQAAgNAGgMQAFgLAJgHQAJgHALgDQAMgDAMgBQAMABAJACQAKACAIAEIAAAeIgFAAIgFgEIgHgEQgEgDgFgBQgFgBgGgBQgOABgIAIQgHAKAAANQAAAPAHAJQAIAIAPAAQAGAAAFgCIAJgDIAGgFIAFgEIAFAAIAAAeQgJAFgIABQgKADgLAAQgOAAgMgDgAAJBBQgJgEgHgHQgJgJgFgNQgFgNAAgTQAAgRAFgPQAEgPAKgLQAIgLAPgGQAPgGAVAAIAQABIALACIAAAcIgEAAIgJgDQgGgCgIAAQgTABgKAIQgLAKgCAQQAIgFAIgCQAIgDAKAAQAJAAAHACQAHACAGAEQAJAGAEAKQAFAHAAAOQAAALgEALQgEAKgHAGQgIAIgLADQgKAEgOAAQgNAAgLgDgAATgEIgJADIAAABIAAAGQAAAMACAIQADAIAEAEQACADAEABQAEACAEAAIAHgCQAEgBADgDIAFgJQABgEAAgIQAAgHgCgFQgCgEgDgBQgEgDgFgBIgJAAIgJAAgAlgA/QgMgEgHgLQgHgJgDgOQgDgPAAgPQAAgUADgOQADgOAIgJQAHgKALgFQAMgEAQgBQARABALAEQALAFAHAKQAIAKADAOQADAOAAASQAAARgDAOQgEAOgHAKQgHAJgLAFQgMAFgQAAQgQAAgMgFgAlVgrQgGALAAAbQAAAXAGALQAFAMAMAAQAMAAAFgMQAFgLAAgYQAAgagFgLQgFgMgMAAQgMAAgFAMgAC0BBIAAgiIhHAAIAAgbIBFhSIAmAAIAABTIAUAAIAAAaIgUAAIAAAigACJAFIArAAIAAgzgAJOBBIAAg3IgBgMQAAgFgCgEQgBgDgEgBQgEgCgGAAQgFAAgEACIgKAEIAABMIgjAAIAAg3IgBgMIgCgJQgCgDgDgBQgEgCgGAAQgFAAgFACIgJAEIAABMIgjAAIAAhrIAjAAIAAALQAJgGAIgEQAJgEAKgBQAKAAAJAFQAIAFAFAKQAKgKAKgFQAKgEAKgBQARAAAKALQAJALAAAUIAABFgApQBBIAAgmIAlAAIAAAmgArWBBIAAgaIAfAAIAAhKIgfAAIAAgYIAOgBQAGgBAEgBQAGgDACgEQADgEAAgGIAgAAIAAB2IAeAAIAAAagAKMgEIAAgPIASgNIANgMQAIgHADgGQADgGAAgFQAAgGgEgEQgEgEgIAAQgGAAgGADIgMAGIgCAAIAAgVIANgEQAJgCAJAAQASAAAJAHQAJAIAAAOQAAAIgEAIQgFAJgJAIIgLAKIgJAGIArAAIAAASg");
	this.shape.setTransform(383.7,22.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AGcBlIARhAIAYAAIgcBAgAuuA9QgHgHAAgQIADgqIAEgqIgfAAQgEA0gDAYQgFAYgFAIQgFAHgKAAQgGAAgFgEQgEgEAAgGQAAgHAHgKQAMgPAGgSQAFgOADglIgKAAQgLAAgHAFQgGAGgGAKIgFAAQAEgQAHgKQAGgKAIgDQAHgDASAAIBdAAIAAAVIgiAAIgDAsIgBATQAAAUAGAEQAEAFAHAAQAOAAADgRIAFAAQgFAogbAAQgNAAgJgIgAExBBQgLgDgIgDIAAgUIACAAQAIAFALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgEACgGQACgEAAgJQAAgIgDgEQgCgGgEgCQgEgCgHgBQgGgBgHAAIgJAAIAAgQIAGAAQAQAAAIgGQAKgHgBgLQABgGgDgDQgCgEgEgDIgJgEIgLgBQgJAAgLAEQgKADgJAGIgCAAIAAgVIATgFQALgDALgBQALABAIACQAIACAHAEQAHAFAEAGQADAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGACAEAEQAFADADAFQADAHAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgMAAgNgDgAQ4BBIAAgUIAWgSIATgRQASgRAHgKQAHgLAAgNQAAgLgIgGQgHgHgNAAQgJAAgKAEQgLADgJAGIgBAAIAAgVQAGgDAMgCQALgDALgBQAXAAAMAMQANAKAAATQAAAIgCAHQgCAIgEAFQgEAHgFAFIgNAMIgVATIgVASIBOAAIAAARgAPFBBIAAgPIAfAAIAAhgIgfAAIAAgNIAOAAQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACBIAeAAIAAAPgAKiBBIAAgpIhGAAIAAgWIBHhQIASAAIAABXIAWAAIAAAPIgWAAIAAApgAJqAJIA4AAIAAhAgAHxBBIAAgPIAfAAIAAhgIgfAAIAAgNIAOAAQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACBIAeAAIAAAPgAAGBBIAAgpIhEAAIAAgWIBFhQIASAAIAABXIAVAAIAAAPIgVAAIAAApgAgwAJIA2AAIAAhAgAmnBBIAAgpIhGAAIAAgWIBHhQIARAAIAABXIAWAAIAAAPIgWAAIAAApgAnfAJIA4AAIAAhAgAttBBIAZhrIASAAIgDAQQAMgJAKgEQAJgDAIAAIAHAAIAHABIgFASIgBAAIgHgBIgJAAQgIAAgKADQgIAFgJAFIgRBMgA1bBBIgGgpIg+AAIgYApIgVAAIBXiPIAaAAIATCPgA2WAJIA0AAIgJhGgAVZAdIAAgPIBzAAIAAAPgAkXAdIAAgPIB0AAIAAAPgAzYAdIAAgPIB0AAIAAAPgAMzAPIAAgaIAYAAIAAAagACXAPIAAgaIAYAAIAAAagApsAPIAAgaIAYAAIAAAagASygEIAAgNIANgLIANgMQAMgLAEgIQAGgHgBgIQABgGgGgFQgEgEgJAAQgGAAgGACQgIACgGAEIgBAAIAAgNQAFgDAHgBQAIgCAHAAQAPAAAIAHQAIAHAAAMIgBAKIgEAJIgGAHIgIAJIgOANIgOAMIAzAAIAAAKgAsTgEIAAgNIAOgLIAMgMQAMgLAEgIQAGgHAAgIQAAgGgGgFQgEgEgJAAQgGAAgHACQgGACgHAEIAAAAIAAgNQAEgDAHgBQAIgCAHAAQAOAAAJAHQAIAHAAAMIgBAKIgEAJIgGAHIgIAJIgOANIgNAMIAyAAIAAAKgAVZgKIAAgPIBzAAIAAAPgAkXgKIAAgPIB0AAIAAAPgAzYgKIAAgPIB0AAIAAAPg");
	this.shape_1.setTransform(150.4,22.2);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.9,12.1,454.5,20.3);


(lib.mc_Formula_2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ah9AAID7AA");
	this.shape.setTransform(67.4,27.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AzvDNQgLgCgIgEIAAgUIACAAQAIAFALAEQALADALAAQAGAAAHgCQAHgBAEgEQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgIgBIgIAAIAAgQIAGAAQAPAAAJgFQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKACgKAHIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAHQAEAGAAAJQAAAMgJAKQgIAIgMADIAAABIALAEQAGACAEADQAFAFADAGQADAGAAAKQAAALgEAHQgDAJgHAGQgHAHgKADQgKADgMAAQgMAAgMgDgAQSBcIARhAIAYAAIgbBAgArPBcIARhAIAYAAIgbBAgAT6A4QgJgDgHgHQgIgIgFgNQgEgNAAgSQAAgSAEgPQAEgQAJgLQAJgLANgGQAOgHASABIAJAAIAIABIAAATIgBAAIgIgDQgFgBgGAAQgVAAgNANQgMANgCAXQAIgFAIgDQAIgDAKAAQAKAAAHACQAHACAHAFQAJAGAEAKQAFAIAAALQAAAXgPANQgPAOgVABQgLgBgIgDgAT7gRQgHACgHAFIgBAEIAAAFQAAANAEAJQADAJAFAFQAFAEAFADQAFABAGAAQAPAAAIgIQAIgJAAgQQAAgJgDgEQgDgGgGgFQgEgDgGgBIgLAAQgIAAgIABgARxA5QgLgCgHgEIAAgUIABAAQAIAFALADQAKADALABQAHAAAGgCQAHgCAFgFQAEgEACgGQACgGAAgIQAAgIgCgCQgDgFgEgEQgFgEgIgBQgHgBgJgBIgQABIgOADIAAhLIBXAAIAAARIhEAAIAAAnIAIgBIAIAAQAMAAAJACQAIACAIAFQAIAGAEAIQAEAIAAALQAAALgDAIQgEAKgHAGQgHAHgJAEQgKADgNABQgMgBgLgCgAMpA4QgMgCgHgDIAAgVIABAAQAIAFAMAEQALADAKABQAGAAAHgCQAHgCAFgEQAEgFACgFQACgFAAgIQAAgIgCgEQgDgEgEgDQgEgDgHgBQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgHQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKADQAGADAFAEQAEAEADAGQADAFAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAs5A4QgMgCgHgDIAAgVIABAAQAIAFAMAEQALADAKABQAGAAAHgCQAHgCAFgEQAEgFACgFQACgFAAgIQAAgIgCgEQgDgEgEgDQgEgDgHgBQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgHQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKADQAGADAFAEQAEAEADAGQADAFAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAW7A3QgKgDgHgHQgHgHgEgLQgEgLAAgOQAAgZAPgPQAOgPAZAAQAJAAAJACQAJADAHAEIAAAUIAAAAQgJgGgJgEQgJgDgIAAQgQAAgJAKQgJALAAASQAAAUAJALQAJAKAQAAIALgBIAKgEIAIgEIAGgFIAAAAIAAAVIgRAGQgIADgJAAQgMAAgKgEgAaYA4IAAg7IgBgOQgBgHgCgDQgCgFgEgCQgEgCgIAAQgIAAgIAEQgHADgIAGIAAAGIABAGIAABDIgTAAIAAg7IAAgPQgBgGgCgDQgCgFgFgCQgEgCgIAAQgHAAgIADIgPAKIAABPIgSAAIAAhrIASAAIAAANQAJgHAIgFQAJgEAKAAQALABAHAEQAIAFAEAIQALgJAJgFQAJgEALAAQASAAAJALQAIALAAAUIAABEgAPRA4IAAgoIhFAAIAAgVIBGhSIASAAIAABXIAWAAIAAAQIgWAAIAAAogAOZAAIA4AAIAAg/gAKWA4IAAgUIAVgSIATgRQASgQAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAJgCAGQgCAIgEAGQgEAHgFAFIgMALIgWAUIgVASIBOAAIAAAQgAJWA4IAAgcIAXAAIAAAcgAHaA4IBGh+IhTAAIAAgRIBkAAIAAAWIhCB5gAgyA4IAAgUIAVgSIATgRQAQgQAHgLQAHgKAAgNQAAgLgHgGQgIgHgLAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAUAAANALQAMAKAAATQAAAJgCAGQgCAIgEAGQgEAHgFAFIgMALIgUAUIgVASIBMAAIAAAQgAimA4IAAgOIAfAAIAAhgIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACCIAeAAIAAAOgAnJA4IAAgoIhFAAIAAgVIBGhSIASAAIAABXIAWAAIAAAQIgWAAIAAAogAoBAAIA4AAIAAg/gAp6A4IAAgOIAfAAIAAhgIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACCIAeAAIAAAOgA7wA4IgTiPIAUAAIAQB+IBLh+IAUAAIhWCPgADsAVIAAgPIB0AAIAAAPgA4yAVIAAgPIBzAAIAAAPgAk4AHIAAgaIAYAAIAAAagAvUAHIAAgaIAYAAIAAAagAbSgMIgMgEIAAgNIABAAQAFADAHACQAIADAHAAIAIgCQAFgBACgDQADgCACgEQABgDAAgFQAAgFgBgEIgFgEIgHgDIgJgBIgFAAIAAgLIAEAAQAKAAAGgDQAFgEAAgIQAAgEgBgCIgEgFIgGgCIgHgBQgGAAgHACIgNAHIAAAAIAAgNIAMgFQAHgBAHAAQAHgBAFACQAGABAEADQAEADADAEQACAEAAAGQAAAIgFAGQgGAGgIACIAAABIAHABIAHAFQADACACAEQACAFAAAGQAAAGgCAGQgDAGgEAEQgFADgGADQgGACgIAAQgIAAgIgCgABSgMIgMgEIAAgNIABAAQAFADAHACQAIADAHAAIAIgCQAFgBACgDQADgCACgEQABgDAAgFQAAgFgBgEIgFgEIgHgDIgJgBIgFAAIAAgLIAEAAQAKAAAGgDQAFgEAAgIQAAgEgBgCIgEgFIgGgCIgHgBQgGAAgHACIgNAHIAAAAIAAgNIAMgFQAHgBAHAAQAHgBAFACQAGABAEADQAEADADAEQACAEAAAGQAAAIgFAGQgGAGgIACIAAABIAHABIAHAFQADACACAEQACAFAAAGQAAAGgCAGQgDAGgEAEQgFADgGADQgGACgIAAQgIAAgIgCgADsgSIAAgQIB0AAIAAAQgA4ygSIAAgQIBzAAIAAAQgAzEg+IAAgpIhGAAIAAgXIBHhRIASAAIAABZIAVAAIAAAPIgVAAIAAApgAz8h2IA4AAIAAhCg");
	this.shape_1.setTransform(190.9,28.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(11.3,7.6,359.4,41.8);


(lib.mc_Formula = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAZAAISFAAAydAAIOTAA");
	this.shape.setTransform(163,27);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABqDuQgLgDgIgDIAAgVIACAAQAIAGALADQALAEAKAAQAHAAAHgCQAGgCAFgEQAFgFACgFQABgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgGgBQgHgBgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgHAAgMQAAgFgDgEQgCgEgDgCIgJgEIgLgBQgKAAgLAEQgJADgKAGIgBAAIAAgVIASgGQAMgDALAAQAKAAAJACQAIACAGAFQAIAEADAHQADAGABAJQAAAMgJAKQgIAJgMACIAAABIALAEQAFACAFAEQAFAEADAGQACAHAAAKQABAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDgAy1DuQgMgDgHgDIAAgVIABAAQAIAGALADQAMAEAKAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAIgHABgMQgBgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKADgKAGIgBAAIAAgVIATgGQAMgDALAAQAKAAAIACQAIACAHAFQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLACIAAABIAKAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgDAIQgEAIgGAGQgIAHgKAEQgKADgMAAQgLAAgMgDgAUmBnIARhAIAZAAIgcBAgAWCBGIgIgCIAAgTIABAAIAIADIALABQAXAAAMgNQAMgNACgWQgKAFgIACQgHADgKAAQgJAAgHgCQgHgCgIgFQgJgGgDgHQgFgJAAgNQAAgWAPgOQAOgOAWAAQAKAAAJADQAJADAHAHQAIAIAEANQAFANAAAUQAAARgFAPQgEAQgIALQgJALgOAGQgNAGgSAAIgKAAgAWIg2QgIAIAAAQQAAAKADAFQACAGAHAFQAEADAFABIAMAAQAIAAAHgBQAIgCAHgEIAAgEIAAgFQAAgQgDgJQgDgJgGgFQgEgEgGgCQgEgCgHAAQgOAAgIAJgAS+BEQgLgDgHgDIAAgVIABAAQAHAFALAEQALADAKAAQAIAAAGgCQAHgCAEgEQAFgFACgFQACgGAAgIQAAgIgCgFQgDgFgFgDQgEgCgIgBQgHgCgJAAIgRABIgOADIAAhLIBYAAIAAARIhEAAIAAAnIAIgBIAHAAQAMAAAKACQAIACAHAFQAIAFAFAHQAEAIAAANQAAAKgDAJQgEAKgHAGQgHAHgJAEQgLADgMAAQgMAAgLgCgARJBDQgKgDgGgHQgJgIgEgNQgEgOgBgTQAAgRAFgPQADgPAKgLQAIgLAOgHQAOgGARAAIAKABIAIABIAAATIgBAAIgIgDQgGgBgFAAQgWAAgMANQgMANgDAXQAJgFAIgDQAHgDALAAQAJAAAHACQAHACAIAFQAIAGAFAJQAFAHAAANQgBAWgOAOQgPAOgVAAQgLAAgIgDgARKgGQgHACgIAEIAAADIAAAFQAAAPAEAJQADAJAFAFQAEAEAGACQAFACAGAAQAPAAAHgIQAIgJAAgQQAAgJgCgGQgDgGgGgDQgFgDgFgBIgLgBQgJAAgHACgAbQBCQgLgDgGgHQgIgHgDgLQgEgLAAgOQAAgZAPgPQAOgPAYAAQAJAAAJACQAKADAHAEIAAAUIAAAAQgJgGgJgEQgJgDgJAAQgPAAgJAKQgJALAAASQAAAUAIAKQAKALAPAAIAMgCIAKgDIAHgFIAHgEIAAAAIAAAUIgRAHQgIADgKAAQgMAAgJgEgEggFABEIgTiQIAUAAIAQB+IBLh+IAUAAIhWCQgAesBDIAAg+IAAgLQgBgHgCgEQgCgEgFgCQgEgCgHAAQgIAAgIAEQgIADgIAGIABAGIAAAFIAABEIgSAAIAAg+IgBgMQgBgGgCgEQgCgEgEgCQgEgCgIAAQgIAAgHADIgPAKIAABPIgSAAIAAhrIASAAIAAAMQAIgHAJgEQAJgEAKAAQAKAAAIAFQAIAFAEAIQALgKAJgEQAJgEAKAAQATAAAIALQAJALgBATIAABFgAYtBDIAAgpIhFAAIAAgWIBGhQIASAAIAABXIAVAAIAAAPIgVAAIAAApgAX1ALIA4AAIAAhAgANOAkIAAgQIB0AAIAAAQgAp5AkIAAgQIB0AAIAAAQgA9HAgIAAgPIB0AAIAAAPgAfngBIgNgEIAAgOIABAAQAGAEAHACQAIADAGAAIAJgCQAEgBADgDQADgCACgEQABgDAAgFQAAgFgBgEIgFgFIgHgDIgJAAIgFAAIAAgLIAEAAQAJAAAHgEQAFgEAAgIQAAgDgCgDIgDgEIgHgCIgGgBQgHAAgGACIgNAGIAAAAIAAgNIALgEQAIgCAHAAQAHAAAFACQAGABADADQAFADADAEQACAEAAAGQAAAIgGAGQgFAGgIABIAAABIAHACIAHAEQADADACAEQACAEAAAHQAAAGgDAGQgCAFgEAEQgFAEgGADQgGABgJAAQgHAAgIgBgANOgDIAAgQIB0AAIAAAQgAp5gDIAAgQIB0AAIAAAQgA9HgHIAAgPIB0AAIAAAPgAjrglIAQhAIAZAAIgcBAgA2ehNQgHgHgBgQIADgrIAFgrIggAAQgDA2gEAYQgEAZgFAHQgGAHgJAAQgGAAgFgEQgEgEgBgGQAAgGAIgLQAMgPAFgRQAGgRADglIgKAAQgMAAgGAGQgGAFgHAKIgEAAQAEgQAGgKQAHgKAIgDQAGgDASAAIBeAAIAAAVIgiAAIgDAtIgBAUQAAAUAFAFQAFAEAGAAQAOAAADgRIAGAAQgFAogcAAQgNAAgIgIgAFChGIgIgCIAAgTIABAAIAIADIALABQAXAAAMgNQAMgNACgWQgKAFgHACQgIADgKAAQgJAAgHgCQgHgCgIgFQgIgGgEgJQgFgJAAgNQAAgWAPgOQAOgOAWAAQAKAAAJADQAJADAHAHQAIAIAEANQAFANAAAUQAAATgFAPQgEAQgIALQgKALgNAGQgNAGgSAAIgKAAgAFIjEQgIAIAAAQQAAAKADAFQACAGAHAFQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgQgDgJQgDgJgGgFQgEgEgGgCQgEgCgHAAQgOAAgIAJgAlVhJQgMgCgHgEIAAgUIABAAQAIAFALAEQAMADAKAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAIgGABgMQgBgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKADgKAGIgBAAIAAgUIATgGQAMgDALAAQAKAAAIACQAIACAHAEQAHAFAEAGQADAHAAAJQAAAMgJAJQgIAJgLACIAAACIAKADQAGADAEADQAFAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAGQgIAHgKADQgKADgMAAQgLAAgMgDgAKShJIBGiAIhTAAIAAgRIBkAAIAAAWIhDB7gAAZhJIAAgpIhDAAIAAgWIBEhSIASAAIAABZIAVAAIAAAPIgVAAIAAApgAgdiBIA2AAIAAhCgAiWhJIAAgPIAeAAIAAhhIgeAAIAAgNIAOgBQAGgBAEgCQAFgDACgDQACgEABgHIAPAAIAACDIAeAAIAAAPgAuWhJIANg+IACgJIABgIQAAgIgEgEQgEgEgLAAQgHAAgJAEQgJAEgIAGIgTBRIgSAAIAiiYIATAAIgNA3QALgHAIgEQAKgEAJAAQAPAAAIAHQAHAHABAOIAAAGIgCAHIgQBHgA1ehJIAahtIASAAIgEAQQANgJAKgDQAIgEAJAAIAHAAIAGABIgEATIgBAAIgIgCIgIAAQgJAAgJAEQgJAEgJAGIgRBNgAH/h7IAAgbIAXAAIAAAbgACqh7IAAgbIAXAAIAAAbgAxch7IAAgbIAXAAIAAAbgA0EiPIAAgOIAOgLIAMgLQANgMAEgHQAFgHAAgIQAAgHgFgFQgFgEgJAAQgFAAgHACQgHACgHAEIAAAAIAAgNQAFgCAHgCQAIgCAGAAQAPAAAJAHQAHAHABAMIgBAKIgFAJIgFAIIgIAIIgPANIgNAMIAyAAIAAALg");
	this.shape_1.setTransform(208.7,26.2);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.4,2.1,414.7,48.3);


(lib.mc_Esfera = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Esfera();
	this.instance.setTransform(0,0,0.624,0.624);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,383.3,373.9);

(lib.mc_Formula_1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ah9AAID7AA");
	this.shape.setTransform(58.1,27.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhMDNQgLgCgIgEIAAgUIACAAQAIAFAMAEQAKADALAAQAGAAAHgCQAHgBAFgEQAEgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAIgFQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKACgJAHIgBAAIAAgVIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAHQAEAGAAAJQAAAMgIAKQgJAIgMADIAAABIALAEQAGACAFADQAEAFADAGQACAGAAAKQAAALgDAHQgDAJgHAGQgHAHgKADQgKADgMAAQgMAAgMgDgApkA8IgTiPIAUAAIAQB+IBLh+IAUAAIhWCPgAGfAyQgIgHAAgQIAEgqIAEgqIgfAAQgEA1gEAXQgEAZgFAHQgGAHgJAAQgGAAgFgEQgFgEAAgHQAAgGAIgKQAMgPAFgPQAGgRADglIgKAAQgMAAgGAFQgGAGgGAKIgFAAQAEgQAGgKQAHgKAIgDQAGgDATAAIBdAAIAAAVIgiAAIgDAtIgBASQAAAUAFAFQAEAEAIAAQAOAAACgSIAFAAQgEApgcAAQgNAAgIgIgAHfA2IAahrIASAAIgEAQQANgJAJgEQAJgDAIAAIAIAAIAGABIgFASIAAAAIgIgBIgIAAQgJAAgJADQgJAFgJAGIgRBLgAmmAZIAAgQIBzAAIAAAQgADMAEIAAgZIAXAAIAAAZgAJHgPIgNgDIAAgOIABAAQAFAEAIACQAHACAHAAIAIgBQAFgBACgDQADgCACgEQABgEABgFQgBgEgBgEIgFgFIgHgDIgJgBIgFAAIAAgKIAEAAQAKAAAGgEQAGgEAAgIQAAgDgCgDIgEgEIgGgCIgHgBQgGAAgHACIgMAGIgBAAIAAgNIAMgEQAHgCAIAAQAHAAAFACQAFABAEACQAFADACAEQACAFABAGQgBAHgFAHQgGAFgHACIAAABIAHACIAGAEQAEACACAFQABAEAAAGQABAHgDAGQgCAFgFAEQgEAEgHACQgGACgIABQgIgBgHgCgAmmgPIAAgPIBzAAIAAAPgAghg+IAAgpIhGAAIAAgXIBHhRIASAAIAABZIAUAAIAAAPIgUAAIAAApgAhZh2IA4AAIAAhCg");
	this.shape_1.setTransform(62.9,28.5);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.3,7.6,126.6,41.8);


(lib.mc_DesarrolloCono = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.desarrolloCono();
	this.instance.setTransform(0,0,0.55,0.55);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,517,380.1);


(lib.mc_ConoComplet = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("r", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 13;
	this.text.setTransform(168.5,276.9);

	this.text_1 = new cjs.Text("h", "italic 18px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(138.6,158.1);

	this.text_2 = new cjs.Text("g", "italic 18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 13;
	this.text_2.setTransform(57.1,123.8);

	this.text_3 = new cjs.Text("v", "italic 18px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 13;
	this.text_3.setTransform(128.1,-8.4);

	this.instance = new lib.ConoComplet_1();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-8.4,271.6,340.5);


(lib.mc_Cono = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Cono();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,271.6,315.6);


(lib.mc_BaseCono = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("r = 3 cm", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 109;
	this.text.setTransform(155,67.4+incremento);

	this.instance = new lib.BaseCono2();
	this.instance.setTransform(6.7,41.7,0.4,0.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(6.7,41.7,271.6,57.2);


(lib.mc_AlturaCono = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("h = 7 cm", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 100;
	this.text.setTransform(137.8,187.8);

	this.instance = new lib.AlturaCono();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,271.2,286.4);


(lib.mc_Triangulo = function() {
	this.initialize();

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("EAVLAvyMAAAhe9MgqNBfDg");
	this.shape.setTransform(164.6,142,0.372,0.372);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FBBBA3").s().p("EAVHgvhMAAABe9MgqNAAGg");
	this.shape_1.setTransform(164.8,142.8,0.372,0.372);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(114.5,29.6,100.6,226.4);


(lib.mc_Flechas = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Flechas();
	this.instance.setTransform(0,0,0.446,0.446);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,184.8,7.2);


(lib.mc_EjeGiro = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Mapadebits1();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,26,310);


(lib.mc_desarrollo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Desarrollo();
	this.instance.setTransform(0,0,0.436,0.436);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,268.4,333.3);


(lib.mc_CuerpoCilindro = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.CilindroComplet();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,155.2,335.6);


(lib.mc_Cuadrado = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cuadrado();
	this.instance.setTransform(139.6,26.8,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(139.6,26.8,76.4,230.4);


(lib.mc_cilindroComplet = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.CilindroComplet();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,155.2,335.6);


(lib.mc_Cilindro = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Cilindro();
	this.instance.setTransform(0,0,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,154.4,331.2);


(lib.mc_BaseCilindro = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("r = 4 cm", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 84;
	this.text.setTransform(-88.7,18.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Al7AAIL3AA");
	this.shape.setTransform(39,34);

	this.addChild(this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-88.7,18.7,87.6,34);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.mc_Cono_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// FlashAICB
	this.text = new cjs.Text("r", "italic 36px Verdana");
	this.text.lineHeight = 41;
	this.text.lineWidth = 22;
	this.text.setTransform(9.5,147.2,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF3434").ss(2,1,1).p("AnjAAIPHAA");
	this.shape.setTransform(5.8,171.5);

	this.text_1 = new cjs.Text("h", "italic 36px Verdana");
	this.text_1.lineHeight = 41;
	this.text_1.lineWidth = 23;
	this.text_1.setTransform(61.7,78.4,0.5,0.5);

	this.text_2 = new cjs.Text("g", "italic 36px Verdana");
	this.text_2.lineHeight = 41;
	this.text_2.lineWidth = 22;
	this.text_2.setTransform(-13.6,47,0.5,0.5);

	this.text_3 = new cjs.Text("Eje de giro", "36px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 41;
	this.text_3.lineWidth = 344;
	this.text_3.setTransform(31.1,-103.5,0.5,0.5);

	this.text_4 = new cjs.Text("Generatriz", "36px Verdana");
	this.text_4.lineHeight = 41;
	this.text_4.lineWidth = 208;
	this.text_4.setTransform(-234.1,89.4,0.5,0.5,-65.9);

	this.text_5 = new cjs.Text("Altura", "36px Verdana");
	this.text_5.lineHeight = 41;
	this.text_5.lineWidth = 143;
	this.text_5.setTransform(-140.1,91.5,0.5,0.5,-89.9);

	this.text_6 = new cjs.Text("Base", "36px Verdana");
	this.text_6.lineHeight = 41;
	this.text_6.lineWidth = 115;
	this.text_6.setTransform(72.9,159.2,0.5,0.5);

	this.text_7 = new cjs.Text("Radio", "36px Verdana");
	this.text_7.lineHeight = 41;
	this.text_7.lineWidth = 115;
	this.text_7.setTransform(-230.7,183,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF3434").ss(2,1,1).p("AAA3eMAAAAu9");
	this.shape_1.setTransform(55.2,65.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape},{t:this.text}]},118).wait(1));

	// FlashAICB
	this.instance_1 = new lib.mc_Flechas();
	this.instance_1.setTransform(-44.9,-71.3,1.058,1,0,0,0,92.4,3.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(97).to({_off:false},0).wait(1).to({alpha:0.083},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.417},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.583},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.917},0).wait(1).to({alpha:1},0).wait(10));

	// Eje
	this.instance_2 = new lib.mc_EjeGiro();
	this.instance_2.setTransform(-0.3,66.5,1,1,0,0,0,13,155);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(9).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(54).wait(1).to({x:-11.2},0).wait(1).to({x:-22.1},0).wait(1).to({x:-33.1},0).wait(1).to({x:-44.1},0).wait(1).to({x:-55},0).wait(1).to({x:-66},0).wait(1).to({x:-77},0).wait(1).to({x:-88},0).wait(1).to({x:-98.9},0).wait(1).to({x:-109.9},0).wait(1).to({x:-120.9},0).wait(1).to({x:-131.8},0).wait(1).to({x:-142.8},0).wait(33));

	// Cuadrado
	this.instance_3 = new lib.mc_Triangulo();
	this.instance_3.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({regX:164.6,regY:142,x:-50.4,y:65.5,alpha:0.111},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:1},0).wait(10).wait(1).to({scaleX:0.93,x:-47},0).wait(1).to({scaleX:0.86,x:-43.6},0).wait(1).to({scaleX:0.79,x:-40.2},0).wait(1).to({scaleX:0.72,x:-36.8},0).wait(1).to({scaleX:0.66,x:-33.4},0).wait(1).to({scaleX:0.59,x:-30.1},0).wait(1).to({scaleX:0.52,x:-26.7},0).wait(1).to({scaleX:0.45,x:-23.3},0).wait(1).to({scaleX:0.38,x:-19.9},0).wait(1).to({scaleX:0.31,x:-16.5},0).wait(1).to({scaleX:0.24,x:-13.1},0).wait(1).to({scaleX:0.17,x:-9.7},0).wait(1).to({scaleX:0.1,x:-6.3},0).wait(1).to({scaleX:0.03,x:-3},0).wait(1).to({skewY:180,x:0.2},0).wait(1).to({scaleX:0.1,x:3.6},0).wait(1).to({scaleX:0.17,x:7},0).wait(1).to({scaleX:0.24,x:10.3},0).wait(1).to({scaleX:0.31,x:13.7},0).wait(1).to({scaleX:0.38,x:17.1},0).wait(1).to({scaleX:0.45,x:20.5},0).wait(1).to({scaleX:0.52,x:23.9},0).wait(1).to({scaleX:0.59,x:27.3},0).wait(1).to({scaleX:0.66,x:30.7},0).wait(1).to({scaleX:0.72,x:34.1},0).wait(1).to({scaleX:0.79,x:37.5},0).wait(1).to({scaleX:0.86,x:40.9},0).wait(1).to({scaleX:0.93,x:44.3},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.88,x:41.5},0).wait(1).to({scaleX:0.75,x:35.4},0).wait(1).to({scaleX:0.63,x:29.2},0).wait(1).to({scaleX:0.5,x:23.1},0).wait(1).to({scaleX:0.38,x:17},0).wait(1).to({scaleX:0.25,x:10.8},0).wait(1).to({scaleX:0.13,x:4.7},0).wait(1).to({scaleX:0,skewY:0,x:-1.8},0).wait(1).to({scaleX:0.13,x:-7.4},0).wait(1).to({scaleX:0.25,x:-13.5},0).wait(1).to({scaleX:0.38,x:-19.7},0).wait(1).to({scaleX:0.5,x:-25.8},0).wait(1).to({scaleX:0.63,x:-31.9},0).wait(1).to({scaleX:0.75,x:-38.1},0).wait(1).to({scaleX:0.88,x:-44.2},0).wait(1).to({scaleX:1,x:-50.4},0).wait(9).wait(1).to({x:-61.4},0).wait(1).to({x:-72.3},0).wait(1).to({x:-83.3},0).wait(1).to({x:-94.3},0).wait(1).to({x:-105.2},0).wait(1).to({x:-116.2},0).wait(1).to({x:-127.2},0).wait(1).to({x:-138.2},0).wait(1).to({x:-149.1},0).wait(1).to({x:-160.1},0).wait(1).to({x:-171.1},0).wait(1).to({x:-182},0).wait(1).to({x:-193},0).wait(33));

	// Mask
	this.instance_4 = new lib.mc_Triangulo();
	this.instance_4.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(22).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.4},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:4},0).wait(1).to({scaleX:0,x:-1.8},0).wait(1).to({scaleX:0.11,skewY:0,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.2},0).wait(1).to({scaleX:0.33,x:-17.7},0).wait(1).to({scaleX:0.44,x:-23.1},0).wait(1).to({scaleX:0.56,x:-28.6},0).wait(1).to({scaleX:0.67,x:-34},0).wait(1).to({scaleX:0.78,x:-39.5},0).wait(1).to({scaleX:0.89,x:-45},0).wait(1).to({scaleX:1,x:-50.4},0).wait(3).to({_off:true},1).wait(56));

	// Mask
	this.instance_5 = new lib.mc_Triangulo();
	this.instance_5.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(24).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.4},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:4},0).wait(1).to({scaleX:0,x:-1.8},0).wait(1).to({scaleX:0.11,skewY:0,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.2},0).wait(1).to({scaleX:0.33,x:-17.7},0).wait(1).to({scaleX:0.44,x:-23.1},0).wait(1).to({scaleX:0.56,x:-28.6},0).wait(1).to({scaleX:0.67,x:-34},0).wait(1).to({scaleX:0.78,x:-39.5},0).wait(1).to({scaleX:0.89,x:-45},0).wait(1).to({scaleX:1,x:-50.4},0).wait(1).to({_off:true},1).wait(56));

	// Mask
	this.instance_6 = new lib.mc_Triangulo();
	this.instance_6.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(26).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.7},0).wait(1).to({scaleX:0.67,x:31.2},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.3},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:3.9},0).wait(1).to({scaleX:0,skewY:0,x:-1.3},0).wait(1).to({scaleX:0.11,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.2},0).wait(1).to({scaleX:0.33,x:-17.7},0).wait(1).to({scaleX:0.44,x:-23.1},0).wait(1).to({scaleX:0.56,x:-28.6},0).wait(1).to({scaleX:0.67,x:-34},0).wait(1).to({scaleX:0.78,x:-39.5},0).wait(1).to({scaleX:0.89,x:-45},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_7 = new lib.mc_Triangulo();
	this.instance_7.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(28).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.7},0).wait(1).to({scaleX:0.67,x:31.2},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.3},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:3.9},0).wait(1).to({scaleX:0,skewY:0,x:-1.3},0).wait(1).to({scaleX:0.11,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.2},0).wait(1).to({scaleX:0.33,x:-17.7},0).wait(1).to({scaleX:0.44,x:-23.1},0).wait(1).to({scaleX:0.56,x:-28.6},0).wait(1).to({scaleX:0.67,x:-34},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_8 = new lib.mc_Triangulo();
	this.instance_8.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(30).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.4},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:4},0).wait(1).to({scaleX:0,x:-1.2},0).wait(1).to({scaleX:0.11,skewY:0,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.1},0).wait(1).to({scaleX:0.33,x:-17.6},0).wait(1).to({scaleX:0.44,x:-23.1},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_9 = new lib.mc_Triangulo();
	this.instance_9.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(32).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.4},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:4},0).wait(1).to({scaleX:0,x:-1.2},0).wait(1).to({scaleX:0.11,skewY:0,x:-6.7},0).wait(1).to({scaleX:0.22,x:-12.1},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_10 = new lib.mc_Triangulo();
	this.instance_10.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(34).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.4},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).wait(1).to({scaleX:0.11,x:4},0).wait(1).to({scaleX:0,x:-1.8},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_11 = new lib.mc_Triangulo();
	this.instance_11.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(36).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.7},0).wait(1).to({scaleX:0.67,x:31.2},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.3},0).wait(1).to({scaleX:0.33,x:14.9},0).wait(1).to({scaleX:0.22,x:9.4},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_12 = new lib.mc_Triangulo();
	this.instance_12.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(38).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.7},0).wait(1).to({scaleX:0.67,x:31.2},0).wait(1).to({scaleX:0.56,x:25.8},0).wait(1).to({scaleX:0.44,x:20.3},0).to({_off:true},1).wait(56));

	// Mask
	this.instance_13 = new lib.mc_Triangulo();
	this.instance_13.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(40).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).wait(1).to({scaleX:0.78,x:36.8},0).wait(1).to({scaleX:0.67,x:31.3},0).to({_off:true},1).wait(56));

	// FlashAICB
	this.instance_14 = new lib.mc_Triangulo();
	this.instance_14.setTransform(-1.3,66.5,1,1,0,0,0,213.8,143);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(42).to({_off:false},0).wait(1).to({regX:164.6,regY:142,scaleX:0.9,x:-45.3,y:65.5},0).wait(1).to({scaleX:0.79,x:-40.1},0).wait(1).to({scaleX:0.68,x:-34.9},0).wait(1).to({scaleX:0.58,x:-29.7},0).wait(1).to({scaleX:0.47,x:-24.6},0).wait(1).to({scaleX:0.37,x:-19.4},0).wait(1).to({scaleX:0.26,x:-14.2},0).wait(1).to({scaleX:0.16,x:-9},0).wait(1).to({scaleX:0.05,x:-3.9},0).wait(1).to({skewY:180,x:1.1},0).wait(1).to({scaleX:0.16,x:6.3},0).wait(1).to({scaleX:0.26,x:11.5},0).wait(1).to({scaleX:0.37,x:16.6},0).wait(1).to({scaleX:0.47,x:21.8},0).wait(1).to({scaleX:0.58,x:27},0).wait(1).to({scaleX:0.68,x:32.2},0).wait(1).to({scaleX:0.79,x:37.3},0).wait(1).to({scaleX:0.9,x:42.5},0).wait(1).to({scaleX:1,x:47.7},0).wait(1).to({scaleX:0.89,x:42.2},0).to({_off:true},1).wait(56));

	// FlashAICB (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("AolR0MAAAgjnIRLAAMAAAAjng");
	var mask_graphics_23 = new cjs.Graphics().p("AnnRcIAppNQAAiDgOiFQgOj0gVj3QgUj+gOkEQgOiVgBiYIAXAAIP8hIIAAKFIAuKQIAANjIuHA/g");
	var mask_graphics_24 = new cjs.Graphics().p("AmpRDIBSorQAAh1gch4QgdjhgojqQgpjwgdj6QgciTAAiXIAWAAIPEiOIAAItIBbJsIAANuItUB+g");
	var mask_graphics_25 = new cjs.Graphics().p("AlqQrIB7oLQgBhmgqhsQgrjOg9jcQg9jigrjxQgqiPgBiWIAXAAIOKjWIAAHXICKJJIAAN4IsiC9g");
	var mask_graphics_26 = new cjs.Graphics().p("AksQSICknqQgBhXg5hfQg5i8hRjNQhRjUg5joQg4iNgCiUIAXAAINSkdIAAGAIC4IkIAAODIrwD8g");
	var mask_graphics_27 = new cjs.Graphics().p("AjuP6IDNnKQgBhIhHhTQhHiohmjCQhljEhIjfQhGiJgBiUIAXAAIMZlkIAAEpIDlIBIAAOOIq9E7g");
	var mask_graphics_28 = new cjs.Graphics().p("AivPiIDzmpQgBg6hThGQhWiWh5i0Qh6i2hWjWQhUiGgCiSIAYAAILgmsIAADTIETHcIAAOZIqLF7g");
	var mask_graphics_29 = new cjs.Graphics().p("AhxPJIEcmIQgBgrhjg6QhiiDiOimQiOiphkjLQhiiDgDiRIAYAAIKonzIAAB8IFBG3IAAOlIpZG5g");
	var mask_graphics_30 = new cjs.Graphics().p("AgzOxIFGloQgDgchwgtQhzhwigiZQiiibhzjCQhwiAgCiQIAYAAIJuo6IAAAlIFvGTIAAOwIonH5g");
	var mask_graphics_31 = new cjs.Graphics().p("AAAOxIE6ljQA+ATACAJIlxFHgAD5I8QiBhdi1iLQi2iNiBi7Qh+h6gDiPIAYAAII2qCIAAgxIGdFuIAAO7Ii8DVIhBgSg");
	var mask_graphics_32 = new cjs.Graphics().p("AAsPEID0lUIAyAbQCMAUADgBImZEmgAgGHEQjLiAiPixQiNh5gDiMIAZAAIH9rJIAAiIIHLFJIAAPHIjREjQh/hFinhng");
	var mask_graphics_33 = new cjs.Graphics().p("AArPXIC2k7QBUAkBHAZQB1AGAegHIm4D/gAIaLSQgBADgKADgAAAIzQjdhxieioQiah3gEiMIAZAAIHGsOIAAjfIH3ElIAAPSIjcF7Qhngsh6g9g");
	var mask_graphics_34 = new cjs.Graphics().p("AAiPqIB8kMQCQAyBxAYQBLgCAqgHIm1DLgAJLMFQgCARg1AJgAAAKjQjyhjisigQiohzgEiLIAZAAIGOtVIAAk2IIkEAIAAPeIjjHpQhLgahTghg");
	var mask_graphics_35 = new cjs.Graphics().p("AAYP9IBMjNQDHA5CWAOIAZgDIlzCJgAJ8M5QgEApieASgAAAMSQkGhVi6iWQi3hwgEiKIAaAAIFVudIAAmMIJSDbIAAPqIjiJnQgxgOgzgQg");
	var mask_graphics_36 = new cjs.Graphics().p("AAPQQIAliCQC4AqCUAKIkRBOgAGAPCIEthVQgEA6jFAfIgHAAQgtAAgwgEgAAAOCQkahHjJiNQjEhtgFiJIAaAAIEcvkIAAnjIKAC3IAAP1IjWLxIg0gMg");
	var mask_graphics_37 = new cjs.Graphics().p("AAGQjIAKgvQBmASBcAKIhbATgADSQQIIMhwQgEBKjUArQg5AFg/AAQhYAAhkgKgAAAPxQkug4jXiEQjThqgFiIIAaAAIDkwrIAAo6IKuCSIAAQBIi/ODIgQgDg");
	var mask_graphics_38 = new cjs.Graphics().p("AAARBQlCgrjmh7QjghmgFiHIAaAAICqxzIAAqQILcBuIAAQLIiVPyICBAAIKPhiQgEBYjhA3QhvATiFAAQiOAAingVg");
	var mask_graphics_39 = new cjs.Graphics().p("AAASIQlXgcj0hyQjuhjgFiGIAaAAIByy6IAArnIMJBJIAAQZIhiQvICSAAIK4hCQgEBnjvBEQilAnjTAAQhlAAhvgJg");
	var mask_graphics_40 = new cjs.Graphics().p("AAATNQlrgOkChpQj9hggFiFIAaAAIA50BIAAs+IM4AlIAAQkIgwRuICjAAILhghQgEB1j+BRQjaBBknAAQg1AAg4gCg");
	var mask_graphics_41 = new cjs.Graphics().p("AqQSwQkLhdgFiEIAbAAMAAAgjdINnAAMAAAAjdIO/AAQgFCEkLBdQkQBfmBAAQl/AAkRhfg");
	var mask_graphics_42 = new cjs.Graphics().p("AonSwQjghdgFiEIAXAAMAAAgjdILcAAMAAAAjdIMmAAQgECEjhBdQjlBflDAAQlCAAjlhfg");
	var mask_graphics_43 = new cjs.Graphics().p("AgBUPQlAAAjkhcIgIgDQjjhdgFiEIAXAAIAAgCMAAAghPIANiMIJlAAIAHAAIB1AAIBIL1IAAWrIJtA9IAWAAIBbAIQgJBjiHBNQgpAXg0AUQjUBWkiAHIgyAAIgCAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AgEUQQlCgCjmhbIgIgDQjlhdgFiEIAXAAIAAgCMAAAghbIAbh/IJpAAIAGgCIB1AAICSKxIAAW0II1B5IARAAIBPARQgOBgiJBLQgqAWg0AUQjWBUkjAGIguABIgHAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AgHUQQlEgCjnhbIgIgDQjohdgFiEIAXAAIAAgBMAAAghpIAphyIJsAAIAGgCIB1AAIDdJsIAAW8IH8C2IANAAQAmAOAcALQgTBeiLBJQgqAWg1ATQjYBSklAGIgpAAIgMAAg");
	var mask_graphics_46 = new cjs.Graphics().p("AgKUQQlGgCjphbIgIgDQjqhdgFiDIAXAAIABgCMAAAgh1IA2hmIJwAAIAFgCIB1AAIEnImIAAXGIHEDzIAIAAQAiARAUAQQgYBbiNBHQgrAVg1ATQjaBQknAFIgkAAIgRAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AgNUQQlHgDjrhaIgIgDQjthdgFiDIAXAAIABgBMAAAgiCIBEhZIJ0AAIAEgDIB2AAIFxHhIAAXPIGLEvIAEAAQAdAWAMAUQgdBYiPBFQgsAVg1ASQjcBOkoAEIghABIgVgBg");
	var mask_graphics_48 = new cjs.Graphics().p("AgQURQlJgEjthaIgIgDQjvhdgFiDIAXAAIABgBMAAAgiPIBShMIJ3AAIAEgEIB2AAIG7GdIAAXXIFTFsIgBAAQAZAbAEAXQgiBWiRBDQgtAUg1ASQjeBMkqAEIgcAAIgaAAg");
	var mask_graphics_49 = new cjs.Graphics().p("AgTURQlLgEjvhaIgIgDQjyhcgEiDIAXAAIABgBMAAAgicIBfhAIJ7AAIADgEIB4AAIIFFYIAAXgIEaGpIgGAAQAVAfgEAbQgoBTiSBBQguAUg1ARQjgBKksADIgXAAIgfAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AgZURQlNgEjwhaIgIgDQj0hcgFiDIAXAAIACgBMAAAgipIBsgyIJ/AAIADgFIB4AAIJOETIAAXpIDiHlIgKAAQAQAjgMAgQgtBQiUA/QgvAUg1AQQjiBIktACIgUAAIgjAAg");
	var mask_graphics_51 = new cjs.Graphics().p("AgkURQlPgFjyhZIgIgDQj3hcgFiDIAYAAIACAAMAAAgi2IB6gmIKCAAIACgGIB5AAIKYDPIAAXxICqIiIgPAAQALAogTAjQgyBOiXA9QgvATg1AQQjkBGkwACIgOAAIgogBg");
	var mask_graphics_52 = new cjs.Graphics().p("AgwUSQlQgGj0hZIgIgDQj5hcgFiCIAXAAIACgBMAAAgjCICIgaIKGAAIABgGIB6AAILiCKIAAX6IBxJfIgTAAQAHAsgcAnQg3BLiYA7QgwATg2APQjmBEkxABIgHAAIgwAAg");
	var mask_graphics_53 = new cjs.Graphics().p("Ag7USQlTgGj1hZIgIgDQj8hcgFiCIAYAAIACAAMAAAgjQICWgNIKJAAIABgGIB6AAIMsBEIAAYEIA5KbIgYAAQADAxgkArQg8BIibA5QgxASg1APQjoBCkxAAIgFAAIg0AAg");
	var mask_graphics_54 = new cjs.Graphics().p("AqSSzQkHhdgEiEIAaAAMAAAgjcIMwAAIAAgIIPyAAMAAAAjkIgdAAQgFCEkGBdQkMBgl4AAQl5AAkMhgg");
	var mask_graphics_55 = new cjs.Graphics().p("AozSzQjhhdgEiEIAWAAMAAAgjcIK8AAIAAgIINfAAMAAAAjkIgYAAQgFCEjgBdQjlBglCAAQlDAAjlhgg");
	var mask_graphics_56 = new cjs.Graphics().p("AgYUiQk/gBjmhZIgOgFQjnhdgFiDIAAgBIAWAAIABgFIAA9fIABgJIgBgxQAAioAcilIABgKQFFgHFPAAIA0AAIABgHQE6AAEzAIQCEAEB6AGQAFA2AAA4IAAApIACAaIAAdmIgDAaQAABogPBmIgZABQgGAygnArQg9BEiJA2Qi9BKj5ANQg6ADg6AAIgIAAg");
	var mask_graphics_57 = new cjs.Graphics().p("AgkUyQlFgCjrhYIgOgGQjvhcgFiDIAAgBIAXAAIABgEIAA+DIACgIQgDgYAAgZQAAimA4ieIACgJQFFgQFcAAIA1AAIABgGQFFABEzAPQCJAJB2ALQALA3AAA3QAAAVgCAWIAGAXIAAeIIgHAZQAABngeBjIgZACQgLAvgpApQhDBCiKAyQjCBHj+AMQg3ADg2AAIgQAAg");
	var mask_graphics_58 = new cjs.Graphics().p("AgxVBQlLgDjvhXIgPgGQj2hcgGiDIAAgBIAYAAIABgDIAA+lIAEgIQgEgYAAgZQAAijBTiYIAEgJQFFgXFnAAIA2AAIACgFQFPABEzAWQCOAOBzARQAQA2AAA4QAAAVgDAWIAJAVIAAerIgJAWQgCBmgsBhIgZADQgQAtgsAnQhJA+iLAwQjHBDkCALQgzACgzAAIgZAAg");
	var mask_graphics_59 = new cjs.Graphics().p("Ag+VRQlQgEj1hXIgPgGQj9hcgGiCIAAgBIAYAAIACgDIAA/IIAEgGQgFgZAAgaQAAifBwiTIAEgIQFGgeFzAAIA2AAIADgFQFZACEzAeQCUASBvAWQAVA2AAA4QAAAWgEAWIAMASIAAfOIgMAUQgCBmg7BeIgaAEQgUAqgvAlQhPA7iMAuQjLA/kHAKQgwACguAAIgjAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AhLVgQlWgFj5hWIgPgFQkFhcgGiDIAAAAIAZAAIACgDIAA/qIAFgGQgGgZAAgaQAAidCLiMIAFgHQFHgmF+AAIA4AAIAEgFQFiADE0AlQCZAXBrAcQAaA1AAA5QAAAWgFAWIAPAQIAAfxIgPARQgCBlhKBcIgaAFQgZAogyAiQhVA5iMAqQjRA9kKAIIhXACIgtgBg");
	var mask_graphics_61 = new cjs.Graphics().p("AhXVwQlcgHj+hVIgQgFQkMhcgGiCIAAgBIAZAAIADgCMAAAggNIAGgFQgIgZAAgbQAAiZCniGIAHgHQFHguGKAAIA4AAIADgDQFvADEzAsQCeAbBoAiQAfA1AAA5QAAAXgFAWIARAOMAAAAgTIgSAPQgCBkhZBaIgaAGQgeAlg0AhQhbA1iOAoQjVA5kPAHIhNABIg4AAg");
	var mask_graphics_62 = new cjs.Graphics().p("AhkV/QlhgHkEhUIgQgGQkThcgGiBIAAgBIAZAAIAEgCMAAAggvIAHgEQgJgaAAgbQAAiXDDh/IAHgGQFIg2GVAAIA4AAIAFgDQF5AEEzA0QCkAfBkAoQAlA0AAA5QAAAYgHAWIAUAMMAAAAg2IgVAMQgDBkhnBXIgbAHQghAig4AfQhhAziOAkQjaA2kUAGIhDABIhEgBg");
	var mask_graphics_63 = new cjs.Graphics().p("AhxWPQlngJkIhTIgQgGQkbhbgGiCIAAAAIAZAAIAEgCMAAAghSIAJgDQgLgaAAgcQAAiTDfh5IAJgGQFHg9GiAAIA4AAIAGgDQGDAFE0A7QCpAkBgAtQAqA0AAA6QAAAXgIAXIAXAJMAAAAhZIgYAKQgDBjh2BVIgbAIQgmAgg7AcQhnAwiPAiQjfAykYAFIg3ABIhSgBg");
	var mask_graphics_64 = new cjs.Graphics().p("Ah+WeQlsgJkNhTIgRgFQkihcgGiBIAAgBIAZAAIAFgBMAAAgh1IAJgCQgLgbAAgbQAAiRD6hyIAKgGQFIhFGtAAIA5ABIAHgCQGNAFE0BCQCuApBdAyQAvA0AAA6QAAAYgIAXIAZAHMAAAAh8IgbAHQgDBjiFBSIgcAJQgqAdg+AaQhsAtiRAfQjjAvkdAEIgrAAIhggBg");
	var mask_graphics_65 = new cjs.Graphics().p("AiLWtQlygKkShSIgQgFQkqhcgHiBIAAAAIAbAAIAFgBMAAAgiXIAKgCQgNgbAAgcQAAiNEXhsIAKgFQFJhNG5AAIA6AAIAHgBQGXAGE1BKQCzAtBZA4QA0A0AAA5QAAAZgJAXIAdAFMAAAAieIgfAFQgDBiiVBQIgbAKQgvAahBAZQhyAqiRAcQjpArkgADIgeAAQg5AAg3gCg");
	var mask_graphics_66 = new cjs.Graphics().p("AiXW9Ql4gMkXhRIgRgFQkxhcgHiAIAAgBIAbAAIAFAAMAAAgi6IAMgBQgOgbAAgcQAAiLEyhmIAMgEQFJhVHEAAIA7ABIAJgBQGhAHE0BRQC5AxBVA+QA6A0AAA6QAAAYgLAYIAgACMAAAAjCIghACQgFBhijBOIgbALQg0AYhDAWQh5AniSAZQjtAokjACIgRAAQhBAAg/gCg");
	var mask_graphics_67 = new cjs.Graphics().p("As9VvQlKhdgHiEIAhAAMAAAgjcIANAAQgQgcAAgdQAAiHFOhgQFOhgHXAAQHZAAFNBgQFPBgAACHQAAAZgMAYIAjAAMAAAAjkIgkAAQgHCElKBdQlRBgnaAAQnbAAlRhgg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:-56.6,y:65.5}).wait(1).to({graphics:mask_graphics_23,x:-56.9,y:67.8}).wait(1).to({graphics:mask_graphics_24,x:-57.1,y:70.2}).wait(1).to({graphics:mask_graphics_25,x:-57.4,y:72.6}).wait(1).to({graphics:mask_graphics_26,x:-57.7,y:75}).wait(1).to({graphics:mask_graphics_27,x:-58,y:77.4}).wait(1).to({graphics:mask_graphics_28,x:-58.2,y:79.8}).wait(1).to({graphics:mask_graphics_29,x:-58.5,y:82.1}).wait(1).to({graphics:mask_graphics_30,x:-58.8,y:84.5}).wait(1).to({graphics:mask_graphics_31,x:-59.1,y:84.4}).wait(1).to({graphics:mask_graphics_32,x:-59.3,y:82.5}).wait(1).to({graphics:mask_graphics_33,x:-55,y:80.5}).wait(1).to({graphics:mask_graphics_34,x:-49.8,y:78.6}).wait(1).to({graphics:mask_graphics_35,x:-44.6,y:76.6}).wait(1).to({graphics:mask_graphics_36,x:-39.5,y:74.7}).wait(1).to({graphics:mask_graphics_37,x:-34.3,y:72.7}).wait(1).to({graphics:mask_graphics_38,x:-29.2,y:74}).wait(1).to({graphics:mask_graphics_39,x:-24,y:76}).wait(1).to({graphics:mask_graphics_40,x:-18.9,y:78.4}).wait(1).to({graphics:mask_graphics_41,x:-13.7,y:81}).wait(1).to({graphics:mask_graphics_42,x:1,y:81}).wait(1).to({graphics:mask_graphics_43,x:-0.2,y:80.9}).wait(1).to({graphics:mask_graphics_44,x:-1.5,y:80.9}).wait(1).to({graphics:mask_graphics_45,x:-2.9,y:80.9}).wait(1).to({graphics:mask_graphics_46,x:-4.2,y:80.8}).wait(1).to({graphics:mask_graphics_47,x:-5.5,y:80.8}).wait(1).to({graphics:mask_graphics_48,x:-6.8,y:80.8}).wait(1).to({graphics:mask_graphics_49,x:-8.1,y:80.7}).wait(1).to({graphics:mask_graphics_50,x:-9.1,y:80.7}).wait(1).to({graphics:mask_graphics_51,x:-9.6,y:80.7}).wait(1).to({graphics:mask_graphics_52,x:-10.1,y:80.6}).wait(1).to({graphics:mask_graphics_53,x:-10.5,y:80.6}).wait(1).to({graphics:mask_graphics_54,x:-11,y:80.6}).wait(1).to({graphics:mask_graphics_55,x:2.2,y:80.6}).wait(1).to({graphics:mask_graphics_56,x:1.3,y:79}).wait(1).to({graphics:mask_graphics_57,x:0.4,y:77.4}).wait(1).to({graphics:mask_graphics_58,x:-0.4,y:75.9}).wait(1).to({graphics:mask_graphics_59,x:-1.2,y:74.3}).wait(1).to({graphics:mask_graphics_60,x:-2.1,y:72.7}).wait(1).to({graphics:mask_graphics_61,x:-3,y:71.2}).wait(1).to({graphics:mask_graphics_62,x:-3.9,y:69.6}).wait(1).to({graphics:mask_graphics_63,x:-4.8,y:68}).wait(1).to({graphics:mask_graphics_64,x:-5.7,y:66.5}).wait(1).to({graphics:mask_graphics_65,x:-6.6,y:64.9}).wait(1).to({graphics:mask_graphics_66,x:-7.5,y:63.4}).wait(1).to({graphics:mask_graphics_67,x:-8.4,y:61.8}).wait(1).to({graphics:null,x:0,y:0}).wait(51));

	// FlashAICB
	this.instance_15 = new lib.mc_Cono();
	this.instance_15.setTransform(-40.9,77.6,0.728,0.767,0,0,0,77.2,165.6);
	this.instance_15._off = true;

	this.instance_15.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({_off:false},0).wait(1).to({regX:135.8,regY:157.8,x:1.7,y:71.7},0).wait(50).wait(1).to({x:5.8},0).wait(1).to({x:10},0).wait(1).to({x:14.1},0).wait(1).to({x:18.3},0).wait(1).to({x:22.4},0).wait(1).to({x:26.5},0).wait(1).to({x:30.7},0).wait(1).to({x:34.8},0).wait(1).to({x:38.9},0).wait(1).to({x:43.1},0).wait(1).to({x:47.2},0).wait(1).to({x:51.4},0).wait(1).to({x:55.5},0).wait(33));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-100.7,-88.4,113.3,310);


(lib.popup_info_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MarcaAgua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(206));

	// Txts
	this.txt_popup_info_03 = new cjs.Text("", "20px Verdana");
	this.txt_popup_info_03.lineHeight = 22;
	this.txt_popup_info_03.lineWidth = 730;
	this.txt_popup_info_03.setTransform(81,18.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_popup_info_03}]}).wait(206));

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.3,54.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_salir}]}).wait(206));

	// Capa 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(2,1,1).p("AMHsRQFBFGAAHLQAAHMlBFGQlCFGnFAAQnEAAlClGQlBlGAAnMQAAnLFBlGQFClGHEAAQHFAAFCFGg");
	this.shape.setTransform(294.6,361.7,1.265,0.342);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,1,1).p("A1dAAQAAimGSh3QGTh3I4AAQI5AAGTB3QGSB3AACmQAAComSB2QmTB3o5AAQo4AAmTh3QmSh2AAio");
	this.shape_1.setTransform(310.1,363.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("A1SAAQAAixGQh/QGPh+IzAAQI0AAGPB+QGQB/AACxQAACzmQB+QmPB+o0AAQozAAmPh+QmQh+AAiz");
	this.shape_2.setTransform(325.6,365.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FF0000").ss(2,1,1).p("A1GAAQAAi8GMiGQGMiGIuAAQIvAAGMCGQGMCGAAC8QAAC9mMCGQmMCGovAAQouAAmMiGQmMiGAAi9");
	this.shape_3.setTransform(341,366.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(2,1,1).p("A07AAQAAjGGJiOQGIiOIqAAQIrAAGICOQGJCOAADGQAADImJCNQmICOorAAQoqAAmIiOQmJiNAAjI");
	this.shape_4.setTransform(356.5,368.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FF0000").ss(2,1,1).p("A0vAAQAAjRGFiVQGFiVIlAAQImAAGFCVQGFCVAADRQAADSmFCVQmFCVomAAQolAAmFiVQmFiVAAjS");
	this.shape_5.setTransform(372,370.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF0000").ss(2,1,1).p("A0kAAQAAjcGCidQGCicIgAAQIhAAGCCcQGCCdAADcQAADdmCCcQmCCdohAAQogAAmCidQmCicAAjd");
	this.shape_6.setTransform(387.4,372);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF0000").ss(2,1,1).p("A0YAAQAAjmF+ilQF/ikIbAAQIcAAF/CkQF+ClAADmQAADol+CkQl/CkocAAQobAAl/ikQl+ikAAjo");
	this.shape_7.setTransform(402.9,373.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FF0000").ss(2,1,1).p("A0MAAQAAjxF6isQF7isIXAAQIYAAF7CsQF6CsAADxQAADyl6CsQl7CsoYAAQoXAAl7isQl6isAAjy");
	this.shape_8.setTransform(418.4,375.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FF0000").ss(2,1,1).p("A0BAAQAAj8F4izQF3izISAAQITAAF3CzQF4CzAAD8QAAD9l4CzQl3CzoTAAQoSAAl3izQl4izAAj9");
	this.shape_9.setTransform(433.8,377.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF0000").ss(2,1,1).p("Az1AAQAAkGF0i7QF0i7INAAQIOAAF0C7QF0C7AAEGQAAEIl0C6Ql0C7oOAAQoNAAl0i7Ql0i6AAkI");
	this.shape_10.setTransform(449.3,378.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FF0000").ss(2,1,1).p("AzqAAQAAkRFxjDQFxjCIIAAQIJAAFxDCQFxDDAAERQAAESlxDCQlxDDoJAAQoIAAlxjDQlxjCAAkS");
	this.shape_11.setTransform(464.8,380.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF0000").ss(2,1,1).p("AzeAAQAAkcFtjKQFujKIDAAQIEAAFuDKQFtDKAAEcQAAEdltDKQluDKoEAAQoDAAlujKQltjKAAkd");
	this.shape_12.setTransform(480.2,382.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF0000").ss(2,1,1).p("AzTAAQAAkmFqjSQFqjRH/AAQIAAAFqDRQFqDSAAEmQAAEolqDRQlqDRoAAAQn/AAlqjRQlqjRAAko");
	this.shape_13.setTransform(495.7,384.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF0000").ss(2,1,1).p("AzHAAQAAkxFmjZQFnjZH6AAQH7AAFnDZQFmDZAAExQAAEylmDZQlnDZn7AAQn6AAlnjZQlmjZAAky");
	this.shape_14.setTransform(511.2,385.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FF0000").ss(2,1,1).p("Ay8AAQAAk8FjjgQFkjhH1AAQH2AAFkDhQFjDgAAE8QAAE9ljDgQlkDhn2AAQn1AAlkjhQljjgAAk9");
	this.shape_15.setTransform(526.6,387.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FF0000").ss(2,1,1).p("AywAAQAAlGFgjpQFgjnHwAAQHxAAFgDnQFgDpAAFGQAAFHlgDoQlgDonxAAQnwAAlgjoQlgjoAAlH");
	this.shape_16.setTransform(542.1,389.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF0000").ss(2,1,1).p("AylAAQAAlRFdjwQFcjvHsAAQHtAAFcDvQFdDwAAFRQAAFSldDwQlcDvntAAQnsAAlcjvQldjwAAlS");
	this.shape_17.setTransform(557.6,390.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF0000").ss(2,1,1).p("AyZAAQAAlcFZj3QFZj3HnAAQHoAAFZD3QFZD3AAFcQAAFdlZD3QlZD3noAAQnnAAlZj3QlZj3AAld");
	this.shape_18.setTransform(573,392.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF0000").ss(2,1,1).p("AyOAAQAAlmFWj/QFWj/HiAAQHjAAFWD/QFWD/AAFmQAAFnlWD/QlWD/njAAQniAAlWj/QlWj/AAln");
	this.shape_19.setTransform(588.5,394.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FF0000").ss(2,1,1).p("AyCAAQAAlxFSkHQFTkFHdAAQHeAAFTEFQFSEHAAFxQAAFylSEGQlTEGneAAQndAAlTkGQlSkGAAly");
	this.shape_20.setTransform(604,396.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FF0000").ss(2,1,1).p("Ax2AAQAAl8FOkOQFQkNHYAAQHZAAFQENQFOEOAAF8QAAF9lOENQlQEOnZAAQnYAAlQkOQlOkNAAl9");
	this.shape_21.setTransform(619.4,397.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FF0000").ss(2,1,1).p("AxrAAQAAmGFMkWQFLkVHUAAQHVAAFLEVQFMEWAAGGQAAGHlMEWQlLEVnVAAQnUAAlLkVQlMkWAAmH");
	this.shape_22.setTransform(634.9,399.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FF0000").ss(2,1,1).p("AxfAAQAAmRFIkdQFIkdHPAAQHQAAFIEdQFIEdAAGRQAAGSlIEdQlIEdnQAAQnPAAlIkdQlIkdAAmS");
	this.shape_23.setTransform(650.4,401.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FF0000").ss(2,1,1).p("AxUAAQAAmcFFkkQFFkkHKAAQHLAAFFEkQFFEkAAGcQAAGdlFEkQlFEknLAAQnKAAlFkkQlFkkAAmd");
	this.shape_24.setTransform(665.8,403);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FF0000").ss(2,1,1).p("AxIAAQAAmmFBktQFCkrHFAAQHGAAFCErQFBEtAAGmQAAGnlBEsQlCEsnGAAQnFAAlCksQlBksAAmn");
	this.shape_25.setTransform(681.3,404.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FF0000").ss(2,1,1).p("Aw9AAQAAmxE+k0QE+kzHBAAQHCAAE+EzQE+E0AAGxQAAGyk+EzQk+E0nCAAQnBAAk+k0Qk+kzAAmy");
	this.shape_26.setTransform(696.8,406.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{scaleX:1.265,scaleY:0.342,x:294.6,y:361.7}}]},178).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape,p:{scaleX:0.981,scaleY:0.967,x:712.2,y:408.1}}]},1).wait(1));

	// mc_Circulo
	this.instance_1 = new lib.mc_Circulo();
	this.instance_1.setTransform(294.6,362,1,1,0,0,0,140.8,38.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(145).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(44));

	// Circulo_01
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FF0000").ss(2,1,1).p("AFzldQCaCRAADMQAADNiaCRQiaCRjZAAQjYAAiaiRQiaiRAAjNQAAjMCaiRQCaiRDYAAQDZAACaCRg");
	this.shape_27.setTransform(277.5,244.5,1.244,0.264,-9.9,0,0,0,0.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FF0000").ss(2,1,1).p("Ap8BwQgLg7CzhKQC0hKEIgvQEGgvDCAKQDDAJAKA7QAKA8izBJQizBKkIAvQkHAvjCgKQjCgIgKg8");
	this.shape_28.setTransform(295.7,244.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FF0000").ss(2,1,1).p("Ap3BvQgMhBCxhOQCxhPEGguQEEguDBAOQDCANAMBCQALBCixBNQixBPkGAuQkEAujBgOQjCgNgLhC");
	this.shape_29.setTransform(313.8,244.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FF0000").ss(2,1,1).p("ApyBuQgMhHCuhSQCvhTEEguQECguDAATQDBASANBIQAMBIivBRQiuBTkEAuQkCAujBgTQjAgSgNhI");
	this.shape_30.setTransform(331.9,243.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FF0000").ss(2,1,1).p("ApsBtQgOhOCshVQCshXECguQEAgtC/AXQDBAXANBOQAOBOisBVQitBXkBAuQkAAtjAgXQjAgXgNhO");
	this.shape_31.setTransform(350,243.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FF0000").ss(2,1,1).p("ApnBsQgPhUCphaQCrhbD/gtQD+gtC/AcQC/AcAPBUQAPBUiqBaQiqBbkAAtQj9Ati/gcQjAgbgOhV");
	this.shape_32.setTransform(368.1,243.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FF0000").ss(2,1,1).p("ApiBrQgQhaCnheQCohfD+gtQD7gsC+AgQC/AgAQBaQAQBbioBeQioBfj9AtQj8Asi+ggQi+gggQhb");
	this.shape_33.setTransform(386.2,243.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FF0000").ss(2,1,1).p("ApdBqQgRhgClhiQCmhjD7gtQD5gsC+AlQC+AlARBgQAQBhilBiQilBjj8AtQj5Asi9glQi+glgRhh");
	this.shape_34.setTransform(404.3,243.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FF0000").ss(2,1,1).p("ApXBpQgThmCjhmQCjhoD5gsQD3gsC9AqQC9AqASBmQASBnijBmQijBoj5AsQj3Ari9gpQi9gqgRhn");
	this.shape_35.setTransform(422.4,243.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FF0000").ss(2,1,1).p("ApSBpQgThrCghsQChhsD3grQD1gsC7AuQC9AvATBsQATBrihBsQigBsj3AsQj1Ari8guQi8gugTht");
	this.shape_36.setTransform(440.5,242.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FF0000").ss(2,1,1).p("ApNBoQgUhxCehxQCfhvD0grQDzgsC7AzQC8AzAUBzQAUByifBwQieBvj1AsQjyAri8gzQi7gzgUhz");
	this.shape_37.setTransform(458.7,242.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FF0000").ss(2,1,1).p("ApIBnQgVh3Cch1QCch0DzgqQDwgrC6A3QC7A4AWB5QAVB4icB0QidB0jyArQjwAqi7g3Qi6g4gWh5");
	this.shape_38.setTransform(476.8,242.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FF0000").ss(2,1,1).p("ApCBmQgXh+Cah4QCah4DwgqQDugrC6A8QC6A9AWB/QAXB+iaB4QiaB4jwAqQjvAri5g9Qi6g8gWh/");
	this.shape_39.setTransform(494.9,242.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FF0000").ss(2,1,1).p("Ao9BlQgYiECYh8QCXh8DugqQDsgqC5BBQC6BAAXCGQAYCEiYB8QiYB8juAqQjsAqi5hBQi5hAgXiG");
	this.shape_40.setTransform(513,242.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FF0000").ss(2,1,1).p("Ao4BkQgYiKCUiAQCWiBDsgpQDqgqC4BGQC4BFAZCMQAYCKiVCAQiVCBjsApQjqAqi4hGQi4hFgZiM");
	this.shape_41.setTransform(531.1,242);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FF0000").ss(2,1,1).p("AozBjQgZiQCSiFQCTiEDqgpQDogqC3BLQC4BKAaCSQAZCQiTCFQiTCEjpApQjoApi4hKQi3hKgaiS");
	this.shape_42.setTransform(549.2,241.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FF0000").ss(2,1,1).p("AotBiQgbiWCQiJQCRiIDngpQDmgpC2BPQC4BPAaCYQAbCWiRCJQiQCIjoApQjlApi3hPQi3hPgaiY");
	this.shape_43.setTransform(567.3,241.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FF0000").ss(2,1,1).p("AooBhQgcicCOiNQCOiNDmgoQDjgpC2BUQC2BTAcCfQAcCciPCNQiOCNjlAoQjjAoi2hTQi2hTgcif");
	this.shape_44.setTransform(585.4,241.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FF0000").ss(2,1,1).p("AojBgQgdiiCMiRQCMiRDjgoQDhgoC1BYQC2BYAdCkQAdCjiNCRQiLCRjkAoQjhAoi1hYQi1hYgdil");
	this.shape_45.setTransform(603.6,241.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FF0000").ss(2,1,1).p("AoeBfQgeioCKiWQCKiUDggoQDfgoC1BdQC0BdAfCqQAeCpiKCVQiKCVjhAoQjfAoi0hdQi1hdgeir");
	this.shape_46.setTransform(621.7,241.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FF0000").ss(2,1,1).p("AoYBeQgfivCHiZQCHiZDfgnQDdgnCzBhQC0BhAfCxQAfCviHCaQiICZjeAnQjdAni0hhQizhigfix");
	this.shape_47.setTransform(639.8,241);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FF0000").ss(2,1,1).p("AoTBdQggi1CFidQCFidDcgnQDbgnCyBmQC0BmAgC3QAgC2iFCdQiFCdjdAnQjaAnizhmQizhmggi4");
	this.shape_48.setTransform(657.9,240.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FF0000").ss(2,1,1).p("AoOBcQghi7CCihQCDihDbgnQDYgmCyBqQCyBrAiC9QAhC8iDChQiDChjaAnQjYAmiyhqQiyhrgii+");
	this.shape_49.setTransform(676,240.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FF0000").ss(2,1,1).p("AoIBbQgjjBCAilQCBimDYgmQDWgmCxBvQCyBwAjDDQAiDCiBClQiACmjYAmQjXAmixhwQixhvgijE");
	this.shape_50.setTransform(694.1,240.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_27,p:{regY:0.2,scaleX:1.244,scaleY:0.264,x:277.5,y:244.5}}]},86).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_27,p:{regY:0.1,scaleX:0.999,scaleY:0.999,x:712.2,y:240.3}}]},1).wait(96));

	// mc_Cupula
	this.instance_2 = new lib.mc_Cupula();
	this.instance_2.setTransform(277.5,240,1,1,0,0,0,66,22.3);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(53).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(136));

	// mc_CorteArriba
	this.instance_3 = new lib.mc_CorteArriba();
	this.instance_3.setTransform(695.5,165,1,1,0,0,0,212,60.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(37).to({_off:false},0).wait(1).to({x:669,y:170,alpha:0.063},0).wait(1).to({x:642.6,y:175,alpha:0.125},0).wait(1).to({x:616.1,y:180,alpha:0.188},0).wait(1).to({x:589.7,y:185,alpha:0.25},0).wait(1).to({x:563.3,y:190,alpha:0.313},0).wait(1).to({x:536.8,y:195,alpha:0.375},0).wait(1).to({x:510.4,y:199.9,alpha:0.438},0).wait(1).to({x:484,y:205,alpha:0.5},0).wait(1).to({x:457.5,y:210,alpha:0.563},0).wait(1).to({x:431.1,y:215,alpha:0.625},0).wait(1).to({x:404.7,y:220,alpha:0.688},0).wait(1).to({x:378.2,y:225,alpha:0.75},0).wait(1).to({x:351.8,y:230,alpha:0.813},0).wait(1).to({x:325.4,y:234.9,alpha:0.875},0).wait(1).to({x:298.9,y:240,alpha:0.938},0).wait(1).to({x:272.5,y:245,alpha:1},0).wait(153));

	// mc_circuloArriba
	this.instance_4 = new lib.mc_circuloArriba();
	this.instance_4.setTransform(294.6,289,1,1,0,0,0,140.3,70.5);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({alpha:0.067},0).wait(1).to({alpha:0.133},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.267},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.467},0).wait(1).to({alpha:0.533},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.733},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.867},0).wait(1).to({alpha:0.933},0).wait(1).to({alpha:1},0).wait(191));

	// mc_CorteMedio
	this.instance_5 = new lib.mc_CorteMedio();
	this.instance_5.setTransform(691.5,367,1,1,0,0,0,225,61.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(127).to({_off:false},0).wait(1).to({x:669.3,alpha:0.056},0).wait(1).to({x:647.2,alpha:0.111},0).wait(1).to({x:625.1,alpha:0.167},0).wait(1).to({x:603,alpha:0.222},0).wait(1).to({x:580.9,alpha:0.278},0).wait(1).to({x:558.8,alpha:0.333},0).wait(1).to({x:536.7,alpha:0.389},0).wait(1).to({x:514.6,alpha:0.444},0).wait(1).to({x:492.5,alpha:0.5},0).wait(1).to({x:470.4,alpha:0.556},0).wait(1).to({x:448.3,alpha:0.611},0).wait(1).to({x:426.2,alpha:0.667},0).wait(1).to({x:404,alpha:0.722},0).wait(1).to({x:381.9,alpha:0.778},0).wait(1).to({x:359.8,alpha:0.833},0).wait(1).to({x:337.7,alpha:0.889},0).wait(1).to({x:315.6,alpha:0.944},0).wait(1).to({x:293.5,alpha:1},0).wait(61));

	// mc_CirculoAbajo
	this.instance_6 = new lib.mc_CirculoAbajo();
	this.instance_6.setTransform(294.6,428.3,1,1,0,0,0,140.3,70.5);
	this.instance_6.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({alpha:0.067},0).wait(1).to({alpha:0.133},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.267},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.467},0).wait(1).to({alpha:0.533},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.733},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.867},0).wait(1).to({alpha:0.933},0).wait(1).to({alpha:1},0).wait(191));

	// Capa 1
	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape_51.setTransform(475,304);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_51}]}).wait(206));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_info_02 = function() {
	this.initialize();

	// MarcaAgua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Txts
	this.txt_popup_2_4 = new cjs.Text("", "20px Arial", "#FF7F00");
	this.txt_popup_2_4.lineHeight = 22;
	this.txt_popup_2_4.lineWidth = 135;
	this.txt_popup_2_4.setTransform(597.2,366);

	this.txt_popup_2_3 = new cjs.Text("", "20px Arial", "#5973FF");
	this.txt_popup_2_3.lineHeight = 22;
	this.txt_popup_2_3.lineWidth = 135;
	this.txt_popup_2_3.setTransform(568.2,322);

	this.txt_popup_2_2 = new cjs.Text("", "20px Arial", "#00FF00");
	this.txt_popup_2_2.lineHeight = 22;
	this.txt_popup_2_2.lineWidth = 135;
	this.txt_popup_2_2.setTransform(546.8,281);

	this.txt_popup_2_1 = new cjs.Text("", "20px Arial", "#FF0000");
	this.txt_popup_2_1.lineHeight = 22;
	this.txt_popup_2_1.lineWidth = 178;
	this.txt_popup_2_1.setTransform(522,238);

	this.txt_popup_info_02 = new cjs.Text("", "20px Verdana");
	this.txt_popup_info_02.lineHeight = 20;
	this.txt_popup_info_02.lineWidth = 794;
	this.txt_popup_info_02.setTransform(82,43.6);

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.3,54.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// FlashAICB
	this.instance_1 = new lib.info_02();
	this.instance_1.setTransform(297.7,187.8,0.4,0.4);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape.setTransform(475,304);

	this.addChild(this.shape,this.instance_1,this.btn_salir,this.txt_popup_info_02,this.txt_popup_2_1,this.txt_popup_2_2,this.txt_popup_2_3,this.txt_popup_2_4,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_info_01 = function() {
	this.initialize();

	// MarcaAgua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Txts
	this.txt_popup_04 = new cjs.Text("", "20px Verdana");
	this.txt_popup_04.textAlign = "center";
	this.txt_popup_04.lineHeight = 22;
	this.txt_popup_04.lineWidth = 135;
	this.txt_popup_04.setTransform(724.7,484);

	this.txt_popup_03 = new cjs.Text("", "20px Verdana");
	this.txt_popup_03.textAlign = "center";
	this.txt_popup_03.lineHeight = 22;
	this.txt_popup_03.lineWidth = 135;
	this.txt_popup_03.setTransform(416.4,484);

	this.txt_popup_02 = new cjs.Text("", "20px Verdana");
	this.txt_popup_02.textAlign = "center";
	this.txt_popup_02.lineHeight = 22;
	this.txt_popup_02.lineWidth = 135;
	this.txt_popup_02.setTransform(150.6,484);

	this.txt_popup_info_01 = new cjs.Text("", "20px Verdana");
	this.txt_popup_info_01.lineHeight = 22;
	this.txt_popup_info_01.lineWidth = 734;
	this.txt_popup_info_01.setTransform(82,43.6);

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.3,54.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Imatges
	this.instance_1 = new lib.elipse();
	this.instance_1.setTransform(81.6,204.6,0.3,0.3);

	this.instance_2 = new lib.parabola();
	this.instance_2.setTransform(330.2,218.1,0.3,0.3);

	this.instance_3 = new lib.hiperbola();
	this.instance_3.setTransform(584.1,216.1,0.3,0.3);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	this.shape.setTransform(475,304);

	this.addChild(this.shape,this.instance_3,this.instance_2,this.instance_1,this.btn_salir,this.txt_popup_info_01,this.txt_popup_02,this.txt_popup_03,this.txt_popup_04,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);
      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}