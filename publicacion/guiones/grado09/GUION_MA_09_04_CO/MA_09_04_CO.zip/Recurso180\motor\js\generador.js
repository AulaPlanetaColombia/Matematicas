Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			//console.log(this.lEnunciados_STRING[this.nOp]);
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		//console.log(this.llRespuestas_SPRITE);
		for(var i = 0; i < Motor.qOperaciones; i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				//console.log("Iteracion : ["+ i + "][" + j + "] Esto es ea : " + ea);
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		//declara variables internas:
		var nAux;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,R,S,T,U,V,W,X,Y,Z;
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var eaP=EA.ini('');
		//console.log(eaP);
		co_pregunta.addChild(eaP);
		nOK=Random.integer(0,this.qAlternativas-1);
		var sOK,s1,s2,s3;
		
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(modelo){
				case 0:
				    EA.adcStatic(JL.cursiva('y')+' = ',eaP);
                    //i=Random.integer(0,6);
					//EA.adcStatic(JL.cursiva('y')+' = ',eaP);
					A=Random.integer(0,6);
					B=A+Random.integer(2,10,[A]);
					this.enun = this.enun.replace('AAA',JL.num2str(A,0)+', '+JL.num2str(B,0));
					
					i=Random.integer(0,2);
					//console.log("formato: "+EA._formatoBase);
						switch(i){
                            case 0://   y = mx
                                EA.adcStatic(EA.pol2([0,Random.integer(-9,9,[0])],'x',true,true),eaP);
                                sOK='origen';
                            break;
                            case 1://   y = mx + n
                                EA.adcStatic(EA.pol2([Random.integer(-5,5,[0]),Random.integer(-9,9,[0])],'x',true,true),eaP);
                                sOK='ninguna';
                            break;
                            case 2://   y = ax2 + c
                                EA.adcStatic(EA.pol2([Random.integer(-5,5),0,Random.integer(-4,4,[0])],'x',true,true),eaP);
                                sOK='eje Y';
                            break;
                            case 3://   y = ax2 + bx + c
                                a=Random.integer(-3,3,[0]);
                                b=Random.integer(-6,6,[0])*2*a;
                                c=Random.integer(-5,5);
                                EA.adcStatic(EA.pol2([c,b,a],'x',true,true),eaP);
                                nAux=-b/2/a;
                                sOK='eje '+JL.cursiva('x')+' = '+JL.num2str(nAux);
                            break;
                            case 4://   y = mx3 + nx
                                m=Random.integer(-3,3,[0]);
                                n=Random.integer(-7,7);
                                EA.adcStatic(EA.pol2([0,n,0,m],'x',true,true),eaP);
                                sOK='origen';
                            break;
                            case 5://   y = N·sen(x)
                                a=Random.integer(1,3);
                                if(a>1){EA.adcStatic(String(a)+' · ',eaP)}
                                if(Random.integer(0,1)==0){EA.adcStatic('sen',eaP)}else{EA.adcStatic('tg',eaP)}
                                //if(r.integer(0,2)==0){EA.ade(eaP,String(2))}
                                EA.adcStatic(JL.cursiva('x'),eaP);
                                sOK='origen';   
                            break;
                            case 6://   y = N·cos(x)
                                a=Random.integer(1,3);
                                if(a>1){EA.adcStatic(String(a)+' · ',eaP)}
                                EA.adcStatic('cos',eaP);
                                EA.adcStatic(JL.cursiva('x'),eaP);
                                sOK='eje Y';
                            break;
                        }
                        
                      var lTira = ['ninguna','origen','eje X','eje Y','origen y eje X','origen y eje Y','eje X y eje Y','origen, eje X y eje Y'];
                      while(true){
                        nAux=Random.integer(0,8);
                        //console.log("Id de array lTira : " + nAux);
                        if(nAux==8){
                            s1='eje '+JL.cursiva('x')+' = '+JL.num2str(Random.integer(-7,7));
                        }else{
                            s1=lTira[nAux];
                        }
                        //console.log("Id : " + nAux + " valor ; " + s1);
                        nAux=Random.integer(0,8);
                        if(nAux==8){
                            s2='eje '+JL.cursiva('x')+' = '+JL.num2str(Random.integer(-7,7));
                        }else{
                            s2=lTira[nAux];
                        }
                        //console.log("Id2 : " + nAux + " valor2 ; " + s2);
                        nAux = Random.integer(0,7);
                        s3=lTira[nAux];
                        //console.log("Id3 : " + nAux + " valor3 ; " + s3);
                        if(JL.sonDistintosTodos([sOK,s1,s2,s3])){break}
                    }
                    var lWork = new Array();
                    lWork = JL.barajar([s1,s2,s3]);
                    //console.log(lWork);
                    nAux=0;
                    for(na=0;na<this.qAlternativas;na++){
                        //var spr:Sprite=lSP_alts[na];
                        if(na==nOK){
                            lSP_alts[na] = sOK;
                            //EA.adc(sOK,spr);
                        }else{
                            lSP_alts[na] = lWork[0];
                            lWork.shift();
                            //EA.adc(lWork[nAux++],spr);
                        }
                    }
                    //console.log(lSP_alts);
					//=============================================
				break;

			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		/*for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
		}*/
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}