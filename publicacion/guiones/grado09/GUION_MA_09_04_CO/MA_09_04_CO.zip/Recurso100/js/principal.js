(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titolintro']);

      

	this.text_btn4 = new cjs.Text(txt['text_btn4'], "bold 16px Arial");
	this.text_btn4.textAlign = "center";
	this.text_btn4.lineHeight = 18;
	this.text_btn4.lineWidth = 191;
	this.text_btn4.setTransform(190,450.5);

	this.text_btn3 = new cjs.Text(txt['text_btn3'], "bold 16px Arial");
	this.text_btn3.textAlign = "center";
	this.text_btn3.lineHeight = 18;
	this.text_btn3.lineWidth = 191;
	this.text_btn3.setTransform(190,368.8);

	this.text_btn2 = new cjs.Text(txt['text_btn2'], "bold 16px Arial");
	this.text_btn2.textAlign = "center";
	this.text_btn2.lineHeight = 18;
	this.text_btn2.lineWidth = 191;
	this.text_btn2.setTransform(190,289);

	this.text_btn1 = new cjs.Text(txt['text_btn1'], "bold 16px Arial");
	this.text_btn1.textAlign = "center";
	this.text_btn1.lineHeight = 18;
	this.text_btn1.lineWidth = 194;
	this.text_btn1.setTransform(190,211.3);


	this.mc_boton4 = new lib.mc_botons();
	this.mc_boton4.setTransform(181.8,458.6,1,1,0,0,0,105.4,22.6);
new cjs.ButtonHelper(this.mc_boton4, 0, 1, 2, false, new lib.btn_01(), 3);
	this.mc_boton3 = new lib.mc_botons();
	this.mc_boton3.setTransform(181.8,379.4,1,1,0,0,0,105.4,22.6);
new cjs.ButtonHelper(this.mc_boton3, 0, 1, 2, false, new lib.btn_01(), 3);

	this.mc_boton2 = new lib.mc_botons();
	this.mc_boton2.setTransform(181.8,299.7,1,1,0,0,0,105.4,22.6);
new cjs.ButtonHelper(this.mc_boton2, 0, 1, 2, false, new lib.btn_01(), 3);

	this.mc_boton1 = new lib.mc_botons();
	this.mc_boton1.setTransform(181.8,221.5,1,1,0,0,0,105.4,22.6);
new cjs.ButtonHelper(this.mc_boton1, 0, 1, 2, false, new lib.btn_01(), 3);
        
        	this.instance_1 = new lib.shutterstock_3205054();
	this.instance_1.setTransform(379.9,156.5,0.515,0.515);
        
        this.mc_boton1.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.mc_boton2.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.mc_boton3.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.mc_boton4.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });


        this.addChild(this.logo, this.titulo,  this.imagen,this.mc_boton4,this.mc_boton3,this.mc_boton2,this.mc_boton1,this.text_btn1,this.text_btn2,this.text_btn3,this.text_btn4,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_00']);
	this.instance_1 = new lib.MTB_10_06_0101();
	this.instance_1.setTransform(239,67.2,0.5,0.5);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_04']);
        texto(this,txt['treball_04'],0,0);
this.instance_1 = new lib.mc_pantalla4();
	this.instance_1.setTransform(473.6,194.1,1,1,0,0,0,386.6,38.4);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_05']);

this.instance_1 = new lib.mc_pantalla5();
	this.instance_1.setTransform(87,155.7);
        
         var html = createDiv(txt['treball_05'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 220);
    this.texto1.setTransform(100, -160);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_05_2']);

	this.instance_1 = new lib.Formulas();
	this.instance_1.setTransform(81.5,151.5,0.827,0.795);
        
   
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['titol_06'],"20px");

	this.instance_1 = new lib.MTB_10_06_0103();
	this.instance_1.setTransform(249.7,151.9,0.5,0.5);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
          this.informacion.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.informacion,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame1_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_popup_info'],0,-50,-560);

	
	this.instance_1 = new lib.shutterstock_40047505();
	this.instance_1.setTransform(328.4,376.4,0.316,0.316);
        
     
          this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
       

        this.addChild(this.logo, this.texto, this.cerrar, this.anterior,this.informacion,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_00_scn2']);
		this.instance_1 = new lib.shutterstock_79443709();
	this.instance_1.setTransform(304.8,146,0.676,0.676);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_01_scn2']);
        texto(this,txt['treball_01_scn2'],0,0);
this.texto.setTransform(100, -160);
	this.instance_1 = new lib.mc_treball_01_scn2();
	this.instance_1.setTransform(476.6,483.3,1,1,0,0,0,391.2,41.6);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_02_scn2']);

this.instance_1 = new lib.mc_treball_02_scn2();
	this.instance_1.setTransform(476.6,483.3,1,1,0,0,0,391.2,41.6);
        
       
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titol_03_scn2']);

		this.instance_1 = new lib.mc_treball_03_scn2();
	this.instance_1.setTransform(474.6,483.3,1,1,0,0,0,391.2,41.6);
        
       var html = createDiv(txt['treball_03_scn2'], "Verdana", "20px", '300px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 20);
    this.texto1.setTransform(100, -480);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
      
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_00_scn3']);
		this.instance_1 = new lib.grafica_1_scn3();
	this.instance_1.setTransform(494.7,319.8,0.55,0.55,0,0,0,474.9,419.3);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_01_scn3']);
        
	this.instance_1 = new lib.grafica_2_scn3();
	this.instance_1.setTransform(648,319.8,0.55,0.55,0,0,0,474.9,419.3);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_02_scn3']);

this.instance_1 = new lib.grafica_3_scn3();
	this.instance_1.setTransform(564,319.8,0.55,0.55,0,0,0,474.9,419.3);
        
         var html = createDiv(txt['treball_02_scn3'], "Verdana", "20px", '350px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 60);
    this.texto1.setTransform(100, -440);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
         titulo2(this, txt['titol_03_scn3']);

this.instance_1 = new lib.grafica_4_scn3();
	this.instance_1.setTransform(563,319.8,0.55,0.55,0,0,0,474.9,419.3);

        
         var html = createDiv(txt['treball_03_scn3'], "Verdana", "20px", '350px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 60);
    this.texto1.setTransform(100, -440);
        
   
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    
      (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_00_scn4']);
	this.instance_1 = new lib.MTB_10_06_0109();
	this.instance_1.setTransform(274,128.4,0.4,0.4);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_01_scn4']);
        texto(this,txt['treball_01_scn4'],0,350);
        
	this.instance_1 = new lib.mc_pantalla2_scn4();
	this.instance_1.setTransform(473.7,194.1,1,1,0,0,0,386.6,38.4);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_02_scn4']);
        texto(this,txt['treball_02_scn4'],0,400);
        
	this.instance_1 = new lib.mc_pantalla3_scn4();
	this.instance_1.setTransform(473.7,194.1,1,1,0,0,0,386.6,38.4);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto,this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_03_scn4']);

	this.instance_1 = new lib.mc_pantalla4_scn4();
	this.instance_1.setTransform(472.6,194.1,1,1,0,0,0,386.6,38.4);
        
   
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titol_04_scn4'],"20px");
  texto(this, txt['treball_04_scn4'],0,-50,-520);
	this.instance_1 = new lib.MTB_10_06_0109_2();
	this.instance_1.setTransform(275,183,0.4,0.4);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.texto,this.home, this.anterior,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '100px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }
   */
   
     
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(265, 560,1.15,1.15);
        else
            escena.informacion.setTransform(200, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(265, 560,1.15,1.15);
        else
            escena.informacion.setTransform(200, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

   //Simbolillos
   
   (lib.Path = function() {
	this.initialize(img.Path);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,128,228);


(lib.Path_1 = function() {
	this.initialize(img.Path_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,386,392);


(lib.Formula_Info = function() {
	this.initialize(img.Formula_Info);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,182,110);


(lib.Formula_p7 = function() {
	this.initialize(img.Formula_p7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,406,74);


(lib.Formulas = function() {
	this.initialize(img.Formulas);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,469);


(lib.maraton = function() {
	this.initialize(img.maraton);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,580,391);


(lib.MTB_10_01_051 = function() {
	this.initialize(img.MTB_10_01_051);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,50);


(lib.MTB_10_01_052 = function() {
	this.initialize(img.MTB_10_01_052);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,50);


(lib.MTB_10_01_054 = function() {
	this.initialize(img.MTB_10_01_054);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,50);


(lib.MTB_10_06_0101 = function() {
	this.initialize(img.MTB_10_06_0101);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.MTB_10_06_0102 = function() {
	this.initialize(img.MTB_10_06_0102);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.MTB_10_06_0103 = function() {
	this.initialize(img.MTB_10_06_0103);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.MTB_10_06_0109 = function() {
	this.initialize(img.MTB_10_06_0109);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.MTB_10_06_0109_2 = function() {
	this.initialize(img.MTB_10_06_0109_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.n = function() {
	this.initialize(img.n);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,19,34);



(lib.practica_01 = function() {
	this.initialize(img.practica_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,91,75);


(lib.practica_02 = function() {
	this.initialize(img.practica_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,91,74);


(lib.practica_03 = function() {
	this.initialize(img.practica_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,94,99);


(lib.practica_04 = function() {
	this.initialize(img.practica_04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,91,74);


(lib.shutterstock_2127301 = function() {
	this.initialize(img.shutterstock_2127301);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,633);


(lib.shutterstock_2127301_2 = function() {
	this.initialize(img.shutterstock_2127301_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,469);


(lib.shutterstock_31082494 = function() {
	this.initialize(img.shutterstock_31082494);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,713);


(lib.shutterstock_3205054 = function() {
	this.initialize(img.shutterstock_3205054);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,713);


(lib.shutterstock_32860192 = function() {
	this.initialize(img.shutterstock_32860192);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1202,802);


(lib.shutterstock_38944744 = function() {
	this.initialize(img.shutterstock_38944744);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,631);


(lib.shutterstock_40047505 = function() {
	this.initialize(img.shutterstock_40047505);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,634);


(lib.shutterstock_64481368 = function() {
	this.initialize(img.shutterstock_64481368);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1125,750);


(lib.shutterstock_79443709 = function() {
	this.initialize(img.shutterstock_79443709);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,588,611);


(lib.shutterstock_85710800 = function() {
	this.initialize(img.shutterstock_85710800);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,656);


(lib.Tecla_247 = function() {
	this.initialize(img.Tecla_247);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,74);


(lib.Tecla_5 = function() {
	this.initialize(img.Tecla_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,74);


(lib.Tecla_Formula = function() {
	this.initialize(img.Tecla_Formula);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,80);


(lib.Tecla_Igual = function() {
	this.initialize(img.Tecla_Igual);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,73);



(lib.punts_vermells = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABZAAQAAAkgaAZQgbAagkAAQgjAAgbgaQgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjg");
	this.shape.setTransform(331.3,136);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_1.setTransform(331.3,136);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2.4,0,0,4).p("AA/g9QAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgaQgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZg");
	this.shape_2.setTransform(230.1,136);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_3.setTransform(230.1,136);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape_4.setTransform(8.9,8.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_5.setTransform(8.9,8.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_6.setTransform(331.3,136);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_7.setTransform(230.1,136);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_8.setTransform(8.9,8.8);

	this.addChild(this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,340.2,144.8);


(lib.grafica_4_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape.setTransform(692.8,620.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_1.setTransform(692.8,620.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_2.setTransform(692.8,620.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape_3.setTransform(591.9,620.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_4.setTransform(591.9,620.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_5.setTransform(591.9,620.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape_6.setTransform(345.5,620.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_7.setTransform(345.5,620.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_8.setTransform(345.5,620.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(80));

	// mascra_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_49 = new cjs.Graphics().p("Egz/ACHQgmAAgbgbQgagaAAgmIAAhXQAAglAagcQAbgaAmAAMBoAAAAQAlAAAbAaQAbAcAAAlIAABXQAAAmgbAaQgbAbglAAg");
	var mask_graphics_50 = new cjs.Graphics().p("Egz/ADoQgmAAgbguQgaguAAhAIAAiXQAAg/AagvQAbguAmAAMBoAAAAQAlAAAbAuQAbAvAAA/IAACXQAABAgbAuQgbAuglAAg");
	var mask_graphics_51 = new cjs.Graphics().p("Egz/AFJQgmAAgbhCQgahAAAhbIAAjXQAAhaAahCQAbhBAmAAMBoAAAAQAlAAAbBBQAbBCAABaIAADXQAABbgbBAQgbBCglAAg");
	var mask_graphics_52 = new cjs.Graphics().p("Egz/AGqQgmAAgbhVQgahUAAh2IAAkVQAAh1AahWQAbhUAmAAMBoAAAAQAlAAAbBUQAbBWAAB1IAAEVQAAB2gbBUQgbBVglAAg");
	var mask_graphics_53 = new cjs.Graphics().p("Egz/AILQgmAAgbhpQgahmAAiRIAAlVQAAiPAahqQAbhnAmAAMBoAAAAQAlAAAbBnQAbBqAACPIAAFVQAACRgbBmQgbBpglAAg");
	var mask_graphics_54 = new cjs.Graphics().p("Egz/AJrQgmAAgbh7Qgah5AAisIAAmVQAAipAah+QAbh5AmAAMBoAAAAQAlAAAbB5QAbB+AACpIAAGVQAACsgbB5QgbB7glAAg");
	var mask_graphics_55 = new cjs.Graphics().p("Egz/ALMQgmAAgbiOQgaiNAAjGIAAnVQAAjEAaiRQAbiMAmAAMBoAAAAQAlAAAbCMQAbCRAADEIAAHVQAADGgbCNQgbCOglAAg");
	var mask_graphics_56 = new cjs.Graphics().p("Egz/AMtQgmAAgbiiQgaifAAjhIAAoVQAAjeAailQAbifAmAAMBoAAAAQAlAAAbCfQAbClAADeIAAIVQAADhgbCfQgbCiglAAg");
	var mask_graphics_57 = new cjs.Graphics().p("Egz/AOOQgmAAgbi1QgaiyAAj8IAApUQAAj5Aai5QAbiyAmAAMBoAAAAQAlAAAbCyQAbC5AAD5IAAJUQAAD8gbCyQgbC1glAAg");
	var mask_graphics_58 = new cjs.Graphics().p("Egz/APvQgmAAgbjJQgajFAAkXIAAqTQAAkTAajNQAbjFAmAAMBoAAAAQAlAAAbDFQAbDNAAETIAAKTQAAEXgbDFQgbDJglAAg");
	var mask_graphics_59 = new cjs.Graphics().p("Egz/ARQQgmAAgbjcQgajYAAkyIAArTQAAkuAajgQAbjYAmAAMBoAAAAQAlAAAbDYQAbDgAAEuIAALTQAAEygbDYQgbDcglAAg");
	var mask_graphics_60 = new cjs.Graphics().p("Egz/ASxQgmAAgbjvQgajrAAlNIAAsTQAAlIAaj0QAbjrAmAAMBoAAAAQAlAAAbDrQAbD0AAFIIAAMTQAAFNgbDrQgbDvglAAg");
	var mask_graphics_61 = new cjs.Graphics().p("Egz/AUSQgmAAgbkDQgaj+AAlnIAAtTQAAliAakIQAbj+AmAAMBoAAAAQAlAAAbD+QAbEIAAFiIAANTQAAFngbD+QgbEDglAAg");
	var mask_graphics_62 = new cjs.Graphics().p("Egz/AVzQgmAAgbkWQgakRAAmCIAAuTQAAl9AakbQAbkRAmAAMBoAAAAQAlAAAbERQAbEbAAF9IAAOTQAAGCgbERQgbEWglAAg");
	var mask_graphics_63 = new cjs.Graphics().p("Egz/AXTQgmAAgbkpQgakkAAmcIAAvSQAAmYAakvQAbkjAmAAMBoAAAAQAlAAAbEjQAbEvAAGYIAAPSQAAGcgbEkQgbEpglAAg");
	var mask_graphics_64 = new cjs.Graphics().p("Egz/AY0QgmAAgbk8Qgak3AAm4IAAwRQAAmyAalDQAbk2AmAAMBoAAAAQAlAAAbE2QAbFDAAGyIAAQRQAAG4gbE3QgbE8glAAg");
	var mask_graphics_65 = new cjs.Graphics().p("Egz/AaVQgmAAgblQQgalJAAnTIAAxRQAAnMAalXQAblJAmAAMBoAAAAQAlAAAbFJQAbFXAAHMIAARRQAAHTgbFJQgbFQglAAg");
	var mask_graphics_66 = new cjs.Graphics().p("Egz/Ab2QgmAAgbljQgaldAAntIAAyRQAAnnAalqQAblcAmAAMBoAAAAQAlAAAbFcQAbFqAAHnIAASRQAAHtgbFdQgbFjglAAg");
	var mask_graphics_67 = new cjs.Graphics().p("Egz/AdXQgmAAgbl2QgalwAAoIIAAzRQAAoBAal9QAblwAmAAMBoAAAAQAlAAAbFwQAbF9AAIBIAATRQAAIIgbFwQgbF2glAAg");
	var mask_graphics_68 = new cjs.Graphics().p("Egz/Ae4QgmAAgbmKQgamCAAojIAA0QQAAocAamRQAbmDAmAAMBoAAAAQAlAAAbGDQAbGRAAIcIAAUQQAAIjgbGCQgbGKglAAg");
	var mask_graphics_69 = new cjs.Graphics().p("Egz/AgZQgmAAgbmdQgamWAAo+IAA1PQAAo3AamkQAbmWAmAAMBoAAAAQAlAAAbGWQAbGkAAI3IAAVPQAAI+gbGWQgbGdglAAg");
	var mask_graphics_70 = new cjs.Graphics().p("Egz/Ah6QgmAAgbmxQgamoAApZIAA2PQAApRAam4QAbmpAmAAMBoAAAAQAlAAAbGpQAbG4AAJRIAAWPQAAJZgbGoQgbGxglAAg");
	var mask_graphics_71 = new cjs.Graphics().p("Egz/AjbQgmAAgbnEQgam7AAp0IAA3PQAAprAanMQAbm8AmAAMBoAAAAQAlAAAbG8QAbHMAAJrIAAXPQAAJ0gbG7QgbHEglAAg");
	var mask_graphics_72 = new cjs.Graphics().p("Egz/Ak8QgmAAgbnXQganPAAqOIAA4PQAAqFAangQAbnPAmAAMBoAAAAQAlAAAbHPQAbHgAAKFIAAYPQAAKOgbHPQgbHXglAAg");
	var mask_graphics_73 = new cjs.Graphics().p("Egz/AmcQgmAAgbnqQganhAAqpIAA5OQAAqhAanzQAbnhAmAAMBoAAAAQAlAAAbHhQAbHzAAKhIAAZOQAAKpgbHhQgbHqglAAg");
	var mask_graphics_74 = new cjs.Graphics().p("Egz/An9QgmAAgbn9Qgan0AArEIAA6OQAAq7AaoHQAbn0AmAAMBoAAAAQAlAAAbH0QAbIHAAK7IAAaOQAALEgbH0QgbH9glAAg");
	var mask_graphics_75 = new cjs.Graphics().p("Egz/ApeQgmAAgboRQgaoHAArfIAA7NQAArVAaobQAboHAmAAMBoAAAAQAlAAAbIHQAbIbAALVIAAbNQAALfgbIHQgbIRglAAg");
	var mask_graphics_76 = new cjs.Graphics().p("Egz/Aq/QgmAAgbokQgaoaAAr6IAA8NQAArvAaovQAboaAmAAMBoAAAAQAlAAAbIaQAbIvAALvIAAcNQAAL6gbIaQgbIkglAAg");
	var mask_graphics_77 = new cjs.Graphics().p("Egz/AsgQgmAAgbo3QgaouAAsUIAA9NQAAsKAapCQAbotAmAAMBoAAAAQAlAAAbItQAbJCAAMKIAAdNQAAMUgbIuQgbI3glAAg");
	var mask_graphics_78 = new cjs.Graphics().p("Egz/AuBQgmAAgbpLQgapAAAsvIAA+MQAAslAapWQAbpAAmAAMBoAAAAQAlAAAbJAQAbJWAAMlIAAeMQAAMvgbJAQgbJLglAAg");
	var mask_graphics_79 = new cjs.Graphics().p("Egz/AviQgmAAgbpeQgapTAAtKIAA/MQAAs/AapqQAbpTAmAAMBoAAAAQAlAAAbJTQAbJqAAM/IAAfMQAANKgbJTQgbJeglAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(49).to({graphics:mask_graphics_49,x:-137.8,y:87.8}).wait(1).to({graphics:mask_graphics_50,x:-137.8,y:97.5}).wait(1).to({graphics:mask_graphics_51,x:-137.8,y:107.2}).wait(1).to({graphics:mask_graphics_52,x:-137.8,y:116.9}).wait(1).to({graphics:mask_graphics_53,x:-137.8,y:126.6}).wait(1).to({graphics:mask_graphics_54,x:-137.8,y:136.2}).wait(1).to({graphics:mask_graphics_55,x:-137.8,y:145.9}).wait(1).to({graphics:mask_graphics_56,x:-137.8,y:155.6}).wait(1).to({graphics:mask_graphics_57,x:-137.8,y:165.3}).wait(1).to({graphics:mask_graphics_58,x:-137.8,y:175}).wait(1).to({graphics:mask_graphics_59,x:-137.8,y:184.7}).wait(1).to({graphics:mask_graphics_60,x:-137.8,y:194.4}).wait(1).to({graphics:mask_graphics_61,x:-137.8,y:204.1}).wait(1).to({graphics:mask_graphics_62,x:-137.8,y:213.8}).wait(1).to({graphics:mask_graphics_63,x:-137.8,y:223.4}).wait(1).to({graphics:mask_graphics_64,x:-137.8,y:233.1}).wait(1).to({graphics:mask_graphics_65,x:-137.8,y:242.8}).wait(1).to({graphics:mask_graphics_66,x:-137.8,y:252.5}).wait(1).to({graphics:mask_graphics_67,x:-137.8,y:262.2}).wait(1).to({graphics:mask_graphics_68,x:-137.8,y:271.9}).wait(1).to({graphics:mask_graphics_69,x:-137.8,y:281.6}).wait(1).to({graphics:mask_graphics_70,x:-137.8,y:291.3}).wait(1).to({graphics:mask_graphics_71,x:-137.8,y:301}).wait(1).to({graphics:mask_graphics_72,x:-137.8,y:310.7}).wait(1).to({graphics:mask_graphics_73,x:-137.8,y:320.3}).wait(1).to({graphics:mask_graphics_74,x:-137.8,y:330}).wait(1).to({graphics:mask_graphics_75,x:-137.8,y:339.7}).wait(1).to({graphics:mask_graphics_76,x:-137.8,y:349.4}).wait(1).to({graphics:mask_graphics_77,x:-137.8,y:359.1}).wait(1).to({graphics:mask_graphics_78,x:-137.8,y:368.8}).wait(1).to({graphics:mask_graphics_79,x:-137.8,y:378.5}).wait(1));

	// text
	this.treball_03_scn3 = new cjs.Text("", "35px Verdana");
	this.treball_03_scn3.lineHeight = 40;
	this.treball_03_scn3.lineWidth = 544;
	this.treball_03_scn3.setTransform(-400.2,102.3);

	this.treball_03_scn3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.treball_03_scn3}]},49).wait(31));

	// grafica
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#3700D6").ss(5.2,0,0,4).p("EgjuA4zQAVjFAbjvQBqulCAsKQC0xADHptQD5sJEIAAQEBAAEjISQB1DVCNFIQBaDSCiGcQCqG3BNC4QCLFMBxDTQEZISDxAAQE8AAEfwkQDmtQDJ3JQCQwkBzz3QAOigANiS");
	this.shape_9.setTransform(552.1,439.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9}]}).wait(80));

	// Capa 1
	this.text = new cjs.Text("X", "36px Verdana");
	this.text.lineHeight = 43;
	this.text.setTransform(1008,633.9);

	this.text_1 = new cjs.Text("Y", "36px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.setTransform(390.2,111.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(4,0,0,4).p("EhKLAAAMCUXAAA");
	this.shape_10.setTransform(591.9,620.4,0.925,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(4.2,0,0,4).p("EAAABBhMAAAiDB");
	this.shape_11.setTransform(371.4,457,1,0.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.text_1},{t:this.text}]}).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(323.4,76.1,709.3,727.2);


(lib.grafica_3_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape.setTransform(371.3,491.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_1.setTransform(371.3,491.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_2.setTransform(371.3,491.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(80));

	// mascra_text (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_49 = new cjs.Graphics().p("Eg0DACIQgogBgegbQgcgaAAglIAAhYQAAgmAcgbQAegaAoAAMBoHAAAQAoAAAdAaQAdAbAAAmIAABYQAAAlgdAaQgdAbgoABg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg0CADjQgoAAgeguQgcgrAAg/IAAiVQAAg/AcgtQAegsAoAAMBoFAAAQAoAAAdAsQAdAtAAA/IAACVQAAA/gdArQgdAugoAAg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg0BAE/QgoAAgdhBQgcg9AAhYIAAjRQAAhYAchAQAdg+AoAAMBoDAAAQAoAAAdA+QAdBAAABYIAADRQAABYgdA9QgdBBgoAAg");
	var mask_graphics_52 = new cjs.Graphics().p("Egz/AGbQgpAAgdhUQgchOAAhxIAAkPQAAhxAchSQAdhQApAAMBn/AAAQApAAAcBQQAdBSAABxIAAEPQAABxgdBOQgcBUgpAAg");
	var mask_graphics_53 = new cjs.Graphics().p("Egz+AH2QgpAAgdhlQgchgAAiLIAAlLQAAiLAchjQAdhiApAAMBn9AAAQApAAAcBiQAdBjAACLIAAFLQAACLgdBgQgcBlgpAAg");
	var mask_graphics_54 = new cjs.Graphics().p("Egz9AJSQgpAAgdh4QgchyAAikIAAmHQAAikAch2QAdh0ApAAMBn7AAAQApAAAcB0QAdB2AACkIAAGHQAACkgdByQgcB4gpAAg");
	var mask_graphics_55 = new cjs.Graphics().p("Egz8AKuQgpAAgdiLQgciDAAi9IAAnFQAAi9AciIQAdiGApAAMBn5AAAQApAAAcCGQAdCIAAC9IAAHFQAAC9gdCDQgcCLgpAAg");
	var mask_graphics_56 = new cjs.Graphics().p("Egz7AMKQgoAAgeieQgciVAAjWIAAoBQAAjWAcibQAeiYAoAAMBn3AAAQAoAAAdCYQAdCbAADWIAAIBQAADWgdCVQgdCegoAAg");
	var mask_graphics_57 = new cjs.Graphics().p("Egz6ANlQgoAAgeiwQgcimAAjwIAAo9QAAjwAcitQAeipAoAAMBn1AAAQAoAAAdCpQAdCtAADwIAAI9QAADwgdCmQgdCwgoAAg");
	var mask_graphics_58 = new cjs.Graphics().p("Egz5APBQgoAAgejCQgci4AAkJIAAp7QAAkJAci/QAei7AoAAMBnzAAAQAoAAAdC7QAdC/AAEJIAAJ7QAAEJgdC4QgdDCgoAAg");
	var mask_graphics_59 = new cjs.Graphics().p("Egz4AQdQgoAAgdjVQgcjKAAkiIAAq3QAAkiAcjRQAdjOAoAAMBnxAAAQAoAAAdDOQAdDRAAEiIAAK3QAAEigdDKQgdDVgoAAg");
	var mask_graphics_60 = new cjs.Graphics().p("Egz3AR4QgoAAgdjnQgcjbAAk8IAArzQAAk8AcjjQAdjfAoAAMBnvAAAQAoAAAdDfQAcDjAAE8IAALzQAAE8gcDbQgdDngoAAg");
	var mask_graphics_61 = new cjs.Graphics().p("Egz2ATUQgoAAgdj6QgcjsAAlVIAAsxQAAlVAcj1QAdjxAoAAMBntAAAQAoAAAcDxQAdD1AAFVIAAMxQAAFVgdDsQgcD6goAAg");
	var mask_graphics_62 = new cjs.Graphics().p("Egz1AUwQgoAAgdkNQgcj+AAluIAAttQAAluAckIQAdkDAoAAMBnrAAAQAoAAAcEDQAdEIAAFuIAANtQAAFugdD+QgcENgoAAg");
	var mask_graphics_63 = new cjs.Graphics().p("EgzzAWMQgpAAgdkgQgckPAAmIIAAupQAAmIAckaQAdkVApAAMBnnAAAQApAAAcEVQAdEaAAGIIAAOpQAAGIgdEPQgcEggpAAg");
	var mask_graphics_64 = new cjs.Graphics().p("EgzyAXnQgpAAgdkxQgckiAAmgIAAvnQAAmhAcksQAdkmApAAMBnlAAAQApAAAcEmQAdEsAAGhIAAPnQAAGggdEiQgcExgpAAg");
	var mask_graphics_65 = new cjs.Graphics().p("EgzxAZDQgpAAgdlEQgckzAAm6IAAwjQAAm6Ack/QAdk4ApAAMBnjAAAQApAAAcE4QAdE/AAG6IAAQjQAAG6gdEzQgcFEgpAAg");
	var mask_graphics_66 = new cjs.Graphics().p("EgzwAafQgoAAgelXQgclEAAnUIAAxfQAAnUAclQQAelLAoAAMBnhAAAQAoAAAdFLQAdFQAAHUIAARfQAAHUgdFEQgdFXgoAAg");
	var mask_graphics_67 = new cjs.Graphics().p("EgzvAb6QgoAAgdlpQgclWAAnsIAAydQAAnsAcljQAdlcAoAAMBnfAAAQAoAAAdFcQAdFjAAHsIAASdQAAHsgdFWQgdFpgoAAg");
	var mask_graphics_68 = new cjs.Graphics().p("EgzuAdWQgoAAgdl8QgclnAAoGIAAzZQAAoGAcl1QAdluAoAAMBndAAAQAoAAAdFuQAcF1AAIGIAATZQAAIGgcFnQgdF8goAAg");
	var mask_graphics_69 = new cjs.Graphics().p("EgztAeyQgoAAgdmPQgcl4AAogIAA0WQAAofAcmHQAdmAAoAAMBnbAAAQAoAAAdGAQAcGHAAIfIAAUWQAAIggcF4QgdGPgoAAg");
	var mask_graphics_70 = new cjs.Graphics().p("EgzsAgOQgoAAgdmiQgcmKAAo4IAA1TQAAo4AcmaQAdmSAoAAMBnZAAAQAoAAAcGSQAdGaAAI4IAAVTQAAI4gdGKQgcGigoAAg");
	var mask_graphics_71 = new cjs.Graphics().p("EgzrAhpQgoAAgdmzQgcmcAApSIAA2PQAApSAcmsQAdmjAoAAMBnXAAAQAoAAAcGjQAdGsAAJSIAAWPQAAJSgdGcQgcGzgoAAg");
	var mask_graphics_72 = new cjs.Graphics().p("EgzqAjFQgoAAgdnGQgcmtAAprIAA3NQAAprAcm+QAdm1AoAAMBnVAAAQAoAAAcG1QAdG+AAJrIAAXNQAAJrgdGtQgcHGgoAAg");
	var mask_graphics_73 = new cjs.Graphics().p("EgzpAkhQgoAAgdnZQgcm/AAqEIAA4JQAAqEAcnQQAdnIAoAAMBnTAAAQAoAAAcHIQAdHQAAKEIAAYJQAAKEgdG/QgcHZgoAAg");
	var mask_graphics_74 = new cjs.Graphics().p("EgznAl8QgpAAgdnrQgcnQAAqeIAA5FQAAqeAcniQAdnZApAAMBnPAAAQApAAAcHZQAdHiAAKeIAAZFQAAKegdHQQgcHrgpAAg");
	var mask_graphics_75 = new cjs.Graphics().p("EgzmAnYQgoAAgdn+QgcniAAq2IAA6DQAAq2Acn1QAdnrAoAAMBnNAAAQAoAAAdHrQAdH1AAK2IAAaDQAAK2gdHiQgdH+goAAg");
	var mask_graphics_76 = new cjs.Graphics().p("EgzlAo0QgoAAgdoRQgcnzAArQIAA6/QAArQAcoHQAdn9AoAAMBnLAAAQAoAAAdH9QAcIHAALQIAAa/QAALQgcHzQgdIRgoAAg");
	var mask_graphics_77 = new cjs.Graphics().p("EgzkAqQQgoAAgdojQgcoFAArqIAA77QAArqAcoZQAdoPAoAAMBnJAAAQAoAAAdIPQAcIZAALqIAAb7QAALqgcIFQgdIjgoAAg");
	var mask_graphics_78 = new cjs.Graphics().p("EgzjArrQgoAAgdo1QgcoXAAsCIAA85QAAsCAcosQAdogAoAAMBnHAAAQAoAAAdIgQAcIsAAMCIAAc5QAAMCgcIXQgdI1goAAg");
	var mask_graphics_79 = new cjs.Graphics().p("EgziAtHQgoAAgdpIQgcooAAscIAA91QAAscAco9QAdozAoAAMBnFAAAQAoAAAdIzQAcI9AAMcIAAd1QAAMcgcIoQgdJIgoAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(49).to({graphics:mask_graphics_49,x:-92.2,y:84}).wait(1).to({graphics:mask_graphics_50,x:-92.3,y:93.1}).wait(1).to({graphics:mask_graphics_51,x:-92.5,y:102.3}).wait(1).to({graphics:mask_graphics_52,x:-92.6,y:111.5}).wait(1).to({graphics:mask_graphics_53,x:-92.7,y:120.6}).wait(1).to({graphics:mask_graphics_54,x:-92.8,y:129.8}).wait(1).to({graphics:mask_graphics_55,x:-92.9,y:139}).wait(1).to({graphics:mask_graphics_56,x:-93,y:148.2}).wait(1).to({graphics:mask_graphics_57,x:-93.1,y:157.3}).wait(1).to({graphics:mask_graphics_58,x:-93.2,y:166.5}).wait(1).to({graphics:mask_graphics_59,x:-93.4,y:175.7}).wait(1).to({graphics:mask_graphics_60,x:-93.5,y:184.8}).wait(1).to({graphics:mask_graphics_61,x:-93.6,y:194}).wait(1).to({graphics:mask_graphics_62,x:-93.7,y:203.2}).wait(1).to({graphics:mask_graphics_63,x:-93.8,y:212.4}).wait(1).to({graphics:mask_graphics_64,x:-93.9,y:221.5}).wait(1).to({graphics:mask_graphics_65,x:-94,y:230.7}).wait(1).to({graphics:mask_graphics_66,x:-94.1,y:239.9}).wait(1).to({graphics:mask_graphics_67,x:-94.3,y:249}).wait(1).to({graphics:mask_graphics_68,x:-94.4,y:258.2}).wait(1).to({graphics:mask_graphics_69,x:-94.5,y:267.4}).wait(1).to({graphics:mask_graphics_70,x:-94.6,y:276.6}).wait(1).to({graphics:mask_graphics_71,x:-94.7,y:285.7}).wait(1).to({graphics:mask_graphics_72,x:-94.8,y:294.9}).wait(1).to({graphics:mask_graphics_73,x:-94.9,y:304.1}).wait(1).to({graphics:mask_graphics_74,x:-95,y:313.2}).wait(1).to({graphics:mask_graphics_75,x:-95.2,y:322.4}).wait(1).to({graphics:mask_graphics_76,x:-95.3,y:331.6}).wait(1).to({graphics:mask_graphics_77,x:-95.4,y:340.8}).wait(1).to({graphics:mask_graphics_78,x:-95.5,y:349.9}).wait(1).to({graphics:mask_graphics_79,x:-95.6,y:359.1}).wait(1));

	// text
	this.treball_02_scn3 = new cjs.Text("", "35px Verdana");
	this.treball_02_scn3.lineHeight = 40;
	this.treball_02_scn3.lineWidth = 622;
	this.treball_02_scn3.setTransform(-399,114.9);

	this.treball_02_scn3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.treball_02_scn3}]},49).wait(31));

	// grafica
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#3700D6").ss(5.2,0,0,4).p("EgjuA4zQAVjFAbjvQBqulCAsKQC0xADHptQD5sJEIAAQEBAAEjISQB1DVCNFIQBaDSCiGcQCqG3BNC4QCLFMBxDTQEZISDxAAQE8AAEfwkQDmtQDJ3JQCQwkBzz3QAOigANiS");
	this.shape_3.setTransform(552.1,439.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3}]}).wait(80));

	// Capa 1
	this.text = new cjs.Text("X", "36px Verdana");
	this.text.lineHeight = 43;
	this.text.setTransform(1008,633.9);

	this.text_1 = new cjs.Text("Y", "36px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.setTransform(390.2,111.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(4,0,0,4).p("EhKLAAAMCUXAAA");
	this.shape_4.setTransform(591.9,620.4,0.925,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(4.2,0,0,4).p("EAAABBhMAAAiDB");
	this.shape_5.setTransform(371.4,457,1,0.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.text_1},{t:this.text}]}).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(323.4,76.1,709.3,727.2);


(lib.grafica_1_scn3 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAaQgaAagkAAQgkAAgagaQgagaAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjg");
	this.shape.setTransform(218.1,623.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ag9A9QgagZAAgkQAAgjAagaQAagZAjAAQAlAAAaAZQAaAaAAAjQAAAkgaAZQgaAaglAAQgjAAgagag");
	this.shape_1.setTransform(218.1,623.1);

	this.text = new cjs.Text("X", "36px Verdana");
	this.text.lineHeight = 43;
	this.text.setTransform(855.2,633.9);

	this.text_1 = new cjs.Text("Y", "36px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.setTransform(237.4,111.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhKLAAAMCUXAAA");
	this.shape_2.setTransform(439.2,620.4,0.925,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4.2,0,0,4).p("EAAABBhMAAAiDB");
	this.shape_3.setTransform(218.7,457,1,0.825);

	this.addChild(this.shape_3,this.shape_2,this.text_1,this.text,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(209.2,111.5,670.7,557.3);


(lib.flecha_verda = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#009933").ss(2,0,0,3.9).p("AOlhPIBABKIg7BWAvxgFIfWAA");
	this.shape.setTransform(101.1,8.1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,200.9,16.2);

(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,206);


(lib.mc_treball_03_scn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// puntos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4.5,0,0,4).p("AAAilQBHAAAyAxQAyAxAABDQAABEgyAxQgyAxhHAAQhFAAgygxQgygxAAhEQAAhDAygxQAygxBFAAg");
	this.shape.setTransform(508.9,-146.7,0.384,0.384);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ah4B1QgygxAAhEQAAhDAygxQAzgxBFAAQBHAAAyAxQAyAxgBBDQABBEgyAxQgyAxhHAAQhFAAgzgxg");
	this.shape_1.setTransform(508.9,-146.7,0.384,0.384);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4.5,0,0,4).p("ACqAAQAABFgyAxQgxAwhHAAQhFAAgygwQgygxAAhFQAAhDAygxQAygxBFAAQBHAAAxAxQAyAxAABDg");
	this.shape_2.setTransform(508.7,-229.5,0.384,0.384);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF001A").s().p("Ah3B2QgygxAAhFQAAhEAygwQAygxBFAAQBHAAAxAxQAyAwAABEQAABFgyAxQgxAwhHAAQhFAAgygwg");
	this.shape_3.setTransform(508.7,-229.5,0.384,0.384);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(4.5,0,0,4).p("AAAilQBHAAAyAxQAyAxAABDQAABEgyAxQgyAxhHAAQhFAAgygxQgygxAAhEQAAhDAygxQAygxBFAAg");
	this.shape_4.setTransform(508.1,-64.5,0.384,0.384);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF001A").s().p("Ah3B1QgzgxAAhEQAAhDAzgxQAxgxBGAAQBGAAAzAxQAxAxAABDQAABEgxAxQgzAxhGAAQhGAAgxgxg");
	this.shape_5.setTransform(508.1,-64.5,0.384,0.384);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},63).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},37).wait(100));

	// GRAFICA 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#7100D6").ss(2,0,0,4).p("A6wuWQBxAPCqAcQFTA3EcBEQGOBfDpBoQEgCCANCKQANCNhWBYQhIBHiUAnQhvAdi0AOQjEALhSAHQjfAVh3CFQgxA3gZBFQgXA+gBA/QgCCpB1BkQBcBPChAfQDWAqCxgoQDOgvC+ijQC0idDZlbQCvkWCBkeQBajHBPhdQBghxBwAAQBZABBMCCQBVCQBGEyQA9EIBHB9QBRCQB6AQ");
	this.shape_6.setTransform(579.3,-156);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6}]}).wait(200));

	// GRAFICA 2
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(506.6,-249.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},85).wait(115));

	// mascra_grafica_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_121 = new cjs.Graphics().p("A2ZEDIAAoGMAs0AAAIAAIGg");
	var mask_graphics_122 = new cjs.Graphics().p("A2ZE6IAApzMAs0AAAIAAJzg");
	var mask_graphics_123 = new cjs.Graphics().p("A2ZFxIAArhMAs0AAAIAALhg");
	var mask_graphics_124 = new cjs.Graphics().p("A2ZGoIAAtPMAs0AAAIAANPg");
	var mask_graphics_125 = new cjs.Graphics().p("A2ZHfIAAu9MAs0AAAIAAO9g");
	var mask_graphics_126 = new cjs.Graphics().p("A2ZIVIAAwpMAs0AAAIAAQpg");
	var mask_graphics_127 = new cjs.Graphics().p("A2ZJMIAAyXMAs0AAAIAASXg");
	var mask_graphics_128 = new cjs.Graphics().p("A2ZKDIAA0FMAs0AAAIAAUFg");
	var mask_graphics_129 = new cjs.Graphics().p("A2ZK6IAA1zMAs0AAAIAAVzg");
	var mask_graphics_130 = new cjs.Graphics().p("A2ZLxIAA3hMAs0AAAIAAXhg");
	var mask_graphics_131 = new cjs.Graphics().p("A2ZMnIAA5NMAs0AAAIAAZNg");
	var mask_graphics_132 = new cjs.Graphics().p("A2ZNeIAA67MAs0AAAIAAa7g");
	var mask_graphics_133 = new cjs.Graphics().p("A2ZOVIAA8pMAs0AAAIAAcpg");
	var mask_graphics_134 = new cjs.Graphics().p("A2ZPMIAA+XMAs0AAAIAAeXg");
	var mask_graphics_135 = new cjs.Graphics().p("A2ZQDMAAAggFMAs0AAAMAAAAgFg");
	var mask_graphics_136 = new cjs.Graphics().p("A2ZQ5MAAAghxMAs0AAAMAAAAhxg");
	var mask_graphics_137 = new cjs.Graphics().p("A2ZRwMAAAgjfMAs0AAAMAAAAjfg");
	var mask_graphics_138 = new cjs.Graphics().p("A2ZSnMAAAglNMAs0AAAMAAAAlNg");
	var mask_graphics_139 = new cjs.Graphics().p("A2ZTeMAAAgm7MAs0AAAMAAAAm7g");
	var mask_graphics_140 = new cjs.Graphics().p("A2ZUVMAAAgopMAs0AAAMAAAAopg");
	var mask_graphics_141 = new cjs.Graphics().p("A2ZVLMAAAgqVMAs0AAAMAAAAqVg");
	var mask_graphics_142 = new cjs.Graphics().p("A2ZWCMAAAgsDMAs0AAAMAAAAsDg");
	var mask_graphics_143 = new cjs.Graphics().p("A2ZW5MAAAgtxMAs0AAAMAAAAtxg");
	var mask_graphics_144 = new cjs.Graphics().p("A2ZXwMAAAgvfMAs0AAAMAAAAvfg");
	var mask_graphics_145 = new cjs.Graphics().p("A2ZYnMAAAgxNMAs0AAAMAAAAxNg");
	var mask_graphics_146 = new cjs.Graphics().p("A2ZZdMAAAgy5MAs0AAAMAAAAy5g");
	var mask_graphics_147 = new cjs.Graphics().p("A2ZaUMAAAg0nMAs0AAAMAAAA0ng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(121).to({graphics:mask_graphics_121,x:617.5,y:61.3}).wait(1).to({graphics:mask_graphics_122,x:617.5,y:55.8}).wait(1).to({graphics:mask_graphics_123,x:617.5,y:50.3}).wait(1).to({graphics:mask_graphics_124,x:617.5,y:44.9}).wait(1).to({graphics:mask_graphics_125,x:617.5,y:39.4}).wait(1).to({graphics:mask_graphics_126,x:617.5,y:33.9}).wait(1).to({graphics:mask_graphics_127,x:617.5,y:28.4}).wait(1).to({graphics:mask_graphics_128,x:617.5,y:22.9}).wait(1).to({graphics:mask_graphics_129,x:617.5,y:17.5}).wait(1).to({graphics:mask_graphics_130,x:617.5,y:12}).wait(1).to({graphics:mask_graphics_131,x:617.5,y:6.5}).wait(1).to({graphics:mask_graphics_132,x:617.5,y:1}).wait(1).to({graphics:mask_graphics_133,x:617.5,y:-4.4}).wait(1).to({graphics:mask_graphics_134,x:617.5,y:-9.8}).wait(1).to({graphics:mask_graphics_135,x:617.5,y:-15.3}).wait(1).to({graphics:mask_graphics_136,x:617.5,y:-20.8}).wait(1).to({graphics:mask_graphics_137,x:617.5,y:-26.3}).wait(1).to({graphics:mask_graphics_138,x:617.5,y:-31.8}).wait(1).to({graphics:mask_graphics_139,x:617.5,y:-37.2}).wait(1).to({graphics:mask_graphics_140,x:617.5,y:-42.7}).wait(1).to({graphics:mask_graphics_141,x:617.5,y:-48.2}).wait(1).to({graphics:mask_graphics_142,x:617.5,y:-53.7}).wait(1).to({graphics:mask_graphics_143,x:617.5,y:-59.2}).wait(1).to({graphics:mask_graphics_144,x:617.5,y:-64.6}).wait(1).to({graphics:mask_graphics_145,x:617.5,y:-70.1}).wait(1).to({graphics:mask_graphics_146,x:617.5,y:-75.6}).wait(1).to({graphics:mask_graphics_147,x:617.5,y:-81.1}).wait(53));

	// GRAFICA 3
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF001A").s().p("AjSjYIGlEAIi5Cxg");
	this.shape_7.setTransform(519.6,-49.8,0.385,0.385);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FF001A").ss(3,0,0,4).p("EAjRAk/MhGihJ+");
	this.shape_8.setTransform(608.7,43.7,0.385,0.385);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF001A").s().p("AjbkQIG2F3Ij1Cqg");
	this.shape_9.setTransform(520.1,-128.6,0.385,0.385);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF001A").ss(3,0,0,4).p("EAjCAzHMhGChmM");
	this.shape_10.setTransform(607.9,1,0.385,0.385);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF001A").s().p("AjEkZIGJGnIkICMg");
	this.shape_11.setTransform(520.6,-214.8,0.385,0.385);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF001A").ss(3,0,0,4).p("ANgZhMga/gzB");
	this.shape_12.setTransform(607.8,-46.8);

	this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]},121).wait(79));

	// EJE VERTI
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3.8,0,0,4).p("EhCRAAAMCEjAAA");
	this.shape_13.setTransform(549.5,-111.7,0.384,0.384);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3.9,0,0,4).p("EAAAA3uMAAAhvb");
	this.shape_14.setTransform(537.7,-128,0.385,0.385);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13}]}).wait(200));

	// mascara_text (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_50 = new cjs.Graphics().p("A6nBaIAAiyMA1PAAAIAACyg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A6nBxIAAjhMA1PAAAIAADhg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A6nCJIAAkRMA1PAAAIAAERg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A6nChIAAlBMA1PAAAIAAFBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A6nC5IAAlxMA1PAAAIAAFxg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A6nDRIAAmhMA1PAAAIAAGhg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A6nDpIAAnRMA1PAAAIAAHRg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A6nEBIAAoBMA1PAAAIAAIBg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A6nEZIAAoxMA1PAAAIAAIxg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A6nExIAAphMA1PAAAIAAJhg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A6nFJIAAqRMA1PAAAIAAKRg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A6nFhIAArBMA1PAAAIAALBg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A6nF5IAArxMA1PAAAIAALxg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A6nGRIAAshMA1PAAAIAAMhg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A6nGoIAAtPMA1PAAAIAANPg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A6nHAIAAt/MA1PAAAIAAN/g");
	var mask_1_graphics_66 = new cjs.Graphics().p("A6nHYIAAuvMA1PAAAIAAOvg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A6nHwIAAvfMA1PAAAIAAPfg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A6nIIIAAwPMA1PAAAIAAQPg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A6nIgIAAw/MA1PAAAIAAQ/g");
	var mask_1_graphics_70 = new cjs.Graphics().p("A6nI4IAAxvMA1PAAAIAARvg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A6nJQIAAyfMA1PAAAIAASfg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A6nJoIAAzPMA1PAAAIAATPg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A6nKAIAAz/MA1PAAAIAAT/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("A6nKYIAA0vMA1PAAAIAAUvg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A6nKwIAA1fMA1PAAAIAAVfg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A6nLIIAA2PMA1PAAAIAAWPg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A6nLfIAA29MA1PAAAIAAW9g");
	var mask_1_graphics_78 = new cjs.Graphics().p("A6nL3IAA3tMA1PAAAIAAXtg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A6nMPIAA4dMA1PAAAIAAYdg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A6nMnIAA5NMA1PAAAIAAZNg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A6nM/IAA59MA1PAAAIAAZ9g");
	var mask_1_graphics_82 = new cjs.Graphics().p("A6nNXIAA6tMA1PAAAIAAatg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A6nNvIAA7dMA1PAAAIAAbdg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A6nOHIAA8NMA1PAAAIAAcNg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A6nOfIAA89MA1PAAAIAAc9g");
	var mask_1_graphics_86 = new cjs.Graphics().p("A6nO3IAA9tMA1PAAAIAAdtg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A6nPPIAA+dMA1PAAAIAAedg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A6nPnIAA/NMA1PAAAIAAfNg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A6nP/IAA/9MA1PAAAIAAf9g");
	var mask_1_graphics_90 = new cjs.Graphics().p("A6nQWMAAAggrMA1PAAAMAAAAgrg");
	var mask_1_graphics_91 = new cjs.Graphics().p("A6nQuMAAAghbMA1PAAAMAAAAhbg");
	var mask_1_graphics_92 = new cjs.Graphics().p("A6nRGMAAAgiLMA1PAAAMAAAAiLg");
	var mask_1_graphics_93 = new cjs.Graphics().p("A6nReMAAAgi7MA1PAAAMAAAAi7g");
	var mask_1_graphics_94 = new cjs.Graphics().p("A6nR2MAAAgjrMA1PAAAMAAAAjrg");
	var mask_1_graphics_95 = new cjs.Graphics().p("A6nSOMAAAgkbMA1PAAAMAAAAkbg");
	var mask_1_graphics_96 = new cjs.Graphics().p("A6nSmMAAAglLMA1PAAAMAAAAlLg");
	var mask_1_graphics_97 = new cjs.Graphics().p("A6nS+MAAAgl7MA1PAAAMAAAAl7g");
	var mask_1_graphics_98 = new cjs.Graphics().p("A6nTWMAAAgmrMA1PAAAMAAAAmrg");
	var mask_1_graphics_99 = new cjs.Graphics().p("A6nTuMAAAgnbMA1PAAAMAAAAnbg");
	var mask_1_graphics_100 = new cjs.Graphics().p("A6nUGMAAAgoLMA1PAAAMAAAAoLg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A6nUeMAAAgo7MA1PAAAMAAAAo7g");
	var mask_1_graphics_102 = new cjs.Graphics().p("A6nU2MAAAgprMA1PAAAMAAAAprg");
	var mask_1_graphics_103 = new cjs.Graphics().p("A6nVOMAAAgqbMA1PAAAMAAAAqbg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A6nVlMAAAgrJMA1PAAAMAAAArJg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A6nV9MAAAgr5MA1PAAAMAAAAr5g");
	var mask_1_graphics_106 = new cjs.Graphics().p("A6nWVMAAAgspMA1PAAAMAAAAspg");
	var mask_1_graphics_107 = new cjs.Graphics().p("A6nWtMAAAgtZMA1PAAAMAAAAtZg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A6nXFMAAAguJMA1PAAAMAAAAuJg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A6nXdMAAAgu5MA1PAAAMAAAAu5g");
	var mask_1_graphics_110 = new cjs.Graphics().p("A6nX1MAAAgvpMA1PAAAMAAAAvpg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A6nYNMAAAgwZMA1PAAAMAAAAwZg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A6nYlMAAAgxJMA1PAAAMAAAAxJg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A6nY9MAAAgx5MA1PAAAMAAAAx5g");
	var mask_1_graphics_114 = new cjs.Graphics().p("A6nZVMAAAgypMA1PAAAMAAAAypg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A6nZtMAAAgzZMA1PAAAMAAAAzZg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A6naFMAAAg0JMA1PAAAMAAAA0Jg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A6nacMAAAg03MA1PAAAMAAAA03g");
	var mask_1_graphics_118 = new cjs.Graphics().p("A6na0MAAAg1nMA1PAAAMAAAA1ng");
	var mask_1_graphics_119 = new cjs.Graphics().p("A6nbMMAAAg2XMA1PAAAMAAAA2Xg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A6nbkMAAAg3HMA1PAAAMAAAA3Hg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(50).to({graphics:mask_1_graphics_50,x:166.5,y:-299.6}).wait(1).to({graphics:mask_1_graphics_51,x:166.5,y:-297.2}).wait(1).to({graphics:mask_1_graphics_52,x:166.5,y:-294.8}).wait(1).to({graphics:mask_1_graphics_53,x:166.5,y:-292.4}).wait(1).to({graphics:mask_1_graphics_54,x:166.5,y:-290}).wait(1).to({graphics:mask_1_graphics_55,x:166.5,y:-287.6}).wait(1).to({graphics:mask_1_graphics_56,x:166.5,y:-285.2}).wait(1).to({graphics:mask_1_graphics_57,x:166.5,y:-282.8}).wait(1).to({graphics:mask_1_graphics_58,x:166.5,y:-280.4}).wait(1).to({graphics:mask_1_graphics_59,x:166.5,y:-278}).wait(1).to({graphics:mask_1_graphics_60,x:166.5,y:-275.6}).wait(1).to({graphics:mask_1_graphics_61,x:166.5,y:-273.2}).wait(1).to({graphics:mask_1_graphics_62,x:166.5,y:-270.8}).wait(1).to({graphics:mask_1_graphics_63,x:166.5,y:-268.4}).wait(1).to({graphics:mask_1_graphics_64,x:166.5,y:-266.1}).wait(1).to({graphics:mask_1_graphics_65,x:166.5,y:-263.7}).wait(1).to({graphics:mask_1_graphics_66,x:166.5,y:-261.3}).wait(1).to({graphics:mask_1_graphics_67,x:166.5,y:-258.9}).wait(1).to({graphics:mask_1_graphics_68,x:166.5,y:-256.5}).wait(1).to({graphics:mask_1_graphics_69,x:166.5,y:-254.1}).wait(1).to({graphics:mask_1_graphics_70,x:166.5,y:-251.7}).wait(1).to({graphics:mask_1_graphics_71,x:166.5,y:-249.3}).wait(1).to({graphics:mask_1_graphics_72,x:166.5,y:-246.9}).wait(1).to({graphics:mask_1_graphics_73,x:166.5,y:-244.5}).wait(1).to({graphics:mask_1_graphics_74,x:166.5,y:-242.1}).wait(1).to({graphics:mask_1_graphics_75,x:166.5,y:-239.7}).wait(1).to({graphics:mask_1_graphics_76,x:166.5,y:-237.3}).wait(1).to({graphics:mask_1_graphics_77,x:166.5,y:-235}).wait(1).to({graphics:mask_1_graphics_78,x:166.5,y:-232.6}).wait(1).to({graphics:mask_1_graphics_79,x:166.5,y:-230.2}).wait(1).to({graphics:mask_1_graphics_80,x:166.5,y:-227.8}).wait(1).to({graphics:mask_1_graphics_81,x:166.5,y:-225.4}).wait(1).to({graphics:mask_1_graphics_82,x:166.5,y:-223}).wait(1).to({graphics:mask_1_graphics_83,x:166.5,y:-220.6}).wait(1).to({graphics:mask_1_graphics_84,x:166.5,y:-218.2}).wait(1).to({graphics:mask_1_graphics_85,x:166.5,y:-215.8}).wait(1).to({graphics:mask_1_graphics_86,x:166.5,y:-213.4}).wait(1).to({graphics:mask_1_graphics_87,x:166.5,y:-211}).wait(1).to({graphics:mask_1_graphics_88,x:166.5,y:-208.6}).wait(1).to({graphics:mask_1_graphics_89,x:166.5,y:-206.2}).wait(1).to({graphics:mask_1_graphics_90,x:166.5,y:-203.9}).wait(1).to({graphics:mask_1_graphics_91,x:166.5,y:-201.5}).wait(1).to({graphics:mask_1_graphics_92,x:166.5,y:-199.1}).wait(1).to({graphics:mask_1_graphics_93,x:166.5,y:-196.7}).wait(1).to({graphics:mask_1_graphics_94,x:166.5,y:-194.3}).wait(1).to({graphics:mask_1_graphics_95,x:166.5,y:-191.9}).wait(1).to({graphics:mask_1_graphics_96,x:166.5,y:-189.5}).wait(1).to({graphics:mask_1_graphics_97,x:166.5,y:-187.1}).wait(1).to({graphics:mask_1_graphics_98,x:166.5,y:-184.7}).wait(1).to({graphics:mask_1_graphics_99,x:166.5,y:-182.3}).wait(1).to({graphics:mask_1_graphics_100,x:166.5,y:-179.9}).wait(1).to({graphics:mask_1_graphics_101,x:166.5,y:-177.5}).wait(1).to({graphics:mask_1_graphics_102,x:166.5,y:-175.1}).wait(1).to({graphics:mask_1_graphics_103,x:166.5,y:-172.7}).wait(1).to({graphics:mask_1_graphics_104,x:166.5,y:-170.4}).wait(1).to({graphics:mask_1_graphics_105,x:166.5,y:-168}).wait(1).to({graphics:mask_1_graphics_106,x:166.5,y:-165.6}).wait(1).to({graphics:mask_1_graphics_107,x:166.5,y:-163.2}).wait(1).to({graphics:mask_1_graphics_108,x:166.5,y:-160.8}).wait(1).to({graphics:mask_1_graphics_109,x:166.5,y:-158.4}).wait(1).to({graphics:mask_1_graphics_110,x:166.5,y:-156}).wait(1).to({graphics:mask_1_graphics_111,x:166.5,y:-153.6}).wait(1).to({graphics:mask_1_graphics_112,x:166.5,y:-151.2}).wait(1).to({graphics:mask_1_graphics_113,x:166.5,y:-148.8}).wait(1).to({graphics:mask_1_graphics_114,x:166.5,y:-146.4}).wait(1).to({graphics:mask_1_graphics_115,x:166.5,y:-144}).wait(1).to({graphics:mask_1_graphics_116,x:166.5,y:-141.6}).wait(1).to({graphics:mask_1_graphics_117,x:166.5,y:-139.3}).wait(1).to({graphics:mask_1_graphics_118,x:166.5,y:-136.9}).wait(1).to({graphics:mask_1_graphics_119,x:166.5,y:-134.5}).wait(1).to({graphics:mask_1_graphics_120,x:166.5,y:-132.1}).wait(80));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(408,-248,342.6,183.9);

(lib.mc_treball_02_scn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara_grafica (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_118 = new cjs.Graphics().p("EgEhAhLQgyAAAAgyMAAAhAxQAAgyAyAAIJDAAQAyAAAAAyMAAABAxQAAAygyAAg");
	var mask_graphics_119 = new cjs.Graphics().p("EgFMAhLQg5AAAAgyMAAAhAxQAAgyA5AAIKZAAQA5AAAAAyMAAABAxQAAAyg5AAg");
	var mask_graphics_120 = new cjs.Graphics().p("EgF3AhLQhAAAAAgyMAAAhAxQAAgyBAAAILvAAQBAAAAAAyMAAABAxQAAAyhAAAg");
	var mask_graphics_121 = new cjs.Graphics().p("EgGhAhLQhJAAAAgyMAAAhAxQAAgyBJAAINDAAQBJAAAAAyMAAABAxQAAAyhJAAg");
	var mask_graphics_122 = new cjs.Graphics().p("EgHMAhLQhQAAAAgyMAAAhAxQAAgyBQAAIOZAAQBQAAAAAyMAAABAxQAAAyhQAAg");
	var mask_graphics_123 = new cjs.Graphics().p("EgH3AhLQhXAAAAgyMAAAhAxQAAgyBXAAIPvAAQBXAAAAAyMAAABAxQAAAyhXAAg");
	var mask_graphics_124 = new cjs.Graphics().p("EgIiAhLQheAAAAgyMAAAhAxQAAgyBeAAIRFAAQBeAAAAAyMAAABAxQAAAyheAAg");
	var mask_graphics_125 = new cjs.Graphics().p("EgJNAhLQhmAAAAgyMAAAhAxQAAgyBmAAISbAAQBmAAAAAyMAAABAxQAAAyhmAAg");
	var mask_graphics_126 = new cjs.Graphics().p("EgJ4AhLQhtAAAAgyMAAAhAxQAAgyBtAAITxAAQBtAAAAAyMAAABAxQAAAyhtAAg");
	var mask_graphics_127 = new cjs.Graphics().p("EgKjAhLQh0AAAAgyMAAAhAxQAAgyB0AAIVHAAQB0AAAAAyMAAABAxQAAAyh0AAg");
	var mask_graphics_128 = new cjs.Graphics().p("EgLOAhLQh7AAAAgyMAAAhAxQAAgyB7AAIWdAAQB7AAAAAyMAAABAxQAAAyh7AAg");
	var mask_graphics_129 = new cjs.Graphics().p("EgL5AhLQiDAAAAgyMAAAhAxQAAgyCDAAIXyAAQCEAAAAAyMAAABAxQAAAyiEAAg");
	var mask_graphics_130 = new cjs.Graphics().p("EgMjAhLQiLAAAAgyMAAAhAxQAAgyCLAAIZHAAQCLAAAAAyMAAABAxQAAAyiLAAg");
	var mask_graphics_131 = new cjs.Graphics().p("EgNOAhLQiSAAAAgyMAAAhAxQAAgyCSAAIadAAQCSAAAAAyMAAABAxQAAAyiSAAg");
	var mask_graphics_132 = new cjs.Graphics().p("EgN5AhLQiaAAAAgyMAAAhAxQAAgyCaAAIbzAAQCaAAAAAyMAAABAxQAAAyiaAAg");
	var mask_graphics_133 = new cjs.Graphics().p("EgOkAhLQihAAAAgyMAAAhAxQAAgyChAAIdJAAQChAAAAAyMAAABAxQAAAyihAAg");
	var mask_graphics_134 = new cjs.Graphics().p("EgPPAhLQioAAAAgyMAAAhAxQAAgyCoAAIefAAQCoAAAAAyMAAABAxQAAAyioAAg");
	var mask_graphics_135 = new cjs.Graphics().p("EgP6AhLQivAAAAgyMAAAhAxQAAgyCvAAIf1AAQCvAAAAAyMAAABAxQAAAyivAAg");
	var mask_graphics_136 = new cjs.Graphics().p("EgQlAhLQi3AAAAgyMAAAhAxQAAgyC3AAMAhLAAAQC3AAAAAyMAAABAxQAAAyi3AAg");
	var mask_graphics_137 = new cjs.Graphics().p("EgRQAhLQi+AAAAgyMAAAhAxQAAgyC+AAMAigAAAQC/AAAAAyMAAABAxQAAAyi/AAg");
	var mask_graphics_138 = new cjs.Graphics().p("EgR7AhLQjFAAAAgyMAAAhAxQAAgyDFAAMAj2AAAQDGAAAAAyMAAABAxQAAAyjGAAg");
	var mask_graphics_139 = new cjs.Graphics().p("EgSlAhLQjNAAAAgyMAAAhAxQAAgyDNAAMAlLAAAQDNAAAAAyMAAABAxQAAAyjNAAg");
	var mask_graphics_140 = new cjs.Graphics().p("EgTQAhLQjVAAAAgyMAAAhAxQAAgyDVAAMAmhAAAQDVAAAAAyMAAABAxQAAAyjVAAg");
	var mask_graphics_141 = new cjs.Graphics().p("EgT7AhLQjcAAAAgyMAAAhAxQAAgyDcAAMAn3AAAQDcAAAAAyMAAABAxQAAAyjcAAg");
	var mask_graphics_142 = new cjs.Graphics().p("EgUmAhLQjjAAAAgyMAAAhAxQAAgyDjAAMApNAAAQDjAAAAAyMAAABAxQAAAyjjAAg");
	var mask_graphics_143 = new cjs.Graphics().p("EgVRAhLQjrAAAAgyMAAAhAxQAAgyDrAAMAqjAAAQDrAAAAAyMAAABAxQAAAyjrAAg");
	var mask_graphics_144 = new cjs.Graphics().p("EgV8AhLQjyAAAAgyMAAAhAxQAAgyDyAAMAr5AAAQDyAAAAAyMAAABAxQAAAyjyAAg");
	var mask_graphics_145 = new cjs.Graphics().p("EgWnAhLQj5AAAAgyMAAAhAxQAAgyD5AAMAtOAAAQD6AAAAAyMAAABAxQAAAyj6AAg");
	var mask_graphics_146 = new cjs.Graphics().p("EgXSAhLQkAAAAAgyMAAAhAxQAAgyEAAAMAukAAAQEBAAAAAyMAAABAxQAAAykBAAg");
	var mask_graphics_147 = new cjs.Graphics().p("EgX9AhLQkIAAAAgyMAAAhAxQAAgyEIAAMAv6AAAQEJAAAAAyMAAABAxQAAAykJAAg");
	var mask_graphics_148 = new cjs.Graphics().p("EgYoAhLQkPAAAAgyMAAAhAxQAAgyEPAAMAxQAAAQEQAAAAAyMAAABAxQAAAykQAAg");
	var mask_graphics_149 = new cjs.Graphics().p("EgZSAhLQkXAAAAgyMAAAhAxQAAgyEXAAMAylAAAQEXAAAAAyMAAABAxQAAAykXAAg");
	var mask_graphics_150 = new cjs.Graphics().p("EgZ9AhLQkeAAAAgyMAAAhAxQAAgyEeAAMAz7AAAQEeAAAAAyMAAABAxQAAAykeAAg");
	var mask_graphics_151 = new cjs.Graphics().p("EgaoAhLQkmAAAAgyMAAAhAxQAAgyEmAAMA1RAAAQEmAAAAAyMAAABAxQAAAykmAAg");
	var mask_graphics_152 = new cjs.Graphics().p("EgbTAhLQktAAAAgyMAAAhAxQAAgyEtAAMA2nAAAQEtAAAAAyMAAABAxQAAAyktAAg");
	var mask_graphics_153 = new cjs.Graphics().p("Egb+AhLQk0AAAAgyMAAAhAxQAAgyE0AAMA38AAAQE1AAAAAyMAAABAxQAAAyk1AAg");
	var mask_graphics_154 = new cjs.Graphics().p("EgcpAhLQk7AAAAgyMAAAhAxQAAgyE7AAMA5SAAAQE8AAAAAyMAAABAxQAAAyk8AAg");
	var mask_graphics_155 = new cjs.Graphics().p("EgdUAhLQlDAAAAgyMAAAhAxQAAgyFDAAMA6oAAAQFEAAAAAyMAAABAxQAAAylEAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(118).to({graphics:mask_graphics_118,x:179.5,y:-120.6}).wait(1).to({graphics:mask_graphics_119,x:184.6,y:-120.6}).wait(1).to({graphics:mask_graphics_120,x:189.6,y:-120.6}).wait(1).to({graphics:mask_graphics_121,x:194.6,y:-120.6}).wait(1).to({graphics:mask_graphics_122,x:199.6,y:-120.6}).wait(1).to({graphics:mask_graphics_123,x:204.7,y:-120.6}).wait(1).to({graphics:mask_graphics_124,x:209.7,y:-120.6}).wait(1).to({graphics:mask_graphics_125,x:214.7,y:-120.6}).wait(1).to({graphics:mask_graphics_126,x:219.7,y:-120.6}).wait(1).to({graphics:mask_graphics_127,x:224.8,y:-120.6}).wait(1).to({graphics:mask_graphics_128,x:229.8,y:-120.6}).wait(1).to({graphics:mask_graphics_129,x:234.8,y:-120.6}).wait(1).to({graphics:mask_graphics_130,x:239.8,y:-120.6}).wait(1).to({graphics:mask_graphics_131,x:244.9,y:-120.6}).wait(1).to({graphics:mask_graphics_132,x:249.9,y:-120.6}).wait(1).to({graphics:mask_graphics_133,x:254.9,y:-120.6}).wait(1).to({graphics:mask_graphics_134,x:260,y:-120.6}).wait(1).to({graphics:mask_graphics_135,x:265,y:-120.6}).wait(1).to({graphics:mask_graphics_136,x:270,y:-120.6}).wait(1).to({graphics:mask_graphics_137,x:275,y:-120.6}).wait(1).to({graphics:mask_graphics_138,x:280.1,y:-120.6}).wait(1).to({graphics:mask_graphics_139,x:285.1,y:-120.6}).wait(1).to({graphics:mask_graphics_140,x:290.1,y:-120.6}).wait(1).to({graphics:mask_graphics_141,x:295.1,y:-120.6}).wait(1).to({graphics:mask_graphics_142,x:300.2,y:-120.6}).wait(1).to({graphics:mask_graphics_143,x:305.2,y:-120.6}).wait(1).to({graphics:mask_graphics_144,x:310.2,y:-120.6}).wait(1).to({graphics:mask_graphics_145,x:315.3,y:-120.6}).wait(1).to({graphics:mask_graphics_146,x:320.3,y:-120.6}).wait(1).to({graphics:mask_graphics_147,x:325.3,y:-120.6}).wait(1).to({graphics:mask_graphics_148,x:330.3,y:-120.6}).wait(1).to({graphics:mask_graphics_149,x:335.4,y:-120.6}).wait(1).to({graphics:mask_graphics_150,x:340.4,y:-120.6}).wait(1).to({graphics:mask_graphics_151,x:345.4,y:-120.6}).wait(1).to({graphics:mask_graphics_152,x:350.4,y:-120.6}).wait(1).to({graphics:mask_graphics_153,x:355.5,y:-120.6}).wait(1).to({graphics:mask_graphics_154,x:360.5,y:-120.6}).wait(1).to({graphics:mask_graphics_155,x:365.5,y:-120.6}).wait(45));

	// GRAFICA 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#7100D6").ss(5.3,0,0,4).p("EgkCBBIQAYk3AynRQBkujB/sIQCxw+DMpqQD/sIEcAAQDpAAEfIVQCzFKFNNJQCwHABLCzQCMFPBtDVQEUIWDVADQE0AEEcwkQDktQDK3NQCQwlB1z8QA7p9Admp");
	this.shape.setTransform(392.7,-88.4,0.566,0.566);

	this.shape.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},118).wait(82));

	// punto_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("ABLAAQAAAfgXAWQgVAWgfAAQgeAAgVgWQgXgWAAgfQAAgdAXgWQAVgXAeAAQAfAAAVAXQAXAWAAAdg");
	this.shape_1.setTransform(512.1,-196.7,0.566,0.566);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9900D6").s().p("Ag0A0QgVgVAAgfQAAgdAVgXQAXgVAdAAQAeAAAWAVQAXAXgBAdQABAfgXAVQgWAXgeAAQgdAAgXgXg");
	this.shape_2.setTransform(512.1,-196.7,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},41).wait(159));

	// puntos
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("ABLAAQAAAfgXAWQgWAWgeAAQgeAAgWgWQgWgWAAgfQAAgeAWgVQAWgXAeAAQAeAAAWAXQAXAVAAAeg");
	this.shape_3.setTransform(510.8,24.3,0.566,0.566);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9900D6").s().p("AgzA0QgXgVAAgfQAAgdAXgXQAVgVAegBQAfABAVAVQAXAXAAAdQAAAfgXAVQgVAXgfAAQgeAAgVgXg");
	this.shape_4.setTransform(510.8,24.3,0.566,0.566);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("ABLAAQAAAegWAWQgXAXgeAAQgdAAgWgXQgXgWAAgeQAAgeAXgWQAWgWAdAAQAeAAAXAWQAWAWAAAeg");
	this.shape_5.setTransform(289.2,-197.3,0.566,0.566);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9900D6").s().p("AgzA0QgXgVAAgfQAAgeAXgVQAVgXAeAAQAeAAAXAXQAVAVAAAeQAAAfgVAVQgXAXgeAAQgeAAgVgXg");
	this.shape_6.setTransform(289.2,-197.3,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},79).wait(121));

	// eixos
	this.text = new cjs.Text("X", "36px Verdana");
	this.text.lineHeight = 43;
	this.text.setTransform(697.3,31.8,0.566,0.566);

	this.text_1 = new cjs.Text("Y", "36px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.setTransform(299.8,-308.8,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},23).wait(177));

	// textos
	this.text_2 = new cjs.Text("a", "italic 30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(506.3,38.6,0.566,0.566);

	this.text_3 = new cjs.Text("", "12px ArialMT");
	this.text_3.lineHeight = 14;
	this.text_3.setTransform(244.1,98.5,0.566,0.566);

	this.text_4 = new cjs.Text("", "12px ArialMT");
	this.text_4.lineHeight = 14;
	this.text_4.setTransform(244.1,98.5,0.566,0.566);

	this.text_5 = new cjs.Text("", "12px ArialMT");
	this.text_5.lineHeight = 14;
	this.text_5.setTransform(244.1,98.5,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3,p:{x:244.1,y:98.5,text:"",font:"12px ArialMT",lineHeight:14.4,lineWidth:0}},{t:this.text_2,p:{x:506.3,y:38.6,text:"a",font:"italic 30px Verdana",lineWidth:18}}]},68).to({state:[{t:this.text_4,p:{x:244.1,y:98.5,text:"",font:"12px ArialMT",lineHeight:14.4,lineWidth:0}},{t:this.text_3,p:{x:248.9,y:-201.4,text:"f(a)",font:"italic 30px Verdana",lineHeight:36,lineWidth:57}},{t:this.text_2,p:{x:506.3,y:38.6,text:"a",font:"italic 30px Verdana",lineWidth:18}}]},36).to({state:[{t:this.text_5},{t:this.text_4,p:{x:248.9,y:-201.4,text:"f(a)",font:"italic 30px Verdana",lineHeight:36,lineWidth:57}},{t:this.text_3,p:{x:506.3,y:38.6,text:"a",font:"italic 30px Verdana",lineHeight:36,lineWidth:18}},{t:this.text_2,p:{x:524.5,y:-199.7,text:"(a, f(a))",font:"30px Verdana",lineWidth:125}}]},51).wait(45));

	// coordenadas_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,0,0,4).p("ABLAAQAAAfgXAWQgWAWgeAAQgeAAgWgWQgWgWAAgfQAAgeAWgVQAWgXAeAAQAeAAAWAXQAXAVAAAeg");
	this.shape_7.setTransform(510.8,24.3,0.566,0.566);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9900D6").s().p("AgzA0QgXgVAAgfQAAgdAXgXQAVgVAegBQAfABAVAVQAXAXAAAdQAAAfgXAVQgVAXgfAAQgeAAgVgXg");
	this.shape_8.setTransform(510.8,24.3,0.566,0.566);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,0,0,4).p("ABLAAQAAAegWAWQgXAXgeAAQgdAAgWgXQgXgWAAgeQAAgeAXgWQAWgWAdAAQAeAAAXAWQAWAWAAAeg");
	this.shape_9.setTransform(289.2,-197.3,0.566,0.566);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9900D6").s().p("AgzA0QgXgVAAgfQAAgeAXgVQAVgXAeAAQAeAAAXAXQAVAVAAAeQAAAfgVAVQgXAXgeAAQgeAAgVgXg");
	this.shape_10.setTransform(289.2,-197.3,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]},134).wait(66));

	// coordenadas


	this.instance = new lib.Path();
	this.instance.setTransform(292.5,-198,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},58).to({state:[{t:this.instance}]},34).wait(108));

	// EJE ORI
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_12.setTransform(698.3,24.3,0.566,0.753,90);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABBfMAAAiC9");
	this.shape_13.setTransform(383.1,24.3,0.566,0.753,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12}]}).wait(200));

	// EJE VERTI
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_14.setTransform(290.2,-324.5,0.566,0.566);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABBfMAAAiC9");
	this.shape_15.setTransform(290.2,-87.8,0.566,0.566);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14}]}).wait(200));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(67.4,-326.7,633.9,476);


(lib.mc_treball_01_scn2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.shutterstock_85710800();
	this.instance.setTransform(189.9,-303.9,0.441,0.441);

	

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-303.9,782.5,387);


(lib.mc_pantalla4_scn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara_negatiova (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_50 = new cjs.Graphics().p("Ah/OzQgyAAAAgyIAA8BQAAgyAyAAID/AAQAyAAAAAyIAAcBQAAAygyAAg");
	var mask_graphics_51 = new cjs.Graphics().p("AidOzQg+AAAAgyIAA8BQAAgyA+AAIE7AAQA+AAAAAyIAAcBQAAAyg+AAg");
	var mask_graphics_52 = new cjs.Graphics().p("Ai8OzQhKAAAAgyIAA8BQAAgyBKAAIF5AAQBKAAAAAyIAAcBQAAAyhKAAg");
	var mask_graphics_53 = new cjs.Graphics().p("AjaOzQhWAAAAgyIAA8BQAAgyBWAAIG1AAQBWAAAAAyIAAcBQAAAyhWAAg");
	var mask_graphics_54 = new cjs.Graphics().p("Aj5OzQhiAAAAgyIAA8BQAAgyBiAAIHzAAQBiAAAAAyIAAcBQAAAyhiAAg");
	var mask_graphics_55 = new cjs.Graphics().p("AkYOzQhtAAAAgyIAA8BQAAgyBtAAIIxAAQBtAAAAAyIAAcBQAAAyhtAAg");
	var mask_graphics_56 = new cjs.Graphics().p("Ak2OzQh6AAAAgyIAA8BQAAgyB6AAIJtAAQB6AAAAAyIAAcBQAAAyh6AAg");
	var mask_graphics_57 = new cjs.Graphics().p("AlVOzQiFAAAAgyIAA8BQAAgyCFAAIKrAAQCFAAAAAyIAAcBQAAAyiFAAg");
	var mask_graphics_58 = new cjs.Graphics().p("AlzOzQiSAAAAgyIAA8BQAAgyCSAAILnAAQCSAAAAAyIAAcBQAAAyiSAAg");
	var mask_graphics_59 = new cjs.Graphics().p("AmSOzQidAAAAgyIAA8BQAAgyCdAAIMlAAQCdAAAAAyIAAcBQAAAyidAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AmwOzQipAAAAgyIAA8BQAAgyCpAAINhAAQCpAAAAAyIAAcBQAAAyipAAg");
	var mask_graphics_61 = new cjs.Graphics().p("AnPOzQi1AAAAgyIAA8BQAAgyC1AAIOfAAQC1AAAAAyIAAcBQAAAyi1AAg");
	var mask_graphics_62 = new cjs.Graphics().p("AntOzQjBAAAAgyIAA8BQAAgyDBAAIPbAAQDBAAAAAyIAAcBQAAAyjBAAg");
	var mask_graphics_63 = new cjs.Graphics().p("AoMOzQjNAAAAgyIAA8BQAAgyDNAAIQZAAQDNAAAAAyIAAcBQAAAyjNAAg");
	var mask_graphics_64 = new cjs.Graphics().p("AorOzQjYAAAAgyIAA8BQAAgyDYAAIRXAAQDYAAAAAyIAAcBQAAAyjYAAg");
	var mask_graphics_65 = new cjs.Graphics().p("ApJOzQjlAAAAgyIAA8BQAAgyDlAAISTAAQDlAAAAAyIAAcBQAAAyjlAAg");
	var mask_graphics_66 = new cjs.Graphics().p("ApoOzQjwAAAAgyIAA8BQAAgyDwAAITRAAQDwAAAAAyIAAcBQAAAyjwAAg");
	var mask_graphics_67 = new cjs.Graphics().p("AqGOzQj9AAAAgyIAA8BQAAgyD9AAIUNAAQD9AAAAAyIAAcBQAAAyj9AAg");
	var mask_graphics_68 = new cjs.Graphics().p("AqlOzQkIAAAAgyIAA8BQAAgyEIAAIVLAAQEIAAAAAyIAAcBQAAAykIAAg");
	var mask_graphics_69 = new cjs.Graphics().p("ArDOzQkVAAAAgyIAA8BQAAgyEVAAIWHAAQEVAAAAAyIAAcBQAAAykVAAg");
	var mask_graphics_70 = new cjs.Graphics().p("AriOzQkgAAAAgyIAA8BQAAgyEgAAIXFAAQEgAAAAAyIAAcBQAAAykgAAg");
	var mask_graphics_71 = new cjs.Graphics().p("AsBOzQksAAAAgyIAA8BQAAgyEsAAIYDAAQEsAAAAAyIAAcBQAAAyksAAg");
	var mask_graphics_72 = new cjs.Graphics().p("AsfOzQk4AAAAgyIAA8BQAAgyE4AAIY/AAQE4AAAAAyIAAcBQAAAyk4AAg");
	var mask_graphics_73 = new cjs.Graphics().p("As+OzQlEAAAAgyIAA8BQAAgyFEAAIZ9AAQFEAAAAAyIAAcBQAAAylEAAg");
	var mask_graphics_74 = new cjs.Graphics().p("AtcOzQlQAAAAgyIAA8BQAAgyFQAAIa5AAQFQAAAAAyIAAcBQAAAylQAAg");
	var mask_graphics_75 = new cjs.Graphics().p("At7OzQlcAAAAgyIAA8BQAAgyFcAAIb3AAQFcAAAAAyIAAcBQAAAylcAAg");
	var mask_graphics_76 = new cjs.Graphics().p("AuZOzQloAAAAgyIAA8BQAAgyFoAAIczAAQFoAAAAAyIAAcBQAAAyloAAg");
	var mask_graphics_77 = new cjs.Graphics().p("Au4OzQl0AAAAgyIAA8BQAAgyF0AAIdxAAQF0AAAAAyIAAcBQAAAyl0AAg");
	var mask_graphics_78 = new cjs.Graphics().p("AvWOzQmAAAAAgyIAA8BQAAgyGAAAIetAAQGAAAAAAyIAAcBQAAAymAAAg");
	var mask_graphics_79 = new cjs.Graphics().p("Av1OzQmMAAAAgyIAA8BQAAgyGMAAIfrAAQGMAAAAAyIAAcBQAAAymMAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(50).to({graphics:mask_graphics_50,x:474.6,y:275.2}).wait(1).to({graphics:mask_graphics_51,x:470.4,y:275.2}).wait(1).to({graphics:mask_graphics_52,x:466.1,y:275.2}).wait(1).to({graphics:mask_graphics_53,x:461.9,y:275.2}).wait(1).to({graphics:mask_graphics_54,x:457.6,y:275.2}).wait(1).to({graphics:mask_graphics_55,x:453.4,y:275.2}).wait(1).to({graphics:mask_graphics_56,x:449.1,y:275.2}).wait(1).to({graphics:mask_graphics_57,x:444.9,y:275.2}).wait(1).to({graphics:mask_graphics_58,x:440.6,y:275.2}).wait(1).to({graphics:mask_graphics_59,x:436.4,y:275.2}).wait(1).to({graphics:mask_graphics_60,x:432.2,y:275.2}).wait(1).to({graphics:mask_graphics_61,x:427.9,y:275.2}).wait(1).to({graphics:mask_graphics_62,x:423.7,y:275.2}).wait(1).to({graphics:mask_graphics_63,x:419.4,y:275.2}).wait(1).to({graphics:mask_graphics_64,x:415.2,y:275.2}).wait(1).to({graphics:mask_graphics_65,x:410.9,y:275.2}).wait(1).to({graphics:mask_graphics_66,x:406.7,y:275.2}).wait(1).to({graphics:mask_graphics_67,x:402.4,y:275.2}).wait(1).to({graphics:mask_graphics_68,x:398.2,y:275.2}).wait(1).to({graphics:mask_graphics_69,x:393.9,y:275.2}).wait(1).to({graphics:mask_graphics_70,x:389.7,y:275.2}).wait(1).to({graphics:mask_graphics_71,x:385.4,y:275.2}).wait(1).to({graphics:mask_graphics_72,x:381.2,y:275.2}).wait(1).to({graphics:mask_graphics_73,x:376.9,y:275.2}).wait(1).to({graphics:mask_graphics_74,x:372.7,y:275.2}).wait(1).to({graphics:mask_graphics_75,x:368.4,y:275.2}).wait(1).to({graphics:mask_graphics_76,x:364.2,y:275.2}).wait(1).to({graphics:mask_graphics_77,x:359.9,y:275.2}).wait(1).to({graphics:mask_graphics_78,x:355.7,y:275.2}).wait(1).to({graphics:mask_graphics_79,x:351.5,y:275.2}).wait(21));

	// GRAFICA 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#3400FD").ss(4,0,0,4).p("Ac89BMg53A6C");
	this.shape.setTransform(346.3,273,0.5,0.5);

	this.shape.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},50).wait(50));

	// mascara_positiva (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgeRuQgyAAAAgyMAAAgh3QAAgyAyAAIA9AAQAyAAAAAyMAAAAh3QAAAygyAAg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AgsRuQhIAAAAgyMAAAgh3QAAgyBIAAIBZAAQBIAAAAAyMAAAAh3QAAAyhIAAg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Ag6RuQheAAAAgyMAAAgh3QAAgyBeAAIB1AAQBeAAAAAyMAAAAh3QAAAyheAAg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AhIRuQh0AAAAgyMAAAgh3QAAgyB0AAICRAAQB0AAAAAyMAAAAh3QAAAyh0AAg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AhWRuQiKAAAAgyMAAAgh3QAAgyCKAAICtAAQCKAAAAAyMAAAAh3QAAAyiKAAg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AhkRuQigAAAAgyMAAAgh3QAAgyCgAAIDJAAQCgAAAAAyMAAAAh3QAAAyigAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AhyRuQi2AAAAgyMAAAgh3QAAgyC2AAIDlAAQC2AAAAAyMAAAAh3QAAAyi2AAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AiARuQjMAAAAgyMAAAgh3QAAgyDMAAIEBAAQDMAAAAAyMAAAAh3QAAAyjMAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AiORuQjiAAAAgyMAAAgh3QAAgyDiAAIEdAAQDiAAAAAyMAAAAh3QAAAyjiAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AicRuQj4AAAAgyMAAAgh3QAAgyD4AAIE5AAQD4AAAAAyMAAAAh3QAAAyj4AAg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AiqRuQkNAAAAgyMAAAgh3QAAgyENAAIFVAAQENAAAAAyMAAAAh3QAAAykNAAg");
	var mask_1_graphics_11 = new cjs.Graphics().p("Ai4RuQkjAAAAgyMAAAgh3QAAgyEjAAIFxAAQEjAAAAAyMAAAAh3QAAAykjAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AjGRuQk5AAAAgyMAAAgh3QAAgyE5AAIGNAAQE5AAAAAyMAAAAh3QAAAyk5AAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AjURuQlPAAAAgyMAAAgh3QAAgyFPAAIGpAAQFPAAAAAyMAAAAh3QAAAylPAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AjiRuQllAAAAgyMAAAgh3QAAgyFlAAIHFAAQFlAAAAAyMAAAAh3QAAAyllAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AjwRuQl7AAAAgyMAAAgh3QAAgyF7AAIHhAAQF7AAAAAyMAAAAh3QAAAyl7AAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aj+RuQmRAAAAgyMAAAgh3QAAgyGRAAIH9AAQGRAAAAAyMAAAAh3QAAAymRAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AkLRuQmoAAAAgyMAAAgh3QAAgyGoAAIIXAAQGoAAAAAyMAAAAh3QAAAymoAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AkZRuQm+AAAAgyMAAAgh3QAAgyG+AAIIzAAQG+AAAAAyMAAAAh3QAAAym+AAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AknRuQnUAAAAgyMAAAgh3QAAgyHUAAIJPAAQHUAAAAAyMAAAAh3QAAAynUAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Ak1RuQnqAAAAgyMAAAgh3QAAgyHqAAIJrAAQHqAAAAAyMAAAAh3QAAAynqAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AlDRuQoAAAAAgyMAAAgh3QAAgyIAAAIKHAAQIAAAAAAyMAAAAh3QAAAyoAAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AlRRuQoWAAAAgyMAAAgh3QAAgyIWAAIKjAAQIWAAAAAyMAAAAh3QAAAyoWAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AlfRuQosAAAAgyMAAAgh3QAAgyIsAAIK/AAQIsAAAAAyMAAAAh3QAAAyosAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AltRuQpBAAAAgyMAAAgh3QAAgyJBAAILbAAQJBAAAAAyMAAAAh3QAAAypBAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Al7RuQpXAAAAgyMAAAgh3QAAgyJXAAIL3AAQJXAAAAAyMAAAAh3QAAAypXAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AmJRuQptAAAAgyMAAAgh3QAAgyJtAAIMTAAQJtAAAAAyMAAAAh3QAAAyptAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AmXRuQqDAAAAgyMAAAgh3QAAgyKDAAIMvAAQKDAAAAAyMAAAAh3QAAAyqDAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AmlRuQqZAAAAgyMAAAgh3QAAgyKZAAINLAAQKZAAAAAyMAAAAh3QAAAyqZAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AmzRuQqvAAAAgyMAAAgh3QAAgyKvAAINnAAQKvAAAAAyMAAAAh3QAAAyqvAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AnBRuQrFAAAAgyMAAAgh3QAAgyLFAAIODAAQLFAAAAAyMAAAAh3QAAAyrFAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AnPRuQrbAAAAgyMAAAgh3QAAgyLbAAIOfAAQLbAAAAAyMAAAAh3QAAAyrbAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AndRuQrxAAAAgyMAAAgh3QAAgyLxAAIO7AAQLxAAAAAyMAAAAh3QAAAyrxAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AnrRuQsHAAAAgyMAAAgh3QAAgyMHAAIPXAAQMHAAAAAyMAAAAh3QAAAysHAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:409.3,y:98.4}).wait(1).to({graphics:mask_1_graphics_1,x:412.9,y:98.4}).wait(1).to({graphics:mask_1_graphics_2,x:416.5,y:98.4}).wait(1).to({graphics:mask_1_graphics_3,x:420.1,y:98.4}).wait(1).to({graphics:mask_1_graphics_4,x:423.6,y:98.4}).wait(1).to({graphics:mask_1_graphics_5,x:427.2,y:98.4}).wait(1).to({graphics:mask_1_graphics_6,x:430.8,y:98.4}).wait(1).to({graphics:mask_1_graphics_7,x:434.4,y:98.4}).wait(1).to({graphics:mask_1_graphics_8,x:438,y:98.4}).wait(1).to({graphics:mask_1_graphics_9,x:441.6,y:98.4}).wait(1).to({graphics:mask_1_graphics_10,x:445.2,y:98.4}).wait(1).to({graphics:mask_1_graphics_11,x:448.8,y:98.4}).wait(1).to({graphics:mask_1_graphics_12,x:452.4,y:98.4}).wait(1).to({graphics:mask_1_graphics_13,x:456,y:98.4}).wait(1).to({graphics:mask_1_graphics_14,x:459.6,y:98.4}).wait(1).to({graphics:mask_1_graphics_15,x:463.2,y:98.4}).wait(1).to({graphics:mask_1_graphics_16,x:466.8,y:98.4}).wait(1).to({graphics:mask_1_graphics_17,x:470.3,y:98.4}).wait(1).to({graphics:mask_1_graphics_18,x:473.9,y:98.4}).wait(1).to({graphics:mask_1_graphics_19,x:477.5,y:98.4}).wait(1).to({graphics:mask_1_graphics_20,x:481.1,y:98.4}).wait(1).to({graphics:mask_1_graphics_21,x:484.7,y:98.4}).wait(1).to({graphics:mask_1_graphics_22,x:488.3,y:98.4}).wait(1).to({graphics:mask_1_graphics_23,x:491.9,y:98.4}).wait(1).to({graphics:mask_1_graphics_24,x:495.5,y:98.4}).wait(1).to({graphics:mask_1_graphics_25,x:499.1,y:98.4}).wait(1).to({graphics:mask_1_graphics_26,x:502.7,y:98.4}).wait(1).to({graphics:mask_1_graphics_27,x:506.3,y:98.4}).wait(1).to({graphics:mask_1_graphics_28,x:509.9,y:98.4}).wait(1).to({graphics:mask_1_graphics_29,x:513.5,y:98.4}).wait(1).to({graphics:mask_1_graphics_30,x:517,y:98.4}).wait(1).to({graphics:mask_1_graphics_31,x:520.6,y:98.4}).wait(1).to({graphics:mask_1_graphics_32,x:524.2,y:98.4}).wait(1).to({graphics:mask_1_graphics_33,x:527.8,y:98.4}).wait(67));

	// GRAFICA 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#F80015").ss(4,0,0,4).p("Acw81Mg5fA5r");
	this.shape_1.setTransform(532.1,87.2,0.5,0.5);

	this.shape_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).wait(100));

	// positiva
	this.text = new cjs.Text("positiva", "30px Arial", "#F80015");
	this.text.lineHeight = 36;
	this.text.setTransform(430.4,84.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},33).wait(67));

	// negativa
	this.text_1 = new cjs.Text("negativa", "30px Arial", "#1EA63F");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(287.5,209,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},79).wait(21));

	// textos
	this.text_2 = new cjs.Text("X", "36px Arial");
	this.text_2.lineHeight = 43;
	this.text_2.setTransform(659,159.8,0.5,0.5);

	this.text_3 = new cjs.Text("Y", "36px Arial");
	this.text_3.lineHeight = 43;
	this.text_3.setTransform(393.1,1.8,0.5,0.5);

	this.text_4 = new cjs.Text("", "12px ArialMT");
	this.text_4.lineHeight = 14;
	this.text_4.setTransform(287.4,347.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.text_3},{t:this.text_2}]}).wait(100));

	// EJE ORI
	this.text_5 = new cjs.Text("", "12px ArialMT");
	this.text_5.lineHeight = 14;
	this.text_5.setTransform(435.5,205.7,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_2.setTransform(643.7,182.4,0.5,0.5);

	this.text_6 = new cjs.Text("25", "24px Verdana");
	this.text_6.lineHeight = 29;
	this.text_6.setTransform(635.9,186.2,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(541.1,182.4,0.5,0.5);

	this.text_7 = new cjs.Text("15", "24px Verdana");
	this.text_7.lineHeight = 29;
	this.text_7.setTransform(534.3,186.2,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(439.4,182.3,0.5,0.5);

	this.text_8 = new cjs.Text("5", "24px Verdana");
	this.text_8.lineHeight = 29;
	this.text_8.setTransform(435.6,187.1,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(236.2,182.9,0.5,0.5);

	this.text_9 = new cjs.Text("-15", "24px Verdana");
	this.text_9.lineHeight = 29;
	this.text_9.setTransform(223.4,187.7,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(338.2,182.5,0.5,0.5);

	this.text_10 = new cjs.Text("-5", "24px Verdana");
	this.text_10.lineHeight = 29;
	this.text_10.setTransform(329.4,187.8,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(592,182.7,0.5,0.5);

	this.text_11 = new cjs.Text("20", "24px Verdana");
	this.text_11.lineHeight = 29;
	this.text_11.setTransform(584.8,186.1,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(286.3,182.8,0.5,0.5);

	this.text_12 = new cjs.Text("-10", "24px Verdana");
	this.text_12.lineHeight = 29;
	this.text_12.setTransform(273.5,187.1,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(490.3,182.2,0.5,0.5);

	this.text_13 = new cjs.Text("10", "24px Verdana");
	this.text_13.lineHeight = 29;
	this.text_13.setTransform(483.6,186.7,0.5,0.5);

	this.text_14 = new cjs.Text("0", "24px Verdana");
	this.text_14.lineHeight = 29;
	this.text_14.setTransform(392.1,185.9,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgmArIApgrIgpgpIASgTIA7A8Ig7A9g");
	this.shape_10.setTransform(692.2,180.4,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_11.setTransform(456.1,180.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.text_14},{t:this.text_13},{t:this.shape_9},{t:this.text_12},{t:this.shape_8},{t:this.text_11},{t:this.shape_7},{t:this.text_10},{t:this.shape_6},{t:this.text_9},{t:this.shape_5},{t:this.text_8},{t:this.shape_4},{t:this.text_7},{t:this.shape_3},{t:this.text_6},{t:this.shape_2},{t:this.text_5}]}).wait(100));

	// EJE VERTI
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_12.setTransform(385.7,332.4,0.5,0.5);

	this.text_15 = new cjs.Text("-15", "24px Verdana");
	this.text_15.lineHeight = 29;
	this.text_15.setTransform(361.1,328.8,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_13.setTransform(386.5,230.7,0.5,0.5);

	this.text_16 = new cjs.Text("-5", "24px Verdana");
	this.text_16.lineHeight = 29;
	this.text_16.setTransform(369.4,226.6,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_14.setTransform(385.8,26.9,0.5,0.5);

	this.text_17 = new cjs.Text("15", "24px Verdana");
	this.text_17.lineHeight = 29;
	this.text_17.setTransform(366.5,22.3,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(385.7,282,0.5,0.5);

	this.text_18 = new cjs.Text("-10", "24px Verdana");
	this.text_18.lineHeight = 29;
	this.text_18.setTransform(361.1,277.4,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(385.1,128.1,0.5,0.5);

	this.text_19 = new cjs.Text("5", "24px Verdana");
	this.text_19.lineHeight = 29;
	this.text_19.setTransform(373.9,124.9,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(385.1,77.7,0.5,0.5);

	this.text_20 = new cjs.Text("10", "24px Verdana");
	this.text_20.lineHeight = 29;
	this.text_20.setTransform(366.3,73.6,0.5,0.5);

	this.text_21 = new cjs.Text("0", "24px Verdana");
	this.text_21.lineHeight = 29;
	this.text_21.setTransform(373.2,167.5,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAAgBIgbAbIgMgMIAngnIAoAnIgMAMg");
	this.shape_18.setTransform(388,-0.1,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAA59MAAAhz5");
	this.shape_19.setTransform(388,185,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.text_21},{t:this.text_20},{t:this.shape_17},{t:this.text_19},{t:this.shape_16},{t:this.text_18},{t:this.shape_15},{t:this.text_17},{t:this.shape_14},{t:this.text_16},{t:this.shape_13},{t:this.text_15},{t:this.shape_12}]}).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(219.5,-5,474.7,375.6);


(lib.mc_pantalla4 = function() {
	this.initialize();

	// text
	
	// imatge
	this.instance = new lib.MTB_10_06_0102();
	this.instance.setTransform(208.8,7.6,0.4,0.4);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2,-22.9,773.3,430.6);

(lib.mc_pantalla3_scn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	

	// EJE ORI
	this.text = new cjs.Text("X", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 17;
	this.text.setTransform(667.8,93.5);

	this.text_1 = new cjs.Text("16", "21px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(640.9,134,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg2IAABt");
	this.shape.setTransform(647.3,130.8,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_1.setTransform(551.5,130.6,0.5,0.5);

	this.text_2 = new cjs.Text("10", "21px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.setTransform(544.9,134,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_2.setTransform(615.7,131,0.5,0.5);

	this.text_3 = new cjs.Text("14", "21px Verdana");
	this.text_3.lineHeight = 25;
	this.text_3.setTransform(608.9,134.5,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(583.2,131.1,0.5,0.5);

	this.text_4 = new cjs.Text("12", "21px Verdana");
	this.text_4.lineHeight = 25;
	this.text_4.setTransform(576.4,134,0.5,0.5);

	this.text_5 = new cjs.Text("-8", "21px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 25;
	this.text_5.setTransform(268,135.1,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(231.3,130.9,0.5,0.5);

	this.text_6 = new cjs.Text("-10", "21px Verdana");
	this.text_6.lineHeight = 25;
	this.text_6.setTransform(219.9,135.3,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(519.1,130.6,0.5,0.5);

	this.text_7 = new cjs.Text("8", "21px Verdana");
	this.text_7.lineHeight = 25;
	this.text_7.setTransform(515.9,135,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(423.3,131.1,0.5,0.5);

	this.text_8 = new cjs.Text("2", "21px Verdana");
	this.text_8.lineHeight = 25;
	this.text_8.setTransform(419.9,135,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(295.3,131,0.5,0.5);

	this.text_9 = new cjs.Text("-6", "21px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 25;
	this.text_9.setTransform(300,135.1,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(359.8,131.1,0.5,0.5);

	this.text_10 = new cjs.Text("-2", "21px Verdana");
	this.text_10.lineHeight = 25;
	this.text_10.setTransform(351.6,135.5,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(487.5,130.6,0.5,0.5);

	this.text_11 = new cjs.Text("6", "21px Verdana");
	this.text_11.lineHeight = 25;
	this.text_11.setTransform(483.9,134.7,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(263.4,131.2,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(328.3,131,0.5,0.5);

	this.text_12 = new cjs.Text("-4", "21px Verdana");
	this.text_12.lineHeight = 25;
	this.text_12.setTransform(320.1,135.4,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_12.setTransform(455,131,0.5,0.5);

	this.text_13 = new cjs.Text("4", "21px Verdana");
	this.text_13.lineHeight = 25;
	this.text_13.setTransform(451.4,135,0.5,0.5);

	this.text_14 = new cjs.Text("0", "21px Verdana");
	this.text_14.lineHeight = 25;
	this.text_14.setTransform(394.2,131.7,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_13.setTransform(681.2,128.5,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_14.setTransform(445.1,128.5,0.5,0.5);

	this.instance = new lib.Mapadebits2();
	this.instance.setTransform(207.1,123);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FF0000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_15.setTransform(681.2,128.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.text_14},{t:this.text_13},{t:this.shape_12},{t:this.text_12},{t:this.shape_11},{t:this.shape_10},{t:this.text_11},{t:this.shape_9},{t:this.text_10},{t:this.shape_8},{t:this.text_9},{t:this.shape_7},{t:this.text_8},{t:this.shape_6},{t:this.text_7},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.text_3},{t:this.shape_2},{t:this.text_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text}]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_15},{t:this.text_14},{t:this.text_13},{t:this.shape_12},{t:this.text_12},{t:this.shape_11},{t:this.shape_10},{t:this.text_11},{t:this.shape_9},{t:this.text_10},{t:this.shape_8},{t:this.text_9},{t:this.shape_7},{t:this.text_8},{t:this.shape_6},{t:this.text_7},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.text_3},{t:this.shape_2},{t:this.text_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text},{t:this.instance}]},49).wait(1));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhDdCQgyAAAAgzMAAAg4eQAAgxAyAAICHAAQAyAAAAAxMAAAA4eQAAAzgyAAg");
	var mask_graphics_1 = new cjs.Graphics().p("AhUdCQg/AAAAgzMAAAg4eQAAgxA/AAICqAAQA+AAAAAxMAAAA4eQAAAzg+AAg");
	var mask_graphics_2 = new cjs.Graphics().p("AhmdCQhMAAAAgzMAAAg4eQAAgxBMAAIDNAAQBMAAAAAxMAAAA4eQAAAzhMAAg");
	var mask_graphics_3 = new cjs.Graphics().p("Ah4dCQhZAAAAgzMAAAg4eQAAgxBZAAIDxAAQBZAAAAAxMAAAA4eQAAAzhZAAg");
	var mask_graphics_4 = new cjs.Graphics().p("AiKdCQhmAAAAgzMAAAg4eQAAgxBmAAIEVAAQBmAAAAAxMAAAA4eQAAAzhmAAg");
	var mask_graphics_5 = new cjs.Graphics().p("AibdCQhzAAAAgzMAAAg4eQAAgxBzAAIE3AAQBzAAAAAxMAAAA4eQAAAzhzAAg");
	var mask_graphics_6 = new cjs.Graphics().p("AitdCQiAAAAAgzMAAAg4eQAAgxCAAAIFbAAQCAAAAAAxMAAAA4eQAAAziAAAg");
	var mask_graphics_7 = new cjs.Graphics().p("Ai/dCQiNAAAAgzMAAAg4eQAAgxCNAAIF/AAQCNAAAAAxMAAAA4eQAAAziNAAg");
	var mask_graphics_8 = new cjs.Graphics().p("AjRdCQiaAAAAgzMAAAg4eQAAgxCaAAIGjAAQCaAAAAAxMAAAA4eQAAAziaAAg");
	var mask_graphics_9 = new cjs.Graphics().p("AjidCQinAAAAgzMAAAg4eQAAgxCnAAIHFAAQCnAAAAAxMAAAA4eQAAAzinAAg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj0dCQi0AAAAgzMAAAg4eQAAgxC0AAIHpAAQC0AAAAAxMAAAA4eQAAAzi0AAg");
	var mask_graphics_11 = new cjs.Graphics().p("AkGdCQjBAAAAgzMAAAg4eQAAgxDBAAIINAAQDBAAAAAxMAAAA4eQAAAzjBAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AkYdCQjOAAAAgzMAAAg4eQAAgxDOAAIIxAAQDOAAAAAxMAAAA4eQAAAzjOAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AkpdCQjbAAAAgzMAAAg4eQAAgxDbAAIJTAAQDbAAAAAxMAAAA4eQAAAzjbAAg");
	var mask_graphics_14 = new cjs.Graphics().p("Ak7dCQjoAAAAgzMAAAg4eQAAgxDoAAIJ3AAQDoAAAAAxMAAAA4eQAAAzjoAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AlNdCQj1AAAAgzMAAAg4eQAAgxD1AAIKbAAQD1AAAAAxMAAAA4eQAAAzj1AAg");
	var mask_graphics_16 = new cjs.Graphics().p("AledCQkCAAAAgzMAAAg4eQAAgxECAAIK+AAQEBAAAAAxMAAAA4eQAAAzkBAAg");
	var mask_graphics_17 = new cjs.Graphics().p("AlwdCQkPAAAAgzMAAAg4eQAAgxEPAAILiAAQEOAAAAAxMAAAA4eQAAAzkOAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AmCdCQkcAAAAgzMAAAg4eQAAgxEcAAIMFAAQEcAAAAAxMAAAA4eQAAAzkcAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AmUdCQkpAAAAgzMAAAg4eQAAgxEpAAIMpAAQEpAAAAAxMAAAA4eQAAAzkpAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AmldCQk2AAAAgzMAAAg4eQAAgxE2AAINMAAQE1AAAAAxMAAAA4eQAAAzk1AAg");
	var mask_graphics_21 = new cjs.Graphics().p("Am3dCQlDAAAAgzMAAAg4eQAAgxFDAAINwAAQFCAAAAAxMAAAA4eQAAAzlCAAg");
	var mask_graphics_22 = new cjs.Graphics().p("AnJdCQlQAAAAgzMAAAg4eQAAgxFQAAIOTAAQFQAAAAAxMAAAA4eQAAAzlQAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AnbdCQldAAAAgzMAAAg4eQAAgxFdAAIO3AAQFdAAAAAxMAAAA4eQAAAzldAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AnsdCQlqAAAAgzMAAAg4eQAAgxFqAAIPaAAQFpAAAAAxMAAAA4eQAAAzlpAAg");
	var mask_graphics_25 = new cjs.Graphics().p("An+dCQl3AAAAgzMAAAg4eQAAgxF3AAIP+AAQF2AAAAAxMAAAA4eQAAAzl2AAg");
	var mask_graphics_26 = new cjs.Graphics().p("AoQdCQmEAAAAgzMAAAg4eQAAgxGEAAIQhAAQGEAAAAAxMAAAA4eQAAAzmEAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AoidCQmRAAAAgzMAAAg4eQAAgxGRAAIRFAAQGRAAAAAxMAAAA4eQAAAzmRAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AozdCQmeAAAAgzMAAAg4eQAAgxGeAAIRoAAQGdAAAAAxMAAAA4eQAAAzmdAAg");
	var mask_graphics_29 = new cjs.Graphics().p("ApFdCQmrAAAAgzMAAAg4eQAAgxGrAAISMAAQGqAAAAAxMAAAA4eQAAAzmqAAg");
	var mask_graphics_30 = new cjs.Graphics().p("ApXdCQm4AAAAgzMAAAg4eQAAgxG4AAISvAAQG4AAAAAxMAAAA4eQAAAzm4AAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:300,y:255}).wait(1).to({graphics:mask_graphics_1,x:303,y:255}).wait(1).to({graphics:mask_graphics_2,x:306.1,y:255}).wait(1).to({graphics:mask_graphics_3,x:309.2,y:255}).wait(1).to({graphics:mask_graphics_4,x:312.3,y:255}).wait(1).to({graphics:mask_graphics_5,x:315.3,y:255}).wait(1).to({graphics:mask_graphics_6,x:318.4,y:255}).wait(1).to({graphics:mask_graphics_7,x:321.5,y:255}).wait(1).to({graphics:mask_graphics_8,x:324.6,y:255}).wait(1).to({graphics:mask_graphics_9,x:327.6,y:255}).wait(1).to({graphics:mask_graphics_10,x:330.7,y:255}).wait(1).to({graphics:mask_graphics_11,x:333.8,y:255}).wait(1).to({graphics:mask_graphics_12,x:336.9,y:255}).wait(1).to({graphics:mask_graphics_13,x:339.9,y:255}).wait(1).to({graphics:mask_graphics_14,x:343,y:255}).wait(1).to({graphics:mask_graphics_15,x:346.1,y:255}).wait(1).to({graphics:mask_graphics_16,x:349.1,y:255}).wait(1).to({graphics:mask_graphics_17,x:352.2,y:255}).wait(1).to({graphics:mask_graphics_18,x:355.3,y:255}).wait(1).to({graphics:mask_graphics_19,x:358.4,y:255}).wait(1).to({graphics:mask_graphics_20,x:361.4,y:255}).wait(1).to({graphics:mask_graphics_21,x:364.5,y:255}).wait(1).to({graphics:mask_graphics_22,x:367.6,y:255}).wait(1).to({graphics:mask_graphics_23,x:370.7,y:255}).wait(1).to({graphics:mask_graphics_24,x:373.7,y:255}).wait(1).to({graphics:mask_graphics_25,x:376.8,y:255}).wait(1).to({graphics:mask_graphics_26,x:379.9,y:255}).wait(1).to({graphics:mask_graphics_27,x:383,y:255}).wait(1).to({graphics:mask_graphics_28,x:386,y:255}).wait(1).to({graphics:mask_graphics_29,x:389.1,y:255}).wait(1).to({graphics:mask_graphics_30,x:392.2,y:255}).wait(20));

	// GRAFICA 1
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#00FF00").ss(2.9,0,0,4).p("EgUUgpRQAmFMBDHxQCGPiCTM6QDPSIDKKVQD9M6DpgDQEKgEELtAQDWqaDMyHQCSs+B+vkQA/nxAilM");
	this.shape_16.setTransform(389.5,295.1,0.5,0.5,0,180,0,0,-0.6);

	this.shape_16.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16}]}).wait(50));

	// EJE VERTI
	this.text_15 = new cjs.Text("-18", "21px Verdana");
	this.text_15.textAlign = "right";
	this.text_15.lineHeight = 25;
	this.text_15.setTransform(386,405,0.5,0.5);

	this.text_16 = new cjs.Text("-14", "21px Verdana");
	this.text_16.textAlign = "right";
	this.text_16.lineHeight = 25;
	this.text_16.setTransform(386,341.2,0.5,0.5);

	this.text_17 = new cjs.Text("-16", "21px Verdana");
	this.text_17.textAlign = "right";
	this.text_17.lineHeight = 25;
	this.text_17.setTransform(386,373,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_17.setTransform(388.2,313.7,0.5,0.5);

	this.text_18 = new cjs.Text("-12", "21px Verdana");
	this.text_18.textAlign = "right";
	this.text_18.lineHeight = 25;
	this.text_18.setTransform(386,309.8,0.5,0.5);

	this.text_19 = new cjs.Text("-8", "21px Verdana");
	this.text_19.lineHeight = 25;
	this.text_19.setTransform(373.1,246,0.5,0.5);

	this.text_20 = new cjs.Text("-10", "21px Verdana");
	this.text_20.textAlign = "right";
	this.text_20.lineHeight = 25;
	this.text_20.setTransform(386,277.8,0.5,0.5);

	this.text_21 = new cjs.Text("Y", "20px Verdana");
	this.text_21.lineHeight = 22;
	this.text_21.lineWidth = 17;
	this.text_21.setTransform(391.1,4.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(389,410,0.5,0.5);

	this.text_22 = new cjs.Text("-6", "21px Verdana");
	this.text_22.lineHeight = 25;
	this.text_22.setTransform(373.1,213,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_19.setTransform(389.2,37.9,0.5,0.5);

	this.text_23 = new cjs.Text("6", "21px Verdana");
	this.text_23.textAlign = "right";
	this.text_23.lineHeight = 25;
	this.text_23.setTransform(386,33.5,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_20.setTransform(388.9,70.1,0.5,0.5);

	this.text_24 = new cjs.Text("4", "21px Verdana");
	this.text_24.textAlign = "right";
	this.text_24.lineHeight = 25;
	this.text_24.setTransform(386,65.6,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_21.setTransform(389.2,102.1,0.5,0.5);

	this.text_25 = new cjs.Text("2", "21px Verdana");
	this.text_25.textAlign = "right";
	this.text_25.lineHeight = 25;
	this.text_25.setTransform(386,97.6,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_22.setTransform(388.4,153.9,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_23.setTransform(389,346.1,0.5,0.5);

	this.text_26 = new cjs.Text("-2", "21px Verdana");
	this.text_26.lineHeight = 25;
	this.text_26.setTransform(373.1,149.2,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_24.setTransform(388.9,185.9,0.5,0.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_25.setTransform(388.8,378,0.5,0.5);

	this.text_27 = new cjs.Text("-4", "21px Verdana");
	this.text_27.lineHeight = 25;
	this.text_27.setTransform(372.9,181,0.5,0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_26.setTransform(388.2,250,0.5,0.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_27.setTransform(388.2,217.7,0.5,0.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_28.setTransform(388.2,281.9,0.5,0.5);

	this.text_28 = new cjs.Text("0", "21px Verdana");
	this.text_28.lineHeight = 25;
	this.text_28.setTransform(381.1,116.2,0.5,0.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAAAAIgbAaIgMgNIAngmIAoAmIgMANg");
	this.shape_29.setTransform(391.1,26.4,0.5,0.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_30.setTransform(391.1,218,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.text_28},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.text_27},{t:this.shape_25},{t:this.shape_24},{t:this.text_26},{t:this.shape_23},{t:this.shape_22},{t:this.text_25},{t:this.shape_21},{t:this.text_24},{t:this.shape_20},{t:this.text_23},{t:this.shape_19},{t:this.text_22},{t:this.shape_18},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.shape_17},{t:this.text_17},{t:this.text_16},{t:this.text_15}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.2,-23.9,692.8,452.1);

(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,478,10);


(lib.mc_pantalla2_scn4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// text
	this.treball_01_scn4 = new cjs.Text("", "20px Verdana");
	this.treball_01_scn4.lineHeight = 22;
	this.treball_01_scn4.lineWidth = 280;
	this.treball_01_scn4.setTransform(-4.2,-23.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.treball_01_scn4}]}).wait(50));

	// EJE ORI
	this.text = new cjs.Text("X", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 17;
	this.text.setTransform(667.8,270.3);

	this.text_1 = new cjs.Text("16", "21px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(640.9,310.8,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg2IAABt");
	this.shape.setTransform(647.3,307.6,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_1.setTransform(551.5,307.4,0.5,0.5);

	this.text_2 = new cjs.Text("10", "21px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.setTransform(544.9,310.8,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_2.setTransform(615.7,307.7,0.5,0.5);

	this.text_3 = new cjs.Text("14", "21px Verdana");
	this.text_3.lineHeight = 25;
	this.text_3.setTransform(608.9,311.3,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(583.2,307.8,0.5,0.5);

	this.text_4 = new cjs.Text("12", "21px Verdana");
	this.text_4.lineHeight = 25;
	this.text_4.setTransform(576.4,310.8,0.5,0.5);

	this.text_5 = new cjs.Text("-8", "21px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 25;
	this.text_5.setTransform(268,311.8,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(231.3,307.6,0.5,0.5);

	this.text_6 = new cjs.Text("-10", "21px Verdana");
	this.text_6.lineHeight = 25;
	this.text_6.setTransform(219.9,312,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(519.1,307.4,0.5,0.5);

	this.text_7 = new cjs.Text("8", "21px Verdana");
	this.text_7.lineHeight = 25;
	this.text_7.setTransform(515.9,311.8,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(423.3,307.9,0.5,0.5);

	this.text_8 = new cjs.Text("2", "21px Verdana");
	this.text_8.lineHeight = 25;
	this.text_8.setTransform(419.9,311.8,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(295.3,307.8,0.5,0.5);

	this.text_9 = new cjs.Text("-6", "21px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 25;
	this.text_9.setTransform(300,311.8,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(359.8,307.9,0.5,0.5);

	this.text_10 = new cjs.Text("-2", "21px Verdana");
	this.text_10.lineHeight = 25;
	this.text_10.setTransform(351.6,312.3,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(487.5,307.4,0.5,0.5);

	this.text_11 = new cjs.Text("6", "21px Verdana");
	this.text_11.lineHeight = 25;
	this.text_11.setTransform(483.9,311.5,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(263.4,307.9,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(328.3,307.7,0.5,0.5);

	this.text_12 = new cjs.Text("-4", "21px Verdana");
	this.text_12.lineHeight = 25;
	this.text_12.setTransform(320.1,312.2,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_12.setTransform(455,307.7,0.5,0.5);

	this.text_13 = new cjs.Text("4", "21px Verdana");
	this.text_13.lineHeight = 25;
	this.text_13.setTransform(451.4,311.8,0.5,0.5);

	this.text_14 = new cjs.Text("0", "21px Verdana");
	this.text_14.lineHeight = 25;
	this.text_14.setTransform(394.2,308.4,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_13.setTransform(681.2,305.3,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_14.setTransform(445.1,305.3,0.5,0.5);

	this.instance = new lib.Mapadebits2();
	this.instance.setTransform(207.1,300.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.text_14},{t:this.text_13},{t:this.shape_12},{t:this.text_12},{t:this.shape_11},{t:this.shape_10},{t:this.text_11},{t:this.shape_9},{t:this.text_10},{t:this.shape_8},{t:this.text_9},{t:this.shape_7},{t:this.text_8},{t:this.shape_6},{t:this.text_7},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.text_3},{t:this.shape_2},{t:this.text_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text}]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.text_14},{t:this.text_13},{t:this.shape_12},{t:this.text_12},{t:this.shape_11},{t:this.shape_10},{t:this.text_11},{t:this.shape_9},{t:this.text_10},{t:this.shape_8},{t:this.text_9},{t:this.shape_7},{t:this.text_8},{t:this.shape_6},{t:this.text_7},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.text_3},{t:this.shape_2},{t:this.text_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text},{t:this.instance}]},49).wait(1));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhDdBQgyABAAgyMAAAg4fQAAgyAyABICHAAQAygBAAAyMAAAA4fQAAAygygBg");
	var mask_graphics_1 = new cjs.Graphics().p("AhTdBQg+ABAAgyMAAAg4fQAAgyA+ABICnAAQA+gBAAAyMAAAA4fQAAAyg+gBg");
	var mask_graphics_2 = new cjs.Graphics().p("AhjdBQhKABAAgyMAAAg4fQAAgyBKABIDHAAQBKgBAAAyMAAAA4fQAAAyhKgBg");
	var mask_graphics_3 = new cjs.Graphics().p("AhzdBQhVABAAgyMAAAg4fQAAgyBVABIDnAAQBVgBAAAyMAAAA4fQAAAyhVgBg");
	var mask_graphics_4 = new cjs.Graphics().p("AiDdBQhhABAAgyMAAAg4fQAAgyBhABIEHAAQBhgBAAAyMAAAA4fQAAAyhhgBg");
	var mask_graphics_5 = new cjs.Graphics().p("AiTdBQhtABAAgyMAAAg4fQAAgyBtABIEnAAQBtgBAAAyMAAAA4fQAAAyhtgBg");
	var mask_graphics_6 = new cjs.Graphics().p("AijdBQh5ABAAgyMAAAg4fQAAgyB5ABIFHAAQB5gBAAAyMAAAA4fQAAAyh5gBg");
	var mask_graphics_7 = new cjs.Graphics().p("Ai0dBQiEABAAgyMAAAg4fQAAgyCEABIFoAAQCFgBAAAyMAAAA4fQAAAyiFgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AjEdBQiQABAAgyMAAAg4fQAAgyCQABIGIAAQCRgBAAAyMAAAA4fQAAAyiRgBg");
	var mask_graphics_9 = new cjs.Graphics().p("AjUdBQicABAAgyMAAAg4fQAAgyCcABIGpAAQCcgBAAAyMAAAA4fQAAAyicgBg");
	var mask_graphics_10 = new cjs.Graphics().p("AjkdBQioABAAgyMAAAg4fQAAgyCoABIHJAAQCogBAAAyMAAAA4fQAAAyiogBg");
	var mask_graphics_11 = new cjs.Graphics().p("Aj0dBQi0ABAAgyMAAAg4fQAAgyC0ABIHpAAQC0gBAAAyMAAAA4fQAAAyi0gBg");
	var mask_graphics_12 = new cjs.Graphics().p("AkEdBQi/ABAAgyMAAAg4fQAAgyC/ABIIJAAQC/gBAAAyMAAAA4fQAAAyi/gBg");
	var mask_graphics_13 = new cjs.Graphics().p("AkUdBQjLABAAgyMAAAg4fQAAgyDLABIIpAAQDLgBAAAyMAAAA4fQAAAyjLgBg");
	var mask_graphics_14 = new cjs.Graphics().p("AkkdBQjXABAAgyMAAAg4fQAAgyDXABIJJAAQDXgBAAAyMAAAA4fQAAAyjXgBg");
	var mask_graphics_15 = new cjs.Graphics().p("Ak0dBQjjABAAgyMAAAg4fQAAgyDjABIJpAAQDjgBAAAyMAAAA4fQAAAyjjgBg");
	var mask_graphics_16 = new cjs.Graphics().p("AlEdBQjvABAAgyMAAAg4fQAAgyDvABIKJAAQDvgBAAAyMAAAA4fQAAAyjvgBg");
	var mask_graphics_17 = new cjs.Graphics().p("AlVdBQj6ABAAgyMAAAg4fQAAgyD6ABIKqAAQD7gBAAAyMAAAA4fQAAAyj7gBg");
	var mask_graphics_18 = new cjs.Graphics().p("AlldBQkGABAAgyMAAAg4fQAAgyEGABILKAAQEHgBAAAyMAAAA4fQAAAykHgBg");
	var mask_graphics_19 = new cjs.Graphics().p("Al1dBQkSABAAgyMAAAg4fQAAgyESABILqAAQETgBAAAyMAAAA4fQAAAykTgBg");
	var mask_graphics_20 = new cjs.Graphics().p("AmFdBQkeABAAgyMAAAg4fQAAgyEeABIMLAAQEegBAAAyMAAAA4fQAAAykegBg");
	var mask_graphics_21 = new cjs.Graphics().p("AmVdBQkpABAAgyMAAAg4fQAAgyEpABIMrAAQEpgBAAAyMAAAA4fQAAAykpgBg");
	var mask_graphics_22 = new cjs.Graphics().p("AmldBQk1ABAAgyMAAAg4fQAAgyE1ABINLAAQE1gBAAAyMAAAA4fQAAAyk1gBg");
	var mask_graphics_23 = new cjs.Graphics().p("Am1dBQlBABAAgyMAAAg4fQAAgyFBABINrAAQFBgBAAAyMAAAA4fQAAAylBgBg");
	var mask_graphics_24 = new cjs.Graphics().p("AnFdBQlNABAAgyMAAAg4fQAAgyFNABIOLAAQFNgBAAAyMAAAA4fQAAAylNgBg");
	var mask_graphics_25 = new cjs.Graphics().p("AnVdBQlZABAAgyMAAAg4fQAAgyFZABIOrAAQFZgBAAAyMAAAA4fQAAAylZgBg");
	var mask_graphics_26 = new cjs.Graphics().p("AnmdBQlkABAAgyMAAAg4fQAAgyFkABIPMAAQFlgBAAAyMAAAA4fQAAAyllgBg");
	var mask_graphics_27 = new cjs.Graphics().p("An2dBQlwABAAgyMAAAg4fQAAgyFwABIPsAAQFxgBAAAyMAAAA4fQAAAylxgBg");
	var mask_graphics_28 = new cjs.Graphics().p("AoGdBQl8ABAAgyMAAAg4fQAAgyF8ABIQMAAQF9gBAAAyMAAAA4fQAAAyl9gBg");
	var mask_graphics_29 = new cjs.Graphics().p("AoWdBQmIABAAgyMAAAg4fQAAgyGIABIQsAAQGJgBAAAyMAAAA4fQAAAymJgBg");
	var mask_graphics_30 = new cjs.Graphics().p("AomdBQmTABAAgyMAAAg4fQAAgyGTABIRNAAQGUgBAAAyMAAAA4fQAAAymUgBg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:300,y:202.5}).wait(1).to({graphics:mask_graphics_1,x:302.8,y:202.5}).wait(1).to({graphics:mask_graphics_2,x:305.6,y:202.5}).wait(1).to({graphics:mask_graphics_3,x:308.3,y:202.5}).wait(1).to({graphics:mask_graphics_4,x:311.1,y:202.5}).wait(1).to({graphics:mask_graphics_5,x:313.9,y:202.5}).wait(1).to({graphics:mask_graphics_6,x:316.7,y:202.5}).wait(1).to({graphics:mask_graphics_7,x:319.5,y:202.5}).wait(1).to({graphics:mask_graphics_8,x:322.3,y:202.5}).wait(1).to({graphics:mask_graphics_9,x:325.1,y:202.5}).wait(1).to({graphics:mask_graphics_10,x:327.9,y:202.5}).wait(1).to({graphics:mask_graphics_11,x:330.7,y:202.5}).wait(1).to({graphics:mask_graphics_12,x:333.4,y:202.5}).wait(1).to({graphics:mask_graphics_13,x:336.2,y:202.5}).wait(1).to({graphics:mask_graphics_14,x:339,y:202.5}).wait(1).to({graphics:mask_graphics_15,x:341.8,y:202.5}).wait(1).to({graphics:mask_graphics_16,x:344.6,y:202.5}).wait(1).to({graphics:mask_graphics_17,x:347.4,y:202.5}).wait(1).to({graphics:mask_graphics_18,x:350.2,y:202.5}).wait(1).to({graphics:mask_graphics_19,x:353,y:202.5}).wait(1).to({graphics:mask_graphics_20,x:355.8,y:202.5}).wait(1).to({graphics:mask_graphics_21,x:358.5,y:202.5}).wait(1).to({graphics:mask_graphics_22,x:361.3,y:202.5}).wait(1).to({graphics:mask_graphics_23,x:364.1,y:202.5}).wait(1).to({graphics:mask_graphics_24,x:366.9,y:202.5}).wait(1).to({graphics:mask_graphics_25,x:369.7,y:202.5}).wait(1).to({graphics:mask_graphics_26,x:372.5,y:202.5}).wait(1).to({graphics:mask_graphics_27,x:375.3,y:202.5}).wait(1).to({graphics:mask_graphics_28,x:378.1,y:202.5}).wait(1).to({graphics:mask_graphics_29,x:380.9,y:202.5}).wait(1).to({graphics:mask_graphics_30,x:383.7,y:202.5}).wait(20));

	// GRAFICA 1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#00FF00").ss(2.9,0,0,4).p("EgUUgpRQAmFMBDHxQCGPiCTM6QDPSIDKKVQD9M6DpgDQEKgEELtAQDWqaDMyHQCSs+B+vkQA/nxAilM");
	this.shape_15.setTransform(391,159.2,0.5,0.5,0,0,0,0,-0.6);

	this.shape_15.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).wait(50));

	// EJE VERTI
	this.text_15 = new cjs.Text("Y", "20px Verdana");
	this.text_15.lineHeight = 22;
	this.text_15.lineWidth = 17;
	this.text_15.setTransform(391.1,4.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(389,401.5,0.5,0.5);

	this.text_16 = new cjs.Text("-6", "21px Verdana");
	this.text_16.lineHeight = 25;
	this.text_16.setTransform(373.1,397,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_17.setTransform(389.2,48.9,0.5,0.5);

	this.text_17 = new cjs.Text("16", "21px Verdana");
	this.text_17.lineHeight = 25;
	this.text_17.setTransform(372,44.5,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(388.9,81.1,0.5,0.5);

	this.text_18 = new cjs.Text("14", "21px Verdana");
	this.text_18.lineHeight = 25;
	this.text_18.setTransform(371.7,76.6,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_19.setTransform(389.2,113.1,0.5,0.5);

	this.text_19 = new cjs.Text("12", "21px Verdana");
	this.text_19.lineHeight = 25;
	this.text_19.setTransform(372,108.6,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_20.setTransform(388.4,145.4,0.5,0.5);

	this.text_20 = new cjs.Text("10", "21px Verdana");
	this.text_20.lineHeight = 25;
	this.text_20.setTransform(371.6,140.9,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_21.setTransform(389,337.6,0.5,0.5);

	this.text_21 = new cjs.Text("-2", "21px Verdana");
	this.text_21.lineHeight = 25;
	this.text_21.setTransform(373.1,333.2,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhyAA");
	this.shape_22.setTransform(388.9,177.4,0.5,0.5);

	this.text_22 = new cjs.Text("8", "21px Verdana");
	this.text_22.lineHeight = 25;
	this.text_22.setTransform(376.1,172.9,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,0,0,4).p("AA5AAIhxAA");
	this.shape_23.setTransform(388.8,369.5,0.5,0.5);

	this.text_23 = new cjs.Text("-4", "21px Verdana");
	this.text_23.lineHeight = 25;
	this.text_23.setTransform(372.9,365,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_24.setTransform(388.2,241.5,0.5,0.5);

	this.text_24 = new cjs.Text("4", "21px Verdana");
	this.text_24.lineHeight = 25;
	this.text_24.setTransform(376,237,0.5,0.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_25.setTransform(388.2,209.2,0.5,0.5);

	this.text_25 = new cjs.Text("6", "21px Verdana");
	this.text_25.lineHeight = 25;
	this.text_25.setTransform(375.5,204.7,0.5,0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,0,0,4).p("AA6AAIhzAA");
	this.shape_26.setTransform(388.2,273.4,0.5,0.5);

	this.text_26 = new cjs.Text("2", "21px Verdana");
	this.text_26.lineHeight = 25;
	this.text_26.setTransform(376.6,268.9,0.5,0.5);

	this.text_27 = new cjs.Text("0", "21px Verdana");
	this.text_27.lineHeight = 25;
	this.text_27.setTransform(381.9,294.8,0.5,0.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAAAAIgbAaIgMgNIAngmIAoAmIgMANg");
	this.shape_27.setTransform(391.1,26.4,0.5,0.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_28.setTransform(391.1,218,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.text_27},{t:this.text_26},{t:this.shape_26},{t:this.text_25},{t:this.shape_25},{t:this.text_24},{t:this.shape_24},{t:this.text_23},{t:this.shape_23},{t:this.text_22},{t:this.shape_22},{t:this.text_21},{t:this.shape_21},{t:this.text_20},{t:this.shape_20},{t:this.text_19},{t:this.shape_19},{t:this.text_18},{t:this.shape_18},{t:this.text_17},{t:this.shape_17},{t:this.text_16},{t:this.shape_16},{t:this.text_15}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.2,-23.9,692.8,434.1);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AWUMBMgsnAAAIAA4BMAsnAAAg");
	this.shape.setTransform(57.3,15.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,255,255,0.498)").s().p("A2TMBIAA4BMAsnAAAIAAYBg");
	this.shape_1.setTransform(57.3,15.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},1).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_botons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// fons
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AuhkWQg8AAAAA8IAAG1QAAA8A8AAIdDAAQA8AAAAg8IAAm1QAAg8g8AAg");
	this.shape.setTransform(114.7,21.2,1,0.895);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AuhEXQg8AAAAg8IAAm1QAAg8A8AAIdDAAQA8AAAAA8IAAG1QAAA8g8AAg");
	this.shape_1.setTransform(114.7,21.2,1,0.895);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AuhEXQg8AAAAg8IAAm1QAAg8A8AAIdDAAQA8AAAAA8IAAG1QAAA8g8AAg");
	this.shape_2.setTransform(114.7,21.2,1,0.895);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#999999").ss(1,1,1).p("AuhkWQg8AAAAA8IAAG1QAAA8A8AAIdDAAQA8AAAAg8IAAm1QAAg8g8AAg");
	this.shape_3.setTransform(114.7,21.2,1,0.895);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AuhEXQg8AAAAg8IAAm1QAAg8A8AAIdDAAQA8AAAAA8IAAG1QAAA8g8AAg");
	this.shape_4.setTransform(114.7,21.2,1,0.895);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape}]},1).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15.6,-3.7,198.2,50);



(lib.RadioButton_selectedIcon = function() {
	this.initialize();

	// icon
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgTAAQABgSASgBQAUABgBASQABAUgUgBQgSABgBgUg");
	this.shape.setTransform(2,2);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,4,4);


(lib.punts_vermells_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.punts_vermells();
	this.instance.setTransform(170.1,72.4,1,1,0,0,0,170.1,72.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,340.2,144.8);


(lib.grafica_2_scn3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgTdBCIQhkgBAAhjMAAAiBHQAAhkBkAAMAm7AAAQBkAAAABkMAAACBHQAABjhkABg");
	var mask_graphics_1 = new cjs.Graphics().p("EgUIBCIQhngBAAhjMAAAiBHQAAhkBnAAMAoRAAAQBnAAAABkMAAACBHQAABjhnABg");
	var mask_graphics_2 = new cjs.Graphics().p("EgUzBCIQhqgBAAhjMAAAiBHQAAhkBqAAMApnAAAQBqAAAABkMAAACBHQAABjhqABg");
	var mask_graphics_3 = new cjs.Graphics().p("EgVeBCIQhugBAAhjMAAAiBHQAAhkBuAAMAq9AAAQBuAAAABkMAAACBHQAABjhuABg");
	var mask_graphics_4 = new cjs.Graphics().p("EgWIBCIQhygBAAhjMAAAiBHQAAhkByAAMAsRAAAQByAAAABkMAAACBHQAABjhyABg");
	var mask_graphics_5 = new cjs.Graphics().p("EgWzBCIQh2gBAAhjMAAAiBHQAAhkB2AAMAtnAAAQB2AAAABkMAAACBHQAABjh2ABg");
	var mask_graphics_6 = new cjs.Graphics().p("EgXeBCIQh5gBAAhjMAAAiBHQAAhkB5AAMAu9AAAQB5AAAABkMAAACBHQAABjh5ABg");
	var mask_graphics_7 = new cjs.Graphics().p("EgYJBCIQh8gBAAhjMAAAiBHQAAhkB8AAMAwTAAAQB8AAAABkMAAACBHQAABjh8ABg");
	var mask_graphics_8 = new cjs.Graphics().p("EgY0BCIQiAgBAAhjMAAAiBHQAAhkCAAAMAxpAAAQCAAAAABkMAAACBHQAABjiAABg");
	var mask_graphics_9 = new cjs.Graphics().p("EgZfBCIQiDgBAAhjMAAAiBHQAAhkCDAAMAy/AAAQCDAAAABkMAAACBHQAABjiDABg");
	var mask_graphics_10 = new cjs.Graphics().p("EgaKBCIQiGgBAAhjMAAAiBHQAAhkCGAAMA0VAAAQCGAAAABkMAAACBHQAABjiGABg");
	var mask_graphics_11 = new cjs.Graphics().p("Ega1BCIQiKgBAAhjMAAAiBHQAAhkCKAAMA1rAAAQCKAAAABkMAAACBHQAABjiKABg");
	var mask_graphics_12 = new cjs.Graphics().p("EgbgBCIQiNgBAAhjMAAAiBHQAAhkCNAAMA3BAAAQCNAAAABkMAAACBHQAABjiNABg");
	var mask_graphics_13 = new cjs.Graphics().p("EgcLBCIQiRgBAAhjMAAAiBHQAAhkCRAAMA4XAAAQCRAAAABkMAAACBHQAABjiRABg");
	var mask_graphics_14 = new cjs.Graphics().p("Egc2BCIQiUgBAAhjMAAAiBHQAAhkCUAAMA5tAAAQCUAAAABkMAAACBHQAABjiUABg");
	var mask_graphics_15 = new cjs.Graphics().p("EgdhBCIQiXgBAAhjMAAAiBHQAAhkCXAAMA7DAAAQCXAAAABkMAAACBHQAABjiXABg");
	var mask_graphics_16 = new cjs.Graphics().p("EgeMBCIQibgBAAhjMAAAiBHQAAhkCbAAMA8YAAAQCcAAAABkMAAACBHQAABjicABg");
	var mask_graphics_17 = new cjs.Graphics().p("Ege3BCIQiegBAAhjMAAAiBHQAAhkCeAAMA9uAAAQCfAAAABkMAAACBHQAABjifABg");
	var mask_graphics_18 = new cjs.Graphics().p("EgfhBCIQiigBAAhjMAAAiBHQAAhkCiAAMA/DAAAQCiAAAABkMAAACBHQAABjiiABg");
	var mask_graphics_19 = new cjs.Graphics().p("EggMBCIQimgBAAhjMAAAiBHQAAhkCmAAMBAZAAAQCmAAAABkMAAACBHQAABjimABg");
	var mask_graphics_20 = new cjs.Graphics().p("Egg3BCIQipgBAAhjMAAAiBHQAAhkCpAAMBBvAAAQCpAAAABkMAAACBHQAABjipABg");
	var mask_graphics_21 = new cjs.Graphics().p("EghiBCIQitgBAAhjMAAAiBHQAAhkCtAAMBDFAAAQCtAAAABkMAAACBHQAABjitABg");
	var mask_graphics_22 = new cjs.Graphics().p("EgiNBCIQiwgBAAhjMAAAiBHQAAhkCwAAMBEbAAAQCwAAAABkMAAACBHQAABjiwABg");
	var mask_graphics_23 = new cjs.Graphics().p("Egi4BCIQizgBAAhjMAAAiBHQAAhkCzAAMBFxAAAQCzAAAABkMAAACBHQAABjizABg");
	var mask_graphics_24 = new cjs.Graphics().p("EgjjBCIQi3gBAAhjMAAAiBHQAAhkC3AAMBHHAAAQC3AAAABkMAAACBHQAABji3ABg");
	var mask_graphics_25 = new cjs.Graphics().p("EgkOBCIQi6gBAAhjMAAAiBHQAAhkC6AAMBIdAAAQC6AAAABkMAAACBHQAABji6ABg");
	var mask_graphics_26 = new cjs.Graphics().p("Egk5BCIQi9gBAAhjMAAAiBHQAAhkC9AAMBJzAAAQC9AAAABkMAAACBHQAABji9ABg");
	var mask_graphics_27 = new cjs.Graphics().p("EglkBCIQjBgBAAhjMAAAiBHQAAhkDBAAMBLJAAAQDBAAAABkMAAACBHQAABjjBABg");
	var mask_graphics_28 = new cjs.Graphics().p("EgmPBCIQjEgBAAhjMAAAiBHQAAhkDEAAMBMfAAAQDEAAAABkMAAACBHQAABjjEABg");
	var mask_graphics_29 = new cjs.Graphics().p("Egm6BCIQjHgBAAhjMAAAiBHQAAhkDHAAMBN0AAAQDIAAAABkMAAACBHQAABjjIABg");
	var mask_graphics_30 = new cjs.Graphics().p("EgnlBCIQjLgBAAhjMAAAiBHQAAhkDLAAMBPKAAAQDMAAAABkMAAACBHQAABjjMABg");
	var mask_graphics_31 = new cjs.Graphics().p("EgoPBCIQjPgBAAhjMAAAiBHQAAhkDPAAMBQfAAAQDPAAAABkMAAACBHQAABjjPABg");
	var mask_graphics_32 = new cjs.Graphics().p("Ego6BCIQjTgBAAhjMAAAiBHQAAhkDTAAMBR1AAAQDTAAAABkMAAACBHQAABjjTABg");
	var mask_graphics_33 = new cjs.Graphics().p("EgplBCIQjWgBAAhjMAAAiBHQAAhkDWAAMBTLAAAQDWAAAABkMAAACBHQAABjjWABg");
	var mask_graphics_34 = new cjs.Graphics().p("EgqQBCIQjZgBAAhjMAAAiBHQAAhkDZAAMBUhAAAQDZAAAABkMAAACBHQAABjjZABg");
	var mask_graphics_35 = new cjs.Graphics().p("Egq7BCIQjdgBAAhjMAAAiBHQAAhkDdAAMBV3AAAQDdAAAABkMAAACBHQAABjjdABg");
	var mask_graphics_36 = new cjs.Graphics().p("EgrmBCIQjggBAAhjMAAAiBHQAAhkDgAAMBXNAAAQDgAAAABkMAAACBHQAABjjgABg");
	var mask_graphics_37 = new cjs.Graphics().p("EgsRBCIQjjgBAAhjMAAAiBHQAAhkDjAAMBYjAAAQDjAAAABkMAAACBHQAABjjjABg");
	var mask_graphics_38 = new cjs.Graphics().p("Egs8BCIQjngBAAhjMAAAiBHQAAhkDnAAMBZ5AAAQDnAAAABkMAAACBHQAABjjnABg");
	var mask_graphics_39 = new cjs.Graphics().p("EgtnBCIQjqgBAAhjMAAAiBHQAAhkDqAAMBbPAAAQDqAAAABkMAAACBHQAABjjqABg");
	var mask_graphics_40 = new cjs.Graphics().p("EguSBCIQjugBAAhjMAAAiBHQAAhkDuAAMBclAAAQDuAAAABkMAAACBHQAABjjuABg");
	var mask_graphics_41 = new cjs.Graphics().p("Egu9BCIQjxgBAAhjMAAAiBHQAAhkDxAAMBd7AAAQDxAAAABkMAAACBHQAABjjxABg");
	var mask_graphics_42 = new cjs.Graphics().p("EgvoBCIQj0gBAAhjMAAAiBHQAAhkD0AAMBfQAAAQD1AAAABkMAAACBHQAABjj1ABg");
	var mask_graphics_43 = new cjs.Graphics().p("EgwTBCIQj4gBAAhjMAAAiBHQAAhkD4AAMBgmAAAQD5AAAABkMAAACBHQAABjj5ABg");
	var mask_graphics_44 = new cjs.Graphics().p("Egw+BCIQj7gBAAhjMAAAiBHQAAhkD7AAMBh8AAAQD8AAAABkMAAACBHQAABjj8ABg");
	var mask_graphics_45 = new cjs.Graphics().p("EgxoBCIQj/gBAAhjMAAAiBHQAAhkD/AAMBjRAAAQD/AAAABkMAAACBHQAABjj/ABg");
	var mask_graphics_46 = new cjs.Graphics().p("EgyTBCIQkDgBAAhjMAAAiBHQAAhkEDAAMBknAAAQEDAAAABkMAAACBHQAABjkDABg");
	var mask_graphics_47 = new cjs.Graphics().p("Egy+BCIQkGgBAAhjMAAAiBHQAAhkEGAAMBl9AAAQEGAAAABkMAAACBHQAABjkGABg");
	var mask_graphics_48 = new cjs.Graphics().p("EgzpBCIQkKgBAAhjMAAAiBHQAAhkEKAAMBnTAAAQEKAAAABkMAAACBHQAABjkKABg");
	var mask_graphics_49 = new cjs.Graphics().p("Eg0UBCIQkNgBAAhjMAAAiBHQAAhkENAAMBopAAAQENAAAABkMAAACBHQAABjkNABg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg0/BCIQkQgBAAhjMAAAiBHQAAhkEQAAMBp/AAAQEQAAAABkMAAACBHQAABjkQABg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg1qBCIQkUgBAAhjMAAAiBHQAAhkEUAAMBrVAAAQEUAAAABkMAAACBHQAABjkUABg");
	var mask_graphics_52 = new cjs.Graphics().p("Eg2VBCIQkXgBAAhjMAAAiBHQAAhkEXAAMBsrAAAQEXAAAABkMAAACBHQAABjkXABg");
	var mask_graphics_53 = new cjs.Graphics().p("Eg3ABCIQkagBAAhjMAAAiBHQAAhkEaAAMBuBAAAQEaAAAABkMAAACBHQAABjkaABg");
	var mask_graphics_54 = new cjs.Graphics().p("Eg3rBCIQkegBAAhjMAAAiBHQAAhkEeAAMBvWAAAQEfAAAABkMAAACBHQAABjkfABg");
	var mask_graphics_55 = new cjs.Graphics().p("Eg4WBCIQkhgBAAhjMAAAiBHQAAhkEhAAMBwsAAAQEiAAAABkMAAACBHQAABjkiABg");
	var mask_graphics_56 = new cjs.Graphics().p("Eg5BBCIQkkgBAAhjMAAAiBHQAAhkEkAAMByCAAAQElAAAABkMAAACBHQAABjklABg");
	var mask_graphics_57 = new cjs.Graphics().p("Eg5sBCIQkogBAAhjMAAAiBHQAAhkEoAAMBzYAAAQEpAAAABkMAAACBHQAABjkpABg");
	var mask_graphics_58 = new cjs.Graphics().p("Eg6XBCIQkrgBAAhjMAAAiBHQAAhkErAAMB0uAAAQEsAAAABkMAAACBHQAABjksABg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg7BBCIQkwgBAAhjMAAAiBHQAAhkEwAAMB2DAAAQEwAAAABkMAAACBHQAABjkwABg");
	var mask_graphics_60 = new cjs.Graphics().p("Eg7sBCIQkzgBAAhjMAAAiBHQAAhkEzAAMB3ZAAAQEzAAAABkMAAACBHQAABjkzABg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg8XBCIQk2gBAAhjMAAAiBHQAAhkE2AAMB4vAAAQE2AAAABkMAAACBHQAABjk2ABg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg9CBCIQk6gBAAhjMAAAiBHQAAhkE6AAMB6FAAAQE6AAAABkMAAACBHQAABjk6ABg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg9tBCIQk9gBAAhjMAAAiBHQAAhkE9AAMB7bAAAQE9AAAABkMAAACBHQAABjk9ABg");
	var mask_graphics_64 = new cjs.Graphics().p("Eg+YBCIQlAgBAAhjMAAAiBHQAAhkFAAAMB8xAAAQFAAAAABkMAAACBHQAABjlAABg");
	var mask_graphics_65 = new cjs.Graphics().p("Eg/DBCIQlEgBAAhjMAAAiBHQAAhkFEAAMB+HAAAQFEAAAABkMAAACBHQAABjlEABg");
	var mask_graphics_66 = new cjs.Graphics().p("Eg/uBCIQlHgBAAhjMAAAiBHQAAhkFHAAMB/dAAAQFHAAAABkMAAACBHQAABjlHABg");
	var mask_graphics_67 = new cjs.Graphics().p("EhAZBCIQlLgBAAhjMAAAiBHQAAhkFLAAMCAyAAAQFMAAAABkMAAACBHQAABjlMABg");
	var mask_graphics_68 = new cjs.Graphics().p("EhBEBCIQlOgBAAhjMAAAiBHQAAhkFOAAMCCIAAAQFPAAAABkMAAACBHQAABjlPABg");
	var mask_graphics_69 = new cjs.Graphics().p("EhBvBCIQlRgBAAhjMAAAiBHQAAhkFRAAMCDeAAAQFSAAAABkMAAACBHQAABjlSABg");
	var mask_graphics_70 = new cjs.Graphics().p("EhCaBCIQlVgBAAhjMAAAiBHQAAhkFVAAMCE0AAAQFWAAAABkMAAACBHQAABjlWABg");
	var mask_graphics_71 = new cjs.Graphics().p("EhDFBCIQlYgBAAhjMAAAiBHQAAhkFYAAMCGKAAAQFZAAAABkMAAACBHQAABjlZABg");
	var mask_graphics_72 = new cjs.Graphics().p("EhDwBCIQlbgBAAhjMAAAiBHQAAhkFbAAMCHgAAAQFcAAAABkMAAACBHQAABjlcABg");
	var mask_graphics_73 = new cjs.Graphics().p("EhEaBCIQlggBAAhjMAAAiBHQAAhkFgAAMCI1AAAQFgAAAABkMAAACBHQAABjlgABg");
	var mask_graphics_74 = new cjs.Graphics().p("EhFFBCIQljgBAAhjMAAAiBHQAAhkFjAAMCKLAAAQFjAAAABkMAAACBHQAABjljABg");
	var mask_graphics_75 = new cjs.Graphics().p("EhFwBCIQlngBAAhjMAAAiBHQAAhkFnAAMCLhAAAQFnAAAABkMAAACBHQAABjlnABg");
	var mask_graphics_76 = new cjs.Graphics().p("EhGbBCIQlqgBAAhjMAAAiBHQAAhkFqAAMCM3AAAQFqAAAABkMAAACBHQAABjlqABg");
	var mask_graphics_77 = new cjs.Graphics().p("EhHGBCIQltgBAAhjMAAAiBHQAAhkFtAAMCONAAAQFtAAAABkMAAACBHQAABjltABg");
	var mask_graphics_78 = new cjs.Graphics().p("EhHxBCIQlxgBAAhjMAAAiBHQAAhkFxAAMCPjAAAQFxAAAABkMAAACBHQAABjlxABg");
	var mask_graphics_79 = new cjs.Graphics().p("EhIcBCIQl0gBAAhjMAAAiBHQAAhkF0AAMCQ5AAAQF0AAAABkMAAACBHQAABjl0ABg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-72.4,y:407.8}).wait(1).to({graphics:mask_graphics_1,x:-67.8,y:407.8}).wait(1).to({graphics:mask_graphics_2,x:-63.2,y:407.8}).wait(1).to({graphics:mask_graphics_3,x:-58.5,y:407.8}).wait(1).to({graphics:mask_graphics_4,x:-53.9,y:407.8}).wait(1).to({graphics:mask_graphics_5,x:-49.2,y:407.8}).wait(1).to({graphics:mask_graphics_6,x:-44.6,y:407.8}).wait(1).to({graphics:mask_graphics_7,x:-40,y:407.8}).wait(1).to({graphics:mask_graphics_8,x:-35.3,y:407.8}).wait(1).to({graphics:mask_graphics_9,x:-30.7,y:407.8}).wait(1).to({graphics:mask_graphics_10,x:-26.1,y:407.8}).wait(1).to({graphics:mask_graphics_11,x:-21.4,y:407.8}).wait(1).to({graphics:mask_graphics_12,x:-16.8,y:407.8}).wait(1).to({graphics:mask_graphics_13,x:-12.1,y:407.8}).wait(1).to({graphics:mask_graphics_14,x:-7.5,y:407.8}).wait(1).to({graphics:mask_graphics_15,x:-2.9,y:407.8}).wait(1).to({graphics:mask_graphics_16,x:1.7,y:407.8}).wait(1).to({graphics:mask_graphics_17,x:6.3,y:407.8}).wait(1).to({graphics:mask_graphics_18,x:10.9,y:407.8}).wait(1).to({graphics:mask_graphics_19,x:15.6,y:407.8}).wait(1).to({graphics:mask_graphics_20,x:20.2,y:407.8}).wait(1).to({graphics:mask_graphics_21,x:24.9,y:407.8}).wait(1).to({graphics:mask_graphics_22,x:29.5,y:407.8}).wait(1).to({graphics:mask_graphics_23,x:34.1,y:407.8}).wait(1).to({graphics:mask_graphics_24,x:38.8,y:407.8}).wait(1).to({graphics:mask_graphics_25,x:43.4,y:407.8}).wait(1).to({graphics:mask_graphics_26,x:48,y:407.8}).wait(1).to({graphics:mask_graphics_27,x:52.7,y:407.8}).wait(1).to({graphics:mask_graphics_28,x:57.3,y:407.8}).wait(1).to({graphics:mask_graphics_29,x:61.9,y:407.8}).wait(1).to({graphics:mask_graphics_30,x:66.6,y:407.8}).wait(1).to({graphics:mask_graphics_31,x:71.2,y:407.8}).wait(1).to({graphics:mask_graphics_32,x:75.9,y:407.8}).wait(1).to({graphics:mask_graphics_33,x:80.5,y:407.8}).wait(1).to({graphics:mask_graphics_34,x:85.1,y:407.8}).wait(1).to({graphics:mask_graphics_35,x:89.8,y:407.8}).wait(1).to({graphics:mask_graphics_36,x:94.4,y:407.8}).wait(1).to({graphics:mask_graphics_37,x:99,y:407.8}).wait(1).to({graphics:mask_graphics_38,x:103.7,y:407.8}).wait(1).to({graphics:mask_graphics_39,x:108.3,y:407.8}).wait(1).to({graphics:mask_graphics_40,x:113,y:407.8}).wait(1).to({graphics:mask_graphics_41,x:117.6,y:407.8}).wait(1).to({graphics:mask_graphics_42,x:122.2,y:407.8}).wait(1).to({graphics:mask_graphics_43,x:126.9,y:407.8}).wait(1).to({graphics:mask_graphics_44,x:131.5,y:407.8}).wait(1).to({graphics:mask_graphics_45,x:136.1,y:407.8}).wait(1).to({graphics:mask_graphics_46,x:140.8,y:407.8}).wait(1).to({graphics:mask_graphics_47,x:145.4,y:407.8}).wait(1).to({graphics:mask_graphics_48,x:150.1,y:407.8}).wait(1).to({graphics:mask_graphics_49,x:154.7,y:407.8}).wait(1).to({graphics:mask_graphics_50,x:159.3,y:407.8}).wait(1).to({graphics:mask_graphics_51,x:164,y:407.8}).wait(1).to({graphics:mask_graphics_52,x:168.6,y:407.8}).wait(1).to({graphics:mask_graphics_53,x:173.2,y:407.8}).wait(1).to({graphics:mask_graphics_54,x:177.9,y:407.8}).wait(1).to({graphics:mask_graphics_55,x:182.5,y:407.8}).wait(1).to({graphics:mask_graphics_56,x:187.1,y:407.8}).wait(1).to({graphics:mask_graphics_57,x:191.8,y:407.8}).wait(1).to({graphics:mask_graphics_58,x:196.4,y:407.8}).wait(1).to({graphics:mask_graphics_59,x:201.1,y:407.8}).wait(1).to({graphics:mask_graphics_60,x:205.7,y:407.8}).wait(1).to({graphics:mask_graphics_61,x:210.3,y:407.8}).wait(1).to({graphics:mask_graphics_62,x:215,y:407.8}).wait(1).to({graphics:mask_graphics_63,x:219.6,y:407.8}).wait(1).to({graphics:mask_graphics_64,x:224.2,y:407.8}).wait(1).to({graphics:mask_graphics_65,x:228.9,y:407.8}).wait(1).to({graphics:mask_graphics_66,x:233.5,y:407.8}).wait(1).to({graphics:mask_graphics_67,x:238.2,y:407.8}).wait(1).to({graphics:mask_graphics_68,x:242.8,y:407.8}).wait(1).to({graphics:mask_graphics_69,x:247.4,y:407.8}).wait(1).to({graphics:mask_graphics_70,x:252.1,y:407.8}).wait(1).to({graphics:mask_graphics_71,x:256.7,y:407.8}).wait(1).to({graphics:mask_graphics_72,x:261.3,y:407.8}).wait(1).to({graphics:mask_graphics_73,x:266,y:407.8}).wait(1).to({graphics:mask_graphics_74,x:270.6,y:407.8}).wait(1).to({graphics:mask_graphics_75,x:275.3,y:407.8}).wait(1).to({graphics:mask_graphics_76,x:279.9,y:407.8}).wait(1).to({graphics:mask_graphics_77,x:284.5,y:407.8}).wait(1).to({graphics:mask_graphics_78,x:289.2,y:407.8}).wait(1).to({graphics:mask_graphics_79,x:293.8,y:407.8}).wait(1));

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABZAAQAAAkgaAZQgbAagkAAQgjAAgbgaQgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjg");
	this.shape.setTransform(540.9,619.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_1.setTransform(540.9,619.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2.4,0,0,4).p("AA/g9QAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgaQgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZg");
	this.shape_2.setTransform(439.7,619.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_3.setTransform(439.7,619.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2.4,0,0,4).p("ABYAAQAAAkgaAZQgZAaglAAQgkAAgZgaQgagZAAgkQAAgjAagaQAZgaAkAAQAlAAAZAaQAaAaAAAjg");
	this.shape_4.setTransform(218.5,491.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_5.setTransform(218.5,491.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_6.setTransform(540.9,619.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagaQAagZAkAAQAkAAAbAZQAaAaAAAjQAAAkgaAZQgbAagkAAQgjAAgbgag");
	this.shape_7.setTransform(439.7,619.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF001A").s().p("Ag+A9QgagZAAgkQAAgjAagZQAagaAkAAQAkAAAaAaQAaAZAAAjQAAAkgaAZQgaAagkAAQgkAAgagag");
	this.shape_8.setTransform(218.5,491.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#3700D6").ss(5.2,0,0,4).p("Egj+A7VQAck3A1nSQBqumCAsJQC0xBDHpsQD5sKEIAAQEBAAEjISQB1DVCNFKQBaDQCiGdQCqG2BNC4QCMFMBwDTQEZISDxAAQE8AAEfwjQDmtQDJ3JQCQwkBzz4QAOiVALiK");
	this.shape_9.setTransform(397.6,457.7);

	this.instance = new lib.punts_vermells_scn3();
	this.instance.setTransform(379.7,555.5,1,1,0,0,0,170.1,72.4);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_9},{t:this.instance}]},79).wait(1));

	// Capa 1
	this.text = new cjs.Text("X", "36px Verdana");
	this.text.lineHeight = 43;
	this.text.setTransform(855.2,633.9);

	this.text_1 = new cjs.Text("Y", "36px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.setTransform(237.4,111.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(4,0,0,4).p("EhKLAAAMCUXAAA");
	this.shape_10.setTransform(439.2,620.4,0.925,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(4.2,0,0,4).p("EAAABBhMAAAiDB");
	this.shape_11.setTransform(218.7,457,1,0.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.text_1},{t:this.text}]}).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(167.3,77.9,712.6,759.6);


(lib.popup_info = function() {
	this.initialize();

	// Capa 1
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892,37,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.txt_popup_info = new cjs.Text("", "18px Verdana");
	this.txt_popup_info.lineHeight = 20;
	this.txt_popup_info.lineWidth = 775;
	this.txt_popup_info.setTransform(94.2,69.7);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(49.6,50.5,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// imatge
	this.instance_1 = new lib.shutterstock_40047505();
	this.instance_1.setTransform(327,317.9,0.316,0.316);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAu/IgBAAMiSiAAAIgCAAIgBAAIgNgCQgsgGAAg0MAAAhcHQAAg6A8AAMCSiAAAQA6AAABA6MAAABcHQAAA0gsAGIgNACIgBAAg");
	this.shape.setTransform(473.6,298.3,1,1.053);

	this.addChild(this.shape,this.instance_1,this.instance,this.txt_popup_info,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.4,-18.4,950,633.6);


(lib._2fletxes_verdas = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.flecha_verda();
	this.instance.setTransform(100.3,38.3,1,1,9.2,0,0,100.3,8.2);

	this.instance_1 = new lib.flecha_verda();
	this.instance_1.setTransform(100.4,8.1,1,1,0,0,0,100.4,8.1);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,200.9,62.3);


(lib.RadioButton_selectedDownIcon = function() {
	this.initialize();

	// icon
	this.instance = new lib.RadioButton_selectedIcon();
	this.instance.setTransform(7,7,1,1,0,0,0,2,2);

	// highlight
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(204,204,204,0)","rgba(255,255,255,0.298)"],[0,1],-1,3.1,-1,-2.9).s().p("Ag7AeQABgYAPgOIACgDQARgSAYAAQAZAAARASIADADQAOAOAAAYg");
	this.shape.setTransform(7,4);

	// fill
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#0075BF","#009DFF"],[0,0.992],0.3,7.9,0.3,-7.7).s().p("AgwAxQgVgVAAgcQAAgcAVgUQAUgVAcAAQAcAAAVAVQAUAUABAcQgBAcgUAVQgVAUgcABQgcgBgUgUgAgpgpQgSARAAAYQAAAZASARQARARAYAAQAZAAARgRQARgRAAgZQAAgYgRgRQgRgSgZAAQgYAAgRASg");
	this.shape_1.setTransform(7,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#99D7FE","#D9F0FE"],[0,1],-0.9,5.3,-0.9,-6.6).s().p("AgpAqQgSgRAAgZQAAgYASgRQARgSAYAAQAZAAARASQARARAAAYQAAAZgRARQgRARgZAAQgYAAgRgRg");
	this.shape_2.setTransform(7,7);

	this.addChild(this.shape_2,this.shape_1,this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,14,14);


(lib.mc_boton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AgoAAQAAgoAoAAQApAAAAAoQAAApgpAAQgoAAAAgpg");
	this.shape.setTransform(0,0,1.3,1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5B5D5E","#B7BABC"],[0,1],-6.9,0.5,7.7,0.5).s().p("AgwAxQgVgVAAgcQAAgbAVgVQAUgVAcAAQAdAAAUAVQAVAVAAAbQAAAcgVAVQgUAVgdAAQgcAAgUgVgAgpgpQgSARAAAYQAAAZASARQARASAYAAIAAAAIAWgEQAKgDAIgIIADgDQARgRAAgZQAAgYgRgRIgDgDIgJgGIgfgJIAAAAQgYAAgRASg");
	this.shape_1.setTransform(0,0,1.3,1.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(204,204,204,0)","rgba(255,255,255,0.298)"],[0,1],-2.9,-1,3.1,-1).s().p("AgdApQAoAAAAgpQAAgogoAAIAAgTIAeAJIAIAGIADADQASARAAAYQAAAZgSARIgDADQgIAIgIADIgWAEg");
	this.shape_2.setTransform(4,0,1.3,1.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(204,204,204,0.4)","rgba(255,255,255,0.6)"],[0,1],-2.2,-0.9,9.7,-0.9).s().p("AAdA8QgZAAgPgSQgSgRAAgZQAAgYASgRQAPgSAZAAIABAAIAAATQgoAAAAAoQAAApAoAAIAAATg");
	this.shape_3.setTransform(-3.8,0,1.3,1.3);

	this.instance = new lib.RadioButton_selectedIcon();
	this.instance.setTransform(0,0.1,1.405,1.415,90,0,0,2,2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#333333").s().p("AAAAsQgsAAAAgsQAAgrAsAAIAAAAQAtAAgBArQABAsgtAAIAAAAg");
	this.shape_4.setTransform(0,0,1.3,1.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#99D7FE","#D9F0FE"],[0,1],-4.6,-1,8.3,-1).s().p("AgiAtQgTgTAAgaQAAgaATgTQATgSAZAAIAAATIgBAAQgrAAAAAsQAAArArAAIABAAIAAAVQgZAAgTgTgAA1gvIgIgHIAJAHIgBAAg");
	this.shape_5.setTransform(-1.3,0.1,1.3,1.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(204,204,204,0)","rgba(255,255,255,0.298)"],[0,1],-3.2,-1,3.4,-1).s().p("AgfArQAqAAAAgrQAAgsgqAAIAAgTIABAAIABAAIADAAIABAAIAbAJIAIAHIABAAIABACIABAAQATATAAAaQAAAagTATIgBABIgCADQgJAIgJADIgXAEg");
	this.shape_6.setTransform(4.2,0.1,1.3,1.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#0075BF","#009DFF"],[0,0.992],-8.4,0.3,8.6,0.3).s().p("Ag0A1QgXgWAAgfQAAgeAXgWQAWgWAeAAQAfAAAWAWQAXAWAAAeQAAAfgXAWQgWAWgfAAQgeAAgWgWgAgtgtQgTATAAAaQAAAaATATQATATAaAAIAXgEQALgDAJgIIACgDIABgBQATgTAAgaQAAgagTgTIgBAAIgBgCIgJgHIgegJIgBAAIgCAAIgBAAIgBAAQgaAAgTASg");
	this.shape_7.setTransform(0,0.1,1.3,1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-9,18.3,18.2);


(lib.mc_resaltat_fletxes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib._2fletxes_verdas();
	this.instance.setTransform(100.4,31.2,1,1,0,0,0,100.4,31.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:101,x:101,alpha:0.889},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200.9,62.3);


(lib.mc_pantalla5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_65 = new cjs.Graphics().p("AkbXIQgyAAAAgyMAAAgsrQAAgyAyAAII3AAQAyAAAAAyMAAAAsrQAAAygyAAg");
	var mask_graphics_66 = new cjs.Graphics().p("AlCXIQg5AAAAgyMAAAgsrQAAgyA5AAIKFAAQA5AAAAAyMAAAAsrQAAAyg5AAg");
	var mask_graphics_67 = new cjs.Graphics().p("AlpXIQhAAAAAgyMAAAgsrQAAgyBAAAILTAAQBAAAAAAyMAAAAsrQAAAyhAAAg");
	var mask_graphics_68 = new cjs.Graphics().p("AmRXIQhGAAAAgyMAAAgsrQAAgyBGAAIMjAAQBGAAAAAyMAAAAsrQAAAyhGAAg");
	var mask_graphics_69 = new cjs.Graphics().p("Am4XIQhNAAAAgyMAAAgsrQAAgyBNAAINxAAQBNAAAAAyMAAAAsrQAAAyhNAAg");
	var mask_graphics_70 = new cjs.Graphics().p("AnfXIQhVAAAAgyMAAAgsrQAAgyBVAAIO/AAQBVAAAAAyMAAAAsrQAAAyhVAAg");
	var mask_graphics_71 = new cjs.Graphics().p("AoGXIQhcAAAAgyMAAAgsrQAAgyBcAAIQNAAQBcAAAAAyMAAAAsrQAAAyhcAAg");
	var mask_graphics_72 = new cjs.Graphics().p("AouXIQhiAAAAgyMAAAgsrQAAgyBiAAIRdAAQBiAAAAAyMAAAAsrQAAAyhiAAg");
	var mask_graphics_73 = new cjs.Graphics().p("ApVXIQhpAAAAgyMAAAgsrQAAgyBpAAISrAAQBpAAAAAyMAAAAsrQAAAyhpAAg");
	var mask_graphics_74 = new cjs.Graphics().p("Ap8XIQhwAAAAgyMAAAgsrQAAgyBwAAIT5AAQBwAAAAAyMAAAAsrQAAAyhwAAg");
	var mask_graphics_75 = new cjs.Graphics().p("AqjXIQh3AAAAgyMAAAgsrQAAgyB3AAIVHAAQB3AAAAAyMAAAAsrQAAAyh3AAg");
	var mask_graphics_76 = new cjs.Graphics().p("ArLXIQh+AAAAgyMAAAgsrQAAgyB+AAIWXAAQB+AAAAAyMAAAAsrQAAAyh+AAg");
	var mask_graphics_77 = new cjs.Graphics().p("AryXIQiFAAAAgyMAAAgsrQAAgyCFAAIXlAAQCFAAAAAyMAAAAsrQAAAyiFAAg");
	var mask_graphics_78 = new cjs.Graphics().p("AsZXIQiMAAAAgyMAAAgsrQAAgyCMAAIYzAAQCMAAAAAyMAAAAsrQAAAyiMAAg");
	var mask_graphics_79 = new cjs.Graphics().p("AtAXIQiTAAAAgyMAAAgsrQAAgyCTAAIaBAAQCTAAAAAyMAAAAsrQAAAyiTAAg");
	var mask_graphics_80 = new cjs.Graphics().p("AtoXIQiZAAAAgyMAAAgsrQAAgyCZAAIbRAAQCZAAAAAyMAAAAsrQAAAyiZAAg");
	var mask_graphics_81 = new cjs.Graphics().p("AuPXIQigAAAAgyMAAAgsrQAAgyCgAAIcfAAQCgAAAAAyMAAAAsrQAAAyigAAg");
	var mask_graphics_82 = new cjs.Graphics().p("Au2XIQioAAAAgyMAAAgsrQAAgyCoAAIdtAAQCoAAAAAyMAAAAsrQAAAyioAAg");
	var mask_graphics_83 = new cjs.Graphics().p("AvdXIQivAAAAgyMAAAgsrQAAgyCvAAIe7AAQCvAAAAAyMAAAAsrQAAAyivAAg");
	var mask_graphics_84 = new cjs.Graphics().p("AwFXIQi1AAAAgyMAAAgsrQAAgyC1AAMAgLAAAQC1AAAAAyMAAAAsrQAAAyi1AAg");
	var mask_graphics_85 = new cjs.Graphics().p("AwsXIQi8AAAAgyMAAAgsrQAAgyC8AAMAhZAAAQC8AAAAAyMAAAAsrQAAAyi8AAg");
	var mask_graphics_86 = new cjs.Graphics().p("AxTXIQjDAAAAgyMAAAgsrQAAgyDDAAMAinAAAQDDAAAAAyMAAAAsrQAAAyjDAAg");
	var mask_graphics_87 = new cjs.Graphics().p("Ax6XIQjKAAAAgyMAAAgsrQAAgyDKAAMAj1AAAQDKAAAAAyMAAAAsrQAAAyjKAAg");
	var mask_graphics_88 = new cjs.Graphics().p("AyiXIQjRAAAAgyMAAAgsrQAAgyDRAAMAlFAAAQDRAAAAAyMAAAAsrQAAAyjRAAg");
	var mask_graphics_89 = new cjs.Graphics().p("AzJXIQjYAAAAgyMAAAgsrQAAgyDYAAMAmTAAAQDYAAAAAyMAAAAsrQAAAyjYAAg");
	var mask_graphics_90 = new cjs.Graphics().p("AzwXIQjfAAAAgyMAAAgsrQAAgyDfAAMAnhAAAQDfAAAAAyMAAAAsrQAAAyjfAAg");
	var mask_graphics_91 = new cjs.Graphics().p("A0XXIQjmAAAAgyMAAAgsrQAAgyDmAAMAovAAAQDmAAAAAyMAAAAsrQAAAyjmAAg");
	var mask_graphics_92 = new cjs.Graphics().p("A0/XIQjsAAAAgyMAAAgsrQAAgyDsAAMAp/AAAQDsAAAAAyMAAAAsrQAAAyjsAAg");
	var mask_graphics_93 = new cjs.Graphics().p("A1mXIQjzAAAAgyMAAAgsrQAAgyDzAAMArNAAAQDzAAAAAyMAAAAsrQAAAyjzAAg");
	var mask_graphics_94 = new cjs.Graphics().p("A2NXIQj7AAAAgyMAAAgsrQAAgyD7AAMAsbAAAQD7AAAAAyMAAAAsrQAAAyj7AAg");
	var mask_graphics_95 = new cjs.Graphics().p("A20XIQkCAAAAgyMAAAgsrQAAgyECAAMAtpAAAQECAAAAAyMAAAAsrQAAAykCAAg");
	var mask_graphics_96 = new cjs.Graphics().p("A3cXIQkIAAAAgyMAAAgsrQAAgyEIAAMAu5AAAQEIAAAAAyMAAAAsrQAAAykIAAg");
	var mask_graphics_97 = new cjs.Graphics().p("A4DXIQkPAAAAgyMAAAgsrQAAgyEPAAMAwHAAAQEPAAAAAyMAAAAsrQAAAykPAAg");
	var mask_graphics_98 = new cjs.Graphics().p("A4qXIQkWAAAAgyMAAAgsrQAAgyEWAAMAxVAAAQEWAAAAAyMAAAAsrQAAAykWAAg");
	var mask_graphics_99 = new cjs.Graphics().p("A5RXIQkdAAAAgyMAAAgsrQAAgyEdAAMAyjAAAQEdAAAAAyMAAAAsrQAAAykdAAg");
	var mask_graphics_100 = new cjs.Graphics().p("A55XIQkkAAAAgyMAAAgsrQAAgyEkAAMAzzAAAQEkAAAAAyMAAAAsrQAAAykkAAg");
	var mask_graphics_101 = new cjs.Graphics().p("A6gXIQkrAAAAgyMAAAgsrQAAgyErAAMA1BAAAQErAAAAAyMAAAAsrQAAAykrAAg");
	var mask_graphics_102 = new cjs.Graphics().p("A7HXIQkyAAAAgyMAAAgsrQAAgyEyAAMA2PAAAQEyAAAAAyMAAAAsrQAAAykyAAg");
	var mask_graphics_103 = new cjs.Graphics().p("A7uXIQk5AAAAgyMAAAgsrQAAgyE5AAMA3dAAAQE5AAAAAyMAAAAsrQAAAyk5AAg");
	var mask_graphics_104 = new cjs.Graphics().p("A8WXIQk/AAAAgyMAAAgsrQAAgyE/AAMA4tAAAQE/AAAAAyMAAAAsrQAAAyk/AAg");
	var mask_graphics_105 = new cjs.Graphics().p("A89XIQlGAAAAgyMAAAgsrQAAgyFGAAMA57AAAQFGAAAAAyMAAAAsrQAAAylGAAg");
	var mask_graphics_106 = new cjs.Graphics().p("A9kXIQlOAAAAgyMAAAgsrQAAgyFOAAMA7JAAAQFOAAAAAyMAAAAsrQAAAylOAAg");
	var mask_graphics_107 = new cjs.Graphics().p("A+LXIQlVAAAAgyMAAAgsrQAAgyFVAAMA8XAAAQFVAAAAAyMAAAAsrQAAAylVAAg");
	var mask_graphics_108 = new cjs.Graphics().p("A+zXIQlbAAAAgyMAAAgsrQAAgyFbAAMA9nAAAQFbAAAAAyMAAAAsrQAAAylbAAg");
	var mask_graphics_109 = new cjs.Graphics().p("A/aXIQliAAAAgyMAAAgsrQAAgyFiAAMA+1AAAQFiAAAAAyMAAAAsrQAAAyliAAg");
	var mask_graphics_110 = new cjs.Graphics().p("EggBAXIQlpAAAAgyMAAAgsrQAAgyFpAAMBADAAAQFpAAAAAyMAAAAsrQAAAylpAAg");
	var mask_graphics_111 = new cjs.Graphics().p("EggoAXIQlwAAAAgyMAAAgsrQAAgyFwAAMBBRAAAQFwAAAAAyMAAAAsrQAAAylwAAg");
	var mask_graphics_112 = new cjs.Graphics().p("EghQAXIQl3AAAAgyMAAAgsrQAAgyF3AAMBChAAAQF3AAAAAyMAAAAsrQAAAyl3AAg");
	var mask_graphics_113 = new cjs.Graphics().p("Egh3AXIQl+AAAAgyMAAAgsrQAAgyF+AAMBDvAAAQF+AAAAAyMAAAAsrQAAAyl+AAg");
	var mask_graphics_114 = new cjs.Graphics().p("EgieAXIQmFAAAAgyMAAAgsrQAAgyGFAAMBE9AAAQGFAAAAAyMAAAAsrQAAAymFAAg");
	var mask_graphics_115 = new cjs.Graphics().p("EgjFAXIQmMAAAAgyMAAAgsrQAAgyGMAAMBGMAAAQGLAAAAAyMAAAAsrQAAAymLAAg");
	var mask_graphics_191 = new cjs.Graphics().p("AqkXIQh4AAAAgyMAAAgsrQAAgyB4AAIVKAAQB3AAAAAyMAAAAsrQAAAyh3AAg");
	var mask_graphics_192 = new cjs.Graphics().p("ArFXIQh+AAAAgyMAAAgsrQAAgyB+AAIWMAAQB9AAAAAyMAAAAsrQAAAyh9AAg");
	var mask_graphics_193 = new cjs.Graphics().p("ArmXIQiDAAAAgyMAAAgsrQAAgyCDAAIXOAAQCCAAAAAyMAAAAsrQAAAyiCAAg");
	var mask_graphics_194 = new cjs.Graphics().p("AsHXIQiJAAAAgyMAAAgsrQAAgyCJAAIYQAAQCIAAAAAyMAAAAsrQAAAyiIAAg");
	var mask_graphics_195 = new cjs.Graphics().p("AsoXIQiPAAAAgyMAAAgsrQAAgyCPAAIZSAAQCOAAAAAyMAAAAsrQAAAyiOAAg");
	var mask_graphics_196 = new cjs.Graphics().p("AtJXIQiVAAAAgyMAAAgsrQAAgyCVAAIaUAAQCUAAAAAyMAAAAsrQAAAyiUAAg");
	var mask_graphics_197 = new cjs.Graphics().p("AtqXIQibAAAAgyMAAAgsrQAAgyCbAAIbWAAQCaAAAAAyMAAAAsrQAAAyiaAAg");
	var mask_graphics_198 = new cjs.Graphics().p("AuLXIQigAAAAgyMAAAgsrQAAgyCgAAIcYAAQCfAAAAAyMAAAAsrQAAAyifAAg");
	var mask_graphics_199 = new cjs.Graphics().p("AusXIQimAAAAgyMAAAgsrQAAgyCmAAIdaAAQClAAAAAyMAAAAsrQAAAyilAAg");
	var mask_graphics_200 = new cjs.Graphics().p("AvNXIQisAAAAgyMAAAgsrQAAgyCsAAIecAAQCrAAAAAyMAAAAsrQAAAyirAAg");
	var mask_graphics_201 = new cjs.Graphics().p("AvuXIQiyAAAAgyMAAAgsrQAAgyCyAAIfeAAQCxAAAAAyMAAAAsrQAAAyixAAg");
	var mask_graphics_202 = new cjs.Graphics().p("AwPXIQi4AAAAgyMAAAgsrQAAgyC4AAMAggAAAQC3AAAAAyMAAAAsrQAAAyi3AAg");
	var mask_graphics_203 = new cjs.Graphics().p("AwwXIQi+AAAAgyMAAAgsrQAAgyC+AAMAhiAAAQC9AAAAAyMAAAAsrQAAAyi9AAg");
	var mask_graphics_204 = new cjs.Graphics().p("AxRXIQjDAAAAgyMAAAgsrQAAgyDDAAMAikAAAQDCAAAAAyMAAAAsrQAAAyjCAAg");
	var mask_graphics_205 = new cjs.Graphics().p("AxyXIQjJAAAAgyMAAAgsrQAAgyDJAAMAjmAAAQDIAAAAAyMAAAAsrQAAAyjIAAg");
	var mask_graphics_206 = new cjs.Graphics().p("AyTXIQjPAAAAgyMAAAgsrQAAgyDPAAMAkoAAAQDOAAAAAyMAAAAsrQAAAyjOAAg");
	var mask_graphics_207 = new cjs.Graphics().p("Ay0XIQjVAAAAgyMAAAgsrQAAgyDVAAMAlqAAAQDUAAAAAyMAAAAsrQAAAyjUAAg");
	var mask_graphics_208 = new cjs.Graphics().p("AzVXIQjbAAAAgyMAAAgsrQAAgyDbAAMAmsAAAQDaAAAAAyMAAAAsrQAAAyjaAAg");
	var mask_graphics_209 = new cjs.Graphics().p("Az2XIQjgAAAAgyMAAAgsrQAAgyDgAAMAnuAAAQDfAAAAAyMAAAAsrQAAAyjfAAg");
	var mask_graphics_210 = new cjs.Graphics().p("A0XXIQjmAAAAgyMAAAgsrQAAgyDmAAMAowAAAQDlAAAAAyMAAAAsrQAAAyjlAAg");
	var mask_graphics_211 = new cjs.Graphics().p("A04XIQjsAAAAgyMAAAgsrQAAgyDsAAMApyAAAQDrAAAAAyMAAAAsrQAAAyjrAAg");
	var mask_graphics_212 = new cjs.Graphics().p("A1ZXIQjyAAAAgyMAAAgsrQAAgyDyAAMAq0AAAQDxAAAAAyMAAAAsrQAAAyjxAAg");
	var mask_graphics_213 = new cjs.Graphics().p("A16XIQj4AAAAgyMAAAgsrQAAgyD4AAMAr2AAAQD3AAAAAyMAAAAsrQAAAyj3AAg");
	var mask_graphics_214 = new cjs.Graphics().p("A2bXIQj+AAAAgyMAAAgsrQAAgyD+AAMAs4AAAQD9AAAAAyMAAAAsrQAAAyj9AAg");
	var mask_graphics_215 = new cjs.Graphics().p("A28XIQkDAAAAgyMAAAgsrQAAgyEDAAMAt6AAAQECAAAAAyMAAAAsrQAAAykCAAg");
	var mask_graphics_216 = new cjs.Graphics().p("A3dXIQkJAAAAgyMAAAgsrQAAgyEJAAMAu8AAAQEIAAAAAyMAAAAsrQAAAykIAAg");
	var mask_graphics_217 = new cjs.Graphics().p("A3+XIQkPAAAAgyMAAAgsrQAAgyEPAAMAv+AAAQEOAAAAAyMAAAAsrQAAAykOAAg");
	var mask_graphics_218 = new cjs.Graphics().p("A4fXIQkVAAAAgyMAAAgsrQAAgyEVAAMAxAAAAQEUAAAAAyMAAAAsrQAAAykUAAg");
	var mask_graphics_219 = new cjs.Graphics().p("A5AXIQkbAAAAgyMAAAgsrQAAgyEbAAMAyCAAAQEaAAAAAyMAAAAsrQAAAykaAAg");
	var mask_graphics_220 = new cjs.Graphics().p("A5hXIQkgAAAAgyMAAAgsrQAAgyEgAAMAzEAAAQEfAAAAAyMAAAAsrQAAAykfAAg");
	var mask_graphics_221 = new cjs.Graphics().p("A6CXIQkmAAAAgyMAAAgsrQAAgyEmAAMA0GAAAQElAAAAAyMAAAAsrQAAAyklAAg");
	var mask_graphics_222 = new cjs.Graphics().p("A6jXIQksAAAAgyMAAAgsrQAAgyEsAAMA1IAAAQErAAAAAyMAAAAsrQAAAykrAAg");
	var mask_graphics_223 = new cjs.Graphics().p("A7EXIQkyAAAAgyMAAAgsrQAAgyEyAAMA2KAAAQExAAAAAyMAAAAsrQAAAykxAAg");
	var mask_graphics_224 = new cjs.Graphics().p("A7lXIQk4AAAAgyMAAAgsrQAAgyE4AAMA3MAAAQE3AAAAAyMAAAAsrQAAAyk3AAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(65).to({graphics:mask_graphics_65,x:125.8,y:142.5}).wait(1).to({graphics:mask_graphics_66,x:130.4,y:142.5}).wait(1).to({graphics:mask_graphics_67,x:135,y:142.5}).wait(1).to({graphics:mask_graphics_68,x:139.6,y:142.5}).wait(1).to({graphics:mask_graphics_69,x:144.2,y:142.5}).wait(1).to({graphics:mask_graphics_70,x:148.9,y:142.5}).wait(1).to({graphics:mask_graphics_71,x:153.5,y:142.5}).wait(1).to({graphics:mask_graphics_72,x:158.1,y:142.5}).wait(1).to({graphics:mask_graphics_73,x:162.7,y:142.5}).wait(1).to({graphics:mask_graphics_74,x:167.3,y:142.5}).wait(1).to({graphics:mask_graphics_75,x:171.9,y:142.5}).wait(1).to({graphics:mask_graphics_76,x:176.6,y:142.5}).wait(1).to({graphics:mask_graphics_77,x:181.2,y:142.5}).wait(1).to({graphics:mask_graphics_78,x:185.8,y:142.5}).wait(1).to({graphics:mask_graphics_79,x:190.4,y:142.5}).wait(1).to({graphics:mask_graphics_80,x:195,y:142.5}).wait(1).to({graphics:mask_graphics_81,x:199.6,y:142.5}).wait(1).to({graphics:mask_graphics_82,x:204.3,y:142.5}).wait(1).to({graphics:mask_graphics_83,x:208.9,y:142.5}).wait(1).to({graphics:mask_graphics_84,x:213.5,y:142.5}).wait(1).to({graphics:mask_graphics_85,x:218.1,y:142.5}).wait(1).to({graphics:mask_graphics_86,x:222.7,y:142.5}).wait(1).to({graphics:mask_graphics_87,x:227.3,y:142.5}).wait(1).to({graphics:mask_graphics_88,x:232,y:142.5}).wait(1).to({graphics:mask_graphics_89,x:236.6,y:142.5}).wait(1).to({graphics:mask_graphics_90,x:241.2,y:142.5}).wait(1).to({graphics:mask_graphics_91,x:245.8,y:142.5}).wait(1).to({graphics:mask_graphics_92,x:250.4,y:142.5}).wait(1).to({graphics:mask_graphics_93,x:255,y:142.5}).wait(1).to({graphics:mask_graphics_94,x:259.7,y:142.5}).wait(1).to({graphics:mask_graphics_95,x:264.3,y:142.5}).wait(1).to({graphics:mask_graphics_96,x:268.9,y:142.5}).wait(1).to({graphics:mask_graphics_97,x:273.5,y:142.5}).wait(1).to({graphics:mask_graphics_98,x:278.1,y:142.5}).wait(1).to({graphics:mask_graphics_99,x:282.7,y:142.5}).wait(1).to({graphics:mask_graphics_100,x:287.4,y:142.5}).wait(1).to({graphics:mask_graphics_101,x:292,y:142.5}).wait(1).to({graphics:mask_graphics_102,x:296.6,y:142.5}).wait(1).to({graphics:mask_graphics_103,x:301.2,y:142.5}).wait(1).to({graphics:mask_graphics_104,x:305.8,y:142.5}).wait(1).to({graphics:mask_graphics_105,x:310.4,y:142.5}).wait(1).to({graphics:mask_graphics_106,x:315.1,y:142.5}).wait(1).to({graphics:mask_graphics_107,x:319.7,y:142.5}).wait(1).to({graphics:mask_graphics_108,x:324.3,y:142.5}).wait(1).to({graphics:mask_graphics_109,x:328.9,y:142.5}).wait(1).to({graphics:mask_graphics_110,x:333.5,y:142.5}).wait(1).to({graphics:mask_graphics_111,x:338.1,y:142.5}).wait(1).to({graphics:mask_graphics_112,x:342.8,y:142.5}).wait(1).to({graphics:mask_graphics_113,x:347.4,y:142.5}).wait(1).to({graphics:mask_graphics_114,x:352,y:142.5}).wait(1).to({graphics:mask_graphics_115,x:356.6,y:142.5}).wait(76).to({graphics:mask_graphics_191,x:172.1,y:142.5}).wait(1).to({graphics:mask_graphics_192,x:176,y:142.5}).wait(1).to({graphics:mask_graphics_193,x:179.8,y:142.5}).wait(1).to({graphics:mask_graphics_194,x:183.7,y:142.5}).wait(1).to({graphics:mask_graphics_195,x:187.6,y:142.5}).wait(1).to({graphics:mask_graphics_196,x:191.5,y:142.5}).wait(1).to({graphics:mask_graphics_197,x:195.4,y:142.5}).wait(1).to({graphics:mask_graphics_198,x:199.2,y:142.5}).wait(1).to({graphics:mask_graphics_199,x:203.1,y:142.5}).wait(1).to({graphics:mask_graphics_200,x:207,y:142.5}).wait(1).to({graphics:mask_graphics_201,x:210.9,y:142.5}).wait(1).to({graphics:mask_graphics_202,x:214.8,y:142.5}).wait(1).to({graphics:mask_graphics_203,x:218.7,y:142.5}).wait(1).to({graphics:mask_graphics_204,x:222.5,y:142.5}).wait(1).to({graphics:mask_graphics_205,x:226.4,y:142.5}).wait(1).to({graphics:mask_graphics_206,x:230.3,y:142.5}).wait(1).to({graphics:mask_graphics_207,x:234.2,y:142.5}).wait(1).to({graphics:mask_graphics_208,x:238.1,y:142.5}).wait(1).to({graphics:mask_graphics_209,x:241.9,y:142.5}).wait(1).to({graphics:mask_graphics_210,x:245.8,y:142.5}).wait(1).to({graphics:mask_graphics_211,x:249.7,y:142.5}).wait(1).to({graphics:mask_graphics_212,x:253.6,y:142.5}).wait(1).to({graphics:mask_graphics_213,x:257.5,y:142.5}).wait(1).to({graphics:mask_graphics_214,x:261.4,y:142.5}).wait(1).to({graphics:mask_graphics_215,x:265.2,y:142.5}).wait(1).to({graphics:mask_graphics_216,x:269.1,y:142.5}).wait(1).to({graphics:mask_graphics_217,x:273,y:142.5}).wait(1).to({graphics:mask_graphics_218,x:276.9,y:142.5}).wait(1).to({graphics:mask_graphics_219,x:280.8,y:142.5}).wait(1).to({graphics:mask_graphics_220,x:284.6,y:142.5}).wait(1).to({graphics:mask_graphics_221,x:288.5,y:142.5}).wait(1).to({graphics:mask_graphics_222,x:292.4,y:142.5}).wait(1).to({graphics:mask_graphics_223,x:296.3,y:142.5}).wait(1).to({graphics:mask_graphics_224,x:300.2,y:142.5}).wait(26));

	// fletxes
	this.instance = new lib.flecha_verda();
	this.instance.setTransform(377.8,74.6,1,1,0,0,0,100.4,8.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#009933").ss(2,0,0,3.9).p("AOppiIBABLIg7BXAOihEIBABIIg7BYAOiHCIBABKIg7BYAv1IMIfXAAAv1AEIfXAAAv1oWIfXAA");
	this.shape.setTransform(378.8,176.6);

	this.instance_1 = new lib.flecha_verda();
	this.instance_1.setTransform(376.4,230.4,1,1,0,0,0,100.4,8.1);

	this.instance_2 = new lib.flecha_verda();
	this.instance_2.setTransform(376.4,157.5,1,1,-8.9,0,0,100.4,8.1);

	this.instance_3 = new lib.flecha_verda();
	this.instance_3.setTransform(376.2,104.8,1,1,9.2,0,0,100.2,8.2);

	this.instance_4 = new lib.flecha_verda();
	this.instance_4.setTransform(376.4,74.6,1,1,0,0,0,100.4,8.1);

	this.instance_5 = new lib.mc_resaltat_fletxes();
	this.instance_5.setTransform(376.4,97.7,1,1,0,0,0,100.4,31.2);

	this.instance.mask = this.shape.mask = this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.instance_4.mask = this.instance_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.instance,p:{regX:100.4,regY:8.1,rotation:0,x:377.8,y:74.6}}]},65).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance,p:{regX:100.2,regY:8.2,rotation:9.2,x:376.2,y:152.1}}]},126).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance,p:{regX:100.2,regY:8.2,rotation:9.2,x:376.2,y:152.1}},{t:this.instance_5}]},33).wait(26));

	// mascra (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AkbXIQgyAAAAgyMAAAgsrQAAgyAyAAII3AAQAyAAAAAyMAAAAsrQAAAygyAAg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ak5XIQg3AAAAgyMAAAgsrQAAgyA3AAIJzAAQA3AAAAAyMAAAAsrQAAAyg3AAg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AlXXIQg9AAAAgyMAAAgsrQAAgyA9AAIKvAAQA9AAAAAyMAAAAsrQAAAyg9AAg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Al1XIQhCAAAAgyMAAAgsrQAAgyBCAAILrAAQBCAAAAAyMAAAAsrQAAAyhCAAg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AmUXIQhHAAAAgyMAAAgsrQAAgyBHAAIMpAAQBHAAAAAyMAAAAsrQAAAyhHAAg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AmyXIQhMAAAAgyMAAAgsrQAAgyBMAAINlAAQBMAAAAAyMAAAAsrQAAAyhMAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnQXIQhSAAAAgyMAAAgsrQAAgyBSAAIOhAAQBSAAAAAyMAAAAsrQAAAyhSAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AnuXIQhXAAAAgyMAAAgsrQAAgyBXAAIPdAAQBXAAAAAyMAAAAsrQAAAyhXAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AoMXIQhdAAAAgyMAAAgsrQAAgyBdAAIQZAAQBdAAAAAyMAAAAsrQAAAyhdAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AorXIQhhAAAAgyMAAAgsrQAAgyBhAAIRXAAQBhAAAAAyMAAAAsrQAAAyhhAAg");
	var mask_1_graphics_10 = new cjs.Graphics().p("ApJXIQhnAAAAgyMAAAgsrQAAgyBnAAISTAAQBnAAAAAyMAAAAsrQAAAyhnAAg");
	var mask_1_graphics_11 = new cjs.Graphics().p("ApnXIQhsAAAAgyMAAAgsrQAAgyBsAAITPAAQBsAAAAAyMAAAAsrQAAAyhsAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AqFXIQhyAAAAgyMAAAgsrQAAgyByAAIULAAQByAAAAAyMAAAAsrQAAAyhyAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqjXIQh3AAAAgyMAAAgsrQAAgyB3AAIVHAAQB3AAAAAyMAAAAsrQAAAyh3AAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("ArBXIQh9AAAAgyMAAAgsrQAAgyB9AAIWDAAQB9AAAAAyMAAAAsrQAAAyh9AAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArgXIQiBAAAAgyMAAAgsrQAAgyCBAAIXBAAQCBAAAAAyMAAAAsrQAAAyiBAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Ar+XIQiHAAAAgyMAAAgsrQAAgyCHAAIX9AAQCHAAAAAyMAAAAsrQAAAyiHAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AscXIQiMAAAAgyMAAAgsrQAAgyCMAAIY5AAQCMAAAAAyMAAAAsrQAAAyiMAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("As6XIQiSAAAAgyMAAAgsrQAAgyCSAAIZ1AAQCSAAAAAyMAAAAsrQAAAyiSAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AtYXIQiXAAAAgyMAAAgsrQAAgyCXAAIaxAAQCXAAAAAyMAAAAsrQAAAyiXAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("At3XIQicAAAAgyMAAAgsrQAAgyCcAAIbvAAQCcAAAAAyMAAAAsrQAAAyicAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AuVXIQihAAAAgyMAAAgsrQAAgyChAAIcrAAQChAAAAAyMAAAAsrQAAAyihAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AuzXIQinAAAAgyMAAAgsrQAAgyCnAAIdnAAQCnAAAAAyMAAAAsrQAAAyinAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AvRXIQitAAAAgyMAAAgsrQAAgyCtAAIejAAQCtAAAAAyMAAAAsrQAAAyitAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AvvXIQiyAAAAgyMAAAgsrQAAgyCyAAIffAAQCyAAAAAyMAAAAsrQAAAyiyAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AwOXIQi3AAAAgyMAAAgsrQAAgyC3AAMAgdAAAQC3AAAAAyMAAAAsrQAAAyi3AAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AwsXIQi8AAAAgyMAAAgsrQAAgyC8AAMAhZAAAQC8AAAAAyMAAAAsrQAAAyi8AAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AxKXIQjCAAAAgyMAAAgsrQAAgyDCAAMAiVAAAQDCAAAAAyMAAAAsrQAAAyjCAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AxoXIQjHAAAAgyMAAAgsrQAAgyDHAAMAjRAAAQDHAAAAAyMAAAAsrQAAAyjHAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AyGXIQjNAAAAgyMAAAgsrQAAgyDNAAMAkNAAAQDNAAAAAyMAAAAsrQAAAyjNAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AylXIQjRAAAAgyMAAAgsrQAAgyDRAAMAlLAAAQDRAAAAAyMAAAAsrQAAAyjRAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AzDXIQjXAAAAgyMAAAgsrQAAgyDXAAMAmHAAAQDXAAAAAyMAAAAsrQAAAyjXAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AzhXIQjcAAAAgyMAAAgsrQAAgyDcAAMAnDAAAQDcAAAAAyMAAAAsrQAAAyjcAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Az/XIQjiAAAAgyMAAAgsrQAAgyDiAAMAn/AAAQDiAAAAAyMAAAAsrQAAAyjiAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A0dXIQjnAAAAgyMAAAgsrQAAgyDnAAMAo7AAAQDnAAAAAyMAAAAsrQAAAyjnAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A08XIQjsAAAAgyMAAAgsrQAAgyDsAAMAp5AAAQDsAAAAAyMAAAAsrQAAAyjsAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("A1aXIQjxAAAAgyMAAAgsrQAAgyDxAAMAq1AAAQDxAAAAAyMAAAAsrQAAAyjxAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("A14XIQj3AAAAgyMAAAgsrQAAgyD3AAMArxAAAQD3AAAAAyMAAAAsrQAAAyj3AAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A2WXIQj8AAAAgyMAAAgsrQAAgyD8AAMAstAAAQD8AAAAAyMAAAAsrQAAAyj8AAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A20XIQkCAAAAgyMAAAgsrQAAgyECAAMAtpAAAQECAAAAAyMAAAAsrQAAAykCAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3TXIQkGAAAAgyMAAAgsrQAAgyEGAAMAunAAAQEGAAAAAyMAAAAsrQAAAykGAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A3xXIQkMAAAAgyMAAAgsrQAAgyEMAAMAvjAAAQEMAAAAAyMAAAAsrQAAAykMAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A4PXIQkRAAAAgyMAAAgsrQAAgyERAAMAwfAAAQERAAAAAyMAAAAsrQAAAykRAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A4tXIQkXAAAAgyMAAAgsrQAAgyEXAAMAxbAAAQEXAAAAAyMAAAAsrQAAAykXAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A5LXIQkcAAAAgyMAAAgsrQAAgyEcAAMAyXAAAQEcAAAAAyMAAAAsrQAAAykcAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A5qXIQkhAAAAgyMAAAgsrQAAgyEhAAMAzVAAAQEhAAAAAyMAAAAsrQAAAykhAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A6IXIQkmAAAAgyMAAAgsrQAAgyEmAAMA0RAAAQEmAAAAAyMAAAAsrQAAAykmAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A6mXIQksAAAAgyMAAAgsrQAAgyEsAAMA1NAAAQEsAAAAAyMAAAAsrQAAAyksAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A7EXIQkxAAAAgyMAAAgsrQAAgyExAAMA2JAAAQExAAAAAyMAAAAsrQAAAykxAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A7iXIQk3AAAAgyMAAAgsrQAAgyE3AAMA3FAAAQE3AAAAAyMAAAAsrQAAAyk3AAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A8BXIQk7AAAAgyMAAAgsrQAAgyE7AAMA4DAAAQE7AAAAAyMAAAAsrQAAAyk7AAg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A8fXIQlBAAAAgyMAAAgsrQAAgyFBAAMA4/AAAQFBAAAAAyMAAAAsrQAAAylBAAg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A89XIQlGAAAAgyMAAAgsrQAAgyFGAAMA57AAAQFGAAAAAyMAAAAsrQAAAylGAAg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A9bXIQlMAAAAgyMAAAgsrQAAgyFMAAMA63AAAQFMAAAAAyMAAAAsrQAAAylMAAg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A95XIQlRAAAAgyMAAAgsrQAAgyFRAAMA7zAAAQFRAAAAAyMAAAAsrQAAAylRAAg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A+YXIQlWAAAAgyMAAAgsrQAAgyFWAAMA8xAAAQFWAAAAAyMAAAAsrQAAAylWAAg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A+2XIQlbAAAAgyMAAAgsrQAAgyFbAAMA9tAAAQFbAAAAAyMAAAAsrQAAAylbAAg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A/UXIQlhAAAAgyMAAAgsrQAAgyFhAAMA+pAAAQFhAAAAAyMAAAAsrQAAAylhAAg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A/yXIQlmAAAAgyMAAAgsrQAAgyFmAAMA/lAAAQFmAAAAAyMAAAAsrQAAAylmAAg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EggQAXIQlsAAAAgyMAAAgsrQAAgyFsAAMBAhAAAQFsAAAAAyMAAAAsrQAAAylsAAg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EggvAXIQlwAAAAgyMAAAgsrQAAgyFwAAMBBfAAAQFwAAAAAyMAAAAsrQAAAylwAAg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EghNAXIQl2AAAAgyMAAAgsrQAAgyF2AAMBCbAAAQF2AAAAAyMAAAAsrQAAAyl2AAg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EghrAXIQl7AAAAgyMAAAgsrQAAgyF7AAMBDXAAAQF7AAAAAyMAAAAsrQAAAyl7AAg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgiJAXIQmBAAAAgyMAAAgsrQAAgyGBAAMBETAAAQGBAAAAAyMAAAAsrQAAAymBAAg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EginAXIQmGAAAAgyMAAAgsrQAAgyGGAAMBFPAAAQGGAAAAAyMAAAAsrQAAAymGAAg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgjFAXIQmMAAAAgyMAAAgsrQAAgyGMAAMBGMAAAQGLAAAAAyMAAAAsrQAAAymLAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:125.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_1,x:129.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_2,x:132.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_3,x:136.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_4,x:140,y:142.5}).wait(1).to({graphics:mask_1_graphics_5,x:143.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_6,x:147.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_7,x:150.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_8,x:154.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_9,x:157.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_10,x:161.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_11,x:164.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_12,x:168.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_13,x:171.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_14,x:175.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_15,x:179,y:142.5}).wait(1).to({graphics:mask_1_graphics_16,x:182.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_17,x:186.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_18,x:189.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_19,x:193.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_20,x:196.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_21,x:200.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_22,x:203.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_23,x:207.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_24,x:211,y:142.5}).wait(1).to({graphics:mask_1_graphics_25,x:214.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_26,x:218.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_27,x:221.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_28,x:225.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_29,x:228.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_30,x:232.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_31,x:235.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_32,x:239.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_33,x:243,y:142.5}).wait(1).to({graphics:mask_1_graphics_34,x:246.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_35,x:250.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_36,x:253.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_37,x:257.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_38,x:260.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_39,x:264.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_40,x:267.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_41,x:271.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_42,x:274.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_43,x:278.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_44,x:282,y:142.5}).wait(1).to({graphics:mask_1_graphics_45,x:285.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_46,x:289.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_47,x:292.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_48,x:296.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_49,x:299.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_50,x:303.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_51,x:306.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_52,x:310.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_53,x:314,y:142.5}).wait(1).to({graphics:mask_1_graphics_54,x:317.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_55,x:321.1,y:142.5}).wait(1).to({graphics:mask_1_graphics_56,x:324.6,y:142.5}).wait(1).to({graphics:mask_1_graphics_57,x:328.2,y:142.5}).wait(1).to({graphics:mask_1_graphics_58,x:331.7,y:142.5}).wait(1).to({graphics:mask_1_graphics_59,x:335.3,y:142.5}).wait(1).to({graphics:mask_1_graphics_60,x:338.8,y:142.5}).wait(1).to({graphics:mask_1_graphics_61,x:342.4,y:142.5}).wait(1).to({graphics:mask_1_graphics_62,x:345.9,y:142.5}).wait(1).to({graphics:mask_1_graphics_63,x:349.5,y:142.5}).wait(1).to({graphics:mask_1_graphics_64,x:353,y:142.5}).wait(1).to({graphics:mask_1_graphics_65,x:356.6,y:142.5}).wait(185));

	// imatge
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,0,0,3.9).p("AJctMQD7FeAAHuQAAHvj7FeQj7FelhAAQlgAAj7leQj7leAAnvQAAnuD7leQD7leFgAAQFhAAD7Feg");
	this.shape_1.setTransform(505.5,152.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#0000FF").ss(2,0,0,3.9).p("ANXAAQAAHvj7FeQgLAPgMAPQgLAQgNAPQjsEhlBAAQlAAAjskhQgNgPgLgQQgMgPgLgPQiJjAg/jsQgzjCAAjfQAAjeAzjBQA/jtCJjAQC9kJD5hAQBQgVBVAAQBWAABRAVQD4BAC9EJQD7FeAAHug");
	this.shape_2.setTransform(266.5,158.6);

	this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(250));

	// text_imatge
	this.text = new cjs.Text("1\n\n2\n\n3\n\n5", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 27;
	this.text.lineWidth = 100;
	this.text.setTransform(500.4,56.7+incremento);

	this.text_1 = new cjs.Text("0\n\n1\n\n-1\n\n2", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 27;
	this.text_1.lineWidth = 100;
	this.text_1.setTransform(257.3,56.7+incremento);

	this.text_2 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 28;
	this.text_2.setTransform(489.5,-1.5+incremento);

	this.text_3 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 28;
	this.text_3.setTransform(249.3,-1.5+incremento);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(250));

	// mascara (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_150 = new cjs.Graphics().p("Eg7kABjQgyAAAAgzIAAhgQAAgyAyABMB3JAAAQAygBAAAyIAABgQAAAzgyAAg");
	var mask_2_graphics_151 = new cjs.Graphics().p("Eg7kABsQgyAAAAg3IAAhpQAAg3AyAAMB3JAAAQAyAAAAA3IAABpQAAA3gyAAg");
	var mask_2_graphics_152 = new cjs.Graphics().p("Eg7kAB1QgyAAAAg7IAAhzQAAg7AyAAMB3JAAAQAyAAAAA7IAABzQAAA7gyAAg");
	var mask_2_graphics_153 = new cjs.Graphics().p("Eg7kAB/QgyAAAAhBIAAh7QAAhBAyAAMB3JAAAQAyAAAABBIAAB7QAABBgyAAg");
	var mask_2_graphics_154 = new cjs.Graphics().p("Eg7kACIQgyAAAAhFIAAiFQAAhFAyAAMB3JAAAQAyAAAABFIAACFQAABFgyAAg");
	var mask_2_graphics_155 = new cjs.Graphics().p("Eg7kACRQgyAAAAhJIAAiPQAAhJAyAAMB3JAAAQAyAAAABJIAACPQAABJgyAAg");
	var mask_2_graphics_156 = new cjs.Graphics().p("Eg7kACbQgyAAAAhPIAAiXQAAhPAyAAMB3JAAAQAyAAAABPIAACXQAABPgyAAg");
	var mask_2_graphics_157 = new cjs.Graphics().p("Eg7kACkQgyAAAAhTIAAihQAAhTAyAAMB3JAAAQAyAAAABTIAAChQAABTgyAAg");
	var mask_2_graphics_158 = new cjs.Graphics().p("Eg7kACtQgyAAAAhXIAAirQAAhXAyAAMB3JAAAQAyAAAABXIAACrQAABXgyAAg");
	var mask_2_graphics_159 = new cjs.Graphics().p("Eg7kAC3QgyAAAAhdIAAizQAAhdAyAAMB3JAAAQAyAAAABdIAACzQAABdgyAAg");
	var mask_2_graphics_160 = new cjs.Graphics().p("Eg7kADAQgyAAAAhhIAAi9QAAhhAyAAMB3JAAAQAyAAAABhIAAC9QAABhgyAAg");
	var mask_2_graphics_161 = new cjs.Graphics().p("Eg7kADJQgyAAAAhlIAAjGQAAhmAyAAMB3JAAAQAyAAAABmIAADGQAABlgyAAg");
	var mask_2_graphics_162 = new cjs.Graphics().p("Eg7kADTQgyAAAAhrIAAjPQAAhrAyAAMB3JAAAQAyAAAABrIAADPQAABrgyAAg");
	var mask_2_graphics_163 = new cjs.Graphics().p("Eg7kADcQgyAAAAhvIAAjZQAAhvAyAAMB3JAAAQAyAAAABvIAADZQAABvgyAAg");
	var mask_2_graphics_164 = new cjs.Graphics().p("Eg7kADmQgyAAAAh1IAAjhQAAh1AyAAMB3JAAAQAyAAAAB1IAADhQAAB1gyAAg");
	var mask_2_graphics_165 = new cjs.Graphics().p("Eg7kADvQgyAAAAh5IAAjrQAAh5AyAAMB3JAAAQAyAAAAB5IAADrQAAB5gyAAg");
	var mask_2_graphics_166 = new cjs.Graphics().p("Eg7kAD4QgyAAAAh9IAAj1QAAh9AyAAMB3JAAAQAyAAAAB9IAAD1QAAB9gyAAg");
	var mask_2_graphics_167 = new cjs.Graphics().p("Eg7kAECQgyAAAAiDIAAj9QAAiDAyAAMB3JAAAQAyAAAACDIAAD9QAACDgyAAg");
	var mask_2_graphics_168 = new cjs.Graphics().p("Eg7kAELQgyAAAAiHIAAkHQAAiHAyAAMB3JAAAQAyAAAACHIAAEHQAACHgyAAg");
	var mask_2_graphics_169 = new cjs.Graphics().p("Eg7kAEUQgyAAAAiLIAAkQQAAiMAyAAMB3JAAAQAyAAAACMIAAEQQAACLgyAAg");
	var mask_2_graphics_170 = new cjs.Graphics().p("Eg7kAEeQgyAAAAiRIAAkZQAAiRAyAAMB3JAAAQAyAAAACRIAAEZQAACRgyAAg");
	var mask_2_graphics_171 = new cjs.Graphics().p("Eg7kAEnQgyAAAAiVIAAkjQAAiVAyAAMB3JAAAQAyAAAACVIAAEjQAACVgyAAg");
	var mask_2_graphics_172 = new cjs.Graphics().p("Eg7kAEwQgyAAAAiZIAAksQAAiaAyAAMB3JAAAQAyAAAACaIAAEsQAACZgyAAg");
	var mask_2_graphics_173 = new cjs.Graphics().p("Eg7kAE6QgyAAAAifIAAk1QAAifAyAAMB3JAAAQAyAAAACfIAAE1QAACfgyAAg");
	var mask_2_graphics_174 = new cjs.Graphics().p("Eg7kAFDQgyAAAAijIAAk/QAAijAyAAMB3JAAAQAyAAAACjIAAE/QAACjgyAAg");
	var mask_2_graphics_175 = new cjs.Graphics().p("Eg7kAFMQgyAAAAinIAAlIQAAioAyAAMB3JAAAQAyAAAACoIAAFIQAACngyAAg");
	var mask_2_graphics_176 = new cjs.Graphics().p("Eg7kAFWQgyAAAAitIAAlRQAAitAyAAMB3JAAAQAyAAAACtIAAFRQAACtgyAAg");
	var mask_2_graphics_177 = new cjs.Graphics().p("Eg7kAFfQgyAAAAixIAAlaQAAiyAyAAMB3JAAAQAyAAAACyIAAFaQAACxgyAAg");
	var mask_2_graphics_178 = new cjs.Graphics().p("Eg7kAFpQgyAAAAi3IAAljQAAi3AyAAMB3JAAAQAyAAAAC3IAAFjQAAC3gyAAg");
	var mask_2_graphics_179 = new cjs.Graphics().p("Eg7kAFyQgyAAAAi7IAAltQAAi7AyAAMB3JAAAQAyAAAAC7IAAFtQAAC7gyAAg");
	var mask_2_graphics_180 = new cjs.Graphics().p("Eg7kAF7QgyAAAAi/IAAl2QAAjAAyAAMB3JAAAQAyAAAADAIAAF2QAAC/gyAAg");
	var mask_2_graphics_181 = new cjs.Graphics().p("Eg7kAGFQgyAAAAjFIAAl/QAAjFAyAAMB3JAAAQAyAAAADFIAAF/QAADFgyAAg");
	var mask_2_graphics_182 = new cjs.Graphics().p("Eg7kAGOQgyAAAAjJIAAmJQAAjJAyAAMB3JAAAQAyAAAADJIAAGJQAADJgyAAg");
	var mask_2_graphics_183 = new cjs.Graphics().p("Eg7kAGXQgyAAAAjNIAAmSQAAjOAyAAMB3JAAAQAyAAAADOIAAGSQAADNgyAAg");
	var mask_2_graphics_184 = new cjs.Graphics().p("Eg7kAGhQgyAAAAjTIAAmbQAAjTAyAAMB3JAAAQAyAAAADTIAAGbQAADTgyAAg");
	var mask_2_graphics_185 = new cjs.Graphics().p("Eg7kAGqQgyAAAAjXIAAmkQAAjYAyAAMB3JAAAQAyAAAADYIAAGkQAADXgyAAg");
	var mask_2_graphics_186 = new cjs.Graphics().p("Eg7kAGzQgyAAAAjbIAAmuQAAjcAyAAMB3JAAAQAyAAAADcIAAGuQAADbgyAAg");
	var mask_2_graphics_187 = new cjs.Graphics().p("Eg7kAG9QgyAAAAjhIAAm3QAAjhAyAAMB3JAAAQAyAAAADhIAAG3QAADhgyAAg");
	var mask_2_graphics_188 = new cjs.Graphics().p("Eg7kAHGQgyAAAAjlIAAnAQAAjmAyAAMB3JAAAQAyAAAADmIAAHAQAADlgyAAg");
	var mask_2_graphics_189 = new cjs.Graphics().p("Eg7kAHQQgyAAAAjrIAAnJQAAjrAyAAMB3JAAAQAyAAAADrIAAHJQAADrgyAAg");
	var mask_2_graphics_190 = new cjs.Graphics().p("Eg7kAHZQgyAAAAjvIAAnTQAAjvAyAAMB3JAAAQAyAAAADvIAAHTQAADvgyAAg");
	var mask_2_graphics_191 = new cjs.Graphics().p("Eg7kAHiQgyAAAAjzIAAncQAAj0AyAAMB3JAAAQAyAAAAD0IAAHcQAADzgyAAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(150).to({graphics:mask_2_graphics_150,x:385.1,y:288.2}).wait(1).to({graphics:mask_2_graphics_151,x:385.1,y:289.1}).wait(1).to({graphics:mask_2_graphics_152,x:385.1,y:290}).wait(1).to({graphics:mask_2_graphics_153,x:385.1,y:291}).wait(1).to({graphics:mask_2_graphics_154,x:385.1,y:291.9}).wait(1).to({graphics:mask_2_graphics_155,x:385.1,y:292.8}).wait(1).to({graphics:mask_2_graphics_156,x:385.1,y:293.8}).wait(1).to({graphics:mask_2_graphics_157,x:385.1,y:294.7}).wait(1).to({graphics:mask_2_graphics_158,x:385.1,y:295.6}).wait(1).to({graphics:mask_2_graphics_159,x:385.1,y:296.6}).wait(1).to({graphics:mask_2_graphics_160,x:385.1,y:297.5}).wait(1).to({graphics:mask_2_graphics_161,x:385.1,y:298.4}).wait(1).to({graphics:mask_2_graphics_162,x:385.1,y:299.4}).wait(1).to({graphics:mask_2_graphics_163,x:385.1,y:300.3}).wait(1).to({graphics:mask_2_graphics_164,x:385.1,y:301.3}).wait(1).to({graphics:mask_2_graphics_165,x:385.1,y:302.2}).wait(1).to({graphics:mask_2_graphics_166,x:385.1,y:303.1}).wait(1).to({graphics:mask_2_graphics_167,x:385.1,y:304.1}).wait(1).to({graphics:mask_2_graphics_168,x:385.1,y:305}).wait(1).to({graphics:mask_2_graphics_169,x:385.1,y:305.9}).wait(1).to({graphics:mask_2_graphics_170,x:385.1,y:306.9}).wait(1).to({graphics:mask_2_graphics_171,x:385.1,y:307.8}).wait(1).to({graphics:mask_2_graphics_172,x:385.1,y:308.7}).wait(1).to({graphics:mask_2_graphics_173,x:385.1,y:309.7}).wait(1).to({graphics:mask_2_graphics_174,x:385.1,y:310.6}).wait(1).to({graphics:mask_2_graphics_175,x:385.1,y:311.5}).wait(1).to({graphics:mask_2_graphics_176,x:385.1,y:312.5}).wait(1).to({graphics:mask_2_graphics_177,x:385.1,y:313.4}).wait(1).to({graphics:mask_2_graphics_178,x:385.1,y:314.4}).wait(1).to({graphics:mask_2_graphics_179,x:385.1,y:315.3}).wait(1).to({graphics:mask_2_graphics_180,x:385.1,y:316.2}).wait(1).to({graphics:mask_2_graphics_181,x:385.1,y:317.2}).wait(1).to({graphics:mask_2_graphics_182,x:385.1,y:318.1}).wait(1).to({graphics:mask_2_graphics_183,x:385.1,y:319}).wait(1).to({graphics:mask_2_graphics_184,x:385.1,y:320}).wait(1).to({graphics:mask_2_graphics_185,x:385.1,y:320.9}).wait(1).to({graphics:mask_2_graphics_186,x:385.1,y:321.8}).wait(1).to({graphics:mask_2_graphics_187,x:385.1,y:322.8}).wait(1).to({graphics:mask_2_graphics_188,x:385.1,y:323.7}).wait(1).to({graphics:mask_2_graphics_189,x:385.1,y:324.7}).wait(1).to({graphics:mask_2_graphics_190,x:385.1,y:325.6}).wait(1).to({graphics:mask_2_graphics_191,x:385.1,y:326.5}).wait(59));

	// text
	this.treball_05 = new cjs.Text("", "22px Verdana");
	this.treball_05.lineHeight = 24;
	this.treball_05.lineWidth = 769;
	this.treball_05.setTransform(-1.7,298.1);

	this.treball_05.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.treball_05}]},150).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(181,-1.5,410,279.7);


(lib.respuesta = function() {
	this.initialize();

	// Capa 1
	this.boton = new lib.mc_boton();
	this.boton.setTransform(-150.5,0);

	this.texto = new cjs.Text("boton", "20px Verdana");
	this.texto.lineHeight = 22;
	this.texto.lineWidth = 290;
	this.texto.setTransform(-136.5,-13.9);

	this.addChild(this.texto,this.boton);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-159.6,-13.9,317.3,28.3);


(lib.opcion = function() {
	this.initialize();

	// Capa 1
	this.boton = new lib.mc_boton();
	this.boton.setTransform(159.5,0);

	this.texto = new cjs.Text("boton", "20px Verdana");
	this.texto.textAlign = "right";
	this.texto.lineHeight = 22;
	this.texto.lineWidth = 308;
	this.texto.setTransform(141.5,-13.9);

	this.addChild(this.texto,this.boton);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-166.4,-13.9,335.1,28.3);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}