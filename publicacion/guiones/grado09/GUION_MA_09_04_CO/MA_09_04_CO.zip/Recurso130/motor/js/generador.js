Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i = 0; i < Motor.qOperaciones; i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt=EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		//declara variables internas:
		var nAux;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,R,S,T,U,V,W,X,Y,Z;
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var eaP=EA.ini('');
		//onsole.log(eaP);
		co_pregunta.addChild(eaP);
		
		nOK=Random.integer(0,this.qAlternativas-1);
		var sOK,s1,s2,s3;

		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(modelo){
				case 0://DOMINIO RECTA OBLICUA (EN GRÁFICO)
					//sprite de la pregunta:=======================
					PlanoXY.PlanoXY([500,400],30);
					//plano.x=650-plano.width/2;plano.y=350-plano.height/2;
					co_pregunta.addChild(PlanoXY.contenedor);
					m = Random.integer(-6,6,[0]);
					n = Random.integer(-4,4);
					PlanoXY.plot('pol',[n,m],"#ff0000");
					eaP = PlanoXY.contenedor;
					//=============================================
					//sprite de las respuestas:====================
					sOK='(−'+String.fromCharCode(8734)+', '+String.fromCharCode(8734)+')';
					while(true){
						s1=s2=s3='';
						s1+=['(','['][Random.integer(0,1)];
						if(n==0){
							s1+='0';
						}else{
							s1+=['','−'][Random.integer(0,1)];
							s1+=Math.abs(n).toString();
						}
						s1+=', ';
						s1+=['','−'][Random.integer(0,1)];
						s1+=String.fromCharCode(8734);
						s1+=[')',']'][Random.integer(0,1)];
						s2+=['(','['][Random.integer(0,1)];
						if(n==0){
							s2+='0';
						}else{
							s2+=['','−'][Random.integer(0,1)];
							s2+=Math.abs(n).toString();
						}
						s2+=', ';
						s2+=['','−'][Random.integer(0,1)];
						s2+=String.fromCharCode(8734);
						s2+=[')',']'][Random.integer(0,1)];
						s3+=['(','['][Random.integer(0,1)];
						if(n==0){
							s3+='0';
						}else{
							s3+=['','−'][Random.integer(0,1)];
							s3+=Math.abs(n).toString();
						}
						s3+=', ';
						s3+=['','−'][Random.integer(0,1)];
						s3+=String.fromCharCode(8734);
						s3+=[')',']'][Random.integer(0,1)];
						if(JL.sonDistintosTodos([sOK,s1,s2,s3])){break}
					}
					nAux=0;

					for(na=0;na<this.qAlternativas;na++){
						var spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 1://RECORRIDO RECTA OBLICUA (EN ECUACIÓN)
					//sprite de la pregunta:=======================
					m=Random.integer(-6,6);
					//m=0;
					n=Random.integer(-4,4,[0]);
					EA.adcStatic(JL.cursiva('y')+' = ',eaP);
					EA.adcStatic(EA.pol2([n,m],'x',true,true),eaP);
					eaP.y = 35;
					//=============================================
					//sprite de las respuestas:====================
					if(m!=0){
						sOK='('+String.fromCharCode(8722)+String.fromCharCode(8734)+', '+String.fromCharCode(8734)+')';
					}else{
						sOK='{'+JL.num2str(n)+'}';
					}
					if(m!=0){
						while(true){
							s1=s2=s3='';
							s1+=['(','['][Random.integer(0,1)];
							if(n==0){
								s1+='0';
							}else{
								s1+=['',String.fromCharCode(8722)][Random.integer(0,1)];
								s1+=Math.abs(n).toString();
							}
							s1+=', ';
							s1+=['',String.fromCharCode(8722)][Random.integer(0,1)];
							s1+=String.fromCharCode(8734);
							s1+=[')',']'][Random.integer(0,1)];
							s2+=['(','['][Random.integer(0,1)];
							if(n==0){
								s2+='0';
							}else{
								s2+=['',String.fromCharCode(8722)][Random.integer(0,1)];
								s2+=String(Math.abs(n));
							}
							s2+=', ';
							s2+=['',String.fromCharCode(8722)][Random.integer(0,1)];
							s2+=String.fromCharCode(8734);
							s2+=[')',']'][Random.integer(0,1)];
							s3+=['(','['][Random.integer(0,1)];
							if(n==0){
								s3+='0';
							}else{
								s3+=['',String.fromCharCode(8722)][Random.integer(0,1)];
								s3+=Math.abs(n).toString();
							}
							s3+=', ';
							s3+=['',String.fromCharCode(8722)][Random.integer(0,1)];
							s3+=String.fromCharCode(8734);
							s3+=[')',']'][Random.integer(0,1)];
							if(JL.sonDistintosTodos([sOK,s1,s2,s3])){break}
						}
					}else{
						while(true){
							s1=s2=s3='';
							nAux=Random.integer(0,2);
							if(Random.integer(0,1)==0){s1+=['R − ','R + '][Random.integer(0,1)]}
							s1+=['{','[','('][nAux];
							s1+=[JL.num2str(n),'0, '+JL.num2str(n)][Random.integer(0,1)];
							s1+=['}',']',')'][nAux];
							nAux=Random.integer(0,2);
							if(Random.integer(0,1)==0){s2+=['R − ','R + '][Random.integer(0,1)]}
							s2+=['{','[','('][nAux];
							s2+=[JL.num2str(n),'0, '+JL.num2str(n)][Random.integer(0,1)];
							s2+=['}',']',')'][nAux];
							nAux=Random.integer(0,2);
							if(Random.integer(0,1)==0){s3+=['R − ','R + '][Random.integer(0,1)]}
							s3+=['{','[','('][nAux];
							s3+=[JL.num2str(n),'0, '+JL.num2str(n)][Random.integer(0,1)];
							s3+=['}',']',')'][nAux];
							if(JL.sonDistintosTodos([sOK,s1,s2,s3])){break}
						}
					}
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 2://RECORRIDO PARÁBOLA (EN GRÁFICO)
					//sprite de la pregunta:=======================
					PlanoXY.PlanoXY([500,400],30);
					//plano.y=-50
					//plano.x=650-plano.width/2;plano.y=350-plano.height/2;
					co_pregunta.addChild(PlanoXY.contenedor);
					while(true){
						a=Random.integer(-5,5,[0]);
						b=Random.integer(-6,6);
						if((b*b)%(4*a)==0){break}
					}
					c=Random.integer(-4,4);
					PlanoXY.plot('pol',[c,b,a],"#ff0000");
					eaP=PlanoXY.contenedor;
					v=-b*b/(4*a)+c;
					//=============================================
					//sprite de las respuestas:====================
					if(a>0){
						sOK='['+JL.num2str(v)+', +'+String.fromCharCode(8734)+')';
					}else{
						sOK='(−'+String.fromCharCode(8734)+', '+JL.num2str(v)+']';
					}
					var lPosibles = new Array();
					lPosibles.push('(−'+String.fromCharCode(8734)+', '+JL.num2str(-v)+']');
					lPosibles.push('R − {0, '+JL.num2str(v)+'}');
					lPosibles.push('[0, '+JL.num2str(v)+')');
					lPosibles.push('(−'+String.fromCharCode(8734)+', '+String.fromCharCode(8734)+')');
					var lEscogidas = new Array();
					while(lEscogidas.length<3){
						lEscogidas.push(lPosibles.splice(Random.integer(0,lPosibles.length-1),1)[0]);
					}
					s1=lEscogidas[0];
					s2=lEscogidas[1];
					s3=lEscogidas[2];
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 3://DOMINIO PARÁBOLA (EN ECUACIÓN)
					//sprite de la pregunta:=======================
					a=Random.integer(-5,5,[0]);
					b=Random.integer(-6,6);
					c=Random.integer(-4,4);
					EA.adcStatic(JL.cursiva('y')+' = ',eaP);
					EA.adcStatic(EA.pol2([c,b,a],'x',true,true),eaP);
					eaP.y = 35;
					v = Math.floor(-b*b/(4*a)+c);
					//=============================================
					//sprites de las respuestas:====================
					sOK='('+String.fromCharCode(8722)+String.fromCharCode(8734)+', '+String.fromCharCode(8734)+')';
					while(true){
						s1=s2=s3='';
						s1+=['(','['][Random.integer(0,1)];
						s1+=JL.num2str(Random.integer(-3,5));
						s1+=', ';
						s1+=['','−'][Random.integer(0,1)];
						s1+=String.fromCharCode(8734);
						s1+=[')',']'][Random.integer(0,1)];
						s2+=['(','['][Random.integer(0,1)];
						s2+=JL.num2str(Random.integer(-3,5));
						s2+=', ';
						s2+=['','−'][Random.integer(0,1)];
						s2+=String.fromCharCode(8734);
						s2+=[')',']'][Random.integer(0,1)];
						s3+=['(','['][Random.integer(0,1)];
						s3+=JL.num2str(Random.integer(-3,5));
						s3+=', ';
						s3+=['','−'][Random.integer(0,1)];
						s3+=String.fromCharCode(8734);
						s3+=[')',']'][Random.integer(0,1)];
						if(JL.sonDistintosTodos([sOK,s1,s2,s3])){break}
					}
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 4://DOMINIO RACIONAL (EN GRÁFICO)
					//sprite de la pregunta:=======================
					PlanoXY.PlanoXY([500,400],30);
					//plano.y=-50;
					
					//plano.x=650-plano.width/2;plano.y=350-plano.height/2;
					co_pregunta.addChild(PlanoXY.contenedor);
					n=Random.integer(-6,6,[0]);
					d=Random.integer(-5,5);
					PlanoXY.plot('rac',[[n],[d,1]],"#ff0000");
					eaP=PlanoXY.contenedor;
					//=============================================
					//sprites de las respuestas:====================
					sOK='R − {'+JL.num2str(-d)+'}';
					
					s1=s2=s3='';
					e=d+[-1,0,1][Random.integer(0,2)];
					s1+='{'+JL.num2str(e)+', 0}';
					f=d+[-1,0,1][Random.integer(0,2)];
					s2+='['+JL.num2str(Math.abs(f))+', '+JL.num2str(-Math.abs(f))+']';
					g=d+[-1,1][Random.integer(0,1)];
					s3+='R − {'+JL.num2str(-g)+'}';
					
					lAux=JL.barajar([s1,s2,s3]);
					s1=lAux[0];s2=lAux[1];s3=lAux[2];
					
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 5://DOMINIO RACIONAL (EN ECUACIÓN)
					//sprite de la pregunta:=======================
					n=Random.integer(-6,6,[0]);
					d=Random.integer(-5,5);
					EA.adcStatic(JL.cursiva('y')+' = ',eaP);
					eaP.y = 35;
					if(d>0){
						EA.adfStatic(EA.fra(JL.num2str(n),JL.cursiva('x') + ' + ' + Math.abs(d)),eaP);
					}else if(d<0){
						EA.adfStatic(EA.fra(JL.num2str(n),JL.cursiva('x') + ' − ' + Math.abs(d)),eaP);
					}else{
						EA.adfStatic(EA.fra(JL.num2str(n),JL.cursiva('x')),eaP);
					}
					//=============================================
					//sprites de las respuestas:====================
					sOK='R − {'+JL.num2str(-d)+'}';
					
					s1=s2=s3='';
					e=d+[-1,0,1][Random.integer(0,2)];
					s1+='{'+JL.num2str(e)+', 0}';
					f=d+[-1,0,1][Random.integer(0,2)];
					s2+='['+JL.num2str(Math.abs(f))+', '+JL.num2str(-Math.abs(f))+']';
					g=d+[-1,1][Random.integer(0,1)];
					s3+='R − {'+JL.num2str(-g)+'}';
					
					lAux=JL.barajar([s1,s2,s3]);
					s1=lAux[0];s2=lAux[1];s3=lAux[2];
					
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;

			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}