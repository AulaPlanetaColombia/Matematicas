Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i = 0; i < Motor.qOperaciones; i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt=EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		//declara variables internas:
		var nAux;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var A,B,C,D,E,F,G,H,I,J,K,L,M,N,P,Q,R,S,T,U,V,W,X,Y,Z;
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var eaP=EA.ini('');
		//onsole.log(eaP);
		co_pregunta.addChild(eaP);
		
		nOK=Random.integer(0,this.qAlternativas-1);
		var sOK,s1,s2,s3;
		
		
		
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(modelo){
				case 0://CONTINUIDAD RECTA OBLICUA
					//sprite de la pregunta:=======================
					PlanoXY.PlanoXY([500,400],30);
					//plano.x=650-plano.width/2;plano.y=350-plano.height/2;
					co_pregunta.addChild(PlanoXY.contenedor);
					m = Random.integer(-6,6, [0]);
					n = Random.integer(-4,4, [0]);
					PlanoXY.plot('pol',[n,m],"#ff0000");
					eaP = PlanoXY.contenedor;
					//console.log(eaP);
					//=============================================
					//sprite de las respuestas:====================
					sOK='No hay discontinuidades';
                    while(true){
                        var lPosibles = new Array();
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(n));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-n));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(n));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-n));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(n+1));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-n+1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(n+1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-n+1));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(n)+', '+JL.num2str(-n));
                        var lEscogidas = new Array();
                        while(lEscogidas.length<3){
                            lEscogidas.push(lPosibles.splice(Random.integer(0,lPosibles.length-1),1)[0]);
                        }
                        s1=lEscogidas[0];
                        s2=lEscogidas[1];
                        s3=lEscogidas[2];
                        if((s1!=s2)&&(s2!=s3)&&(s1!=s3)&&(sOK!=s1)&&(sOK!=s2)&&(sOK!=s3)){break}
                    }
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						var spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 1://CONTINUIDAD EN PARÁBOLA
					//sprite de la pregunta:=======================
                    PlanoXY.PlanoXY([500,400],30);
                    //plano.x=650-plano.width/2;plano.y=350-plano.height/2;
                    co_pregunta.addChild(PlanoXY.contenedor);
                    //plano.y=-50;
                    while(true){
                        a=Random.integer(-5,5,[0]);
                        b=Random.integer(-6,6);
                        if((b*b)%(4*a)==0){break}
                    }
                    c=Random.integer(-4,4,[0]);
                    PlanoXY.plot('pol',[c,b,a],"#ff0000");
                    eaP=PlanoXY.contenedor;
                    v=-b*b/(4*a)+c;
                    //=============================================
                    //sprite de las respuestas:====================
					sOK='No hay discontinuidades';
                    while(true){
                        lPosibles = new Array();
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(c));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-c));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(c));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-c));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(c)+', '+JL.num2str(-c));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(v));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(v));
                        lEscogidas = new Array();
                        while(lEscogidas.length<3){
                            lEscogidas.push(lPosibles.splice(Random.integer(0,lPosibles.length-1),1)[0]);
                        }
                        s1=lEscogidas[0];
                        s2=lEscogidas[1];
                        s3=lEscogidas[2];
                        if((s1!=s2)&&(s2!=s3)&&(s1!=s3)&&(sOK!=s1)&&(sOK!=s2)&&(sOK!=s3)){break}
                    }
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 2://CONTINUIDAD RACIONAL
                    //sprite de la pregunta:=======================
                    PlanoXY.PlanoXY([500,400],30);
                    //plano.x=650-plano.width/2;plano.y=350-plano.height/2;
                    //plano.y=-50;
                    co_pregunta.addChild(PlanoXY.contenedor);
                    n=Random.integer(-6,6,[0]);
                    d=Random.integer(-5,5);
                    PlanoXY.plot('rac',[[n],[d,1]],"#ff0000");
                    eaP=PlanoXY.contenedor;
                    //=============================================
                    //sprite de las respuestas:====================
                    sOK=JL.cursiva('x')+' = '+JL.num2str(-d);
                    if(d==0){e=1}else{e=d}
                    while(true){
                        lPosibles=new Array();
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(e));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(e));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-e));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(e+1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(e+1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-e+1));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(e-1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(e-1));
                        lPosibles.push(JL.cursiva('x')+' = 0, '+JL.num2str(-e-1));
                        if(d!=0){lPosibles.push(JL.cursiva('x')+' = 0')}
                        lEscogidas=new Array();
                        while(lEscogidas.length<3){
                            lEscogidas.push(lPosibles.splice(Random.integer(0,lPosibles.length-1),1)[0]);
                        }
                        s1=lEscogidas[0];
                        s2=lEscogidas[1];
                        s3=lEscogidas[2];
                        if((s1!=s2)&&(s2!=s3)&&(s1!=s3)&&(sOK!=s1)&&(sOK!=s2)&&(sOK!=s3)){break}
                    }
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
				case 3://CONTINUIDAD RACIONAL II
                    //sprite de la pregunta:=======================
                    PlanoXY.PlanoXY([500,400],20);
                    //plano.x=650-plano.width/2;plano.y=350-plano.height/2;
                    //plano.y=-50;
                    co_pregunta.addChild(PlanoXY.contenedor);
                    n=Random.integer(-3,3,[0]);
                    p=Random.integer(-8,8);
                    q=Random.integer(-8,8,[p]);
                    a=1;
                    b=-p-q;
                    c=p*q;
                    PlanoXY.plot('rac',[[n],[c,b,a]],"#ff0000");
                    eaP=PlanoXY.contenedor;
                    //=============================================
                    //sprite de las respuestas:====================
                    sOK=JL.cursiva('x')+' = '+JL.num2str(p)+', '+JL.num2str(q);
                    while(true){
                        lPosibles=new Array();
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-p)+', '+JL.num2str(-q));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(p)+', '+JL.num2str(-q));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-p)+', '+JL.num2str(q));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(p));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(q));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-p));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-q));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-p)+', '+JL.num2str(-q+1));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(p)+', '+JL.num2str(-q+1));
                        lPosibles.push(JL.cursiva('x')+' = '+JL.num2str(-p)+', '+JL.num2str(q+1));
                        lEscogidas=new Array();
                        while(lEscogidas.length<3){
                            lEscogidas.push(lPosibles.splice(Random.integer(0,lPosibles.length-1),1)[0]);
                        }
                        s1=lEscogidas[0];
                        s2=lEscogidas[1];
                        s3=lEscogidas[2];
                        if((s1!=s2)&&(s2!=s3)&&(s1!=s3)&&(sOK!=s1)&&(sOK!=s2)&&(sOK!=s3)){break}
                    }
					nAux=0;
					for(na=0;na<this.qAlternativas;na++){
						spr=lSP_alts[na];
						if(na==nOK){
							EA.adcStatic(sOK,spr);
						}else{
							EA.adcStatic([s1,s2,s3][nAux++],spr);
						}
					}
				break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
			this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}