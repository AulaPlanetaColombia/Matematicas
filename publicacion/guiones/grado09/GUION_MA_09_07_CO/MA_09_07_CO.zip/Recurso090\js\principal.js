(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

this.entrar = new lib.btnFalse();
	this.entrar.setTransform(475.9,338.4,1.236,1.405,0,0,0,200.6,130.4);
	new cjs.ButtonHelper(this.entrar, 0, 1, 2, false, new lib.btnFalse(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(3).p("A2NTYIB5AEQCaAAClgPQISgvG5i0QJoj8FinhQG7pXAEug");
	this.shape.setTransform(399.4,324.2);

	this.text = new cjs.Text("Y", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 22;
	this.text.setTransform(488.6,168.5);

	this.text_1 = new cjs.Text("X", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 22;
	this.text_1.setTransform(650.5,415.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiHibIEPCbIkOCdg");
	this.shape_1.setTransform(475.7,167.9,0.525,0.416,-89.9,0,0,-0.9,-0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(2).p("Egh3AAAMBDvAAA");
	this.shape_2.setTransform(475.5,344.9,0.794,1,-89.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiHibIEPCbIkOCdg");
	this.shape_3.setTransform(690.9,449.8,0.661,0.416);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(2).p("Egh3AAAMBDvAAA");
	this.shape_4.setTransform(467.6,449.9);

	

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });

 this.entrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.siguiente, this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_1,this.text,this.shape,this.entrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        texto(this, txt['pantalla1'],0,300);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(3).p("A2NTYIB5AEQCaAAClgPQISgvG5i0QJoj8FinhQG7pXAEug");
	this.shape.setTransform(651.2,315.1,0.716,0.716);

	this.text_1 = new cjs.Text("Y", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 22;
	this.text_1.setTransform(715.2,203.5,0.716,0.716);

	this.text_2 = new cjs.Text("X", "bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 22;
	this.text_2.setTransform(831,380.5,0.716,0.716);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiHibIEPCbIkOCdg");
	this.shape_1.setTransform(705.6,203.2,0.376,0.298,-89.9,0,0,-0.6,-1.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(2).p("Egh3AAAMBDvAAA");
	this.shape_2.setTransform(705.7,330,0.568,0.716,-89.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiHibIEPCbIkOCdg");
	this.shape_3.setTransform(859.9,404.9,0.473,0.298,0,0,0,0.6,-0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1D1D1B").ss(2).p("Egh3AAAMBDvAAA");
	this.shape_4.setTransform(700,405.5,0.716,0.716);

	
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.siguiente,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_2,this.text_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         texto(this, txt['pantalla2'],0,300);
this.instance_1 = new lib.reloj();
	this.instance_1.setTransform(872.4,70,0.342,0.342,0,0,0,36,-24.1);

	this.instance_2 = new lib.moneda_Anim();
	this.instance_2.setTransform(630.4,496.4,1,1,0,0,0,32.7,11.3);

	this.instance_3 = new lib.munequitos();
	this.instance_3.setTransform(723.9,269,0.537,0.537,0,0,0,52.5,86);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_3,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      texto(this, txt['pantalla3'],0,300);
this.instance_1 = new lib.ameba();
	this.instance_1.setTransform(735.4,304.1,0.702,0.702,0,0,0,3.1,6.4);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      texto(this, txt['pantalla4'],0,300);
         var html = createDiv(txt['pantalla4'], "Verdana", "20px", '400px', '300px', "20px", "185px", "left");
    this.texto = new lib.fadeText(html, 0);
    this.texto.setTransform(100, 150-608);
    html = createDiv(txt['pantalla4b'], "Verdana", "20px", '400px', '350px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 40);
    this.texto1.setTransform(100, 150-608);
    html = createDiv(txt['pantalla4c'], "Verdana", "20px", '400px', '350px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 80);
    this.texto2.setTransform(100, 150-608);
this.instance_1 = new lib.amebas_anim();
	this.instance_1.setTransform(45.4,158.1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      texto(this, txt['pantalla5'],0,300);
this.instance_1 = new lib.grafica1();
	this.instance_1.setTransform(706.5,347.5,1,1,0,0,0,173.2,199.6);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame7= function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     var html = createDiv(txt['pantalla6'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto = new lib.fadeText(html, 0);
    this.texto.setTransform(100, -480);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        var html = createDiv(txt['pantalla7'], "Verdana", "20px", '400px', '100px', "20px", "185px", "left");
    this.texto = new lib.fadeText(html, 0);
    this.texto.setTransform(100, -480);
	this.instance_1 = new lib.textoAnimado3();
	this.instance_1.setTransform(45.5,154.6);
          this.practica = new lib.btn_practica(txt['txt_boto_practica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);


        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
         this.practica.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior,this.practica,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
       titulo2(this,txt['practicatxt'],"20px");
	this.instance_1 = new lib.shutterstock_92259214();
	this.instance_1.setTransform(165.1,151.8,0.502,0.502);
          this.practica = new lib.btn_practica(txt['txt_boto_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);


        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame8());
        });
         this.practica.on("click", function (evt) {
            putStage(new lib.frame10());
        });
       

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior,this.practica,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
         titulo2(this,txt['practicatxt'],"20px");
       var html = createDiv(txt['soluciontxt'], "Verdana", "20px", '840px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(80, -480);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame8());
        });
         this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
       

        this.addChild(this.logo, this.texto1,this.titulo, this.cerrar, this.anterior,this.practica,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   /* function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

   
   //Simbolillos
   
   (lib._112273517_OPT = function() {
	this.initialize(img._112273517_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,600);


(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_0 = function() {
	this.initialize(img.Image_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_10 = function() {
	this.initialize(img.Image_10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_11 = function() {
	this.initialize(img.Image_11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,72);


(lib.Image_12 = function() {
	this.initialize(img.Image_12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_13 = function() {
	this.initialize(img.Image_13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_14 = function() {
	this.initialize(img.Image_14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,72);


(lib.Image_15 = function() {
	this.initialize(img.Image_15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_16 = function() {
	this.initialize(img.Image_16);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_17 = function() {
	this.initialize(img.Image_17);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,72);


(lib.Image_18 = function() {
	this.initialize(img.Image_18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_19 = function() {
	this.initialize(img.Image_19);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_2 = function() {
	this.initialize(img.Image_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_20 = function() {
	this.initialize(img.Image_20);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_21 = function() {
	this.initialize(img.Image_21);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_22 = function() {
	this.initialize(img.Image_22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_23 = function() {
	this.initialize(img.Image_23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_24 = function() {
	this.initialize(img.Image_24);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_25 = function() {
	this.initialize(img.Image_25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_26 = function() {
	this.initialize(img.Image_26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_27 = function() {
	this.initialize(img.Image_27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,116,226);


(lib.Image_28 = function() {
	this.initialize(img.Image_28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,60,65);


(lib.Image_3 = function() {
	this.initialize(img.Image_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_4 = function() {
	this.initialize(img.Image_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_5 = function() {
	this.initialize(img.Image_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,73);


(lib.Image_6 = function() {
	this.initialize(img.Image_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Image_7 = function() {
	this.initialize(img.Image_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,56,60);


(lib.Image_8 = function() {
	this.initialize(img.Image_8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,72);


(lib.Image_9 = function() {
	this.initialize(img.Image_9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,104,203);


(lib.Mapadebits36 = function() {
	this.initialize(img.Mapadebits36);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,266,303);


(lib.Mapadebits37 = function() {
	this.initialize(img.Mapadebits37);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,213,220);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,367,412);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,367,412);


(lib.Mapadebits5copia = function() {
	this.initialize(img.Mapadebits5copia);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,413,267);


(lib.pastel_OPT = function() {
	this.initialize(img.pastel_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,747,599);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_92259214 = function() {
	this.initialize(img.shutterstock_92259214);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1235,750);


(lib.textoAnimado4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("Eg+egAxMB89AAAIAABjMh89AAAg");
	var mask_graphics_5 = new cjs.Graphics().p("Eg+eABGIAAiLMB89AAAIAACLg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg+eABaIAAizMB89AAAIAACzg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg+eABvIAAjdMB89AAAIAADdg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg+eACDIAAkFMB89AAAIAAEFg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg+eACXIAAktMB89AAAIAAEtg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg+eACrIAAlWMB89AAAIAAFWg");
	var mask_graphics_11 = new cjs.Graphics().p("Eg+eADAIAAl/MB89AAAIAAF/g");
	var mask_graphics_12 = new cjs.Graphics().p("Eg+eADUIAAmnMB89AAAIAAGng");
	var mask_graphics_13 = new cjs.Graphics().p("Eg+eADpIAAnRMB89AAAIAAHRg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg+eAD9IAAn5MB89AAAIAAH5g");
	var mask_graphics_15 = new cjs.Graphics().p("Eg+eAERIAAohMB89AAAIAAIhg");
	var mask_graphics_16 = new cjs.Graphics().p("Eg+eAElIAApKMB89AAAIAAJKg");
	var mask_graphics_17 = new cjs.Graphics().p("Eg+eAE6IAApzMB89AAAIAAJzg");
	var mask_graphics_18 = new cjs.Graphics().p("Eg+eAFOIAAqbMB89AAAIAAKbg");
	var mask_graphics_19 = new cjs.Graphics().p("Eg+dgFhMB8+AAAIAALDMh8+AAAg");
	var mask_graphics_20 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_21 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_22 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_23 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_24 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_25 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_26 = new cjs.Graphics().p("Eg+eAFjIAArFMB89AAAIAALFg");
	var mask_graphics_27 = new cjs.Graphics().p("Eg+dgFhMB8+AAAIAALDMh8+AAAg");
	var mask_graphics_28 = new cjs.Graphics().p("Eg+eAGCIAAsDMB89AAAIAAMDg");
	var mask_graphics_29 = new cjs.Graphics().p("Eg+eAGiIAAtDMB89AAAIAANDg");
	var mask_graphics_30 = new cjs.Graphics().p("Eg+eAHCIAAuDMB89AAAIAAODg");
	var mask_graphics_31 = new cjs.Graphics().p("Eg+eAHiIAAvDMB89AAAIAAPDg");
	var mask_graphics_32 = new cjs.Graphics().p("Eg+eAICIAAwDMB89AAAIAAQDg");
	var mask_graphics_33 = new cjs.Graphics().p("Eg+eAIiIAAxDMB89AAAIAARDg");
	var mask_graphics_34 = new cjs.Graphics().p("Eg+eAJBIAAyBMB89AAAIAASBg");
	var mask_graphics_35 = new cjs.Graphics().p("Eg+eAJhIAAzBMB89AAAIAATBg");
	var mask_graphics_36 = new cjs.Graphics().p("Eg+eAKBIAA0BMB89AAAIAAUBg");
	var mask_graphics_37 = new cjs.Graphics().p("Eg+eAKhIAA1BMB89AAAIAAVBg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg+eALBIAA2BMB89AAAIAAWBg");
	var mask_graphics_39 = new cjs.Graphics().p("Eg+eALhIAA3BMB89AAAIAAXBg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg+eAMAIAA3/MB89AAAIAAX/g");
	var mask_graphics_41 = new cjs.Graphics().p("Eg+dgMfMB8+AAAIAAY/Mh8+AAAg");
	var mask_graphics_42 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_43 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_44 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_45 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_46 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_47 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_48 = new cjs.Graphics().p("Eg+eAMgIAA4/MB89AAAIAAY/g");
	var mask_graphics_49 = new cjs.Graphics().p("Eg+dgMfMB8+AAAIAAY/Mh8+AAAg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg+eAM8IAA53MB89AAAIAAZ3g");
	var mask_graphics_51 = new cjs.Graphics().p("Eg+eANYIAA6vMB89AAAIAAavg");
	var mask_graphics_52 = new cjs.Graphics().p("Eg+eANzIAA7lMB89AAAIAAblg");
	var mask_graphics_53 = new cjs.Graphics().p("Eg+eAOPIAA8dMB89AAAIAAcdg");
	var mask_graphics_54 = new cjs.Graphics().p("Eg+eAOrIAA9VMB89AAAIAAdVg");
	var mask_graphics_55 = new cjs.Graphics().p("Eg+eAPGIAA+LMB89AAAIAAeLg");
	var mask_graphics_56 = new cjs.Graphics().p("Eg+eAPiIAA/DMB89AAAIAAfDg");
	var mask_graphics_57 = new cjs.Graphics().p("Eg+eAP+IAA/7MB89AAAIAAf7g");
	var mask_graphics_58 = new cjs.Graphics().p("Eg+eAQZMAAAggxMB89AAAMAAAAgxg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg+eAQ1MAAAghpMB89AAAMAAAAhpg");
	var mask_graphics_60 = new cjs.Graphics().p("Eg+eARRMAAAgihMB89AAAMAAAAihg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg+eARtMAAAgjZMB89AAAMAAAAjZg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg+dgSHMB8+AAAMAAAAkPMh8+AAAg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_64 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_65 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_66 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_67 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_68 = new cjs.Graphics().p("Eg+eASIMAAAgkPMB89AAAMAAAAkPg");
	var mask_graphics_69 = new cjs.Graphics().p("Eg+dgSHMB8+AAAMAAAAkPMh8+AAAg");
	var mask_graphics_70 = new cjs.Graphics().p("Eg+eASdMAAAgk5MB89AAAMAAAAk5g");
	var mask_graphics_71 = new cjs.Graphics().p("Eg+eASyMAAAgljMB89AAAMAAAAljg");
	var mask_graphics_72 = new cjs.Graphics().p("Eg+eATHMAAAgmNMB89AAAMAAAAmNg");
	var mask_graphics_73 = new cjs.Graphics().p("Eg+eATcMAAAgm3MB89AAAMAAAAm3g");
	var mask_graphics_74 = new cjs.Graphics().p("Eg+eATxMAAAgnhMB89AAAMAAAAnhg");
	var mask_graphics_75 = new cjs.Graphics().p("Eg+eAUGMAAAgoLMB89AAAMAAAAoLg");
	var mask_graphics_76 = new cjs.Graphics().p("Eg+eAUaMAAAgozMB89AAAMAAAAozg");
	var mask_graphics_77 = new cjs.Graphics().p("Eg+eAUvMAAAgpdMB89AAAMAAAApdg");
	var mask_graphics_78 = new cjs.Graphics().p("Eg+eAVEMAAAgqHMB89AAAMAAAAqHg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg+eAVZMAAAgqxMB89AAAMAAAAqxg");
	var mask_graphics_80 = new cjs.Graphics().p("Eg+eAVuMAAAgrbMB89AAAMAAAArbg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg+eAWDMAAAgsFMB89AAAMAAAAsFg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg+eAWYMAAAgsvMB89AAAMAAAAsvg");
	var mask_graphics_83 = new cjs.Graphics().p("Eg+eAWtMAAAgtZMB89AAAMAAAAtZg");
	var mask_graphics_84 = new cjs.Graphics().p("Eg+dgXBMB8+AAAMAAAAuDMh8+AAAg");
	var mask_graphics_85 = new cjs.Graphics().p("Eg+eAXBMAAAguBMB89AAAMAAAAuBg");
	var mask_graphics_86 = new cjs.Graphics().p("Eg+eAXBMAAAguBMB89AAAMAAAAuBg");
	var mask_graphics_87 = new cjs.Graphics().p("Eg+eAXBMAAAguBMB89AAAMAAAAuBg");
	var mask_graphics_88 = new cjs.Graphics().p("Eg+eAXBMAAAguBMB89AAAMAAAAuBg");
	var mask_graphics_89 = new cjs.Graphics().p("Eg+eAXBMAAAguBMB89AAAMAAAAuBg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg+dgXBMB8+AAAMAAAAuDMh8+AAAg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg+eAXPMAAAgudMB89AAAMAAAAudg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg+eAXcMAAAgu3MB89AAAMAAAAu3g");
	var mask_graphics_93 = new cjs.Graphics().p("Eg+eAXpMAAAgvRMB89AAAMAAAAvRg");
	var mask_graphics_94 = new cjs.Graphics().p("Eg+eAX2MAAAgvrMB89AAAMAAAAvrg");
	var mask_graphics_95 = new cjs.Graphics().p("Eg+eAYDMAAAgwFMB89AAAMAAAAwFg");
	var mask_graphics_96 = new cjs.Graphics().p("Eg+eAYQMAAAgwfMB89AAAMAAAAwfg");
	var mask_graphics_97 = new cjs.Graphics().p("Eg+eAYeMAAAgw7MB89AAAMAAAAw7g");
	var mask_graphics_98 = new cjs.Graphics().p("Eg+eAYrMAAAgxVMB89AAAMAAAAxVg");
	var mask_graphics_99 = new cjs.Graphics().p("Eg+eAY4MAAAgxvMB89AAAMAAAAxvg");
	var mask_graphics_100 = new cjs.Graphics().p("Eg+eAZFMAAAgyJMB89AAAMAAAAyJg");
	var mask_graphics_101 = new cjs.Graphics().p("Eg+eAZSMAAAgyjMB89AAAMAAAAyjg");
	var mask_graphics_102 = new cjs.Graphics().p("Eg+eAZfMAAAgy9MB89AAAMAAAAy9g");
	var mask_graphics_103 = new cjs.Graphics().p("Eg+eAZtMAAAgzZMB89AAAMAAAAzZg");
	var mask_graphics_104 = new cjs.Graphics().p("Eg+dgZ5MB8+AAAMAAAAzzMh8+AAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:400.3,y:-11.9}).wait(1).to({graphics:mask_graphics_5,x:400.3,y:-9.9}).wait(1).to({graphics:mask_graphics_6,x:400.3,y:-7.8}).wait(1).to({graphics:mask_graphics_7,x:400.3,y:-5.8}).wait(1).to({graphics:mask_graphics_8,x:400.3,y:-3.8}).wait(1).to({graphics:mask_graphics_9,x:400.3,y:-1.7}).wait(1).to({graphics:mask_graphics_10,x:400.3,y:0.2}).wait(1).to({graphics:mask_graphics_11,x:400.3,y:2.2}).wait(1).to({graphics:mask_graphics_12,x:400.3,y:4.3}).wait(1).to({graphics:mask_graphics_13,x:400.3,y:6.3}).wait(1).to({graphics:mask_graphics_14,x:400.3,y:8.3}).wait(1).to({graphics:mask_graphics_15,x:400.3,y:10.4}).wait(1).to({graphics:mask_graphics_16,x:400.3,y:12.4}).wait(1).to({graphics:mask_graphics_17,x:400.3,y:14.4}).wait(1).to({graphics:mask_graphics_18,x:400.3,y:16.5}).wait(1).to({graphics:mask_graphics_19,x:400.1,y:18.5}).wait(1).to({graphics:mask_graphics_20,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_21,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_22,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_23,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_24,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_25,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_26,x:400.3,y:18.5}).wait(1).to({graphics:mask_graphics_27,x:400.1,y:18.5}).wait(1).to({graphics:mask_graphics_28,x:400.3,y:21.7}).wait(1).to({graphics:mask_graphics_29,x:400.3,y:24.9}).wait(1).to({graphics:mask_graphics_30,x:400.3,y:28.1}).wait(1).to({graphics:mask_graphics_31,x:400.3,y:31.3}).wait(1).to({graphics:mask_graphics_32,x:400.3,y:34.5}).wait(1).to({graphics:mask_graphics_33,x:400.3,y:37.6}).wait(1).to({graphics:mask_graphics_34,x:400.3,y:40.8}).wait(1).to({graphics:mask_graphics_35,x:400.3,y:44}).wait(1).to({graphics:mask_graphics_36,x:400.3,y:47.2}).wait(1).to({graphics:mask_graphics_37,x:400.3,y:50.4}).wait(1).to({graphics:mask_graphics_38,x:400.3,y:53.6}).wait(1).to({graphics:mask_graphics_39,x:400.3,y:56.8}).wait(1).to({graphics:mask_graphics_40,x:400.3,y:60}).wait(1).to({graphics:mask_graphics_41,x:400.1,y:63.2}).wait(1).to({graphics:mask_graphics_42,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_43,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_44,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_45,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_46,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_47,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_48,x:400.3,y:63.2}).wait(1).to({graphics:mask_graphics_49,x:400.1,y:63.2}).wait(1).to({graphics:mask_graphics_50,x:400.3,y:65.9}).wait(1).to({graphics:mask_graphics_51,x:400.3,y:68.7}).wait(1).to({graphics:mask_graphics_52,x:400.3,y:71.5}).wait(1).to({graphics:mask_graphics_53,x:400.3,y:74.3}).wait(1).to({graphics:mask_graphics_54,x:400.3,y:77}).wait(1).to({graphics:mask_graphics_55,x:400.3,y:79.8}).wait(1).to({graphics:mask_graphics_56,x:400.3,y:82.6}).wait(1).to({graphics:mask_graphics_57,x:400.3,y:85.4}).wait(1).to({graphics:mask_graphics_58,x:400.3,y:88.1}).wait(1).to({graphics:mask_graphics_59,x:400.3,y:90.9}).wait(1).to({graphics:mask_graphics_60,x:400.3,y:93.7}).wait(1).to({graphics:mask_graphics_61,x:400.3,y:96.5}).wait(1).to({graphics:mask_graphics_62,x:400.1,y:99.2}).wait(1).to({graphics:mask_graphics_63,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_64,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_65,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_66,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_67,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_68,x:400.3,y:99.2}).wait(1).to({graphics:mask_graphics_69,x:400.1,y:99.2}).wait(1).to({graphics:mask_graphics_70,x:400.3,y:101.3}).wait(1).to({graphics:mask_graphics_71,x:400.3,y:103.4}).wait(1).to({graphics:mask_graphics_72,x:400.3,y:105.5}).wait(1).to({graphics:mask_graphics_73,x:400.3,y:107.6}).wait(1).to({graphics:mask_graphics_74,x:400.3,y:109.8}).wait(1).to({graphics:mask_graphics_75,x:400.3,y:111.9}).wait(1).to({graphics:mask_graphics_76,x:400.3,y:114}).wait(1).to({graphics:mask_graphics_77,x:400.3,y:116.1}).wait(1).to({graphics:mask_graphics_78,x:400.3,y:118.2}).wait(1).to({graphics:mask_graphics_79,x:400.3,y:120.3}).wait(1).to({graphics:mask_graphics_80,x:400.3,y:122.4}).wait(1).to({graphics:mask_graphics_81,x:400.3,y:124.5}).wait(1).to({graphics:mask_graphics_82,x:400.3,y:126.6}).wait(1).to({graphics:mask_graphics_83,x:400.3,y:128.7}).wait(1).to({graphics:mask_graphics_84,x:400.1,y:130.8}).wait(1).to({graphics:mask_graphics_85,x:400.3,y:130.8}).wait(1).to({graphics:mask_graphics_86,x:400.3,y:130.8}).wait(1).to({graphics:mask_graphics_87,x:400.3,y:130.8}).wait(1).to({graphics:mask_graphics_88,x:400.3,y:130.8}).wait(1).to({graphics:mask_graphics_89,x:400.3,y:130.8}).wait(1).to({graphics:mask_graphics_90,x:400.1,y:130.8}).wait(1).to({graphics:mask_graphics_91,x:400.3,y:132.2}).wait(1).to({graphics:mask_graphics_92,x:400.3,y:133.5}).wait(1).to({graphics:mask_graphics_93,x:400.3,y:134.9}).wait(1).to({graphics:mask_graphics_94,x:400.3,y:136.3}).wait(1).to({graphics:mask_graphics_95,x:400.3,y:137.6}).wait(1).to({graphics:mask_graphics_96,x:400.3,y:139}).wait(1).to({graphics:mask_graphics_97,x:400.3,y:140.4}).wait(1).to({graphics:mask_graphics_98,x:400.3,y:141.8}).wait(1).to({graphics:mask_graphics_99,x:400.3,y:143.1}).wait(1).to({graphics:mask_graphics_100,x:400.3,y:144.5}).wait(1).to({graphics:mask_graphics_101,x:400.3,y:145.9}).wait(1).to({graphics:mask_graphics_102,x:400.3,y:147.2}).wait(1).to({graphics:mask_graphics_103,x:400.3,y:148.6}).wait(1).to({graphics:mask_graphics_104,x:400.1,y:150}).wait(16));

	// Capa 4
	this.text = new cjs.Text("x", "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(364.2,281);

	this.soluciontxt = new cjs.Text("• Al cabo de un año tendrá:\n100 + 0,02 · 100 = 100 · 1,02 = 102 habitantes\n\n• Al cabo de dos años tendrá:\n100 · 1,02 + 0,02 · 100 · 1,02 = 100 · 1,02 · (1 + 0,02) = 100 · 1,022 = 104'04 habitantes\n\n• Si vamos repitiendo el proceso, vemos que al cabo de 3 años tendrá:\n100 · 1,023 = 106,12 habitantes\n\n• Al cabo de 4 años tendrá:\n100 · 1,024 = 108,24 habitantes\n\n• Al cabo de x años costara: 100 · 1,02  euros", "18px Verdana");
	this.soluciontxt.lineHeight = 18;
	this.soluciontxt.lineWidth = 801;

	this.text.mask = this.soluciontxt.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.soluciontxt},{t:this.text}]},4).wait(116));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.textoAnimado2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg97gAYMB73AAAIAAAxMh73AAAg");
	var mask_graphics_1 = new cjs.Graphics().p("Eg97ABMIAAiXMB73AAAIAACXg");
	var mask_graphics_2 = new cjs.Graphics().p("Eg97ACAIAAj/MB73AAAIAAD/g");
	var mask_graphics_3 = new cjs.Graphics().p("Eg97AC0IAAlnMB73AAAIAAFng");
	var mask_graphics_4 = new cjs.Graphics().p("Eg97ADnIAAnNMB73AAAIAAHNg");
	var mask_graphics_5 = new cjs.Graphics().p("Eg97AEbIAAo1MB73AAAIAAI1g");
	var mask_graphics_6 = new cjs.Graphics().p("Eg97AFPIAAqdMB73AAAIAAKdg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg97AGDIAAsFMB73AAAIAAMFg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg97AG2IAAtrMB73AAAIAANrg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg97AHqIAAvTMB73AAAIAAPTg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg97AIeIAAw7MB73AAAIAAQ7g");
	var mask_graphics_11 = new cjs.Graphics().p("Eg97AJSIAAyjMB73AAAIAASjg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg97gKEMB73AAAIAAUJMh73AAAg");
	var mask_graphics_19 = new cjs.Graphics().p("Eg97gKEMB73AAAIAAUJMh73AAAg");
	var mask_graphics_20 = new cjs.Graphics().p("Eg97AKnIAA1NMB73AAAIAAVNg");
	var mask_graphics_21 = new cjs.Graphics().p("Eg97ALJIAA2RMB73AAAIAAWRg");
	var mask_graphics_22 = new cjs.Graphics().p("Eg97ALrIAA3VMB73AAAIAAXVg");
	var mask_graphics_23 = new cjs.Graphics().p("Eg97AMNIAA4ZMB73AAAIAAYZg");
	var mask_graphics_24 = new cjs.Graphics().p("Eg97AMvIAA5dMB73AAAIAAZdg");
	var mask_graphics_25 = new cjs.Graphics().p("Eg97ANRIAA6hMB73AAAIAAahg");
	var mask_graphics_26 = new cjs.Graphics().p("Eg97ANyIAA7jMB73AAAIAAbjg");
	var mask_graphics_27 = new cjs.Graphics().p("Eg97gOTMB73AAAIAAcnMh73AAAg");
	var mask_graphics_35 = new cjs.Graphics().p("Eg97gOTMB73AAAIAAcnMh73AAAg");
	var mask_graphics_36 = new cjs.Graphics().p("Eg97AOsIAA9XMB73AAAIAAdXg");
	var mask_graphics_37 = new cjs.Graphics().p("Eg97APDIAA+FMB73AAAIAAeFg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg97APbIAA+1MB73AAAIAAe1g");
	var mask_graphics_39 = new cjs.Graphics().p("Eg97APyIAA/jMB73AAAIAAfjg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg97AQJMAAAggRMB73AAAMAAAAgRg");
	var mask_graphics_41 = new cjs.Graphics().p("Eg97AQhMAAAghBMB73AAAMAAAAhBg");
	var mask_graphics_42 = new cjs.Graphics().p("Eg97AQ4MAAAghvMB73AAAMAAAAhvg");
	var mask_graphics_43 = new cjs.Graphics().p("Eg97ARQMAAAgifMB73AAAMAAAAifg");
	var mask_graphics_44 = new cjs.Graphics().p("Eg97ARnMAAAgjNMB73AAAMAAAAjNg");
	var mask_graphics_45 = new cjs.Graphics().p("Eg97AR+MAAAgj7MB73AAAMAAAAj7g");
	var mask_graphics_46 = new cjs.Graphics().p("Eg97ASWMAAAgkrMB73AAAMAAAAkrg");
	var mask_graphics_47 = new cjs.Graphics().p("Eg97gSsMB73AAAMAAAAlZMh73AAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:394.6,y:-8.9}).wait(1).to({graphics:mask_graphics_1,x:394.6,y:-3.7}).wait(1).to({graphics:mask_graphics_2,x:394.6,y:1.4}).wait(1).to({graphics:mask_graphics_3,x:394.6,y:6.5}).wait(1).to({graphics:mask_graphics_4,x:394.6,y:11.7}).wait(1).to({graphics:mask_graphics_5,x:394.6,y:16.9}).wait(1).to({graphics:mask_graphics_6,x:394.6,y:22.1}).wait(1).to({graphics:mask_graphics_7,x:394.6,y:27.3}).wait(1).to({graphics:mask_graphics_8,x:394.6,y:32.5}).wait(1).to({graphics:mask_graphics_9,x:394.6,y:37.6}).wait(1).to({graphics:mask_graphics_10,x:394.6,y:42.8}).wait(1).to({graphics:mask_graphics_11,x:394.6,y:48}).wait(1).to({graphics:mask_graphics_12,x:394.6,y:53.2}).wait(7).to({graphics:mask_graphics_19,x:394.6,y:53.2}).wait(1).to({graphics:mask_graphics_20,x:394.6,y:56.4}).wait(1).to({graphics:mask_graphics_21,x:394.6,y:59.7}).wait(1).to({graphics:mask_graphics_22,x:394.6,y:62.9}).wait(1).to({graphics:mask_graphics_23,x:394.6,y:66.2}).wait(1).to({graphics:mask_graphics_24,x:394.6,y:69.4}).wait(1).to({graphics:mask_graphics_25,x:394.6,y:72.6}).wait(1).to({graphics:mask_graphics_26,x:394.6,y:75.9}).wait(1).to({graphics:mask_graphics_27,x:394.6,y:79.1}).wait(8).to({graphics:mask_graphics_35,x:394.6,y:79.1}).wait(1).to({graphics:mask_graphics_36,x:394.6,y:81.5}).wait(1).to({graphics:mask_graphics_37,x:394.6,y:83.8}).wait(1).to({graphics:mask_graphics_38,x:394.6,y:86.2}).wait(1).to({graphics:mask_graphics_39,x:394.6,y:88.5}).wait(1).to({graphics:mask_graphics_40,x:394.6,y:90.9}).wait(1).to({graphics:mask_graphics_41,x:394.6,y:93.2}).wait(1).to({graphics:mask_graphics_42,x:394.6,y:95.6}).wait(1).to({graphics:mask_graphics_43,x:394.6,y:97.9}).wait(1).to({graphics:mask_graphics_44,x:394.6,y:100.3}).wait(1).to({graphics:mask_graphics_45,x:394.6,y:102.6}).wait(1).to({graphics:mask_graphics_46,x:394.6,y:105}).wait(1).to({graphics:mask_graphics_47,x:394.6,y:107.3}).wait(6));

	// Capa 4
	this.text = new cjs.Text("t", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 42;
	this.text.setTransform(440,134);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},12).wait(41));

	// Capa 1
	this.pantalla6 = new cjs.Text("En el crecimiento exponencial, cada valor de y se obtiene multiplicando el valor anterior por una cantidad constante a (positiva y distinta de 1). \n\nLa fórmula es: \n\ny = k · at\n\nDonde t es el tiempo y k es el valor inicial (para t = 0). ", "20px Verdana");
	this.pantalla6.lineHeight = 22;
	this.pantalla6.lineWidth = 783;

	this.pantalla6.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.pantalla6}]}).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,787.1,238.7);


(lib.moneda = function() {
	this.initialize();

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F8E153","#FBF6D2"],[0.004,1],-0.7,0,0.9,0).s().p("AgHgCIAPgEIAAAJIgPAEg");
	this.shape.setTransform(44.7,-17.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FCF8DB","#F8E153","#FBF6D2"],[0.165,0.741,1],-8.3,0,8.4,0).s().p("AgiAEIgwgIIAGgCICfADIAAAKg");
	this.shape_1.setTransform(35.5,-17.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#EFDD54","#C09200","#E2BA00"],[0.004,0.482,1],-4.6,0,4.8,0).s().p("AgugBIAAgLIBdAYIgmABg");
	this.shape_2.setTransform(24.1,-16);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FBF6D2","#F8E153","#FBF6D2"],[0.012,0.741,1],-2,0,2.2,0).s().p("AgSAIQgEgEADgDQADgCAHgBIAegHIAAAJQgaAFgJAFg");
	this.shape_3.setTransform(17.1,-16.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#E2BA00","#C09200","#E2BA00"],[0.004,0.431,1],-7.9,0,8,0).s().p("AhPgLIAAgLICfApIgaAEg");
	this.shape_4.setTransform(44.8,-10.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#F8E153","#FFFFFF"],[0,1],-1.7,0,1.8,0).s().p("AgRADIAjgQIAAALIgjAQg");
	this.shape_5.setTransform(48.5,3.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#EFDD54","#C09200","#E2BA00"],[0.004,0.118,1],-12.7,0,12.8,0).s().p("Ah/gsIAAgMID/BlIAAAMg");
	this.shape_6.setTransform(33.8,-0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#EFDD54","#C09200","#E2BA00"],[0.004,0.518,1],-5.1,0,5.3,0).s().p("AgzgHIAAAAIAAgLIAAAAIBnAaIAAALg");
	this.shape_7.setTransform(68.1,-3.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#F8E153","#FFFFFF"],[0,1],-4.7,0,4.9,0).s().p("AgvAHIBfgYIAAAMIhfAXg");
	this.shape_8.setTransform(78.3,-3.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FCF8DB","#F8E153","#FBF6D2"],[0.165,0.741,1],-8.1,1.5,8.6,-2.3).s().p("Ag7AAQAPgIAXgDIBggNIAAALIhgANQgRABgOAGQgRAIgEAKQgFgPATgKg");
	this.shape_9.setTransform(55.4,-3.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#E2BA00","#C09200","#E2BA00"],[0.004,0.431,1],-7,0,7.2,0).s().p("AAhABQgdgEgkACIgmgJIAZgCQApgDAgAGQAgAFAJAHQAFAGgFAFQgJgIgbgFg");
	this.shape_10.setTransform(54.4,-12.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFACA","#F8E153","#F6EB9E"],[0.004,0.325,1],4.7,-3.1,-9.7,15.7).s().p("AicA9QgfgdAngPIA9gNIA/gMQAlgKAVgRQAHgGAQgWIAKACQAkAGAWAPQAdATgiARQgSAGgMAEIBQASIgcAIQgaAGgvAJIhIgUIhhAOQgQACgOAGQgPAGgGAJQgDgBgCgCg");
	this.shape_11.setTransform(63.3,-8.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#FBF6D2","#F8E153"],[0.016,1],9.5,-4.6,-7.6,1.3).s().p("AhggMIAlgFQAXACAtAAQAuABAqgCQgvAWhBAMg");
	this.shape_12.setTransform(30.7,-5.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#ECD153","#F8E153"],[0.016,1],19.3,-4.9,-15.9,7.3).s().p("ACHALQiAAJhaAAQhfAAgZgQQAzgPBGgLIACAAQgDADADAEQAGAFAuACQAoACArgCIhHgUQBhgFA/AVQA2APAGAbg");
	this.shape_13.setTransform(23.3,-13.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#F8E153","#FFFACA","#F8E153","#FFFACA"],[0.004,0.184,0.569,0.988],-40.3,0,40.6,0).s().p("AjWARIAkgFQAaADA+AAQA5AAAmgDQAmgCA7gKIiegqQiAAJhcAAQhkAAgXgSQgXgTBogRIBCgIIgZgGIA9gHIAfAHQA9gIAIgIIAQgCICCAWIgSAFIingEIgEAAIBzAaQDTgNBrAVQAlAGAWAOQAcAUghAQQgSAHgNAEIBsAYIhhAZIhpgcIhiAOQghAEgOAQQgSASAlAZIglASgABHgzIgaACICIAeQANgIgHgIQgJgJgggEQgWgEgZAAIgcABgAkRhGQAGAFAuADQAqACArgDIhfgaQg0AIAKALg");
	this.shape_14.setTransform(42.6,-8.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#ECD153","#E2BA00","#FCF8DB","#F8E153","#FBF6D2"],[0.012,0.141,0.325,0.741,1],-17.2,0,17.3,0).s().p("AioAAQgEgCAAgDIAAgLIAGAHQAYAPBhAAQBaAACAgHIAAAJQiAAJhaAAQhkAAgXgRg");
	this.shape_15.setTransform(19.5,-12.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#F8E153","#FBF6D2"],[0.004,1],-2.3,0,2.4,0).s().p("AgWANQAMgEAQgJIALgEIAGgMIAAAMQAAAHgRAJIgKAFg");
	this.shape_16.setTransform(74.8,-9.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#FFFFFF","#FBF6D2"],[0,1],8,0,-8.1,0).s().p("AhOAEQBZgGBCgKIADAJQhKAJhVAHg");
	this.shape_17.setTransform(68.3,5.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#F6EA9A","#FBF6D2","#E2BA00","#F8E153"],[0,0.608,0.894,1],63.6,-0.3,-64.6,1.3).s().p("AnBAxQi7gogBg5IAFgTIgBAJQABA6C6AnQC7AoEEgEQEHgDC5gtQC6gqgBg7IgBgKQAEALABAIIAAAAQABA8i6AqQi7AskJAEIgoAAQjuAAisgkg");
	this.shape_18.setTransform(42.8,-1.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#E2BA00","#ECD153","#E2BA00","#B98D00","#E2BA00"],[0,0.392,0.608,0.898,1],65.1,0,-64.7,0).s().p("AgQCKQgHgVgBg9QAAguADgSIALAAQgDASABAuQAAA9AIAVgAg2CKQgGgWgBg8QAAguADgSIALAAQgDAPABAxQgBA5AIAZgAAQCKQgHgVgBg+QAAgtADgTIAMAAQgEATABAtQABA+AGAVgAhbCKQgHgWgBg8QAAguAEgSIALAAQgEAPABAxQAAA6AHAYgAArA+QgBg+ACgKIAMAAQgDAKACA+QABBAAEALIgLAAQgEgKgChBgAiCCJQgHgUgBg9QgBgvAEgTIALAAQgDATAAAvQACA7AGAWgABOA9QgCg9ACgLIALAAQgBALABA8QACBBAEAKIgMABQgDgLgChAgAinCHQgHgWgBg5QgBgvAEgVIALABQgDAOAAA1QABA4AHAYgABwA6QgCg7ABgLIALgBIABBIQACBAACALIgMAAQgCgNgBg/gAjKCFQgIgNgCg8QgCg8AHgOIALAAQgHAOACA8QABA8AJAOgACSA6IgDhIIAMgBIAECTIgLAAIgChKgAjtCDQgIgOgCg8QgBg5AGgQIALABQgHAPACA6QACA8AIANgACzA0QAAg4gCgNIALgBQAFAQAAA7QgBA7gDANIgLABQACgSgBg8gAkQCAQgIgOgBg8QgCg6AHgPIALgCQgIAPACA7QACA+AIAOgADWA1QABg4gCgRIAKgBQAFAPgBA4QgCA2gEAWIgKABQACgRABg5gAk2B8QgJgOgBg8QgBg6AHgPIALABQgHAPACA6QABA8AIAOgAD3AyQABg6gFgPIAKgCQAHASgBA4QgBA5gHARIgKABQAFgRABg5gAEbAuQAAg6gHgPIAKgBQAIAQgBA5QgBA8gIAOIgKACQAIgOABg9gAlbB3QgIgOAAg8QgBg5AHgQIAJACQgGAPABA6QABA8AIANgAFAApQAAg6gIgQIAKgCQAHAQAAA6QABA9gIAOIgLACQAIgOABg9gAl+ByQgJgOAAg8QAAg6AGgPIALABQgHAQABA6QAAA8AJANgAFkAkQAAg5gHgPIAJgCQAIAPAAA5QABA9gJANIgLACQAHgOACg8gAmgBsQgIgOgBg8QgCg5AHgQIALACQgIAPACA6QACA8AIAOgAGCAfQABg5gIgQIALgCQAHAQAAA5QAAA8gHAOIgMACQAIgOAAg8gAnDBlQgKgPAAg4QAAgzAIgXIAKACQgIASAAA4QABA5AJAOgAGkAYQACg7gIgPIALgDQAGAQgBA6QAAA9gJAOIgKADQAIgOABg9gAnhBeQgIgOABg4QAAg1AHgXIAKADQgIASAAA4QAAA5AIAOgAHHASQAAg4gIgSIAKgDQAIAXgBA1QAAA5gIAPIgKACQAIgPABg6gAn/BWQgJgPAAg3QABg0AHgXIAKACQgHATAAA3QgBA5AIAOgAHkAKQgBg4gHgSIAJgDQAIAXAAA1QABA4gIAQIgKACQAIgOAAg7gAoXBOQgJgQABg3QAAgzAIgYIAIADQgGASAAA4QAAA6AGAOgAIBACQAAg4gHgSIAJgDQAIAXAAA1QABA4gJAPIgIADQAHgPgBg6gAosBGQgJgUAAgxQAAgvAJgcIAJADQgJAVAAA2QAAA3AIAOgAIZgFQAAg7gIgRIAJgEQAIAYAAA3QABA1gJAQIgIAEQAHgPAAg5gAo/A+QgIgVAAguQAAgwAIgcIAIADQgIAVAAA4QABA0AGAOgAIugKQAAg4gJgVIAJgEQAJAcAAAyQAAAvgIAVIgIAEQAIgPgBg2gApOA2QgKgWgBgwQgBg1AKgaIAHAGQgKAUABA6QACA1AIAQgAJAgSQABg4gIgVIAIgEQAIAcAAAyQABAugIAVIgIAEQAHgPgBg1gApcAtQgKgVgCgwQgEg1AKgaIAHAGQgJAUAEA6QACA2AKAPgAJUgcQAAg7gJgUIAGgHQALAagBA2QgBAxgKAXIgGAEQAIgQACg2gApuAeQgKgWgCgwQgDg2AMgYIAEAGQgKAUAFA4QADAyAKAYgAJigkQADg8gJgUIAHgGQAKAagDA2QgCAwgJAXIgIAFQAJgPACg3gAJ0g3QAEg4gKgVIAFgFQALAYgDA2QgBAzgLAVIgIAJQAJgXAEg2g");
	this.shape_19.setTransform(43.1,8.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#B98D00","#F8E153","#F8E153","#B98D00"],[0,0.259,0.522,1],-61.6,0,61.7,0).s().p("ApnBBQgBg2C1goQCzgqEAgEQD+gDC1AjQC1AkAAA1QAAAGgCAGQgRg2iyghQixgjjyADQj1AEiyAoQixAmgNA3QgCgGAAgFg");
	this.shape_20.setTransform(42.8,-13.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#F6EB9E","#EFDD54"],[0.004,0.388],0.2,16.1,-0.1,-21.6).s().p("Am+BrQi6gogBg7QAAg6C5gsQC5gsEGgEQEFgDC7AnQC7AoAAA7QABA6i5AsQi6AskGAEIguAAQjoAAiqgkgAAAiDQkAAEi0AqQi0AqAAA0QABA3C1AkQC1AkD+gEQEAgEC0gqQC0gpgBg1QAAg3i1gkQilggjjAAIgrAAg");
	this.shape_21.setTransform(42.8,-8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#F8E153","#E9CA52","#F8E153","#F8E153"],[0.004,0.392,0.776,1],34,10.6,-23,-9.5).s().p("AjXAMIAAgLID/BmIAkgSIAAAMIgkASgABCAjQAQgKAXgCIBhgOIBpAcIBhgZIAAALIhhAZIhpgcIAAAAIhhAPQgRABgPAHQgQAIgEAKQgFgPASgLgAg5gwQiOAJhOAAQhjAAgYgSQgDgDAAgDIAAgLIAFAHQAZARBgAAQBcAACAgJICfArIgaAEgACWg2QgegFgkABIgngJIAZgCQAqgDAiAGQAfAFAJAKQAGAFgGAGQgIgIgcgGgAjohfQgcAFgJAFIgEgCQgEgEADgDQADgEAHgBIAggHIBgAaIgmABgAhqhlIgwgLIAGgBICgADIARgEIAAALIgRAFg");
	this.shape_22.setTransform(42.6,-5.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#F8E153","#F6EB9E"],[0.016,0.973],-4.6,16.6,11.1,-4).s().p("Aj3BZQgngmAxgTQAbgKAzgGIBRgQQAygNAagVQAHgIARgYQAPgWAOgHQAYgLBhAeQBkAfgHAcQgHAZg0AVQgXAKgxAMQhXAXh7AQQhKAJgrAAQgrAAgLgKg");
	this.shape_23.setTransform(73.9,-6.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#FCF8DB","#F8E153"],[0.016,1],-26.4,17.8,21,-17.9).s().p("AjjA6IgtgOQgbgNgBgaQAAgeBxgfQA6gPA/gKQCxgWBtAiQBdAdgPAoQgKAdhWAdQhbAghfAAIgKABQh4AAhxghg");
	this.shape_24.setTransform(14.2,-7.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#B98D00","#F8E153","#E2BA00"],[0.004,0.569,0.988],-47.1,37.1,52.6,-36.8).s().p("AmyBkQi1gkgBg3QAAg0C0gqQC0gqEAgEQD+gDC1AjQC1AkAAA3QABA1i0ApQi0AqkAAEIgwAAQjgAAijggg");
	this.shape_25.setTransform(42.8,-8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(0.5,0,0,4).p("AImgGQABAtihAjQihAkjkADQjjACihgeQihgfgBgvQAAgtCggjQChgkDkgDQDigCChAfQCiAeABAvg");
	this.shape_26.setTransform(42.8,-8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AmDBVQihgfgBgvQAAgtCggjQChgkDkgDQDigCChAfQCiAeABAvQABAtihAjQihAkjkADIggAAQjPAAiVgcg");
	this.shape_27.setTransform(42.8,-8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FCF8DB","#F1DC7B"],[0.165,1],7.9,0,-16.5,0).s().p("AhTAVQgEhQAJgQQAMgXBAgBQA/gCAKAZIAEAMQAHAVACAvQADA0gHAaQhDALhbAHQgEgmgBgpg");
	this.shape_28.setTransform(68.7,11.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#E2BA00","#EFDD54","#F6EB9E"],[0.169,0.702,0.933],1.4,-1.8,-3.3,1.9).s().p("AgKBIQgHgMgEgUQgHgaAAgaQgBg1AKgkIAwAKIgEAYQgBACgCACIgEAFQgPAjgCAkQgBA1AUAkQgWgPgIgPg");
	this.shape_29.setTransform(-18.7,3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#EFDD54","#F6EB9E","#EFDD54","#C09200","#E2BA00"],[0,0.392,0.608,0.898,1],72.3,-0.4,-67.7,1.3).s().p("AmjCGQi0gigcg2QgHgMgEgUQgHgYAAgbQgBhRASgeITmgQQAJANAGAfQAFAdAAAlQABAbgEATQgDAMgHAUIgDAIQgeA1iyAmQizAmjxAEIglAAQjaAAimgfg");
	this.shape_30.setTransform(42.9,5.6);

	this.addChild(this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-21.7,-22.4,129.4,44.6);


(lib.manilla = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#5A5A5A","#000000"],[0,1],-0.7,-8,0,-0.7,-8,14.2).s().p("AhKBLQgfgfAAgsQAAgrAfgfQAggfAqAAQAsAAAfAfQAfAfAAArQAAArgfAgQgfAfgsAAQgqAAgggfg");
	this.shape.setTransform(10.6,10.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#5A5A5A","#323232","#111111","#030303","#000000"],[0,0.29,0.573,0.82,1],0,-4.8,0,4.3).s().p("AlSAzQgMAAgIgNQgJgMAAgTIAAgNQAAgTAJgMQAIgNAMAAIKYAAQANAAAOANQAPAOAAARIAAANQAAARgPAOQgOANgNAAg");
	this.shape_1.setTransform(39.1,10.6);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,75.9,21.3);


(lib.Mapadebits1c = function() {
	this.initialize(img.Mapadebits1c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,28,1);


(lib.Mapadebits2c = function() {
	this.initialize(img.Mapadebits2c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,45);



(lib.Mapadebits3c = function() {
	this.initialize(img.Mapadebits3c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,28,1);


(lib.Mapadebits4c = function() {
	this.initialize(img.Mapadebits4c);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,18);


(lib.grafico2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.instance = new lib.Mapadebits4c();
	this.instance.setTransform(110.2,124.7);

	this.instance_1 = new lib.Mapadebits3c();
	this.instance_1.setTransform(83.6,124.7);

	this.instance_2 = new lib.Mapadebits2c();
	this.instance_2.setTransform(110.2,80.8);

	this.instance_3 = new lib.Mapadebits1c();
	this.instance_3.setTransform(83.6,80.8);

	this.text = new cjs.Text("a > ", "italic 12px Verdana");
	this.text.lineHeight = 14;
	this.text.setTransform(103.3,-6);
	this.textb = new cjs.Text("      1", " 12px Verdana");
	this.textb.lineHeight = 14;
	this.textb.setTransform(103.3,-6);

	this.text_1 = new cjs.Text("a < ", "italic 12px Verdana");
	this.text_1.lineHeight = 14;
	this.text_1.setTransform(20.7,-6);
this.text_1b = new cjs.Text("      1", " 12px Verdana");
	this.text_1b.lineHeight = 14;
	this.text_1b.setTransform(20.7,-6);

	this.text_2 = new cjs.Text("1", "12px Verdana");
	this.text_2.lineHeight = 14;
	this.text_2.setTransform(104.3,143.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgRARQgHgHAAgKQAAgJAHgIQAIgHAJAAQAKAAAHAHQAIAIAAAJQAAAKgIAHQgHAIgKAAQgJAAgIgIg");
	this.shape.setTransform(110.7,124.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgRARQgHgHAAgKQAAgJAHgIQAIgHAJAAQAKAAAHAHQAIAIAAAJQAAAKgIAHQgHAIgKAAQgJAAgIgIg");
	this.shape_1.setTransform(110.7,81.5);

	this.text_3 = new cjs.Text("a", "italic 12px Verdana");
	this.text_3.lineHeight = 14;
	this.text_3.setTransform(70.4,117.1+incremento);

	this.text_4 = new cjs.Text("a", "italic 12px Verdana");
	this.text_4.lineHeight = 14;
	this.text_4.setTransform(70.4,67.6);

	this.text_5 = new cjs.Text("X", "12px Verdana");
	this.text_5.lineHeight = 14;
	this.text_5.setTransform(165.4,143.9);

	this.text_6 = new cjs.Text("Y", "12px Verdana");
	this.text_6.lineHeight = 14;
	this.text_6.setTransform(66.3,5.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAgNIAAAb");
	this.shape_2.setTransform(110.7,143.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AgnqMIAAUZIEJAAIKFAAAtmKNIM/AA");
	this.shape_3.setTransform(88.1,76.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.shape_1},{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text_1b},{t:this.text},{t:this.textb},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(76));

	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AgKJaIAAyzIAWAAIAASzg");
	var mask_graphics_15 = new cjs.Graphics().p("Ag0JaIAAyzIBpAAIAASzg");
	var mask_graphics_16 = new cjs.Graphics().p("AheJaIAAyzIC9AAIAASzg");
	var mask_graphics_17 = new cjs.Graphics().p("AiIJaIAAyzIERAAIAASzg");
	var mask_graphics_18 = new cjs.Graphics().p("AixJaIAAyzIFjAAIAASzg");
	var mask_graphics_19 = new cjs.Graphics().p("AjbJaIAAyzIG3AAIAASzg");
	var mask_graphics_20 = new cjs.Graphics().p("AkFJaIAAyzIILAAIAASzg");
	var mask_graphics_21 = new cjs.Graphics().p("AkvJaIAAyzIJfAAIAASzg");
	var mask_graphics_22 = new cjs.Graphics().p("AlYJaIAAyzIKxAAIAASzg");
	var mask_graphics_23 = new cjs.Graphics().p("AmCJaIAAyzIMFAAIAASzg");
	var mask_graphics_24 = new cjs.Graphics().p("AmsJaIAAyzINZAAIAASzg");
	var mask_graphics_25 = new cjs.Graphics().p("AnVJaIAAyzIOrAAIAASzg");
	var mask_graphics_26 = new cjs.Graphics().p("An/JaIAAyzIP/AAIAASzg");
	var mask_graphics_27 = new cjs.Graphics().p("AopJaIAAyzIRTAAIAASzg");
	var mask_graphics_28 = new cjs.Graphics().p("ApTJaIAAyzISnAAIAASzg");
	var mask_graphics_29 = new cjs.Graphics().p("Ap8JaIAAyzIT5AAIAASzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:1.6,y:73.7}).wait(1).to({graphics:mask_graphics_15,x:5.7,y:73.7}).wait(1).to({graphics:mask_graphics_16,x:9.9,y:73.7}).wait(1).to({graphics:mask_graphics_17,x:14.1,y:73.7}).wait(1).to({graphics:mask_graphics_18,x:18.2,y:73.7}).wait(1).to({graphics:mask_graphics_19,x:22.4,y:73.7}).wait(1).to({graphics:mask_graphics_20,x:26.6,y:73.7}).wait(1).to({graphics:mask_graphics_21,x:30.8,y:73.7}).wait(1).to({graphics:mask_graphics_22,x:34.9,y:73.7}).wait(1).to({graphics:mask_graphics_23,x:39.1,y:73.7}).wait(1).to({graphics:mask_graphics_24,x:43.3,y:73.7}).wait(1).to({graphics:mask_graphics_25,x:47.4,y:73.7}).wait(1).to({graphics:mask_graphics_26,x:51.6,y:73.7}).wait(1).to({graphics:mask_graphics_27,x:55.8,y:73.7}).wait(1).to({graphics:mask_graphics_28,x:60,y:73.7}).wait(1).to({graphics:mask_graphics_29,x:64.1,y:73.7}).wait(47));

	// Capa 3
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#009900").ss(1,1,1).p("ApYI2QF2gFDUg2QDbg4B6h/QBzh4A/jfQAzi1Atlu");
	this.shape_4.setTransform(63.3,73.5);

	this.shape_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4}]},14).wait(62));

	// Capa 6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_45 = new cjs.Graphics().p("AgfJaIAAyzIA/AAIAASzg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AhKJaIAAyzICVAAIAASzg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Ah2JaIAAyzIDtAAIAASzg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AihJaIAAyzIFDAAIAASzg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AjNJaIAAyzIGbAAIAASzg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Aj4JaIAAyzIHxAAIAASzg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AkkJaIAAyzIJJAAIAASzg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AlPJaIAAyzIKfAAIAASzg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Al7JaIAAyzIL3AAIAASzg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AmmJaIAAyzINNAAIAASzg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AnSJaIAAyzIOlAAIAASzg");
	var mask_1_graphics_56 = new cjs.Graphics().p("An9JaIAAyzIP7AAIAASzg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AopJaIAAyzIRTAAIAASzg");
	var mask_1_graphics_58 = new cjs.Graphics().p("ApUJaIAAyzISpAAIAASzg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AqAJaIAAyzIUBAAIAASzg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AqrJaIAAyzIVXAAIAASzg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(45).to({graphics:mask_1_graphics_45,x:37.9,y:73.7}).wait(1).to({graphics:mask_1_graphics_46,x:42.3,y:73.7}).wait(1).to({graphics:mask_1_graphics_47,x:46.6,y:73.7}).wait(1).to({graphics:mask_1_graphics_48,x:51,y:73.7}).wait(1).to({graphics:mask_1_graphics_49,x:55.3,y:73.7}).wait(1).to({graphics:mask_1_graphics_50,x:59.7,y:73.7}).wait(1).to({graphics:mask_1_graphics_51,x:64,y:73.7}).wait(1).to({graphics:mask_1_graphics_52,x:68.4,y:73.7}).wait(1).to({graphics:mask_1_graphics_53,x:72.7,y:73.7}).wait(1).to({graphics:mask_1_graphics_54,x:77.1,y:73.7}).wait(1).to({graphics:mask_1_graphics_55,x:81.4,y:73.7}).wait(1).to({graphics:mask_1_graphics_56,x:85.8,y:73.7}).wait(1).to({graphics:mask_1_graphics_57,x:90.1,y:73.7}).wait(1).to({graphics:mask_1_graphics_58,x:94.5,y:73.7}).wait(1).to({graphics:mask_1_graphics_59,x:98.8,y:73.7}).wait(1).to({graphics:mask_1_graphics_60,x:103.2,y:73.7}).wait(16));

	// Capa 4
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#CC0000").ss(1,1,1).p("AJZI2Ql2gFjUg2Qjbg4h6h/Qhzh4hAjfQgyi1gtlu");
	this.shape_5.setTransform(104.3,73.5);

	this.shape_5.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5}]},45).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1,-6,176.8,168.4);


(lib.Grupodeclips0_68 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AiBCUIAAknIECAAIAAEng");
	mask.setTransform(14.1,15.3);

	// Capa 3
	this.instance = new lib.Image_28();
	this.instance.setTransform(0,31.2,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,28.8,31.2);


(lib.Grupodeclips0_66 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AATADIgzgGIAFAAIA8AHg");
	mask.setTransform(3.4,0.4);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C22E12").s().p("AATADIgzgGIBBAHg");
	this.shape.setTransform(3.4,0.4);

	this.shape.mask = mask;

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.8,0.9);


(lib.Grupodeclips0_65 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkFIUIAAwnIILAAIAAQng");
	mask.setTransform(27.4,54.2);

	// Capa 3
	this.instance = new lib.Image_27();
	this.instance.setTransform(0,108.5,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,55.7,108.5);


(lib.Grupodeclips0_63 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkuCkIAAlHIJdAAIAAFHg");
	mask.setTransform(31.6,17.1);

	// Capa 3
	this.instance = new lib.Image_26();
	this.instance.setTransform(0,35.1,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,63.4,35.1);


(lib.Grupodeclips0_26 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhzCEIAAkHIDnAAIAAEHg");
	mask.setTransform(12.7,14.1);

	// Capa 3
	this.instance = new lib.Image_10();
	this.instance.setTransform(0,28.8,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,26.9,28.8);


(lib.Grupodeclips0_24 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAXADIgJAAIgugGIAJAAIA4AHg");
	mask.setTransform(3.3,0.4);

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B787A").s().p("AAOADIgugGIAJAAIA4AHg");
	this.shape.setTransform(3.3,0.4);

	this.shape.mask = mask;

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,0.8);


(lib.Grupodeclips0_23 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjqHcIAAu4IHVAAIAAO4g");
	mask.setTransform(24.6,48.6);

	// Capa 3
	this.instance = new lib.Image_9();
	this.instance.setTransform(0,97.5,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,49.9,97.5);


(lib.Grupodeclips0_21 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkuCkIAAlHIJdAAIAAFHg");
	mask.setTransform(31.4,17.1);

	// Capa 3
	this.instance = new lib.Image_8();
	this.instance.setTransform(0,34.6,0.48,0.48,0,180,0);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,63.4,34.6);


(lib.curva1_MC = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AzgYNUAhMgEWAF1gsD");
	this.shape.setTransform(125,154.9);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,249.9,309.8);


(lib.btnFalse = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().dr(-200.5,-130.5,401,261);
	this.shape.setTransform(200.5,130.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().dr(-200.5,-130.5,401,261);
	this.shape_1.setTransform(200.5,130.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);



(lib.ameba = function() {
	this.initialize();

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E75F22").ss(0.8,0,0,4).p("AAzgJQAEATgMASQgLASgWAFQgTAEgSgMQgSgLgFgWQgEgTAMgSQAMgSAVgFQATgEASAMQATAMAEAVg");
	this.shape.setTransform(21.9,-6.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FDF4F9").s().p("AgbArQgTgLgEgWQgEgTAMgSQAMgSAVgFQATgEASAMQATAMADAVQAFATgMASQgMASgVAFIgKABQgOAAgNgJg");
	this.shape_1.setTransform(21.9,-6.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E75F22").ss(1,0,0,4).p("AAigGQADANgIAMQgIAMgPADQgMADgMgIQgMgIgDgOQgDgNAIgMQAIgMAOgDQAMgDANAIQAMAIADAOg");
	this.shape_2.setTransform(-16.7,-24.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FDF4F9").s().p("AgSAdQgMgHgDgPQgDgMAIgNQAIgMAOgDQAMgDANAIQAMAIADAPQADAMgIAMQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_3.setTransform(-16.7,-24.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#E75F22").ss(0.5,0,0,4).p("AAfgFQADALgIALQgHALgNADQgLACgLgHQgLgHgDgNQgCgLAHgLQAHgLANgDQALgCALAHQALAHADANg");
	this.shape_4.setTransform(68,21.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FDF4F9").s().p("AgQAaQgLgHgDgNQgCgLAHgLQAHgLANgDQALgCALAHQALAHADANQADALgIALQgHALgNADIgGAAQgIAAgIgFg");
	this.shape_5.setTransform(68,21.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#E75F22").ss(1,0,0,4).p("AAmgGQADAOgJANQgJANgQAEQgOADgNgJQgOgJgDgPQgDgOAJgOQAIgNAQgEQAOgDAOAJQANAJAEAQg");
	this.shape_6.setTransform(-26.3,32.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FDF4F9").s().p("AgUAgQgOgJgDgPQgDgOAJgOQAIgNAQgEQAOgDAOAJQANAJAEAQQADAOgJANQgJANgQAEIgHABQgKAAgKgHg");
	this.shape_7.setTransform(-26.3,32.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#E75F22").ss(0.5,0,0,4).p("AASgCQACAGgEAGQgFAHgIACQgGABgGgEQgHgEgCgIQgBgGAEgHQAEgHAIgCQAGgBAHAEQAHAFABAIg");
	this.shape_8.setTransform(13,-39.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FDF4F9").s().p("AgJAQQgHgEgCgIQgBgGAEgHQAEgHAIgCQAGgBAHAEQAHAFABAIQACAGgEAGQgFAHgIACIgDAAQgEAAgFgDg");
	this.shape_9.setTransform(13,-39.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F3AC71").s().p("AgsBGQgegTgHgjQgHgfATgeQAUgdAhgHQAggHAeATQAdATAHAiQAHAggTAdQgTAegiAHQgKACgHAAQgXAAgVgOg");
	this.shape_10.setTransform(-8.9,-87.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F19E67").s().p("AghAzQgVgOgGgZQgFgXAOgVQAOgWAZgFQAYgFAVAOQAWAOAFAZQAGAXgPAVQgOAWgZAFIgMACQgRAAgQgLg");
	this.shape_11.setTransform(47.2,-23.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AghAzQgVgOgFgZQgGgXAOgWQAPgVAZgGQAXgFAVAOQAWAOAFAaQAGAXgPAVQgOAWgZAFIgMACQgRAAgQgLg");
	this.shape_12.setTransform(-33.1,-1.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EF925A").s().p("AhPBrQgygngMg1QgKgxAfgsQAggsA3gMQA2gMA3AbQA4AcAKAyQAKAygjA6QglA6g2ALQgLADgMAAQgoAAgqggg");
	this.shape_13.setTransform(-32.9,3.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FCEDF5").s().p("Ag7BBQgZgNgCggQgBgaARgeQASgfAbgMQAdgOAdAQQAhASAOAmQANAhgLAfQgMAigiAIQgKACgKAAQgfAAgsgWg");
	this.shape_14.setTransform(37.1,35.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EB7B52").s().p("Ag7DWQhng/gohpQgkhfAhhSQAhhVBXgNQBhgOCDBbQBKAzAFBRQAEBFgwBHQgtBEhCAdQgjAPgeAAQggAAgdgSg");
	this.shape_15.setTransform(28.9,36.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F3AA5D").s().p("AgHANQgGgEgBgGQgBgFADgFQAEgGAGgBQAFgBAFADQAGAEABAGQABAFgDAFQgEAGgGABIgDAAQgDAAgEgCg");
	this.shape_16.setTransform(86.6,-42.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F3AA5D").s().p("AgMAUQgJgFgCgLQgCgIAFgJQAGgIAKgCQAIgCAJAFQAJAGACAKQADAIgGAJQgGAJgKACIgFABQgGAAgGgFg");
	this.shape_17.setTransform(93.2,-45.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F19F4E").s().p("AgGABQgBgBACgDQABgDAEAAQAGgCABAIQABABgCADQgCADgDAAIgBAAQgFAAgBgGg");
	this.shape_18.setTransform(97.7,-49.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F7BD56").s().p("AgMAUQgIgGgDgKQgCgHAGgJQAGgIAJgDQAIgCAJAGQAIAGACAJQADAIgGAJQgGAIgKACIgEABQgGAAgGgEg");
	this.shape_19.setTransform(114.5,-67.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FCD888").s().p("AgHANQgGgEgBgHQgBgEADgGQAEgFAGgBQAFgBAFADQAGAEABAGQABAFgDAFQgEAGgGABIgDAAQgDAAgEgCg");
	this.shape_20.setTransform(110.7,-73.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F3AA5D").s().p("AgFAJQgEgCgBgFQAAgDACgEQADgEAEgBQADAAAEACQAEADABAEQABADgDAEQgCAEgFABIgCAAQgCAAgDgCg");
	this.shape_21.setTransform(81.5,-31.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#F3AA5D").s().p("AgIAPQgHgFgBgHQgCgFAEgHQAFgGAGgCQAGgBAHAEQAGAEACAIQABAFgEAGQgEAHgIABIgDABQgEAAgEgDg");
	this.shape_22.setTransform(80.3,-35.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F19F4E").s().p("AgEABQgBgEAFgBQADgBACAFQABAEgFABIgBAAQgDAAgBgEg");
	this.shape_23.setTransform(89.6,-36.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F7BD56").s().p("AgJAOQgFgEgCgHQgCgFAFgHQAEgFAHgCQAFgCAGAFQAHAEABAHQABAFgDAGQgFAHgHABIgDAAQgEAAgFgDg");
	this.shape_24.setTransform(103,-56);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FCD888").s().p("AgFAJQgEgDgBgEQgBgDADgEQACgEAFgBQADgBAEADQAEACABAFQABADgDAEQgCAEgFABIgCAAQgCAAgDgCg");
	this.shape_25.setTransform(88.4,-39.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F19F4E").s().p("AgMAUQgJgFgCgKQgCgIAGgJQAFgJAKgCQAIgCAJAGQAJAFACAKQACAIgGAJQgFAJgKACIgFAAQgGAAgGgEg");
	this.shape_26.setTransform(85.7,-34.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F3AA5D").s().p("AgEAKQgEgBgCgGQgCgDACgEQADgFAEgBQADgCAFADQAEACACAEQACADgCAEQgDAFgEACIgEABIgEgCg");
	this.shape_27.setTransform(-127.7,88.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F3AA5D").s().p("AgHARQgHgDgDgIQgDgGAEgHQADgHAIgDQAGgDAHAEQAHADADAIQADAGgEAHQgDAHgIADIgGABQgDAAgEgCg");
	this.shape_28.setTransform(-120,148.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F7BD56").s().p("AgHAQQgHgDgCgHQgDgGADgHQAEgHAHgDQAGgCAGADQAHAEADAHQADAGgEAGQgDAIgHACIgGACQgCAAgFgDg");
	this.shape_29.setTransform(-99.5,144.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FCD888").s().p("AgEAKQgEgCgCgFQgCgDACgEQADgFAEgBQADgCAFACQAEADACAEQACADgDAEQgCAFgEACIgEABIgEgCg");
	this.shape_30.setTransform(-125.7,99.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F19F4E").s().p("AgKAXQgKgFgDgJQgEgJAFgKQAEgKALgDQAIgEAKAEQAKAFAEALQADAIgFAKQgEAKgLADQgEACgEAAQgEAAgGgDg");
	this.shape_31.setTransform(-128.1,93.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F3AA5D").s().p("AgKAMQgFgFAAgHQAAgEAEgGQAFgFAGAAQAFAAAFAEQAFAFABAGQAAAFgFAGQgEAEgHABQgFAAgFgEg");
	this.shape_32.setTransform(-127.5,106.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#F3AA5D").s().p("AgQASQgIgHgBgKQAAgJAIgIQAHgIAKgBQAJAAAIAIQAJAHAAAKQAAAJgIAJQgGAHgMABIAAAAQgJAAgHgIg");
	this.shape_33.setTransform(-131.3,110.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#F19F4E").s().p("AgEAFQgGgFAFgEQAFgGAFAGQAGAEgGAFQgCADgDAAQgCAAgCgDg");
	this.shape_34.setTransform(-139.6,100.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F7BD56").s().p("AgQASQgHgHgBgLQAAgIAHgIQAHgIAKAAQAJAAAIAHQAHAHABAKQAAAJgHAIQgHAHgLABQgIAAgIgHg");
	this.shape_35.setTransform(-138.5,109.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FCD888").s().p("AgKALQgFgEAAgHQAAgFAEgFQAFgFAGAAQAGAAAFAFQAFAEAAAGQAAAGgFAFQgEAFgHAAIAAAAQgFAAgFgFg");
	this.shape_36.setTransform(-141.9,104.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#F19F4E").s().p("AgWAZQgMgKAAgOQAAgNAKgLQAJgLAPAAQANAAAKAKQAMAKAAAOQABANgLALQgJAKgPABIgBAAQgNAAgJgKg");
	this.shape_37.setTransform(-134,103.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#F3AA5D").s().p("AgDAWQgKgCgFgIQgFgIACgHQACgKAIgFQAIgFAHACQAKACAFAIQAFAIgCAHQgCAJgIAFQgGAEgGAAIgDAAg");
	this.shape_38.setTransform(-133.7,96.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#F3AA5D").s().p("AgGAjQgPgDgIgNQgIgNADgNQADgOANgIQANgIAMADQAPADAIANQAIANgDAMQgDAOgNAJQgJAGgKAAIgGgBg");
	this.shape_39.setTransform(-141.5,95.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#F7BD56").s().p("AgGAiQgOgDgIgNQgIgMADgMQADgOAMgIQANgIAMADQAOADAIAMQAIANgDAMQgDAOgNAIQgIAGgKAAIgGgBg");
	this.shape_40.setTransform(-121.7,-2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F19F4E").s().p("AgJAwQgUgFgLgRQgLgRAEgSQAFgUARgLQARgLASAEQAUAFALARQALARgEASQgFAUgRALQgMAIgOAAIgJgBg");
	this.shape_41.setTransform(-135.2,86.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#F3AA5D").s().p("AgHAIQgEgDAAgFQAAgEAEgDQAEgEADAAQAFABADADQAEAEAAADQgBAFgDADQgEAEgEAAQgEAAgDgEg");
	this.shape_42.setTransform(-88.8,137.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#F3AA5D").s().p("AAAATQgHgBgGgFQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgHAAIgBAAg");
	this.shape_43.setTransform(-95.8,119.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#F7BD56").s().p("AgMANQgGgGABgHQAAgHAFgFQAGgFAGgBQAIABAFAGQAGAFgBAGQAAAIgGAFQgFAGgHgBQgHAAgFgFg");
	this.shape_44.setTransform(-108.3,130);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FCD888").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAADAEQAEADAAAEQAAAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_45.setTransform(-140.9,140.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#F19F4E").s().p("AAAAaQgKAAgIgIQgHgIAAgKQAAgKAIgIQAIgHAJAAQALAAAIAJQAHAHAAAJQAAALgIAIQgIAHgKAAIAAAAg");
	this.shape_46.setTransform(-86.7,122);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F3AA5D").s().p("AgEAPQgGgCgDgHQgDgGACgEQADgHAFgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_47.setTransform(-103.5,147.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#F19F4E").s().p("AgBAHQgDgBgCgDQgBgDABgBQABgEADgBQACgBACABQAIACgDAGQgCAGgFAAIgBgBg");
	this.shape_48.setTransform(-86.2,134);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F7BD56").s().p("AgHAYQgKgEgEgKQgFgJAEgIQADgKAJgEQAKgFAIAEQAKADAEAJQAFAKgEAHQgDAKgKAGQgFACgFAAIgHgBg");
	this.shape_49.setTransform(-94.1,138.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FCD888").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_50.setTransform(-90.5,133.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#F3AA5D").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAADAEQAEADAAAEQAAAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_51.setTransform(-110.2,69.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#F3AA5D").s().p("AgNANQgFgGAAgHQABgHAFgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgGAFgHAAQgHAAgGgGg");
	this.shape_52.setTransform(-154.2,107.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#F19F4E").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQABgFAEABQAGAAAAAEQAAAGgGAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_53.setTransform(-119.6,72.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#F7BD56").s().p("AgMANQgGgGABgHQAAgGAGgGQAFgFAGgBQAIABAFAGQAGAFgBAGQAAAIgFAFQgGAGgHgBQgHAAgFgFg");
	this.shape_54.setTransform(-114.5,77.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FCD888").s().p("AgHAIQgEgEAAgEQAAgEAEgDQADgEAEAAQAFAAADAEQAEAEAAADQgBAFgDADQgEAEgEAAQgEgBgDgDg");
	this.shape_55.setTransform(-119.1,76.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAEACQAHACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_56.setTransform(-126.2,77.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKAEAFAJQAFAKgEAIQgDAKgKAFQgFADgGAAQgCAAgFgCg");
	this.shape_57.setTransform(-131.7,78.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#F19F4E").s().p("AgBAHQgIgCADgGQACgHAGACQADABACADQABACgBACQgBAGgFAAIgCgBg");
	this.shape_58.setTransform(-127.8,82.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgKQgFgJADgIQAEgKAJgEQAKgFAIAEQAKADAEAJQAFAKgEAIQgDAKgKAEQgFADgFAAIgHgCg");
	this.shape_59.setTransform(-121.3,105.2);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgGQgDgGACgFQACgGAGgDQAGgDAFACQAGADADAFQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_60.setTransform(-152.8,116.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAFgIQAFgIAKgCQAHgCAIAFQAIAFACAKQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_61.setTransform(-148.9,94.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F19F4E").s().p("AgFAJQgEgDAAgEQgBgDACgEQADgEAEgBQADAAAEACQAEACAAAFQACACgDAEQgDAEgEACIgCAAQgCAAgDgCg");
	this.shape_62.setTransform(-124.2,72.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_63.setTransform(-121.1,81.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F3AA5D").s().p("AgMANQgGgGAAgHQABgHAFgGQAGgFAGAAQAIAAAFAGQAGAGAAAGQAAAIgGAGQgGAFgHAAQgHAAgFgGg");
	this.shape_64.setTransform(29.3,78.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F7BD56").s().p("AgMAMQgGgFABgHQAAgHAFgFQAGgGAGABQAIAAAFAFQAGAGgBAGQAAAIgGAFQgFAFgHABQgHgBgFgGg");
	this.shape_65.setTransform(33.7,91.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F7BD56").s().p("AgHAXQgJgDgFgKQgFgJAEgIQADgJAKgFQAJgFAIAEQAKADAEAKQAFAJgEAIQgDAKgKAEQgFADgFAAIgHgCg");
	this.shape_66.setTransform(-11.2,109.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgHQgDgGACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAEQgCAHgGADQgEACgDAAIgEgBg");
	this.shape_67.setTransform(-9.6,104.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F19F4E").s().p("AgKAhQgOgFgHgNQgGgNAFgMQAFgOANgGQANgHAMAFQAOAFAGANQAHANgFAMQgFAOgNAGQgIAEgHAAQgEAAgGgCg");
	this.shape_68.setTransform(56.2,146.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F3AA5D").s().p("AgTAeQgMgIgDgPQgDgNAIgNQAJgMAOgDQANgDANAIQAMAIADAPQADAMgIAOQgIAMgPADIgHABQgJAAgKgGg");
	this.shape_69.setTransform(34.6,83.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#F19F4E").s().p("AgFAJQgEgDgBgEQAAgDACgEQADgEAEgBQADgBAEADQAEACABAFQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_70.setTransform(36.3,135.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgOQgDgMAIgNQAIgMAOgDQANgDAMAIQAMAIADAOQADAMgIANQgIAMgPADIgGABQgJAAgJgGg");
	this.shape_71.setTransform(-94.2,127.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_72.setTransform(36.6,125.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F3AA5D").s().p("AgFAHQgDgCgBgEQAAgCACgDQADgEAEAAQACgBADADQAIAGgGAGQgCADgFABQgCAAgDgDg");
	this.shape_73.setTransform(-103.3,130.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#F3AA5D").s().p("AgIAMQgFgEgBgHQgBgFAEgEQAEgFAHgBQAEgBAFAEQAFAEABAHQABADgEAGQgEAFgHABIgBAAQgEAAgEgDg");
	this.shape_74.setTransform(-100.2,132.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#F19F4E").s().p("AgBADQgFgCAEgDQACgDADACQADADgCACQgBABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAIgBgCg");
	this.shape_75.setTransform(-106,138.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F7BD56").s().p("AgIAMQgFgFgBgGQgBgEAEgFQAEgFAHAAQAEgBAFADQAFAEABAGQAAAFgEAEQgDAGgHAAIgBABQgEAAgEgDg");
	this.shape_76.setTransform(-100.5,137.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FCD888").s().p("AgFAHQgDgCgBgEQAAgCACgDQADgEAEAAQACgBADADQAIAGgGAGQgDADgEABQgCAAgDgDg");
	this.shape_77.setTransform(-103.5,139.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F3AA5D").s().p("AgBAMQgFAAgDgFQgEgEABgEQABgFAFgDQAFgEADABQAGABACAFQADAEgBAEQgBAFgEADQgDADgEAAIgBgBg");
	this.shape_78.setTransform(-106.3,144.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F3AA5D").s().p("AgDAUQgIgCgFgHQgFgHACgHQABgIAHgFQAHgFAHACQAJABAFAHQAFAHgCAHQgCAJgHAFQgFAEgGAAIgDgBg");
	this.shape_79.setTransform(-110,147.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#F19F4E").s().p("AgEADQgEgDAGgEQADgDAEAFQACACgBABQAAADgDABIgDABQgCAAgCgDg");
	this.shape_80.setTransform(-114.8,138.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#F7BD56").s().p("AgCAUQgIgCgFgHQgFgHABgGQACgIAHgFQAHgFAGACQAJABAEAHQAFAHgBAGQgCAJgHAFQgFADgGAAIgCAAg");
	this.shape_81.setTransform(-115.6,145.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FCD888").s().p("AgBAMQgFgBgDgEQgEgEABgEQABgFAFgEQAFgCADAAQAFACADAEQAEAFgBADQgBAGgFADQgEACgDAAIgBgBg");
	this.shape_82.setTransform(-117.4,140.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#F3AA5D").s().p("AgGAQQgHgDgDgHQgDgGAEgGQADgHAHgDQAFgCAHADQAHADADAHQACAFgDAHQgDAHgHADIgGABQgDAAgDgCg");
	this.shape_83.setTransform(-109.5,135.9);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#F3AA5D").s().p("AgKAaQgLgFgFgLQgEgKAFgLQAFgLAMgEQAJgEALAFQALAFAEALQAEAKgFALQgFALgLAEQgFACgFAAQgEAAgGgDg");
	this.shape_84.setTransform(-116,133.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#F3AA5D").s().p("AgFAGQgCgDgBgDQABgDACgCQADgDACABQADAAADACQACADAAACQAAAIgIAAQgDAAgCgCg");
	this.shape_85.setTransform(-126.3,150.6);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#F3AA5D").s().p("AAAANQgFAAgEgEQgEgEABgFQAAgFAEgEQAEgEAEAAQAGABAEAEQAEAEAAAEQgBAGgEAEQgEAEgFAAIAAgBg");
	this.shape_86.setTransform(-54.9,20.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#F7BD56").s().p("AgIAJQgEgEAAgFQAAgEAEgEQAEgEAEAAQAFAAAEAEQAEAEAAAEQAAAFgEAEQgEAEgFAAQgFAAgDgEg");
	this.shape_87.setTransform(-52.2,32.6);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FCD888").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQAEAAACADQADACgBACQAAAEgCACQgDADgDAAQgCgBgDgDg");
	this.shape_88.setTransform(-50,23.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#F3AA5D").s().p("AgCALQgFgCgCgEQgCgFABgCQACgFAEgCQAEgCADABQAFACACAEQACAEgBADQgCAFgEACIgFABIgCAAg");
	this.shape_89.setTransform(-57,34.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#F7BD56").s().p("AgEARQgHgDgEgHQgDgHACgFQADgHAHgDQAGgDAFACQAHADAEAGQADAHgCAFQgDAHgGAEQgEACgEAAIgEgBg");
	this.shape_90.setTransform(-136.5,136.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#F3AA5D").s().p("AgNAVQgJgGgCgLQgCgIAFgJQAGgJALgCQAIgCAJAFQAKAGACALQACAIgGAJQgGAKgLACIgEABQgHAAgGgFg");
	this.shape_91.setTransform(-135.1,143.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#F19F4E").s().p("AgHABQAAgBABgDQACgDAEgBQAFgBACAIQABABgCADQgBADgEAAIgBABQgFAAgCgHg");
	this.shape_92.setTransform(-121.9,142.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#F7BD56").s().p("AgMAVQgJgGgCgKQgCgJAGgJQAFgIALgCQAIgCAJAFQAIAGACAKQADAIgGAJQgGAJgKACIgFABQgGAAgGgEg");
	this.shape_93.setTransform(-130.1,137.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FCD888").s().p("AgIANQgFgDgCgHQgBgFAEgGQAEgFAGgCQAFgBAFAEQAGADACAHQABAFgEAFQgEAGgGACIgDAAQgDAAgFgDg");
	this.shape_94.setTransform(-123.6,138.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#F19F4E").s().p("AgSAdQgMgIgDgOQgDgNAIgMQAIgMAOgDQANgDAMAIQAMAIADAOQADANgIAMQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_95.setTransform(-127.5,145.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#F3AA5D").s().p("AgEALQgEgDgCgFQgBgDACgEQACgFAEgBQADgCAFACQAEADACAEQACADgCAEQgDAFgEACIgEABIgEgBg");
	this.shape_96.setTransform(38.2,89.6);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#F3AA5D").s().p("AgHARQgHgEgDgHQgCgGADgHQAEgHAHgDQAGgDAHAEQAHADADAIQADAGgEAHQgDAHgIADIgGABQgDAAgEgCg");
	this.shape_97.setTransform(-14.2,103.6);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#F7BD56").s().p("AgHAQQgHgDgCgHQgDgGADgHQADgHAIgCQAFgDAHADQAHAEADAHQADAFgEAHQgDAHgIADIgFABQgCAAgFgCg");
	this.shape_98.setTransform(-0.2,102.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#F19F4E").s().p("AgKAXQgKgFgEgKQgDgIAEgKQAFgKALgEQAIgDAKAEQAKAFAEAKQADAJgFAKQgEAKgKADQgFACgEAAQgEAAgGgDg");
	this.shape_99.setTransform(62.4,53.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#F3AA5D").s().p("AgKAMQgFgFAAgHQAAgEAFgFQAEgFAGgBQAGAAAFAFQAFAEAAAGQAAAGgEAFQgFAFgHAAIAAAAQgFAAgFgEg");
	this.shape_100.setTransform(39.4,130.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#F3AA5D").s().p("AgQATQgIgIAAgKQgBgJAHgIQAIgJAKABQAJgBAIAIQAIAHAAAKQABAJgIAJQgHAHgLABIAAAAQgJAAgHgHg");
	this.shape_101.setTransform(39.5,156.6);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F19F4E").s().p("AgEAFQgDgCAAgDQAAgCACgCQAFgGAFAFQADADAAACQAAADgDACQgCADgDAAQgBAAgDgDg");
	this.shape_102.setTransform(40.5,94.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F7BD56").s().p("AgQASQgHgHgBgLQAAgIAHgIQAHgIAKAAQAJAAAIAHQAHAHABAKQAAAJgHAIQgHAHgLABQgIAAgIgHg");
	this.shape_103.setTransform(37,117.6);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FCD888").s().p("AgKAMQgFgFAAgHQAAgFAFgFQAEgFAGAAQAGAAAFAFQAFAEAAAGQAAAGgEAFQgFAFgHAAIAAAAQgFAAgFgEg");
	this.shape_104.setTransform(-10.7,98.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#F3AA5D").s().p("AgDAWQgKgCgFgIQgFgIACgIQACgJAIgFQAIgFAHACQAKACAFAIQAFAIgCAHQgCAJgIAFQgGAEgGAAIgDAAg");
	this.shape_105.setTransform(34.9,97.8);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F19F4E").s().p("AgBALQgFgBgCgEQgCgEABgDQABgFADgCQAFgCACAAQAEABADAFQADADgCADQAAAFgEACQgDACgDAAIgBAAg");
	this.shape_106.setTransform(-3.1,92.1);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FCD888").s().p("AgDAWQgJgCgFgIQgGgIACgHQADgJAHgFQAIgGAHACQAKADAFAHQAFAIgCAHQgCAKgIAFQgFADgHAAIgDAAg");
	this.shape_107.setTransform(93.2,134.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F3AA5D").s().p("AAAAMQgEAAgDgEQgEgEAAgEQAAgEAEgDQAEgEADAAQAFABAEADQADAEAAADQgBAFgDAEQgDADgFAAIAAAAg");
	this.shape_108.setTransform(78,88.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_109.setTransform(20.1,71.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#F7BD56").s().p("AAAASQgHAAgFgFQgGgGAAgHQABgHAGgFQAFgFAGAAQAIAAAFAGQAGAFgBAGQAAAIgFAFQgGAFgHAAIAAAAg");
	this.shape_110.setTransform(12.1,72.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FCD888").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFABADADQAEAEAAADQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_111.setTransform(13.5,67.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#F19F4E").s().p("AAAAaQgKAAgIgIQgHgIAAgKQABgKAIgIQAHgIAJABQALABAIAHQAHAIAAAJQAAALgIAIQgIAHgKAAIAAAAg");
	this.shape_112.setTransform(-15.1,61.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#F3AA5D").s().p("AgEAPQgGgCgDgHQgDgGACgEQADgHAFgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_113.setTransform(-67.7,19.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKADAFAKQAFAKgEAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_114.setTransform(-72.4,14.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#F19F4E").s().p("AgBAHQgIgCADgGQABgDADgCQACgBACABQAHACgCAGQgBAEgDABIgDABIgBgBg");
	this.shape_115.setTransform(-49.9,28.4);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#F7BD56").s().p("AgCALQgFgBgDgFQgCgFABgDQADgFAEgCQAEgCAEACQAEABADAFQACAEgBAEQgCAFgFACIgFABIgCgBg");
	this.shape_116.setTransform(-67.1,13.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FCD888").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_117.setTransform(65.3,47.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F3AA5D").s().p("AgLASQgHgFgDgJQgCgHAFgIQAFgIAKgCQAHgCAIAFQAIAFACAKQACAHgGAIQgEAIgKACIgEAAQgFAAgGgEg");
	this.shape_118.setTransform(77.6,44.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#F19F4E").s().p("AgFAJQgEgDgBgEQAAgDACgEQADgEAEgBQADgBAEADQAEACABAFQABADgDAEQgCAEgFABIgCAAQgCAAgDgCg");
	this.shape_119.setTransform(-12.4,76.9);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FCD888").s().p("AgLASQgHgFgDgJQgCgHAGgIQAEgIAKgCQAHgCAIAFQAIAFACAKQACAHgGAIQgEAIgKACIgEAAQgFAAgGgEg");
	this.shape_120.setTransform(-12.9,83.9);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#F3AA5D").s().p("AgEAKQgFgCgBgFQgCgDADgEQACgFAFgBQADgCAEADQAFACABAFQACADgDAEQgCAFgFABIgDABQgCAAgCgCg");
	this.shape_121.setTransform(-88.3,114.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#F19F4E").s().p("AgBAFQgFgEACgCQADgGADADQABAAAAABQABAAAAAAQABABAAAAQAAABAAABQABAAgBACQgCAEgDAAIgBgBg");
	this.shape_122.setTransform(-69,99.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#F7BD56").s().p("AgMAMQgFgFgBgHQABgHAGgFQAFgGAGABQAIAAAFAFQAGAGgBAGQAAAIgFAFQgGAFgHABQgHgBgFgGg");
	this.shape_123.setTransform(-143.6,88.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FCD888").s().p("AgEAKQgFgCgBgFQgCgDADgEQACgFAFgBQADgCAEADQAFACABAFQACADgDAEQgCAFgFABIgDABQgBAAgDgCg");
	this.shape_124.setTransform(-65.8,100.3);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#F3AA5D").s().p("AgLALQgEgFAAgGQAAgGAFgFQAFgEAFAAQAHAAAEAFQAFAFAAAFQAAAGgFAGQgFAEgGAAQgFAAgGgFg");
	this.shape_125.setTransform(-68,107.3);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#F3AA5D").s().p("AAAAZQgKAAgIgIQgHgHAAgKQABgKAHgIQAIgHAJABQALAAAHAHQAIAIgBAJQABALgJAIQgHAHgKAAIAAgBg");
	this.shape_126.setTransform(-72,111.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#F19F4E").s().p("AgEAFQgGgFAGgEQAEgGAGAGQAFAEgGAFQgCADgDAAQgCAAgCgDg");
	this.shape_127.setTransform(-79.8,101.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#F7BD56").s().p("AgRARQgHgIAAgJQABgKAHgHQAIgHAIAAQALAAAHAIQAHAHAAAJQAAAKgIAIQgHAHgKAAQgJgBgIgHg");
	this.shape_128.setTransform(-79.2,110.4);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FCD888").s().p("AgKALQgFgFAAgGQAAgFAFgGQAFgEAFAAQAGAAAFAFQAFAFAAAFQAAAGgFAGQgFAEgGAAQgGAAgEgFg");
	this.shape_129.setTransform(-82.3,104.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#F19F4E").s().p("AgFAJQgDgDgBgEQgCgDADgEQADgEAEgBQACgBAFADQAEACAAAFQABADgCAEQgDAEgFABIgBAAQgCAAgDgCg");
	this.shape_130.setTransform(-47.5,72.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_131.setTransform(-61.7,95.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#F3AA5D").s().p("AgHAIQgEgEABgEQAAgEADgEQAEgDADAAQAFAAAEAEQADAEgBADQABAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_132.setTransform(0.4,94.7);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_133.setTransform(68.5,75.1);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#F19F4E").s().p("AAAAFQgFAAAAgFQAAgFAFAAQAAAAABABQAAAAABAAQAAAAABABQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAAAAAAAQgBAGgEAAIgBgBg");
	this.shape_134.setTransform(9,66.7);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#F7BD56").s().p("AgMAMQgGgFABgHQAAgHAFgFQAGgGAGABQAIAAAFAFQAFAGAAAGQAAAIgGAFQgFAFgHAAQgHAAgFgGg");
	this.shape_135.setTransform(41.3,122.4);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FCD888").s().p("AgIAIQgDgEAAgEQAAgEAEgDQADgEAEAAQAFABADADQAEAEAAADQgBAFgDADQgEAEgEAAQgEAAgEgEg");
	this.shape_136.setTransform(64,61.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#F19F4E").s().p("AAAAaQgKAAgIgIQgHgIAAgKQABgKAIgIQAHgHAJAAQALABAIAHQAHAIAAAJQAAAMgIAHQgIAHgKAAIAAAAg");
	this.shape_137.setTransform(83.6,109.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#F3AA5D").s().p("AgEAPQgGgCgDgGQgDgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_138.setTransform(-5.7,111.9);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQADgKAKgFQAKgFAIAEQAKADAFAKQAFAKgEAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_139.setTransform(-4.4,98);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#F19F4E").s().p("AgBAHQgIgCADgGQADgIAFADQAHACgCAGQgBAEgDABIgDABIgBgBg");
	this.shape_140.setTransform(19,66.6);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#F7BD56").s().p("AgHAYQgKgEgEgKQgFgJADgIQAEgKAJgEQAKgFAIAEQAKADAEAJQAFAKgEAHQgDAKgKAGQgFACgFAAIgHgBg");
	this.shape_141.setTransform(0.5,89.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FCD888").s().p("AgEAPQgHgDgDgFQgCgHACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgDAGgFADQgEACgDAAIgEgBg");
	this.shape_142.setTransform(4.5,77.7);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#F3AA5D").s().p("AgLATQgIgFgCgKQgCgHAGgIQAEgIAKgCQAHgCAIAGQAIAFACAJQACAHgFAIQgGAIgJACIgEAAQgFAAgGgDg");
	this.shape_143.setTransform(-5.1,106.6);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#F19F4E").s().p("AgFAJQgEgCgBgFQgBgDADgEQACgEAFgBQADAAAEACQAEACABAFQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_144.setTransform(25.4,71.5);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgFAIQgFAIgKACIgEAAQgFAAgGgEg");
	this.shape_145.setTransform(73.7,79.8);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#F7BD56").s().p("AgIAMQgFgEgBgGQgBgFAEgFQAEgFAHAAQAEgBAFADQAFAEABAGQAAAFgEAFQgDAFgHAAIgBABQgEAAgEgDg");
	this.shape_146.setTransform(-18.2,96.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#F3AA5D").s().p("AgBANQgFgBgDgFQgEgFABgDQABgFAFgEQAFgCADABQAFABADAEQAEAEgBAEQgBAGgFADQgDACgEAAIgBAAg");
	this.shape_147.setTransform(-12.9,72.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#F3AA5D").s().p("AgCAUQgJgCgFgHQgFgHACgHQABgIAIgFQAHgFAGACQAJABAFAHQAFAHgCAHQgBAJgIAFQgFAEgGAAIgCgBg");
	this.shape_148.setTransform(-20.9,56.6);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#F19F4E").s().p("AgEADQgEgDAGgEQADgEAEAGQADADgFAEIgDACQgCAAgCgEg");
	this.shape_149.setTransform(-26.2,50.4);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#F7BD56").s().p("AgCAUQgIgCgFgHQgFgHACgGQABgIAHgFQAHgFAGACQAJABAFAHQAEAHgBAGQgCAJgHAEQgFAEgGAAIgCAAg");
	this.shape_150.setTransform(-29.5,56.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FCD888").s().p("AgBAMQgFgBgDgEQgEgFACgDQAAgFAFgDQAEgEAEABQAFABADAFQADAFgBADQAAAGgFACQgDADgEAAIgBgBg");
	this.shape_151.setTransform(-18.8,101.4);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#F3AA5D").s().p("AgGAQQgHgDgDgHQgCgGADgGQADgHAHgDQAFgDAHAEQAHADADAHQADAFgEAHQgDAHgHADIgGABQgDAAgDgCg");
	this.shape_152.setTransform(-52.8,75.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#F7BD56").s().p("AgKAZQgLgFgEgLQgEgJAFgKQAFgLALgEQAJgEAKAFQALAFAEALQAEAJgFAKQgFALgLAEQgFACgEAAQgEAAgGgDg");
	this.shape_153.setTransform(-14.2,90.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FCD888").s().p("AgGAQQgHgDgDgHQgDgGAEgGQADgHAHgDQAFgCAHADQAHADADAHQACAGgDAGQgDAHgHADIgGABQgCAAgEgCg");
	this.shape_154.setTransform(-11.1,66.7);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#F3AA5D").s().p("AAAAIQgCAAgDgCQgCgDAAgDQAAgCADgDQACgCACAAQADAAADADQADACgBACQAAAEgCACQgDACgDAAIAAAAg");
	this.shape_155.setTransform(-39.9,63.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#F3AA5D").s().p("AgIAJQgFgEABgFQAAgFAEgEQAEgDAEAAQAGgBAEAFQAEAEAAAEQgBAFgEAEQgEAFgFAAQgEAAgEgFg");
	this.shape_156.setTransform(-25.1,53.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#F19F4E").s().p("AgDAAQAAgDADAAQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape_157.setTransform(-46.7,65.4);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#F7BD56").s().p("AgIAJQgEgEAAgFQAAgEAEgEQAEgEAEAAQAFAAAEAEQAEAEAAAEQAAAFgEAEQgEAEgFAAQgEAAgEgEg");
	this.shape_158.setTransform(-43,68.7);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FCD888").s().p("AgFAGQgDgDABgDQAAgDACgCQADgDACABQADAAADACQACADAAACQAAAIgIAAQgDAAgCgCg");
	this.shape_159.setTransform(-46.3,67.7);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#F19F4E").s().p("AAAASQgHAAgFgGQgGgFAAgHQABgHAGgFQAFgGAGAAQAIABAFAFQAGAGAAAGQgBAIgFAFQgFAGgHAAIgBgBg");
	this.shape_160.setTransform(-43.4,64.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#F3AA5D").s().p("AgDAKQgEgBgCgEQgCgFABgCQACgFAEgCQAEgDADACQAFACACAFQACADgCAEQgBAEgFACIgEABIgDgBg");
	this.shape_161.setTransform(-53.4,82);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#F3AA5D").s().p("AgFARQgHgCgDgHQgEgHADgFQACgIAIgDQAGgEAFADQAIACAEAHQADAHgCAGQgDAHgHAEQgEABgEAAIgFgBg");
	this.shape_162.setTransform(-81.5,50.5);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#F19F4E").s().p("AAAAFQgGgCACgDQACgGAEACQAFACgCADQgBAFgEAAIAAgBg");
	this.shape_163.setTransform(-51.4,59);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#F7BD56").s().p("AgEARQgHgDgEgGQgDgIACgFQADgGAHgEQAGgDAFADQAHABAEAHQADAHgCAGQgDAGgHAEQgDACgEAAIgEgBg");
	this.shape_164.setTransform(-75.8,47.5);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FCD888").s().p("AgCALQgFgCgCgEQgCgFABgCQACgFAEgCQAEgCADABQAFACACAEQACAEgBADQgCAFgEACIgFABIgCAAg");
	this.shape_165.setTransform(-76.8,51.8);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#F19F4E").s().p("AgHAYQgKgEgFgKQgEgJADgIQAEgKAJgFQAKgEAIADQAKAEAEAJQAFAKgEAIQgDAKgKAFQgFACgFAAIgHgBg");
	this.shape_166.setTransform(-69.9,44.4);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#F3AA5D").s().p("AgHANQgGgDgBgHQgCgFAEgFQAEgGAGgBQAFgCAGAEQAFAEACAGQABAFgEAGQgDAFgHACIgDAAQgDAAgEgDg");
	this.shape_167.setTransform(-19.3,105.9);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#F19F4E").s().p("AgDAGQgDgCgBgDQgBgGAIgCQAFgBACAIQABABgCADQgCADgDAAIgBABIgDgCg");
	this.shape_168.setTransform(-35.5,55);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#F7BD56").s().p("AgNAVQgIgGgCgKQgCgJAFgIQAGgJAKgCQAIgCAJAFQAJAGACAKQACAIgGAJQgFAJgLACIgEABQgGAAgHgEg");
	this.shape_169.setTransform(-37.2,59.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#FCD888").s().p("AgIANQgFgDgCgHQgBgFAEgGQAEgFAGgCQAFgBAFAEQAGAEACAGQABAFgEAFQgEAGgGABIgDABQgEAAgEgDg");
	this.shape_170.setTransform(-58.2,87.9);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#F19F4E").s().p("AgSAdQgMgIgDgOQgDgNAIgMQAIgMAOgDQANgDAMAIQAMAIADAOQADANgIAMQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_171.setTransform(-63.1,41.5);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#F3AA5D").s().p("AgFAKQgEgDgBgFQgBgDACgEQADgFAFgBQADgBAEADQAFADABAFQABADgDAEQgDAEgFABIgCABQgCAAgDgCg");
	this.shape_172.setTransform(43.6,173.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#F3AA5D").s().p("AgJAQQgHgEgCgJQgBgFAEgHQAEgHAIgBQAGgDAHAFQAHAFABAHQACAGgEAHQgFAHgIABIgDABQgFAAgEgDg");
	this.shape_173.setTransform(101.2,164.9);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#F19F4E").s().p("AgEABQgCgEAGgCQAEgBABAGQAAAAABAAQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAABQgBAAAAAAQgBAAAAAAIgBABQgEAAAAgFg");
	this.shape_174.setTransform(38.5,164.6);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#F7BD56").s().p("AgJAPQgHgEgBgHQgBgGADgHQAFgGAIgCQAFgCAGAFQAHAEACAIQABAFgEAHQgEAGgHACIgEAAQgFAAgEgDg");
	this.shape_175.setTransform(94.8,187.9);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#FCD888").s().p("AgFAKQgFgDgBgFQAAgDACgEQADgFAFgBQADAAAEACQAEADABAFQABADgCAEQgDAEgFABIgCABQgCAAgDgCg");
	this.shape_176.setTransform(43.9,146);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#F3AA5D").s().p("AAAAQQgGgBgFgFQgEgFAAgFQABgHAFgEQAFgEAFAAQAGABAFAFQAEAFAAAFQgBAHgFAEQgEAEgGAAIAAAAg");
	this.shape_177.setTransform(44.3,138.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#F19F4E").s().p("AAAAIQgDgBgCgCQgCgDAAgCQABgHAGABQAEAAACACQACADAAABQgBAEgCACQgCACgDAAIAAAAg");
	this.shape_178.setTransform(45.5,156.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#F7BD56").s().p("AgBAZQgLgBgGgIQgGgIAAgJQACgKAHgHQAJgGAIAAQAKABAHAJQAGAIAAAIQgBAKgIAHQgHAGgJAAIgBAAg");
	this.shape_179.setTransform(39.1,149.5);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#FCD888").s().p("AAAAQQgHgBgEgFQgEgFAAgFQABgHAFgEQAGgEAEAAQAHABAEAFQAFAFgBAFQgBAHgFAEQgFAEgFAAIAAAAg");
	this.shape_180.setTransform(45.1,151.8);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#F3AA5D").s().p("AgGAVQgJgEgEgIQgEgIADgHQADgJAJgEQAIgEAHADQAJAEAEAIQAEAIgDAHQgDAJgJAEQgFACgEAAIgGgBg");
	this.shape_181.setTransform(43.4,163.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#F19F4E").s().p("AgCAKQgEgCgDgEQgCgEACgDQACgEAEgCQADgCADACQAFABACAEQACAEgCADQgBAEgFADIgEABIgCgBg");
	this.shape_182.setTransform(56.2,176.3);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#F7BD56").s().p("AgLAgQgNgFgGgNQgHgNAFgMQAFgNANgGQANgHAMAFQAOAFAGANQAGANgFAMQgFAOgNAGQgHAEgHAAQgEAAgHgDg");
	this.shape_183.setTransform(59.6,163.9);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#F19F4E").s().p("AgPAuQgTgHgJgSQgJgTAHgRQAHgTASgJQATgJARAHQATAHAJASQAJATgHARQgHATgSAJQgLAFgKAAQgHAAgIgDg");
	this.shape_184.setTransform(50.5,169.8);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#F3AA5D").s().p("AgBALQgFgBgDgDQgCgFAAgCQABgGAFgCQADgEAEABQAEABADAEQAEAEgBADQgBAFgEAEQgDACgEAAIgBgBg");
	this.shape_185.setTransform(76.9,193.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#F19F4E").s().p("AgDADQgEgDAFgEQADgDADAFQAEADgFADIgDACQgBAAgCgDg");
	this.shape_186.setTransform(89.4,196.4);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#F7BD56").s().p("AgBASQgIgBgFgGQgEgHABgGQABgHAGgEQAHgGAFACQAIABAFAGQAEAHgBAGQgBAHgGAEQgFAEgGAAIgBAAg");
	this.shape_187.setTransform(68.9,198.7);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#FCD888").s().p("AgBAMQgEgBgEgEQgCgEAAgEQABgFAFgDQADgDAEABQAEABAEAEQADAEgBADQgBAFgEADQgDADgEAAIgBAAg");
	this.shape_188.setTransform(77.4,198.8);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#F19F4E").s().p("AgDAZQgKgBgHgJQgGgJABgJQACgKAJgHQAJgHAJADQAKABAHAJQAGAJgBAJQgCALgJAGQgHAFgHAAIgEgBg");
	this.shape_189.setTransform(37.8,141.6);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#F3AA5D").s().p("AgGAOQgGgDgCgGQgCgFADgGQADgGAGgCQAFgCAGADQAGADACAGQACAFgDAGQgDAGgGACIgFABQgCAAgEgCg");
	this.shape_190.setTransform(82.4,193.5);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#F3AA5D").s().p("AgKAXQgKgFgDgKQgEgJAFgJQAFgKAKgDQAIgEAKAFQAKAFADAKQAEAIgFAKQgFAKgKADIgIACQgEAAgGgDg");
	this.shape_191.setTransform(88.9,189.5);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#F19F4E").s().p("AgGACQgBgCABgCQACgDADgBQAGgDACAIQABABgBADQgCADgDABIgCABQgEAAgCgGg");
	this.shape_192.setTransform(73.5,197.3);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#F7BD56").s().p("AgKAWQgJgEgDgKQgEgJAFgJQAEgJALgEQAHgDAKAFQAJAEADAKQAEAIgFAJQgFAKgKAEIgHABQgEAAgGgDg");
	this.shape_193.setTransform(94.2,193.5);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#FCD888").s().p("AgGAOQgGgDgCgGQgCgFADgGQADgGAGgCQAFgCAGADQAGADACAHQACAEgDAGQgDAGgHACIgEABQgDAAgDgCg");
	this.shape_194.setTransform(79,187.7);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#F3AA5D").s().p("AgOARQgHgHAAgJQgBgHAGgHQAGgHAKgBQAHgBAHAGQAHAGABAKQABAHgHAHQgGAHgJABIgBAAQgHAAgHgFg");
	this.shape_195.setTransform(50.5,151.4);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#F19F4E").s().p("AgGAIQgEgDAAgFQAAgCADgEQADgEAEABQAEgBADADQADADABAEQAAADgDAEQgDAEgEgBIgBABQgDAAgDgDg");
	this.shape_196.setTransform(82,172.3);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#F7BD56").s().p("AgVAaQgLgJgCgPQgBgMAKgLQAJgLAPgCQAMgBALAKQALAJACAPQABAMgKALQgJALgPACIgCAAQgLAAgKgJg");
	this.shape_197.setTransform(103.7,158);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#FCD888").s().p("AgNAQQgHgGgBgJQgBgIAGgHQAHgHAJAAQAHgBAHAGQAHAGABAKQABAHgGAHQgGAHgKABIgBAAQgHAAgGgGg");
	this.shape_198.setTransform(87.3,175.4);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#F19F4E").s().p("AgeAlQgQgNgBgVQgCgSANgPQAOgQAUgBQASgCAQANQAPAOACAUQABASgNAQQgNAPgVACIgDAAQgRAAgNgMg");
	this.shape_199.setTransform(95.7,170.4);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#F3AA5D").s().p("AAAAMQgFgBgDgEQgDgEAAgDQABgFAEgDQAEgDADAAQAFABADAEQADAEAAADQgBAFgEADQgEADgDAAIAAAAg");
	this.shape_200.setTransform(101.9,135.1);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#F3AA5D").s().p("AgBATQgIgCgFgGQgFgGABgHQACgHAGgFQAHgFAGABQAHABAFAHQAFAGgBAHQgCAHgGAFQgFAEgGAAIgBAAg");
	this.shape_201.setTransform(98.9,131.7);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#F7BD56").s().p("AgCASQgHgBgFgGQgFgHACgFQABgIAGgFQAHgEAFABQAIABAFAGQAEAHgBAFQgBAIgHAFQgFADgFAAIgCAAg");
	this.shape_202.setTransform(100.7,126.5);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FCD888").s().p("AgBAMQgEgBgEgEQgDgEABgDQABgFAEgDQAEgDAEAAQAEABAEAEQACAEAAADQgBAFgFADQgDADgDAAIgBAAg");
	this.shape_203.setTransform(94.2,127);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#F3AA5D").s().p("AgGAOQgGgDgCgGQgCgFADgGQADgGAGgCQAFgCAGADQAGADACAGQACAFgDAGQgDAGgGACIgFABQgCAAgEgCg");
	this.shape_204.setTransform(92.3,112.6);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#F3AA5D").s().p("AgKAXQgKgFgDgKQgEgJAFgJQAFgKAKgDQAIgEAKAFQAKAFADAKQAEAIgFAKQgFAKgKADIgIACQgFAAgFgDg");
	this.shape_205.setTransform(76.7,167.5);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#F19F4E").s().p("AgGACQgDgFAIgDQAFgDADAIQADAFgIADIgCABQgEAAgCgGg");
	this.shape_206.setTransform(86.6,120.1);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#F7BD56").s().p("AgKAWQgJgEgEgLQgDgIAFgJQAFgJAJgDQAIgEAKAFQAJAFADAJQAEAJgFAIQgFAKgKAEIgHABQgEAAgGgDg");
	this.shape_207.setTransform(97.3,140);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#FCD888").s().p("AgGAOQgFgDgDgGQgCgFADgGQADgGAHgCQAEgCAGADQAGADACAGQACAFgDAGQgDAGgGACIgFABQgCAAgEgCg");
	this.shape_208.setTransform(97.1,147.4);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#F19F4E").s().p("AgOAfQgNgGgFgOQgFgMAHgNQAGgNAOgFQAMgFANAHQANAGAFAOQAFANgHANQgGANgOAEQgGACgFAAQgHAAgHgEg");
	this.shape_209.setTransform(93.8,156.5);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#F3AA5D").s().p("AgNARQgHgHgBgJQgBgHAGgHQAHgHAJgBQAHgBAHAGQAHAGABAKQABAHgGAHQgGAHgKABIgBAAQgHAAgGgFg");
	this.shape_210.setTransform(113.4,154.9);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#F19F4E").s().p("AgGAIQgDgDgBgFQAAgCADgEQADgDAEgBQADAAAEADQADADABAEQAAADgDAEQgDAEgFAAIAAAAQgDAAgDgDg");
	this.shape_211.setTransform(104.1,147.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#F7BD56").s().p("AgVAaQgLgJgBgPQgCgNAKgKQAKgMAOgBQAMgBALAKQALAJABAPQACAMgKAMQgKAKgOABIgCABQgMAAgJgJg");
	this.shape_212.setTransform(86.4,164.2);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FCD888").s().p("AgNARQgIgGAAgKQgBgHAGgHQAGgHAKgBQAHgBAHAGQAHAHABAJQABAHgGAHQgHAHgJABIgBAAQgHAAgGgFg");
	this.shape_213.setTransform(109.4,151);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#F19F4E").s().p("AgfAlQgPgNgCgVQgBgSANgQQANgPAVgCQASgBAQANQAPAOACAUQABASgNAQQgNAPgVACIgDAAQgRAAgOgMg");
	this.shape_214.setTransform(106.4,140.7);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#F3AA5D").s().p("AgBAMQgEgBgEgEQgDgEABgDQABgGAFgCQADgDAEAAQAEABAEAEQADAEgBADQgBAFgFADQgDADgDAAIgBAAg");
	this.shape_215.setTransform(54.5,190.5);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#F3AA5D").s().p("AgBATQgJgBgEgHQgFgGABgGQACgIAGgFQAHgFAFACQAJABAEAGQAFAHgCAGQgBAIgGAEQgFAEgGAAIgBAAg");
	this.shape_216.setTransform(51.5,187.1);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#F19F4E").s().p("AgEADQgDgDAFgDQADgEADAFQAEADgFAEIgDABQgBAAgDgDg");
	this.shape_217.setTransform(60.2,182.4);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#F7BD56").s().p("AgBASQgIgBgFgHQgEgGABgFQABgIAGgFQAHgEAFABQAIABAFAGQAEAHgBAFQgBAIgGAFQgFADgGAAIgBAAg");
	this.shape_218.setTransform(53.3,181.9);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FCD888").s().p("AAAAMQgFgBgEgEQgCgEABgDQABgFADgDQAFgDACAAQAGABACAEQADAEgBADQgBAFgDADQgEADgDAAIAAAAg");
	this.shape_219.setTransform(57.8,180.2);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#F19F4E").s().p("AgDAZQgLgBgGgJQgGgJABgJQACgKAJgHQAIgGAKABQAKACAHAJQAGAJgCAJQgBAKgJAHQgHAFgIAAIgDgBg");
	this.shape_220.setTransform(57.3,186.1);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#F3AA5D").s().p("AgGAOQgGgDgCgGQgCgFADgGQADgGAGgCQAFgCAGADQAGADACAGQACAFgDAGQgDAGgGACIgFABQgCAAgEgCg");
	this.shape_221.setTransform(62.7,174.8);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#F3AA5D").s().p("AgKAXQgJgFgEgKQgEgJAFgJQAFgKAKgDQAJgEAJAFQAKAFADAKQAEAIgFAKQgFAJgKAEIgIACQgEAAgGgDg");
	this.shape_222.setTransform(68.3,172.4);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#F19F4E").s().p("AgGACQgBgCABgCQACgDADgBQABgBADABQAEACAAADQADAGgIACIgCABQgEAAgCgGg");
	this.shape_223.setTransform(70.7,185.4);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#F7BD56").s().p("AgKAWQgJgFgEgJQgDgIAFgKQAFgJAJgEQAIgDAKAFQAJAEADALQAEAIgFAJQgFAJgKADIgHACQgEAAgGgDg");
	this.shape_224.setTransform(74.2,176.9);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FCD888").s().p("AgGAOQgGgDgCgGQgCgFADgGQADgGAGgCQAFgCAGADQAGADACAGQACAFgDAGQgDAGgGACIgFABQgCAAgEgCg");
	this.shape_225.setTransform(74.6,183.3);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#F19F4E").s().p("AgOAfQgOgGgEgOQgFgMAHgOQAGgNAOgEQAMgFANAHQANAGAFAOQAFAMgHANQgGANgOAFQgGACgFAAQgHAAgHgEg");
	this.shape_226.setTransform(67.2,180.3);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#F3AA5D").s().p("AgNARQgHgGgBgKQgBgHAGgHQAGgHAKgBQAHgBAHAGQAHAHABAJQABAHgGAHQgGAHgKABIgBAAQgHAAgGgFg");
	this.shape_227.setTransform(63.6,186.3);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#F3AA5D").s().p("AgWAbQgMgKgBgPQgBgNAKgLQAKgMAPgBQANgBALAKQALAJABAQQACAMgKAMQgKALgPABIgCABQgMAAgKgJg");
	this.shape_228.setTransform(70.5,191.2);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#F19F4E").s().p("AgGAIQgDgDgBgEQAAgDADgEQADgDAEgBQADAAAEADQADADABAEQAAADgDAEQgDAEgFAAIAAAAQgDAAgDgDg");
	this.shape_229.setTransform(84.5,197.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#F7BD56").s().p("AgWAaQgKgJgCgPQgBgMAKgMQAJgLAPgBQAMAAAMAJQAKAJACAPQAAANgJAKQgJAMgPABIgCAAQgLAAgLgJg");
	this.shape_230.setTransform(45.1,180.2);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FCD888").s().p("AgOARQgHgHAAgJQgBgHAGgHQAGgIAKAAQAHgBAHAGQAHAGABAKQABAHgGAHQgHAHgJABIgBAAQgHAAgHgFg");
	this.shape_231.setTransform(68.5,164.2);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#F19F4E").s().p("AgeAlQgQgOgCgUQgBgSANgQQANgPAVgCQASgBAQANQAPANACAVQABASgNAQQgNAPgVACIgDAAQgQAAgOgMg");
	this.shape_232.setTransform(60.3,195.5);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#F3AA5D").s().p("AgGAGQgCgCgBgEQABgDACgCQAEgEACAAQADAAAEAEQACACAAADQAAAEgCACQgEADgDABQgCgBgEgDg");
	this.shape_233.setTransform(86.6,193.8);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#F3AA5D").s().p("AgKALQgEgFAAgGQAAgFAEgFQAFgEAFAAQAGAAAFAEQAEAFAAAFQAAAGgEAFQgFAEgGAAQgFAAgFgEg");
	this.shape_234.setTransform(65,150.7);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#F19F4E").s().p("AgDAAQAAgDADAAQAFAAAAADQAAAEgFAAQgDAAAAgEg");
	this.shape_235.setTransform(103.5,188.7);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#F7BD56").s().p("AgJAKQgFgEAAgGQAAgFAFgEQAEgFAFAAQAGAAAEAFQAFAEAAAFQAAAGgFAEQgEAFgGAAQgFAAgEgFg");
	this.shape_236.setTransform(99.9,191.4);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#FCD888").s().p("AgGAGQgCgCAAgEQAAgCACgEQADgDADAAQADAAAEADQADAEAAACQAAAEgDACQgEADgDAAQgDAAgDgDg");
	this.shape_237.setTransform(99.8,187.3);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#F19F4E").s().p("AgNAPQgHgHAAgIQAAgHAHgHQAGgGAHAAQAJAAAGAGQAGAHAAAHQAAAJgGAGQgHAGgIAAQgHAAgGgGg");
	this.shape_238.setTransform(86.7,137);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#F3AA5D").s().p("AgDAMQgFgBgCgFQgDgFACgEQACgFAFgCQAEgDAEACQAFACACAEQADAFgCADQgCAGgFACIgFACIgDgBg");
	this.shape_239.setTransform(99.8,183.4);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#F3AA5D").s().p("AgFAUQgIgDgEgIQgEgIADgGQACgIAIgEQAIgEAGACQAJADADAIQAEAIgCAGQgDAIgIAEQgEADgFAAIgFgBg");
	this.shape_240.setTransform(101.5,176.5);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#F19F4E").s().p("AgBAGQgFgDABgEQABgCADgCQABgBACABQAFACgBAEQgCAFgEAAIgBAAg");
	this.shape_241.setTransform(110.5,183.3);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#F7BD56").s().p("AgFATQgIgDgEgHQgDgIACgGQADgIAHgEQAIgEAGADQAIACAEAIQAEAIgDAGQgCAIgIAEQgFACgEAAIgFgBg");
	this.shape_242.setTransform(108.2,175.5);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#FCD888").s().p("AgDAMQgFgCgDgFQgCgFACgDQACgFAEgCQAFgDADACQAGACACAFQADAEgCAEQgCAFgFACQgDACgCAAIgDgBg");
	this.shape_243.setTransform(111,179.7);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#F19F4E").s().p("AgHAbQgMgDgFgMQgGgKAEgJQAEgMALgFQAKgFAJADQAMAEAFAKQAFALgDAKQgEAKgKAGQgHADgGAAIgHgBg");
	this.shape_244.setTransform(105.1,182.2);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#F3AA5D").s().p("AgIAPQgHgEgBgIQgCgFAEgGQAEgHAIgCQAFgBAHAEQAGAEACAIQABAFgEAGQgEAHgHABIgEABQgEAAgEgDg");
	this.shape_245.setTransform(106.7,187.5);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#F7BD56").s().p("AgOAYQgKgHgCgLQgDgKAGgJQAHgLALgCQAKgCAKAGQAKAFACAMQADAJgGAKQgHALgLACIgGABQgGAAgIgEg");
	this.shape_246.setTransform(106.3,169.4);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FCD888").s().p("AgIAPQgHgEgCgHQgBgGAEgGQAEgHAHgBQAGgCAGAEQAHAEABAHQACAGgEAGQgEAHgIABIgDABQgEAAgEgDg");
	this.shape_247.setTransform(95.2,180.9);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#F19F4E").s().p("AgUAhQgOgJgEgQQgDgOAJgOQAJgNAQgEQAOgEAOAJQAOAJADAQQAEAOgJAOQgJAOgQAEIgIABQgKAAgKgHg");
	this.shape_248.setTransform(84.4,183.2);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#F3AA5D").s().p("AgGAFQgCgDABgCQAAgDADgCQAFgGAGAIQAFAFgHAFQgEACgBAAQgDAAgDgEg");
	this.shape_249.setTransform(112.1,166.4);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#F19F4E").s().p("AgCACQgDgCAEgCQABgDADAEQADABgEADIgCABQAAAAAAAAQAAAAgBAAQAAgBAAAAQgBgBAAAAg");
	this.shape_250.setTransform(116.2,160.6);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#F7BD56").s().p("AgBANQgFgBgDgEQgEgFABgEQABgFAEgEQAFgDAEABQAFABADAFQAEAEgBAEQgBAFgEAEQgEACgEAAIgBAAg");
	this.shape_251.setTransform(111.2,160.2);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#F3AA5D").s().p("AgEAKQgEgCgCgFQgBgDACgEQACgEAFgCQACgBAFACQAEACACAFQABADgCAEQgCAEgFACIgDAAIgEgBg");
	this.shape_252.setTransform(112.1,145.8);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#F3AA5D").s().p("AgHAQQgHgDgCgHQgDgGAEgHQADgHAIgDQAFgCAHADQAHAEACAIQADAFgEAHQgDAHgIACIgFACQgDAAgEgDg");
	this.shape_253.setTransform(91.1,150.8);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#F7BD56").s().p("AgHAQQgHgEgCgHQgCgFADgHQAEgHAHgCQAFgCAHADQAHADACAIQACAFgDAHQgEAGgHADIgFABQgDAAgEgCg");
	this.shape_254.setTransform(86.1,154.7);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#FCD888").s().p("AgEAKQgEgCgCgFQgBgDACgEQACgEAFgCQACgBAFACQAEACACAFQABACgCAFQgCAEgFACIgDAAIgEgBg");
	this.shape_255.setTransform(85.5,131.3);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#F3AA5D").s().p("AgPAUQgIgHgBgLQgBgJAHgIQAHgJALAAQAIgBAJAGQAIAIABAKQAAAJgHAIQgGAIgLABIgCABQgIAAgHgGg");
	this.shape_256.setTransform(59.2,155.2);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#F19F4E").s().p("AgEAGQgDgCAAgEQAAgCACgCQAFgGAFAFQAGAFgGAFQgCACgDABQgCAAgCgCg");
	this.shape_257.setTransform(113.7,175.7);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#F7BD56").s().p("AgPATQgIgHgBgLQgBgIAHgIQAHgIAKgBQAJgBAIAHQAIAHABAKQAAAJgHAIQgHAIgKABIgBAAQgIAAgHgGg");
	this.shape_258.setTransform(77.7,151.7);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#F19F4E").s().p("AgWAaQgLgKgBgOQgBgMAKgMQAJgLAOgBQANgBAMAKQALAJABAOQABANgKAMQgKALgOABIgCAAQgMAAgKgJg");
	this.shape_259.setTransform(116.3,170);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#F3AA5D").s().p("AgEAKQgFgCgCgFQgBgEADgEQADgEAEgBQADgCAFADQAEACACAGQAAADgCAEQgDAEgEACIgDAAQgCAAgCgCg");
	this.shape_260.setTransform(101.6,2.8);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#F3AA5D").s().p("AgIAQQgHgEgCgHQgCgGAEgHQAEgHAIgCQAGgCAGAEQAHAEACAIQACAGgEAHQgEAHgIABIgEABQgEAAgEgDg");
	this.shape_261.setTransform(137.8,17);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#F19F4E").s().p("AgCAFQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAgBAAAAQAAAAAAAAQAAAAAAAAQABgBAAAAQADgFADACQAGAEgEADQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBABIgBAAIgCgBg");
	this.shape_262.setTransform(92,0.7);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#F7BD56").s().p("AgIAQQgHgEgCgIQgCgGAEgGQAEgHAIgCQAFgCAHAEQAGAEADAIQACAFgEAHQgEAGgIADIgEAAQgEAAgEgCg");
	this.shape_263.setTransform(150.4,37.3);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#FCD888").s().p("AgEAKQgFgDgCgFQgBgCADgFQADgEAFgBQACgCAFADQAEACACAGQAAADgCAEQgCAEgFABIgDABQgCAAgCgCg");
	this.shape_264.setTransform(90.8,3.8);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#F19F4E").s().p("AgMAWQgKgFgCgLQgDgIAGgKQAFgJALgDQAIgDAKAGQAKAFACALQADAIgFAKQgGAJgLADIgGABQgFAAgHgEg");
	this.shape_265.setTransform(96.5,1.9);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#F3AA5D").s().p("AAAAQQgGgBgFgFQgEgFAAgFQABgGAFgFQAFgEAEAAQAHABAFAFQAEAFAAAEQgBAHgFAFQgEAEgGAAIAAAAg");
	this.shape_266.setTransform(71.7,69.9);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#F3AA5D").s().p("AAAAaQgLgBgHgIQgHgIAAgJQABgKAIgIQAIgHAJABQALAAAHAJQAHAIAAAIQgBALgIAHQgIAHgJAAIAAAAg");
	this.shape_267.setTransform(67.2,65.7);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#F19F4E").s().p("AAAAIQgCgBgDgCQgCgCAAgDQABgCACgDQADgCABAAQAEABACACQACADAAABQgBAEgCACQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAgBAAIAAAAg");
	this.shape_268.setTransform(90.5,45.5);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#F7BD56").s().p("AAAAZQgKgBgHgIQgHgIAAgIQABgKAIgHQAIgHAIAAQALABAGAIQAHAHAAAJQgBAKgIAHQgHAHgJAAIAAAAg");
	this.shape_269.setTransform(69,58.6);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#FCD888").s().p("AAAAQQgGgBgFgFQgEgFAAgFQAAgGAFgFQAGgEAEAAQAHAAAFAFQAEAFAAAFQgBAHgFAFQgEAEgGAAIAAAAg");
	this.shape_270.setTransform(87,42.8);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#F3AA5D").s().p("AgFAVQgJgCgFgJQgEgIADgHQACgJAJgFQAIgEAHADQAJADAFAIQAEAIgDAHQgDAJgIAFQgFACgFAAIgFgBg");
	this.shape_271.setTransform(94.1,-3.9);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#F3AA5D").s().p("AgJAiQgOgFgIgNQgHgNAFgNQAEgOANgGQAOgIAMAFQAPAEAHAOQAHANgFANQgFANgNAHQgIAFgIAAQgEAAgFgCg");
	this.shape_272.setTransform(95.9,43.5);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#F19F4E").s().p("AgCAKQgEgBgCgEQgDgEACgDQABgEAEgCQAEgDADACQAEABADAEQACAEgCADQgBAEgEADIgFABIgCgBg");
	this.shape_273.setTransform(118.8,50.9);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#F7BD56").s().p("AgJAhQgOgFgGgNQgHgMAEgMQAEgOANgHQANgGAMAEQAOAEAHANQAGANgEAMQgEAOgNAGQgIAFgIAAQgDAAgGgCg");
	this.shape_274.setTransform(108.9,46.9);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#FCD888").s().p("AgFAVQgJgCgFgJQgEgIADgHQADgJAIgFQAIgEAHADQAJADAFAIQAEAIgDAHQgDAJgIAFQgFACgFAAIgFgBg");
	this.shape_275.setTransform(117.2,38.2);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#F19F4E").s().p("AgNAvQgUgHgJgSQgKgSAHgRQAGgUASgJQASgKARAHQAUAGAJASQAKASgGARQgGAUgSAJQgMAGgLAAQgGAAgHgCg");
	this.shape_276.setTransform(120.2,8.7);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#F3AA5D").s().p("AgFAPQgGgDgDgHQgCgFADgFQACgGAHgDQAEgCAGADQAHACACAHQACAEgDAGQgCAHgHACIgFABIgFgBg");
	this.shape_277.setTransform(146.1,50.2);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#F3AA5D").s().p("AgJAXQgKgEgEgKQgEgJAFgJQAEgKAKgEQAJgEAJAFQAKAEAEAKQAEAJgFAJQgEAKgKAEQgFACgEAAQgEAAgFgDg");
	this.shape_278.setTransform(148.1,44.4);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#F7BD56").s().p("AgJAXQgJgFgEgKQgEgIAFgJQAEgJAKgEQAHgEAKAFQAJAEAEAKQAEAHgEAKQgFAJgKAEQgEACgEAAQgEAAgFgCg");
	this.shape_279.setTransform(155.3,43.1);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#F19F4E").s().p("AgGAJQgDgDgBgFQAAgDACgEQADgDAFgBQADAAAEADQADADABAEQAAADgDAEQgDAEgEAAIgBAAQgDAAgDgCg");
	this.shape_280.setTransform(130.3,36.1);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#F7BD56").s().p("AgUAbQgMgJgBgOQgCgNAJgLQAJgMAPgBQAMgCALAJQAMAJABAPQACAMgJALQgJAMgOABIgEABQgLAAgJgIg");
	this.shape_281.setTransform(134.5,10.5);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#FCD888").s().p("AgNASQgHgGgBgKQgBgHAGgIQAFgHAKgBQAHgBAIAGQAHAGABAJQABAHgGAIQgGAHgJABIgCAAQgHAAgGgEg");
	this.shape_282.setTransform(136.2,34.3);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#F7BD56").s().p("AgBASQgHAAgFgHQgFgGABgFQABgIAGgFQAGgFAGABQAIABAFAGQAEAGgBAGQAAAIgHAFQgFADgGAAIgBAAg");
	this.shape_283.setTransform(106.9,1.6);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#FCD888").s().p("AAAAMQgFgBgDgEQgDgEAAgDQABgFAEgDQADgDAEAAQAFABADAEQADAEgBADQAAAFgEADQgDADgEAAIAAAAg");
	this.shape_284.setTransform(112.5,11.8);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#F19F4E").s().p("AgCAaQgLgBgGgJQgHgIABgJQABgLAJgHQAIgHAJABQALABAHAJQAHAJgBAJQgCALgIAGQgHAGgJAAIgCAAg");
	this.shape_285.setTransform(95.9,119);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#F3AA5D").s().p("AgFAPQgHgDgCgHQgCgFADgFQACgGAHgDQAEgCAGADQAGACADAHQACAEgDAGQgDAHgGACIgFABIgFgBg");
	this.shape_286.setTransform(112.2,3);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#F3AA5D").s().p("AgJAXQgKgEgEgKQgEgJAFgJQAEgKAKgEQAIgEAKAFQAKAEAEAKQADAIgEAKQgEAKgKAEQgFACgEAAQgEAAgFgDg");
	this.shape_287.setTransform(108.3,8.4);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#F7BD56").s().p("AgJAWQgJgEgEgKQgEgIAFgJQAEgJAKgEQAHgEAKAEQAKAFADAKQAEAHgEAKQgFAJgKAEQgEACgEAAQgEAAgFgDg");
	this.shape_288.setTransform(124.5,39.3);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#FCD888").s().p("AgFAOQgHgCgCgHQgCgFACgFQADgHAHgCQAEgCAGACQAGADADAHQACAEgDAGQgCAGgHADIgFABQgCAAgDgCg");
	this.shape_289.setTransform(128.3,8);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#F19F4E").s().p("AgGAIQgDgDgBgEQAAgDADgEQADgDAEgBQADAAAEACQAEADAAAFQABADgDAEQgDADgFABIgBAAQgDAAgDgDg");
	this.shape_290.setTransform(127.3,3.3);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#F7BD56").s().p("AgBASQgIgBgEgGQgFgGABgGQABgIAGgEQAGgFAGABQAHABAFAGQAFAGgBAGQgBAHgGAFQgFAEgGAAIgBAAg");
	this.shape_291.setTransform(102.6,36.9);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#FCD888").s().p("AAAALQgFAAgDgEQgDgEAAgDQABgFAEgDQAEgDADAAQAFABADAEQADAEgBADQAAAFgEADQgDADgEAAIAAgBg");
	this.shape_292.setTransform(111.5,38.9);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#F3AA5D").s().p("AgFAOQgHgCgCgHQgCgFACgFQADgHAHgCQAEgCAGACQAGADADAHQACAEgDAGQgCAGgHADIgFABQgCAAgDgCg");
	this.shape_293.setTransform(116,45.4);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#F3AA5D").s().p("AgJAXQgKgEgEgKQgDgJAEgJQAEgKAKgEQAJgEAJAFQAKAEAEAKQAEAIgFAKQgEAKgKAEQgFACgEAAQgEAAgFgDg");
	this.shape_294.setTransform(121,46.2);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#F19F4E").s().p("AgCAHQgHgEADgFQABgDAEgBQABgCADACQAHADgDAGQgBADgDABIgDABIgCgBg");
	this.shape_295.setTransform(132.2,53.3);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#FCD888").s().p("AgFAPQgHgDgCgHQgCgFACgFQADgGAHgDQAEgCAGADQAGACADAHQACAEgDAGQgDAHgGACIgFABIgFgBg");
	this.shape_296.setTransform(129.9,45.9);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#F19F4E").s().p("AgHASQgIgDgDgIQgDgHAEgHQAEgIAHgDQAGgDAIAEQAIADADAIQADAGgEAIQgDAIgIADIgHABQgDAAgEgCg");
	this.shape_297.setTransform(-78.7,12.9);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#F3AA5D").s().p("AgNARQgHgGgBgJQgBgIAGgHQAFgHAKgBQAHgBAHAGQAIAFABAKQABAHgGAHQgGAIgJABIgCAAQgHAAgGgFg");
	this.shape_298.setTransform(128.4,13.9);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#F3AA5D").s().p("AgVAcQgMgKgCgOQgBgNAJgMQAJgMAPgCQANgCAMAKQALAJACAQQACAMgJAMQgKALgPACIgDABQgLAAgKgIg");
	this.shape_299.setTransform(139.1,51);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#F3AA5D").s().p("AgGAHQgDgDAAgEQAAgCADgDQAGgHAGAGQAHAGgHAGQgCADgEABQgDAAgDgDg");
	this.shape_300.setTransform(152.4,48.9);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#F3AA5D").s().p("AgJALQgFgFAAgGQAAgFAEgEQAFgFAFAAQAGgBAEAFQAFAEAAAGQABAFgFAFQgEAFgHAAQgEAAgFgEg");
	this.shape_301.setTransform(131.9,19.8);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#F19F4E").s().p("AgCADQgEgDAEgCQACgEADAEQAEACgEADQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAAAAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAAAgBg");
	this.shape_302.setTransform(156.9,31.4);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#F7BD56").s().p("AgJAKQgFgEAAgGQAAgEAEgFQAEgFAGAAQAFAAAFAEQAEAEABAGQAAAFgEAFQgFAEgGABQgEAAgFgFg");
	this.shape_303.setTransform(157.5,37);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FCD888").s().p("AgFAHQgHgHAGgFQAGgHAGAHQADACABADQAAAEgDADQgDADgEAAQgCAAgDgDg");
	this.shape_304.setTransform(155.4,33.6);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#F19F4E").s().p("AgNAPQgHgGAAgJQgBgHAHgGQAGgHAIAAQAIAAAGAGQAHAGAAAIQABAIgHAGQgGAHgJAAIAAAAQgHAAgGgGg");
	this.shape_305.setTransform(160.3,33.1);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#F3AA5D").s().p("AgCAMQgGgBgCgFQgDgFACgDQABgGAFgCQAFgDADACQAFABADAFQACAFgBADQgBAGgFACQgDACgDAAIgCgBg");
	this.shape_306.setTransform(150.5,30.5);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#F3AA5D").s().p("AgEAUQgJgCgEgIQgEgIACgGQACgJAIgEQAIgEAGACQAJACAEAIQAEAIgCAGQgDAIgHAFQgGADgEAAIgEgBg");
	this.shape_307.setTransform(147.7,26.5);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#F19F4E").s().p("AgEADQgEgFAGgCQAEgEADAGQADAEgFADIgDABQgDAAgBgDg");
	this.shape_308.setTransform(157.7,22.6);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#F7BD56").s().p("AgEATQgIgCgFgIQgEgHACgGQADgJAHgEQAIgDAGACQAIACAEAHQAFAIgCAGQgDAJgHADQgFADgFAAIgEgBg");
	this.shape_309.setTransform(150.3,21.1);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#FCD888").s().p("AgCAMQgGgBgCgFQgDgFACgDQABgGAFgCQAFgDADACQAFABADAFQACAFgBADQgBAFgFADQgEACgCAAIgCgBg");
	this.shape_310.setTransform(155.4,19.8);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#F3AA5D").s().p("AgIAPQgHgDgCgIQgBgFADgHQAEgGAHgCQAFgCAHADQAHAEACAHQACAGgEAGQgEAHgHACIgEABQgDAAgFgDg");
	this.shape_311.setTransform(159.5,28.1);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#F7BD56").s().p("AgMAYQgLgGgDgLQgDgKAGgKQAFgKAMgDQAKgDAKAGQAKAGADALQADAJgGALQgFAKgMADIgHABQgGAAgGgEg");
	this.shape_312.setTransform(144.6,16.2);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#FCD888").s().p("AgIAPQgHgDgCgIQgBgFADgHQAEgGAHgCQAFgCAHADQAHAEACAHQACAGgEAGQgEAHgHACIgEABQgDAAgFgDg");
	this.shape_313.setTransform(145.6,32.2);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#F19F4E").s().p("AgSAiQgPgIgEgQQgFgOAJgPQAIgOAQgEQAOgEAOAIQAPAIAEAQQAEAOgIAOQgIAPgQAEQgFABgFAAQgJAAgJgFg");
	this.shape_314.setTransform(139.9,41.8);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#F3AA5D").s().p("AAAAIQgDAAgCgDQgDgDABgCQABgIAHABQADAAACADQADADgBABQAAAEgDACQgCACgDAAIAAAAg");
	this.shape_315.setTransform(146.3,10);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#F3AA5D").s().p("AAAANQgGAAgEgFQgDgEAAgEQABgGAFgDQAEgEAEABQAGAAADAFQAEAEgBAEQAAAGgFADQgEADgEAAIAAAAg");
	this.shape_316.setTransform(143.1,9.9);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#F7BD56").s().p("AAAANQgGgBgDgEQgEgFABgDQABgGAEgDQAEgEAEABQAFABAEAEQAEAEgBAEQgBAFgEAEQgEADgEAAIAAAAg");
	this.shape_317.setTransform(141.2,6.4);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#F19F4E").s().p("AgBASQgIgBgEgGQgGgGABgGQABgIAGgFQAHgEAGABQAHAAAFAHQAGAGgBAFQgBAIgHAGQgFAEgGAAIgBgBg");
	this.shape_318.setTransform(150.9,11.6);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#F19F4E").s().p("AgBAFQgFgDACgDQADgFADACQAFADgCADQgCAEgDAAIgBgBg");
	this.shape_319.setTransform(103.2,14.3);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#F7BD56").s().p("AgGAQQgHgDgCgHQgDgGADgGQADgHAHgDQAFgCAHADQAHADADAHQACAFgDAHQgDAHgHADIgGABQgCAAgEgCg");
	this.shape_320.setTransform(100.4,8.3);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#FCD888").s().p("AgDAKQgFgCgBgEQgCgEACgDQACgFAFgBQACgCAFACQAEACACAEQACADgDAEQgCAFgEACIgEAAIgDgBg");
	this.shape_321.setTransform(104,11.2);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#F3AA5D").s().p("AgPAUQgJgHAAgKQgCgJAHgJQAGgIALgBQAKgCAHAHQAJAHABALQACAIgHAJQgGAIgLABIgDABQgIAAgHgGg");
	this.shape_322.setTransform(108,-62.1);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#F19F4E").s().p("AgDAGQgDgCAAgEQgBgGAHgBQAHgBABAIQAAACgCADQgCACgDABIgBAAQgBAAgCgCg");
	this.shape_323.setTransform(154.2,15.1);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#FCD888").s().p("AgJAMQgFgEgBgHQAAgEAEgGQAEgFAHgBQAFAAAFAEQAFAEABAGQABAFgFAGQgEAFgHABIgBAAQgEAAgFgEg");
	this.shape_324.setTransform(159.9,18.9);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#F3AA5D").s().p("AgIAAQABgIAHAAQAJABAAAHQgBAJgIAAQgIgBAAgIg");
	this.shape_325.setTransform(-105.9,-30.5);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#F3AA5D").s().p("AAAAOQgFAAgEgEQgFgFAAgFQABgFAFgEQAEgFAEABQAGAAAEAEQAEAFABAEQgBAGgEAEQgEAEgGAAIAAAAg");
	this.shape_326.setTransform(-90.4,4);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#F19F4E").s().p("AgDAAQAAgDADAAQAEABAAACQAAAEgEAAQgEAAABgEg");
	this.shape_327.setTransform(-113.1,-28.3);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#F7BD56").s().p("AgJAKQgEgFAAgFQAAgEAFgFQAEgEAEAAQAGAAAEAEQAEAFAAAEQAAAGgFAEQgEAEgFAAQgFAAgEgEg");
	this.shape_328.setTransform(-109.2,-24.8);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#FCD888").s().p("AAAAJQgIAAAAgJQABgIAHAAQADAAAEADQACADAAACQAAAEgDACQgDADgDAAIAAAAg");
	this.shape_329.setTransform(-112.7,-25.8);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#F19F4E").s().p("AAAATQgHAAgGgFQgGgHAAgHQAAgHAGgGQAHgGAGABQAIgBAGAHQAGAFAAAHQgBAIgGAGQgFAGgIAAIAAgBg");
	this.shape_330.setTransform(-121.3,-31);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#F3AA5D").s().p("AgDALQgFgCgCgEQgCgFACgDQABgFAFgCQAEgCAEACQAFABACAFQACAEgCADQgCAFgEACQgDACgCAAIgDgBg");
	this.shape_331.setTransform(-118.2,-24.8);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#F3AA5D").s().p("AgFASQgIgCgDgIQgEgHADgGQACgIAIgDQAHgEAGADQAIACAEAIQADAHgDAGQgCAIgIADQgEACgEAAIgFgBg");
	this.shape_332.setTransform(-119.7,-39.6);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#F19F4E").s().p("AAAAGQgHgDACgDQACgGAEACQAHABgCAFQgBAAAAABQAAAAAAABQgBAAAAAAQgBABgBAAIgCABIAAAAg");
	this.shape_333.setTransform(-118.1,-35);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#F7BD56").s().p("AgFARQgHgCgEgHQgDgHACgGQADgIAHgDQAHgDAGACQAHADAEAHQADAHgCAGQgDAHgHAEQgEACgEAAIgFgCg");
	this.shape_334.setTransform(-132.4,-36.9);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#FCD888").s().p("AgDALQgFgBgCgFQgCgEACgDQACgFAEgCQAEgDAEACQAFACACAEQACAEgCAEQgBAFgFACIgFABIgDgBg");
	this.shape_335.setTransform(-125.9,-38.2);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#F19F4E").s().p("AgIAZQgKgDgFgLQgFgKAEgIQAEgLAJgFQAKgFAJAEQALAEAFAKQAFAKgEAIQgEALgKAFQgFADgGAAQgDAAgFgCg");
	this.shape_336.setTransform(-128.4,-31.5);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#F3AA5D").s().p("AgIAOQgGgEgBgHQgCgFAEgGQAEgGAHgBQAFgCAGAEQAGAEACAHQABAFgEAGQgEAGgHACIgDAAQgDAAgFgDg");
	this.shape_337.setTransform(-112.2,-35.1);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#F3AA5D").s().p("AgOAXQgJgHgDgLQgCgJAHgKQAFgJAMgDQAJgCAKAGQAJAHACALQADAJgGAKQgHAJgLADIgFAAQgHAAgHgEg");
	this.shape_338.setTransform(-113.2,-43.8);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#F19F4E").s().p("AgEAHQgCgCgBgEQgBgBACgDQACgDADgBQACgBADACQADACABAEQABABgCADQgDADgDABIgBAAIgEgBg");
	this.shape_339.setTransform(-101.2,-39.3);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#F7BD56").s().p("AgNAWQgJgGgDgLQgCgJAGgJQAGgJALgDQAJgCAJAGQAJAGADALQACAJgGAJQgGAKgLACIgFAAQgHAAgGgEg");
	this.shape_340.setTransform(-111.1,-52.2);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#FCD888").s().p("AgIAOQgGgEgCgHQgBgFAEgGQAEgGAHgBQAFgCAGAEQAGAEABAHQACAFgEAGQgEAGgHABIgDABQgEAAgEgDg");
	this.shape_341.setTransform(-103.1,-43.7);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#F3AA5D").s().p("AAAAGQgFAAAAgGQAAAAAAAAQAAAAAAgBQABAAAAgBQAAgBABAAQACgCABAAQAHAAgBAFQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIAAAAg");
	this.shape_342.setTransform(-19.3,-61.7);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#F3AA5D").s().p("AgGAHQgDgEAAgDQAAgDADgDQAEgDACAAQAEAAADADQADAEAAACQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_343.setTransform(17.9,-78.3);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#F19F4E").s().p("AgCAAQAAAAAAAAQABgBAAAAQABAAAAgBQAAAAAAAAQAAAAABAAQABABAAAAQAAABABAAQAAAAAAAAQAAAAAAABQgBABAAAAQAAAAgBABQgBAAAAAAQAAAAAAAAQAAgBgBAAQAAgBgBAAQAAgBAAAAg");
	this.shape_344.setTransform(-28.6,-69.4);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#F7BD56").s().p("AgGAHQgDgDABgEQAAgDADgDQADgDACABQAKAAAAAIQAAAKgKAAQgDAAgDgDg");
	this.shape_345.setTransform(-25.8,-67);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#FCD888").s().p("AgFAAQAAgFAFAAQAGABAAAEQAAAGgGAAQgGAAABgGg");
	this.shape_346.setTransform(-17.9,-54.7);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#F19F4E").s().p("AAAAOQgFAAgEgEQgEgFAAgFQABgFAEgEQAEgEAEAAQAGABAEAEQAEAEAAAEQAAAGgEAEQgEAEgGAAIAAAAg");
	this.shape_347.setTransform(-19.4,-47.7);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#F3AA5D").s().p("AgBAIQgIgEACgFQABgEAEgCQACgBACABQAJAEgDAFQgBAEgEACIgDAAIgBAAg");
	this.shape_348.setTransform(-115.9,-19.9);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#F19F4E").s().p("AAAAEQgEgCABgCQACgEACABQAEACgBACQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAIAAAAg");
	this.shape_349.setTransform(-30.3,-65.3);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#F7BD56").s().p("AgDAMQgFgCgDgFQgCgFACgDQACgFAFgDQAEgCAEACQAFACADAFQACAEgCAEQgCAFgFADIgFABIgDgBg");
	this.shape_350.setTransform(-129.9,1.8);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#F19F4E").s().p("AgFARQgHgCgEgHQgDgHADgFQACgIAHgEQAHgDAGACQAHADAEAHQADAHgCAGQgDAHgHADQgFADgDAAIgFgCg");
	this.shape_351.setTransform(-149.1,-43.5);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#F3AA5D").s().p("AgFAKQgFgDgBgFQAAgDACgEQADgEAFgBQADgBAEACQAEADABAFQABADgCAEQgDAFgFABIgCAAQgCAAgDgCg");
	this.shape_352.setTransform(-23.4,-60.3);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#F3AA5D").s().p("AgJAPQgHgDgCgJQgBgGAEgGQAFgHAIgBQAFgCAHAFQAHAEABAHQACAHgFAGQgEAHgHACIgEAAQgEAAgFgEg");
	this.shape_353.setTransform(-125.2,-10.7);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#F19F4E").s().p("AgFABQgBgEAGgCQAEgBABAGQABAAAAAAQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABQAAAAgBABQAAAAgBAAQgBAAAAAAIgBABQgDAAgCgFg");
	this.shape_354.setTransform(-113.8,-3.7);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#F7BD56").s().p("AgJAPQgGgEgCgIQgBgFAEgHQAEgGAIgCQAFgBAHAEQAGAEACAIQACAFgFAHQgEAGgIACIgDAAQgEAAgFgDg");
	this.shape_355.setTransform(-120.7,-17.8);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#FCD888").s().p("AgFAKQgFgDgBgFQAAgDACgEQADgFAFgBQADAAAEACQAEADABAFQABADgCAEQgDAEgFABIgCABQgCAAgDgCg");
	this.shape_356.setTransform(-115,-6.7);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#F19F4E").s().p("AgNAWQgJgHgDgKQgCgJAGgJQAGgJALgDQAJgCAJAHQAJAFACALQADAJgGAJQgGAJgLACIgFABQgGAAgHgEg");
	this.shape_357.setTransform(-27.4,-30.8);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#F3AA5D").s().p("AAAAIQgCAAgDgDQgCgCAAgDQAAgHAHAAQAIAAAAAHQAAADgCADQgDACgDAAIAAAAg");
	this.shape_358.setTransform(-101.9,120.1);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#F3AA5D").s().p("AAAANQgEAAgFgEQgDgFAAgEQAAgFAEgDQAEgEAEAAQAFAAAEAEQAFAEgBAEQAAAFgEAEQgEAEgFAAIAAAAg");
	this.shape_359.setTransform(-101.7,123.3);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#F19F4E").s().p("AgDAAQABgDACAAQAEAAAAADQgBAEgDAAQgDAAAAgEg");
	this.shape_360.setTransform(-108.6,122.1);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#F7BD56").s().p("AgIAIQgEgEAAgEQAAgFAEgDQAEgEAEAAQAFAAAEAEQAEAEAAAEQgBAFgEAEQgEAEgEAAQgFgBgDgEg");
	this.shape_361.setTransform(-104.9,125.4);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#FCD888").s().p("AAAAIQgCAAgDgDQgCgCAAgDQABgHAGAAQADAAADACQACADAAACQgBAIgGAAIgBAAg");
	this.shape_362.setTransform(-108.2,124.4);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#F19F4E").s().p("AAAASQgHAAgFgFQgFgGAAgHQAAgHAGgFQAFgFAGAAQAIAAAFAGQAFAFAAAGQAAAIgGAFQgFAFgHAAIAAAAg");
	this.shape_363.setTransform(-105.4,121.3);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#F3AA5D").s().p("AgCAKQgFgBgCgEQgCgFACgCQABgFAFgCQADgCADACQAFABACAFQACADgCADQgBAFgEACIgFABIgCgBg");
	this.shape_364.setTransform(-113.2,125.3);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#F3AA5D").s().p("AgFARQgHgCgDgHQgDgHACgFQADgHAGgEQAHgDAFACQAIADADAHQADAGgCAGQgDAHgHADQgDACgEAAIgFgBg");
	this.shape_365.setTransform(-117.4,124.2);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#F19F4E").s().p("AAAAFQgGgCACgDQACgGADACQAGACgCADQgBAFgEAAIAAgBg");
	this.shape_366.setTransform(-113.2,116);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#F7BD56").s().p("AgFAQQgHgCgDgHQgDgGACgFQADgHAHgDQAGgDAFACQAHACADAHQAEAGgDAFQgCAHgHAEQgDABgEAAIgFgBg");
	this.shape_367.setTransform(-118.7,119.2);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#FCD888").s().p("AgCAKQgFgCgCgDQgCgFACgCQABgFAFgCQADgCADACQAFABACAEQACAEgCADQgBAEgEADIgFABIgCgBg");
	this.shape_368.setTransform(-116.2,115.5);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#F19F4E").s().p("AgHAXQgJgEgFgJQgEgJADgIQADgJAJgFQAJgEAIADQALADAEAKQAFAJgEAIQgEAJgIAFQgGADgFAAQgCAAgFgCg");
	this.shape_369.setTransform(-113.4,120.4);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#F3AA5D").s().p("AgHANQgGgEgBgGQgBgFADgFQAEgGAGgBQAFgCAFAEQAGADABAHQACAFgEAFQgEAGgGABIgDABQgDAAgEgDg");
	this.shape_370.setTransform(-108.8,118.5);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#F3AA5D").s().p("AgNAVQgIgGgCgKQgCgJAFgJQAGgIAKgDQAJgCAIAGQAJAGACAKQADAIgGAJQgGAJgKACIgFABQgGAAgHgEg");
	this.shape_371.setTransform(-121.9,112.9);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#F19F4E").s().p("AgGABQgCgFAIgCQABgBADACQADACAAADQACAGgIABIgBAAQgFAAgBgGg");
	this.shape_372.setTransform(-97.7,112);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#F7BD56").s().p("AgMAUQgJgFgCgKQgCgIAGgJQAFgIAKgDQAIgCAJAGQAIAGACAKQADAIgGAIQgGAJgKACIgEAAQgGAAgGgEg");
	this.shape_373.setTransform(-79.7,125.7);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#FCD888").s().p("AgHANQgGgEgBgGQgCgFAEgFQAEgGAGgBQAFgBAFADQAGAEABAGQABAFgDAFQgEAGgGABIgDAAQgDAAgEgCg");
	this.shape_374.setTransform(-87.6,126.9);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#F19F4E").s().p("AgRAdQgMgIgDgOQgDgMAIgMQAHgMAOgDQANgDAMAIQAMAIACAOQADAMgIAMQgHAMgOADIgHAAQgIAAgJgFg");
	this.shape_375.setTransform(-77.7,118.7);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#F3AA5D").s().p("AgCALQgFgBgCgFQgDgEACgDQABgFAFgCQAEgDADACQAFABACAFQACAEAAADQgCAFgFACQgCACgDAAIgCgBg");
	this.shape_376.setTransform(-138.6,133.1);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#F3AA5D").s().p("AgEASQgHgCgEgHQgEgHACgGQACgHAHgEQAHgEAGACQAIACAEAHQAEAHgDAGQgCAIgHAEQgEACgFAAIgEgBg");
	this.shape_377.setTransform(-142.4,135.6);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#F19F4E").s().p("AgEACQAAAAAAgBQgBAAAAgBQAAAAAAAAQAAAAABAAQAAgBAAgBQAAAAABAAQAAgBABAAQAAgBABAAQADgCADAFQAAAAAAABQAAAAABAAQAAAAAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAABIgDABQgCAAgCgEg");
	this.shape_378.setTransform(-145.9,126.4);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#F7BD56").s().p("AgDASQgIgDgEgGQgEgHACgGQACgHAHgEQAHgEAGADQAHACAEAGQAEAHgCAFQgCAIgHAEQgEACgFAAIgDAAg");
	this.shape_379.setTransform(-147.3,133.2);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#FCD888").s().p("AgCALQgFgBgCgEQgDgFACgDQABgFAFgCQAEgCADABQAFABACAEQADAFgCADQgBAEgEADQgDACgDAAIgCgBg");
	this.shape_380.setTransform(-148.5,128.6);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#F19F4E").s().p("AgGAZQgKgDgGgKQgFgJADgJQADgLAKgFQAJgFAJADQALADAFAKQAFAJgDAJQgDAKgKAGQgGADgGAAIgGgBg");
	this.shape_381.setTransform(-142.6,129.7);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#F3AA5D").s().p("AgHANQgHgEAAgGQgCgFAEgGQADgFAHgCQAFgBAGAEQAFAEABAGQACAFgEAGQgEAFgHACIgCAAQgDAAgEgDg");
	this.shape_382.setTransform(-153.2,123);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#F19F4E").s().p("AgHABQAAgBABgDQACgDAEAAQAFgCACAIQABABgCADQgCADgDABIgBAAQgFAAgCgHg");
	this.shape_383.setTransform(-141.7,116.3);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#F7BD56").s().p("AgMAVQgJgGgCgKQgCgIAGgJQAFgJALgCQAIgCAJAGQAIAFACALQADAIgGAJQgGAIgKACIgFABQgGAAgGgEg");
	this.shape_384.setTransform(-149.8,111.8);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#FCD888").s().p("AgHANQgHgEAAgGQgCgFAEgGQADgFAHgCQAFgBAGAEQAFAEABAGQACAFgEAGQgEAFgGABIgDABQgEAAgDgDg");
	this.shape_385.setTransform(-143.4,112.2);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#F19F4E").s().p("AgSAdQgMgIgDgOQgDgNAIgMQAIgMAOgEQANgCAMAIQAMAIADAOQADANgIAMQgIANgPACIgGABQgJAAgJgGg");
	this.shape_386.setTransform(-147.2,119.2);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#F3AA5D").s().p("AAAAXQgJgBgGgHQgHgHABgIQAAgJAHgHQAHgGAIABQAJAAAGAHQAHAHAAAHQgBAKgHAGQgHAHgIAAIAAAAg");
	this.shape_387.setTransform(-135.4,118.8);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#F19F4E").s().p("AAAALQgEAAgDgEQgDgDAAgEQABgDADgEQAEgDACAAQAFABADADQADAEAAACQAAAFgEADQgDADgEAAIAAAAg");
	this.shape_388.setTransform(-125.6,132.4);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#F7BD56").s().p("AgBAiQgOAAgKgLQgJgLAAgMQABgPALgJQALgKAMABQAPAAAJALQAKALgBANQAAAOgLAJQgKAKgNAAIgBgBg");
	this.shape_389.setTransform(-126,119.6);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#FCD888").s().p("AAAAWQgJAAgGgHQgHgHABgIQAAgJAHgGQAHgHAHABQAKAAAGAHQAHAHgBAHQAAAKgHAGQgHAGgIAAIAAAAg");
	this.shape_390.setTransform(-121.9,127.5);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#F19F4E").s().p("AgBAxQgUgBgOgPQgOgPABgTQABgUAPgOQAPgOATABQAUABAOAPQAOAPgBATQgBAUgPAOQgOANgTAAIgBAAg");
	this.shape_391.setTransform(-133,127.9);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#F3AA5D").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAAEAEQADAEAAADQAAAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_392.setTransform(125.6,-89);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_393.setTransform(125.9,-84.4);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#F19F4E").s().p("AgEAAQgBgEAFAAQAFAAAAAEQAAAGgFgBQgFABABgGg");
	this.shape_394.setTransform(116.2,-86.1);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#F7BD56").s().p("AgMANQgFgGAAgHQAAgHAGgFQAFgGAGAAQAIABAFAFQAGAHgBAFQAAAIgFAFQgGAGgHAAQgHgBgFgFg");
	this.shape_395.setTransform(121.3,-81.5);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#FCD888").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAADAEQAEADAAAEQAAAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_396.setTransform(116.7,-82.8);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#F19F4E").s().p("AgSASQgHgIAAgKQAAgKAIgIQAIgHAJAAQALAAAIAIQAHAIAAAJQAAALgIAIQgIAHgKAAQgKAAgIgIg");
	this.shape_397.setTransform(120.7,-87.2);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_398.setTransform(109.6,-81.6);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#F3AA5D").s().p("AgHAYQgKgEgFgJQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKADAFAKQAEAKgDAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_399.setTransform(77.6,-86);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#F19F4E").s().p("AgBAHQgIgCADgGQABgDADgCQACgBACABQAIACgDAGQgBADgDACIgDABIgBgBg");
	this.shape_400.setTransform(109.7,-94.8);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgKQgFgJAEgIQADgKAJgEQAKgFAHADQALAEAEAJQAFAKgEAIQgDAKgJAEQgGADgFAAIgHgCg");
	this.shape_401.setTransform(46.4,-43.6);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgGQgEgGADgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgGADQgDACgEAAIgEgBg");
	this.shape_402.setTransform(105.3,-95.5);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#F19F4E").s().p("AgKAhQgOgFgHgNQgGgNAFgMQAFgOANgGQANgHAMAFQAOAFAGANQAHANgFAMQgFAOgNAHQgHADgIAAQgEAAgGgCg");
	this.shape_403.setTransform(109.3,-88.6);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgFAAgGgEg");
	this.shape_404.setTransform(115.8,-91.2);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#F3AA5D").s().p("AgSAeQgNgJgDgOQgDgNAIgMQAIgNAPgDQANgDAMAIQANAIADAPQADANgIAMQgJANgOADIgHABQgJAAgJgGg");
	this.shape_405.setTransform(113.4,-99.3);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#F19F4E").s().p("AgFAJQgEgCgBgFQgBgDADgEQACgDAFgCQADgBAEADQAEADABAEQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_406.setTransform(120.7,-100.3);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#F7BD56").s().p("AgGALQgFgDgBgGQgBgDADgFQADgFAGgBQADgBAFADQAFADABAGQABADgDAFQgDAFgGABIgCAAQgCAAgEgCg");
	this.shape_407.setTransform(118.8,-104.1);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#FCD888").s().p("AgLATQgIgFgCgKQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgFAAgGgDg");
	this.shape_408.setTransform(114.1,-77.8);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#F19F4E").s().p("AgTAfQgNgIgDgQQgDgNAIgNQAJgNAPgDQANgDANAIQANAJADAPQADANgIANQgIANgQADIgHABQgJAAgKgGg");
	this.shape_409.setTransform(123.1,-95.1);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#F3AA5D").s().p("AAAAMQgEAAgDgEQgEgEAAgEQAAgEAEgDQAEgEADAAQAFABAEADQADAEgBADQAAAFgDAEQgDADgFAAIAAAAg");
	this.shape_410.setTransform(105.6,-110.2);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#F3AA5D").s().p("AgMANQgGgGAAgHQABgHAFgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgGAFgHAAQgHAAgFgGg");
	this.shape_411.setTransform(105.9,-105.6);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#F19F4E").s().p("AgFAAQAAgFAFAAQAFAAAAAFQAAAGgFAAQgFgBAAgFg");
	this.shape_412.setTransform(96.2,-107.2);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#F7BD56").s().p("AgMANQgGgGABgHQAAgHAFgFQAGgGAGAAQAIABAFAFQAFAGABAGQgBAIgGAFQgFAGgHAAQgHgBgFgFg");
	this.shape_413.setTransform(100.2,-98.7);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#FCD888").s().p("AAAAMQgEAAgDgEQgEgEAAgEQABgEADgDQAEgEADAAQAFABAEADQADAEAAADQAAAFgEAEQgDADgFAAIAAAAg");
	this.shape_414.setTransform(96.7,-104);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#F19F4E").s().p("AAAAaQgKgBgIgHQgHgIAAgKQAAgKAIgIQAIgIAJABQALABAIAHQAHAIAAAJQAAALgIAIQgIAHgKAAIAAAAg");
	this.shape_415.setTransform(100.7,-108.4);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgHQgCgGACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgDAGgFADQgEACgDAAIgEgBg");
	this.shape_416.setTransform(89.5,-102.7);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQADgKAKgFQAKgFAIAEQAKADAFAKQAFAKgEAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_417.setTransform(94.1,-98.4);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#F19F4E").s().p("AgBAHQgHgCACgGQABgEADgBQACgBACABQAIACgDAGQgCAGgFAAIgBgBg");
	this.shape_418.setTransform(101.5,-113.5);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#F7BD56").s().p("AgHAXQgJgDgGgKQgEgJADgIQAEgJAKgFQAJgFAIAEQAJADAGAKQAEAJgDAIQgEAKgKAEQgFADgFAAIgHgCg");
	this.shape_419.setTransform(87.8,-96.8);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#FCD888").s().p("AgEAPQgHgCgDgHQgCgGACgEQACgHAGgDQAGgCAEACQAHACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_420.setTransform(83.7,-99);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#F19F4E").s().p("AgGATQgIgDgEgIQgDgIADgGQADgIAHgEQAIgDAHACQAIADADAIQAFAIgEAGQgCAJgJADQgEADgEAAIgGgCg");
	this.shape_421.setTransform(90.2,-107.9);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#F3AA5D").s().p("AgLATQgIgFgCgKQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgFAAgGgDg");
	this.shape_422.setTransform(95.8,-112.4);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#F19F4E").s().p("AgFAJQgEgCgBgFQAAgDACgEQACgEAFgBQADAAAEACQAEADABAEQAAADgCAEQgCAEgFABIgCAAQgCAAgDgCg");
	this.shape_423.setTransform(107.2,-100.9);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#F7BD56").s().p("AgMAUQgHgGgDgKQgCgHAFgIQAGgJAJgCQAIgCAIAGQAJAFACAKQACAHgFAJQgGAIgKACIgEAAQgFAAgHgDg");
	this.shape_424.setTransform(81.1,-93.2);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#FCD888").s().p("AgLATQgIgFgCgKQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgGAAgFgDg");
	this.shape_425.setTransform(112.3,-108.1);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#F19F4E").s().p("AgQAaQgLgHgDgNQgCgLAHgLQAIgLAMgDQALgCALAHQALAIACAMQADALgHALQgHALgNACIgGABQgIAAgIgFg");
	this.shape_426.setTransform(120.6,-75.1);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#F3AA5D").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAAEAEQADAEAAADQAAAFgEADQgEAEgEAAQgEgBgDgDg");
	this.shape_427.setTransform(72.5,-71.8);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_428.setTransform(73.4,-78.6);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#F7BD56").s().p("AAAASQgHAAgFgFQgFgGgBgHQABgHAGgFQAFgFAGAAQAIAAAFAGQAGAFgBAGQAAAIgFAFQgGAFgHAAIAAAAg");
	this.shape_429.setTransform(66.4,-70.1);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#FCD888").s().p("AgHAIQgEgEAAgEQABgEADgDQAEgEADAAQAFAAADAEQAEAEAAADQAAAFgEADQgDAEgFAAQgEAAgDgEg");
	this.shape_430.setTransform(26.6,-61);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#F19F4E").s().p("AgSASQgHgIAAgKQAAgKAIgIQAIgHAJAAQALABAIAIQAHAHAAAJQgBALgHAIQgIAHgKAAQgKAAgIgIg");
	this.shape_431.setTransform(-25.2,-45.2);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgHQgCgGACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAEQgCAHgHADQgDACgDAAIgEgBg");
	this.shape_432.setTransform(19.5,-59.7);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQADgKAKgFQAKgEAIADQAKAEAFAJQAEAKgDAIQgEAKgJAFQgGADgFAAQgDAAgEgCg");
	this.shape_433.setTransform(39.1,-45.8);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#F19F4E").s().p("AgBAHQgIgCADgGQADgIAFADQADABACADQABACgBACQgBAEgDABIgDABIgBgBg");
	this.shape_434.setTransform(19.6,-73);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#F7BD56").s().p("AgHAXQgKgDgFgKQgEgJAEgIQADgKAJgEQAKgFAHADQALAEAEAJQAFAKgEAIQgDAKgJAEQgGADgFAAIgHgCg");
	this.shape_435.setTransform(18.1,-51.5);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgGQgEgGADgFQACgGAGgDQAGgDAFACQAGADADAFQADAGgCAFQgDAGgFADQgEACgDAAIgEgBg");
	this.shape_436.setTransform(15.2,-73.7);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#F19F4E").s().p("AgKAhQgOgFgHgNQgGgNAFgMQAFgOANgGQANgHAMAFQAOAFAGANQAHANgFAMQgFAOgNAGQgHAEgIAAQgEAAgGgCg");
	this.shape_437.setTransform(19.2,-66.8);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgFAAgGgEg");
	this.shape_438.setTransform(-28.4,-60.5);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#F3AA5D").s().p("AgSAeQgNgJgDgOQgDgNAIgNQAJgMAOgDQANgDAMAIQANAIADAPQADAMgIAOQgJAMgOADIgHABQgJAAgJgGg");
	this.shape_439.setTransform(25.4,-54.4);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#F19F4E").s().p("AgFAJQgEgDgBgFQgBgCADgEQACgDAFgBQADgBAEACQAEADABAEQABACgDAFQgDADgEABIgCABQgCAAgDgCg");
	this.shape_440.setTransform(89.5,-7.3);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgOQgDgMAIgNQAIgMAOgDQANgDAMAIQAMAIADAOQADAMgIANQgIAMgPADIgGABQgJAAgJgGg");
	this.shape_441.setTransform(78.2,-13.4);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#FCD888").s().p("AgLATQgIgFgCgKQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgDg");
	this.shape_442.setTransform(87.1,-13);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#F19F4E").s().p("AgHANQgGgDgBgHQgBgFADgFQAEgGAGgBQAFgCAGAEQAFAEABAGQACAFgEAFQgDAGgHABIgDABQgDAAgEgDg");
	this.shape_443.setTransform(93.5,-91.8);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#F3AA5D").s().p("AgHARQgHgDgDgIQgDgGAEgHQAEgHAHgDQAGgCAHADQAHAEADAHQADAGgEAHQgDAHgIADIgGABQgDAAgEgCg");
	this.shape_444.setTransform(-37.7,-160.9);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#F19F4E").s().p("AgBAFQgGgDADgDQADgFADACQAGADgDADQgCAEgDAAIgBgBg");
	this.shape_445.setTransform(11.7,-122.6);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#F7BD56").s().p("AgHAQQgHgDgCgHQgDgGADgHQAEgHAHgCQAGgDAHADQAHAEACAHQADAGgEAGQgDAHgHADIgGABQgCAAgFgCg");
	this.shape_446.setTransform(-18.6,-175.2);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#FCD888").s().p("AgEAKQgFgCgBgFQgCgDACgEQADgEAEgCQADgCAEACQAFADACAEQACADgDAFQgCAEgFACIgDABIgEgCg");
	this.shape_447.setTransform(-5.5,-166.2);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#F3AA5D").s().p("AgKALQgFgEAAgHQAAgFAFgFQAEgFAGAAQAGAAAFAEQAFAFAAAGQAAAGgFAFQgEAFgHAAQgFAAgFgFg");
	this.shape_448.setTransform(10.6,-117.2);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#F3AA5D").s().p("AgQASQgIgHAAgLQgBgIAHgJQAIgHAKgBQAKAAAIAHQAHAIAAAKQABAKgHAHQgIAJgKgBIgBABQgIAAgIgIg");
	this.shape_449.setTransform(-49.8,-141.3);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#F19F4E").s().p("AgFAGQgCgDAAgDQAAgCACgCQAFgGAFAFQAGAFgGAFQgDADgCAAQgBAAgEgCg");
	this.shape_450.setTransform(-48.9,-130.2);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#F7BD56").s().p("AgQASQgHgHgBgLQAAgIAHgIQAHgIAKAAQAJAAAIAHQAHAHABAKQAAAJgHAIQgHAHgLABQgIAAgIgHg");
	this.shape_451.setTransform(-49.9,-112.4);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#FCD888").s().p("AgKAMQgFgFAAgHQAAgFAFgFQAEgFAGAAQAGAAAFAFQAFAEAAAGQAAAGgEAFQgFAFgHAAIAAAAQgFAAgFgEg");
	this.shape_452.setTransform(8.5,-127.2);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#F3AA5D").s().p("AgEAWQgJgCgFgIQgFgIACgHQACgKAIgFQAIgEAHACQAJABAFAJQAGAHgCAIQgDAIgHAFQgGAEgGAAIgEAAg");
	this.shape_453.setTransform(7.7,-134);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#F3AA5D").s().p("AgGAjQgPgDgIgMQgIgNADgNQADgPANgIQANgIAMADQAPADAIANQAIANgDAMQgDAPgNAIQgJAGgKAAIgGgBg");
	this.shape_454.setTransform(-46,-105.4);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#F19F4E").s().p("AgBALQgEgBgDgEQgDgEACgDQABgFADgCQAEgDADABQAEABADAEQADAEgCADQAAAEgEADQgDACgDAAIgBAAg");
	this.shape_455.setTransform(4.8,-142.6);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#F7BD56").s().p("AgGAiQgOgDgIgNQgIgMADgMQADgOAMgIQANgIAMADQAOADAIAMQAIANgDAMQgDAOgNAIQgIAGgKAAIgGgBg");
	this.shape_456.setTransform(-53,-121.3);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#FCD888").s().p("AgDAWQgKgCgFgIQgFgIACgHQACgKAIgFQAIgFAHACQAJACAFAIQAGAIgCAHQgCAKgIAFQgGADgGAAIgDAAg");
	this.shape_457.setTransform(1.9,-138.5);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgHQgCgGACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_458.setTransform(-5.4,-172.1);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKAEAFAJQAFAKgEAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_459.setTransform(-11.3,-173.6);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgJQgFgKAEgIQADgJAKgFQAJgFAIAEQAKADAEAKQAFAJgEAIQgDAKgKAEQgFADgFAAQgCAAgFgCg");
	this.shape_460.setTransform(-13.3,-180.7);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#F19F4E").s().p("AgFAJQgEgCgBgFQAAgDACgEQACgEAFgBQADAAAEACQAEADABAEQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_461.setTransform(-18,-155.1);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgOQgDgMAIgNQAIgMAPgDQAMgDAMAIQAMAIADAOQADAMgIANQgIAMgPADIgGABQgJAAgJgGg");
	this.shape_462.setTransform(-43.9,-157);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAFgIQAGgIAJgCQAHgCAIAGQAIAFACAJQACAHgGAIQgEAIgKACIgEAAQgFAAgGgEg");
	this.shape_463.setTransform(-20.4,-160.8);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#F19F4E").s().p("AgaApQgRgLgEgUQgEgSALgRQAMgRAUgFQASgEARAMQARALAEAUQAEASgLARQgLARgUAEIgKABQgNAAgNgIg");
	this.shape_464.setTransform(-30,-162);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#F3AA5D").s().p("AgHAIQgEgEAAgEQAAgEAEgDQADgEAEAAQAFAAADAEQAEAEAAADQgBAFgDADQgEAEgEAAQgEAAgDgEg");
	this.shape_465.setTransform(-56.4,-137.7);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_466.setTransform(-56.1,-133.1);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#F7BD56").s().p("AgMAMQgGgFABgHQAAgHAFgFQAGgGAGABQAIAAAFAFQAFAGABAGQgBAIgGAFQgFAFgHAAQgHAAgFgGg");
	this.shape_467.setTransform(-57.7,-127.5);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#FCD888").s().p("AAAAMQgEgBgDgDQgEgEAAgEQABgEADgDQAEgEADAAQAFABADADQAEADAAAEQAAAFgEAEQgDADgFAAIAAAAg");
	this.shape_468.setTransform(-65,-148.5);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#F19F4E").s().p("AgSASQgHgIAAgKQAAgKAIgIQAIgHAJAAQALAAAIAIQAHAIAAAJQAAALgIAIQgIAHgKAAQgKAAgIgIg");
	this.shape_469.setTransform(-61.4,-135.9);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgJQgFgKADgIQAEgKAJgEQAKgFAIAEQAKADAEAKQAFAJgEAIQgDAKgKAEQgFADgFAAQgCAAgFgCg");
	this.shape_470.setTransform(-0.2,-164.6);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#F3AA5D").s().p("AgLATQgIgFgCgKQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgDg");
	this.shape_471.setTransform(-65,-159.9);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#F19F4E").s().p("AgFAJQgEgDgBgEQAAgDACgEQADgEAEgBQADgBAEADQAEACABAFQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_472.setTransform(-50.4,-149.2);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgOQgDgMAIgNQAIgMAOgDQANgDAMAIQAMAIADAOQADAMgIANQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_473.setTransform(-58.3,-146.7);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_474.setTransform(-52.7,-154.9);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#F19F4E").s().p("AgEAAQAAgFAEAAQAGABgBAEQABAGgGAAQgEAAAAgGg");
	this.shape_475.setTransform(5.4,-149.9);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#FCD888").s().p("AAAALQgEAAgDgDQgEgDAAgFQAAgEAEgDQAEgEADAAQAFAAADAEQAEADAAAEQAAAFgEAEQgDADgFAAIAAgBg");
	this.shape_476.setTransform(5.9,-146.6);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#F3AA5D").s().p("AgEAPQgHgDgDgFQgCgHACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_477.setTransform(-1.1,-145.4);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#F3AA5D").s().p("AgHAYQgKgEgFgJQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKADAFAKQAFAKgEAIQgEAKgJAFQgGADgFAAIgHgCg");
	this.shape_478.setTransform(-7.1,-146.9);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#F19F4E").s().p("AgBAHQgEgBgBgDQgBgDABgBQAAgEAEgBQACgBACABQAHACgCAGQgBADgDACIgDABIgBgBg");
	this.shape_479.setTransform(-1,-158.6);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#F7BD56").s().p("AgHAYQgKgFgEgJQgFgJAEgIQADgJAKgGQAJgEAIADQAKAEAEAKQAFAJgEAIQgDAJgKAGQgFACgFAAIgHgBg");
	this.shape_480.setTransform(-9,-154);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#FCD888").s().p("AgEAPQgHgDgDgFQgCgHACgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_481.setTransform(-5.4,-159.3);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#F19F4E").s().p("AgKAhQgOgFgHgNQgGgNAFgMQAFgOANgGQANgHAMAFQAOAFAGANQAHANgFAMQgFAOgNAHQgHADgIAAQgEAAgGgCg");
	this.shape_482.setTransform(-1.4,-152.4);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#F3AA5D").s().p("AgLASQgHgFgDgJQgCgHAGgIQAEgIAKgCQAHgCAIAFQAIAFACAKQACAHgGAIQgEAIgKACIgEAAQgFAAgGgEg");
	this.shape_483.setTransform(2.8,-157);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#F3AA5D").s().p("AAAAMQgEAAgEgEQgDgEABgEQgBgEAEgDQAEgEADAAQAFABADADQAEAEAAADQAAAFgEAEQgEADgEAAIAAAAg");
	this.shape_484.setTransform(41.2,-37.5);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_485.setTransform(76.9,-21.4);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#F19F4E").s().p("AAAAFQgFAAAAgFQABgFAEAAQAGAAAAAFQAAAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAQAAABgBAAIAAgBg");
	this.shape_486.setTransform(32.8,-44.4);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#F7BD56").s().p("AgMAMQgFgFAAgHQAAgHAGgFQAFgGAGABQAIAAAFAFQAFAGAAAGQAAAIgGAFQgFAFgHABQgHgBgFgGg");
	this.shape_487.setTransform(86.5,-27.4);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#FCD888").s().p("AgIAIQgDgEAAgEQAAgEAEgEQAEgDADAAQAFAAADAEQAEAEAAADQgBAFgDADQgEAEgEAAQgEgBgEgDg");
	this.shape_488.setTransform(53.5,-46.4);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#F19F4E").s().p("AgSASQgHgIAAgKQABgKAHgIQAIgHAJAAQALABAIAIQAIAHgBAJQgBALgHAIQgIAHgKAAQgKAAgIgIg");
	this.shape_489.setTransform(42.7,-52.2);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_490.setTransform(81.4,-26.3);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#F3AA5D").s().p("AgHAYQgKgEgFgJQgFgKAEgIQAEgKAJgFQAKgFAIAEQAKADAFAKQAEAKgDAIQgEAKgJAFQgGADgFAAQgDAAgEgCg");
	this.shape_491.setTransform(70.7,48.8);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#F19F4E").s().p("AgBAHQgEgBgBgDQgBgDABgBQACgIAGADQAIADgDAFQgBADgDACIgDABIgBgBg");
	this.shape_492.setTransform(25.2,-43.3);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#F7BD56").s().p("AgHAXQgKgEgEgIQgFgKAEgIQADgKAJgEQAKgFAIAEQAKADAEAJQAFAKgEAHQgDALgKAEQgFADgFAAIgHgCg");
	this.shape_493.setTransform(-23.4,-36.6);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgHQgEgGADgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgGADQgDACgEAAIgEgBg");
	this.shape_494.setTransform(20.8,-43.9);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#F19F4E").s().p("AgKAhQgOgFgGgNQgHgNAFgMQAFgOANgHQANgGAMAFQAOAFAGANQAHANgFAMQgFAOgNAGQgIAEgHAAQgEAAgGgCg");
	this.shape_495.setTransform(-24.2,-53.4);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_496.setTransform(28.5,-47.4);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#F19F4E").s().p("AgFAJQgEgCgBgFQAAgDACgEQACgEAFgBQADAAAEACQAEADABAEQAAADgCAEQgCAEgFABIgCAAQgCAAgDgCg");
	this.shape_497.setTransform(47.3,-49);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgPQgDgMAIgMQAIgMAOgDQANgDAMAIQAMAIADAOQADANgIAMQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_498.setTransform(34.1,-52.4);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_499.setTransform(84.4,-20.6);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#F3AA5D").s().p("AAAAMQgEAAgDgEQgEgEAAgEQABgEADgDQAEgEADAAQAFABAEADQADAEAAADQgBAFgDAEQgDADgFAAIAAAAg");
	this.shape_500.setTransform(-34.9,-28);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#F3AA5D").s().p("AgNANQgFgGAAgHQABgHAFgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgGAFgHAAQgHAAgGgGg");
	this.shape_501.setTransform(-34.6,-23.5);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#F19F4E").s().p("AgEAAQgBgFAFAAQAFAAAAAFQAAAGgFAAQgFgBABgFg");
	this.shape_502.setTransform(-44.4,-25.1);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#F7BD56").s().p("AAAASQgHAAgFgFQgGgGABgHQAAgHAGgFQAFgGAGABQAIAAAFAGQAGAFgBAGQAAAIgFAFQgGAFgHAAIAAAAg");
	this.shape_503.setTransform(-93.8,9.4);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#FCD888").s().p("AAAAMQgEAAgDgEQgEgEAAgEQABgEADgDQAEgEADAAQAFABADADQAEAEAAADQAAAFgEAEQgDADgFAAIAAAAg");
	this.shape_504.setTransform(-43.8,-21.8);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#F19F4E").s().p("AAAAaQgKAAgIgIQgHgIAAgKQAAgKAIgIQAIgHAJAAQALAAAIAJQAHAHAAAJQAAALgIAIQgIAHgKAAIAAAAg");
	this.shape_505.setTransform(-33.6,-34.9);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#F3AA5D").s().p("AgEAPQgGgCgDgGQgDgGACgFQADgGAFgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_506.setTransform(-118.4,-11.7);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQAEgKAJgFQAKgEAIADQAKAEAFAJQAFAKgEAIQgEAKgJAFQgGADgFAAIgHgCg");
	this.shape_507.setTransform(-85.4,10.3);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#F19F4E").s().p("AgBAHQgEgBgBgDQgBgDABgBQACgIAGADQADABACADQABACgBACQgBADgDACIgDABIgBgBg");
	this.shape_508.setTransform(-50.9,-33.8);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgJQgFgKAEgIQADgJAKgFQAJgFAIAEQAKADAEAKQAFAJgEAIQgDAKgJAEQgGADgFAAIgHgCg");
	this.shape_509.setTransform(-58.9,-29.2);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgHQgEgGADgEQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgGADQgDACgEAAIgEgBg");
	this.shape_510.setTransform(-55.3,-34.5);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#F19F4E").s().p("AgKAhQgOgFgGgNQgHgNAFgMQAFgOANgHQANgGAMAFQAOAFAHANQAGANgFAMQgFAOgNAHQgHADgIAAQgEAAgGgCg");
	this.shape_511.setTransform(-41.5,-147.2);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#F3AA5D").s().p("AgLATQgIgFgCgKQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgGAAgFgDg");
	this.shape_512.setTransform(-44.7,-30.2);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#F3AA5D").s().p("AgSAeQgNgJgDgOQgDgNAIgMQAJgNAOgDQANgDAMAIQANAJADAOQADANgIAMQgJANgOADIgHABQgJAAgJgGg");
	this.shape_513.setTransform(-55.8,27.3);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#F19F4E").s().p("AgFAJQgEgCAAgFQgCgDADgEQADgEAEgBQADAAAEACQAEADAAAEQACADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_514.setTransform(-28.9,-39.5);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#FCD888").s().p("AgLATQgHgFgDgKQgCgHAGgIQAFgIAJgCQAHgCAIAGQAIAFACAJQACAHgFAIQgFAIgKACIgEAAQgFAAgGgDg");
	this.shape_515.setTransform(-116.2,3.2);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#F3AA5D").s().p("AgFAHQgDgCgBgEQAAgCACgDQADgEAEAAQACgBADADQAIAGgGAGQgCADgFABQgCAAgDgDg");
	this.shape_516.setTransform(-27.2,-187.4);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#F3AA5D").s().p("AgJAMQgEgEgBgGQgBgFAEgFQAEgFAGgBQAEgBAGAEQAFAEABAHQABAEgEAFQgEAFgGABIgCAAQgEAAgFgDg");
	this.shape_517.setTransform(-19.4,-186.8);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#F19F4E").s().p("AgCAEQgDgEACgBQADgEACADQAEACgDADQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAAAAAIgCgBg");
	this.shape_518.setTransform(-25.1,-181.2);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#F7BD56").s().p("AgIAMQgFgEgBgHQgBgEAEgFQAEgFAHgBQAEgBAFAEQAFAEABAHQABAEgEAFQgEAFgHABIgBAAQgDAAgFgDg");
	this.shape_519.setTransform(-19.6,-182.3);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#FCD888").s().p("AgFAIQgDgDgBgEQAAgCACgDQAHgIAFAGQAIAGgGAGQgDADgEABIAAAAQgCAAgDgCg");
	this.shape_520.setTransform(-22.7,-180);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#F19F4E").s().p("AgMARQgHgGgBgJQgBgGAFgHQAGgHAJgCQAHgBAHAGQAHAFABAJQABAHgGAHQgFAHgJABIgCAAQgGAAgGgEg");
	this.shape_521.setTransform(-23.7,-184.7);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#F3AA5D").s().p("AgBANQgFgCgDgEQgDgFABgDQAAgGAFgDQAEgCAEABQAFABADAEQAEAEgBAEQgCAFgEAEQgDACgEAAIgBAAg");
	this.shape_522.setTransform(-25.4,-174.7);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#F3AA5D").s().p("AgDAUQgIgCgFgHQgFgHACgHQABgIAHgFQAHgFAHACQAJABAFAHQAFAHgCAHQgCAJgHAFQgFAEgGAAIgDgBg");
	this.shape_523.setTransform(-29.2,-171.5);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#F19F4E").s().p("AgEADQgEgDAGgEQADgDAEAFQACACgBABQAAADgDABIgDABQgBAAgDgDg");
	this.shape_524.setTransform(-34,-181.2);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#F7BD56").s().p("AgCAUQgIgCgFgHQgFgHACgGQABgIAHgFQAHgFAGACQAJABAFAHQAEAHgBAGQgCAJgHAEQgFAEgGAAIgCAAg");
	this.shape_525.setTransform(-34.8,-173.7);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#FCD888").s().p("AgBANQgFgCgDgEQgEgEABgEQABgFAFgDQAFgDADABQAFAAADAFQADAEgBAEQgBAFgEADQgDADgEAAIgBAAg");
	this.shape_526.setTransform(-36.5,-178.6);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#F19F4E").s().p("AgEAcQgLgCgHgKQgHgKACgKQACgLAKgHQAKgHAKACQALACAHAKQAHAKgCAKQgCALgKAHQgIAFgIAAIgEAAg");
	this.shape_527.setTransform(-30.1,-177.9);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#F3AA5D").s().p("AgGAQQgHgDgDgHQgCgGADgGQADgHAHgDQAFgDAHAEQAHADADAHQADAFgEAHQgDAHgHADIgGABQgDAAgDgCg");
	this.shape_528.setTransform(-28.6,-183.4);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#F7BD56").s().p("AgKAZQgLgFgEgLQgEgJAFgKQAEgLAMgEQAJgEAKAFQALAFAEALQAFAJgFAKQgGALgLAEQgEACgFAAQgEAAgGgDg");
	this.shape_529.setTransform(-39.1,-167.6);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#FCD888").s().p("AgGAQQgHgDgDgHQgCgGADgGQADgHAHgDQAGgCAGADQAHADADAHQADAGgEAGQgDAHgHADIgGABQgCAAgEgCg");
	this.shape_530.setTransform(-23.3,-170);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#F19F4E").s().p("AgPAkQgPgHgGgQQgGgNAHgPQAHgPAQgGQANgGAPAHQAPAHAGAPQAGAOgHAPQgHAPgPAGQgHADgHAAQgHAAgIgEg");
	this.shape_531.setTransform(-13.3,-165.2);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#F3AA5D").s().p("AgIAAQABgHAHAAQAIAAAAAHQAAAEgDACQgCADgDAAQgHgCgBgHg");
	this.shape_532.setTransform(-45.5,-168.8);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#F3AA5D").s().p("AgJAJQgEgEAAgFQABgFAEgEQAEgEAEABQAGAAAEAEQAEAEgBAEQAAAGgEAEQgEAEgFAAQgFgBgEgEg");
	this.shape_533.setTransform(-45.2,-165.5);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#F19F4E").s().p("AgDAAQAAgEADABQAEAAAAADQAAAEgEAAQgDAAAAgEg");
	this.shape_534.setTransform(-52.3,-166.6);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#F7BD56").s().p("AgIAJQgEgEAAgFQAAgEAEgEQAFgEADAAQAGAAAEAEQADAEAAAEQAAAFgEAEQgEAEgFAAQgEAAgEgEg");
	this.shape_535.setTransform(-48.6,-163.3);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#FCD888").s().p("AgHAAQAAgHAHAAQAIAAAAAHQAAAIgIAAQgHAAAAgIg");
	this.shape_536.setTransform(-51.9,-164.3);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#F19F4E").s().p("AgNANQgFgGABgHQAAgHAFgFQAGgGAGAAQAIABAFAFQAGAGgBAGQABAIgHAFQgFAGgHAAQgHgBgGgFg");
	this.shape_537.setTransform(-49,-167.5);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#F3AA5D").s().p("AgCAKQgFgBgCgEQgCgFABgCQACgFAFgCQADgCAEACQAEABACAEQACAEgBADQgCAFgFACIgEABIgCgBg");
	this.shape_538.setTransform(-57.1,-163.4);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#F3AA5D").s().p("AgFARQgHgCgDgHQgEgHADgGQACgHAHgDQAHgEAGADQAHACADAHQAEAHgDAGQgCAHgHAEQgEABgEAAIgFgBg");
	this.shape_539.setTransform(-61.3,-164.5);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#F19F4E").s().p("AAAAFQgGgBACgEQACgGADACQAGACgCAEQgCADgDAAIAAAAg");
	this.shape_540.setTransform(-57,-173);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#F7BD56").s().p("AgEARQgHgDgEgHQgDgHACgFQADgHAHgDQAGgDAFACQAHADAEAHQADAGgCAFQgDAHgGAEQgEACgEAAIgEgBg");
	this.shape_541.setTransform(-62.7,-169.6);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#FCD888").s().p("AgCALQgFgCgCgEQgCgFACgCQABgFAEgCQAEgCADABQAFACACAEQACAEgCADQgBAFgEACIgFABIgCAAg");
	this.shape_542.setTransform(-60.2,-173.4);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#F19F4E").s().p("AgHAYQgKgEgEgJQgFgKAEgIQADgKAJgEQAKgFAIADQAKAEAEAJQAFAKgEAIQgDAKgJAFQgGACgFAAIgHgBg");
	this.shape_543.setTransform(-60.1,-155.4);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#F3AA5D").s().p("AgIANQgFgDgCgHQgBgFAEgGQAEgFAGgCQAFgBAGAEQAFAEACAGQABAFgEAFQgEAGgGABIgDABQgEAAgEgDg");
	this.shape_544.setTransform(-52.5,-170.3);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#F3AA5D").s().p("AgNAVQgJgGgCgKQgCgJAFgJQAGgJALgCQAJgCAJAGQAJAGACAKQACAJgGAJQgGAJgKACIgFABQgGAAgHgFg");
	this.shape_545.setTransform(-54.3,-176.2);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#F19F4E").s().p("AgDAGQgDgCgBgDQgBgGAIgCQABAAADABQADACABAEQABAGgIABIgBABIgDgCg");
	this.shape_546.setTransform(-41.1,-177);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#F7BD56").s().p("AgMAVQgJgGgCgKQgCgIAGgJQAFgJALgCQAIgCAJAFQAIAGACAKQADAJgGAIQgGAJgKACIgFABQgGAAgGgEg");
	this.shape_547.setTransform(-43.1,-182.8);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#FCD888").s().p("AgHANQgGgDgBgHQgCgEAEgHQAEgFAGgBQAFgCAGAEQAFAEACAGQABAEgEAGQgDAGgHABIgDABQgDAAgEgDg");
	this.shape_548.setTransform(-35.5,-185.1);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#F19F4E").s().p("AgSAdQgMgIgDgOQgDgNAIgMQAIgMAOgDQANgDAMAIQAMAIADAOQADANgIAMQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_549.setTransform(-46.6,-174.1);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#F3AA5D").s().p("AAAAOQgFABgEgFQgFgFAAgFQABgFAEgFQAEgEAFABQAGAAAEAEQAFAFAAAEQgBAGgEAFQgEAEgGAAIAAgBg");
	this.shape_550.setTransform(15.9,-82.8);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#F3AA5D").s().p("AAAAYQgJAAgHgIQgHgHAAgJQABgJAHgHQAHgHAIABQAKAAAHAHQAHAHAAAIQgBAKgHAHQgHAHgJAAIAAAAg");
	this.shape_551.setTransform(-58.7,-41.3);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#F19F4E").s().p("AAAAHQgCAAgCgCQgCgDAAgCQAAgGAGAAQADAAACACQACACAAACQAAADgCACQgBAAAAABQgBAAAAABQgBAAAAAAQgBAAgBAAIAAAAg");
	this.shape_552.setTransform(-70.8,-43.2);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#F7BD56").s().p("AAAAXQgJAAgGgHQgHgIAAgIQAAgJAHgGQAIgHAHAAQAKAAAGAHQAHAIAAAHQAAAKgHAGQgHAHgJAAIAAAAg");
	this.shape_553.setTransform(-64.4,-37.5);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#FCD888").s().p("AgJAKQgFgFAAgFQABgFAEgEQAEgFAFAAQAGABAEAEQAFAEAAAFQgBAGgEAEQgFAFgFAAQgFgBgEgEg");
	this.shape_554.setTransform(-70.1,-39.2);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#F19F4E").s().p("AAAAgQgNAAgJgKQgKgKAAgMQABgNAKgJQAJgKAMABQAOAAAJAKQAKAKgBALQAAAOgKAJQgJAJgNAAIAAAAg");
	this.shape_555.setTransform(-65.2,-44.7);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#F3AA5D").s().p("AgFATQgIgDgEgHQgDgIADgGQACgIAHgEQAIgDAGACQAIADADAIQAEAHgDAGQgCAIgIAEQgEACgEAAIgFgBg");
	this.shape_556.setTransform(-77.7,-58.4);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#F19F4E").s().p("AgCAJQgEgBgBgEQgCgEABgCQAEgJAHADQAEABACAEQABADgBADQgBAEgEACIgEABIgCgBg");
	this.shape_557.setTransform(-78.9,-54.1);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#F7BD56").s().p("AgJAdQgMgEgGgMQgFgLAEgKQAEgNAMgFQALgGALAEQAMAEAGAMQAFAMgEAJQgEANgMAFQgGAEgHAAQgDAAgGgCg");
	this.shape_558.setTransform(-88.8,-48.3);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#FCD888").s().p("AgFATQgIgDgEgHQgEgIADgGQADgIAHgEQAIgDAGACQAIADAEAIQADAHgCAGQgDAIgIAEQgEACgEAAIgFgBg");
	this.shape_559.setTransform(-84.3,-54.9);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#F3AA5D").s().p("AgOAXQgKgGgCgMQgCgJAGgKQAGgKAMgCQAJgCAKAGQAKAGACAMQACAJgGAKQgGAKgMACIgFABQgHAAgHgFg");
	this.shape_560.setTransform(-71.2,-49.6);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#F19F4E").s().p("AgGALQgFgDgBgGQgCgDADgFQAEgFAFgBQAEgBAFADQAFADABAGQABADgDAFQgDAFgGABIgCABQgCAAgEgDg");
	this.shape_561.setTransform(-102.6,-49.9);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#FCD888").s().p("AgOAXQgKgGgCgMQgCgJAGgKQAGgKAMgCQAJgCAKAGQAKAGACAMQADAJgHAKQgGAKgMACIgFABQgHAAgHgFg");
	this.shape_562.setTransform(-61.5,19.2);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#F19F4E").s().p("AgQAbQgMgHgDgOQgCgLAHgLQAIgMANgDQALgCAMAHQALAIADANQADALgIAMQgHALgOADIgGAAQgIAAgIgFg");
	this.shape_563.setTransform(52.6,-54);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#F3AA5D").s().p("AgHAIQgEgEAAgEQAAgEAEgDQAEgEADAAQAFAAADAEQAEAEAAADQAAAFgEADQgEAEgEAAQgEAAgDgEg");
	this.shape_564.setTransform(-83.9,-66);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_565.setTransform(-83.6,-61.5);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#F19F4E").s().p("AgDAEQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQABgEAEAAQAGAAAAAEQAAAGgGgBQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_566.setTransform(-93.3,-63.1);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#F7BD56").s().p("AgMAMQgGgFABgHQAAgHAFgFQAGgGAGAAQAIABAFAFQAGAGgBAGQAAAIgGAFQgFAGgHAAQgHgBgFgGg");
	this.shape_567.setTransform(-88.2,-58.5);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#FCD888").s().p("AgIAIQgDgEAAgEQAAgEAEgDQADgEAEAAQAFAAADAEQAEAEAAADQgBAFgDADQgEAEgEAAQgEAAgEgEg");
	this.shape_568.setTransform(-92.8,-59.8);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#F19F4E").s().p("AgSASQgIgIABgKQAAgKAJgIQAHgHAJAAQALAAAIAIQAHAIAAAJQAAALgIAIQgIAHgKAAQgKAAgIgIg");
	this.shape_569.setTransform(-88.8,-64.3);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#F3AA5D").s().p("AgEAPQgGgCgDgGQgDgGACgFQADgGAFgDQAGgDAFACQAGADADAFQADAGgCAFQgCAGgGADQgEACgDAAIgEgBg");
	this.shape_570.setTransform(-100,-58.6);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgFgKAEgIQADgKAKgFQAKgFAIAEQAKADAFAKQAFAKgEAIQgDAKgKAFQgGADgFAAIgHgCg");
	this.shape_571.setTransform(-105.9,-60.1);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#F19F4E").s().p("AgBAHQgIgDADgFQABgDADgCQACgBACABQAIACgDAGQgCAGgFAAIgBgBg");
	this.shape_572.setTransform(-99.9,-71.9);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgKQgFgJAEgIQADgKAJgEQAKgFAIADQAKAEAEAJQAFAKgEAIQgDAKgKAEQgFADgFAAIgHgCg");
	this.shape_573.setTransform(-107.8,-67.2);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#FCD888").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_574.setTransform(-104.2,-72.5);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#F19F4E").s().p("AgKAhQgOgFgHgNQgGgNAFgMQAFgOANgGQANgHAMAFQAOAFAHANQAGANgFAMQgFAOgNAHQgHADgIAAQgEAAgGgCg");
	this.shape_575.setTransform(-100.2,-65.7);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgFAAgGgEg");
	this.shape_576.setTransform(-93.7,-68.2);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#F19F4E").s().p("AgFAJQgEgDgBgEQgBgDADgEQACgEAFgBQADgBAEADQAEACABAFQABADgDAEQgDAEgEABIgCAAQgCAAgDgCg");
	this.shape_577.setTransform(-91.7,-54.8);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#F7BD56").s().p("AgMAUQgIgGgDgKQgCgIAGgIQAGgJAKgCQAIgCAIAGQAJAFACAKQACAIgGAJQgFAIgKACIgFABQgGAAgGgEg");
	this.shape_578.setTransform(-97,-53.1);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#FCD888").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgFAIQgFAIgKACIgEAAQgFAAgGgEg");
	this.shape_579.setTransform(-111.3,-74.4);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#F3AA5D").s().p("AgEALQgEgCgCgFQgCgEACgDQADgFAEgCQADgBAFABQAEACACAFQACADgCAEQgDAFgEACIgEABIgEgBg");
	this.shape_580.setTransform(-132.6,-25.7);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#F3AA5D").s().p("AgHARQgHgDgDgIQgDgGAEgGQADgIAIgDQAFgDAIAEQAHADADAIQADAFgEAIQgDAHgIADIgGABQgDAAgEgCg");
	this.shape_581.setTransform(-100.9,7.7);

	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f("#F19F4E").s().p("AgBAFQgFgCACgEQADgFADACQAFABgCAFQgBAEgEAAIgBgBg");
	this.shape_582.setTransform(-133.6,-15.8);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#F7BD56").s().p("AgGARQgHgEgDgHQgDgGADgGQAEgHAHgDQAFgDAHADQAHAEADAHQADAFgDAHQgEAHgHADIgGACQgCAAgEgCg");
	this.shape_583.setTransform(-127.3,-18.7);

	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#FCD888").s().p("AgEALQgEgDgCgEQgBgEACgDQACgFAEgCQADgCAFACQAEADACAEQABADgCAFQgCAEgEACIgEABIgEgBg");
	this.shape_584.setTransform(-130.4,-15);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#F19F4E").s().p("AgKAYQgJgFgEgKQgEgJAEgJQAFgKAKgEQAIgEAKAEQAKAFAEAKQAEAJgEAKQgFAKgKADQgFACgEAAQgEAAgGgCg");
	this.shape_585.setTransform(-132.9,-20.4);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#F3AA5D").s().p("AgJAMQgFgFgBgHQAAgFAFgFQAEgFAGAAQAGAAAFAEQAFAFAAAGQAAAFgEAFQgFAFgHABIAAAAQgFAAgEgEg");
	this.shape_586.setTransform(-132.1,-7.9);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#F3AA5D").s().p("AgQATQgIgHAAgLQgBgJAHgIQAHgIALAAQAJgBAIAHQAIAHAAALQABAJgHAIQgIAIgKABIgBAAQgIAAgIgHg");
	this.shape_587.setTransform(-135.7,-3.1);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f("#F19F4E").s().p("AgEAGQgDgCAAgEQAAgBACgDQAFgGAFAFQAGAFgGAFQgDADgCAAQgBAAgDgCg");
	this.shape_588.setTransform(-144.2,-13.2);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#F7BD56").s().p("AgPASQgIgHgBgKQAAgJAHgIQAHgIAKAAQAJAAAHAHQAIAHABAKQAAAIgHAIQgHAIgKABQgJAAgHgHg");
	this.shape_589.setTransform(-143,-4);

	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#FCD888").s().p("AgKAMQgFgFAAgHQAAgEAEgGQAFgFAGAAQAFAAAFAEQAFAFABAGQAAAFgEAFQgFAFgHABIAAAAQgFAAgFgEg");
	this.shape_590.setTransform(-146.5,-9.4);

	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#F19F4E").s().p("AgWAZQgLgJgBgPQgBgMAKgLQAKgMAOAAQANgBALAKQAMAKAAAOQABANgKALQgKALgPABIgBAAQgMAAgKgKg");
	this.shape_591.setTransform(-138.6,-10.5);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#F3AA5D").s().p("AgDAWQgJgCgFgIQgGgIACgHQACgJAIgFQAIgGAHACQAJACAFAIQAGAIgCAHQgCAJgIAFQgGAEgGAAIgDAAg");
	this.shape_592.setTransform(13.6,-89.1);

	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f("#F3AA5D").s().p("AgFAjQgPgDgJgMQgIgNADgNQADgOAMgJQANgIAMADQAPADAIAMQAJANgDANQgDAOgMAJQgKAGgKAAIgFgBg");
	this.shape_593.setTransform(-146.9,-18.4);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#F19F4E").s().p("AgBALQgFgBgCgEQgDgEABgDQABgEAEgDQAEgCADAAQAEABADAEQADAEgBADQgBAEgEADQgDACgDAAIgBAAg");
	this.shape_594.setTransform(-140.8,-35.7);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#F7BD56").s().p("AgFAiQgPgDgIgMQgIgMADgMQADgPAMgIQAMgIAMADQAPADAIAMQAIAMgDAMQgDAPgMAIQgJAGgKAAIgFgBg");
	this.shape_595.setTransform(-150.9,-27.8);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#FCD888").s().p("AgDAWQgJgCgFgIQgGgIACgHQACgJAIgFQAIgGAHACQAJACAFAIQAGAHgCAIQgCAJgIAFQgFAEgHAAIgDAAg");
	this.shape_596.setTransform(-147,-35.8);

	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#F19F4E").s().p("AgIAwQgUgEgMgRQgLgRAEgSQAEgUARgLQARgMASAEQAUAEALARQAMARgEASQgEAUgRAMQgNAIgOAAIgIgBg");
	this.shape_597.setTransform(-140.1,-27.1);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#F3AA5D").s().p("AAAALQgEABgDgEQgEgEABgEQAAgEADgEQAEgDADABQAFgBAEAEQADAEgBADQABAFgEADQgDAEgFAAIAAgBg");
	this.shape_598.setTransform(-119.7,-51.4);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#F3AA5D").s().p("AAAATQgHAAgGgGQgFgGAAgHQAAgHAGgGQAGgFAGAAQAIAAAGAGQAFAGAAAGQAAAIgGAGQgFAFgIAAIAAAAg");
	this.shape_599.setTransform(-109.8,5);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#F19F4E").s().p("AgFAAQAAgFAFAAQAFAAABAFQgBAGgFAAQgFAAAAgGg");
	this.shape_600.setTransform(-129.1,-48.4);

	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#F7BD56").s().p("AAAASQgHAAgFgFQgFgGAAgHQAAgHAGgFQAFgFAGAAQAIAAAFAGQAGAFgBAGQAAAIgFAFQgFAFgHAAIgBAAg");
	this.shape_601.setTransform(-124,-43.8);

	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#FCD888").s().p("AAAALQgEABgDgEQgEgEAAgEQABgEADgDQAEgEADABQAFAAAEADQADAEAAADQAAAFgEAEQgDADgFAAIAAgBg");
	this.shape_602.setTransform(-128.6,-45.2);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#F19F4E").s().p("AAAAaQgKgBgIgHQgHgIAAgKQAAgKAIgIQAIgHAJAAQALAAAIAIQAHAIAAAJQAAALgIAIQgIAHgKAAIAAAAg");
	this.shape_603.setTransform(-124.6,-49.6);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#F3AA5D").s().p("AgEAPQgHgCgDgGQgCgGACgFQACgGAGgDQAGgDAFACQAGACADAGQADAGgCAFQgCAGgHADQgDACgDAAIgEgBg");
	this.shape_604.setTransform(-32.6,-74.2);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#F3AA5D").s().p("AgHAYQgKgDgFgKQgEgKADgIQADgKAKgFQAKgEAIADQAKAEAFAJQAEAKgDAIQgEAKgJAFQgGADgFAAQgDAAgEgCg");
	this.shape_605.setTransform(-141.7,-45.4);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#F19F4E").s().p("AgBAHQgEgBgBgDQgBgDABgBQACgIAGADQAIADgDAFQgBADgDACIgDABIgBgBg");
	this.shape_606.setTransform(-135.6,-57.2);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#F7BD56").s().p("AgHAXQgKgDgEgJQgFgKAEgIQADgJAKgFQAJgFAIAEQAKADAEAKQAFAJgEAIQgDAKgJAEQgGADgFAAIgHgCg");
	this.shape_607.setTransform(-143.6,-52.5);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#FCD888").s().p("AgEAPQgGgCgDgGQgDgGACgFQACgHAGgDQAGgCAFACQAGACADAGQADAGgCAFQgCAGgGADQgDACgEAAIgEgBg");
	this.shape_608.setTransform(-140,-57.8);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#F19F4E").s().p("AgKAhQgOgFgGgNQgHgNAFgMQAFgOANgGQANgHAMAFQAOAFAHANQAGANgFAMQgFAOgNAGQgHAEgIAAQgEAAgGgCg");
	this.shape_609.setTransform(-136,-51);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#F3AA5D").s().p("AgLASQgIgFgCgJQgCgHAGgIQAFgIAJgCQAHgCAIAFQAIAFACAKQACAHgFAIQgFAIgKACIgEAAQgFAAgGgEg");
	this.shape_610.setTransform(60.7,-59);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#F3AA5D").s().p("AgSAeQgNgIgDgPQgDgNAIgNQAJgMAOgDQANgDAMAIQANAIADAPQADAMgIAOQgJAMgOADIgHABQgJAAgJgGg");
	this.shape_611.setTransform(-131.9,-61.7);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#F19F4E").s().p("AgFAJQgDgCgBgGQgCgCADgEQADgDAFgCQACgBAEADQAEADAAAEQABADgCAEQgDAEgEAAIgCABQgCAAgDgCg");
	this.shape_612.setTransform(-113.6,-62.9);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#F7BD56").s().p("AgSAdQgMgIgDgOQgDgMAIgNQAIgMAOgDQANgDAMAIQAMAIADAOQADAMgIANQgIAMgOADIgHABQgJAAgJgGg");
	this.shape_613.setTransform(-124.9,-69);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#FCD888").s().p("AgLATQgIgFgCgKQgCgHAFgIQAFgIAKgCQAHgCAIAGQAIAFACAJQACAHgGAIQgFAIgJACIgEAAQgGAAgFgDg");
	this.shape_614.setTransform(-115.9,-68.6);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#F19F4E").s().p("AgaApQgRgMgEgUQgEgSALgRQALgRAUgEQASgEASALQARALAEAUQAEASgLASQgLARgUAEIgKABQgNAAgNgIg");
	this.shape_615.setTransform(-121.3,-58.8);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f().s("#E65B40").ss(2,0,0,4).p("ALRvVQhHCAgLAUQgwBRgqAtQhtB3iCg4Qhmgsgxj3QgPhPgVieQgXi0gMhJQgykrhgh8QiCimj5BJQkVBRgHDmQgECjCTEtQAoBSBQCeQBDCHAbBSQBKDeiOBAQguAVhNg9QgggZh/h7QhwhuhNgzQhyhMhlgBQiSgCiGByQh9Bqg4CaQg6CgAzB9QA5CNC3AuQAvAJCWAgQCNAdBNAVQD+BDAoBUQAQAhhzBCQgVAMkCCEQjNBnh1BRQinBzg9BsQhCB1AgCNQAeCGBnBdQBsBjCKACQCdADCVh9QBMhBBlijQB0jIA3hfQBjipA/hBQBUhXBBArQBJAygBBTQgBA0gnBmQgoBlAAAmQgCBDBKAaQBwAnAsgtQAeggAGhgQALh6ALghQAbhNBOgJQBDgIAkBDQAfA4AOB6QAIBJAHCyQAIC4AKBcQAiFGB/BwQCoCUFqivQDGhggcjUQgViZiekLQhYiSgrhFQhLh8gkhKQhkjQBRhPQAngnCOAaQBTAPDFArQCuAcBfgkQB8gwAXijQAWijhlhMQhIg1ipgYQhdgLgtgGQhQgKgvgMQiBgigThYQgciJBciGQAigxA7g9QAigjBEhDQB3h6AQhUQAXh2iJiCQiPiGhwBEQhMAvhmC5g");
	this.shape_616.setTransform(3.2,6.4);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#FCEEEA").s().p("AHWdoQh/hwgilGQgKhcgIi4QgHiygIhJQgOh6gfg4QgkhDhDAIQhOAJgbBNQgLAhgLB6QgGBggeAgQgsAthwgnQhKgaAChDQAAgmAohlQAnhmABg0QABhThJgyQhBgrhUBXQg/BBhjCpIirEnQhlCjhMBBQiVB9idgDQiKgChshjQhnhdgeiGQggiNBCh1QA9hsCnhzQB1hRDNhnQECiEAVgMQBzhCgQghQgohUj+hDQhNgViNgdQiWgggvgJQi3gug5iNQgzh9A6igQA4iaB9hqQCGhyCSACQBlABByBMQBNAzBwBuQB/B7AgAZQBNA9AugVQCOhAhKjeQgbhShDiHQhQiegohSQiTktAEijQAHjmEVhRQD5hJCCCmQBgB8AyErQAMBJAXC0QAVCeAPBPQAxD3BmAsQCCA4Bth3QAqgtAwhRIBSiUQBmi5BMgvQBwhECPCGQCJCCgXB2QgQBUh3B6IhmBmQg7A9giAxQhcCGAcCJQATBYCBAiQAvAMBQAKICKARQCpAYBIA1QBlBMgWCjQgXCjh8AwQhfAkiugcQjFgrhTgPQiOgagnAnQhRBPBkDQQAkBKBLB8ICDDXQCeELAVCZQAcDUjGBgQjEBfiLAAQh2AAhNhEg");
	this.shape_617.setTransform(3.2,6.4);

	this.addChild(this.shape_617,this.shape_616,this.shape_615,this.shape_614,this.shape_613,this.shape_612,this.shape_611,this.shape_610,this.shape_609,this.shape_608,this.shape_607,this.shape_606,this.shape_605,this.shape_604,this.shape_603,this.shape_602,this.shape_601,this.shape_600,this.shape_599,this.shape_598,this.shape_597,this.shape_596,this.shape_595,this.shape_594,this.shape_593,this.shape_592,this.shape_591,this.shape_590,this.shape_589,this.shape_588,this.shape_587,this.shape_586,this.shape_585,this.shape_584,this.shape_583,this.shape_582,this.shape_581,this.shape_580,this.shape_579,this.shape_578,this.shape_577,this.shape_576,this.shape_575,this.shape_574,this.shape_573,this.shape_572,this.shape_571,this.shape_570,this.shape_569,this.shape_568,this.shape_567,this.shape_566,this.shape_565,this.shape_564,this.shape_563,this.shape_562,this.shape_561,this.shape_560,this.shape_559,this.shape_558,this.shape_557,this.shape_556,this.shape_555,this.shape_554,this.shape_553,this.shape_552,this.shape_551,this.shape_550,this.shape_549,this.shape_548,this.shape_547,this.shape_546,this.shape_545,this.shape_544,this.shape_543,this.shape_542,this.shape_541,this.shape_540,this.shape_539,this.shape_538,this.shape_537,this.shape_536,this.shape_535,this.shape_534,this.shape_533,this.shape_532,this.shape_531,this.shape_530,this.shape_529,this.shape_528,this.shape_527,this.shape_526,this.shape_525,this.shape_524,this.shape_523,this.shape_522,this.shape_521,this.shape_520,this.shape_519,this.shape_518,this.shape_517,this.shape_516,this.shape_515,this.shape_514,this.shape_513,this.shape_512,this.shape_511,this.shape_510,this.shape_509,this.shape_508,this.shape_507,this.shape_506,this.shape_505,this.shape_504,this.shape_503,this.shape_502,this.shape_501,this.shape_500,this.shape_499,this.shape_498,this.shape_497,this.shape_496,this.shape_495,this.shape_494,this.shape_493,this.shape_492,this.shape_491,this.shape_490,this.shape_489,this.shape_488,this.shape_487,this.shape_486,this.shape_485,this.shape_484,this.shape_483,this.shape_482,this.shape_481,this.shape_480,this.shape_479,this.shape_478,this.shape_477,this.shape_476,this.shape_475,this.shape_474,this.shape_473,this.shape_472,this.shape_471,this.shape_470,this.shape_469,this.shape_468,this.shape_467,this.shape_466,this.shape_465,this.shape_464,this.shape_463,this.shape_462,this.shape_461,this.shape_460,this.shape_459,this.shape_458,this.shape_457,this.shape_456,this.shape_455,this.shape_454,this.shape_453,this.shape_452,this.shape_451,this.shape_450,this.shape_449,this.shape_448,this.shape_447,this.shape_446,this.shape_445,this.shape_444,this.shape_443,this.shape_442,this.shape_441,this.shape_440,this.shape_439,this.shape_438,this.shape_437,this.shape_436,this.shape_435,this.shape_434,this.shape_433,this.shape_432,this.shape_431,this.shape_430,this.shape_429,this.shape_428,this.shape_427,this.shape_426,this.shape_425,this.shape_424,this.shape_423,this.shape_422,this.shape_421,this.shape_420,this.shape_419,this.shape_418,this.shape_417,this.shape_416,this.shape_415,this.shape_414,this.shape_413,this.shape_412,this.shape_411,this.shape_410,this.shape_409,this.shape_408,this.shape_407,this.shape_406,this.shape_405,this.shape_404,this.shape_403,this.shape_402,this.shape_401,this.shape_400,this.shape_399,this.shape_398,this.shape_397,this.shape_396,this.shape_395,this.shape_394,this.shape_393,this.shape_392,this.shape_391,this.shape_390,this.shape_389,this.shape_388,this.shape_387,this.shape_386,this.shape_385,this.shape_384,this.shape_383,this.shape_382,this.shape_381,this.shape_380,this.shape_379,this.shape_378,this.shape_377,this.shape_376,this.shape_375,this.shape_374,this.shape_373,this.shape_372,this.shape_371,this.shape_370,this.shape_369,this.shape_368,this.shape_367,this.shape_366,this.shape_365,this.shape_364,this.shape_363,this.shape_362,this.shape_361,this.shape_360,this.shape_359,this.shape_358,this.shape_357,this.shape_356,this.shape_355,this.shape_354,this.shape_353,this.shape_352,this.shape_351,this.shape_350,this.shape_349,this.shape_348,this.shape_347,this.shape_346,this.shape_345,this.shape_344,this.shape_343,this.shape_342,this.shape_341,this.shape_340,this.shape_339,this.shape_338,this.shape_337,this.shape_336,this.shape_335,this.shape_334,this.shape_333,this.shape_332,this.shape_331,this.shape_330,this.shape_329,this.shape_328,this.shape_327,this.shape_326,this.shape_325,this.shape_324,this.shape_323,this.shape_322,this.shape_321,this.shape_320,this.shape_319,this.shape_318,this.shape_317,this.shape_316,this.shape_315,this.shape_314,this.shape_313,this.shape_312,this.shape_311,this.shape_310,this.shape_309,this.shape_308,this.shape_307,this.shape_306,this.shape_305,this.shape_304,this.shape_303,this.shape_302,this.shape_301,this.shape_300,this.shape_299,this.shape_298,this.shape_297,this.shape_296,this.shape_295,this.shape_294,this.shape_293,this.shape_292,this.shape_291,this.shape_290,this.shape_289,this.shape_288,this.shape_287,this.shape_286,this.shape_285,this.shape_284,this.shape_283,this.shape_282,this.shape_281,this.shape_280,this.shape_279,this.shape_278,this.shape_277,this.shape_276,this.shape_275,this.shape_274,this.shape_273,this.shape_272,this.shape_271,this.shape_270,this.shape_269,this.shape_268,this.shape_267,this.shape_266,this.shape_265,this.shape_264,this.shape_263,this.shape_262,this.shape_261,this.shape_260,this.shape_259,this.shape_258,this.shape_257,this.shape_256,this.shape_255,this.shape_254,this.shape_253,this.shape_252,this.shape_251,this.shape_250,this.shape_249,this.shape_248,this.shape_247,this.shape_246,this.shape_245,this.shape_244,this.shape_243,this.shape_242,this.shape_241,this.shape_240,this.shape_239,this.shape_238,this.shape_237,this.shape_236,this.shape_235,this.shape_234,this.shape_233,this.shape_232,this.shape_231,this.shape_230,this.shape_229,this.shape_228,this.shape_227,this.shape_226,this.shape_225,this.shape_224,this.shape_223,this.shape_222,this.shape_221,this.shape_220,this.shape_219,this.shape_218,this.shape_217,this.shape_216,this.shape_215,this.shape_214,this.shape_213,this.shape_212,this.shape_211,this.shape_210,this.shape_209,this.shape_208,this.shape_207,this.shape_206,this.shape_205,this.shape_204,this.shape_203,this.shape_202,this.shape_201,this.shape_200,this.shape_199,this.shape_198,this.shape_197,this.shape_196,this.shape_195,this.shape_194,this.shape_193,this.shape_192,this.shape_191,this.shape_190,this.shape_189,this.shape_188,this.shape_187,this.shape_186,this.shape_185,this.shape_184,this.shape_183,this.shape_182,this.shape_181,this.shape_180,this.shape_179,this.shape_178,this.shape_177,this.shape_176,this.shape_175,this.shape_174,this.shape_173,this.shape_172,this.shape_171,this.shape_170,this.shape_169,this.shape_168,this.shape_167,this.shape_166,this.shape_165,this.shape_164,this.shape_163,this.shape_162,this.shape_161,this.shape_160,this.shape_159,this.shape_158,this.shape_157,this.shape_156,this.shape_155,this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-157.9,-190,322.3,392.9);


(lib.textoAnimado3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgmLgAnMBMXAAAIAABPMhMXAAAg");
	var mask_graphics_1 = new cjs.Graphics().p("EgmLABCIAAiDMBMXAAAIAACDg");
	var mask_graphics_2 = new cjs.Graphics().p("EgmLABcIAAi3MBMXAAAIAAC3g");
	var mask_graphics_3 = new cjs.Graphics().p("EgmLAB2IAAjrMBMXAAAIAADrg");
	var mask_graphics_4 = new cjs.Graphics().p("EgmLACQIAAkfMBMXAAAIAAEfg");
	var mask_graphics_5 = new cjs.Graphics().p("EgmLACrIAAlVMBMXAAAIAAFVg");
	var mask_graphics_6 = new cjs.Graphics().p("EgmLADFIAAmJMBMXAAAIAAGJg");
	var mask_graphics_7 = new cjs.Graphics().p("EgmLADfIAAm9MBMXAAAIAAG9g");
	var mask_graphics_8 = new cjs.Graphics().p("EgmLAD5IAAnxMBMXAAAIAAHxg");
	var mask_graphics_9 = new cjs.Graphics().p("EgmLAEUIAAonMBMXAAAIAAIng");
	var mask_graphics_10 = new cjs.Graphics().p("EgmLAEuIAApbMBMXAAAIAAJbg");
	var mask_graphics_11 = new cjs.Graphics().p("EgmLAFIIAAqPMBMXAAAIAAKPg");
	var mask_graphics_12 = new cjs.Graphics().p("EgmLAFiIAArDMBMXAAAIAALDg");
	var mask_graphics_13 = new cjs.Graphics().p("EgmLAF9IAAr5MBMXAAAIAAL5g");
	var mask_graphics_14 = new cjs.Graphics().p("EgmLAGXIAAstMBMXAAAIAAMtg");
	var mask_graphics_15 = new cjs.Graphics().p("EgmLAGxIAAthMBMXAAAIAANhg");
	var mask_graphics_16 = new cjs.Graphics().p("EgmLAHLIAAuVMBMXAAAIAAOVg");
	var mask_graphics_17 = new cjs.Graphics().p("EgmLAHmIAAvLMBMXAAAIAAPLg");
	var mask_graphics_18 = new cjs.Graphics().p("EgmLAIAIAAv/MBMXAAAIAAP/g");
	var mask_graphics_19 = new cjs.Graphics().p("EgmLAIaIAAwzMBMXAAAIAAQzg");
	var mask_graphics_20 = new cjs.Graphics().p("EgmLAI0IAAxnMBMXAAAIAARng");
	var mask_graphics_21 = new cjs.Graphics().p("EgmLAJPIAAydMBMXAAAIAASdg");
	var mask_graphics_22 = new cjs.Graphics().p("EgmLAJpIAAzRMBMXAAAIAATRg");
	var mask_graphics_23 = new cjs.Graphics().p("EgmLAKDIAA0FMBMXAAAIAAUFg");
	var mask_graphics_24 = new cjs.Graphics().p("EgmLgKcMBMXAAAIAAU5MhMXAAAg");
	var mask_graphics_25 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_26 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_27 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_28 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_29 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_30 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_31 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_32 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_33 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_34 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_35 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_36 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_37 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_38 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_39 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_40 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_41 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_42 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_43 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_44 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_45 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_46 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_47 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_48 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_49 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_50 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_51 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_52 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_53 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_54 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_55 = new cjs.Graphics().p("EgmLAKdIAA05MBMXAAAIAAU5g");
	var mask_graphics_56 = new cjs.Graphics().p("EgmLgKcMBMXAAAIAAU5MhMXAAAg");
	var mask_graphics_57 = new cjs.Graphics().p("EgmLAK2IAA1rMBMXAAAIAAVrg");
	var mask_graphics_58 = new cjs.Graphics().p("EgmLALOIAA2bMBMXAAAIAAWbg");
	var mask_graphics_59 = new cjs.Graphics().p("EgmLALnIAA3NMBMXAAAIAAXNg");
	var mask_graphics_60 = new cjs.Graphics().p("EgmLAL/IAA39MBMXAAAIAAX9g");
	var mask_graphics_61 = new cjs.Graphics().p("EgmLAMXIAA4tMBMXAAAIAAYtg");
	var mask_graphics_62 = new cjs.Graphics().p("EgmLAMwIAA5fMBMXAAAIAAZfg");
	var mask_graphics_63 = new cjs.Graphics().p("EgmLANIIAA6PMBMXAAAIAAaPg");
	var mask_graphics_64 = new cjs.Graphics().p("EgmLANhIAA7BMBMXAAAIAAbBg");
	var mask_graphics_65 = new cjs.Graphics().p("EgmLAN5IAA7xMBMXAAAIAAbxg");
	var mask_graphics_66 = new cjs.Graphics().p("EgmLAOSIAA8jMBMXAAAIAAcjg");
	var mask_graphics_67 = new cjs.Graphics().p("EgmLAOqIAA9TMBMXAAAIAAdTg");
	var mask_graphics_68 = new cjs.Graphics().p("EgmLAPDIAA+FMBMXAAAIAAeFg");
	var mask_graphics_69 = new cjs.Graphics().p("EgmLAPbIAA+1MBMXAAAIAAe1g");
	var mask_graphics_70 = new cjs.Graphics().p("EgmLAP0IAA/nMBMXAAAIAAfng");
	var mask_graphics_71 = new cjs.Graphics().p("EgmLAQMMAAAggXMBMXAAAMAAAAgXg");
	var mask_graphics_72 = new cjs.Graphics().p("EgmLAQkMAAAghHMBMXAAAMAAAAhHg");
	var mask_graphics_73 = new cjs.Graphics().p("EgmLAQ9MAAAgh5MBMXAAAMAAAAh5g");
	var mask_graphics_74 = new cjs.Graphics().p("EgmLARVMAAAgipMBMXAAAMAAAAipg");
	var mask_graphics_75 = new cjs.Graphics().p("EgmLgRtMBMXAAAMAAAAjbMhMXAAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:238.5,y:1.5}).wait(1).to({graphics:mask_graphics_1,x:238.5,y:4.1}).wait(1).to({graphics:mask_graphics_2,x:238.5,y:6.7}).wait(1).to({graphics:mask_graphics_3,x:238.5,y:9.3}).wait(1).to({graphics:mask_graphics_4,x:238.5,y:11.9}).wait(1).to({graphics:mask_graphics_5,x:238.5,y:14.6}).wait(1).to({graphics:mask_graphics_6,x:238.5,y:17.2}).wait(1).to({graphics:mask_graphics_7,x:238.5,y:19.8}).wait(1).to({graphics:mask_graphics_8,x:238.5,y:22.4}).wait(1).to({graphics:mask_graphics_9,x:238.5,y:25.1}).wait(1).to({graphics:mask_graphics_10,x:238.5,y:27.7}).wait(1).to({graphics:mask_graphics_11,x:238.5,y:30.3}).wait(1).to({graphics:mask_graphics_12,x:238.5,y:32.9}).wait(1).to({graphics:mask_graphics_13,x:238.5,y:35.6}).wait(1).to({graphics:mask_graphics_14,x:238.5,y:38.2}).wait(1).to({graphics:mask_graphics_15,x:238.5,y:40.8}).wait(1).to({graphics:mask_graphics_16,x:238.5,y:43.4}).wait(1).to({graphics:mask_graphics_17,x:238.5,y:46.1}).wait(1).to({graphics:mask_graphics_18,x:238.5,y:48.7}).wait(1).to({graphics:mask_graphics_19,x:238.5,y:51.3}).wait(1).to({graphics:mask_graphics_20,x:238.5,y:53.9}).wait(1).to({graphics:mask_graphics_21,x:238.5,y:56.6}).wait(1).to({graphics:mask_graphics_22,x:238.5,y:59.2}).wait(1).to({graphics:mask_graphics_23,x:238.5,y:61.8}).wait(1).to({graphics:mask_graphics_24,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_25,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_26,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_27,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_28,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_29,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_30,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_31,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_32,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_33,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_34,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_35,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_36,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_37,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_38,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_39,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_40,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_41,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_42,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_43,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_44,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_45,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_46,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_47,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_48,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_49,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_50,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_51,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_52,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_53,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_54,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_55,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_56,x:238.5,y:64.4}).wait(1).to({graphics:mask_graphics_57,x:238.5,y:66.9}).wait(1).to({graphics:mask_graphics_58,x:238.5,y:69.3}).wait(1).to({graphics:mask_graphics_59,x:238.5,y:71.7}).wait(1).to({graphics:mask_graphics_60,x:238.5,y:74.1}).wait(1).to({graphics:mask_graphics_61,x:238.5,y:76.6}).wait(1).to({graphics:mask_graphics_62,x:238.5,y:79}).wait(1).to({graphics:mask_graphics_63,x:238.5,y:81.4}).wait(1).to({graphics:mask_graphics_64,x:238.5,y:83.9}).wait(1).to({graphics:mask_graphics_65,x:238.5,y:86.3}).wait(1).to({graphics:mask_graphics_66,x:238.5,y:88.7}).wait(1).to({graphics:mask_graphics_67,x:238.5,y:91.1}).wait(1).to({graphics:mask_graphics_68,x:238.5,y:93.6}).wait(1).to({graphics:mask_graphics_69,x:238.5,y:96}).wait(1).to({graphics:mask_graphics_70,x:238.5,y:98.4}).wait(1).to({graphics:mask_graphics_71,x:238.5,y:100.9}).wait(1).to({graphics:mask_graphics_72,x:238.5,y:103.3}).wait(1).to({graphics:mask_graphics_73,x:238.5,y:105.7}).wait(1).to({graphics:mask_graphics_74,x:238.5,y:108.1}).wait(1).to({graphics:mask_graphics_75,x:238.5,y:110.6}).wait(35));

	// Capa 1
	

	// Capa 2
	this.instance = new lib.grafico2("single",0);
	this.instance.setTransform(526.4,10.4,1.717,1.717);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(29).to({mode:"synched",startPosition:14,loop:false},0).wait(20).to({mode:"single",startPosition:34},0).wait(33).to({mode:"synched",startPosition:44,loop:false},0).wait(22).to({mode:"single",startPosition:66},0).wait(6));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,837.7,331.4);


(lib.reloj = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.manilla();
	this.instance.setTransform(34.8,-24.4,1,1,0,0,0,9,10.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:1440},154).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFC100").s().p("AABAMQgaAAgbACQATgbAhAAQAQAAAOAIQAOAGAJANQgagCgaAAg");
	this.shape.setTransform(36,-110.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF7F00").s().p("AgsAgQgUgTABgZQAAgTALgRQAbgCAaAAQAaAAAaACQALARAAATQAAAZgTATQgTATgaAAQgaAAgSgTg");
	this.shape_1.setTransform(36,-104);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF5000").s().p("AgsAtQgTgTAAgaQAAgZATgTQATgTAZAAQAaAAATATQATATAAAZQAAAagTATQgTATgaAAQgZAAgTgTg");
	this.shape_2.setTransform(-45.3,-23.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF5000").s().p("AgsAtQgTgTAAgaQAAgZATgTQATgTAZAAQAaAAATATQATATAAAZQAAAagTATQgTATgaAAQgZAAgTgTg");
	this.shape_3.setTransform(117.4,-23.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AgsAtQgUgTABgaQgBgZAUgTQASgTAaAAQAaAAATATQATATAAAZQAAAagTATQgTATgaAAQgaAAgSgTg");
	this.shape_4.setTransform(36,57.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9A9A9A").s().p("AAAAKQgEgBgDgDQgCgDAAgDQABgFADgCQAEgDACABQAEAAADAEQADADgBACQgBAKgJAAIAAAAg");
	this.shape_5.setTransform(-43.7,-34.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#9A9A9A").s().p("AgBAKQgKgDACgIQABgEAEgDQADgCADABQAEABACAEQADAEgBACQgCAIgIAAIgBAAg");
	this.shape_6.setTransform(-42.1,-42.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9A9A9A").s().p("AgCAKQgEgBgCgFQgCgEACgCQABgEAEgCQADgCADACQAEABACAEQACADgBADQgCAEgEACIgEABIgCAAg");
	this.shape_7.setTransform(-39.6,-51.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgBgEQgCgDACgDQACgEAEgCQACgBAEACQAJAFgEAHQgCAEgEACIgDAAIgDgBg");
	this.shape_8.setTransform(-36.2,-59.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9A9A9A").s().p("AgEAJQgEgDgBgEQgBgDADgDQACgEAFgBQACgBAEADQADACABAEQABADgDADQgCAEgEABIgCAAIgEgBg");
	this.shape_9.setTransform(-32,-67);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#9A9A9A").s().p("AgFAIQgEgDAAgEQgBgCADgEQADgDAEgBQADAAADADQAEACAAAEQABADgDADQgDAEgEAAQgDAAgDgCg");
	this.shape_10.setTransform(-26.9,-74.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#9A9A9A").s().p("AgGAHQgDgDAAgEQAAgDADgDQAEgDACAAQAEAAADADQADAEAAACQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_11.setTransform(-21.1,-80.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9A9A9A").s().p("AAAAKQgEgBgDgDQgCgDAAgDQAAgEAEgDQADgDADABQAEAAADAEQADADgBACQAAAFgEADQgDACgDAAIAAAAg");
	this.shape_12.setTransform(-14.6,-86.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#9A9A9A").s().p("AgBAKQgEgBgCgDQgDgEABgDQABgEAEgDQADgBADAAQAEABACAEQADAEgBABQgBAFgEACQgDACgCAAIgBAAg");
	this.shape_13.setTransform(-7.5,-91.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#9A9A9A").s().p("AgBAKQgEgCgDgEQgCgEACgCQABgEAEgCQADgCADABQAEACACAEQACADgBADQgCAEgEACQgCABgCAAIgBAAg");
	this.shape_14.setTransform(0,-96.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9A9A9A").s().p("AgDAKQgEgDgBgDQgCgEACgCQACgFAEgCQACgBAEABQAEACABAFQACACgCAEQgCADgEADIgDAAIgDAAg");
	this.shape_15.setTransform(8,-99.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#9A9A9A").s().p("AgEAJQgEgCgBgEQgBgDACgDQADgEAEgCQACgBAEACQAEADABAEQABACgDAEQgCAEgEABIgCAAIgEgBg");
	this.shape_16.setTransform(16.4,-102.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9A9A9A").s().p("AgFAIQgDgCgBgFQAAgCACgDQADgEAEgBQACgBAEADQADADABAEQABAIgKACIgBAAQgCAAgDgCg");
	this.shape_17.setTransform(25,-104);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9A9A9A").s().p("AgFAIQgEgDAAgEQgBgCADgEQADgDAEgBQACAAAEACQADADABAEQABAJgLABIAAAAQgCAAgDgCg");
	this.shape_18.setTransform(116.6,-34.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#9A9A9A").s().p("AgEAIQgEgCgBgEQgBgCADgEQACgEAEgBQACgBAEACQAEADABAEQABACgDAEQgCAEgEABIgCAAQgBAAgDgCg");
	this.shape_19.setTransform(115,-42.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgBgEQgCgDACgDQACgEAEgBQACgCAEACQAEACACAEQABACgCAEQgCAFgEABIgDAAIgDgBg");
	this.shape_20.setTransform(112.5,-51.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9A9A9A").s().p("AgCAKQgEgCgCgEQgEgHAJgFQADgCADABQAEACACAEQACADgCADQgCAEgEACIgDABIgCAAg");
	this.shape_21.setTransform(109.2,-59.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#9A9A9A").s().p("AgBAKQgEgBgCgEQgDgEABgCQABgEAEgCQAHgGAGAJQACADgBADQgBAEgEADIgFABIgBAAg");
	this.shape_22.setTransform(104.9,-67);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#9A9A9A").s().p("AgHAGQgDgEABgCQAAgEADgDQAEgDACABQAFAAADAEQACADAAACQAAAFgEACQgDADgDAAQgDAAgEgEg");
	this.shape_23.setTransform(99.8,-74.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#9A9A9A").s().p("AgGAHQgDgDAAgEQAAgCADgEQAGgHAHAHQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_24.setTransform(94,-80.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#9A9A9A").s().p("AgFAIQgEgDAAgFQAAgCACgDQADgEAEAAQADgBADADQAEADAAAEQABADgDADQgDADgEABIgBAAQgDAAgCgCg");
	this.shape_25.setTransform(87.5,-86.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#9A9A9A").s().p("AgEAIQgEgCgBgFQgBgCADgDQACgEAEgBQADAAADABQAEADABAEQABADgDAEQgCADgFABIgBAAQgBAAgDgCg");
	this.shape_26.setTransform(80.4,-91.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgBgEQgCgDACgDQACgEAEgCQACgBAEACQAEACABAEQACACgCAEQgCAEgEACIgDAAIgDgBg");
	this.shape_27.setTransform(72.8,-96.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#9A9A9A").s().p("AgCAKQgJgFACgHQACgFAEgCQADgBADABQAEACACAFQACACgCAEQgCADgEADIgDAAIgCAAg");
	this.shape_28.setTransform(64.8,-99.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#9A9A9A").s().p("AgBAKQgEgBgDgEQgBgEAAgCQACgEADgDQAEgCACABQAEACACAEQACADgBADQgBAEgDACIgFABIgBAAg");
	this.shape_29.setTransform(56.5,-102.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#9A9A9A").s().p("AAAAKQgKgCABgIQABgEADgDQAEgDACABQAEABADAEQADADgBACQgBAFgEACQgCACgDAAIAAAAg");
	this.shape_30.setTransform(47.9,-104);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#9A9A9A").s().p("AgFAIQgDgDgBgEQAAgCACgEQADgDAEgBQADAAADACQADADABAEQABACgDAEQgDAEgEAAIgBAAQgCAAgDgCg");
	this.shape_31.setTransform(-43.7,-13);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#9A9A9A").s().p("AgJACQgBgDACgDQADgEAEgBQACgBAEACQAEADABAEQABACgDAEQgCAEgEABIgCAAQgHAAgCgIg");
	this.shape_32.setTransform(-42.1,-4.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgBgEQgCgDACgDQACgEAEgCQACgBAEACQAEACACAEQABACgCAEQgCAEgEABIgDABIgDgBg");
	this.shape_33.setTransform(-39.6,3.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#9A9A9A").s().p("AgCAKQgEgCgCgEQgCgEACgCQABgEAEgCQADgCADABQAEACACAEQAEAHgJAFIgEABIgCAAg");
	this.shape_34.setTransform(-36.2,12);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#9A9A9A").s().p("AAAAKQgFgBgCgEQgDgDABgDQABgEAEgCQAEgCACABQAEABACADQADAEgBACQgBAEgDACQgDACgDAAIAAAAg");
	this.shape_35.setTransform(-32,19.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#9A9A9A").s().p("AgHAGQgDgEABgCQAAgEAEgDQADgDADABQAEAAADADQADAEgBACQAAAEgEADQgDADgDAAQgDAAgEgEg");
	this.shape_36.setTransform(-26.9,26.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#9A9A9A").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgCAAgEgDg");
	this.shape_37.setTransform(-21.1,33.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#9A9A9A").s().p("AgFAHQgEgCAAgFQAAgCACgDQADgDAEgBQADAAADACQAEADAAAEQABADgDADQgDAEgEAAIgBAAQgCAAgDgDg");
	this.shape_38.setTransform(-14.6,39.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#9A9A9A").s().p("AgEAIQgEgCgBgEQgBgDADgDQACgEAEgBQADgBADADQAEACABAEQABACgDAEQgCAEgEABIgCAAQgBAAgDgCg");
	this.shape_39.setTransform(-7.5,44.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgBgEQgCgDACgDQADgEAEgCQACgBADACQAFACABAEQABADgCAEQgCADgEACIgDAAIgDgBg");
	this.shape_40.setTransform(0,48.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#9A9A9A").s().p("AgCAJQgEgBgCgEQgCgEACgDQABgEAEgBQADgCADACQAEABACAEQACADgCADQgBAEgEACIgEABIgCgBg");
	this.shape_41.setTransform(8,52.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#9A9A9A").s().p("AgBAKQgKgEACgIQABgEAEgCQAEgCACABQAEABACAEQADAEgBACQgCAIgHAAIgCAAg");
	this.shape_42.setTransform(16.4,54.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#9A9A9A").s().p("AAAAKQgEAAgDgEQgCgEAAgCQABgFADgCQAEgDACABQAEABADADQADAEgBACQgBAEgDADQgDACgDAAIAAAAg");
	this.shape_43.setTransform(25,56.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#9A9A9A").s().p("AAAAKQgEAAgCgEQgEgEABgCQABgEADgDQADgCADAAQAEABACADQAEAEgBACQgBAEgDADQgDACgDAAIAAAAg");
	this.shape_44.setTransform(116.6,-13);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#9A9A9A").s().p("AgBAKQgEgBgCgEQgDgEABgCQABgEAEgDQAEgCACABQAEABACAEQADADgBADQgBAEgEACQgDACgCAAIgBAAg");
	this.shape_45.setTransform(115,-4.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#9A9A9A").s().p("AgCAJQgEgBgCgEQgCgEACgCQABgEAEgCQADgCADABQAEACACAEQACADgBADQgCAEgEACIgEABIgCgBg");
	this.shape_46.setTransform(112.5,3.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#9A9A9A").s().p("AgDAJQgJgFAEgHQACgEAEgCQACgBADACQAEACACAEQACACgCAEQgCAEgEACIgDAAIgDgBg");
	this.shape_47.setTransform(109.2,12);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#9A9A9A").s().p("AgEAIQgEgCgBgEQgBgCADgEQACgDAEgBQADgBADACQAEACABAEQABADgCADQgDAEgEABIgCAAQgCAAgCgCg");
	this.shape_48.setTransform(104.9,19.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#9A9A9A").s().p("AgGAIQgDgDAAgFQgBgCADgDQAHgHAGAFQAEADAAAEQAAADgCADQgDAEgFAAQgCAAgEgCg");
	this.shape_49.setTransform(99.8,26.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#9A9A9A").s().p("AgGAHQgDgDAAgEQAAgDADgDQAGgGAHAHQADADAAACQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_50.setTransform(94,33.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#9A9A9A").s().p("AAAAKQgEAAgDgEQgCgDAAgDQAAgEAEgDQADgCADAAQAEABADADQADADgBACQAAAFgEACQgDADgDAAIAAAAg");
	this.shape_51.setTransform(87.5,39.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#9A9A9A").s().p("AgBAKQgEgBgCgEQgDgDABgDQABgEAEgCQADgDACABQAFABACAEQADADgBADQgBAEgEACQgDACgCAAIgBAAg");
	this.shape_52.setTransform(80.4,44.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#9A9A9A").s().p("AgCAKQgEgCgCgDQgCgEACgDQABgEAEgCQADgCADABQAEACACAEQACADgCADQgBAEgEACIgEABIgCAAg");
	this.shape_53.setTransform(72.8,48.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#9A9A9A").s().p("AgDAJQgEgCgCgEQgBgDACgDQACgEAEgBQACgCADACQAEABACAEQACADgCAEQgCAEgEABIgDABIgDgBg");
	this.shape_54.setTransform(64.8,52.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#9A9A9A").s().p("AgEAJQgEgCgBgFQgBgCACgEQADgEAEgBQACgBAEACQADACABAEQADAIgKAEIgCAAIgEgBg");
	this.shape_55.setTransform(56.5,54.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#9A9A9A").s().p("AgFAIQgDgDgBgEQgBgIAKgCQACgBADACQAEADABAEQABACgDAEQgDAEgEABIgBAAQgCAAgDgCg");
	this.shape_56.setTransform(47.9,56.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#858585").s().p("ABDgOQgcgbgnAAQgmAAgcAbQgcAagCAnIAAgFQAAgoAdgbQAcgcAngBQAoABAdAcQAcAbAAAoIAAAFQgCgngcgag");
	this.shape_57.setTransform(36.4,-29.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AoFiGQDwiwEoAAQELAADhCQQDgCPBwDuIgIgBQh6jKjKh4QjNh8jtgMQgJgOgOgHQgPgIgQAAQggAAgTAdQkMAPjdCZQjYCVhtDuQBdkTDsiqg");
	this.shape_58.setTransform(34,-84.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#858585").s().p("AAlAAQgMgPgQAAIgQAAQgQAAgNAPQgMALAAAOIAAgJQAAgNAMgMQANgPAQAAIAQAAQAQAAAMAPQAMAMAAANIAAAJQAAgOgMgLg");
	this.shape_59.setTransform(36.4,-71.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#5A5A5A","#3C3C3C","#1E1E1E","#070707","#020202","#000000"],[0,0.137,0.31,0.486,0.663,0.843],0,-26,0,23).s().p("AgHETQgVAAgOgMQgPgMAAgQIAAnKQAAgRAPgRQAPgQAUAAIAQAAQATAAAPAQQAPARAAARIAAHKQAAAQgPAMQgOAMgUAAg");
	this.shape_60.setTransform(36.4,-47.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#B8B8B8","#E3E3E3","#BCBCBC"],[0.141,0.51,1],0,141.4,0,-63.1).s().p("AluJGQiphFiFh+QiFh/hOilQhQiogLi9QDcAyEEg/QChgnExiAQE1iCCZgoQEFhEDaAtQA2CbAACjQAADGhNCzQhJCuiHCHQiGCHivBJQi0BNjFAAQi+AAiwhIg");
	this.shape_61.setTransform(36.1,7.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#4E4E4E").s().p("AluJGQiphFiFh+QiFh/hOilQhQiogLi9QDcAzEEhAQChgnExiAQE2iCCYgoQEFhEDaAtQA2CbAACkQAADFhNCzQhJCuiHCHQiGCHivBJQi0BNjFAAQi+AAiwhIg");
	this.shape_62.setTransform(36.1,9.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#FFFFFF","#CACACA"],[0.118,0.918],0,-51.8,0,59).s().p("AuuH2QgCgbAAgcQAAjGBNi0QBJitCHiGQCGiHCvhJQC0hNDEAAQE7AAD/C4QD4C1BlEfQjagtkFBEQiZAok4CCQkvCAigAnQiRAjiFAAQhpAAhhgWg");
	this.shape_63.setTransform(33.3,-68.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#1F1F1E","#656564","#A8A8A8","#D8D8D7","#F4F4F4","#FFFFFF"],[0,0.239,0.506,0.733,0.902,1],0,-66.8,0,76.2).s().p("Al7JbQivhIiKiDQiKiDhQirQhTiugLjEQDjA1EOhCQCmgoE8iEQFBiHCegpQEOhGDiAuQA3CfAACqQAADNhPC5QhMC1iLCLQiMCLi0BNQi7BPjMAAQjFAAi2hKg");
	this.shape_64.setTransform(36.1,8.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#060600","#393930","#63635E","#7B7B7A","#848484"],[0,0.216,0.427,0.588,0.686],0,-53.6,0,61.1).s().p("AvQIHQgBgbAAgdQAAjNBPi7QBMiyCMiLQCLiMC0hMQC7hPDLAAQFGAAEIC/QEBC6BoEqQjhgukPBGQieAplDCHQk6CEimAoQiWAkiJAAQhtAAhlgXg");
	this.shape_65.setTransform(33.2,-70.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#FFFFFF","#919191","#FFFFFF"],[0,0.506,1],17.7,-100.3,-17.7,101).s().p("Al7OyQiyhHiLiCQiLiEhTirQhWixgMjFIgBAAIgBgfIAAABIgBgmQAAjNBQi+QBOi4CNiMQCOiOC3hNQC9hRDOAAQFDAAEJC7QEIC7BtExIALAfIAAgBQAwCZAACdQAADPhRC9QhNC4iNCNQiNCNi4BNQi9BRjPAAQjFAAi2hKg");
	this.shape_66.setTransform(36,-24);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#AEAEAE","#AAAAAA","#50504D","#13130E","#020200"],[0,0.02,0.498,0.839,1],0,172.5,0,-77.1).s().p("AnkK7QjfhfititQitishfjgQhijmAAj9IABgkQElCcFUg4QCIgWCng8QBjgjDJhUQDEhSBlgkQCng7CJgVQFUg1ElCgQAVByAAByQAAD9hhDmQhfDgitCsQisCtjgBfQjoBij9AAQj8AAjohig");
	this.shape_67.setTransform(36,20.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#A6A6A6").s().p("AnkK7QjfhfititQitishejgQhijmgBj9IABgkQElCcFUg4QCIgWCng8QBjgjDJhUQDEhSBmgkQCng7CIgVQFVg1EkCgQAWBygBByQAAD9hiDmQheDgitCsQisCtjgBfQjoBij9AAQj8AAjohig");
	this.shape_68.setTransform(36.2,21.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#3B3B3B","#464646","#636363","#919191","#CDCDCD","#E2E2E2"],[0.286,0.373,0.522,0.714,0.933,0.996],0,143.5,0,-64).s().p("AzSIkQAHj4BkjhQBijYCrinQCsinDchcQDlheD3AAQDhAADRBNQDKBMCmCLQCkCKBtC5QBvC7AnDXQkkihlVA2QiIAVinA6QhmAkjFBTQjIBUhiAjQioA7iIAXQhaAOhWAAQjxAAjXhyg");
	this.shape_69.setTransform(35,-82.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AzSIkQAHj4BkjhQBijYCrinQCsinDchcQDlhfD3AAQDhAADRBOQDKBLCmCMQCkCKBtC5QBvC7AnDXQkkihlVA2QiIAVinA6QhmAkjFBTQjIBUhiAjQioA7iIAXQhaAPhWAAQjxAAjXhzg");
	this.shape_70.setTransform(35,-83.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#464646","#000000"],[0,1],0,-128.2,0,124).s().p("An1SmQjohjiyizQiziyhijoQhmjwAAkGIADhsIACABQAUj3BsjcQBpjWCviiQCwiiDfhXQDkhbD6AAQDjAADVBNQDPBLCrCMQCqCMByC7QB2DBAtDfIABAAIAVByIACA1IACBYQAAEGhmDwQhhDoi0CyQizCzjnBjQjwBlkGAAQkFAAjwhlg");
	this.shape_71.setTransform(36,-24);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(155));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.1,-153.2,258.3,258.4);


(lib.moneda_Anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.moneda();
	this.instance.setTransform(118.2,-2.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_1 = new lib.moneda();
	this.instance_1.setTransform(95.7,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_2 = new lib.moneda();
	this.instance_2.setTransform(194.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_3 = new lib.moneda();
	this.instance_3.setTransform(127.2,6.8,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_4 = new lib.moneda();
	this.instance_4.setTransform(95.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_5 = new lib.moneda();
	this.instance_5.setTransform(32.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_6 = new lib.moneda();
	this.instance_6.setTransform(100.2,-33.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_7 = new lib.moneda();
	this.instance_7.setTransform(95.7,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_8 = new lib.moneda();
	this.instance_8.setTransform(28.2,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_9 = new lib.moneda();
	this.instance_9.setTransform(28.2,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_10 = new lib.moneda();
	this.instance_10.setTransform(32.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_11 = new lib.moneda();
	this.instance_11.setTransform(32.7,2.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_12 = new lib.moneda();
	this.instance_12.setTransform(118.2,-2.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_13 = new lib.moneda();
	this.instance_13.setTransform(95.7,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_14 = new lib.moneda();
	this.instance_14.setTransform(194.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_15 = new lib.moneda();
	this.instance_15.setTransform(127.2,6.8,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_16 = new lib.moneda();
	this.instance_16.setTransform(95.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_17 = new lib.moneda();
	this.instance_17.setTransform(32.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_18 = new lib.moneda();
	this.instance_18.setTransform(100.2,-33.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_19 = new lib.moneda();
	this.instance_19.setTransform(95.7,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_20 = new lib.moneda();
	this.instance_20.setTransform(28.2,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_21 = new lib.moneda();
	this.instance_21.setTransform(28.2,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_22 = new lib.moneda();
	this.instance_22.setTransform(32.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_23 = new lib.moneda();
	this.instance_23.setTransform(32.7,2.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_24 = new lib.moneda();
	this.instance_24.setTransform(118.2,-2.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_25 = new lib.moneda();
	this.instance_25.setTransform(95.7,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_26 = new lib.moneda();
	this.instance_26.setTransform(194.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_27 = new lib.moneda();
	this.instance_27.setTransform(127.2,6.8,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_28 = new lib.moneda();
	this.instance_28.setTransform(95.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_29 = new lib.moneda();
	this.instance_29.setTransform(32.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_30 = new lib.moneda();
	this.instance_30.setTransform(122.7,-20.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_31 = new lib.moneda();
	this.instance_31.setTransform(122.7,-11.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_32 = new lib.moneda();
	this.instance_32.setTransform(95.7,-51.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_33 = new lib.moneda();
	this.instance_33.setTransform(95.7,-42.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_34 = new lib.moneda();
	this.instance_34.setTransform(100.2,-33.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_35 = new lib.moneda();
	this.instance_35.setTransform(95.7,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_36 = new lib.moneda();
	this.instance_36.setTransform(28.2,-24.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_37 = new lib.moneda();
	this.instance_37.setTransform(28.2,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_38 = new lib.moneda();
	this.instance_38.setTransform(32.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_39 = new lib.moneda();
	this.instance_39.setTransform(32.7,2.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_40 = new lib.moneda();
	this.instance_40.setTransform(118.2,-2.1,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_41 = new lib.moneda();
	this.instance_41.setTransform(95.7,-15.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_42 = new lib.moneda();
	this.instance_42.setTransform(194.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_43 = new lib.moneda();
	this.instance_43.setTransform(127.2,6.8,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_44 = new lib.moneda();
	this.instance_44.setTransform(95.7,-6.6,0.506,0.506,0,0,0,42.9,-0.1);

	this.instance_45 = new lib.moneda();
	this.instance_45.setTransform(32.7,11.3,0.506,0.506,0,0,0,42.9,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5,p:{x:32.7,y:11.3}},{t:this.instance_4,p:{y:-6.6,x:95.7}},{t:this.instance_3,p:{x:127.2,y:6.8}},{t:this.instance_2,p:{x:194.7,y:11.3}},{t:this.instance_1,p:{x:95.7,y:-15.6}},{t:this.instance,p:{x:118.2,y:-2.1}}]},90).to({state:[{t:this.instance_17,p:{x:32.7,y:11.3}},{t:this.instance_16,p:{y:-6.6,x:95.7}},{t:this.instance_15,p:{x:127.2,y:6.8}},{t:this.instance_14,p:{x:194.7,y:11.3}},{t:this.instance_13,p:{x:95.7,y:-15.6}},{t:this.instance_12,p:{x:118.2,y:-2.1}},{t:this.instance_11,p:{x:32.7,y:2.3}},{t:this.instance_10,p:{x:32.7,y:-6.6}},{t:this.instance_9,p:{x:28.2,y:-15.6}},{t:this.instance_8,p:{x:28.2,y:-24.6}},{t:this.instance_7,p:{x:95.7,y:-24.6}},{t:this.instance_6,p:{x:100.2,y:-33.6}},{t:this.instance_5,p:{x:95.7,y:-42.6}},{t:this.instance_4,p:{y:-51.6,x:95.7}},{t:this.instance_3,p:{x:122.7,y:-11.1}},{t:this.instance_2,p:{x:122.7,y:-20.1}},{t:this.instance_1,p:{x:194.7,y:2.3}},{t:this.instance,p:{x:194.7,y:-6.6}}]},17).to({state:[{t:this.instance_29,p:{x:32.7,y:11.3}},{t:this.instance_28,p:{x:95.7}},{t:this.instance_27,p:{x:127.2,y:6.8}},{t:this.instance_26,p:{x:194.7,y:11.3}},{t:this.instance_25,p:{x:95.7,y:-15.6}},{t:this.instance_24,p:{x:118.2,y:-2.1}},{t:this.instance_23,p:{x:32.7,y:2.3}},{t:this.instance_22,p:{x:32.7,y:-6.6}},{t:this.instance_21,p:{x:28.2,y:-15.6}},{t:this.instance_20,p:{x:28.2,y:-24.6}},{t:this.instance_19,p:{x:95.7,y:-24.6}},{t:this.instance_18,p:{x:100.2,y:-33.6}},{t:this.instance_17,p:{x:95.7,y:-42.6}},{t:this.instance_16,p:{y:-51.6,x:95.7}},{t:this.instance_15,p:{x:122.7,y:-11.1}},{t:this.instance_14,p:{x:122.7,y:-20.1}},{t:this.instance_13,p:{x:194.7,y:2.3}},{t:this.instance_12,p:{x:194.7,y:-6.6}},{t:this.instance_11,p:{x:100.2,y:-60.6}},{t:this.instance_10,p:{x:100.2,y:-69.6}},{t:this.instance_9,p:{x:100.2,y:-78.6}},{t:this.instance_8,p:{x:23.7,y:-33.6}},{t:this.instance_7,p:{x:28.2,y:-42.6}},{t:this.instance_6,p:{x:28.2,y:-51.6}},{t:this.instance_5,p:{x:122.7,y:-29.1}},{t:this.instance_4,p:{y:-38.1,x:122.7}},{t:this.instance_3,p:{x:199.2,y:-15.6}},{t:this.instance_2,p:{x:194.7,y:-24.6}},{t:this.instance_1,p:{x:194.7,y:-33.6}},{t:this.instance,p:{x:199.2,y:-42.6}}]},16).to({state:[{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29,p:{x:194.7,y:2.3}},{t:this.instance_28,p:{x:194.7}},{t:this.instance_27,p:{x:100.2,y:-60.6}},{t:this.instance_26,p:{x:100.2,y:-69.6}},{t:this.instance_25,p:{x:100.2,y:-78.6}},{t:this.instance_24,p:{x:23.7,y:-33.6}},{t:this.instance_23,p:{x:28.2,y:-42.6}},{t:this.instance_22,p:{x:28.2,y:-51.6}},{t:this.instance_21,p:{x:122.7,y:-29.1}},{t:this.instance_20,p:{x:122.7,y:-38.1}},{t:this.instance_19,p:{x:199.2,y:-15.6}},{t:this.instance_18,p:{x:194.7,y:-24.6}},{t:this.instance_17,p:{x:194.7,y:-33.6}},{t:this.instance_16,p:{y:-42.6,x:199.2}},{t:this.instance_15,p:{x:95.7,y:-87.6}},{t:this.instance_14,p:{x:91.2,y:-96.6}},{t:this.instance_13,p:{x:95.7,y:-105.6}},{t:this.instance_12,p:{x:95.7,y:-114.6}},{t:this.instance_11,p:{x:100.2,y:-123.6}},{t:this.instance_10,p:{x:23.7,y:-60.6}},{t:this.instance_9,p:{x:28.2,y:-69.6}},{t:this.instance_8,p:{x:23.7,y:-78.6}},{t:this.instance_7,p:{x:127.2,y:-47.1}},{t:this.instance_6,p:{x:122.7,y:-56.1}},{t:this.instance_5,p:{x:122.7,y:-65.1}},{t:this.instance_4,p:{y:-74.1,x:118.2}},{t:this.instance_3,p:{x:203.7,y:-51.6}},{t:this.instance_2,p:{x:203.7,y:-60.6}},{t:this.instance_1,p:{x:199.2,y:-69.6}},{t:this.instance,p:{x:100.2,y:-132.6}}]},15).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.grafica1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.text = new cjs.Text("320", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(-75.9,257.4);

	this.text_1 = new cjs.Text("6", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(-75.9,213.4);

	this.text_2 = new cjs.Text("160", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(-139.9,257.4);

	this.text_3 = new cjs.Text("5", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(-139.9,213.4);

	this.text_4 = new cjs.Text("80", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(-203.9,257.4);

	this.text_5 = new cjs.Text("4", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(-203.9,213.4);

	this.text_6 = new cjs.Text("40", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(-267.9,257.4);

	this.text_7 = new cjs.Text("3", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(-267.9,213.4);

	this.text_8 = new cjs.Text("20", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(-331.9,257.4);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(-331.9,213.4);

	this.text_10 = new cjs.Text("10", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(-395.9,257.4);

	this.text_11 = new cjs.Text("1", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(-395.9,213.4);

	this.text_12 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_12.lineHeight = 22;
	this.text_12.lineWidth = 50;
	this.text_12.setTransform(-483.9,257.4);

	this.text_13 = new cjs.Text("t", "italic bold 20px Verdana");
	this.text_13.lineHeight = 22;
	this.text_13.lineWidth = 50;
	this.text_13.setTransform(-483.9,213.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AE+AAIp+AAIAAG3IJ+AAgAO9G3IKAAAIAAm3IqAAAIAAG3Ip/AAAO9m2Ip/AAIAAG2IJ/AAIAAm2IKAAAIKCAAIAAG2IAAG3IqCAAAlAm2Ip/AAIAAG2IJ/AAIAAm2IJ+AAAY9m2IAAG2IKCAAAlAG3Ip/AAIqAAAIp/AAIAAm3IAAm2IJ/AAIKAAAAu/G3IAAm3IqAAAIAAG3Egi+AAAIJ/AAIAAm2");
	this.shape.setTransform(-264.9,250.5-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AE+AAIp+AAIAAm2IJ+AAIAAG2IJ/AAIAAG3Ip/AAgAY9AAIAAm2IKCAAIAAG2IqCAAIqAAAIAAm2IKAAAAE+m2IJ/AAAlAG3Ip/AAIAAm3IJ/AAIAAG3IJ+AAEAi/AAAIAAG3IqCAAIAAm3AY9G3IqAAAA4/m2IKAAAIAAG2IqAAAIp/AAIAAm2IJ/AAIAAG2IAAG3Ip/AAIAAm3Au/G3IqAAAAu/m2IJ/AA");
	this.shape_1.setTransform(-264.9,250.5-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]}).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"bold 20px Verdana"}},{t:this.text_10,p:{font:"bold 20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},50).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"bold 20px Verdana"}},{t:this.text_8,p:{font:"bold 20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},20).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"bold 20px Verdana"}},{t:this.text_6,p:{font:"bold 20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},20).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"bold 20px Verdana"}},{t:this.text_4,p:{font:"bold 20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},21).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"bold 20px Verdana"}},{t:this.text_2,p:{font:"bold 20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},20).to({state:[{t:this.shape_1},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"bold 20px Verdana"}},{t:this.text,p:{font:"bold 20px Verdana"}}]},20).to({state:[{t:this.shape},{t:this.text_13},{t:this.text_12},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1,p:{font:"20px Verdana"}},{t:this.text,p:{font:"20px Verdana"}}]},19).wait(25));

	// Capa 5
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AgjgjQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPg");
	this.shape_2.setTransform(97.7,328.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_3.setTransform(97.7,328.9);

	this.text_14 = new cjs.Text("(1,10)", "14px Verdana", "#9966CC");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(64.3,301.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAgyQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAg");
	this.shape_4.setTransform(97.7,328.9);

	this.text_15 = new cjs.Text("(2,20)", "14px Verdana", "#9966CC");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(157,313.1+incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_5.setTransform(147.3,317.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAkgjQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPg");
	this.shape_6.setTransform(97.7,328.9);

	this.text_16 = new cjs.Text("(3,40)", "14px Verdana", "#9966CC");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(206.6,289+incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("AAAgyQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAg");
	this.shape_7.setTransform(196.9,300.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_8.setTransform(196.9,300.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("AAzAAQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUg");
	this.shape_9.setTransform(97.7,328.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AAkgjQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPg");
	this.shape_10.setTransform(196.9,300.1);

	this.text_17 = new cjs.Text("(4,80)", "14px Verdana", "#9966CC");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(258.2,247.2+incremento);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1).p("AgyAAQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVg");
	this.shape_11.setTransform(248.5,258.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_12.setTransform(248.5,258.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("AAkAkQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPg");
	this.shape_13.setTransform(97.7,328.9);

	this.text_18 = new cjs.Text("(5,160)", "14px Verdana", "#9966CC");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(312.2,168);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("AgjgjQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPg");
	this.shape_14.setTransform(302.5,178.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_15.setTransform(302.5,178.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("AAAAzQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAg");
	this.shape_16.setTransform(97.7,328.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_17.setTransform(97.7,328.9);

	this.text_19 = new cjs.Text("(6,320)", "14px Verdana", "#9966CC");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(277.4,7.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AAAgyQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAg");
	this.shape_18.setTransform(346.9,18.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_19.setTransform(346.9,18.1);

	this.text_20 = new cjs.Text("(5,160)", "14px Verdana", "#9966CC");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(312.2,168);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_20.setTransform(302.5,178.9);

	this.text_21 = new cjs.Text("(4,80)", "14px Verdana", "#9966CC");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(258.2,247.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_21.setTransform(248.5,258.1);

	this.text_22 = new cjs.Text("(3,40)", "14px Verdana", "#9966CC");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(206.6,289.2+incremento);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAgyQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPQAPgPAUAAg");
	this.shape_22.setTransform(196.9,300.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_23.setTransform(196.9,300.1);

	this.text_23 = new cjs.Text("(2,20)", "14px Verdana", "#9966CC");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(157,313.1+incremento);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AgjgjQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPQgPgPAAgVQAAgUAPgPg");
	this.shape_24.setTransform(147.3,317.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#9966CC").s().p("AgjAkQgPgPAAgVQAAgUAPgPQAPgPAUAAQAVAAAPAPQAPAPAAAUQAAAVgPAPQgPAPgVAAQgUAAgPgPg");
	this.shape_25.setTransform(147.3,317.7);

	this.text_24 = new cjs.Text("(1,10)", "14px Verdana", "#9966CC");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(64.3,301.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_2,p:{x:97.7,y:328.9}}]},50).to({state:[{t:this.shape_5,p:{x:147.3,y:317.7}},{t:this.shape_2,p:{x:147.3,y:317.7}},{t:this.text_15,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_4,p:{x:97.7,y:328.9}}]},20).to({state:[{t:this.shape_8,p:{x:196.9,y:300.1}},{t:this.shape_7,p:{x:196.9,y:300.1}},{t:this.text_16,p:{x:206.6,y:289.2+incremento,text:"(3,40)"}},{t:this.shape_5,p:{x:147.3,y:317.7}},{t:this.shape_4,p:{x:147.3,y:317.7}},{t:this.text_15,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_6,p:{x:97.7,y:328.9}}]},20).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.text_17,p:{x:258.2,y:247.2,text:"(4,80)"}},{t:this.shape_8,p:{x:196.9,y:300.1}},{t:this.shape_10},{t:this.text_16,p:{x:206.6,y:289.2+incremento,text:"(3,40)"}},{t:this.shape_5,p:{x:147.3,y:317.7}},{t:this.shape_6,p:{x:147.3,y:317.7}},{t:this.text_15,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_9,p:{x:97.7,y:328.9}}]},21).to({state:[{t:this.shape_15,p:{x:302.5,y:178.9}},{t:this.shape_14},{t:this.text_18,p:{x:312.2,y:168,text:"(5,160)",lineWidth:54}},{t:this.shape_12},{t:this.shape_2,p:{x:248.5,y:258.1}},{t:this.text_17,p:{x:258.2,y:247.2,text:"(4,80)"}},{t:this.shape_8,p:{x:196.9,y:300.1}},{t:this.shape_4,p:{x:196.9,y:300.1}},{t:this.text_16,p:{x:206.6,y:289.2+incremento,text:"(3,40)"}},{t:this.shape_5,p:{x:147.3,y:317.7}},{t:this.shape_9,p:{x:147.3,y:317.7}},{t:this.text_15,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_13,p:{x:97.7,y:328.9}}]},20).to({state:[{t:this.text_24},{t:this.shape_25},{t:this.shape_24},{t:this.text_23},{t:this.shape_23},{t:this.shape_22},{t:this.text_22},{t:this.shape_21},{t:this.shape_11},{t:this.text_21},{t:this.shape_20},{t:this.shape_14},{t:this.text_20},{t:this.shape_19},{t:this.shape_18},{t:this.text_19,p:{x:277.4,y:7.2,text:"(6,320)",lineWidth:54}},{t:this.shape_17,p:{x:97.7,y:328.9}},{t:this.shape_2,p:{x:97.7,y:328.9}},{t:this.shape_15,p:{x:302.5,y:178.9}},{t:this.shape_7,p:{x:302.5,y:178.9}},{t:this.text_18,p:{x:312.2,y:168,text:"(5,160)",lineWidth:54}},{t:this.shape_12},{t:this.shape_4,p:{x:248.5,y:258.1}},{t:this.text_17,p:{x:258.2,y:247.2,text:"(4,80)"}},{t:this.shape_8,p:{x:196.9,y:300.1}},{t:this.shape_6,p:{x:196.9,y:300.1}},{t:this.text_16,p:{x:206.6,y:289.2+incremento,text:"(3,40)"}},{t:this.shape_5,p:{x:147.3,y:317.7}},{t:this.shape_13,p:{x:147.3,y:317.7}},{t:this.text_15,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.text_14,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_3},{t:this.shape_16}]},20).to({state:[{t:this.text_19,p:{x:64.3,y:301.8,text:"(1,10)",lineWidth:45}},{t:this.shape_17,p:{x:147.3,y:317.7}},{t:this.shape_24},{t:this.text_18,p:{x:157,y:313.1+incremento,text:"(2,20)",lineWidth:45}},{t:this.shape_15,p:{x:196.9,y:300.1}},{t:this.shape_7,p:{x:196.9,y:300.1}},{t:this.text_17,p:{x:206.6,y:289.2+incremento,text:"(3,40)"}},{t:this.shape_12},{t:this.shape_11},{t:this.text_16,p:{x:258.2,y:247.2,text:"(4,80)"}},{t:this.shape_8,p:{x:302.5,y:178.9}},{t:this.shape_14},{t:this.text_15,p:{x:312.2,y:168,text:"(5,160)",lineWidth:54}},{t:this.shape_5,p:{x:346.9,y:18.1}},{t:this.shape_4,p:{x:346.9,y:18.1}},{t:this.text_14,p:{x:277.4,y:7.2,text:"(6,320)",lineWidth:54}},{t:this.shape_3},{t:this.shape_2,p:{x:97.7,y:328.9}}]},19).wait(25));

	// Capa 4
	this.instance = new lib.curva1_MC();
	this.instance.setTransform(222.7,174.5,1,1,0,0,0,125,154.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(176).to({_off:false},0).to({alpha:1},18).wait(1));

	// Capa 2
	this.text_25 = new cjs.Text("350", "14px Verdana");
	this.text_25.textAlign = "right";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(33.9,-16.7);

	this.text_26 = new cjs.Text("6", "14px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(344.9,348.5);

	this.text_27 = new cjs.Text("5", "14px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(296.9,348.5);

	this.text_28 = new cjs.Text("4", "14px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(246.5,348.5);

	this.text_29 = new cjs.Text("3", "14px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(195.3,348.5);

	this.text_30 = new cjs.Text("y", "italic bold 16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 18;
	this.text_30.setTransform(34.4,-53);

	this.text_31 = new cjs.Text("300", "14px Verdana");
	this.text_31.textAlign = "right";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(33.9,28.9);

	this.text_32 = new cjs.Text("250", "14px Verdana");
	this.text_32.textAlign = "right";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(33.9,79.1);

	this.text_33 = new cjs.Text("200", "14px Verdana");
	this.text_33.textAlign = "right";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(33.9,130.9);

	this.text_34 = new cjs.Text("150", "14px Verdana");
	this.text_34.textAlign = "right";
	this.text_34.lineHeight = 16;
	this.text_34.setTransform(33.9,180.4);

	this.text_35 = new cjs.Text("100", "14px Verdana");
	this.text_35.textAlign = "right";
	this.text_35.lineHeight = 16;
	this.text_35.setTransform(33.9,231.4);

	this.text_36 = new cjs.Text("50", "14px Verdana");
	this.text_36.textAlign = "right";
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(33.9,282.4);

	this.text_37 = new cjs.Text("0", "14px Verdana");
	this.text_37.textAlign = "right";
	this.text_37.lineHeight = 16;
	this.text_37.setTransform(33.9,322.1);

	this.text_38 = new cjs.Text("2", "14px Verdana");
	this.text_38.textAlign = "center";
	this.text_38.lineHeight = 16;
	this.text_38.setTransform(146.5,348.5);

	this.text_39 = new cjs.Text("1", "14px Verdana");
	this.text_39.textAlign = "center";
	this.text_39.lineHeight = 16;
	this.text_39.setTransform(97.1,348.5);

	this.text_40 = new cjs.Text("0", "14px Verdana");
	this.text_40.textAlign = "center";
	this.text_40.lineHeight = 16;
	this.text_40.setTransform(55.6,348.5);

	this.text_41 = new cjs.Text("t", "italic bold 16px Verdana");
	this.text_41.textAlign = "center";
	this.text_41.lineHeight = 18;
	this.text_41.setTransform(5.5,341.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("A1G6XIhCAAAcmcQIjJAAIAABKA1Gy3IhCAAA1GrAIhCAAA1GjCIhCAAA1GErIhCAAA1GMpIhCAAA1GUfIhCAAEgU+Ag0IAAkkInnAAAlddaIAAhKIn3AAIAABKEgU+ggzMAAAA9DIHqAAAKGdaIAAhKIn9AAIAABKAZdcQIngAAIAABKAKGcQIH3AAAldcQIHmAA");
	this.shape_26.setTransform(184,161.5-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.text_41},{t:this.text_40},{t:this.text_39},{t:this.text_38},{t:this.text_37},{t:this.text_36},{t:this.text_35},{t:this.text_34},{t:this.text_33},{t:this.text_32},{t:this.text_31},{t:this.text_30},{t:this.text_29},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.text_25}]}).wait(195));

	// Capa 1
	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.9,-53,856,452.2);


(lib.Grupodeclips0_67 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgvCMQgYgKgSgSQgRgSgLgbQgLgcAAgeQAAgcAKgdQALgdASgUQARgWAZgNQAZgMAZgCQAaAAAYAKQAWAKATAUQARAUAJAaQAKAcgBAcQAAAagKAdQgKAagSAVQgRAVgXANQgXANgaACIgIAAQgVAAgUgHg");
	mask.setTransform(14.1,15.3);

	// Capa 3
	this.instance = new lib.Grupodeclips0_68();
	this.instance.setTransform(14.4,15.6,1,1,0,0,0,14.4,15.6);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.1,0.5,26,29.7);


(lib.Grupodeclips0_64 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhnITQgHgBgHgFQgGgEgEgHQgDgHAAgJIAAgFIAAgCIgGsYQAAgIgCgHIgEgMQgDgGgDgCQgDgCgEAAQgDAAgDADIgFAIIgEAKIgCAOIAEFpIAAAFIgCAGIgGAKIgEAEIgFAEIgFACIgFACIgdAFIgLgBIgFgCQgCAAgDgDIgDgEIgDgEIgCgFIAAgGIgImhQAAgeAJgcQAJgcARgWQARgWAWgOQAWgNAZgDIEhgYQAWgCAWAJQAVAJAPARQAQASAJAXQAIAYAAAcIgKGKIgCAKIgCADIgHAJIgFADIgEACIgjAGIgFAAIgEgCIgEgDIgDgEQgCgCgBgDIgBgEIAGlgIgCgLIgDgIQgCgEgDgCQgCgBgDAAQgDAAgDADIgGAJQgDAGAAAGQgCAHAAAIIgNMHQAAAFgEAKQgFAJgFAFQgFAGgHAEQgIAFgGABIghAIQgJACgGgBQgEgBgIgEQgFgDgEgGQgDgGgCgIIACmKQAAgHgBgGQgBgFgDgGQgCgFgDgBQgDgDgDABQgDAAgEAEQgCACgBAGQgDAHgBAFIgBAOIgBGMQgBAHgEAJQgDAGgHAHQgFAGgIAFQgGAEgKADIgkAIIgJABIgIAAg");
	mask.setTransform(27.4,54.2);

	// Capa 3
	this.instance = new lib.Grupodeclips0_65();
	this.instance.setTransform(27.9,54.2,1,1,0,0,0,27.9,54.2);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.1,0.9,52.6,106.5);


(lib.Grupodeclips0_62 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjVB0QhZgwAAhEQAAhCBZgxQBZgwB8AAQB9AABZAwQBZAwAABDQAABEhZAwQhZAwh9AAQh8AAhZgwg");
	mask.setTransform(31.6,17.1);

	// Capa 3
	this.instance = new lib.Grupodeclips0_63();
	this.instance.setTransform(31.7,17.5,1,1,0,0,0,31.7,17.5);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.3,0.7,60.7,33);


(lib.Grupodeclips0_25 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgqB9QgUgIgRgRQgRgSgJgWQgKgaAAgaQAAgZAKgaQAJgZAQgTQASgUAUgLQAWgLAWgBQAZgBAVAKQAUAJAQASQAQARAIAXQAIAZAAAZQAAAYgKAZQgJAZgPASQgQASgUAMQgWAMgXABIgGAAQgTAAgSgGg");
	mask.setTransform(12.7,14.1);

	// Capa 3
	this.instance = new lib.Grupodeclips0_26();
	this.instance.setTransform(13.5,14.4,1,1,0,0,0,13.5,14.4);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.1,0.9,23.3,26.6);


(lib.Grupodeclips0_22 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhcHbQgIgCgFgDQgFgEgEgGQgDgGAAgIIAAgEIABgCIgGrGIgBgNQgBgFgDgGQgDgFgCgCQgDgCgEAAIgFADQgDADgCAEIgDAKIgCALIAEFDIgCAKIgFAKIgEADIgEADIgFADIgkAGIgEgBIgFgCIgEgCIgDgEIgDgEIgBgFIgBgFIgHl1QAAgcAIgYQAIgYAPgVQAQgUATgMQAVgMAVgCIEDgWQAVgBASAIQATAIAOAPQAOAPAIAVQAIAXgBAYIgJFhIgBAJIgCACIgDAFIgEADIgEADIgEACIgEABIgbAFIgEgBIgEgCIgEgCIgDgEIgCgEIgBgIIAGk3IgCgKIgDgHIgEgFQgCgBgDAAQgCAAgDADIgFAIIgEALIgMLCQgBAFgEAJQgCAGgGAGIgLAKQgGAEgHABIgdAHQgIACgFgBQgGgBgFgDQgGgFgCgEQgEgGAAgGIABlhIgBgMIgDgJQgCgEgDgCQgDgCgCAAQgEABgCADQgDADAAAEIgDALIgBAMIgBFjQgCAJgDAFQgDAHgGAFIgLAKQgIAEgHACIggAIIgKABIgFgBg");
	mask.setTransform(24.6,48.6);

	// Capa 3
	this.instance = new lib.Grupodeclips0_23();
	this.instance.setTransform(24.9,48.7,1,1,0,0,0,24.9,48.7);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.1,0.9,47.1,95.4);


(lib.Grupodeclips0_20 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjVB0QhZgwAAhEQAAhDBZgwQBZgwB8AAQB9AABZAwQBZAwAABDQAABEhZAwQhZAwh9AAQh8AAhZgwg");
	mask.setTransform(31.4,17.1);

	// Capa 3
	this.instance = new lib.Grupodeclips0_21();
	this.instance.setTransform(31.7,17.3,1,1,0,0,0,31.7,17.3);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1.1,0.6,60.7,33);


(lib.Mapadebits1b = function() {
	this.initialize(img.Mapadebits1b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,140);


(lib.Mapadebits2b = function() {
	this.initialize(img.Mapadebits2b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,280);


(lib.Mapadebits3b = function() {
	this.initialize(img.Mapadebits3b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,297);


(lib.Mapadebits4b = function() {
	this.initialize(img.Mapadebits4b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,297);


(lib.Mapadebits5b = function() {
	this.initialize(img.Mapadebits5b);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,333,319);


(lib.amebas3_IMG = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.Mapadebits5b();
	this.instance.setTransform(-0.1,-0.1);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,333,319);


(lib.amebas2_IMG = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Mapadebits2b();
	this.instance.setTransform(-0.1,-0.1);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,333,280);


(lib.amebas1_IMG = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Mapadebits1b();
	this.instance.setTransform(-0.1,-0.1);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,333,140);


(lib.amebas_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Egk7gDMMBJ3AAAIAAAyMhJ3AAAg");
	var mask_graphics_1 = new cjs.Graphics().p("Egk7AAzIAAhlMBJ3AAAIAABlg");
	var mask_graphics_2 = new cjs.Graphics().p("Egk7ABOIAAibMBJ3AAAIAACbg");
	var mask_graphics_3 = new cjs.Graphics().p("Egk7ABpIAAjRMBJ3AAAIAADRg");
	var mask_graphics_4 = new cjs.Graphics().p("Egk7ACDIAAkFMBJ3AAAIAAEFg");
	var mask_graphics_5 = new cjs.Graphics().p("Egk7ACeIAAk7MBJ3AAAIAAE7g");
	var mask_graphics_6 = new cjs.Graphics().p("Egk7AC5IAAlxMBJ3AAAIAAFxg");
	var mask_graphics_7 = new cjs.Graphics().p("Egk7ADUIAAmnMBJ3AAAIAAGng");
	var mask_graphics_8 = new cjs.Graphics().p("Egk7ADuIAAnbMBJ3AAAIAAHbg");
	var mask_graphics_9 = new cjs.Graphics().p("Egk7AEJIAAoRMBJ3AAAIAAIRg");
	var mask_graphics_10 = new cjs.Graphics().p("Egk7AEkIAApHMBJ3AAAIAAJHg");
	var mask_graphics_11 = new cjs.Graphics().p("Egk7AE/IAAp9MBJ3AAAIAAJ9g");
	var mask_graphics_12 = new cjs.Graphics().p("Egk7AFZIAAqxMBJ3AAAIAAKxg");
	var mask_graphics_13 = new cjs.Graphics().p("Egk7AF0IAArnMBJ3AAAIAALng");
	var mask_graphics_14 = new cjs.Graphics().p("Egk7AGPIAAsdMBJ3AAAIAAMdg");
	var mask_graphics_15 = new cjs.Graphics().p("Egk7AGpIAAtRMBJ3AAAIAANRg");
	var mask_graphics_16 = new cjs.Graphics().p("Egk7AHEIAAuHMBJ3AAAIAAOHg");
	var mask_graphics_17 = new cjs.Graphics().p("Egk7AHfIAAu9MBJ3AAAIAAO9g");
	var mask_graphics_18 = new cjs.Graphics().p("Egk7AH6IAAvzMBJ3AAAIAAPzg");
	var mask_graphics_19 = new cjs.Graphics().p("Egk7AIUIAAwnMBJ3AAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("Egk7AIvIAAxdMBJ3AAAIAARdg");
	var mask_graphics_21 = new cjs.Graphics().p("Egk7AJKIAAyTMBJ3AAAIAASTg");
	var mask_graphics_22 = new cjs.Graphics().p("Egk7AJlIAAzJMBJ3AAAIAATJg");
	var mask_graphics_23 = new cjs.Graphics().p("Egk7AJ/IAAz9MBJ3AAAIAAT9g");
	var mask_graphics_24 = new cjs.Graphics().p("Egk7AKaIAA0zMBJ3AAAIAAUzg");
	var mask_graphics_25 = new cjs.Graphics().p("Egk7AK1IAA1pMBJ3AAAIAAVpg");
	var mask_graphics_26 = new cjs.Graphics().p("Egk7gLPMBJ3AAAIAAWfMhJ3AAAg");
	var mask_graphics_27 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_28 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_29 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_30 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_31 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_32 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_33 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_34 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_35 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_36 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_37 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_38 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_39 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_40 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_41 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_42 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_43 = new cjs.Graphics().p("Egk7ALQIAA2eMBJ3AAAIAAWeg");
	var mask_graphics_44 = new cjs.Graphics().p("Egk7gLPMBJ3AAAIAAWfMhJ3AAAg");
	var mask_graphics_45 = new cjs.Graphics().p("Egk7ALuIAA3bMBJ3AAAIAAXbg");
	var mask_graphics_46 = new cjs.Graphics().p("Egk7AMMIAA4XMBJ3AAAIAAYXg");
	var mask_graphics_47 = new cjs.Graphics().p("Egk7AMqIAA5TMBJ3AAAIAAZTg");
	var mask_graphics_48 = new cjs.Graphics().p("Egk7ANIIAA6PMBJ3AAAIAAaPg");
	var mask_graphics_49 = new cjs.Graphics().p("Egk7ANnIAA7NMBJ3AAAIAAbNg");
	var mask_graphics_50 = new cjs.Graphics().p("Egk7AOFIAA8JMBJ3AAAIAAcJg");
	var mask_graphics_51 = new cjs.Graphics().p("Egk7AOjIAA9FMBJ3AAAIAAdFg");
	var mask_graphics_52 = new cjs.Graphics().p("Egk7APBIAA+BMBJ3AAAIAAeBg");
	var mask_graphics_53 = new cjs.Graphics().p("Egk7APgIAA+/MBJ3AAAIAAe/g");
	var mask_graphics_54 = new cjs.Graphics().p("Egk7AP+IAA/7MBJ3AAAIAAf7g");
	var mask_graphics_55 = new cjs.Graphics().p("Egk7AQcMAAAgg3MBJ3AAAMAAAAg3g");
	var mask_graphics_56 = new cjs.Graphics().p("Egk7AQ6MAAAghzMBJ3AAAMAAAAhzg");
	var mask_graphics_57 = new cjs.Graphics().p("Egk7ARZMAAAgixMBJ3AAAMAAAAixg");
	var mask_graphics_58 = new cjs.Graphics().p("Egk7AR3MAAAgjtMBJ3AAAMAAAAjtg");
	var mask_graphics_59 = new cjs.Graphics().p("Egk7gSUMBJ3AAAMAAAAkpMhJ3AAAg");
	var mask_graphics_60 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_61 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_62 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_63 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_64 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_65 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_66 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_67 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_68 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_69 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_70 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_71 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_72 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_73 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_74 = new cjs.Graphics().p("Egk7ASVMAAAgkpMBJ3AAAMAAAAkpg");
	var mask_graphics_75 = new cjs.Graphics().p("Egk7gSUMBJ3AAAMAAAAkpMhJ3AAAg");
	var mask_graphics_76 = new cjs.Graphics().p("Egk7ASrMAAAglVMBJ3AAAMAAAAlVg");
	var mask_graphics_77 = new cjs.Graphics().p("Egk7ATBMAAAgmBMBJ3AAAMAAAAmBg");
	var mask_graphics_78 = new cjs.Graphics().p("Egk7ATXMAAAgmtMBJ3AAAMAAAAmtg");
	var mask_graphics_79 = new cjs.Graphics().p("Egk7ATtMAAAgnZMBJ3AAAMAAAAnZg");
	var mask_graphics_80 = new cjs.Graphics().p("Egk7AUEMAAAgoHMBJ3AAAMAAAAoHg");
	var mask_graphics_81 = new cjs.Graphics().p("Egk7AUaMAAAgozMBJ3AAAMAAAAozg");
	var mask_graphics_82 = new cjs.Graphics().p("Egk7AUwMAAAgpfMBJ3AAAMAAAApfg");
	var mask_graphics_83 = new cjs.Graphics().p("Egk7AVGMAAAgqLMBJ3AAAMAAAAqLg");
	var mask_graphics_84 = new cjs.Graphics().p("Egk7AVcMAAAgq3MBJ3AAAMAAAAq3g");
	var mask_graphics_85 = new cjs.Graphics().p("Egk7AVyMAAAgrjMBJ3AAAMAAAArjg");
	var mask_graphics_86 = new cjs.Graphics().p("Egk7AWIMAAAgsPMBJ3AAAMAAAAsPg");
	var mask_graphics_87 = new cjs.Graphics().p("Egk7AWeMAAAgs7MBJ3AAAMAAAAs7g");
	var mask_graphics_88 = new cjs.Graphics().p("Egk7AW0MAAAgtnMBJ3AAAMAAAAtng");
	var mask_graphics_89 = new cjs.Graphics().p("Egk7AXKMAAAguTMBJ3AAAMAAAAuTg");
	var mask_graphics_90 = new cjs.Graphics().p("Egk7AXhMAAAgvBMBJ3AAAMAAAAvBg");
	var mask_graphics_91 = new cjs.Graphics().p("Egk7AX3MAAAgvtMBJ3AAAMAAAAvtg");
	var mask_graphics_92 = new cjs.Graphics().p("Egk7gYMMBJ3AAAMAAAAwZMhJ3AAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:228.5,y:-20.4}).wait(1).to({graphics:mask_graphics_1,x:228.5,y:-35.8}).wait(1).to({graphics:mask_graphics_2,x:228.5,y:-33.1}).wait(1).to({graphics:mask_graphics_3,x:228.5,y:-30.4}).wait(1).to({graphics:mask_graphics_4,x:228.5,y:-27.7}).wait(1).to({graphics:mask_graphics_5,x:228.5,y:-25.1}).wait(1).to({graphics:mask_graphics_6,x:228.5,y:-22.4}).wait(1).to({graphics:mask_graphics_7,x:228.5,y:-19.7}).wait(1).to({graphics:mask_graphics_8,x:228.5,y:-17}).wait(1).to({graphics:mask_graphics_9,x:228.5,y:-14.3}).wait(1).to({graphics:mask_graphics_10,x:228.5,y:-11.7}).wait(1).to({graphics:mask_graphics_11,x:228.5,y:-9}).wait(1).to({graphics:mask_graphics_12,x:228.5,y:-6.3}).wait(1).to({graphics:mask_graphics_13,x:228.5,y:-3.6}).wait(1).to({graphics:mask_graphics_14,x:228.5,y:-0.9}).wait(1).to({graphics:mask_graphics_15,x:228.5,y:1.6}).wait(1).to({graphics:mask_graphics_16,x:228.5,y:4.3}).wait(1).to({graphics:mask_graphics_17,x:228.5,y:7}).wait(1).to({graphics:mask_graphics_18,x:228.5,y:9.7}).wait(1).to({graphics:mask_graphics_19,x:228.5,y:12.3}).wait(1).to({graphics:mask_graphics_20,x:228.5,y:15}).wait(1).to({graphics:mask_graphics_21,x:228.5,y:17.7}).wait(1).to({graphics:mask_graphics_22,x:228.5,y:20.4}).wait(1).to({graphics:mask_graphics_23,x:228.5,y:23.1}).wait(1).to({graphics:mask_graphics_24,x:228.5,y:25.7}).wait(1).to({graphics:mask_graphics_25,x:228.5,y:28.4}).wait(1).to({graphics:mask_graphics_26,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_27,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_28,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_29,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_30,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_31,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_32,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_33,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_34,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_35,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_36,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_37,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_38,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_39,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_40,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_41,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_42,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_43,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_44,x:228.5,y:31.1}).wait(1).to({graphics:mask_graphics_45,x:228.5,y:34.1}).wait(1).to({graphics:mask_graphics_46,x:228.5,y:37.1}).wait(1).to({graphics:mask_graphics_47,x:228.5,y:40.1}).wait(1).to({graphics:mask_graphics_48,x:228.5,y:43.1}).wait(1).to({graphics:mask_graphics_49,x:228.5,y:46.1}).wait(1).to({graphics:mask_graphics_50,x:228.5,y:49.1}).wait(1).to({graphics:mask_graphics_51,x:228.5,y:52.1}).wait(1).to({graphics:mask_graphics_52,x:228.5,y:55.1}).wait(1).to({graphics:mask_graphics_53,x:228.5,y:58.1}).wait(1).to({graphics:mask_graphics_54,x:228.5,y:61.1}).wait(1).to({graphics:mask_graphics_55,x:228.5,y:64.1}).wait(1).to({graphics:mask_graphics_56,x:228.5,y:67.1}).wait(1).to({graphics:mask_graphics_57,x:228.5,y:70.1}).wait(1).to({graphics:mask_graphics_58,x:228.5,y:73.1}).wait(1).to({graphics:mask_graphics_59,x:228.5,y:76.1}).wait(1).to({graphics:mask_graphics_60,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_61,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_62,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_63,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_64,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_65,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_66,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_67,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_68,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_69,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_70,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_71,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_72,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_73,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_74,x:228.5,y:76.2}).wait(1).to({graphics:mask_graphics_75,x:228.5,y:76.1}).wait(1).to({graphics:mask_graphics_76,x:228.5,y:78.4}).wait(1).to({graphics:mask_graphics_77,x:228.5,y:80.6}).wait(1).to({graphics:mask_graphics_78,x:228.5,y:82.9}).wait(1).to({graphics:mask_graphics_79,x:228.5,y:85.1}).wait(1).to({graphics:mask_graphics_80,x:228.5,y:87.4}).wait(1).to({graphics:mask_graphics_81,x:228.5,y:89.6}).wait(1).to({graphics:mask_graphics_82,x:228.5,y:91.9}).wait(1).to({graphics:mask_graphics_83,x:228.5,y:94.1}).wait(1).to({graphics:mask_graphics_84,x:228.5,y:96.4}).wait(1).to({graphics:mask_graphics_85,x:228.5,y:98.6}).wait(1).to({graphics:mask_graphics_86,x:228.5,y:100.9}).wait(1).to({graphics:mask_graphics_87,x:228.5,y:103.1}).wait(1).to({graphics:mask_graphics_88,x:228.5,y:105.4}).wait(1).to({graphics:mask_graphics_89,x:228.5,y:107.6}).wait(1).to({graphics:mask_graphics_90,x:228.5,y:109.9}).wait(1).to({graphics:mask_graphics_91,x:228.5,y:112.1}).wait(1).to({graphics:mask_graphics_92,x:228.5,y:114.4}).wait(38));

	
	// Capa 5
	this.instance = new lib.amebas1_IMG();
	this.instance.setTransform(664.8,68.9,1,1,0,0,0,166.3,69.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(29).to({_off:false},0).to({alpha:1},14).wait(87));

	// Capa 6
	this.instance_1 = new lib.amebas2_IMG();
	this.instance_1.setTransform(664.8,68.9,1,1,0,0,0,166.3,69.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60).to({_off:false},0).to({alpha:1},14).wait(56));

	// Capa 7
	this.instance_2 = new lib.amebas3_IMG();
	this.instance_2.setTransform(664.8,68.9,1,1,0,0,0,166.3,69.9);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(94).to({_off:false},0).to({alpha:1},15).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.7,-30.9,471,400);


(lib.muñequitos_4 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Grupodeclips0_25();
	this.instance.setTransform(391.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape.setTransform(382.4,13.3);

	this.instance_1 = new lib.Grupodeclips0_24();
	this.instance_1.setTransform(389.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_1.setTransform(384.4,55.2);

	this.instance_2 = new lib.Grupodeclips0_22();
	this.instance_2.setTransform(390.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_2.setTransform(375.7,83);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_3.setTransform(403.6,58.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_4.setTransform(390.1,98);

	this.instance_3 = new lib.Grupodeclips0_20();
	this.instance_3.setTransform(390.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_4 = new lib.Grupodeclips0_25();
	this.instance_4.setTransform(271.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_5.setTransform(262.4,13.3);

	this.instance_5 = new lib.Grupodeclips0_24();
	this.instance_5.setTransform(269.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_6.setTransform(264.4,55.2);

	this.instance_6 = new lib.Grupodeclips0_22();
	this.instance_6.setTransform(270.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_7.setTransform(255.7,83);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_8.setTransform(283.6,58.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_9.setTransform(270.1,98);

	this.instance_7 = new lib.Grupodeclips0_20();
	this.instance_7.setTransform(270.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_8 = new lib.Grupodeclips0_25();
	this.instance_8.setTransform(151.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_10.setTransform(142.4,13.3);

	this.instance_9 = new lib.Grupodeclips0_24();
	this.instance_9.setTransform(149.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_11.setTransform(144.4,55.2);

	this.instance_10 = new lib.Grupodeclips0_22();
	this.instance_10.setTransform(150.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_12.setTransform(135.7,83);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_13.setTransform(163.6,58.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_14.setTransform(150.1,98);

	this.instance_11 = new lib.Grupodeclips0_20();
	this.instance_11.setTransform(150.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_12 = new lib.Grupodeclips0_25();
	this.instance_12.setTransform(31.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_15.setTransform(22.4,13.3);

	this.instance_13 = new lib.Grupodeclips0_24();
	this.instance_13.setTransform(29.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_16.setTransform(24.4,55.2);

	this.instance_14 = new lib.Grupodeclips0_22();
	this.instance_14.setTransform(30.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_17.setTransform(15.7,83);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_18.setTransform(43.6,58.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_19.setTransform(30.1,98);

	this.instance_15 = new lib.Grupodeclips0_20();
	this.instance_15.setTransform(30.6,118.4,1,1,0,0,0,31.7,17.3);

	this.addChild(this.instance_15,this.shape_19,this.shape_18,this.shape_17,this.instance_14,this.shape_16,this.instance_13,this.shape_15,this.instance_12,this.instance_11,this.shape_14,this.shape_13,this.shape_12,this.instance_10,this.shape_11,this.instance_9,this.shape_10,this.instance_8,this.instance_7,this.shape_9,this.shape_8,this.shape_7,this.instance_6,this.shape_6,this.instance_5,this.shape_5,this.instance_4,this.instance_3,this.shape_4,this.shape_3,this.shape_2,this.instance_2,this.shape_1,this.instance_1,this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,420.7,134.7);


(lib.muñequitos_3 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Grupodeclips0_25();
	this.instance.setTransform(273.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape.setTransform(264.4,13.3);

	this.instance_1 = new lib.Grupodeclips0_24();
	this.instance_1.setTransform(271.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_1.setTransform(266.4,55.2);

	this.instance_2 = new lib.Grupodeclips0_22();
	this.instance_2.setTransform(272.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_2.setTransform(257.7,83);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_3.setTransform(285.6,58.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_4.setTransform(272.1,98);

	this.instance_3 = new lib.Grupodeclips0_20();
	this.instance_3.setTransform(272.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_4 = new lib.Grupodeclips0_25();
	this.instance_4.setTransform(153.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_5.setTransform(144.4,13.3);

	this.instance_5 = new lib.Grupodeclips0_24();
	this.instance_5.setTransform(151.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_6.setTransform(146.4,55.2);

	this.instance_6 = new lib.Grupodeclips0_22();
	this.instance_6.setTransform(152.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_7.setTransform(137.7,83);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_8.setTransform(165.6,58.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_9.setTransform(152.1,98);

	this.instance_7 = new lib.Grupodeclips0_20();
	this.instance_7.setTransform(152.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_8 = new lib.Grupodeclips0_25();
	this.instance_8.setTransform(31.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_10.setTransform(22.4,13.3);

	this.instance_9 = new lib.Grupodeclips0_24();
	this.instance_9.setTransform(29.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_11.setTransform(24.4,55.2);

	this.instance_10 = new lib.Grupodeclips0_22();
	this.instance_10.setTransform(30.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_12.setTransform(15.7,83);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_13.setTransform(43.6,58.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_14.setTransform(30.1,98);

	this.instance_11 = new lib.Grupodeclips0_20();
	this.instance_11.setTransform(30.6,118.4,1,1,0,0,0,31.7,17.3);

	this.addChild(this.instance_11,this.shape_14,this.shape_13,this.shape_12,this.instance_10,this.shape_11,this.instance_9,this.shape_10,this.instance_8,this.instance_7,this.shape_9,this.shape_8,this.shape_7,this.instance_6,this.shape_6,this.instance_5,this.shape_5,this.instance_4,this.instance_3,this.shape_4,this.shape_3,this.shape_2,this.instance_2,this.shape_1,this.instance_1,this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,302.7,134.7);


(lib.muñequitos_2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Grupodeclips0_25();
	this.instance.setTransform(151.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape.setTransform(142.4,13.3);

	this.instance_1 = new lib.Grupodeclips0_24();
	this.instance_1.setTransform(149.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_1.setTransform(144.4,55.2);

	this.instance_2 = new lib.Grupodeclips0_22();
	this.instance_2.setTransform(150.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_2.setTransform(135.7,83);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_3.setTransform(163.6,58.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_4.setTransform(150.1,98);

	this.instance_3 = new lib.Grupodeclips0_20();
	this.instance_3.setTransform(150.6,118.4,1,1,0,0,0,31.7,17.3);

	this.instance_4 = new lib.Grupodeclips0_25();
	this.instance_4.setTransform(31.1,14.2,1,1,0,0,0,13.5,14.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7B787A").s().p("AgCB2QgRgFgOgLQgPgMgJgOQgLgPgGgTQgFgRgBgXQAAgZAJgYQAIgYAQgTQASgUAUgKQASgLAZgBIAvAHQgYABgWAMQgUAKgQAUQgQAUgJAZQgKAaAAAZQAAAUAHAVQAGATAKAQQAKAOANAMQAOALARAGg");
	this.shape_5.setTransform(22.4,13.3);

	this.instance_5 = new lib.Grupodeclips0_24();
	this.instance_5.setTransform(29.1,0.4,1,1,0,0,0,3.3,0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7B787A").s().p("AjKD/IgEgDIgCgFIgCgEIAAgFIgIlrQgBgZAIgaQAHgWAQgWQAOgTAUgLQASgMAXgCIEEgVIAIABIAHABIAHABIAyAPIgPgDIgHgBIkLAXQgVACgVAMQgTAMgQAUQgPAUgIAYQgIAZAAAcIAHF1IABAFIABAFIADAEIAEAEg");
	this.shape_6.setTransform(24.4,55.2);

	this.instance_6 = new lib.Grupodeclips0_22();
	this.instance_6.setTransform(30.4,75.8,1,1,0,0,0,24.9,48.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4D4C4E").s().p("AgFFkIgEgFIgDgFIgBgFIgBgHIAAgCIAAgCIAAgCIABgCIgJqyIgBgLIgDgJIgDgHIgDgDIAnATQACABACAEIAEAGIADAKIABAMIAGLFIgBACIABAKIAEALIAEAFg");
	this.shape_7.setTransform(15.7,83);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4D4C4E").s().p("AgPCeIgBgBIgBgBIgDgDIgDgIIAEkzIgCgIIgCgHIgDgFIgEgDIAvATIAEACIADAFIACAIQACAEAAAEIgGE2IABAJIACAEIADADIABABIACABg");
	this.shape_8.setTransform(43.6,58.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#7B787A").s().p("AgLCwIgGgIIgCgFIgBgFIAAlXIgBgJIgCgIIgDgGIgDgEIAqAcIAEAEIADAGIACAIIgBFpIABAFIACAFIAHAIg");
	this.shape_9.setTransform(30.1,98);

	this.instance_7 = new lib.Grupodeclips0_20();
	this.instance_7.setTransform(30.6,118.4,1,1,0,0,0,31.7,17.3);

	this.addChild(this.instance_7,this.shape_9,this.shape_8,this.shape_7,this.instance_6,this.shape_6,this.instance_5,this.shape_5,this.instance_4,this.instance_3,this.shape_4,this.shape_3,this.shape_2,this.instance_2,this.shape_1,this.instance_1,this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,180.7,134.7);


(lib.munequitos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 3
	this.instance = new lib.Grupodeclips0_67();
	this.instance.setTransform(54.3,26.4,1,1,0,0,0,14.4,15.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C22E12").s().p("AgDCEQgSgGgQgMQgOgKgOgSQgMgUgGgSQgHgVAAgYQAAgbAKgcQAKgcASgUQARgWAYgMQAVgMAbgBIA2AIQgbABgZANQgZANgPAVQgSAUgLAeQgKAcAAAdQAAAYAHAWQAHAWALARQAMARAOAMQAQAMARAGg");
	this.shape.setTransform(45.2,25.4);

	this.instance_1 = new lib.Grupodeclips0_66();
	this.instance_1.setTransform(52.4,10.9,1,1,0,0,0,3.4,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C22E12").s().p("AjhEeIgBAAIAAgBIAAAAIgEgEIgCgEIgCgFIgBgGIgJmWQAAgdAJgbQAIgcARgVQAPgUAWgOQAXgNAYgCIEagXIAJgBIAIABIAIABIBAASIgIgCIgJgBIgIAAIgJAAIkhAYQgZADgWANQgWAOgRAWQgRAWgJAcQgJAcABAeIAHGhIABAGIACAFIACAEIADAEg");
	this.shape_1.setTransform(47.4,72.1);

	this.instance_2 = new lib.Grupodeclips0_64();
	this.instance_2.setTransform(54.2,95.1,1,1,0,0,0,27.9,54.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#A01E18").s().p("AgFGOIgEgFIgDgGIgCgGIAAgLIAAgDIgJsEIgBgMIgDgLIgFgHQgCgEgDgBIAuAWQADACACADIAFAIIADALIABAMIAGMZIAAACIAAAMIACAGIADAGIAEAEg");
	this.shape_2.setTransform(37.6,103.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A01E18").s().p("AgRCwIgBgBIgBAAIgGgIIgBgKIAFlSIgFgRIgDgFIgEgDIA0AUIAFADIADAGIADAHIABAKIgGFgIABAEQABADACACIADAEIABABIABAAIAAABg");
	this.shape_3.setTransform(68.9,76.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C22E12").s().p("AgMDEIgHgIIgEgMIAAmJIgDgJIgDgHIgEgEIAwAgIAEADIADAHIADAUIgCGIIACAHIACAFIADAFIAEAEg");
	this.shape_4.setTransform(53.8,120);

	this.instance_3 = new lib.Grupodeclips0_62();
	this.instance_3.setTransform(52.6,144.2,1,1,0,0,0,31.7,17.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.instance_2},{t:this.shape_1},{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(90));

	// Capa 4
	this.instance_4 = new lib.muñequitos_2();
	this.instance_4.setTransform(44.3,8.3,1,1,0,0,0,90.5,67.7);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(9).to({_off:false},0).to({alpha:1},27).wait(54));

	// Capa 2
	this.instance_5 = new lib.muñequitos_3();
	this.instance_5.setTransform(40.4,-43.6,1,1,0,0,0,151.6,67.7);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(36).to({_off:false},0).to({alpha:1},27).wait(27));

	// Capa 3
	this.instance_6 = new lib.muñequitos_4();
	this.instance_6.setTransform(36.4,-92.6,1,1,0,0,0,210.6,67.7);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(63).to({_off:false},0).to({alpha:1},26).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22.1,10.5,60.7,149.8);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}