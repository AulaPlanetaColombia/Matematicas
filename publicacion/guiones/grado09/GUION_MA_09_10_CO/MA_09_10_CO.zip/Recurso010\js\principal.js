(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,1,0,0);
        titulo1(this,txt['titulo']);
	this.btn_elementos = new lib.btn_elementos_1();
	this.btn_elementos.setTransform(248.1,231.5,1,1,0,0,0,135,25);
	new cjs.ButtonHelper(this.btn_elementos, 0, 1, 2, false, new lib.btn_elementos_1(), 3);

	this.btn_deuna = new lib.btn_una();
	//this.btn_deuna.setTransform(248.1,338.8,1,1,0,0,0,135,25);
	this.btn_deuna.setTransform(-248.1,-338.8,1,1,0,0,0,135,25);
	new cjs.ButtonHelper(this.btn_deuna, 0, 1, 2, false, new lib.btn_una(), 3);

	this.btn_dedos = new lib.btn_dedos();
	this.btn_dedos.setTransform(248.3,447.7,1,1,0,0,0,135.2,25);
	new cjs.ButtonHelper(this.btn_dedos, 0, 1, 2, false, new lib.btn_dedos(), 3);

  this.informacion.on("click", function (evt) {
        putStage(new lib.frame2());
    });

  this.btn_elementos.on("click", function (evt) {
        putStage(new lib.frame3());
    });
this.btn_deuna.on("click", function (evt) {
        putStage(new lib.frame4());
    });
this.btn_dedos.on("click", function (evt) {
        putStage(new lib.frame5());
    });

	this.instance = new lib._01();
	this.instance.setTransform(556.6,148);

        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance,this.btn_dedos,this.btn_deuna,this.btn_elementos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit1'],"23px");
	this.instance = new lib.MT_07_13_0901A();
	this.instance.setTransform(275,147.2,0.8,0.8);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
        
	this.instance = new lib.CdP_Circulo();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro("single",2);
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    	this.instance = new lib.CdP_Centro();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio("single",2);
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    
this.instance = new lib.CdP_Radio();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda("single",2);
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    
this.instance = new lib.CdP_Cuerda();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro("single",2);
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    
this.instance = new lib.CdP_Diametro();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos();
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco("single",2);
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    
this.instance = new lib.CdP_Arco();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2']);
        this.btn_todos = new lib.btn_elementos("single",2);
	this.btn_todos.setTransform(147.7,510.7,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_todos, 0, 1, 2, false, new lib.btn_elementos(), 3);

	this.btn_arco = new lib.btn_arco();
	this.btn_arco.setTransform(147.7,441.4,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_arco, 0, 1, 2, false, new lib.btn_arco(), 3);

	this.btn_diametro = new lib.btn_diametro();
	this.btn_diametro.setTransform(147.7,373,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_diametro, 0, 1, 2, false, new lib.btn_diametro(), 3);

	this.btn_cuerda = new lib.btn_cuerda();
	this.btn_cuerda.setTransform(147.9,306,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_cuerda, 0, 1, 2, false, new lib.btn_cuerda(), 3);

	this.btn_radio = new lib.btn_radio();
	this.btn_radio.setTransform(147.7,238.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_radio, 0, 1, 2, false, new lib.btn_radio(), 3);

	this.btn_centro = new lib.btn_centro();
	this.btn_centro.setTransform(148,170.3,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_centro, 0, 1, 2, false, new lib.btn_centro(), 3);
  this.btn_centro.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
      this.btn_radio.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
      this.btn_cuerda.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
      this.btn_diametro.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
      this.btn_arco.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      this.btn_todos.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
      
    
this.instance = new lib.CdP_Elementos();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);

      this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance,this.btn_centro,this.btn_radio,this.btn_cuerda,this.btn_diametro,this.btn_arco,this.btn_todos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3'],"23px");
this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
        this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

	this.instance = new lib.CdP_DeUna();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.btn_exteriores,this.instance,this.btn_tangentes,this.btn_secantes);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3'],"23px");
this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores("single",2);
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
        this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

	this.instance = new lib.CdP_Exteriores_1();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);
    this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.btn_exteriores,this.instance,this.btn_tangentes,this.btn_secantes);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3'],"23px");
this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente("single",2);
	this.btn_tangentes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
        this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

	this.instance = new lib.CdP_Tangentes_1();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);
    this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.btn_exteriores,this.instance,this.btn_tangentes,this.btn_secantes);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3'],"23px");
this.btn_secantes = new lib.btn_secantes("single",2);
	this.btn_secantes.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
        this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

	this.instance = new lib.CdP_Secantes_1();
	this.instance.setTransform(636.3,336.7,1,1,0,0,0,200,200);
    this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.btn_exteriores,this.instance,this.btn_tangentes,this.btn_secantes);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores();
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas();
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.Circulo2();
	this.instance.setTransform(621,240.6);

	this.instance_1 = new lib.Circulo2();
	this.instance_1.setTransform(333,240.6);
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores();
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas();
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores("single",2);
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.CdP_Exteriores();
	this.instance.setTransform(571.7,341.5,1,1,0,0,0,250,150);

     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame5_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores();
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas();
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente("single",2);
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.CdP_Tangentes();
	this.instance.setTransform(571.7,341.5,1,1,0,0,0,250,150);

     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame5_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores();
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas();
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes("single",2);
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.CdP_Secantes();
	this.instance.setTransform(571.7,341.5,1,1,0,0,0,250,150);

     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame5_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores();
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas("single",2);
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.CdP_Concentricas();
	this.instance.setTransform(571.7,341.5,1,1,0,0,0,250,150);

     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame5_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.btn_interiores = new lib.btn_interiores("single",2);
	this.btn_interiores.setTransform(183.4,476.6,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_interiores, 0, 1, 2, false, new lib.btn_interiores(), 3);

	this.btn_concentricas = new lib.btn_Concentricas();
	this.btn_concentricas.setTransform(183.4,408.2,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_concentricas, 0, 1, 2, false, new lib.btn_Concentricas(), 3);

	this.btn_secantes = new lib.btn_secantes();
	this.btn_secantes.setTransform(183.6,341.2,1,1,0,0,0,72.7,15);
	new cjs.ButtonHelper(this.btn_secantes, 0, 1, 2, false, new lib.btn_secantes(), 3);

	this.btn_tangentes = new lib.btn_tangente();
	this.btn_tangentes.setTransform(183.4,273.8,1,1,0,0,0,72.5,15);
	new cjs.ButtonHelper(this.btn_tangentes, 0, 1, 2, false, new lib.btn_tangente(), 3);

	this.btn_exteriores = new lib.btn_exteriores();
	this.btn_exteriores.setTransform(183.7,205.5,1,1,0,0,0,72.8,15);
	new cjs.ButtonHelper(this.btn_exteriores, 0, 1, 2, false, new lib.btn_exteriores(), 3);
    this.btn_exteriores.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
    this.btn_tangentes.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
    this.btn_secantes.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
       this.btn_concentricas.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
    this.btn_interiores.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });

	this.instance = new lib.CdP_Interiores();
	this.instance.setTransform(571.7,341.5,1,1,0,0,0,250,150);

     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.instance_1,this.instance,this.btn_exteriores,this.btn_tangentes,this.btn_secantes,this.btn_concentricas,this.btn_interiores);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(60, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._01 = function() {
	this.initialize(img._01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,285,380);


(lib.Arco = function() {
	this.initialize(img.Arco);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Centro = function() {
	this.initialize(img.Centro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Circulo = function() {
	this.initialize(img.Circulo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Circulo2 = function() {
	this.initialize(img.Circulo2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,200,200);


(lib.Cuerda = function() {
	this.initialize(img.Cuerda);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Diametro = function() {
	this.initialize(img.Diametro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.MT_07_13_0901A = function() {
	this.initialize(img.MT_07_13_0901A);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.MT_07_13_0902 = function() {
	this.initialize(img.MT_07_13_0902);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,470,350);


(lib.MT_07_13_0902_Proba = function() {
	this.initialize(img.MT_07_13_0902_Proba);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,470,350);


(lib.MT_07_13_0903 = function() {
	this.initialize(img.MT_07_13_0903);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,347,350);


(lib.MT_07_13_0904 = function() {
	this.initialize(img.MT_07_13_0904);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,409,350);


(lib.MT_07_13_0905 = function() {
	this.initialize(img.MT_07_13_0905);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,300);


(lib.MT_07_13_0906 = function() {
	this.initialize(img.MT_07_13_0906);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,499,300);


(lib.MT_07_13_0907 = function() {
	this.initialize(img.MT_07_13_0907);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,297,300);


(lib.MT_07_13_0908 = function() {
	this.initialize(img.MT_07_13_0908);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,349,300);


(lib.MT_07_13_0909 = function() {
	this.initialize(img.MT_07_13_0909);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,302,300);


(lib.MT_07_13_0910 = function() {
	this.initialize(img.MT_07_13_0910);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,300);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.Radio = function() {
	this.initialize(img.Radio);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 8;
	this.text.setTransform(13.1,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape.setTransform(15,15.9,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(15,15.9,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,30,30.7);


(lib.CdP_Tangentes2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.MT_07_13_0907();
	this.instance.setTransform(322.7,56.3,0.6,0.6);

	this.instance_1 = new lib.MT_07_13_0906();
	this.instance_1.setTransform(8.8,56.1,0.6,0.6);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(8.8,56.1,492.2,180.2);


(lib.CdP_Secantes2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.MT_07_13_0908();
	this.instance.setTransform(113.8,27.6,0.8,0.8);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(113.8,27.6,279.2,240);


(lib.CdP_Interiores2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.MT_07_13_0910();
	this.instance.setTransform(113.8,26,0.8,0.8);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(113.8,26,240,240);


(lib.CdP_Exteriores2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.MT_07_13_0905();
	this.instance.setTransform(50,30,0.8,0.8);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(50,30,400,240);


(lib.CdP_Concentricas2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.MT_07_13_0909();
	this.instance.setTransform(113.8,47.6,0.8,0.8);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(113.8,47.6,241.6,240);


(lib.btn_tangente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Tangentes", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 141;
	this.text.setTransform(70.3,3.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.7,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.7,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.7,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.2,30);


(lib.btn_secantes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Secantes", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 140;
	this.text.setTransform(70.3,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_interiores = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Interiores", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 140;
	this.text.setTransform(70.3,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_exteriores = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Exteriores", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 141;
	this.text.setTransform(70.3,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.8,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.8,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.8,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,30);


(lib.btn_Concentricas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Concéntricas", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 140;
	this.text.setTransform(70.4,3.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.CdP_Tangentes2_1 = function() {
	this.initialize();

	// Capa 2
	this.instance_2 = new lib.MT_07_13_0903();
	this.instance_2.setTransform(-22,-13,1.01,1.01);

	this.addChild(this.instance_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-22,-13,350.5,353.5);


(lib.CdP_Secantes2_1 = function() {
	this.initialize();

	// Capa 1
	this.instance_1 = new lib.MT_07_13_0904();
	this.instance_1.setTransform(-34.3,-15.5,1.033,1.033);

	this.addChild(this.instance_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-34.3,-15.5,422.5,361.6);


(lib.CdP_Exteriores2_1 = function() {
	this.initialize();

	// Capa 1
	this.instance_1 = new lib.MT_07_13_0902();

	this.addChild(this.instance_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,470,350);


(lib.CdP_DeUna = function() {
	this.initialize();

	// Circulo
	this.instance = new lib.Circulo();
	this.instance.setTransform(-64.8,7.8,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-64.8,7.8,325,325);


(lib.btn_tangente_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text_1 = new cjs.Text("Tangentes", "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 141;
	this.text_1.setTransform(70.3,3.1+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_3.setTransform(72.7,15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_4.setTransform(72.7,15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_5.setTransform(72.7,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]}).to({state:[{t:this.shape_4},{t:this.text_1,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_5},{t:this.text_1,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.2,30);


(lib.btn_secantes_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text_1 = new cjs.Text("Secantes", "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 140;
	this.text_1.setTransform(70.3,3.2+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_3.setTransform(72.5,15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_4.setTransform(72.5,15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_5.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]}).to({state:[{t:this.shape_4},{t:this.text_1,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_5},{t:this.text_1,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_exteriores_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text_1 = new cjs.Text("Exteriores", "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 141;
	this.text_1.setTransform(70.3,3.2+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_3.setTransform(72.8,15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_4.setTransform(72.8,15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_5.setTransform(72.8,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]}).to({state:[{t:this.shape_4},{t:this.text_1,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_5},{t:this.text_1,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,30);


(lib.CdP_Radio2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Radio();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.CdP_Diametro2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Diametro();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.CdP_Cuerda2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Cuerda();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.CdP_Circunferencia = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Circulo();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.CdP_Circulo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Circulo();
	this.instance.setTransform(-11.8,3.4,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Centro2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Centro();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.CdP_Arco2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Arco();
	this.instance.setTransform(0,0,0.65,0.65);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325,325);


(lib.btn_radio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Radio", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 141;
	this.text.setTransform(70.5,3.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_elementos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Todos los elementos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 217;
	this.text.setTransform(109.1,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-111.25,-15.05,222.5,30.1,6);
	this.shape.setTransform(111.2,14.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-111.25,-15.05,222.5,30.1,6);
	this.shape_1.setTransform(111.2,14.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-111.25,-15.05,222.5,30.1,6);
	this.shape_2.setTransform(111.2,14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.1,222.5,30.1);


(lib.btn_diametro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Diámetro", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 140;
	this.text.setTransform(70.4,3.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_cuerda = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Cuerda", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 141;
	this.text.setTransform(70.3,3.1+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.7,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.7,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.7,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.2,30);


(lib.btn_centro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Centro", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 141;
	this.text.setTransform(70.3,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.8,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.8,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.8,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145.3,30);


(lib.btn_arco = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Arco", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 140;
	this.text.setTransform(70.3,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape.setTransform(72.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_1.setTransform(72.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-72.5,-15,145,30,6);
	this.shape_2.setTransform(72.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,145,30);


(lib.btn_una = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Posiciones relativas de una\nrecta y una circunferencia", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 265;
	this.text.setTransform(132.7,2.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape.setTransform(135,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_1.setTransform(135,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_2.setTransform(135,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,50);


(lib.btn_elementos_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text_1 = new cjs.Text("Elementos de la\ncircunferencia", "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 265;
	this.text_1.setTransform(132.7,3.1+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_3.setTransform(135,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_4.setTransform(135,25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_5.setTransform(135,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]}).to({state:[{t:this.shape_4},{t:this.text_1,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_5},{t:this.text_1,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_3},{t:this.text_1,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270,50);


(lib.btn_dedos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("Posiciones relativas de\ndos circunferencias", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 266;
	this.text.setTransform(132.9,2.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape.setTransform(135.2,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_1.setTransform(135.2,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-135,-25,270,50,6);
	this.shape_2.setTransform(135.2,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,270.2,50);


(lib.CdP_Tangentes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt2
	this.text = new cjs.Text("En el caso de las tangentes exteriores, la distancia –d- entre los centros es igual a la suma de los radios. En el de las interiores, la distancia –d- entre los centros es igual que la diferencia de los radios.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 566;
	this.text.setTransform(-22.1,242.4);
 var html = createDiv(txt['text12'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-22, 242-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},29).wait(1));

	// Txt1
	this.text_1 = new cjs.Text("Tangentes: las circunferencias tienen un solo punto en común. Pueden ser circunferencias tangentes exteriores o interiores.", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 567;
	this.text_1.setTransform(-22.1,-46.7);
      
  html = createDiv(txt['text11'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-22, -46-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},19).wait(11));

	// Capa 1
	this.instance = new lib.CdP_Tangentes2();
	this.instance.setTransform(232.4,139.6,1,1,0,0,0,250,150);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:254.8,regY:146.2,x:237.2,y:135.8,alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.8,45.7,492.2,180.2);


(lib.CdP_Secantes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt2
	this.text = new cjs.Text("La distancia –d- entre los centros es más pequeña que la suma de los radios y más grande que su diferencia.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 566;
	this.text.setTransform(-22.1,280.8);
var html = createDiv(txt['text14'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-22, 280-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},29).wait(1));

	// Txt1
	this.text_1 = new cjs.Text("Secantes: las circunferencias tienen dos puntos en común.", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 600;
	this.text_1.setTransform(-22.1,-46.7);
 html = createDiv(txt['text13'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-22, -46-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},19).wait(11));

	// Capa 1
	this.instance = new lib.CdP_Secantes2();
	this.instance.setTransform(232.4,139.6,1,1,0,0,0,250,150);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:253.3,regY:147.6,x:235.7,y:137.2,alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96.2,17.2,279.2,240);


(lib.CdP_Interiores = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt2
	this.text = new cjs.Text("La distancia -d- entre los centros es menor que la diferencia de los radios.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 566;
	this.text.setTransform(-22.1,287.2);
var html = createDiv(txt['text17'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-22, 287-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},29).wait(1));

	// Txt1
	this.text_1 = new cjs.Text("Interiores: no tienen punto de contacto y los centros no coinciden.", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 561;
	this.text_1.setTransform(-22.1,-46.7);
 html = createDiv(txt['text18'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-22, -46-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},19).wait(11));

	// Capa 1
	this.instance = new lib.CdP_Interiores2();
	this.instance.setTransform(232.4,150,1,1,0,0,0,250,150);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:233.7,regY:146,x:216.1,y:146,alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96.2,26,240,240);


(lib.CdP_Exteriores = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt2
	this.text = new cjs.Text("La distancia –d- entre los centros es más grande que la suma de los radios.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 543;
	this.text.setTransform(-22.1,280.8);
var html = createDiv(txt['text10'], "Verdana", "20px", '550px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-22, 280-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},29).wait(1));

	// Txt1
	this.text_1 = new cjs.Text("Exteriores: las circunferencias no se cortan, no tienen puntos en común.", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 566;
	this.text_1.setTransform(-22.1,-46.7);
        
  html = createDiv(txt['text9'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-22, -46-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},19).wait(11));

	// Capa 1
	this.instance = new lib.CdP_Exteriores2();
	this.instance.setTransform(232.4,139.6,1,1,0,0,0,250,150);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(32.4,19.6,400,240);


(lib.CdP_Concentricas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt2
	this.text = new cjs.Text(txt['text15'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 566;
	this.text.setTransform(-22.1,287.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},29).wait(1));

	// Txt1
	this.text_1 = new cjs.Text("Concéntricas: las circunferencias concéntricas tienen el mismo centro y distinto radio.", "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 561;
	this.text_1.setTransform(-22.1,-46.7);
  var html = createDiv(txt['text16'], "Verdana", "20px", '570px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-22, -46-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},19).wait(11));

	// Capa 1
	this.instance = new lib.CdP_Concentricas2();
	this.instance.setTransform(232.4,139.6,1,1,0,0,0,250,150);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:234.5,regY:167.6,x:216.9,y:157.2,alpha:0.091},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:1},0).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(96.2,37.2,241.6,240);


(lib.CdP_Tangentes_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text_2 = new cjs.Text("Tangentes: la recta y la circunferencia tienen un solo punto en común.", "bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 400;
	this.text_2.setTransform(-103.4,340.8);
var html = createDiv(txt['text7'], "Verdana", "20px", '400px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(-103, 340-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2}]},19).wait(1));

	// Capa 2
	this.instance_1 = new lib.CdP_Tangentes2_1();
	this.instance_1.setTransform(184.9,155,1.05,1.05,0,0,0,235.3,175);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:153.2,regY:163.6,x:98.7,y:143,alpha:0.053},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:1},0).wait(1));

	// Circulo
	this.instance_2 = new lib.Circulo();
	this.instance_2.setTransform(-64.8,7.8,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.2,-42.6,368,375.4);


(lib.CdP_Secantes_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text_2 = new cjs.Text("Secantes: la recta y la circunferencia \nse cortan en dos puntos.", "bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 417;
	this.text_2.setTransform(-111.4,340.8);
var html = createDiv(txt['text8'], "Verdana", "20px", '420px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(-111, 340-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2}]},19).wait(1));

	// Capa 2
	this.instance_1 = new lib.CdP_Secantes2_1();
	this.instance_1.setTransform(185,154.1,1.05,1.05,0,0,0,235.3,174.8);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:176.8,regY:165.2,x:123.6,y:144,alpha:0.053},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:1},0).wait(1));

	// Circulo
	this.instance_2 = new lib.Circulo();
	this.instance_2.setTransform(-64.8,7.8,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98.1,-45.8,443.6,379.6);


(lib.CdP_Exteriores_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text_2 = new cjs.Text("Exteriores: la recta y la circunferencia \nno se cortan, no tienen puntos en común.", "bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 445;
	this.text_2.setTransform(-118.6,340.8);
var html = createDiv(txt['text6'], "Verdana", "20px", '450px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(-118, 340-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2}]},19).wait(1));

	// Capa 2
	this.instance_1 = new lib.CdP_Exteriores2_1();
	this.instance_1.setTransform(183.8,155.4,1.045,1.045,0,0,0,235.3,174.8);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:235,regY:175,x:183.4,y:155.6,alpha:0.053},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:1},0).wait(1));

	// Circulo
	this.instance_2 = new lib.Circulo();
	this.instance_2.setTransform(-64.8,7.8,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.8,-27.2,493.9,365.8);


(lib.CdP_Radiocopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.CdP_Radio2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Radio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text = new cjs.Text("Radio: es un segmento que une el centro con un punto cualquiera de la circunferencia.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 456;
	this.text.setTransform(-76.2,335.8);
 var html = createDiv(txt['text2'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-76, 335-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(1));

	// Capa 2
	this.instance = new lib.CdP_Radio2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Circulo();
	this.instance_1.setTransform(-11.8,3.4,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Diametrocopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.CdP_Diametro2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Diametro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text = new cjs.Text("Diámetro: es una cuerda que pasa por el centro de la circunferencia.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 497;
	this.text.setTransform(-76.2,335.8);
 var html = createDiv(txt['text4'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-76, 335-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(1));

	// Capa 2
	this.instance = new lib.CdP_Diametro2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Circulo();
	this.instance_1.setTransform(-11.8,3.4,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Cuerdacopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.CdP_Cuerda2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Cuerda = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text = new cjs.Text("Cuerda: es un segmento que une dos puntos de la circunferencia.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 461;
	this.text.setTransform(-76.2,335.8);
 var html = createDiv(txt['text3'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-76, 335-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(1));

	// Capa 2
	this.instance = new lib.CdP_Cuerda2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Circulo();
	this.instance_1.setTransform(-11.8,3.4,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Centrocopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.CdP_Centro2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Centro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text = new cjs.Text("Centro: es el punto del cual equidistan todos los puntos que la conforman.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 462;
	this.text.setTransform(-79.8,335.8);
  var html = createDiv(txt['text1'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-80, 335-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(1));

	// Capa 2
	this.instance = new lib.CdP_Centro2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Circulo();
	this.instance_1.setTransform(-11.8,3.4,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Arcocopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.CdP_Arco2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Arco = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.text = new cjs.Text("Arco: es la parte de la circunferencia comprendida entre dos de sus puntos.", "bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 520;
	this.text.setTransform(-86.1,335.8);
 var html = createDiv(txt['text5'], "Verdana", "20px", '530px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(-86, 335-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(1));

	// Capa 2
	this.instance = new lib.CdP_Arco2();
	this.instance.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.063},0).wait(1).to({alpha:0.125},0).wait(1).to({alpha:0.188},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.313},0).wait(1).to({alpha:0.375},0).wait(1).to({alpha:0.438},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.563},0).wait(1).to({alpha:0.625},0).wait(1).to({alpha:0.688},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.813},0).wait(1).to({alpha:0.875},0).wait(1).to({alpha:0.938},0).wait(1).to({alpha:1},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Circulo();
	this.instance_1.setTransform(-11.8,3.4,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325,325);


(lib.CdP_Elementos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 6
	this.instance = new lib.CdP_Arcocopia();
	this.instance.setTransform(162.6,162.7,1,1,0,0,0,162.5,162.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(65).to({_off:false},0).wait(1));

	// Capa 5
	this.instance_1 = new lib.CdP_Diametrocopia();
	this.instance_1.setTransform(162.6,162.7,1,1,0,0,0,162.5,162.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49).to({_off:false},0).wait(17));

	// Capa 4
	this.instance_2 = new lib.CdP_Cuerdacopia();
	this.instance_2.setTransform(162.6,162.7,1,1,0,0,0,162.5,162.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(33).to({_off:false},0).wait(33));

	// Capa 3
	this.instance_3 = new lib.CdP_Radiocopia();
	this.instance_3.setTransform(162.6,162.7,1,1,0,0,0,162.5,162.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).wait(49));

	// Capa 2
	this.instance_4 = new lib.CdP_Centrocopia();
	this.instance_4.setTransform(162.6,162.7,1,1,0,0,0,162.5,162.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(66));

	// Capa 1
	this.instance_5 = new lib.CdP_Circunferencia();
	this.instance_5.setTransform(150.6,165.9,1,1,0,0,0,162.5,162.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).wait(66));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.8,3.4,325.1,325.2);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}