Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		this.lVariaciones=new Array();
	
		this.lEnunciados_STRING=new Array();
		this.lEnunciados_SPRITE=new Array();
		this.llRespuestas_SPRITE=new Array();
		this.lIndicesOK_INT=new Array();
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		var nAux,rr;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var a1,an;
		var lOrdinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lCardinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			
			switch(modelo){
				case 0:
					a1=Random.integer(5,12);
                    d=Random.integer(3,9);
                    n=Random.integer(8,15);
                    this.enun=this.enun.replace('AAA',JL.num2str(n,-1));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,-1));
                    i=Random.integer(3,6);
                    this.enun=this.enun.replace('AAA',['tercero','cuarto','quinto','sexto'][i-3]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+d*(i-1),-1));
                    an=a1+(n-1)*d;
                    resp=(a1+an)*n/2;
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 1:
					a1=Random.integer(5,12);
                    d=Random.integer(3,9);
                    n=Random.integer(8,15);
                    an=a1+(n-1)*d;
                    s=(a1+an)*n/2;
                    this.enun=this.enun.replace('AAA',lOrdinales[n]);
                    this.enun=this.enun.replace('AAA',JL.num2str(s,-1));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,-1));
                    resp=d;
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[2,12]);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 2:
					d=Random.integer(3,49);
                    a1=Random.integer(2,49);
                    i=Random.integer(3,6);
                    this.enun=this.enun.replace('AAA',['tercero','cuarto','quinto','sexto'][i-3]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(i-1)*d,-1));
                    j=Random.integer(3,7);
                    this.enun=this.enun.replace('AAA',JL.num2str(j,-1));
                    this.enun=this.enun.replace(      'AAA',JL.num2str(    (a1+a1+(j-1)*d)*j/2,-1      )       );
                    resp=a1;
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[2,3*resp]);
					nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 3:
					d=Random.integer(3,49);
                    a1=Random.integer(2,49);
                    n=Random.integer(5,12);
                    an=a1+(n-1)*d;
                    s=(a1+an)*n/2;
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(n,0));
                    resp=s;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 4:
					d=Random.integer(11,49);
                    a1=Random.integer(51,99);
                    i=Random.integer(4,9);
                    this.enun=this.enun.replace('AAA',JL.num2str(2*a1+d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(d,0));
                    this.enun=this.enun.replace('AAA',['cuarto','quinto','sexto','séptimo','octavo','noveno'][i-4]);
                    resp=a1+(i-1)*d;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 5:
					d=Random.integer(11,49);
                    a1=Random.integer(51,99);
                    i=Random.integer(5,9);
                    this.enun=this.enun.replace('AAA',['quinto','sexto','séptimo','octavo','noveno'][i-5]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(i-1)*d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(i-1)*d+d,0));
                    resp=a1*(a1+d);
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 6:
				//console.log(this.enun);
					a=Random.integer(11,49);
                    d=Random.integer(11,29,[a]);
                    this.enun=this.enun.replace('AAA',JL.num2str(2*a+d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(d,0));
                    resp=a;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 7:
					a=Random.integer(123,299);
                    d=Random.integer(31,99);
                    this.enun=this.enun.replace('AAA',JL.num2str(2*a+d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(2*a-d,0));
                    resp=d;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 8:
					a1=Random.integer(3,15);
                    d=Random.integer(4,9);
                    
                    i=Random.integer(2,5);
                    j=Random.integer(i+2,9);
                    k=Random.integer(11,49);
                    s=(a1+a1+(k-1)*d)*k/2;
                    
                    this.enun=this.enun.replace('AAA',['segundo','tercer','cuarto','quinto'][i-2]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(i-1)*d,0));
                    this.enun=this.enun.replace('AAA',['cuarto','quinto','sexto','séptimo','octavo','noveno'][j-4]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(j-1)*d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(s,0));
                    resp=k;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 9:
					a1=Random.integer(6,25);
                    d=Random.integer(11,39);
                    i=Random.integer(5,9);
                    this.enun=this.enun.replace('AAA',['quinto','sexto','séptimo','octavo','noveno'][i-5]);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1+(i-2)*d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    resp=d;
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
			
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=r.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}