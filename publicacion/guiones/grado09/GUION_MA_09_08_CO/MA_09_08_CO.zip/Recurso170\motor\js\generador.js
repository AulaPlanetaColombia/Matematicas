Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,"#000000",false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		var nAux,rr;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var a1,an;
		var lCardinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lOrdinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(modelo){
				case 0:
					d=Random.integer(2,9);
                    n=Random.integer(3,9);
                    q=Random.integer(2,3);
                    m=n+q;
                    an=Random.integer(100,300);

                    am=an*Math.pow(d,q+1);
                    this.enun=this.enun.replace('AAA',JL.num2str(an, -1));
                    this.enun=this.enun.replace('AAA',JL.num2str(am, -1));
                    this.enun=this.enun.replace('AAA',JL.num2str(q, -1));
                    resp=d;
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[2,9]);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 1:
					a1=Random.integer(7,18);
                    dd=Random.integer(2,9);
                    q=Random.integer(3,6);
                    an=a1*Math.pow(dd,q+1);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1, -1));
                    this.enun=this.enun.replace('AAA',JL.num2str(an, -1));
                    this.enun=this.enun.replace('AAA',JL.num2str(dd, -1));
                    resp=q;
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[1,resp+6]);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 2:
					a1=Random.integer(7,18);
                    dd=Random.integer(12,88)/100;
                    q=Random.integer(2,5);
                    an=a1*Math.pow(dd,q+1);
                    this.enun=this.enun.replace('AAA',JL.num2str(a1, -1));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(an,5)));
                    this.enun=this.enun.replace('AAA',JL.num2str(q, -1));
                    resp=a1/(1-dd);
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[1,resp+6]);
					nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
				case 3:
					a1=Random.integer(3,9);
                    rr=Random.integer(11,29,[20])/10;
                    i=Random.integer(3,7);
                    aa=a1*Math.pow(rr,i-1);
                    j=i+Random.integer(3,7);
                    bb=a1*Math.pow(rr,j-1);
                    n=Random.integer(3,5);
                    resp=Math.sqrt(Math.pow(a1*a1*Math.pow(rr,n-1),n));
                    this.enun=this.enun.replace('AAA',lOrdinales[i]);
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(aa,3)));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(bb,3)));
                    this.enun=this.enun.replace('AAA',JL.num2str(j-i-1,0));
                    this.enun=this.enun.replace('AAA',lCardinales[n]);
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 4:
					a1=Random.integer(7,18);
                    rr=Random.integer(2,6);
                    i=Random.integer(3,7);
                    aa=a1*Math.pow(rr,i-1);
                    j=Random.integer(3,4);
                    k=j+Random.integer(2,5);
                    bb=a1*Math.pow(rr,j-1);
                    cc=a1*Math.pow(rr,k-1);
                    resp=k-j-1;
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    this.enun=this.enun.replace('AAA',lOrdinales[i]);
                    this.enun=this.enun.replace('AAA',JL.num2str(aa,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(bb,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(cc,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1,[1,12]);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 5:
					a1=Random.integer(234,489);
                    rr=Random.integer(5,9)/10;
                    ss=a1/(1-rr);
                    i=Random.integer(3,7);
                    aa=a1*Math.pow(rr,i-1);
                    j=i+Random.integer(2,5);
                    bb=a1*Math.pow(rr,j-1);
                    resp=j-i-1;
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(ss,2)));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(aa,1)));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(bb,1)));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1,[1,12]);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 6:
					a=Random.integer(11,49);
                    a1=Random.integer(512,987);
                    rr=Random.integer(2,7)/10;
                    i=Random.integer(3,7);
                    aa=a1*Math.pow(rr,i-1);
                    j=i+Random.integer(3,5);
                    bb=a1*Math.pow(rr,j-1);
                    ss=a1/(1-rr);
                    resp=a1;
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(aa,3)));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(bb,3)));
                    this.enun=this.enun.replace('AAA',JL.num2str(j-i-1,0));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(ss,3)));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 7:
					a1=Random.integer(3,7);
                    rr=Random.integer(2,6);
                    nn=Random.integer(2,4);
                    pp=Math.sqrt(Math.pow(a1*a1*Math.pow(rr,nn-1),nn));
                    i=Random.integer(2,5);
                    aa=a1*Math.pow(rr,i-1);
                    j=i+Random.integer(2,5);
                    bb=a1*Math.pow(rr,j-1);
                    resp=j-i-1;
                    this.enun=this.enun.replace('AAA',lCardinales[nn]);
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(pp,3)));
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(aa,3)));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(bb,3)));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1,[1,15]);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 8:
					a1=Random.integer(3,9);
                    rr=Random.integer(2,5);
                    nn=Random.integer(4,6);
                    aa=a1*Math.pow(rr,nn-1);
                    j=Random.integer(4,6,[nn]);
                    k=j+Random.integer(2,3);
                    bb=a1*Math.pow(rr,j-1);
                    cc=a1*Math.pow(rr,k-1);
                    resp=k-j-1;
                    this.enun=this.enun.replace('AAA',JL.num2str(a1,0));
                    this.enun=this.enun.replace('AAA',lOrdinales[nn]);
                    this.enun=this.enun.replace('AAA',JL.num2str(aa,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(bb,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(cc,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1,[1,9]);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 9:
					a1=Random.integer(256,654);
                    rr=Random.integer(105,114)/100;
                    i=Random.integer(4,8);
                    aa=a1*Math.pow(rr,i-1);
                    j=i+Random.integer(3,8);
                    bb=a1*Math.pow(rr,j-1);
                    resp=j-i-1;
                    this.enun=this.enun.replace('AAA',JL.num2str(rr,2));
                    this.enun=this.enun.replace('AAA',JL.num2str(aa,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(bb,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1,[1,9]);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=r.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}