Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar();
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		var nAux,rr;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var a1,an;
		var lCardinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lOrdinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		this.enun = Motor.lEnunciados[modelo];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(modelo){
				case 0:
					c=Random.integer(240,560);
                    d=Random.integer(24,54);
                    this.enun=this.enun.replace('AAA',JL.num2str(d,-1));
                    this.enun=this.enun.replace('AAA',JL.num2str(c,-1));
                    resp=Math.ceil(c/d-1);
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1,[2,12]);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
				break;
			    case 1:
					a=Random.integer(186,278);
                    b=a + Random.integer(15,35);
                    k = Random.integer(65,145);
                    resp = 1000*(b-a)/(k+1);
                    this.enun=this.enun.replace('AAA',JL.num2str(a,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(b,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(k,0));
                    
                    this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1);
                    //this.lAlternativas=this.getAlternativas(resp,0,this.qAlternativas-1);
                    nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na] +' m';}
				break;
				case 2:
					nAux=Random.integer(161,399)/10;
                    q=Random.integer(5,12);
                    resp=nAux/q;
                    this.enun=this.enun.replace('AAA',JL.num2str(nAux,1));
                    this.enun=this.enun.replace('AAA',JL.num2str(q,0));
                    this.lAlternativas=this.getAlternativas(resp,2,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
                    for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na] +' m';}
				break;
				case 3:
					while(true){
                        l=Random.integer(445,789);
                        d=Random.integer(12,29);
                        n=Math.floor(l/d-1);
                        nAux=l/(n+1);
                        a=Random.integer(5,12);
                        resp=n-a;
                        if(resp>0){
                            break
                        }
                    }
                    this.enun=this.enun.replace('AAA',JL.num2str(l,0));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(nAux,2)));
                    this.enun=this.enun.replace('AAA',JL.num2str(a,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 4:
					m=Random.integer(4,9);
                    n=Random.integer(3,9);
                    i=Random.integer(5,12);
                    resp=n - 1;
                    this.enun=this.enun.replace('AAA',JL.num2str(m*i,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(m*i+m*n,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(m,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 5:
					l=Random.integer(1234,2678);
                    d=Random.integer(8,34);
                    n=Math.floor(l/d-1);
                    nAux=l/(n+1);
                    resp=2*n;
                    this.enun=this.enun.replace('AAA',JL.num2str(l,0));
                    this.enun=this.enun.replace('AAA',JL.quitarCerosDec(JL.num2str(nAux,2)));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 6:
					n=Random.integer(11,29);
                    d=Random.integer(5,12);
                    i=Random.integer(123,789);
                    s=i+(n+1)*d;
                    resp=i;
                    this.enun=this.enun.replace('AAA',JL.num2str(n,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(d,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(s,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 7:
					d=Random.integer(8,19);
                    n=Random.integer(10,25);
                    l=(n+1)*d;
                    resp=d;
                    this.enun=this.enun.replace('AAA',JL.num2str(l/10,1));
                    this.enun=this.enun.replace('AAA',JL.num2str(n,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na] +' mm';}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 8:
					d=Random.integer(11,39);
                    n=Random.integer(16,36);
                    a=Random.integer(251,987);
                    resp=n;
                    sAux=String(a)+', . . . , '+JL.num2str(a+(n+1)*d,0)+', '+JL.num2str(a+(n+2)*d,0);
                    this.enun=this.enun.replace('AAA',sAux);
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
				case 9:
					d=Random.integer(8,19);
                    a=Random.integer(61,99);
                    m=Random.integer(15,35);
                    b=a+(m+1)*d;
                    n=Random.integer(15,35,[m]);
                    c=b+(n+1)*d;
                    resp=n;
                    sAux=String(a)+', . . . , '+JL.num2str(b,0)+', . . . , '+JL.num2str(c,0);
                    this.enun=this.enun.replace('AAA',sAux);
                    this.enun=this.enun.replace('AAA',JL.num2str(m,0));
					this.lAlternativas=this.getAlternativas (resp,0,this.qAlternativas-1);
					nOK=this.lAlternativas[1];
					for(na=0;na<this.qAlternativas;na++){lSP_alts[na] = this.lAlternativas[0][na];}
					//for(na=0;na<this.qAlternativas;na++){EA.adc(this.lAlternativas[0][na],lSP_alts[na])}
				break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
			
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=nOK;
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;

		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v,-1));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok,-1);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					var np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			
			var bCercanos=false;
			//console.log(lWork);
			for(var j = 0;j<qAlt;j++){
				for(var k = j+1;k<qAlt+1;k++){
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			//console.log("if"+bCercanos);			
			if(!bCercanos){
				//console.log(lWork);
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}