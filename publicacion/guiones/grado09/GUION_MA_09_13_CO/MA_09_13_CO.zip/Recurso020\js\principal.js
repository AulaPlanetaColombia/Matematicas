(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,0,0,0,0);
        titulo1(this,txt['f1_01']);

        this.btn_03 = new lib.btn_03();
        this.btn_03.setTransform(198.7,396.6,1,1,0,0,0,108.7,40.4);
        new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_03(), 3);
        this.btn_03.on("click", function (evt) {
          putStage(new lib.frame14());
        });

        this.btn_02 = new lib.btn_02();
        this.btn_02.setTransform(188.9,306.4,1,1,0,0,0,99.1,40.2);
        new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_02(), 3);
        this.btn_02.on("click", function (evt) {
          putStage(new lib.frame8());
        });

        this.btn_04 = new lib.btn_04();
        this.btn_04.setTransform(188.7,474.7,1,1,0,0,0,98.9,28);
        new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_04(), 3);
        this.btn_04.on("click", function (evt) {
          putStage(new lib.frame20());
        });

        this.btn_01 = new lib.btn_01();
        this.btn_01.setTransform(188.9,203.5,1,1,0,0,0,98.9,28);
        new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);
        this.btn_01.on("click", function (evt) {
          putStage(new lib.frame2());
        });
        
        this.instance_1 = new lib._1_shutterstock_48807301();
        this.instance_1.setTransform(376.8,152,0.5,0.5);
  
        this.addChild(this.logo,this.titulo,this.instance_1,this.text,this.btn_01,this.btn_04,this.btn_02,this.btn_03,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    
    (lib.frame2 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,0,1,0,0);
        titulo1(this,txt['f2_01']);
        
        this.instance_1 = new lib.mc_p0();
        this.instance_1.setTransform(473.9,339.6,1,1,0,0,0,250.3,187.5);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame3());
        });
        
        this.addChild(this.logo,this.home,this.siguiente,this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this,txt['f3_01']);
        
        var html = document.createElement('img');
        html.src = "images/interseccion.gif";
        html.id="interseccion";
        document.body.appendChild(html);
        this.instance_2= new cjs.DOMElement(html);
        this.instance_2.setTransform(-850,130);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame4());
        });

        this.addChild(this.logo,this.home,this.anterior,this.siguiente,this.titulo,this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this,txt['f4_01']);
        
        this.instance_1 = new lib.mc_p2();
        this.instance_1.setTransform(82.1,152.9);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame5());
        });

        this.addChild(this.logo,this.home,this.anterior,this.siguiente,this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame5 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this,txt["f5_01"]);

   this.instance_1 = new lib.mc_p3();
        this.instance_1.setTransform(460.6,268.2,1,1,0,0,0,185.1,18.8);
     

               this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame6());
        });

        this.addChild(this.logo,this.home,this.anterior,this.siguiente,this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame6 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,0,1,0);
        titulo2(this, txt["f6_01"]);

        /*this.btn_info_01 = new lib.btn_info();
        this.btn_info_01.setTransform(173,555);
        new cjs.ButtonHelper(this.btn_info_01, 0, 1, 2, false, new lib.btn_info(), 3);*/

        this.instance_1 = new lib.mc_p4();
        this.instance_1.setTransform(462.7,283.6,1,1,0,0,0,92.1,17.2);
        
        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame5());
        });
        this.informacion.on("click", function (evt) {
          putStage(new lib.frame7());
        });

        this.addChild(this.logo,this.home,this.anterior,this.informacion,this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame7 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,0,0,0,1);
        texto(this,txt['f7_01'],0,0);
        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame6());
        });

        this.addChild(this.logo,this.cerrar,this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame8 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,0,1,0,0);
        titulo1(this, txt["f8_01"]);

        this.instance_1 = new lib.mc_f0();
        this.instance_1.setTransform(476.1,340.1,1,1,0,0,0,199.3,187.5);
        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame9());
        });

        this.addChild(this.logo,this.home,this.siguiente,this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame9 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f9_01"]);
        
	this.instance_1 = new lib.dice();
	this.instance_1.setTransform(475,370.4,1.401,1.401);

	
  
        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame8());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame10());
        });

        this.addChild(this.instance_1,this.instance_2,this.logo,this.home,this.anterior,this.siguiente,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    
    (lib.frame10 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f10_01"]);
        
        this.instance_1 = new lib.mc_f2();
        this.instance_1.setTransform(535.5,339.4,1,1,0,0,0,334.3,187.5);
  
        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame9());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame11());
        });

        this.addChild(this.instance_1,this.logo,this.home,this.anterior,this.siguiente,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame11 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt["f11_01"]);
        
        this.btn_practica = new lib.btn_practica();
        this.btn_practica.setTransform(832.2,574.9);
        new cjs.ButtonHelper(this.btn_practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.btn_practica.on("click", function (evt) {
          putStage(new lib.frame12());
        });
        
        this.mc_f3 = new lib.mc_f3();
        this.mc_f3.setTransform(359.8,218.9);
  
        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame10());
        });

        this.addChild(this.mc_f3,this.logo,this.home,this.anterior,this.btn_practica,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame12 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,0,0,0,1);
        titulo2(this, txt["f12_01"]);

        this.btn_solucion = new lib.btn_solucion();
        this.btn_solucion.setTransform(832.2,574.4);
        new cjs.ButtonHelper(this.btn_solucion, 0, 1, 2, false, new lib.btn_solucion(), 3);
        this.btn_solucion.on("click", function (evt) {
          putStage(new lib.frame13());
        });
        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame11());
        });

        this.addChild(this.logo,this.cerrar,this.titulo, this.btn_solucion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame13 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,1,0,0,1);
        parrafo(this, txt["f13_01"], "22px", 65, -480);

        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame11());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame12());
        });

        this.addChild(this.logo,this.cerrar,this.texto, this.anterior);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame14 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,0,1,0,0);
        titulo1(this, txt["f14_01"]);
        
        this.instance_1 = new lib.mc_h0();
        this.instance_1.setTransform(475.2,339.3,1,1,0,0,0,337.5,187.5);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame15());
        });

        this.addChild(this.logo,this.home, this.siguiente, this.titulo, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame15 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f15_01"]);
         var html = document.createElement('img');
        html.src = "images/interseccion2.gif";
        html.id="interseccion";
        document.body.appendChild(html);
        this.instance_2= new cjs.DOMElement(html);
        this.instance_2.setTransform(-850,160,0.9,0.9);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame14());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame16());
        });

        this.addChild(this.logo,this.home, this.siguiente, this.titulo, this.anterior, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame16 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        if (isbq)
        titulo2(this, txt["f16_01bq"]);
        else
                    titulo2(this, txt["f16_01"]);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AhVBhIAagiQgMgMgHgRQgHgQAAgSQAAgpAXgXQAXgXAngBQANAAALADQALACAKAFIANgSIAYAAIgWAeQAMALAHARQAHAQAAAWQAAAmgXAXQgXAXgoABQgLAAgMgEQgMgCgJgGIgSAYgAgXAtQAFAFAGABQAGADAGAAQAIAAAIgDQAIgEAFgGQAHgIADgLQADgLAAgLIgCgTIgEgQgAgOg2QgHACgHAIQgGAGgDALQgEALAAAQQAAAIACAIQABAJADAGIA7hQQgGgEgGgCQgGgCgGAAQgHAAgHADg");
        this.shape.setTransform(491.1,101.1,1,1,0,0,180);

        this.instance_1 = new lib.mc_h2();
        this.instance_1.setTransform(464.9,269.5,1,1,0,0,0,217.6,20);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame15());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame17());
        });

        this.addChild(this.logo,this.home, this.siguiente, this.titulo, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame17 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f17_01"]);

	this.instance_1 = new lib.mc_h3();
	this.instance_1.setTransform(466.2,317.6,1,1,0,0,0,349.2,166.3);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame16());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame18());
        });

        this.addChild(this.logo,this.home, this.siguiente, this.titulo, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame18 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,0,1,0);
        titulo2(this, txt["f18_01"]);

	this.instance_1 = new lib.mc_h4();
	this.instance_1.setTransform(474.8,268.8,1,1,0,0,0,195.4,19.1);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame17());
        });
        this.informacion.on("click", function (evt) {
          putStage(new lib.frame19());
        });

        this.addChild(this.logo,this.home, this.informacion, this.titulo, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame19 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,0,0,0,1);
        titulo2(this, txt["f19_01"]);
        this.instance = new lib.mc_popup2();
        this.instance.setTransform(470.1,304.8,1,1,0,0,0,87.5,10.7);
        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame18());
        });

        this.addChild(this.logo,this.cerrar, this.titulo,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.mc_popup2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhuH2IAAvrIClAAIAAPrg");
	var mask_graphics_1 = new cjs.Graphics().p("AhlH2IAAvrIDLAAIAAPrg");
	var mask_graphics_2 = new cjs.Graphics().p("Ah4H2IAAvrIDxAAIAAPrg");
	var mask_graphics_3 = new cjs.Graphics().p("AiLH1IAAvpIEXAAIAAPpg");
	var mask_graphics_4 = new cjs.Graphics().p("AieH1IAAvpIE9AAIAAPpg");
	var mask_graphics_5 = new cjs.Graphics().p("AixH1IAAvpIFjAAIAAPpg");
	var mask_graphics_6 = new cjs.Graphics().p("AjEH1IAAvpIGJAAIAAPpg");
	var mask_graphics_7 = new cjs.Graphics().p("AjXH1IAAvpIGvAAIAAPpg");
	var mask_graphics_8 = new cjs.Graphics().p("AjqH0IAAvnIHVAAIAAPng");
	var mask_graphics_9 = new cjs.Graphics().p("Aj9H0IAAvnIH7AAIAAPng");
	var mask_graphics_10 = new cjs.Graphics().p("AkPH0IAAvnIIfAAIAAPng");
	var mask_graphics_11 = new cjs.Graphics().p("AkiH0IAAvnIJFAAIAAPng");
	var mask_graphics_12 = new cjs.Graphics().p("Ak1H0IAAvnIJrAAIAAPng");
	var mask_graphics_13 = new cjs.Graphics().p("AlIHzIAAvlIKRAAIAAPlg");
	var mask_graphics_14 = new cjs.Graphics().p("AlbHzIAAvlIK3AAIAAPlg");
	var mask_graphics_15 = new cjs.Graphics().p("AluHzIAAvlILdAAIAAPlg");
	var mask_graphics_16 = new cjs.Graphics().p("AmBHzIAAvlIMDAAIAAPlg");
	var mask_graphics_17 = new cjs.Graphics().p("AmUHzIAAvlIMpAAIAAPlg");
	var mask_graphics_18 = new cjs.Graphics().p("AmnHyIAAvjINPAAIAAPjg");
	var mask_graphics_19 = new cjs.Graphics().p("Am6HyIAAvjIN1AAIAAPjg");
	var mask_graphics_20 = new cjs.Graphics().p("AnNHyIAAvjIObAAIAAPjg");
	var mask_graphics_21 = new cjs.Graphics().p("AngHyIAAvjIPBAAIAAPjg");
	var mask_graphics_22 = new cjs.Graphics().p("AnzHyIAAvjIPnAAIAAPjg");
	var mask_graphics_23 = new cjs.Graphics().p("AoGHxIAAvhIQNAAIAAPhg");
	var mask_graphics_24 = new cjs.Graphics().p("AoZHxIAAvhIQzAAIAAPhg");
	var mask_graphics_25 = new cjs.Graphics().p("AosHxIAAvhIRZAAIAAPhg");
	var mask_graphics_47 = new cjs.Graphics().p("AosHxIAAvhIRZAAIAAPhg");
	var mask_graphics_48 = new cjs.Graphics().p("Ao6HxIAAvhIR1AAIAAPhg");
	var mask_graphics_49 = new cjs.Graphics().p("ApIHxIAAvhISRAAIAAPhg");
	var mask_graphics_50 = new cjs.Graphics().p("ApWHxIAAvhIStAAIAAPhg");
	var mask_graphics_51 = new cjs.Graphics().p("ApkHxIAAvhITJAAIAAPhg");
	var mask_graphics_52 = new cjs.Graphics().p("ApyHxIAAvhITlAAIAAPhg");
	var mask_graphics_53 = new cjs.Graphics().p("AqAHxIAAvhIUBAAIAAPhg");
	var mask_graphics_54 = new cjs.Graphics().p("AqNHxIAAvhIUbAAIAAPhg");
	var mask_graphics_55 = new cjs.Graphics().p("AqbHxIAAvhIU3AAIAAPhg");
	var mask_graphics_56 = new cjs.Graphics().p("AqpHxIAAvhIVTAAIAAPhg");
	var mask_graphics_57 = new cjs.Graphics().p("Aq3HxIAAvhIVvAAIAAPhg");
	var mask_graphics_58 = new cjs.Graphics().p("ArFHxIAAvhIWLAAIAAPhg");
	var mask_graphics_59 = new cjs.Graphics().p("ArTHxIAAvhIWnAAIAAPhg");
	var mask_graphics_60 = new cjs.Graphics().p("ArhHxIAAvhIXDAAIAAPhg");
	var mask_graphics_61 = new cjs.Graphics().p("ArvHxIAAvhIXfAAIAAPhg");
	var mask_graphics_62 = new cjs.Graphics().p("Ar9HxIAAvhIX7AAIAAPhg");
	var mask_graphics_63 = new cjs.Graphics().p("AsLHxIAAvhIYXAAIAAPhg");
	var mask_graphics_64 = new cjs.Graphics().p("AsZHxIAAvhIYzAAIAAPhg");
	var mask_graphics_65 = new cjs.Graphics().p("AsnHxIAAvhIZPAAIAAPhg");
	var mask_graphics_66 = new cjs.Graphics().p("As1HxIAAvhIZrAAIAAPhg");
	var mask_graphics_67 = new cjs.Graphics().p("AtDHxIAAvhIaHAAIAAPhg");
	var mask_graphics_68 = new cjs.Graphics().p("AtRHxIAAvhIajAAIAAPhg");
	var mask_graphics_69 = new cjs.Graphics().p("AtfHxIAAvhIa/AAIAAPhg");
	var mask_graphics_70 = new cjs.Graphics().p("AttHxIAAvhIbbAAIAAPhg");
	var mask_graphics_71 = new cjs.Graphics().p("At7HxIAAvhIb3AAIAAPhg");
	var mask_graphics_72 = new cjs.Graphics().p("AuJHxIAAvhIcTAAIAAPhg");
	var mask_graphics_73 = new cjs.Graphics().p("AuXHxIAAvhIcvAAIAAPhg");
	var mask_graphics_74 = new cjs.Graphics().p("AulHxIAAvhIdLAAIAAPhg");
	var mask_graphics_75 = new cjs.Graphics().p("AuzHxIAAvhIdnAAIAAPhg");
	var mask_graphics_76 = new cjs.Graphics().p("AvBHxIAAvhIeDAAIAAPhg");
	var mask_graphics_77 = new cjs.Graphics().p("AvPHxIAAvhIefAAIAAPhg");
	var mask_graphics_78 = new cjs.Graphics().p("AvdHxIAAvhIe7AAIAAPhg");
	var mask_graphics_79 = new cjs.Graphics().p("AvqHxIAAvhIfVAAIAAPhg");
	var mask_graphics_80 = new cjs.Graphics().p("Av4HxIAAvhIfxAAIAAPhg");
	var mask_graphics_81 = new cjs.Graphics().p("AwGHxIAAvhMAgNAAAIAAPhg");
	var mask_graphics_82 = new cjs.Graphics().p("AwUHxIAAvhMAgpAAAIAAPhg");
	var mask_graphics_83 = new cjs.Graphics().p("AwiHxIAAvhMAhFAAAIAAPhg");
	var mask_graphics_84 = new cjs.Graphics().p("AwwHxIAAvhMAhhAAAIAAPhg");
	var mask_graphics_85 = new cjs.Graphics().p("Aw+HxIAAvhMAh9AAAIAAPhg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-11.1,y:39.1}).wait(1).to({graphics:mask_graphics_1,x:-12,y:39.1}).wait(1).to({graphics:mask_graphics_2,x:-10.1,y:39.1}).wait(1).to({graphics:mask_graphics_3,x:-8.2,y:39}).wait(1).to({graphics:mask_graphics_4,x:-6.3,y:39}).wait(1).to({graphics:mask_graphics_5,x:-4.4,y:39}).wait(1).to({graphics:mask_graphics_6,x:-2.5,y:39}).wait(1).to({graphics:mask_graphics_7,x:-0.6,y:39}).wait(1).to({graphics:mask_graphics_8,x:1.2,y:38.9}).wait(1).to({graphics:mask_graphics_9,x:3.1,y:38.9}).wait(1).to({graphics:mask_graphics_10,x:5,y:38.9}).wait(1).to({graphics:mask_graphics_11,x:6.8,y:38.9}).wait(1).to({graphics:mask_graphics_12,x:8.7,y:38.9}).wait(1).to({graphics:mask_graphics_13,x:10.6,y:38.8}).wait(1).to({graphics:mask_graphics_14,x:12.5,y:38.8}).wait(1).to({graphics:mask_graphics_15,x:14.4,y:38.8}).wait(1).to({graphics:mask_graphics_16,x:16.3,y:38.8}).wait(1).to({graphics:mask_graphics_17,x:18.2,y:38.8}).wait(1).to({graphics:mask_graphics_18,x:20.1,y:38.7}).wait(1).to({graphics:mask_graphics_19,x:22,y:38.7}).wait(1).to({graphics:mask_graphics_20,x:23.9,y:38.7}).wait(1).to({graphics:mask_graphics_21,x:25.8,y:38.7}).wait(1).to({graphics:mask_graphics_22,x:27.7,y:38.7}).wait(1).to({graphics:mask_graphics_23,x:29.6,y:38.6}).wait(1).to({graphics:mask_graphics_24,x:31.5,y:38.6}).wait(1).to({graphics:mask_graphics_25,x:33.4,y:38.6}).wait(22).to({graphics:mask_graphics_47,x:33.4,y:38.6}).wait(1).to({graphics:mask_graphics_48,x:34.8,y:38.6}).wait(1).to({graphics:mask_graphics_49,x:36.2,y:38.6}).wait(1).to({graphics:mask_graphics_50,x:37.6,y:38.6}).wait(1).to({graphics:mask_graphics_51,x:39,y:38.6}).wait(1).to({graphics:mask_graphics_52,x:40.4,y:38.6}).wait(1).to({graphics:mask_graphics_53,x:41.8,y:38.6}).wait(1).to({graphics:mask_graphics_54,x:43.2,y:38.6}).wait(1).to({graphics:mask_graphics_55,x:44.6,y:38.6}).wait(1).to({graphics:mask_graphics_56,x:46,y:38.6}).wait(1).to({graphics:mask_graphics_57,x:47.4,y:38.6}).wait(1).to({graphics:mask_graphics_58,x:48.8,y:38.6}).wait(1).to({graphics:mask_graphics_59,x:50.2,y:38.6}).wait(1).to({graphics:mask_graphics_60,x:51.6,y:38.6}).wait(1).to({graphics:mask_graphics_61,x:53,y:38.6}).wait(1).to({graphics:mask_graphics_62,x:54.4,y:38.6}).wait(1).to({graphics:mask_graphics_63,x:55.8,y:38.6}).wait(1).to({graphics:mask_graphics_64,x:57.2,y:38.6}).wait(1).to({graphics:mask_graphics_65,x:58.6,y:38.6}).wait(1).to({graphics:mask_graphics_66,x:60,y:38.6}).wait(1).to({graphics:mask_graphics_67,x:61.4,y:38.6}).wait(1).to({graphics:mask_graphics_68,x:62.8,y:38.6}).wait(1).to({graphics:mask_graphics_69,x:64.2,y:38.6}).wait(1).to({graphics:mask_graphics_70,x:65.6,y:38.6}).wait(1).to({graphics:mask_graphics_71,x:67,y:38.6}).wait(1).to({graphics:mask_graphics_72,x:68.4,y:38.6}).wait(1).to({graphics:mask_graphics_73,x:69.8,y:38.6}).wait(1).to({graphics:mask_graphics_74,x:71.2,y:38.6}).wait(1).to({graphics:mask_graphics_75,x:72.6,y:38.6}).wait(1).to({graphics:mask_graphics_76,x:74,y:38.6}).wait(1).to({graphics:mask_graphics_77,x:75.4,y:38.6}).wait(1).to({graphics:mask_graphics_78,x:76.8,y:38.6}).wait(1).to({graphics:mask_graphics_79,x:78.2,y:38.6}).wait(1).to({graphics:mask_graphics_80,x:79.6,y:38.6}).wait(1).to({graphics:mask_graphics_81,x:81,y:38.6}).wait(1).to({graphics:mask_graphics_82,x:82.4,y:38.6}).wait(1).to({graphics:mask_graphics_83,x:83.8,y:38.6}).wait(1).to({graphics:mask_graphics_84,x:85.2,y:38.6}).wait(1).to({graphics:mask_graphics_85,x:86.6,y:38.6}).wait(10));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape.setTransform(153,53.2,0.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AhlAAIDLAA");
	this.shape_1.setTransform(100,53.2,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape_2.setTransform(30,53.2,0.74,1);

	//this.text = new cjs.Text("", "italic 20px Verdana");
	//this.text.lineHeight = 22;
	//this.text.setTransform(0,52+incremento);
if (isbq)
  html = createDiv(txt["f19_03bq"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  else
  html = createDiv(txt["f19_03"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");

  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-305,-605);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape_3.setTransform(153,1.2,0.2,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AhlAAIDLAA");
	this.shape_4.setTransform(100,1.2,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape_5.setTransform(30,1.2,0.74,1);

	//this.text_1 = new cjs.Text("", "italic 20px Verdana");
	//this.text_1.lineHeight = 22;
  //this.text_1.setTransform(0,incremento);
if (isbq)
  html = createDiv(txt["f19_02bq"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  else
  html = createDiv(txt["f19_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");

  this.text_1 = new cjs.DOMElement(html);
  this.text_1.setTransform(-305,-553);

	//this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.text.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.text_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,185.8,88.8);

    (lib.frame20 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,0,1,0,0);
        titulo1(this, txt["f20_01"]);
        
        this.instance_1 = new lib.mc_g0();
        this.instance_1.setTransform(475.2,340,1,1,0,0,0,303,187.5);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame21());
        });
        this.addChild(this.logo, this.home, this.siguiente, this.titulo, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame21 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f21_01"]);
        
	this.instance_1 = new lib.mc_g1();
	this.instance_1.setTransform(476,340.1,0.9,0.9,0,0,0,199.2,187.5);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame20());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame22());
        });
        this.addChild(this.logo, this.home, this.anterior, this.siguiente, this.titulo,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame22 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt["f22_01"]);
        
	this.instance_1 = new lib.mc_g2();
	this.instance_1.setTransform(270.1,319.5,1,1,0,0,0,87.4,40);

	this.instance_2 = new lib.mc_g1();
	this.instance_2.setTransform(668.3,340.1,0.9,0.9,0,0,0,199.2,187.5);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame21());
        });
        this.siguiente.on("click", function (evt) {
          putStage(new lib.frame23());
        });
        this.addChild(this.logo, this.home, this.anterior, this.siguiente, this.titulo, this.instance_1, this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame23 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt["f23_01"]);
        
	this.instance_1 = new lib.mc_g1();
	this.instance_1.setTransform(668.3,340.1,0.9,0.9,0,0,0,199.2,187.5);
  
	this.mc_g3 = new lib.mc_g3();
	this.mc_g3.setTransform(264.7,248.2,1,1,0,0,0,96,17.2);

 	this.btn_practica = new lib.btn_practica();
	this.btn_practica.setTransform(832.2,574.9);
	new cjs.ButtonHelper(this.btn_practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.home.on("click", function (evt) {
          putStage(new lib.frame1());
        });
        this.btn_practica.on("click", function (evt) {
          putStage(new lib.frame24());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame22());
        });
        this.addChild(this.logo, this.home, this.anterior, this.btn_practica, this.titulo, this.instance_1, this.mc_g3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame24 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,0,0,0,1);
        titulo2(this, txt["f24_01"]);
        
	this.btn_solucion = new lib.btn_solucion();
	this.btn_solucion.setTransform(832.2,574.4);
	new cjs.ButtonHelper(this.btn_solucion, 0, 1, 2, false, new lib.btn_solucion(), 3);

        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame23());
        });
        this.btn_solucion.on("click", function (evt) {
          putStage(new lib.frame25());
        });
        this.addChild(this.logo, this.btn_solucion, this.titulo, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame25 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0,1,0,0,1);
        texto(this, txt["f25_01"], "20px", 40, 150);
        
        this.cerrar.on("click", function (evt) {
          putStage(new lib.frame23());
        });
        this.anterior.on("click", function (evt) {
          putStage(new lib.frame24());
        });
        this.addChild(this.logo, this.cerrar, this.anterior, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    // symbols:
    

    
(lib.mc_g3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgsC1IAAlpIBZAAIAAFpg");
	var mask_graphics_1 = new cjs.Graphics().p("Ag+C1IAAlpIB9AAIAAFpg");
	var mask_graphics_2 = new cjs.Graphics().p("AhQC1IAAlpIChAAIAAFpg");
	var mask_graphics_3 = new cjs.Graphics().p("AhjC1IAAlpIDGAAIAAFpg");
	var mask_graphics_4 = new cjs.Graphics().p("Ah1C1IAAlpIDrAAIAAFpg");
	var mask_graphics_5 = new cjs.Graphics().p("AiHC1IAAlpIEPAAIAAFpg");
	var mask_graphics_6 = new cjs.Graphics().p("AiZC1IAAlpIEzAAIAAFpg");
	var mask_graphics_7 = new cjs.Graphics().p("AisC1IAAlpIFZAAIAAFpg");
	var mask_graphics_8 = new cjs.Graphics().p("Ai+C1IAAlpIF9AAIAAFpg");
	var mask_graphics_9 = new cjs.Graphics().p("AjQC1IAAlpIGhAAIAAFpg");
	var mask_graphics_10 = new cjs.Graphics().p("AjiC1IAAlpIHFAAIAAFpg");
	var mask_graphics_11 = new cjs.Graphics().p("Aj1C1IAAlpIHrAAIAAFpg");
	var mask_graphics_12 = new cjs.Graphics().p("AkHC1IAAlpIIPAAIAAFpg");
	var mask_graphics_13 = new cjs.Graphics().p("AkZC1IAAlpIIzAAIAAFpg");
	var mask_graphics_14 = new cjs.Graphics().p("AkrC1IAAlpIJXAAIAAFpg");
	var mask_graphics_15 = new cjs.Graphics().p("Ak+C1IAAlpIJ8AAIAAFpg");
	var mask_graphics_16 = new cjs.Graphics().p("AlQC1IAAlpIKhAAIAAFpg");
	var mask_graphics_17 = new cjs.Graphics().p("AliC1IAAlpILFAAIAAFpg");
	var mask_graphics_18 = new cjs.Graphics().p("Al0C1IAAlpILpAAIAAFpg");
	var mask_graphics_19 = new cjs.Graphics().p("AmHC1IAAlpIMOAAIAAFpg");
	var mask_graphics_20 = new cjs.Graphics().p("AmZC1IAAlpIMzAAIAAFpg");
	var mask_graphics_21 = new cjs.Graphics().p("AlpC1IAAlpINXAAIAAFpg");
	var mask_graphics_36 = new cjs.Graphics().p("AlpC1IAAlpINXAAIAAFpg");
	var mask_graphics_37 = new cjs.Graphics().p("Am9C1IAAlpIN7AAIAAFpg");
	var mask_graphics_38 = new cjs.Graphics().p("AnPC1IAAlpIOfAAIAAFpg");
	var mask_graphics_39 = new cjs.Graphics().p("AnhC1IAAlpIPDAAIAAFpg");
	var mask_graphics_40 = new cjs.Graphics().p("AnzC1IAAlpIPnAAIAAFpg");
	var mask_graphics_41 = new cjs.Graphics().p("AoFC1IAAlpIQLAAIAAFpg");
	var mask_graphics_42 = new cjs.Graphics().p("AoXC1IAAlpIQvAAIAAFpg");
	var mask_graphics_43 = new cjs.Graphics().p("AopC1IAAlpIRTAAIAAFpg");
	var mask_graphics_44 = new cjs.Graphics().p("Ao7C1IAAlpIR3AAIAAFpg");
	var mask_graphics_45 = new cjs.Graphics().p("ApNC1IAAlpISbAAIAAFpg");
	var mask_graphics_46 = new cjs.Graphics().p("ApfC1IAAlpIS/AAIAAFpg");
	var mask_graphics_47 = new cjs.Graphics().p("ApxC1IAAlpITjAAIAAFpg");
	var mask_graphics_48 = new cjs.Graphics().p("AqDC1IAAlpIUHAAIAAFpg");
	var mask_graphics_49 = new cjs.Graphics().p("AqVC1IAAlpIUrAAIAAFpg");
	var mask_graphics_50 = new cjs.Graphics().p("AqoC1IAAlpIVRAAIAAFpg");
	var mask_graphics_51 = new cjs.Graphics().p("Aq6C1IAAlpIV1AAIAAFpg");
	var mask_graphics_52 = new cjs.Graphics().p("ArMC1IAAlpIWZAAIAAFpg");
	var mask_graphics_53 = new cjs.Graphics().p("AreC1IAAlpIW9AAIAAFpg");
	var mask_graphics_54 = new cjs.Graphics().p("ArwC1IAAlpIXhAAIAAFpg");
	var mask_graphics_55 = new cjs.Graphics().p("AsCC1IAAlpIYFAAIAAFpg");
	var mask_graphics_56 = new cjs.Graphics().p("AsUC1IAAlpIYpAAIAAFpg");
	var mask_graphics_57 = new cjs.Graphics().p("ArjC1IAAlpIZNAAIAAFpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:17.7,y:15}).wait(1).to({graphics:mask_graphics_1,x:19.5,y:15}).wait(1).to({graphics:mask_graphics_2,x:21.3,y:15}).wait(1).to({graphics:mask_graphics_3,x:23.2,y:15}).wait(1).to({graphics:mask_graphics_4,x:25,y:15}).wait(1).to({graphics:mask_graphics_5,x:26.8,y:15}).wait(1).to({graphics:mask_graphics_6,x:28.6,y:15}).wait(1).to({graphics:mask_graphics_7,x:30.5,y:15}).wait(1).to({graphics:mask_graphics_8,x:32.3,y:15}).wait(1).to({graphics:mask_graphics_9,x:34.1,y:15}).wait(1).to({graphics:mask_graphics_10,x:35.9,y:15}).wait(1).to({graphics:mask_graphics_11,x:37.8,y:15}).wait(1).to({graphics:mask_graphics_12,x:39.6,y:15}).wait(1).to({graphics:mask_graphics_13,x:41.4,y:15}).wait(1).to({graphics:mask_graphics_14,x:43.2,y:15}).wait(1).to({graphics:mask_graphics_15,x:45.1,y:15}).wait(1).to({graphics:mask_graphics_16,x:46.9,y:15}).wait(1).to({graphics:mask_graphics_17,x:48.7,y:15}).wait(1).to({graphics:mask_graphics_18,x:50.5,y:15}).wait(1).to({graphics:mask_graphics_19,x:52.4,y:15}).wait(1).to({graphics:mask_graphics_20,x:54.2,y:15}).wait(1).to({graphics:mask_graphics_21,x:49.4,y:15}).wait(15).to({graphics:mask_graphics_36,x:49.4,y:15}).wait(1).to({graphics:mask_graphics_37,x:57.8,y:15}).wait(1).to({graphics:mask_graphics_38,x:59.6,y:15}).wait(1).to({graphics:mask_graphics_39,x:61.4,y:15}).wait(1).to({graphics:mask_graphics_40,x:63.3,y:15}).wait(1).to({graphics:mask_graphics_41,x:65.1,y:15}).wait(1).to({graphics:mask_graphics_42,x:66.9,y:15}).wait(1).to({graphics:mask_graphics_43,x:68.7,y:15}).wait(1).to({graphics:mask_graphics_44,x:70.5,y:15}).wait(1).to({graphics:mask_graphics_45,x:72.3,y:15}).wait(1).to({graphics:mask_graphics_46,x:74.1,y:15}).wait(1).to({graphics:mask_graphics_47,x:75.9,y:15}).wait(1).to({graphics:mask_graphics_48,x:77.8,y:15}).wait(1).to({graphics:mask_graphics_49,x:79.6,y:15}).wait(1).to({graphics:mask_graphics_50,x:81.4,y:15}).wait(1).to({graphics:mask_graphics_51,x:83.2,y:15}).wait(1).to({graphics:mask_graphics_52,x:85,y:15}).wait(1).to({graphics:mask_graphics_53,x:86.8,y:15}).wait(1).to({graphics:mask_graphics_54,x:88.6,y:15}).wait(1).to({graphics:mask_graphics_55,x:90.4,y:15}).wait(1).to({graphics:mask_graphics_56,x:92.3,y:15}).wait(1).to({graphics:mask_graphics_57,x:87.4,y:15}).wait(8));

	// Capa 1
	//this.text = new cjs.Text(txt["f23_02"], "italic 20px Verdana");
	//this.text.textAlign = "center";
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 188;
	//this.text.setTransform(94.1,0);

  html = createDiv(txt["f23_02"], "Verdana", "20px", '200px', '30px', "20px", "185px", "left");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-5,-573);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(65));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,192.2,34);

(lib.mc_g2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgsCZIAAkxIBZAAIAAExg");
	var mask_graphics_1 = new cjs.Graphics().p("AhGCiIAAgTIBZAAIAAATgAATCPIAAkdIhZAAIAAEdIAAkwICNAAIAAEwg");
	var mask_graphics_2 = new cjs.Graphics().p("AhgCsIAAgmIBbAAIAAAmgAgFCGIAAkLIhbAAIAAELIAAkxIDBAAIAAExg");
	var mask_graphics_3 = new cjs.Graphics().p("Ah6C1IAAg5IBbAAIAAA5gAgfB8IAAj3IhbAAIAAD3IAAkwID1AAIAAEwg");
	var mask_graphics_4 = new cjs.Graphics().p("AiUC/IAAhMIBaAAIAABMgAg6BzIAAjlIhaAAIAADlIAAkxIEpAAIAAExg");
	var mask_graphics_5 = new cjs.Graphics().p("AiuDIIAAhfIBaAAIAABfgAhUBpIAAjRIhaAAIAADRIAAkwIFdAAIAAEwg");
	var mask_graphics_6 = new cjs.Graphics().p("AjIDSIAAhzIBaAAIAABzgAhuBfIAAi9IhaAAIAAC9IAAkwIGRAAIAAEwg");
	var mask_graphics_7 = new cjs.Graphics().p("AjiDcIAAiGIBaAAIAACGgAiIBWIAAirIhaAAIAACrIAAkxIHFAAIAAExg");
	var mask_graphics_8 = new cjs.Graphics().p("Aj8DlIAAiZIBaAAIAACZgAiiBMIAAiXIhaAAIAACXIAAkwIH5AAIAAEwg");
	var mask_graphics_9 = new cjs.Graphics().p("AkWDvIAAisIBaAAIAACsgAi8BDIAAiFIhaAAIAACFIAAkxIItAAIAAExg");
	var mask_graphics_10 = new cjs.Graphics().p("AkwD4IAAi/IBaAAIAAC/gAjWA5IAAhxIhaAAIAABxIAAkwIJhAAIAAEwg");
	var mask_graphics_11 = new cjs.Graphics().p("AlKECIAAjSIBaAAIAADSgAjwAwIAAhfIhaAAIAABfIAAkxIKVAAIAAExg");
	var mask_graphics_12 = new cjs.Graphics().p("AllELIAAjlIBbAAIAADlgAkKAmIAAhLIhbAAIAABLIAAkwILLAAIAAEwg");
	var mask_graphics_13 = new cjs.Graphics().p("Al/EVIAAj4IBbAAIAAD4gAkkAdIAAg5IhbAAIAAA5IAAkxIL/AAIAAExg");
	var mask_graphics_14 = new cjs.Graphics().p("AmZEeIAAkLIBbAAIAAELgAk+ATIAAglIhbAAIAAAlIAAkwIMzAAIAAEwg");
	var mask_graphics_15 = new cjs.Graphics().p("AmzEoIAAkeIBbAAIAAEegAlYAKIAAgTIhbAAIAAATIAAkxINnAAIAAExg");
	var mask_graphics_16 = new cjs.Graphics().p("AnNExIAAkxIBbAAIAAExgAlyAAIAAAAIhbAAIAAAAIAAkwIObAAIAAEwg");
	var mask_graphics_17 = new cjs.Graphics().p("AnnE7IAAkyIBbAAIAAEygAnngIIAAkyIPPAAIAAEyg");
	var mask_graphics_18 = new cjs.Graphics().p("AoBFFIAAkzIBbAAIAAEzgAoBgRIAAkzIQDAAIAAEzg");
	var mask_graphics_19 = new cjs.Graphics().p("AobFOIAAkyIBbAAIAAEygAobgbIAAkyIQ3AAIAAEyg");
	var mask_graphics_20 = new cjs.Graphics().p("Ao1FYIAAkzIBaAAIAAEzgAo1gkIAAkzIRrAAIAAEzg");
	var mask_graphics_21 = new cjs.Graphics().p("ApPFhIAAkyIBaAAIAAEygApPguIAAkyISfAAIAAEyg");
	var mask_graphics_22 = new cjs.Graphics().p("AppFrIAAkzIBaAAIAAEzgAppg3IAAkzITTAAIAAEzg");
	var mask_graphics_23 = new cjs.Graphics().p("AqDF0IAAkyIBaAAIAAEygAqDhBIAAkyIUHAAIAAEyg");
	var mask_graphics_24 = new cjs.Graphics().p("AqdF+IAAkzIBaAAIAAEzgAqdhKIAAkzIU7AAIAAEzg");
	var mask_graphics_25 = new cjs.Graphics().p("Aq3GHIAAkyIBaAAIAAEygAq3hUIAAkyIVvAAIAAEyg");
	var mask_graphics_26 = new cjs.Graphics().p("ArRGRIAAkzIBaAAIAAEzgArRhdIAAkzIWjAAIAAEzg");
	var mask_graphics_27 = new cjs.Graphics().p("ArsGaIAAkyIBbAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_41 = new cjs.Graphics().p("ArsGaIAAkyIBbAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_42 = new cjs.Graphics().p("ArsGaIAAkyICPAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_43 = new cjs.Graphics().p("ArsGaIAAkyIDDAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_44 = new cjs.Graphics().p("ArsGaIAAkyID3AAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_45 = new cjs.Graphics().p("ArsGaIAAkyIEsAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_46 = new cjs.Graphics().p("ArsGaIAAkyIFgAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_47 = new cjs.Graphics().p("ArsGaIAAkyIGUAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_48 = new cjs.Graphics().p("ArsGaIAAkyIHIAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_49 = new cjs.Graphics().p("ArsGaIAAkyIH8AAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_50 = new cjs.Graphics().p("ArsGaIAAkyIIwAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_51 = new cjs.Graphics().p("ArsGaIAAkyIJkAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_52 = new cjs.Graphics().p("ArsGaIAAkyIKYAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_53 = new cjs.Graphics().p("ArsGaIAAkyILNAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_54 = new cjs.Graphics().p("ArsGaIAAkyIL/AAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_55 = new cjs.Graphics().p("ArsGaIAAkyIMzAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_56 = new cjs.Graphics().p("ArsGaIAAkyINnAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_57 = new cjs.Graphics().p("ArsGaIAAkyIObAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_58 = new cjs.Graphics().p("ArsGaIAAkyIPPAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_59 = new cjs.Graphics().p("ArsGaIAAkyIQDAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_60 = new cjs.Graphics().p("ArsGaIAAkyIQ3AAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_61 = new cjs.Graphics().p("ArsGaIAAkyIRsAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_62 = new cjs.Graphics().p("ArsGaIAAkyISgAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_63 = new cjs.Graphics().p("ArsGaIAAkyITUAAIAAEygArshnIAAkyIXZAAIAAEyg");
	var mask_graphics_64 = new cjs.Graphics().p("ArsGaIAAkyIUIAAIAAEygArshnIAAkyIXZAAIAAEyg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:14.2,y:15.2}).wait(1).to({graphics:mask_graphics_1,x:16.8,y:16.2}).wait(1).to({graphics:mask_graphics_2,x:19.4,y:17.1}).wait(1).to({graphics:mask_graphics_3,x:22,y:18.1}).wait(1).to({graphics:mask_graphics_4,x:24.6,y:19}).wait(1).to({graphics:mask_graphics_5,x:27.2,y:20}).wait(1).to({graphics:mask_graphics_6,x:29.8,y:21}).wait(1).to({graphics:mask_graphics_7,x:32.4,y:21.9}).wait(1).to({graphics:mask_graphics_8,x:35,y:22.9}).wait(1).to({graphics:mask_graphics_9,x:37.6,y:23.8}).wait(1).to({graphics:mask_graphics_10,x:40.2,y:24.8}).wait(1).to({graphics:mask_graphics_11,x:42.8,y:25.7}).wait(1).to({graphics:mask_graphics_12,x:45.5,y:26.7}).wait(1).to({graphics:mask_graphics_13,x:48.1,y:27.6}).wait(1).to({graphics:mask_graphics_14,x:50.7,y:28.6}).wait(1).to({graphics:mask_graphics_15,x:53.3,y:29.5}).wait(1).to({graphics:mask_graphics_16,x:55.9,y:30.5}).wait(1).to({graphics:mask_graphics_17,x:58.5,y:31.5}).wait(1).to({graphics:mask_graphics_18,x:61.1,y:32.4}).wait(1).to({graphics:mask_graphics_19,x:63.7,y:33.4}).wait(1).to({graphics:mask_graphics_20,x:66.3,y:34.3}).wait(1).to({graphics:mask_graphics_21,x:68.9,y:35.3}).wait(1).to({graphics:mask_graphics_22,x:71.5,y:36.2}).wait(1).to({graphics:mask_graphics_23,x:74.1,y:37.2}).wait(1).to({graphics:mask_graphics_24,x:76.7,y:38.1}).wait(1).to({graphics:mask_graphics_25,x:79.3,y:39.1}).wait(1).to({graphics:mask_graphics_26,x:81.9,y:40}).wait(1).to({graphics:mask_graphics_27,x:84.6,y:41}).wait(14).to({graphics:mask_graphics_41,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_42,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_43,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_44,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_45,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_46,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_47,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_48,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_49,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_50,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_51,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_52,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_53,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_54,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_55,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_56,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_57,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_58,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_59,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_60,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_61,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_62,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_63,x:84.6,y:41}).wait(1).to({graphics:mask_graphics_64,x:84.6,y:41}).wait(1));

	// Capa 1
	//this.text = new cjs.Text(txt["f22_02"], "20px Verdana");
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 171;
	//this.text.setTransform(19.3,10);

  html = createDiv(txt["f22_02"], "Verdana", "20px", '200px', '30px', "20px", "185px", "left");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-5,-573);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(65));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(19.3,0,174.8,80.9);

(lib.mc_g1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._2_shutterstock_38323795();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,398.5,375);

(lib.mc_g0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._4_shutterstock_25332253();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,606,375);

(lib.mc_h4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgzDbIAAm1IBnAAIAAG1g");
	var mask_graphics_1 = new cjs.Graphics().p("AhIDbIAAm1ICRAAIAAG1g");
	var mask_graphics_2 = new cjs.Graphics().p("AhdDbIAAm1IC7AAIAAG1g");
	var mask_graphics_3 = new cjs.Graphics().p("AhyDbIAAm1IDlAAIAAG1g");
	var mask_graphics_4 = new cjs.Graphics().p("AiHDbIAAm1IEPAAIAAG1g");
	var mask_graphics_5 = new cjs.Graphics().p("AicDbIAAm1IE5AAIAAG1g");
	var mask_graphics_6 = new cjs.Graphics().p("AixDbIAAm1IFjAAIAAG1g");
	var mask_graphics_7 = new cjs.Graphics().p("AjGDbIAAm1IGNAAIAAG1g");
	var mask_graphics_8 = new cjs.Graphics().p("AjbDbIAAm1IG3AAIAAG1g");
	var mask_graphics_9 = new cjs.Graphics().p("AjwDbIAAm1IHhAAIAAG1g");
	var mask_graphics_10 = new cjs.Graphics().p("AkFDbIAAm1IILAAIAAG1g");
	var mask_graphics_11 = new cjs.Graphics().p("AkaDbIAAm1II1AAIAAG1g");
	var mask_graphics_12 = new cjs.Graphics().p("AkvDbIAAm1IJfAAIAAG1g");
	var mask_graphics_13 = new cjs.Graphics().p("AlEDbIAAm1IKJAAIAAG1g");
	var mask_graphics_14 = new cjs.Graphics().p("AlZDbIAAm1IKzAAIAAG1g");
	var mask_graphics_15 = new cjs.Graphics().p("AluDbIAAm1ILdAAIAAG1g");
	var mask_graphics_16 = new cjs.Graphics().p("AmDDbIAAm1IMHAAIAAG1g");
	var mask_graphics_17 = new cjs.Graphics().p("AmYDbIAAm1IMxAAIAAG1g");
	var mask_graphics_18 = new cjs.Graphics().p("AmtDbIAAm1INbAAIAAG1g");
	var mask_graphics_19 = new cjs.Graphics().p("AnDDbIAAm1IOHAAIAAG1g");
	var mask_graphics_20 = new cjs.Graphics().p("AnYDbIAAm1IOxAAIAAG1g");
	var mask_graphics_21 = new cjs.Graphics().p("AntDbIAAm1IPbAAIAAG1g");
	var mask_graphics_22 = new cjs.Graphics().p("AoCDbIAAm1IQFAAIAAG1g");
	var mask_graphics_23 = new cjs.Graphics().p("AoXDbIAAm1IQvAAIAAG1g");
	var mask_graphics_24 = new cjs.Graphics().p("AosDbIAAm1IRZAAIAAG1g");
	var mask_graphics_25 = new cjs.Graphics().p("ApBDbIAAm1ISDAAIAAG1g");
	var mask_graphics_38 = new cjs.Graphics().p("ApBDbIAAm1ISDAAIAAG1g");
	var mask_graphics_39 = new cjs.Graphics().p("ApcDbIAAm1IS5AAIAAG1g");
	var mask_graphics_40 = new cjs.Graphics().p("Ap4DbIAAm1ITxAAIAAG1g");
	var mask_graphics_41 = new cjs.Graphics().p("AqTDbIAAm1IUnAAIAAG1g");
	var mask_graphics_42 = new cjs.Graphics().p("AqvDbIAAm1IVfAAIAAG1g");
	var mask_graphics_43 = new cjs.Graphics().p("ArLDbIAAm1IWXAAIAAG1g");
	var mask_graphics_44 = new cjs.Graphics().p("ArmDbIAAm1IXNAAIAAG1g");
	var mask_graphics_45 = new cjs.Graphics().p("AsCDbIAAm1IYFAAIAAG1g");
	var mask_graphics_46 = new cjs.Graphics().p("AsdDbIAAm1IY7AAIAAG1g");
	var mask_graphics_47 = new cjs.Graphics().p("As5DbIAAm1IZzAAIAAG1g");
	var mask_graphics_48 = new cjs.Graphics().p("AtUDbIAAm1IapAAIAAG1g");
	var mask_graphics_49 = new cjs.Graphics().p("AtwDbIAAm1IbhAAIAAG1g");
	var mask_graphics_50 = new cjs.Graphics().p("AuLDbIAAm1IcXAAIAAG1g");
	var mask_graphics_51 = new cjs.Graphics().p("AunDbIAAm1IdPAAIAAG1g");
	var mask_graphics_52 = new cjs.Graphics().p("AvDDbIAAm1IeHAAIAAG1g");
	var mask_graphics_53 = new cjs.Graphics().p("AveDbIAAm1Ie9AAIAAG1g");
	var mask_graphics_54 = new cjs.Graphics().p("Av6DbIAAm1If1AAIAAG1g");
	var mask_graphics_55 = new cjs.Graphics().p("AwVDbIAAm1MAgrAAAIAAG1g");
	var mask_graphics_56 = new cjs.Graphics().p("AwxDbIAAm1MAhjAAAIAAG1g");
	var mask_graphics_57 = new cjs.Graphics().p("AxMDbIAAm1MAiZAAAIAAG1g");
	var mask_graphics_58 = new cjs.Graphics().p("AxoDbIAAm1MAjRAAAIAAG1g");
	var mask_graphics_59 = new cjs.Graphics().p("AyDDbIAAm1MAkHAAAIAAG1g");
	var mask_graphics_60 = new cjs.Graphics().p("AyfDbIAAm1MAk/AAAIAAG1g");
	var mask_graphics_61 = new cjs.Graphics().p("Ay7DbIAAm1MAl3AAAIAAG1g");
	var mask_graphics_62 = new cjs.Graphics().p("AzWDbIAAm1MAmtAAAIAAG1g");
	var mask_graphics_63 = new cjs.Graphics().p("AzyDbIAAm1MAnlAAAIAAG1g");
	var mask_graphics_64 = new cjs.Graphics().p("A0NDbIAAm1MAobAAAIAAG1g");
	var mask_graphics_65 = new cjs.Graphics().p("A0pDbIAAm1MApTAAAIAAG1g");
	var mask_graphics_66 = new cjs.Graphics().p("A1EDbIAAm1MAqJAAAIAAG1g");
	var mask_graphics_67 = new cjs.Graphics().p("A1gDbIAAm1MArBAAAIAAG1g");
	var mask_graphics_68 = new cjs.Graphics().p("A18DbIAAm1MAr5AAAIAAG1g");
	var mask_graphics_69 = new cjs.Graphics().p("A2XDbIAAm1MAsvAAAIAAG1g");
	var mask_graphics_70 = new cjs.Graphics().p("A2zDbIAAm1MAtnAAAIAAG1g");
	var mask_graphics_71 = new cjs.Graphics().p("A3ODbIAAm1MAudAAAIAAG1g");
	var mask_graphics_72 = new cjs.Graphics().p("A3qDbIAAm1MAvVAAAIAAG1g");
	var mask_graphics_73 = new cjs.Graphics().p("A4FDbIAAm1MAwLAAAIAAG1g");
	var mask_graphics_74 = new cjs.Graphics().p("A4hDbIAAm1MAxDAAAIAAG1g");
	var mask_graphics_75 = new cjs.Graphics().p("A48DbIAAm1MAx5AAAIAAG1g");
	var mask_graphics_76 = new cjs.Graphics().p("A5YDbIAAm1MAyxAAAIAAG1g");
	var mask_graphics_77 = new cjs.Graphics().p("A50DbIAAm1MAzpAAAIAAG1g");
	var mask_graphics_78 = new cjs.Graphics().p("A6PDbIAAm1MA0fAAAIAAG1g");
	var mask_graphics_79 = new cjs.Graphics().p("A6rDbIAAm1MA1XAAAIAAG1g");
	var mask_graphics_80 = new cjs.Graphics().p("A7GDbIAAm1MA2NAAAIAAG1g");
	var mask_graphics_81 = new cjs.Graphics().p("A7iDbIAAm1MA3FAAAIAAG1g");
	var mask_graphics_82 = new cjs.Graphics().p("A79DbIAAm1MA37AAAIAAG1g");
	var mask_graphics_83 = new cjs.Graphics().p("A8ZDbIAAm1MA4zAAAIAAG1g");
	var mask_graphics_84 = new cjs.Graphics().p("A80DbIAAm1MA5pAAAIAAG1g");
	var mask_graphics_85 = new cjs.Graphics().p("A9QDbIAAm1MA6hAAAIAAG1g");
	var mask_graphics_86 = new cjs.Graphics().p("A9sDbIAAm1MA7ZAAAIAAG1g");
	var mask_graphics_87 = new cjs.Graphics().p("A+HDbIAAm1MA8PAAAIAAG1g");
	var mask_graphics_88 = new cjs.Graphics().p("A+jDbIAAm1MA9HAAAIAAG1g");
	var mask_graphics_89 = new cjs.Graphics().p("A++DbIAAm1MA99AAAIAAG1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:0.4,y:21.1}).wait(1).to({graphics:mask_graphics_1,x:2.5,y:21.1}).wait(1).to({graphics:mask_graphics_2,x:4.6,y:21.1}).wait(1).to({graphics:mask_graphics_3,x:6.7,y:21.1}).wait(1).to({graphics:mask_graphics_4,x:8.8,y:21.1}).wait(1).to({graphics:mask_graphics_5,x:10.9,y:21.1}).wait(1).to({graphics:mask_graphics_6,x:13,y:21.1}).wait(1).to({graphics:mask_graphics_7,x:15.1,y:21.1}).wait(1).to({graphics:mask_graphics_8,x:17.2,y:21.1}).wait(1).to({graphics:mask_graphics_9,x:19.3,y:21.1}).wait(1).to({graphics:mask_graphics_10,x:21.4,y:21.1}).wait(1).to({graphics:mask_graphics_11,x:23.5,y:21.1}).wait(1).to({graphics:mask_graphics_12,x:25.6,y:21.1}).wait(1).to({graphics:mask_graphics_13,x:27.7,y:21.1}).wait(1).to({graphics:mask_graphics_14,x:29.8,y:21.1}).wait(1).to({graphics:mask_graphics_15,x:31.9,y:21.1}).wait(1).to({graphics:mask_graphics_16,x:34,y:21.1}).wait(1).to({graphics:mask_graphics_17,x:36.1,y:21.1}).wait(1).to({graphics:mask_graphics_18,x:38.2,y:21.1}).wait(1).to({graphics:mask_graphics_19,x:40.4,y:21.1}).wait(1).to({graphics:mask_graphics_20,x:42.5,y:21.1}).wait(1).to({graphics:mask_graphics_21,x:44.6,y:21.1}).wait(1).to({graphics:mask_graphics_22,x:46.7,y:21.1}).wait(1).to({graphics:mask_graphics_23,x:48.8,y:21.1}).wait(1).to({graphics:mask_graphics_24,x:50.9,y:21.1}).wait(1).to({graphics:mask_graphics_25,x:53,y:21.1}).wait(13).to({graphics:mask_graphics_38,x:53,y:21.1}).wait(1).to({graphics:mask_graphics_39,x:55.7,y:21.1}).wait(1).to({graphics:mask_graphics_40,x:58.5,y:21.1}).wait(1).to({graphics:mask_graphics_41,x:61.2,y:21.1}).wait(1).to({graphics:mask_graphics_42,x:64,y:21.1}).wait(1).to({graphics:mask_graphics_43,x:66.8,y:21.1}).wait(1).to({graphics:mask_graphics_44,x:69.5,y:21.1}).wait(1).to({graphics:mask_graphics_45,x:72.3,y:21.1}).wait(1).to({graphics:mask_graphics_46,x:75,y:21.1}).wait(1).to({graphics:mask_graphics_47,x:77.8,y:21.1}).wait(1).to({graphics:mask_graphics_48,x:80.6,y:21.1}).wait(1).to({graphics:mask_graphics_49,x:83.3,y:21.1}).wait(1).to({graphics:mask_graphics_50,x:86.1,y:21.1}).wait(1).to({graphics:mask_graphics_51,x:88.8,y:21.1}).wait(1).to({graphics:mask_graphics_52,x:91.6,y:21.1}).wait(1).to({graphics:mask_graphics_53,x:94.3,y:21.1}).wait(1).to({graphics:mask_graphics_54,x:97.1,y:21.1}).wait(1).to({graphics:mask_graphics_55,x:99.9,y:21.1}).wait(1).to({graphics:mask_graphics_56,x:102.6,y:21.1}).wait(1).to({graphics:mask_graphics_57,x:105.4,y:21.1}).wait(1).to({graphics:mask_graphics_58,x:108.1,y:21.1}).wait(1).to({graphics:mask_graphics_59,x:110.9,y:21.1}).wait(1).to({graphics:mask_graphics_60,x:113.6,y:21.1}).wait(1).to({graphics:mask_graphics_61,x:116.4,y:21.1}).wait(1).to({graphics:mask_graphics_62,x:119.2,y:21.1}).wait(1).to({graphics:mask_graphics_63,x:121.9,y:21.1}).wait(1).to({graphics:mask_graphics_64,x:124.7,y:21.1}).wait(1).to({graphics:mask_graphics_65,x:127.4,y:21.1}).wait(1).to({graphics:mask_graphics_66,x:130.2,y:21.1}).wait(1).to({graphics:mask_graphics_67,x:133,y:21.1}).wait(1).to({graphics:mask_graphics_68,x:135.7,y:21.1}).wait(1).to({graphics:mask_graphics_69,x:138.5,y:21.1}).wait(1).to({graphics:mask_graphics_70,x:141.2,y:21.1}).wait(1).to({graphics:mask_graphics_71,x:144,y:21.1}).wait(1).to({graphics:mask_graphics_72,x:146.7,y:21.1}).wait(1).to({graphics:mask_graphics_73,x:149.5,y:21.1}).wait(1).to({graphics:mask_graphics_74,x:152.3,y:21.1}).wait(1).to({graphics:mask_graphics_75,x:155,y:21.1}).wait(1).to({graphics:mask_graphics_76,x:157.8,y:21.1}).wait(1).to({graphics:mask_graphics_77,x:160.5,y:21.1}).wait(1).to({graphics:mask_graphics_78,x:163.3,y:21.1}).wait(1).to({graphics:mask_graphics_79,x:166,y:21.1}).wait(1).to({graphics:mask_graphics_80,x:168.8,y:21.1}).wait(1).to({graphics:mask_graphics_81,x:171.6,y:21.1}).wait(1).to({graphics:mask_graphics_82,x:174.3,y:21.1}).wait(1).to({graphics:mask_graphics_83,x:177.1,y:21.1}).wait(1).to({graphics:mask_graphics_84,x:179.8,y:21.1}).wait(1).to({graphics:mask_graphics_85,x:182.6,y:21.1}).wait(1).to({graphics:mask_graphics_86,x:185.4,y:21.1}).wait(1).to({graphics:mask_graphics_87,x:188.1,y:21.1}).wait(1).to({graphics:mask_graphics_88,x:190.9,y:21.1}).wait(1).to({graphics:mask_graphics_89,x:193.6,y:21.1}).wait(1));

	// Capa 1
	//this.text = new cjs.Text(txt["f18_02"], "italic 20px Verdana");
	//this.text.textAlign = "center";
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 387;
	//this.text.setTransform(193.4,0);

  html = createDiv(txt["f18_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-185,-570);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(90));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,390.8,63.1);
    
(lib.mc_p1_02 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("B", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.setTransform(148,30);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AWqAAQAAJbmpGpQmoGrpZAAQpYAAmpmrQmompAApbQAApaGomqQGpmqJYAAQJZAAGoGqQGpGqAAJag");
	this.shape.setTransform(150,211.6,1.034,1.031);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("AwBQEQmomqAApaQAApaGomqQGqmqJXAAQJYAAGpGqQGpGqAAJaQAAJampGqQmpGrpYAAQpXAAmqmrg");
	this.shape_1.setTransform(150,211.6,1.034,1.031);

	this.addChild(this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,300,331.6);


(lib.mc_p1_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("A", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.setTransform(148,30);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AWqAAQAAJbmpGpQmoGrpZAAQpYAAmpmrQmompAApbQAApaGomqQGpmqJYAAQJZAAGoGqQGpGqAAJag");
	this.shape.setTransform(150,211.6,1.034,1.031);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("AwBQEQmomqAApaQAApaGomqQGqmqJXAAQJYAAGpGqQGpGqAAJaQAAJampGqQmpGrpYAAQpXAAmqmrg");
	this.shape_1.setTransform(150,211.6,1.034,1.031);

	this.addChild(this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,300,331.6);

(lib.mc_h3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 4
	//this.text = new cjs.Text(txt["f17_02"], "italic 20px Verdana");
	//this.text.textAlign = "center";
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 412;
	//this.text.setTransform(350.9,359.8);
  
  html = createDiv(txt["f17_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-25,-230);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(48));

	// mc_p1_01
	this.text_1 = new cjs.Text("6", "bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(546,194.8);

	this.text_2 = new cjs.Text("1", "bold 20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(144.7,194.8);

	this.instance = new lib.mc_p1_01();
	this.instance.setTransform(150,166.3,1,1,0,0,0,150,166.3);
	this.instance.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text_2},{t:this.text_1}]}).wait(48));

	// mc_p1_02
	this.instance_1 = new lib.mc_p1_02();
	this.instance_1.setTransform(548.3,166.3,1,1,0,0,0,150,166.3);
	this.instance_1.alpha = 0.801;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(48));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,698.3,363.8);
    
(lib.mc_h2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgvERIAAohIBfAAIAAIhg");
	var mask_graphics_1 = new cjs.Graphics().p("AhXERIAAohICvAAIAAIhg");
	var mask_graphics_2 = new cjs.Graphics().p("Ah/ERIAAohID/AAIAAIhg");
	var mask_graphics_3 = new cjs.Graphics().p("AinERIAAohIFPAAIAAIhg");
	var mask_graphics_4 = new cjs.Graphics().p("AjPERIAAohIGfAAIAAIhg");
	var mask_graphics_5 = new cjs.Graphics().p("Aj3ERIAAohIHvAAIAAIhg");
	var mask_graphics_6 = new cjs.Graphics().p("AkfERIAAohII/AAIAAIhg");
	var mask_graphics_7 = new cjs.Graphics().p("AlIERIAAohIKQAAIAAIhg");
	var mask_graphics_8 = new cjs.Graphics().p("AlwERIAAohILhAAIAAIhg");
	var mask_graphics_9 = new cjs.Graphics().p("AmYERIAAohIMxAAIAAIhg");
	var mask_graphics_10 = new cjs.Graphics().p("AnAERIAAohIOBAAIAAIhg");
	var mask_graphics_11 = new cjs.Graphics().p("AnoERIAAohIPRAAIAAIhg");
	var mask_graphics_12 = new cjs.Graphics().p("AoQERIAAohIQhAAIAAIhg");
	var mask_graphics_13 = new cjs.Graphics().p("Ao4ERIAAohIRxAAIAAIhg");
	var mask_graphics_14 = new cjs.Graphics().p("ApgERIAAohITBAAIAAIhg");
	var mask_graphics_15 = new cjs.Graphics().p("AqIERIAAohIURAAIAAIhg");
	var mask_graphics_16 = new cjs.Graphics().p("AqwERIAAohIVhAAIAAIhg");
	var mask_graphics_17 = new cjs.Graphics().p("ArYERIAAohIWxAAIAAIhg");
	var mask_graphics_18 = new cjs.Graphics().p("AsAERIAAohIYBAAIAAIhg");
	var mask_graphics_19 = new cjs.Graphics().p("AsoERIAAohIZRAAIAAIhg");
	var mask_graphics_20 = new cjs.Graphics().p("AtQERIAAohIahAAIAAIhg");
	var mask_graphics_21 = new cjs.Graphics().p("At4ERIAAohIbxAAIAAIhg");
	var mask_graphics_22 = new cjs.Graphics().p("AugERIAAohIdBAAIAAIhg");
	var mask_graphics_23 = new cjs.Graphics().p("AvIERIAAohIeRAAIAAIhg");
	var mask_graphics_24 = new cjs.Graphics().p("AvwERIAAohIfhAAIAAIhg");
	var mask_graphics_25 = new cjs.Graphics().p("AwYERIAAohMAgxAAAIAAIhg");
	var mask_graphics_26 = new cjs.Graphics().p("AxAERIAAohMAiBAAAIAAIhg");
	var mask_graphics_27 = new cjs.Graphics().p("AxoERIAAohMAjRAAAIAAIhg");
	var mask_graphics_28 = new cjs.Graphics().p("AyQERIAAohMAkhAAAIAAIhg");
	var mask_graphics_45 = new cjs.Graphics().p("AyQERIAAohMAkhAAAIAAIhg");
	var mask_graphics_46 = new cjs.Graphics().p("Ay1ERIAAohMAlrAAAIAAIhg");
	var mask_graphics_47 = new cjs.Graphics().p("AzbERIAAohMAm3AAAIAAIhg");
	var mask_graphics_48 = new cjs.Graphics().p("A0AERIAAohMAoBAAAIAAIhg");
	var mask_graphics_49 = new cjs.Graphics().p("A0lERIAAohMApLAAAIAAIhg");
	var mask_graphics_50 = new cjs.Graphics().p("A1KERIAAohMAqVAAAIAAIhg");
	var mask_graphics_51 = new cjs.Graphics().p("A1wERIAAohMArhAAAIAAIhg");
	var mask_graphics_52 = new cjs.Graphics().p("A2VERIAAohMAsrAAAIAAIhg");
	var mask_graphics_53 = new cjs.Graphics().p("A26ERIAAohMAt1AAAIAAIhg");
	var mask_graphics_54 = new cjs.Graphics().p("A3fERIAAohMAu/AAAIAAIhg");
	var mask_graphics_55 = new cjs.Graphics().p("A4FERIAAohMAwLAAAIAAIhg");
	var mask_graphics_56 = new cjs.Graphics().p("A4qERIAAohMAxVAAAIAAIhg");
	var mask_graphics_57 = new cjs.Graphics().p("A5PERIAAohMAyfAAAIAAIhg");
	var mask_graphics_58 = new cjs.Graphics().p("A50ERIAAohMAzpAAAIAAIhg");
	var mask_graphics_59 = new cjs.Graphics().p("A6aERIAAohMA01AAAIAAIhg");
	var mask_graphics_60 = new cjs.Graphics().p("A6/ERIAAohMA1/AAAIAAIhg");
	var mask_graphics_61 = new cjs.Graphics().p("A7kERIAAohMA3JAAAIAAIhg");
	var mask_graphics_62 = new cjs.Graphics().p("A8JERIAAohMA4TAAAIAAIhg");
	var mask_graphics_63 = new cjs.Graphics().p("A8uERIAAohMA5dAAAIAAIhg");
	var mask_graphics_64 = new cjs.Graphics().p("A9UERIAAohMA6pAAAIAAIhg");
	var mask_graphics_65 = new cjs.Graphics().p("A95ERIAAohMA7zAAAIAAIhg");
	var mask_graphics_66 = new cjs.Graphics().p("A+eERIAAohMA89AAAIAAIhg");
	var mask_graphics_67 = new cjs.Graphics().p("A/DERIAAohMA+HAAAIAAIhg");
	var mask_graphics_68 = new cjs.Graphics().p("A/pERIAAohMA/TAAAIAAIhg");
	var mask_graphics_69 = new cjs.Graphics().p("EggOAERIAAohMBAdAAAIAAIhg");
	var mask_graphics_70 = new cjs.Graphics().p("EggzAERIAAohMBBnAAAIAAIhg");
	var mask_graphics_71 = new cjs.Graphics().p("EghYAERIAAohMBCxAAAIAAIhg");
	var mask_graphics_72 = new cjs.Graphics().p("Egh+AERIAAohMBD9AAAIAAIhg");
	var mask_graphics_73 = new cjs.Graphics().p("EgijAERIAAohMBFHAAAIAAIhg");
	var mask_graphics_74 = new cjs.Graphics().p("EgjIAERIAAohMBGRAAAIAAIhg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-3.8,y:17.1}).wait(1).to({graphics:mask_graphics_1,x:0.1,y:17.1}).wait(1).to({graphics:mask_graphics_2,x:4.1,y:17.1}).wait(1).to({graphics:mask_graphics_3,x:8.1,y:17.1}).wait(1).to({graphics:mask_graphics_4,x:12.1,y:17.1}).wait(1).to({graphics:mask_graphics_5,x:16.1,y:17.1}).wait(1).to({graphics:mask_graphics_6,x:20.1,y:17.1}).wait(1).to({graphics:mask_graphics_7,x:24.1,y:17.1}).wait(1).to({graphics:mask_graphics_8,x:28.1,y:17.1}).wait(1).to({graphics:mask_graphics_9,x:32.1,y:17.1}).wait(1).to({graphics:mask_graphics_10,x:36.1,y:17.1}).wait(1).to({graphics:mask_graphics_11,x:40.1,y:17.1}).wait(1).to({graphics:mask_graphics_12,x:44.1,y:17.1}).wait(1).to({graphics:mask_graphics_13,x:48.1,y:17.1}).wait(1).to({graphics:mask_graphics_14,x:52.1,y:17.1}).wait(1).to({graphics:mask_graphics_15,x:56.1,y:17.1}).wait(1).to({graphics:mask_graphics_16,x:60.1,y:17.1}).wait(1).to({graphics:mask_graphics_17,x:64.1,y:17.1}).wait(1).to({graphics:mask_graphics_18,x:68.1,y:17.1}).wait(1).to({graphics:mask_graphics_19,x:72.1,y:17.1}).wait(1).to({graphics:mask_graphics_20,x:76.1,y:17.1}).wait(1).to({graphics:mask_graphics_21,x:80.2,y:17.1}).wait(1).to({graphics:mask_graphics_22,x:84.2,y:17.1}).wait(1).to({graphics:mask_graphics_23,x:88.2,y:17.1}).wait(1).to({graphics:mask_graphics_24,x:92.2,y:17.1}).wait(1).to({graphics:mask_graphics_25,x:96.2,y:17.1}).wait(1).to({graphics:mask_graphics_26,x:100.2,y:17.1}).wait(1).to({graphics:mask_graphics_27,x:104.2,y:17.1}).wait(1).to({graphics:mask_graphics_28,x:108.2,y:17.1}).wait(17).to({graphics:mask_graphics_45,x:108.2,y:17.1}).wait(1).to({graphics:mask_graphics_46,x:111.9,y:17.1}).wait(1).to({graphics:mask_graphics_47,x:115.6,y:17.1}).wait(1).to({graphics:mask_graphics_48,x:119.3,y:17.1}).wait(1).to({graphics:mask_graphics_49,x:123,y:17.1}).wait(1).to({graphics:mask_graphics_50,x:126.7,y:17.1}).wait(1).to({graphics:mask_graphics_51,x:130.4,y:17.1}).wait(1).to({graphics:mask_graphics_52,x:134.1,y:17.1}).wait(1).to({graphics:mask_graphics_53,x:137.8,y:17.1}).wait(1).to({graphics:mask_graphics_54,x:141.5,y:17.1}).wait(1).to({graphics:mask_graphics_55,x:145.2,y:17.1}).wait(1).to({graphics:mask_graphics_56,x:148.9,y:17.1}).wait(1).to({graphics:mask_graphics_57,x:152.6,y:17.1}).wait(1).to({graphics:mask_graphics_58,x:156.3,y:17.1}).wait(1).to({graphics:mask_graphics_59,x:160,y:17.1}).wait(1).to({graphics:mask_graphics_60,x:163.7,y:17.1}).wait(1).to({graphics:mask_graphics_61,x:167.4,y:17.1}).wait(1).to({graphics:mask_graphics_62,x:171.1,y:17.1}).wait(1).to({graphics:mask_graphics_63,x:174.9,y:17.1}).wait(1).to({graphics:mask_graphics_64,x:178.6,y:17.1}).wait(1).to({graphics:mask_graphics_65,x:182.3,y:17.1}).wait(1).to({graphics:mask_graphics_66,x:186,y:17.1}).wait(1).to({graphics:mask_graphics_67,x:189.7,y:17.1}).wait(1).to({graphics:mask_graphics_68,x:193.4,y:17.1}).wait(1).to({graphics:mask_graphics_69,x:197.1,y:17.1}).wait(1).to({graphics:mask_graphics_70,x:200.8,y:17.1}).wait(1).to({graphics:mask_graphics_71,x:204.5,y:17.1}).wait(1).to({graphics:mask_graphics_72,x:208.2,y:17.1}).wait(1).to({graphics:mask_graphics_73,x:211.9,y:17.1}).wait(1).to({graphics:mask_graphics_74,x:215.6,y:17.1}).wait(1));

	// Capa 1
	//this.text = new cjs.Text(txt["f16_02"], "italic 20px Verdana");
	//this.text.textAlign = "center";
	//this.text.lineHeight = 20;
	//this.text.lineWidth = 431;
	//this.text.setTransform(215.6,0);

  html = createDiv(txt["f16_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-150,-570);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(75));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,435.1,36.8);

(lib.mc_h0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._3_shutterstock_61371553();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,675,375);

(lib.btn_solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f12_02"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-14.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(9.3,-3,1.096,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(9.3,-3,1.096,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(9.3,-3,1.096,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.6,-18.1,130,30);

    
(lib.shape587 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.image586).s();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);

    
(lib.mc_f3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgvD3IAAntIBfAAIAAHtg");
	var mask_graphics_1 = new cjs.Graphics().p("AhKD3IAAntICVAAIAAHtg");
	var mask_graphics_2 = new cjs.Graphics().p("AhkD3IAAntIDJAAIAAHtg");
	var mask_graphics_3 = new cjs.Graphics().p("Ah/D3IAAntID/AAIAAHtg");
	var mask_graphics_4 = new cjs.Graphics().p("AiaD3IAAntIE1AAIAAHtg");
	var mask_graphics_5 = new cjs.Graphics().p("Ai0D3IAAntIFpAAIAAHtg");
	var mask_graphics_6 = new cjs.Graphics().p("AjPD3IAAntIGfAAIAAHtg");
	var mask_graphics_7 = new cjs.Graphics().p("AjqD3IAAntIHVAAIAAHtg");
	var mask_graphics_8 = new cjs.Graphics().p("AkED3IAAntIIJAAIAAHtg");
	var mask_graphics_9 = new cjs.Graphics().p("AkfD3IAAntII/AAIAAHtg");
	var mask_graphics_10 = new cjs.Graphics().p("Ak5D3IAAntIJzAAIAAHtg");
	var mask_graphics_11 = new cjs.Graphics().p("AlUD3IAAntIKpAAIAAHtg");
	var mask_graphics_12 = new cjs.Graphics().p("AlvD3IAAntILfAAIAAHtg");
	var mask_graphics_13 = new cjs.Graphics().p("AmJD3IAAntIMTAAIAAHtg");
	var mask_graphics_14 = new cjs.Graphics().p("AmkD3IAAntINJAAIAAHtg");
	var mask_graphics_15 = new cjs.Graphics().p("Am+D3IAAntIN9AAIAAHtg");
	var mask_graphics_16 = new cjs.Graphics().p("AnZD3IAAntIOzAAIAAHtg");
	var mask_graphics_17 = new cjs.Graphics().p("An0D3IAAntIPpAAIAAHtg");
	var mask_graphics_18 = new cjs.Graphics().p("AoOD3IAAntIQdAAIAAHtg");
	var mask_graphics_19 = new cjs.Graphics().p("AopD3IAAntIRTAAIAAHtg");
	var mask_graphics_20 = new cjs.Graphics().p("ApDD3IAAntISHAAIAAHtg");
	var mask_graphics_21 = new cjs.Graphics().p("ApeD3IAAntIS9AAIAAHtg");
	var mask_graphics_22 = new cjs.Graphics().p("Ap5D3IAAntITzAAIAAHtg");
	var mask_graphics_23 = new cjs.Graphics().p("AqTD3IAAntIUnAAIAAHtg");
	var mask_graphics_24 = new cjs.Graphics().p("AquD3IAAntIVdAAIAAHtg");
	var mask_graphics_25 = new cjs.Graphics().p("ArJD3IAAntIWTAAIAAHtg");
	var mask_graphics_26 = new cjs.Graphics().p("ArjD3IAAntIXHAAIAAHtg");
	var mask_graphics_27 = new cjs.Graphics().p("Ar+D3IAAntIX9AAIAAHtg");
	var mask_graphics_28 = new cjs.Graphics().p("AsYD3IAAntIYxAAIAAHtg");
	var mask_graphics_29 = new cjs.Graphics().p("AszD3IAAntIZnAAIAAHtg");
	var mask_graphics_30 = new cjs.Graphics().p("AtOD3IAAntIadAAIAAHtg");
	var mask_graphics_31 = new cjs.Graphics().p("AtoD3IAAntIbRAAIAAHtg");
	var mask_graphics_32 = new cjs.Graphics().p("AuDD3IAAntIcHAAIAAHtg");
	var mask_graphics_33 = new cjs.Graphics().p("AudD3IAAntIc7AAIAAHtg");
	var mask_graphics_34 = new cjs.Graphics().p("Au4D3IAAntIdxAAIAAHtg");
	var mask_graphics_35 = new cjs.Graphics().p("AvTD3IAAntIenAAIAAHtg");
	var mask_graphics_36 = new cjs.Graphics().p("AvtD3IAAntIfbAAIAAHtg");
	var mask_graphics_37 = new cjs.Graphics().p("AwID3IAAntMAgRAAAIAAHtg");
	var mask_graphics_38 = new cjs.Graphics().p("AwiD3IAAntMAhFAAAIAAHtg");
	var mask_graphics_39 = new cjs.Graphics().p("Aw9D3IAAntMAh7AAAIAAHtg");
	var mask_graphics_40 = new cjs.Graphics().p("AxYD3IAAntMAixAAAIAAHtg");
	var mask_graphics_41 = new cjs.Graphics().p("AxyD3IAAntMAjlAAAIAAHtg");
	var mask_graphics_42 = new cjs.Graphics().p("AyND3IAAntMAkbAAAIAAHtg");
	var mask_graphics_43 = new cjs.Graphics().p("AyoD3IAAntMAlRAAAIAAHtg");
	var mask_graphics_44 = new cjs.Graphics().p("AzCD3IAAntMAmFAAAIAAHtg");
	var mask_graphics_45 = new cjs.Graphics().p("AzdD3IAAntMAm7AAAIAAHtg");
	var mask_graphics_46 = new cjs.Graphics().p("Az3D3IAAntMAnvAAAIAAHtg");
	var mask_graphics_47 = new cjs.Graphics().p("A0SD3IAAntMAolAAAIAAHtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-11.3,y:20.5}).wait(1).to({graphics:mask_graphics_1,x:-8.7,y:20.5}).wait(1).to({graphics:mask_graphics_2,x:-6,y:20.5}).wait(1).to({graphics:mask_graphics_3,x:-3.3,y:20.5}).wait(1).to({graphics:mask_graphics_4,x:-0.7,y:20.5}).wait(1).to({graphics:mask_graphics_5,x:1.9,y:20.5}).wait(1).to({graphics:mask_graphics_6,x:4.5,y:20.5}).wait(1).to({graphics:mask_graphics_7,x:7.2,y:20.5}).wait(1).to({graphics:mask_graphics_8,x:9.9,y:20.5}).wait(1).to({graphics:mask_graphics_9,x:12.5,y:20.5}).wait(1).to({graphics:mask_graphics_10,x:15.2,y:20.5}).wait(1).to({graphics:mask_graphics_11,x:17.8,y:20.5}).wait(1).to({graphics:mask_graphics_12,x:20.5,y:20.5}).wait(1).to({graphics:mask_graphics_13,x:23.2,y:20.5}).wait(1).to({graphics:mask_graphics_14,x:25.8,y:20.5}).wait(1).to({graphics:mask_graphics_15,x:28.5,y:20.5}).wait(1).to({graphics:mask_graphics_16,x:31.2,y:20.5}).wait(1).to({graphics:mask_graphics_17,x:33.8,y:20.5}).wait(1).to({graphics:mask_graphics_18,x:36.5,y:20.5}).wait(1).to({graphics:mask_graphics_19,x:39.1,y:20.5}).wait(1).to({graphics:mask_graphics_20,x:41.8,y:20.5}).wait(1).to({graphics:mask_graphics_21,x:44.5,y:20.5}).wait(1).to({graphics:mask_graphics_22,x:47.1,y:20.5}).wait(1).to({graphics:mask_graphics_23,x:49.8,y:20.5}).wait(1).to({graphics:mask_graphics_24,x:52.4,y:20.5}).wait(1).to({graphics:mask_graphics_25,x:55.1,y:20.5}).wait(1).to({graphics:mask_graphics_26,x:57.8,y:20.5}).wait(1).to({graphics:mask_graphics_27,x:60.4,y:20.5}).wait(1).to({graphics:mask_graphics_28,x:63.1,y:20.5}).wait(1).to({graphics:mask_graphics_29,x:65.7,y:20.5}).wait(1).to({graphics:mask_graphics_30,x:68.4,y:20.5}).wait(1).to({graphics:mask_graphics_31,x:71.1,y:20.5}).wait(1).to({graphics:mask_graphics_32,x:73.7,y:20.5}).wait(1).to({graphics:mask_graphics_33,x:76.4,y:20.5}).wait(1).to({graphics:mask_graphics_34,x:79.1,y:20.5}).wait(1).to({graphics:mask_graphics_35,x:81.7,y:20.5}).wait(1).to({graphics:mask_graphics_36,x:84.4,y:20.5}).wait(1).to({graphics:mask_graphics_37,x:87,y:20.5}).wait(1).to({graphics:mask_graphics_38,x:89.7,y:20.5}).wait(1).to({graphics:mask_graphics_39,x:92.4,y:20.5}).wait(1).to({graphics:mask_graphics_40,x:95,y:20.5}).wait(1).to({graphics:mask_graphics_41,x:97.7,y:20.5}).wait(1).to({graphics:mask_graphics_42,x:100.3,y:20.5}).wait(1).to({graphics:mask_graphics_43,x:103,y:20.5}).wait(1).to({graphics:mask_graphics_44,x:105.7,y:20.5}).wait(1).to({graphics:mask_graphics_45,x:108.3,y:20.5}).wait(1).to({graphics:mask_graphics_46,x:111,y:20.5}).wait(1).to({graphics:mask_graphics_47,x:113.7,y:20.5}).wait(69));

	// A ?   B = {2, 4, 5, 6,}
	//this.text = new cjs.Text(txt["f11_02"], "italic 20px Verdana");
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 225;

  html = createDiv(txt["f11_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-270,-570);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(116));

	// mc_f3_01
	this.dado = new lib.dice();
	this.dado.setTransform(114,132.6,1.401,1.401);
	this.dado.alpha = 0;
	this.dado._off = true;

	this.timeline.addTween(cjs.Tween.get(this.dado).wait(17).to({_off:false},0).wait(1).to({x:114.2,alpha:0.143},0).wait(1).to({x:114.4,alpha:0.286},0).wait(1).to({x:114.6,alpha:0.429},0).wait(1).to({x:114.8,alpha:0.571},0).wait(1).to({x:115,alpha:0.714},0).wait(1).to({x:115.2,alpha:0.857},0).wait(1).to({x:115.4,alpha:1},0).wait(62));

	
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,229,63.1);


(lib.dice_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// as
	this.instance = new lib.shape419("synched",0);

	this.instance_1 = new lib.shape421("synched",0);

	this.instance_2 = new lib.shape423("synched",0);

	this.instance_3 = new lib.shape425("synched",0);

	this.instance_4 = new lib.shape427("synched",0);

	this.instance_5 = new lib.shape429("synched",0);

	this.instance_6 = new lib.shape431("synched",0);

	this.instance_7 = new lib.shape433("synched",0);

	this.instance_8 = new lib.shape435("synched",0);

	this.instance_9 = new lib.shape437("synched",0);

	this.instance_10 = new lib.shape439("synched",0);

	this.instance_11 = new lib.shape441("synched",0);

	this.instance_12 = new lib.shape443("synched",0);

	this.instance_13 = new lib.shape587("synched",0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},13).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).wait(1));

	// Layer 1
	this.instance_14 = new lib.shape419("synched",0);

	this.instance_15 = new lib.shape421("synched",0);

	this.instance_16 = new lib.shape423("synched",0);

	this.instance_17 = new lib.shape425("synched",0);

	this.instance_18 = new lib.shape427("synched",0);

	this.instance_19 = new lib.shape429("synched",0);

	this.instance_20 = new lib.shape431("synched",0);

	this.instance_21 = new lib.shape433("synched",0);

	this.instance_22 = new lib.shape435("synched",0);

	this.instance_23 = new lib.shape437("synched",0);

	this.instance_24 = new lib.shape439("synched",0);

	this.instance_25 = new lib.shape441("synched",0);

	this.instance_26 = new lib.shape443("synched",0);

	this.instance_27 = new lib.shape445("synched",0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[]},1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);

(lib.mc_f2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgoC8IAAl3IBRAAIAAF3g");
	var mask_graphics_1 = new cjs.Graphics().p("Ag/C8IAAl3IB/AAIAAF3g");
	var mask_graphics_2 = new cjs.Graphics().p("AhWC8IAAl3ICtAAIAAF3g");
	var mask_graphics_3 = new cjs.Graphics().p("AhtC8IAAl3IDbAAIAAF3g");
	var mask_graphics_4 = new cjs.Graphics().p("AiEC8IAAl3IEJAAIAAF3g");
	var mask_graphics_5 = new cjs.Graphics().p("AibC8IAAl3IE3AAIAAF3g");
	var mask_graphics_6 = new cjs.Graphics().p("AiyC8IAAl3IFlAAIAAF3g");
	var mask_graphics_7 = new cjs.Graphics().p("AjJC8IAAl3IGTAAIAAF3g");
	var mask_graphics_8 = new cjs.Graphics().p("AjgC8IAAl3IHBAAIAAF3g");
	var mask_graphics_9 = new cjs.Graphics().p("Aj3C8IAAl3IHvAAIAAF3g");
	var mask_graphics_10 = new cjs.Graphics().p("AkOC8IAAl3IIdAAIAAF3g");
	var mask_graphics_11 = new cjs.Graphics().p("AklC8IAAl3IJLAAIAAF3g");
	var mask_graphics_12 = new cjs.Graphics().p("Ak8C8IAAl3IJ5AAIAAF3g");
	var mask_graphics_13 = new cjs.Graphics().p("AlTC8IAAl3IKnAAIAAF3g");
	var mask_graphics_14 = new cjs.Graphics().p("AlqC8IAAl3ILVAAIAAF3g");
	var mask_graphics_15 = new cjs.Graphics().p("AmBC8IAAl3IMDAAIAAF3g");
	var mask_graphics_16 = new cjs.Graphics().p("AmYC8IAAl3IMxAAIAAF3g");
	var mask_graphics_17 = new cjs.Graphics().p("AmvC8IAAl3INfAAIAAF3g");
	var mask_graphics_18 = new cjs.Graphics().p("AnGC8IAAl3IONAAIAAF3g");
	var mask_graphics_19 = new cjs.Graphics().p("AndC8IAAl3IO7AAIAAF3g");
	var mask_graphics_20 = new cjs.Graphics().p("An0C8IAAl3IPpAAIAAF3g");
	var mask_graphics_21 = new cjs.Graphics().p("AoLC8IAAl3IQXAAIAAF3g");
	var mask_graphics_22 = new cjs.Graphics().p("AoiC8IAAl3IRFAAIAAF3g");
	var mask_graphics_23 = new cjs.Graphics().p("Ao5C8IAAl3IRzAAIAAF3g");
	var mask_graphics_24 = new cjs.Graphics().p("ApPC8IAAl3ISfAAIAAF3g");
	var mask_graphics_25 = new cjs.Graphics().p("ApmC8IAAl3ITNAAIAAF3g");
	var mask_graphics_26 = new cjs.Graphics().p("Ap9C8IAAl3IT7AAIAAF3g");
	var mask_graphics_27 = new cjs.Graphics().p("AqUC8IAAl3IUpAAIAAF3g");
	var mask_graphics_28 = new cjs.Graphics().p("AqrC8IAAl3IVXAAIAAF3g");
	var mask_graphics_29 = new cjs.Graphics().p("ArCC8IAAl3IWFAAIAAF3g");
	var mask_graphics_30 = new cjs.Graphics().p("ArZC8IAAl3IWzAAIAAF3g");
	var mask_graphics_31 = new cjs.Graphics().p("ArwC8IAAl3IXhAAIAAF3g");
	var mask_graphics_32 = new cjs.Graphics().p("AsHC8IAAl3IYPAAIAAF3g");
	var mask_graphics_61 = new cjs.Graphics().p("AsHGzIAAl4IDYAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_62 = new cjs.Graphics().p("AsHGzIAAl4IEFAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_63 = new cjs.Graphics().p("AsHGzIAAl4IEyAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_64 = new cjs.Graphics().p("AsHGzIAAl4IFfAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_65 = new cjs.Graphics().p("AsHGzIAAl4IGMAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_66 = new cjs.Graphics().p("AsHGzIAAl4IG6AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_67 = new cjs.Graphics().p("AsHGzIAAl4IHnAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_68 = new cjs.Graphics().p("AsHGzIAAl4IIUAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_69 = new cjs.Graphics().p("AsHGzIAAl4IJBAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_70 = new cjs.Graphics().p("AsHGzIAAl4IJuAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_71 = new cjs.Graphics().p("AsHGzIAAl4IKbAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_72 = new cjs.Graphics().p("AsHGzIAAl4ILJAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_73 = new cjs.Graphics().p("AsHGzIAAl4IL2AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_74 = new cjs.Graphics().p("AsHGzIAAl4IMhAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_75 = new cjs.Graphics().p("AsHGzIAAl4INOAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_76 = new cjs.Graphics().p("AsHGzIAAl4IN7AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_77 = new cjs.Graphics().p("AsHGzIAAl4IOpAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_78 = new cjs.Graphics().p("AsHGzIAAl4IPWAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_79 = new cjs.Graphics().p("AsHGzIAAl4IQDAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_80 = new cjs.Graphics().p("AsHGzIAAl4IQwAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_81 = new cjs.Graphics().p("AsHGzIAAl4IRdAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_82 = new cjs.Graphics().p("AsHGzIAAl4ISKAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_83 = new cjs.Graphics().p("AsHGzIAAl4IS4AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_84 = new cjs.Graphics().p("AsHGzIAAl4ITlAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_85 = new cjs.Graphics().p("AsHGzIAAl4IUSAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_86 = new cjs.Graphics().p("AsHGzIAAl4IU/AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_87 = new cjs.Graphics().p("AsHGzIAAl4IVsAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_88 = new cjs.Graphics().p("AsHGzIAAl4IWZAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_89 = new cjs.Graphics().p("AsHGzIAAl4IXHAAIAAF4gAsHg6IAAl4IYPAAIAAF4g");
	var mask_graphics_90 = new cjs.Graphics().p("AsHGzIAAl4IX0AAIAAF4gAsHg6IAAl4IYPAAIAAF4g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-1.1,y:135.9}).wait(1).to({graphics:mask_graphics_1,x:1.1,y:135.9}).wait(1).to({graphics:mask_graphics_2,x:3.4,y:135.9}).wait(1).to({graphics:mask_graphics_3,x:5.7,y:135.9}).wait(1).to({graphics:mask_graphics_4,x:8,y:135.9}).wait(1).to({graphics:mask_graphics_5,x:10.3,y:135.9}).wait(1).to({graphics:mask_graphics_6,x:12.6,y:135.9}).wait(1).to({graphics:mask_graphics_7,x:14.9,y:135.9}).wait(1).to({graphics:mask_graphics_8,x:17.2,y:135.9}).wait(1).to({graphics:mask_graphics_9,x:19.5,y:135.9}).wait(1).to({graphics:mask_graphics_10,x:21.8,y:135.9}).wait(1).to({graphics:mask_graphics_11,x:24.1,y:135.9}).wait(1).to({graphics:mask_graphics_12,x:26.4,y:135.9}).wait(1).to({graphics:mask_graphics_13,x:28.7,y:135.9}).wait(1).to({graphics:mask_graphics_14,x:31,y:135.9}).wait(1).to({graphics:mask_graphics_15,x:33.3,y:135.9}).wait(1).to({graphics:mask_graphics_16,x:35.6,y:135.9}).wait(1).to({graphics:mask_graphics_17,x:37.9,y:135.9}).wait(1).to({graphics:mask_graphics_18,x:40.2,y:135.9}).wait(1).to({graphics:mask_graphics_19,x:42.5,y:135.9}).wait(1).to({graphics:mask_graphics_20,x:44.8,y:135.9}).wait(1).to({graphics:mask_graphics_21,x:47.1,y:135.9}).wait(1).to({graphics:mask_graphics_22,x:49.4,y:135.9}).wait(1).to({graphics:mask_graphics_23,x:51.7,y:135.9}).wait(1).to({graphics:mask_graphics_24,x:54,y:135.9}).wait(1).to({graphics:mask_graphics_25,x:56.2,y:135.9}).wait(1).to({graphics:mask_graphics_26,x:58.5,y:135.9}).wait(1).to({graphics:mask_graphics_27,x:60.8,y:135.9}).wait(1).to({graphics:mask_graphics_28,x:63.1,y:135.9}).wait(1).to({graphics:mask_graphics_29,x:65.4,y:135.9}).wait(1).to({graphics:mask_graphics_30,x:67.7,y:135.9}).wait(1).to({graphics:mask_graphics_31,x:70,y:135.9}).wait(1).to({graphics:mask_graphics_32,x:72.3,y:135.9}).wait(29).to({graphics:mask_graphics_61,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_62,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_63,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_64,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_65,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_66,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_67,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_68,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_69,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_70,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_71,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_72,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_73,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_74,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_75,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_76,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_77,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_78,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_79,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_80,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_81,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_82,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_83,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_84,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_85,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_86,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_87,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_88,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_89,x:72.3,y:160.7}).wait(1).to({graphics:mask_graphics_90,x:72.3,y:160.7}).wait(74));

	// A = {2,4,6}  B = {5,6}
	//this.text = new cjs.Text(txt["f10_02"], "italic 20px Verdana");
	//this.text.textAlign = "center";
	//this.text.lineHeight = 22;
	//this.text.lineWidth = 143;
	//this.text.setTransform(71.3,121.3);
  
  html = createDiv(txt["f10_02"], "Verdana", "20px", '200px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(0,-470);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(164));

	// mc_f0
	this.instance = new lib.mc_f0();
	this.instance.setTransform(469.3,187.5,1,1,0,0,0,199.3,187.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(01).wait(1).to({alpha:0.05},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.15},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.35},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.45},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.55},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.65},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.85},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:0.95},0).wait(1).to({alpha:1},0).wait(43));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,668.5,375);


(lib.mc_f0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._2_shutterstock_38323795();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,398.5,375);


(lib._1_shutterstock_48807301 = function() {
	this.initialize(img._1_shutterstock_48807301);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1001,750);

(lib._2_shutterstock_38323795 = function() {
	this.initialize(img._2_shutterstock_38323795);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,797,750);

(lib._3_shutterstock_61371553 = function() {
	this.initialize(img._3_shutterstock_61371553);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1350,750);

(lib._4_shutterstock_25332253 = function() {
	this.initialize(img._4_shutterstock_25332253);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1212,750);


(lib.image412 = function() {
	this.initialize(img.image412);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image418 = function() {
	this.initialize(img.image418);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image420 = function() {
	this.initialize(img.image420);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image422 = function() {
	this.initialize(img.image422);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image424 = function() {
	this.initialize(img.image424);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image426 = function() {
	this.initialize(img.image426);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image428 = function() {
	this.initialize(img.image428);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image430 = function() {
	this.initialize(img.image430);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image432 = function() {
	this.initialize(img.image432);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image434 = function() {
	this.initialize(img.image434);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image436 = function() {
	this.initialize(img.image436);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image438 = function() {
	this.initialize(img.image438);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image440 = function() {
	this.initialize(img.image440);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image442 = function() {
	this.initialize(img.image442);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.image444 = function() {
	this.initialize(img.image444);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape445 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image444();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape443 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image442();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape441 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image440();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape439 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image438();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape437 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image436();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape435 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image434();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape433 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image432();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape431 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image430();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape429 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image428();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape427 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image426();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape425 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image424();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape423 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image422();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape421 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image420();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape419 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image418();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.shape413 = function() {
	this.initialize();

	// Layer 1
	this.shape = new lib.image412();

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.dice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// as
	this.instance = new lib.shape419("synched",0);
	this.instance_1 = new lib.shape421("synched",0);
	this.instance_2 = new lib.shape423("synched",0);
	this.instance_3 = new lib.shape425("synched",0);
	this.instance_4 = new lib.shape427("synched",0);
	this.instance_5 = new lib.shape429("synched",0);
	this.instance_6 = new lib.shape431("synched",0);
	this.instance_7 = new lib.shape433("synched",0);
	this.instance_8 = new lib.shape435("synched",0);
	this.instance_9 = new lib.shape437("synched",0);
	this.instance_10 = new lib.shape439("synched",0);
	this.instance_11 = new lib.shape441("synched",0);
	this.instance_12 = new lib.shape443("synched",0);
	this.instance_13 = new lib.image412();
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},13).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).wait(1));

	// Layer 1
	this.instance_14 = new lib.shape419("synched",0);
	this.instance_15 = new lib.shape421("synched",0);
	this.instance_16 = new lib.shape423("synched",0);
	this.instance_17 = new lib.shape425("synched",0);
	this.instance_18 = new lib.shape427("synched",0);
	this.instance_19 = new lib.shape429("synched",0);
	this.instance_20 = new lib.shape431("synched",0);
	this.instance_21 = new lib.shape433("synched",0);
	this.instance_22 = new lib.shape435("synched",0);
	this.instance_23 = new lib.shape437("synched",0);
	this.instance_24 = new lib.shape439("synched",0);
	this.instance_25 = new lib.shape441("synched",0);
	this.instance_26 = new lib.shape443("synched",0);
	this.instance_27 = new lib.shape445("synched",0);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_14}]}).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[]},1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,80,80);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 8;
	this.text.setTransform(13.1,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape.setTransform(15,15.9,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(15,15.9,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,30,30.7);


(lib.mc_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgTD/IAAn9IAnAAIAAH9g");
	var mask_graphics_1 = new cjs.Graphics().p("AglD/IAAn9IBLAAIAAH9g");
	var mask_graphics_2 = new cjs.Graphics().p("Ag2D/IAAn9IBtAAIAAH9g");
	var mask_graphics_3 = new cjs.Graphics().p("AhID/IAAn9ICRAAIAAH9g");
	var mask_graphics_4 = new cjs.Graphics().p("AhZD/IAAn9ICzAAIAAH9g");
	var mask_graphics_5 = new cjs.Graphics().p("AhrD/IAAn9IDXAAIAAH9g");
	var mask_graphics_6 = new cjs.Graphics().p("Ah8D/IAAn9ID5AAIAAH9g");
	var mask_graphics_7 = new cjs.Graphics().p("AiND/IAAn9IEbAAIAAH9g");
	var mask_graphics_8 = new cjs.Graphics().p("AifD/IAAn9IE/AAIAAH9g");
	var mask_graphics_9 = new cjs.Graphics().p("AiwD/IAAn9IFhAAIAAH9g");
	var mask_graphics_10 = new cjs.Graphics().p("AjCD/IAAn9IGFAAIAAH9g");
	var mask_graphics_11 = new cjs.Graphics().p("AjTD/IAAn9IGnAAIAAH9g");
	var mask_graphics_12 = new cjs.Graphics().p("AjlD/IAAn9IHLAAIAAH9g");
	var mask_graphics_13 = new cjs.Graphics().p("Aj2D/IAAn9IHtAAIAAH9g");
	var mask_graphics_14 = new cjs.Graphics().p("AkID/IAAn9IIRAAIAAH9g");
	var mask_graphics_15 = new cjs.Graphics().p("AkZD/IAAn9IIzAAIAAH9g");
	var mask_graphics_16 = new cjs.Graphics().p("AkrD/IAAn9IJXAAIAAH9g");
	var mask_graphics_17 = new cjs.Graphics().p("Ak8D/IAAn9IJ5AAIAAH9g");
	var mask_graphics_18 = new cjs.Graphics().p("AlND/IAAn9IKbAAIAAH9g");
	var mask_graphics_19 = new cjs.Graphics().p("AlfD/IAAn9IK/AAIAAH9g");
	var mask_graphics_20 = new cjs.Graphics().p("AlwD/IAAn9ILhAAIAAH9g");
	var mask_graphics_21 = new cjs.Graphics().p("AmCD/IAAn9IMFAAIAAH9g");
	var mask_graphics_22 = new cjs.Graphics().p("AmTD/IAAn9IMnAAIAAH9g");
	var mask_graphics_23 = new cjs.Graphics().p("AmlD/IAAn9INLAAIAAH9g");
	var mask_graphics_24 = new cjs.Graphics().p("Am2D/IAAn9INtAAIAAH9g");
	var mask_graphics_25 = new cjs.Graphics().p("AnID/IAAn9IORAAIAAH9g");
	var mask_graphics_26 = new cjs.Graphics().p("AnZD/IAAn9IOzAAIAAH9g");
	var mask_graphics_27 = new cjs.Graphics().p("AnrD/IAAn9IPXAAIAAH9g");
	var mask_graphics_39 = new cjs.Graphics().p("AnrD/IAAn9IPXAAIAAH9g");
	var mask_graphics_40 = new cjs.Graphics().p("AnzD/IAAn9IPnAAIAAH9g");
	var mask_graphics_41 = new cjs.Graphics().p("An8D/IAAn9IP5AAIAAH9g");
	var mask_graphics_42 = new cjs.Graphics().p("AoFD/IAAn9IQLAAIAAH9g");
	var mask_graphics_43 = new cjs.Graphics().p("AoOD/IAAn9IQdAAIAAH9g");
	var mask_graphics_44 = new cjs.Graphics().p("AoXD/IAAn9IQvAAIAAH9g");
	var mask_graphics_45 = new cjs.Graphics().p("AogD/IAAn9IRBAAIAAH9g");
	var mask_graphics_46 = new cjs.Graphics().p("AopD/IAAn9IRTAAIAAH9g");
	var mask_graphics_47 = new cjs.Graphics().p("AoyD/IAAn9IRkAAIAAH9g");
	var mask_graphics_48 = new cjs.Graphics().p("Ao6D/IAAn9IR1AAIAAH9g");
	var mask_graphics_49 = new cjs.Graphics().p("ApDD/IAAn9ISHAAIAAH9g");
	var mask_graphics_60 = new cjs.Graphics().p("ApDD/IAAn9ISHAAIAAH9g");
	var mask_graphics_61 = new cjs.Graphics().p("ApVD/IAAn9ISrAAIAAH9g");
	var mask_graphics_62 = new cjs.Graphics().p("ApoD/IAAn9ITRAAIAAH9g");
	var mask_graphics_63 = new cjs.Graphics().p("Ap6D/IAAn9IT1AAIAAH9g");
	var mask_graphics_64 = new cjs.Graphics().p("AqMD/IAAn9IUZAAIAAH9g");
	var mask_graphics_65 = new cjs.Graphics().p("AqeD/IAAn9IU9AAIAAH9g");
	var mask_graphics_66 = new cjs.Graphics().p("AqwD/IAAn9IVhAAIAAH9g");
	var mask_graphics_67 = new cjs.Graphics().p("ArDD/IAAn9IWHAAIAAH9g");
	var mask_graphics_68 = new cjs.Graphics().p("ArVD/IAAn9IWrAAIAAH9g");
	var mask_graphics_69 = new cjs.Graphics().p("ArnD/IAAn9IXPAAIAAH9g");
	var mask_graphics_70 = new cjs.Graphics().p("Ar5D/IAAn9IXzAAIAAH9g");
	var mask_graphics_71 = new cjs.Graphics().p("AsLD/IAAn9IYXAAIAAH9g");
	var mask_graphics_72 = new cjs.Graphics().p("AseD/IAAn9IY9AAIAAH9g");
	var mask_graphics_73 = new cjs.Graphics().p("AswD/IAAn9IZhAAIAAH9g");
	var mask_graphics_74 = new cjs.Graphics().p("AtCD/IAAn9IaFAAIAAH9g");
	var mask_graphics_75 = new cjs.Graphics().p("AtUD/IAAn9IapAAIAAH9g");
	var mask_graphics_76 = new cjs.Graphics().p("AtmD/IAAn9IbNAAIAAH9g");
	var mask_graphics_77 = new cjs.Graphics().p("At5D/IAAn9IbzAAIAAH9g");
	var mask_graphics_78 = new cjs.Graphics().p("AuLD/IAAn9IcXAAIAAH9g");
	var mask_graphics_79 = new cjs.Graphics().p("AudD/IAAn9Ic7AAIAAH9g");
	var mask_graphics_80 = new cjs.Graphics().p("AuvD/IAAn9IdfAAIAAH9g");
	var mask_graphics_81 = new cjs.Graphics().p("AvBD/IAAn9IeDAAIAAH9g");
	var mask_graphics_82 = new cjs.Graphics().p("AvUD/IAAn9IepAAIAAH9g");
	var mask_graphics_83 = new cjs.Graphics().p("AvmD/IAAn9IfNAAIAAH9g");
	var mask_graphics_84 = new cjs.Graphics().p("Av4D/IAAn9IfxAAIAAH9g");
	var mask_graphics_85 = new cjs.Graphics().p("AwKD/IAAn9MAgVAAAIAAH9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-7.2,y:10.7}).wait(1).to({graphics:mask_graphics_1,x:-5.4,y:10.7}).wait(1).to({graphics:mask_graphics_2,x:-3.7,y:10.7}).wait(1).to({graphics:mask_graphics_3,x:-1.9,y:10.7}).wait(1).to({graphics:mask_graphics_4,x:-0.2,y:10.7}).wait(1).to({graphics:mask_graphics_5,x:1.5,y:10.7}).wait(1).to({graphics:mask_graphics_6,x:3.2,y:10.7}).wait(1).to({graphics:mask_graphics_7,x:4.9,y:10.7}).wait(1).to({graphics:mask_graphics_8,x:6.7,y:10.7}).wait(1).to({graphics:mask_graphics_9,x:8.4,y:10.7}).wait(1).to({graphics:mask_graphics_10,x:10.2,y:10.7}).wait(1).to({graphics:mask_graphics_11,x:11.9,y:10.7}).wait(1).to({graphics:mask_graphics_12,x:13.7,y:10.7}).wait(1).to({graphics:mask_graphics_13,x:15.4,y:10.7}).wait(1).to({graphics:mask_graphics_14,x:17.2,y:10.7}).wait(1).to({graphics:mask_graphics_15,x:18.9,y:10.7}).wait(1).to({graphics:mask_graphics_16,x:20.7,y:10.7}).wait(1).to({graphics:mask_graphics_17,x:22.4,y:10.7}).wait(1).to({graphics:mask_graphics_18,x:24.1,y:10.7}).wait(1).to({graphics:mask_graphics_19,x:25.9,y:10.7}).wait(1).to({graphics:mask_graphics_20,x:27.6,y:10.7}).wait(1).to({graphics:mask_graphics_21,x:29.4,y:10.7}).wait(1).to({graphics:mask_graphics_22,x:31.1,y:10.7}).wait(1).to({graphics:mask_graphics_23,x:32.9,y:10.7}).wait(1).to({graphics:mask_graphics_24,x:34.6,y:10.7}).wait(1).to({graphics:mask_graphics_25,x:36.4,y:10.7}).wait(1).to({graphics:mask_graphics_26,x:38.1,y:10.7}).wait(1).to({graphics:mask_graphics_27,x:39.9,y:10.7}).wait(12).to({graphics:mask_graphics_39,x:39.9,y:10.7}).wait(1).to({graphics:mask_graphics_40,x:40.8,y:10.7}).wait(1).to({graphics:mask_graphics_41,x:41.7,y:10.7}).wait(1).to({graphics:mask_graphics_42,x:42.6,y:10.7}).wait(1).to({graphics:mask_graphics_43,x:43.5,y:10.7}).wait(1).to({graphics:mask_graphics_44,x:44.4,y:10.7}).wait(1).to({graphics:mask_graphics_45,x:45.3,y:10.7}).wait(1).to({graphics:mask_graphics_46,x:46.2,y:10.7}).wait(1).to({graphics:mask_graphics_47,x:47.2,y:10.7}).wait(1).to({graphics:mask_graphics_48,x:48.1,y:10.7}).wait(1).to({graphics:mask_graphics_49,x:49,y:10.7}).wait(11).to({graphics:mask_graphics_60,x:49,y:10.7}).wait(1).to({graphics:mask_graphics_61,x:50.8,y:10.7}).wait(1).to({graphics:mask_graphics_62,x:52.6,y:10.7}).wait(1).to({graphics:mask_graphics_63,x:54.4,y:10.7}).wait(1).to({graphics:mask_graphics_64,x:56.2,y:10.7}).wait(1).to({graphics:mask_graphics_65,x:57.9,y:10.7}).wait(1).to({graphics:mask_graphics_66,x:59.7,y:10.7}).wait(1).to({graphics:mask_graphics_67,x:61.5,y:10.7}).wait(1).to({graphics:mask_graphics_68,x:63.3,y:10.7}).wait(1).to({graphics:mask_graphics_69,x:65.1,y:10.7}).wait(1).to({graphics:mask_graphics_70,x:66.9,y:10.7}).wait(1).to({graphics:mask_graphics_71,x:68.7,y:10.7}).wait(1).to({graphics:mask_graphics_72,x:70.5,y:10.7}).wait(1).to({graphics:mask_graphics_73,x:72.3,y:10.7}).wait(1).to({graphics:mask_graphics_74,x:74.1,y:10.7}).wait(1).to({graphics:mask_graphics_75,x:75.9,y:10.7}).wait(1).to({graphics:mask_graphics_76,x:77.7,y:10.7}).wait(1).to({graphics:mask_graphics_77,x:79.5,y:10.7}).wait(1).to({graphics:mask_graphics_78,x:81.3,y:10.7}).wait(1).to({graphics:mask_graphics_79,x:83.1,y:10.7}).wait(1).to({graphics:mask_graphics_80,x:84.9,y:10.7}).wait(1).to({graphics:mask_graphics_81,x:86.6,y:10.7}).wait(1).to({graphics:mask_graphics_82,x:88.4,y:10.7}).wait(1).to({graphics:mask_graphics_83,x:90.2,y:10.7}).wait(1).to({graphics:mask_graphics_84,x:92,y:10.7}).wait(1).to({graphics:mask_graphics_85,x:93.8,y:10.7}).wait(10));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape.setTransform(153,-4,0.233,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AhlAAIDLAA");
	this.shape_1.setTransform(110,-4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINsAA");
	this.shape_2.setTransform(40,-4,0.93,1);

	//this.text = new cjs.Text(txt["f6_02"], "20px Verdana");
	//this.text.lineHeight = 22;
  
  html = createDiv(txt["f6_02"], "Verdana", "20px", '770px', '30px', "20px", "185px", "center");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(-304,-610);

	//this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(95));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,204,36.8);

(lib.mc_p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgsEWIAAorIBZAAIAAIrg");
	var mask_graphics_1 = new cjs.Graphics().p("AhDEWIAAorICHAAIAAIrg");
	var mask_graphics_2 = new cjs.Graphics().p("AhaEWIAAorIC1AAIAAIrg");
	var mask_graphics_3 = new cjs.Graphics().p("AhxEWIAAorIDjAAIAAIrg");
	var mask_graphics_4 = new cjs.Graphics().p("AiIEWIAAorIERAAIAAIrg");
	var mask_graphics_5 = new cjs.Graphics().p("AigEWIAAorIFBAAIAAIrg");
	var mask_graphics_6 = new cjs.Graphics().p("Ai3EWIAAorIFvAAIAAIrg");
	var mask_graphics_7 = new cjs.Graphics().p("AjOEWIAAorIGdAAIAAIrg");
	var mask_graphics_8 = new cjs.Graphics().p("AjlEWIAAorIHLAAIAAIrg");
	var mask_graphics_9 = new cjs.Graphics().p("Aj8EWIAAorIH5AAIAAIrg");
	var mask_graphics_10 = new cjs.Graphics().p("AkTEWIAAorIInAAIAAIrg");
	var mask_graphics_11 = new cjs.Graphics().p("AkrEWIAAorIJXAAIAAIrg");
	var mask_graphics_12 = new cjs.Graphics().p("AlCEWIAAorIKFAAIAAIrg");
	var mask_graphics_13 = new cjs.Graphics().p("AlZEWIAAorIKzAAIAAIrg");
	var mask_graphics_14 = new cjs.Graphics().p("AlwEWIAAorILhAAIAAIrg");
	var mask_graphics_15 = new cjs.Graphics().p("AmHEWIAAorIMPAAIAAIrg");
	var mask_graphics_16 = new cjs.Graphics().p("AmfEWIAAorIM/AAIAAIrg");
	var mask_graphics_17 = new cjs.Graphics().p("Am2EWIAAorINtAAIAAIrg");
	var mask_graphics_18 = new cjs.Graphics().p("AnNEWIAAorIObAAIAAIrg");
	var mask_graphics_19 = new cjs.Graphics().p("AnkEWIAAorIPJAAIAAIrg");
	var mask_graphics_20 = new cjs.Graphics().p("An7EWIAAorIP3AAIAAIrg");
	var mask_graphics_21 = new cjs.Graphics().p("AoSEWIAAorIQlAAIAAIrg");
	var mask_graphics_22 = new cjs.Graphics().p("AoqEWIAAorIRVAAIAAIrg");
	var mask_graphics_23 = new cjs.Graphics().p("ApBEWIAAorISDAAIAAIrg");
	var mask_graphics_39 = new cjs.Graphics().p("ApBEWIAAorISDAAIAAIrg");
	var mask_graphics_40 = new cjs.Graphics().p("ApXEWIAAorISvAAIAAIrg");
	var mask_graphics_41 = new cjs.Graphics().p("ApuEWIAAorITdAAIAAIrg");
	var mask_graphics_42 = new cjs.Graphics().p("AqFEWIAAorIULAAIAAIrg");
	var mask_graphics_43 = new cjs.Graphics().p("AqcEWIAAorIU5AAIAAIrg");
	var mask_graphics_44 = new cjs.Graphics().p("AqyEWIAAorIVlAAIAAIrg");
	var mask_graphics_45 = new cjs.Graphics().p("ArJEWIAAorIWTAAIAAIrg");
	var mask_graphics_46 = new cjs.Graphics().p("ArgEWIAAorIXBAAIAAIrg");
	var mask_graphics_47 = new cjs.Graphics().p("Ar3EWIAAorIXvAAIAAIrg");
	var mask_graphics_48 = new cjs.Graphics().p("AsNEWIAAorIYbAAIAAIrg");
	var mask_graphics_49 = new cjs.Graphics().p("AskEWIAAorIZJAAIAAIrg");
	var mask_graphics_50 = new cjs.Graphics().p("As7EWIAAorIZ3AAIAAIrg");
	var mask_graphics_51 = new cjs.Graphics().p("AtSEWIAAorIalAAIAAIrg");
	var mask_graphics_52 = new cjs.Graphics().p("AtoEWIAAorIbRAAIAAIrg");
	var mask_graphics_53 = new cjs.Graphics().p("At/EWIAAorIb/AAIAAIrg");
	var mask_graphics_54 = new cjs.Graphics().p("AuWEWIAAorIctAAIAAIrg");
	var mask_graphics_55 = new cjs.Graphics().p("AutEWIAAorIdbAAIAAIrg");
	var mask_graphics_56 = new cjs.Graphics().p("AvDEWIAAorIeHAAIAAIrg");
	var mask_graphics_70 = new cjs.Graphics().p("AvDEWIAAorIeHAAIAAIrg");
	var mask_graphics_71 = new cjs.Graphics().p("AvZEWIAAorIezAAIAAIrg");
	var mask_graphics_72 = new cjs.Graphics().p("AvvEWIAAorIffAAIAAIrg");
	var mask_graphics_73 = new cjs.Graphics().p("AwFEWIAAorMAgLAAAIAAIrg");
	var mask_graphics_74 = new cjs.Graphics().p("AwbEWIAAorMAg3AAAIAAIrg");
	var mask_graphics_75 = new cjs.Graphics().p("AwxEWIAAorMAhjAAAIAAIrg");
	var mask_graphics_76 = new cjs.Graphics().p("AxHEWIAAorMAiPAAAIAAIrg");
	var mask_graphics_77 = new cjs.Graphics().p("AxdEWIAAorMAi7AAAIAAIrg");
	var mask_graphics_78 = new cjs.Graphics().p("AxzEWIAAorMAjnAAAIAAIrg");
	var mask_graphics_79 = new cjs.Graphics().p("AyJEWIAAorMAkTAAAIAAIrg");
	var mask_graphics_80 = new cjs.Graphics().p("AyfEWIAAorMAk/AAAIAAIrg");
	var mask_graphics_81 = new cjs.Graphics().p("Ay1EWIAAorMAlrAAAIAAIrg");
	var mask_graphics_82 = new cjs.Graphics().p("AzLEWIAAorMAmXAAAIAAIrg");
	var mask_graphics_83 = new cjs.Graphics().p("AzhEWIAAorMAnDAAAIAAIrg");
	var mask_graphics_84 = new cjs.Graphics().p("Az3EWIAAorMAnvAAAIAAIrg");
	var mask_graphics_85 = new cjs.Graphics().p("A0NEWIAAorMAobAAAIAAIrg");
	var mask_graphics_86 = new cjs.Graphics().p("A0jEWIAAorMApHAAAIAAIrg");
	var mask_graphics_101 = new cjs.Graphics().p("A0jEWIAAorMApHAAAIAAIrg");
	var mask_graphics_102 = new cjs.Graphics().p("A1AEWIAAorMAqBAAAIAAIrg");
	var mask_graphics_103 = new cjs.Graphics().p("A1dEWIAAorMAq7AAAIAAIrg");
	var mask_graphics_104 = new cjs.Graphics().p("A16EWIAAorMAr1AAAIAAIrg");
	var mask_graphics_105 = new cjs.Graphics().p("A2XEWIAAorMAsvAAAIAAIrg");
	var mask_graphics_106 = new cjs.Graphics().p("A20EWIAAorMAtpAAAIAAIrg");
	var mask_graphics_107 = new cjs.Graphics().p("A3REWIAAorMAujAAAIAAIrg");
	var mask_graphics_108 = new cjs.Graphics().p("A3uEWIAAorMAvdAAAIAAIrg");
	var mask_graphics_109 = new cjs.Graphics().p("A4LEWIAAorMAwXAAAIAAIrg");
	var mask_graphics_110 = new cjs.Graphics().p("A4oEWIAAorMAxRAAAIAAIrg");
	var mask_graphics_111 = new cjs.Graphics().p("A5FEWIAAorMAyLAAAIAAIrg");
	var mask_graphics_112 = new cjs.Graphics().p("A5iEWIAAorMAzFAAAIAAIrg");
	var mask_graphics_113 = new cjs.Graphics().p("A5/EWIAAorMAz/AAAIAAIrg");
	var mask_graphics_114 = new cjs.Graphics().p("A6cEWIAAorMA05AAAIAAIrg");
	var mask_graphics_115 = new cjs.Graphics().p("A65EWIAAorMA1zAAAIAAIrg");
	var mask_graphics_116 = new cjs.Graphics().p("A7WEWIAAorMA2tAAAIAAIrg");
	var mask_graphics_117 = new cjs.Graphics().p("A7zEWIAAorMA3nAAAIAAIrg");
	var mask_graphics_118 = new cjs.Graphics().p("A8QEWIAAorMA4hAAAIAAIrg");
	var mask_graphics_119 = new cjs.Graphics().p("A8tEWIAAorMA5bAAAIAAIrg");
	var mask_graphics_120 = new cjs.Graphics().p("A9LEWIAAorMA6XAAAIAAIrg");
	var mask_graphics_121 = new cjs.Graphics().p("A9oEWIAAorMA7RAAAIAAIrg");
	var mask_graphics_122 = new cjs.Graphics().p("A+FEWIAAorMA8LAAAIAAIrg");
	var mask_graphics_123 = new cjs.Graphics().p("A+iEWIAAorMA9FAAAIAAIrg");
	var mask_graphics_124 = new cjs.Graphics().p("A+/EWIAAorMA9/AAAIAAIrg");
	var mask_graphics_125 = new cjs.Graphics().p("A/cEWIAAorMA+5AAAIAAIrg");
	var mask_graphics_126 = new cjs.Graphics().p("A/5EWIAAorMA/zAAAIAAIrg");
	var mask_graphics_127 = new cjs.Graphics().p("EggWAEWIAAorMBAtAAAIAAIrg");
	var mask_graphics_128 = new cjs.Graphics().p("EggzAEWIAAorMBBnAAAIAAIrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-10.9,y:16.8}).wait(1).to({graphics:mask_graphics_1,x:-8.6,y:16.8}).wait(1).to({graphics:mask_graphics_2,x:-6.3,y:16.8}).wait(1).to({graphics:mask_graphics_3,x:-4,y:16.8}).wait(1).to({graphics:mask_graphics_4,x:-1.7,y:16.8}).wait(1).to({graphics:mask_graphics_5,x:0.6,y:16.8}).wait(1).to({graphics:mask_graphics_6,x:2.9,y:16.8}).wait(1).to({graphics:mask_graphics_7,x:5.2,y:16.8}).wait(1).to({graphics:mask_graphics_8,x:7.5,y:16.8}).wait(1).to({graphics:mask_graphics_9,x:9.8,y:16.8}).wait(1).to({graphics:mask_graphics_10,x:12.1,y:16.8}).wait(1).to({graphics:mask_graphics_11,x:14.5,y:16.8}).wait(1).to({graphics:mask_graphics_12,x:16.8,y:16.8}).wait(1).to({graphics:mask_graphics_13,x:19.1,y:16.8}).wait(1).to({graphics:mask_graphics_14,x:21.4,y:16.8}).wait(1).to({graphics:mask_graphics_15,x:23.7,y:16.8}).wait(1).to({graphics:mask_graphics_16,x:26.1,y:16.8}).wait(1).to({graphics:mask_graphics_17,x:28.4,y:16.8}).wait(1).to({graphics:mask_graphics_18,x:30.7,y:16.8}).wait(1).to({graphics:mask_graphics_19,x:33,y:16.8}).wait(1).to({graphics:mask_graphics_20,x:35.3,y:16.8}).wait(1).to({graphics:mask_graphics_21,x:37.6,y:16.8}).wait(1).to({graphics:mask_graphics_22,x:40,y:16.8}).wait(1).to({graphics:mask_graphics_23,x:42.3,y:16.8}).wait(16).to({graphics:mask_graphics_39,x:42.3,y:16.8}).wait(1).to({graphics:mask_graphics_40,x:44.6,y:16.8}).wait(1).to({graphics:mask_graphics_41,x:46.8,y:16.8}).wait(1).to({graphics:mask_graphics_42,x:49.1,y:16.8}).wait(1).to({graphics:mask_graphics_43,x:51.4,y:16.8}).wait(1).to({graphics:mask_graphics_44,x:53.7,y:16.8}).wait(1).to({graphics:mask_graphics_45,x:55.9,y:16.8}).wait(1).to({graphics:mask_graphics_46,x:58.2,y:16.8}).wait(1).to({graphics:mask_graphics_47,x:60.5,y:16.8}).wait(1).to({graphics:mask_graphics_48,x:62.8,y:16.8}).wait(1).to({graphics:mask_graphics_49,x:65,y:16.8}).wait(1).to({graphics:mask_graphics_50,x:67.3,y:16.8}).wait(1).to({graphics:mask_graphics_51,x:69.6,y:16.8}).wait(1).to({graphics:mask_graphics_52,x:71.9,y:16.8}).wait(1).to({graphics:mask_graphics_53,x:74.1,y:16.8}).wait(1).to({graphics:mask_graphics_54,x:76.4,y:16.8}).wait(1).to({graphics:mask_graphics_55,x:78.7,y:16.8}).wait(1).to({graphics:mask_graphics_56,x:81,y:16.8}).wait(14).to({graphics:mask_graphics_70,x:81,y:16.8}).wait(1).to({graphics:mask_graphics_71,x:83.1,y:16.8}).wait(1).to({graphics:mask_graphics_72,x:85.3,y:16.8}).wait(1).to({graphics:mask_graphics_73,x:87.5,y:16.8}).wait(1).to({graphics:mask_graphics_74,x:89.7,y:16.8}).wait(1).to({graphics:mask_graphics_75,x:91.8,y:16.8}).wait(1).to({graphics:mask_graphics_76,x:94,y:16.8}).wait(1).to({graphics:mask_graphics_77,x:96.2,y:16.8}).wait(1).to({graphics:mask_graphics_78,x:98.3,y:16.8}).wait(1).to({graphics:mask_graphics_79,x:100.5,y:16.8}).wait(1).to({graphics:mask_graphics_80,x:102.7,y:16.8}).wait(1).to({graphics:mask_graphics_81,x:104.8,y:16.8}).wait(1).to({graphics:mask_graphics_82,x:107,y:16.8}).wait(1).to({graphics:mask_graphics_83,x:109.2,y:16.8}).wait(1).to({graphics:mask_graphics_84,x:111.4,y:16.8}).wait(1).to({graphics:mask_graphics_85,x:113.5,y:16.8}).wait(1).to({graphics:mask_graphics_86,x:115.7,y:16.8}).wait(15).to({graphics:mask_graphics_101,x:115.7,y:16.8}).wait(1).to({graphics:mask_graphics_102,x:118.6,y:16.8}).wait(1).to({graphics:mask_graphics_103,x:121.5,y:16.8}).wait(1).to({graphics:mask_graphics_104,x:124.4,y:16.8}).wait(1).to({graphics:mask_graphics_105,x:127.3,y:16.8}).wait(1).to({graphics:mask_graphics_106,x:130.2,y:16.8}).wait(1).to({graphics:mask_graphics_107,x:133.1,y:16.8}).wait(1).to({graphics:mask_graphics_108,x:136,y:16.8}).wait(1).to({graphics:mask_graphics_109,x:138.9,y:16.8}).wait(1).to({graphics:mask_graphics_110,x:141.8,y:16.8}).wait(1).to({graphics:mask_graphics_111,x:144.7,y:16.8}).wait(1).to({graphics:mask_graphics_112,x:147.6,y:16.8}).wait(1).to({graphics:mask_graphics_113,x:150.5,y:16.8}).wait(1).to({graphics:mask_graphics_114,x:153.4,y:16.8}).wait(1).to({graphics:mask_graphics_115,x:156.3,y:16.8}).wait(1).to({graphics:mask_graphics_116,x:159.2,y:16.8}).wait(1).to({graphics:mask_graphics_117,x:162.1,y:16.8}).wait(1).to({graphics:mask_graphics_118,x:165,y:16.8}).wait(1).to({graphics:mask_graphics_119,x:168,y:16.8}).wait(1).to({graphics:mask_graphics_120,x:170.9,y:16.8}).wait(1).to({graphics:mask_graphics_121,x:173.8,y:16.8}).wait(1).to({graphics:mask_graphics_122,x:176.7,y:16.8}).wait(1).to({graphics:mask_graphics_123,x:179.6,y:16.8}).wait(1).to({graphics:mask_graphics_124,x:182.5,y:16.8}).wait(1).to({graphics:mask_graphics_125,x:185.4,y:16.8}).wait(1).to({graphics:mask_graphics_126,x:188.3,y:16.8}).wait(1).to({graphics:mask_graphics_127,x:191.2,y:16.8}).wait(1).to({graphics:mask_graphics_128,x:194.1,y:16.8}).wait(47));

	// Capa 1
	//this.text = new cjs.Text(txt["f5_02"], "italic 20px Verdana");
	//this.text.lineHeight = 22;
	//this.text.setTransform(2.8,0);

  html = createDiv(txt["f5_02"], "Verdana", "20px", '470px', '30px', "20px", "185px", "left");
  this.text = new cjs.DOMElement(html);
  this.text.setTransform(40,-610);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(175));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.8,0,393,36.8);

(lib.mc_p2_01 = function() {
	this.initialize();

	// Capa 1
	/*this.text = new cjs.Text(txt["f4_02"], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 790;*/
  parrafo(this,txt["f4_02"], "20px", 10, -630);


	this.addChild(this.texto);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,794.3,89.4);


(lib.mc_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhuE9IAAp5IDeAAIAAJ5g");
	var mask_graphics_27 = new cjs.Graphics().p("AhuE9IAAp5IDeAAIAAJ5g");
	var mask_graphics_28 = new cjs.Graphics().p("AiFE9IAAp5IELAAIAAJ5g");
	var mask_graphics_29 = new cjs.Graphics().p("AibE9IAAp5IE3AAIAAJ5g");
	var mask_graphics_30 = new cjs.Graphics().p("AiyE9IAAp5IFlAAIAAJ5g");
	var mask_graphics_31 = new cjs.Graphics().p("AjIE9IAAp5IGRAAIAAJ5g");
	var mask_graphics_32 = new cjs.Graphics().p("AjeE9IAAp5IG9AAIAAJ5g");
	var mask_graphics_33 = new cjs.Graphics().p("Aj1E9IAAp5IHrAAIAAJ5g");
	var mask_graphics_34 = new cjs.Graphics().p("AkLE9IAAp5IIXAAIAAJ5g");
	var mask_graphics_35 = new cjs.Graphics().p("AkhE9IAAp5IJDAAIAAJ5g");
	var mask_graphics_36 = new cjs.Graphics().p("Ak4E9IAAp5IJxAAIAAJ5g");
	var mask_graphics_37 = new cjs.Graphics().p("AlOE9IAAp5IKdAAIAAJ5g");
	var mask_graphics_38 = new cjs.Graphics().p("AllE9IAAp5ILLAAIAAJ5g");
	var mask_graphics_39 = new cjs.Graphics().p("Al7E9IAAp5IL3AAIAAJ5g");
	var mask_graphics_40 = new cjs.Graphics().p("AmRE9IAAp5IMjAAIAAJ5g");
	var mask_graphics_41 = new cjs.Graphics().p("AmoE9IAAp5INRAAIAAJ5g");
	var mask_graphics_42 = new cjs.Graphics().p("Am+E9IAAp5IN9AAIAAJ5g");
	var mask_graphics_43 = new cjs.Graphics().p("AnUE9IAAp5IOpAAIAAJ5g");
	var mask_graphics_44 = new cjs.Graphics().p("AnrE9IAAp5IPXAAIAAJ5g");
	var mask_graphics_45 = new cjs.Graphics().p("AoBE9IAAp5IQDAAIAAJ5g");
	var mask_graphics_46 = new cjs.Graphics().p("AoXE9IAAp5IQvAAIAAJ5g");
	var mask_graphics_47 = new cjs.Graphics().p("AouE9IAAp5IRdAAIAAJ5g");
	var mask_graphics_48 = new cjs.Graphics().p("ApEE9IAAp5ISJAAIAAJ5g");
	var mask_graphics_49 = new cjs.Graphics().p("ApbE9IAAp5IS3AAIAAJ5g");
	var mask_graphics_50 = new cjs.Graphics().p("ApxE9IAAp5ITjAAIAAJ5g");
	var mask_graphics_51 = new cjs.Graphics().p("AHkRNIAAp7IUSAAIAAJ7g");
	var mask_graphics_69 = new cjs.Graphics().p("AHkRNIAAp7IUSAAIAAJ7g");
	var mask_graphics_70 = new cjs.Graphics().p("AqeE9IAAp5IU9AAIAAJ5g");
	var mask_graphics_71 = new cjs.Graphics().p("Aq0E9IAAp5IVpAAIAAJ5g");
	var mask_graphics_72 = new cjs.Graphics().p("ArLE9IAAp5IWXAAIAAJ5g");
	var mask_graphics_73 = new cjs.Graphics().p("ArhE9IAAp5IXDAAIAAJ5g");
	var mask_graphics_74 = new cjs.Graphics().p("Ar4E9IAAp5IXxAAIAAJ5g");
	var mask_graphics_75 = new cjs.Graphics().p("AsPE9IAAp5IYfAAIAAJ5g");
	var mask_graphics_76 = new cjs.Graphics().p("AslE9IAAp5IZLAAIAAJ5g");
	var mask_graphics_77 = new cjs.Graphics().p("As8E9IAAp5IZ5AAIAAJ5g");
	var mask_graphics_78 = new cjs.Graphics().p("AtSE9IAAp5IalAAIAAJ5g");
	var mask_graphics_79 = new cjs.Graphics().p("AtpE9IAAp5IbTAAIAAJ5g");
	var mask_graphics_80 = new cjs.Graphics().p("At/E9IAAp5Ib/AAIAAJ5g");
	var mask_graphics_81 = new cjs.Graphics().p("AuWE9IAAp5IctAAIAAJ5g");
	var mask_graphics_82 = new cjs.Graphics().p("AutE9IAAp5IdbAAIAAJ5g");
	var mask_graphics_83 = new cjs.Graphics().p("AvDE9IAAp5IeHAAIAAJ5g");
	var mask_graphics_84 = new cjs.Graphics().p("AvaE9IAAp5Ie1AAIAAJ5g");
	var mask_graphics_85 = new cjs.Graphics().p("AvwE9IAAp5IfhAAIAAJ5g");
	var mask_graphics_86 = new cjs.Graphics().p("ABlRNIAAp7MAgQAAAIAAJ7g");
	var mask_graphics_103 = new cjs.Graphics().p("ABlRNIAAp7MAgQAAAIAAJ7g");
	var mask_graphics_104 = new cjs.Graphics().p("AweE9IAAp5MAg9AAAIAAJ5g");
	var mask_graphics_105 = new cjs.Graphics().p("Aw1E9IAAp5MAhrAAAIAAJ5g");
	var mask_graphics_106 = new cjs.Graphics().p("AxNE9IAAp5MAibAAAIAAJ5g");
	var mask_graphics_107 = new cjs.Graphics().p("AxkE9IAAp5MAjJAAAIAAJ5g");
	var mask_graphics_108 = new cjs.Graphics().p("Ax7E9IAAp5MAj3AAAIAAJ5g");
	var mask_graphics_109 = new cjs.Graphics().p("AyTE9IAAp5MAknAAAIAAJ5g");
	var mask_graphics_110 = new cjs.Graphics().p("AyqE9IAAp5MAlVAAAIAAJ5g");
	var mask_graphics_111 = new cjs.Graphics().p("AzBE9IAAp5MAmDAAAIAAJ5g");
	var mask_graphics_112 = new cjs.Graphics().p("AzZE9IAAp5MAmzAAAIAAJ5g");
	var mask_graphics_113 = new cjs.Graphics().p("AzwE9IAAp5MAnhAAAIAAJ5g");
	var mask_graphics_114 = new cjs.Graphics().p("A0HE9IAAp5MAoPAAAIAAJ5g");
	var mask_graphics_115 = new cjs.Graphics().p("A0fE9IAAp5MAo/AAAIAAJ5g");
	var mask_graphics_116 = new cjs.Graphics().p("A02E9IAAp5MAptAAAIAAJ5g");
	var mask_graphics_117 = new cjs.Graphics().p("A1NE9IAAp5MAqbAAAIAAJ5g");
	var mask_graphics_118 = new cjs.Graphics().p("A1lE9IAAp5MArLAAAIAAJ5g");
	var mask_graphics_119 = new cjs.Graphics().p("A18E9IAAp5MAr5AAAIAAJ5g");
	var mask_graphics_120 = new cjs.Graphics().p("AkmRNIAAp7MAsnAAAIAAJ7g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:237.9,y:188.5}).wait(27).to({graphics:mask_graphics_27,x:237.9,y:188.5}).wait(1).to({graphics:mask_graphics_28,x:240.1,y:188.5}).wait(1).to({graphics:mask_graphics_29,x:242.4,y:188.5}).wait(1).to({graphics:mask_graphics_30,x:244.6,y:188.5}).wait(1).to({graphics:mask_graphics_31,x:246.8,y:188.5}).wait(1).to({graphics:mask_graphics_32,x:249.1,y:188.5}).wait(1).to({graphics:mask_graphics_33,x:251.3,y:188.5}).wait(1).to({graphics:mask_graphics_34,x:253.6,y:188.5}).wait(1).to({graphics:mask_graphics_35,x:255.8,y:188.5}).wait(1).to({graphics:mask_graphics_36,x:258,y:188.5}).wait(1).to({graphics:mask_graphics_37,x:260.3,y:188.5}).wait(1).to({graphics:mask_graphics_38,x:262.5,y:188.5}).wait(1).to({graphics:mask_graphics_39,x:264.7,y:188.5}).wait(1).to({graphics:mask_graphics_40,x:267,y:188.5}).wait(1).to({graphics:mask_graphics_41,x:269.2,y:188.5}).wait(1).to({graphics:mask_graphics_42,x:271.4,y:188.5}).wait(1).to({graphics:mask_graphics_43,x:273.7,y:188.5}).wait(1).to({graphics:mask_graphics_44,x:275.9,y:188.5}).wait(1).to({graphics:mask_graphics_45,x:278.2,y:188.5}).wait(1).to({graphics:mask_graphics_46,x:280.4,y:188.5}).wait(1).to({graphics:mask_graphics_47,x:282.6,y:188.5}).wait(1).to({graphics:mask_graphics_48,x:284.9,y:188.5}).wait(1).to({graphics:mask_graphics_49,x:287.1,y:188.5}).wait(1).to({graphics:mask_graphics_50,x:289.3,y:188.5}).wait(1).to({graphics:mask_graphics_51,x:178.2,y:110.1}).wait(18).to({graphics:mask_graphics_69,x:178.2,y:110.1}).wait(1).to({graphics:mask_graphics_70,x:293.8,y:188.5}).wait(1).to({graphics:mask_graphics_71,x:296.1,y:188.5}).wait(1).to({graphics:mask_graphics_72,x:298.3,y:188.5}).wait(1).to({graphics:mask_graphics_73,x:300.6,y:188.5}).wait(1).to({graphics:mask_graphics_74,x:302.9,y:188.5}).wait(1).to({graphics:mask_graphics_75,x:305.1,y:188.5}).wait(1).to({graphics:mask_graphics_76,x:307.4,y:188.5}).wait(1).to({graphics:mask_graphics_77,x:309.6,y:188.5}).wait(1).to({graphics:mask_graphics_78,x:311.9,y:188.5}).wait(1).to({graphics:mask_graphics_79,x:314.1,y:188.5}).wait(1).to({graphics:mask_graphics_80,x:316.4,y:188.5}).wait(1).to({graphics:mask_graphics_81,x:318.6,y:188.5}).wait(1).to({graphics:mask_graphics_82,x:320.9,y:188.5}).wait(1).to({graphics:mask_graphics_83,x:323.2,y:188.5}).wait(1).to({graphics:mask_graphics_84,x:325.4,y:188.5}).wait(1).to({graphics:mask_graphics_85,x:327.7,y:188.5}).wait(1).to({graphics:mask_graphics_86,x:216.6,y:110.1}).wait(17).to({graphics:mask_graphics_103,x:216.6,y:110.1}).wait(1).to({graphics:mask_graphics_104,x:332.2,y:188.5}).wait(1).to({graphics:mask_graphics_105,x:334.6,y:188.5}).wait(1).to({graphics:mask_graphics_106,x:336.9,y:188.5}).wait(1).to({graphics:mask_graphics_107,x:339.2,y:188.5}).wait(1).to({graphics:mask_graphics_108,x:341.5,y:188.5}).wait(1).to({graphics:mask_graphics_109,x:343.9,y:188.5}).wait(1).to({graphics:mask_graphics_110,x:346.2,y:188.5}).wait(1).to({graphics:mask_graphics_111,x:348.5,y:188.5}).wait(1).to({graphics:mask_graphics_112,x:350.8,y:188.5}).wait(1).to({graphics:mask_graphics_113,x:353.2,y:188.5}).wait(1).to({graphics:mask_graphics_114,x:355.5,y:188.5}).wait(1).to({graphics:mask_graphics_115,x:357.8,y:188.5}).wait(1).to({graphics:mask_graphics_116,x:360.1,y:188.5}).wait(1).to({graphics:mask_graphics_117,x:362.5,y:188.5}).wait(1).to({graphics:mask_graphics_118,x:364.8,y:188.5}).wait(1).to({graphics:mask_graphics_119,x:367.1,y:188.5}).wait(1).to({graphics:mask_graphics_120,x:256.1,y:110.1}).wait(70));

	// Capa 2
	this.text = new cjs.Text(txt["f4_03"], "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(253.1,169.3);
var html = createDiv(txt['f4_03'], "Verdana", "20px", '500px', '100px', "20px", "185px", "left");
    this.text = new lib.fadeText(html, 20);
    this.text.setTransform(253, 169-608);
	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(190));

	// Capa 1
	this.instance = new lib.mc_p2_01();
	this.instance.setTransform(393.9,44.5,1,1,0,0,0,393.9,44.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:397.1,regY:44.7,x:397.1,y:44.7,alpha:0.067},0).wait(1).to({alpha:0.133},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.267},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.467},0).wait(1).to({alpha:0.533},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.733},0).wait(1).to({alpha:0.8},0).wait(1).to({x:397,alpha:0.867},0).wait(1).to({alpha:0.933},0).wait(1).to({alpha:1},0).wait(10).wait(1).to({x:396.9},0).wait(11).wait(1).to({x:396.8},0).wait(12).wait(1).to({x:396.7},0).wait(12).wait(1).to({x:396.6},0).wait(11).wait(1).to({x:396.5},0).wait(12).wait(1).to({x:396.4},0).wait(12).wait(1).to({x:396.3},0).wait(11).wait(1).to({x:396.2},0).wait(76));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,794.3,209.7);

(lib.mc_p0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._1_shutterstock_48807301();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,500.5,375);

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }
    function parrafo(escena, texto, size, left, top) {
      var html = createDiv(texto, "Verdana", size, '800px', '400px', "22px", "185px", "left");
      html.style.lineHeight = "1.5em";
      escena.texto = new cjs.DOMElement(html);
      escena.texto.setTransform(left,top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

 (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    
    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
    
(lib.btn_practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f11_03"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-15.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_1.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_2.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.5,-18.1,130.1,30);
   
     (lib.fadeText = function (textohtml,espera,delay,mode, startPosition, loop) {
         espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        this.texto=new cjs.DOMElement(textohtml);
        this.texto.alpha=0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
     (lib.fadeElement = function (elemento,espera,delay,mode, startPosition, loop) {
           espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.btn_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f1_05"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 234;
	this.text.setTransform(120.7,5.5+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape.setTransform(123.4,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_1.setTransform(123.4,27.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_2.setTransform(123.4,27.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.3,-0.3,246.3,56);


(lib.btn_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f1_04"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 242;
	this.text.setTransform(120.9,6.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape.setTransform(123.4,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_1.setTransform(123.4,27.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_2.setTransform(123.4,27.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.3,246.5,56);


(lib.btn_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f1_03"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 241;
	this.text.setTransform(121.1,5.7+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape.setTransform(123.4,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_1.setTransform(123.4,27.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_2.setTransform(123.4,27.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.3,-0.3,246.3,56);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt["f1_02"], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 243;
	this.text.setTransform(121.4,15.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape.setTransform(123.4,27.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_1.setTransform(123.4,27.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-123.15,-28,246.3,56,6);
	this.shape_2.setTransform(123.4,27.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.3,246.7,56);





})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')) {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}