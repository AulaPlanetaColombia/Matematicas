(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,1,0,0);
        titulo1(this, txt['titol']);
     
        this.instance = new lib.ImatgeIntrob();
	this.instance.setTransform(254,200,0.484,0.484);
         this.instance.on("mouseover", function (evt) {
            this.setTransform(204,190,0.684,0.684);
        });
        
         this.instance.on("mouseout", function (evt) {
            this.setTransform(254,200,0.484,0.484);
        });
        
         this.instance.on("click", function (evt) {
            putStage(new lib.frame2());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo,  this.titulo,  this.siguiente,  this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['titol_01']);
     
        
	this.instance_1 = new lib.MTB_10_01_022();
        if (isbq)
	this.instance_1.setTransform(290,10,0.841,0.841);
    else
        	this.instance_1.setTransform(318.9,10,0.841,0.841);

        this.animacion = new lib.mc_p1();
	this.animacion.setTransform(442.2,329.6,1,1,0,0,0,359.7,167.1);
        
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo,  this.titulo, this.home,  this.siguiente,  this.instance_1,this.animacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['titol_02']);
     
        
		this.instance_1 = new lib.MTB_10_01_024();
                 if (isbq)
	this.instance_1.setTransform(430,10,0.841,0.841);
else
    	this.instance_1.setTransform(460.6,10,0.841,0.841);

	

	this.instance_2 = new lib.mc_formula_p1();
	this.instance_2.setTransform(835.7,194.7,1,1,0,0,0,121,39.8);
        
        this.animacion = new lib.mc_p2();
	this.animacion.setTransform(442.2,329.6,1,1,0,0,0,359.7,167.1);
        
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.addChild(this.logo,  this.titulo, this.home,  this.anterior,this.siguiente,  this.instance_1,this.instance_2,this.animacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


(lib.frame4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['titol_03']);
     
        
this.instance_1 = new lib.mc_formula_p2();
	this.instance_1.setTransform(837.4,286.2,1,1,0,0,0,120.4,39.5);

	this.instance_2 = new lib.mc_formula_p1();
	this.instance_2.setTransform(835.7,194.7,1,1,0,0,0,121,39.8);
        
         var html = createDiv(txt['txt_3_01a'], "Verdana", "20px", '400px', '30px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(90, -460);
        
        this.animacion = new lib.mc_p3();
	this.animacion.setTransform(444.2,326.6,1,1,0,0,0,359.7,167.1);
        
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo,  this.titulo, this.home,  this.anterior,this.siguiente,  this.instance_1,this.instance_2,this.animacion,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


(lib.frame5 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['titol_04']);
     
        
        
        this.animacion = new lib.mc_p4();
	this.animacion.setTransform(594.2,226.6,1,1,0,0,0,359.7,167.1);
        
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo,  this.titulo, this.home,  this.anterior,this.siguiente, this.animacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame6 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt['titol_05']);
     
        
        
        this.animacion = new lib.mc_p5();
	this.animacion.setTransform(594.2,226.6,1,1,0,0,0,359.7,167.1);
          this.practica = new lib.btn_practica(txt['txt_boto_practica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        
        
         this.practica.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
       

        this.addChild(this.logo,  this.titulo, this.home, this.anterior,this.anterior, this.practica, this.animacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame7 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this,0,0,0,0,1);
        titulo2(this, txt['titol_practica_1']);
     
        
        
      	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAA70MAAAA3p");
	this.shape.setTransform(463.9,341.5,1,1.06);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("EgpeAAAMBS9AAA");
	this.shape_1.setTransform(463.8,435.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("EgpjAAAMBTHAAA");
	this.shape_2.setTransform(464.3,339.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("EgpaAAAMBS1AAA");
	this.shape_3.setTransform(464.3,245.5);

	this.instance_1 = new lib.Imatge_practica_04();
	this.instance_1.setTransform(307.1,442.5,0.56,0.56);

	this.instance_2 = new lib.Imatge_practica_03();
	this.instance_2.setTransform(306.8,346,0.56,0.56);

	this.instance_3 = new lib.Imatge_practica_02();
	this.instance_3.setTransform(291.7,262,0.5,0.5);

	this.instance_4 = new lib.Imatge_practica_01();
	this.instance_4.setTransform(291.7,168.4,0.5,0.5);
        this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(2,1,1).rr(-266.05,-177.7,532.1,355.4,10);
	this.shape_4.setTransform(464.3,341.5,1,1.068);
          this.practica = new lib.btn_practica(txt['txt_boto_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        
        
         this.practica.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        
       

        this.addChild(this.logo,  this.titulo,  this.cerrar, this.practica,this.shape_4, this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame8 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this,0,1,0,0,1);
       
     
        
        
      	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAA70MAAAA3p");
	this.shape.setTransform(463.9,341.5,1,1.06);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("EgpeAAAMBS9AAA");
	this.shape_1.setTransform(463.8,435.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("EgpjAAAMBTHAAA");
	this.shape_2.setTransform(464.3,339.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("EgpaAAAMBS1AAA");
	this.shape_3.setTransform(464.3,245.5);

	this.instance_1 = new lib.Imatge_practica_04();
	this.instance_1.setTransform(307.1,442.5,0.56,0.56);

	this.instance_2 = new lib.Imatge_practica_03();
	this.instance_2.setTransform(306.8,346,0.56,0.56);

	this.instance_3 = new lib.Imatge_practica_02();
	this.instance_3.setTransform(291.7,262,0.5,0.5);

	this.instance_4 = new lib.Imatge_practica_01();
	this.instance_4.setTransform(291.7,168.4,0.5,0.5);
        this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(2,1,1).rr(-266.05,-177.7,532.1,355.4,10);
	this.shape_4.setTransform(464.3,341.5,1,1.068);
         this.instance_5 = new lib.Imatge_solucion_03();
	this.instance_5.setTransform(547.9,350.2,0.622,0.622);

	this.instance_6 = new lib.Imatge_solucion_04();
	this.instance_6.setTransform(551.4,446.9,0.58,0.622);

	this.instance_7 = new lib.Imatge_solucion_02();
	this.instance_7.setTransform(570.5,251.4,0.528,0.611);

	this.instance_8 = new lib.Imatge_solucion_01();
	this.instance_8.setTransform(571.8,157.7,0.607,0.607);
        
         this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        
       

        this.addChild(this.logo,    this.cerrar, this.anterior,this.shape_4,this.instance_8,this.instance_7,this.instance_6,this.instance_5, this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }
    */
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    
    (lib._2 = function() {
	this.initialize(img._2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,56);


(lib._5 = function() {
	this.initialize(img._5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,32,57);


(lib._6 = function() {
	this.initialize(img._6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,57);


(lib._7 = function() {
	this.initialize(img._7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,31,56);


(lib.Formula_Ms = function() {
	this.initialize(img.Formula_Ms);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,208,80);


(lib.Formula_Ns = function() {
	this.initialize(img.Formula_Ns);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,125,49);


(lib.Formula_p1 = function() {
	this.initialize(img.Formula_p1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,484,159);


(lib.Formula_p2 = function() {
	this.initialize(img.Formula_p2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,531,174);


(lib.Formula_p3 = function() {
	this.initialize(img.Formula_p3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,251,111);


(lib.Formula_p4 = function() {
	this.initialize(img.Formula_p4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,344,162);


(lib.Formula_p5 = function() {
	this.initialize(img.Formula_p5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,294,129);


(lib.Guion = function() {
	this.initialize(img.Guion);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,34,4);


(lib.Imatge_practica_01 = function() {
	this.initialize(img.Imatge_practica_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,135);


(lib.Imatge_practica_02 = function() {
	this.initialize(img.Imatge_practica_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,135);


(lib.Imatge_practica_03 = function() {
	this.initialize(img.Imatge_practica_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,150);


(lib.Imatge_practica_04 = function() {
	this.initialize(img.Imatge_practica_04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,79,150);


(lib.Imatge_solucion_01 = function() {
	this.initialize(img.Imatge_solucion_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,76,151);


(lib.Imatge_solucion_02 = function() {
	this.initialize(img.Imatge_solucion_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,92,153);


(lib.Imatge_solucion_03 = function() {
	this.initialize(img.Imatge_solucion_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,151,134);


(lib.Imatge_solucion_04 = function() {
	this.initialize(img.Imatge_solucion_04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,150,123);


(lib.ImatgeBotons_1 = function() {
	this.initialize(img.ImatgeBotons_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,580,82);


(lib.ImatgeBotons_2 = function() {
	this.initialize(img.ImatgeBotons_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,425,82);


(lib.ImatgeBotons_3 = function() {
	this.initialize(img.ImatgeBotons_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,529,74);


(lib.ImatgeBotons_4 = function() {
	this.initialize(img.ImatgeBotons_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,388,74);


(lib.ImatgeIntro = function() {
	this.initialize(img.ImatgeIntro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,786,339);
(lib.ImatgeIntrob = function() {
	this.initialize(img.ImatgeIntrob);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,786,339);


(lib.ImatgeIntro_2 = function() {
	this.initialize(img.ImatgeIntro_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,250,108);


(lib.MTB_10_01_022 = function() {
	this.initialize(img.MTB_10_01_022);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,50);


(lib.MTB_10_01_024 = function() {
	this.initialize(img.MTB_10_01_024);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,50,50);



(lib.mc_Num_3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("3", "bold 23px Verdana", "#FF6600");
	this.text.lineHeight = 25;
	this.text.lineWidth = 25;
	this.text.setTransform(68.3,-14.7,1,1.093);

	this.text_1 = new cjs.Text("3", "bold 23px Verdana", "#FF6600");
	this.text_1.lineHeight = 25;
	this.text_1.lineWidth = 25;
	this.text_1.setTransform(-0.7,-6.1,1,1.093);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.7,-14.7,98.1,43.5);


(lib.mc_Num_2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("2", "bold 23px Verdana", "#FF6600");
	this.text.lineHeight = 25;
	this.text.lineWidth = 25;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,29,32);


(lib.mc_MsNs = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Formula_Ns();
	this.instance.setTransform(-269.7,41.6,0.8,0.8);

	this.instance_1 = new lib.Formula_Ms();
	this.instance_1.setTransform(-274,11.1,0.8,0.8);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-274,11.1,166.4,69.7);


(lib.mc_intro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.ImatgeIntro();
	this.instance.setTransform(84,0,0.484,0.484);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{scaleX:0.484,scaleY:0.484,x:84,y:0}}]}).to({state:[{t:this.instance,p:{scaleX:0.535,scaleY:0.535,x:65,y:-8.6}}]},1).to({state:[{t:this.instance,p:{scaleX:0.484,scaleY:0.484,x:84,y:0}}]},1).to({state:[{t:this.instance,p:{scaleX:0.484,scaleY:0.484,x:84,y:0}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(84,0,380.7,164.2);


(lib.mc_Guion = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Guion();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,34,4);


(lib.mc_formula_p2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Formula_p2();
	this.instance.setTransform(0,0,0.453,0.453);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,240.7,78.9);


(lib.mc_formula_p1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Formula_p1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,242,79.5);


(lib.mc_7 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._7();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,31,56);


(lib.mc_6 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._6();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,31,57);


(lib.mc_5 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._5();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,32,57);


(lib.mc_2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._2();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,31,56);


(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);


(lib.mc_p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiGPsIAA/XIEMAAIAAfXg");
	var mask_graphics_1 = new cjs.Graphics().p("AikPsIAA/XIFJAAIAAfXg");
	var mask_graphics_2 = new cjs.Graphics().p("AjCPsIAA/XIGFAAIAAfXg");
	var mask_graphics_3 = new cjs.Graphics().p("AjhPsIAA/XIHDAAIAAfXg");
	var mask_graphics_4 = new cjs.Graphics().p("Aj/PsIAA/XIH/AAIAAfXg");
	var mask_graphics_5 = new cjs.Graphics().p("AkePsIAA/XII9AAIAAfXg");
	var mask_graphics_6 = new cjs.Graphics().p("Ak8PsIAA/XIJ5AAIAAfXg");
	var mask_graphics_7 = new cjs.Graphics().p("AlaPsIAA/XIK1AAIAAfXg");
	var mask_graphics_8 = new cjs.Graphics().p("Al5PsIAA/XILzAAIAAfXg");
	var mask_graphics_9 = new cjs.Graphics().p("AmXPsIAA/XIMvAAIAAfXg");
	var mask_graphics_10 = new cjs.Graphics().p("Am2PsIAA/XINtAAIAAfXg");
	var mask_graphics_11 = new cjs.Graphics().p("AnUPsIAA/XIOpAAIAAfXg");
	var mask_graphics_12 = new cjs.Graphics().p("AnyPsIAA/XIPlAAIAAfXg");
	var mask_graphics_13 = new cjs.Graphics().p("AoRPsIAA/XIQjAAIAAfXg");
	var mask_graphics_14 = new cjs.Graphics().p("AovPsIAA/XIRfAAIAAfXg");
	var mask_graphics_15 = new cjs.Graphics().p("ApOPsIAA/XISdAAIAAfXg");
	var mask_graphics_16 = new cjs.Graphics().p("ApsPsIAA/XITZAAIAAfXg");
	var mask_graphics_17 = new cjs.Graphics().p("AqKPsIAA/XIUVAAIAAfXg");
	var mask_graphics_18 = new cjs.Graphics().p("AqpPsIAA/XIVTAAIAAfXg");
	var mask_graphics_19 = new cjs.Graphics().p("ArHPsIAA/XIWPAAIAAfXg");
	var mask_graphics_20 = new cjs.Graphics().p("ArmPsIAA/XIXNAAIAAfXg");
	var mask_graphics_21 = new cjs.Graphics().p("AsEPsIAA/XIYJAAIAAfXg");
	var mask_graphics_22 = new cjs.Graphics().p("AsiPsIAA/XIZFAAIAAfXg");
	var mask_graphics_23 = new cjs.Graphics().p("AtBPsIAA/XIaDAAIAAfXg");
	var mask_graphics_24 = new cjs.Graphics().p("AtfPsIAA/XIa/AAIAAfXg");
	var mask_graphics_25 = new cjs.Graphics().p("At+PsIAA/XIb9AAIAAfXg");
	var mask_graphics_26 = new cjs.Graphics().p("AucPsIAA/XIc5AAIAAfXg");
	var mask_graphics_27 = new cjs.Graphics().p("Au6PsIAA/XId1AAIAAfXg");
	var mask_graphics_28 = new cjs.Graphics().p("AvZPsIAA/XIezAAIAAfXg");
	var mask_graphics_29 = new cjs.Graphics().p("Av3XoIAA/YIfvAAIAAfYg");
	var mask_graphics_53 = new cjs.Graphics().p("Av3XoIAA/YIfvAAIAAfYg");
	var mask_graphics_54 = new cjs.Graphics().p("AwIPsIAA/XMAgRAAAIAAfXg");
	var mask_graphics_55 = new cjs.Graphics().p("AwYPsIAA/XMAgxAAAIAAfXg");
	var mask_graphics_56 = new cjs.Graphics().p("AwoPsIAA/XMAhRAAAIAAfXg");
	var mask_graphics_57 = new cjs.Graphics().p("Aw5PsIAA/XMAhzAAAIAAfXg");
	var mask_graphics_58 = new cjs.Graphics().p("AxJPsIAA/XMAiTAAAIAAfXg");
	var mask_graphics_59 = new cjs.Graphics().p("AxZPsIAA/XMAizAAAIAAfXg");
	var mask_graphics_60 = new cjs.Graphics().p("AxqPsIAA/XMAjVAAAIAAfXg");
	var mask_graphics_61 = new cjs.Graphics().p("Ax6PsIAA/XMAj1AAAIAAfXg");
	var mask_graphics_62 = new cjs.Graphics().p("AyKPsIAA/XMAkVAAAIAAfXg");
	var mask_graphics_63 = new cjs.Graphics().p("AybPsIAA/XMAk3AAAIAAfXg");
	var mask_graphics_64 = new cjs.Graphics().p("AyrPsIAA/XMAlXAAAIAAfXg");
	var mask_graphics_65 = new cjs.Graphics().p("Ay8PsIAA/XMAl5AAAIAAfXg");
	var mask_graphics_66 = new cjs.Graphics().p("AzMPsIAA/XMAmZAAAIAAfXg");
	var mask_graphics_67 = new cjs.Graphics().p("AzcPsIAA/XMAm5AAAIAAfXg");
	var mask_graphics_68 = new cjs.Graphics().p("AztPsIAA/XMAnbAAAIAAfXg");
	var mask_graphics_69 = new cjs.Graphics().p("Az9PsIAA/XMAn7AAAIAAfXg");
	var mask_graphics_70 = new cjs.Graphics().p("A0NPsIAA/XMAobAAAIAAfXg");
	var mask_graphics_71 = new cjs.Graphics().p("A0ePsIAA/XMAo9AAAIAAfXg");
	var mask_graphics_72 = new cjs.Graphics().p("A0uXoIAA/YMApdAAAIAAfYg");
	var mask_graphics_101 = new cjs.Graphics().p("A0uXoIAA/YMApdAAAIAAfYg");
	var mask_graphics_102 = new cjs.Graphics().p("A1GPsIAA/XMAqNAAAIAAfXg");
	var mask_graphics_103 = new cjs.Graphics().p("A1ePsIAA/XMAq9AAAIAAfXg");
	var mask_graphics_104 = new cjs.Graphics().p("A12PsIAA/XMArtAAAIAAfXg");
	var mask_graphics_105 = new cjs.Graphics().p("A2PPsIAA/XMAsfAAAIAAfXg");
	var mask_graphics_106 = new cjs.Graphics().p("A2nPsIAA/XMAtPAAAIAAfXg");
	var mask_graphics_107 = new cjs.Graphics().p("A2/PsIAA/XMAt/AAAIAAfXg");
	var mask_graphics_108 = new cjs.Graphics().p("A3XPsIAA/XMAuvAAAIAAfXg");
	var mask_graphics_109 = new cjs.Graphics().p("A3vPsIAA/XMAvfAAAIAAfXg");
	var mask_graphics_110 = new cjs.Graphics().p("A4HPsIAA/XMAwPAAAIAAfXg");
	var mask_graphics_111 = new cjs.Graphics().p("A4gPsIAA/XMAxBAAAIAAfXg");
	var mask_graphics_112 = new cjs.Graphics().p("A44PsIAA/XMAxxAAAIAAfXg");
	var mask_graphics_113 = new cjs.Graphics().p("A5QPsIAA/XMAyhAAAIAAfXg");
	var mask_graphics_114 = new cjs.Graphics().p("A5oPsIAA/XMAzRAAAIAAfXg");
	var mask_graphics_115 = new cjs.Graphics().p("A6APsIAA/XMA0BAAAIAAfXg");
	var mask_graphics_116 = new cjs.Graphics().p("A6YPsIAA/XMA0xAAAIAAfXg");
	var mask_graphics_117 = new cjs.Graphics().p("A6xPsIAA/XMA1jAAAIAAfXg");
	var mask_graphics_118 = new cjs.Graphics().p("A7JPsIAA/XMA2TAAAIAAfXg");
	var mask_graphics_119 = new cjs.Graphics().p("A7hPsIAA/XMA3DAAAIAAfXg");
	var mask_graphics_120 = new cjs.Graphics().p("A75PsIAA/XMA3zAAAIAAfXg");
	var mask_graphics_121 = new cjs.Graphics().p("A8RPsIAA/XMA4jAAAIAAfXg");
	var mask_graphics_122 = new cjs.Graphics().p("A8pPsIAA/XMA5TAAAIAAfXg");
	var mask_graphics_123 = new cjs.Graphics().p("A9CPsIAA/XMA6FAAAIAAfXg");
	var mask_graphics_124 = new cjs.Graphics().p("A9aPsIAA/XMA61AAAIAAfXg");
	var mask_graphics_125 = new cjs.Graphics().p("A9yPsIAA/XMA7lAAAIAAfXg");
	var mask_graphics_126 = new cjs.Graphics().p("A+KPsIAA/XMA8VAAAIAAfXg");
	var mask_graphics_127 = new cjs.Graphics().p("A+iPsIAA/XMA9FAAAIAAfXg");
	var mask_graphics_128 = new cjs.Graphics().p("A+6PsIAA/XMA91AAAIAAfXg");
	var mask_graphics_129 = new cjs.Graphics().p("A/TPsIAA/XMA+nAAAIAAfXg");
	var mask_graphics_130 = new cjs.Graphics().p("A/rXoIAA/YMA/XAAAIAAfYg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-18.4,y:202}).wait(1).to({graphics:mask_graphics_1,x:-15.3,y:202}).wait(1).to({graphics:mask_graphics_2,x:-12.3,y:202}).wait(1).to({graphics:mask_graphics_3,x:-9.2,y:202}).wait(1).to({graphics:mask_graphics_4,x:-6.2,y:202}).wait(1).to({graphics:mask_graphics_5,x:-3.1,y:202}).wait(1).to({graphics:mask_graphics_6,x:-0.1,y:202}).wait(1).to({graphics:mask_graphics_7,x:2.8,y:202}).wait(1).to({graphics:mask_graphics_8,x:5.9,y:202}).wait(1).to({graphics:mask_graphics_9,x:8.9,y:202}).wait(1).to({graphics:mask_graphics_10,x:12,y:202}).wait(1).to({graphics:mask_graphics_11,x:15,y:202}).wait(1).to({graphics:mask_graphics_12,x:18,y:202}).wait(1).to({graphics:mask_graphics_13,x:21.1,y:202}).wait(1).to({graphics:mask_graphics_14,x:24.1,y:202}).wait(1).to({graphics:mask_graphics_15,x:27.2,y:202}).wait(1).to({graphics:mask_graphics_16,x:30.2,y:202}).wait(1).to({graphics:mask_graphics_17,x:33.2,y:202}).wait(1).to({graphics:mask_graphics_18,x:36.3,y:202}).wait(1).to({graphics:mask_graphics_19,x:39.3,y:202}).wait(1).to({graphics:mask_graphics_20,x:42.4,y:202}).wait(1).to({graphics:mask_graphics_21,x:45.4,y:202}).wait(1).to({graphics:mask_graphics_22,x:48.4,y:202}).wait(1).to({graphics:mask_graphics_23,x:51.5,y:202}).wait(1).to({graphics:mask_graphics_24,x:54.5,y:202}).wait(1).to({graphics:mask_graphics_25,x:57.6,y:202}).wait(1).to({graphics:mask_graphics_26,x:60.6,y:202}).wait(1).to({graphics:mask_graphics_27,x:63.6,y:202}).wait(1).to({graphics:mask_graphics_28,x:66.7,y:202}).wait(1).to({graphics:mask_graphics_29,x:69.7,y:151.3}).wait(24).to({graphics:mask_graphics_53,x:69.7,y:151.3}).wait(1).to({graphics:mask_graphics_54,x:71.4,y:202}).wait(1).to({graphics:mask_graphics_55,x:73,y:202}).wait(1).to({graphics:mask_graphics_56,x:74.6,y:202}).wait(1).to({graphics:mask_graphics_57,x:76.3,y:202}).wait(1).to({graphics:mask_graphics_58,x:77.9,y:202}).wait(1).to({graphics:mask_graphics_59,x:79.5,y:202}).wait(1).to({graphics:mask_graphics_60,x:81.2,y:202}).wait(1).to({graphics:mask_graphics_61,x:82.8,y:202}).wait(1).to({graphics:mask_graphics_62,x:84.4,y:202}).wait(1).to({graphics:mask_graphics_63,x:86.1,y:202}).wait(1).to({graphics:mask_graphics_64,x:87.7,y:202}).wait(1).to({graphics:mask_graphics_65,x:89.3,y:202}).wait(1).to({graphics:mask_graphics_66,x:91,y:202}).wait(1).to({graphics:mask_graphics_67,x:92.6,y:202}).wait(1).to({graphics:mask_graphics_68,x:94.2,y:202}).wait(1).to({graphics:mask_graphics_69,x:95.9,y:202}).wait(1).to({graphics:mask_graphics_70,x:97.5,y:202}).wait(1).to({graphics:mask_graphics_71,x:99.1,y:202}).wait(1).to({graphics:mask_graphics_72,x:100.7,y:151.3}).wait(29).to({graphics:mask_graphics_101,x:100.7,y:151.3}).wait(1).to({graphics:mask_graphics_102,x:103.2,y:202}).wait(1).to({graphics:mask_graphics_103,x:105.6,y:202}).wait(1).to({graphics:mask_graphics_104,x:108,y:202}).wait(1).to({graphics:mask_graphics_105,x:110.4,y:202}).wait(1).to({graphics:mask_graphics_106,x:112.8,y:202}).wait(1).to({graphics:mask_graphics_107,x:115.2,y:202}).wait(1).to({graphics:mask_graphics_108,x:117.6,y:202}).wait(1).to({graphics:mask_graphics_109,x:120,y:202}).wait(1).to({graphics:mask_graphics_110,x:122.5,y:202}).wait(1).to({graphics:mask_graphics_111,x:124.9,y:202}).wait(1).to({graphics:mask_graphics_112,x:127.3,y:202}).wait(1).to({graphics:mask_graphics_113,x:129.7,y:202}).wait(1).to({graphics:mask_graphics_114,x:132.1,y:202}).wait(1).to({graphics:mask_graphics_115,x:134.5,y:202}).wait(1).to({graphics:mask_graphics_116,x:136.9,y:202}).wait(1).to({graphics:mask_graphics_117,x:139.3,y:202}).wait(1).to({graphics:mask_graphics_118,x:141.7,y:202}).wait(1).to({graphics:mask_graphics_119,x:144.2,y:202}).wait(1).to({graphics:mask_graphics_120,x:146.6,y:202}).wait(1).to({graphics:mask_graphics_121,x:149,y:202}).wait(1).to({graphics:mask_graphics_122,x:151.4,y:202}).wait(1).to({graphics:mask_graphics_123,x:153.8,y:202}).wait(1).to({graphics:mask_graphics_124,x:156.2,y:202}).wait(1).to({graphics:mask_graphics_125,x:158.6,y:202}).wait(1).to({graphics:mask_graphics_126,x:161,y:202}).wait(1).to({graphics:mask_graphics_127,x:163.4,y:202}).wait(1).to({graphics:mask_graphics_128,x:165.9,y:202}).wait(1).to({graphics:mask_graphics_129,x:168.3,y:202}).wait(1).to({graphics:mask_graphics_130,x:170.7,y:151.3}).wait(103));

	// 5
	this.instance = new lib.mc_5();
	this.instance.setTransform(124,195.6,1,1,0,0,0,16,28.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(142).to({_off:false},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:1},0).wait(1).to({x:133.4,y:192.9},0).wait(1).to({x:142.9,y:190.3},0).wait(1).to({x:152.4,y:187.7},0).wait(1).to({x:161.9,y:185.1},0).wait(1).to({x:171.4,y:182.4},0).wait(1).to({x:180.9,y:179.8},0).wait(1).to({x:190.4,y:177.2},0).wait(1).to({x:199.9,y:174.6},0).wait(1).to({x:209.4,y:171.9},0).wait(1).to({x:218.9,y:169.3},0).wait(1).to({x:228.4,y:166.7},0).wait(1).to({x:237.9,y:164.1},0).wait(1).to({x:247.4,y:161.5},0).wait(1).to({x:256.9,y:158.8},0).wait(1).to({x:266.4,y:156.2},0).wait(1).to({x:275.9,y:153.6},0).wait(1).to({x:285.4,y:151},0).wait(1).to({x:294.9,y:148.3},0).wait(1).to({x:304.4,y:145.7},0).wait(1).to({x:313.9,y:143.1},0).wait(64));

	// Guio
	this.instance_1 = new lib.mc_Guion();
	this.instance_1.setTransform(315.6,168.7,1,1,0,0,0,17,2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(142).to({_off:false},0).wait(40).wait(1).to({alpha:0.083},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.25},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.417},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.583},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.917},0).wait(1).to({alpha:1},0).wait(39));

	// 6
	this.instance_2 = new lib.mc_6();
	this.instance_2.setTransform(27.3,192.6,1,1,0,0,0,15.5,28.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(142).to({_off:false},0).wait(64).wait(1).to({x:38.3,y:193,alpha:0.2},0).wait(1).to({x:49.4,y:193.5,alpha:0.4},0).wait(1).to({x:60.4,y:193.9,alpha:0.6},0).wait(1).to({x:71.5,y:194.4,alpha:0.8},0).wait(1).to({x:82.5,y:194.8,alpha:1},0).wait(1).to({x:93.6,y:195.3},0).wait(1).to({x:104.6,y:195.7},0).wait(1).to({x:115.7,y:196.1},0).wait(1).to({x:126.7,y:196.6},0).wait(1).to({x:137.8,y:197},0).wait(1).to({x:148.9,y:197.5},0).wait(1).to({x:159.9,y:197.9},0).wait(1).to({x:171,y:198.4},0).wait(1).to({x:182,y:198.8},0).wait(1).to({x:193.1,y:199.2},0).wait(1).to({x:204.1,y:199.7},0).wait(1).to({x:215.2,y:200.1},0).wait(1).to({x:226.2,y:200.6},0).wait(1).to({x:237.3,y:201},0).wait(1).to({x:248.4,y:201.4},0).wait(1).to({x:259.4,y:201.9},0).wait(1).to({x:270.5,y:202.3},0).wait(1).to({x:281.5,y:202.8},0).wait(1).to({x:292.6,y:203.2},0).wait(1).to({x:303.6,y:203.7},0).wait(1).to({x:314.7,y:204.1},0).wait(1));

	// FlashAICB
	this.instance_3 = new lib.Formula_p5();
	this.instance_3.setTransform(9,143);

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(233000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9,143,294,129);


(lib.mc_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiGPsIAA/XIEMAAIAAfXg");
	var mask_graphics_1 = new cjs.Graphics().p("AiaPsIAA/XIE1AAIAAfXg");
	var mask_graphics_2 = new cjs.Graphics().p("AivPsIAA/XIFfAAIAAfXg");
	var mask_graphics_3 = new cjs.Graphics().p("AjEPsIAA/XIGJAAIAAfXg");
	var mask_graphics_4 = new cjs.Graphics().p("AjZPsIAA/XIGzAAIAAfXg");
	var mask_graphics_5 = new cjs.Graphics().p("AjuPsIAA/XIHdAAIAAfXg");
	var mask_graphics_6 = new cjs.Graphics().p("AkDPsIAA/XIIHAAIAAfXg");
	var mask_graphics_7 = new cjs.Graphics().p("AkYPsIAA/XIIxAAIAAfXg");
	var mask_graphics_8 = new cjs.Graphics().p("AksPsIAA/XIJZAAIAAfXg");
	var mask_graphics_9 = new cjs.Graphics().p("AlBPsIAA/XIKDAAIAAfXg");
	var mask_graphics_10 = new cjs.Graphics().p("AlWPsIAA/XIKtAAIAAfXg");
	var mask_graphics_11 = new cjs.Graphics().p("AlrPsIAA/XILXAAIAAfXg");
	var mask_graphics_12 = new cjs.Graphics().p("AmAPsIAA/XIMBAAIAAfXg");
	var mask_graphics_13 = new cjs.Graphics().p("AmVPsIAA/XIMrAAIAAfXg");
	var mask_graphics_14 = new cjs.Graphics().p("AmqPsIAA/XINVAAIAAfXg");
	var mask_graphics_15 = new cjs.Graphics().p("Am+PsIAA/XIN9AAIAAfXg");
	var mask_graphics_16 = new cjs.Graphics().p("AnTPsIAA/XIOnAAIAAfXg");
	var mask_graphics_17 = new cjs.Graphics().p("AnoPsIAA/XIPRAAIAAfXg");
	var mask_graphics_18 = new cjs.Graphics().p("An9PsIAA/XIP7AAIAAfXg");
	var mask_graphics_19 = new cjs.Graphics().p("AoSPsIAA/XIQlAAIAAfXg");
	var mask_graphics_20 = new cjs.Graphics().p("AonPsIAA/XIRPAAIAAfXg");
	var mask_graphics_21 = new cjs.Graphics().p("Ao8PsIAA/XIR5AAIAAfXg");
	var mask_graphics_22 = new cjs.Graphics().p("ApQPsIAA/XIShAAIAAfXg");
	var mask_graphics_23 = new cjs.Graphics().p("AplPsIAA/XITLAAIAAfXg");
	var mask_graphics_24 = new cjs.Graphics().p("Ap6PsIAA/XIT1AAIAAfXg");
	var mask_graphics_25 = new cjs.Graphics().p("AqPPsIAA/XIUfAAIAAfXg");
	var mask_graphics_26 = new cjs.Graphics().p("AqkPsIAA/XIVJAAIAAfXg");
	var mask_graphics_27 = new cjs.Graphics().p("Aq5PsIAA/XIVzAAIAAfXg");
	var mask_graphics_28 = new cjs.Graphics().p("ArOPsIAA/XIWdAAIAAfXg");
	var mask_graphics_29 = new cjs.Graphics().p("AriXoIAA/YIXFAAIAAfYg");
	var mask_graphics_53 = new cjs.Graphics().p("AriXoIAA/YIXFAAIAAfYg");
	var mask_graphics_54 = new cjs.Graphics().p("AryPsIAA/XIXlAAIAAfXg");
	var mask_graphics_55 = new cjs.Graphics().p("AsCPsIAA/XIYFAAIAAfXg");
	var mask_graphics_56 = new cjs.Graphics().p("AsSPsIAA/XIYlAAIAAfXg");
	var mask_graphics_57 = new cjs.Graphics().p("AsiPsIAA/XIZFAAIAAfXg");
	var mask_graphics_58 = new cjs.Graphics().p("AsxPsIAA/XIZjAAIAAfXg");
	var mask_graphics_59 = new cjs.Graphics().p("AtBPsIAA/XIaDAAIAAfXg");
	var mask_graphics_60 = new cjs.Graphics().p("AtRPsIAA/XIajAAIAAfXg");
	var mask_graphics_61 = new cjs.Graphics().p("AthPsIAA/XIbDAAIAAfXg");
	var mask_graphics_62 = new cjs.Graphics().p("AtxPsIAA/XIbjAAIAAfXg");
	var mask_graphics_63 = new cjs.Graphics().p("AuAPsIAA/XIcBAAIAAfXg");
	var mask_graphics_64 = new cjs.Graphics().p("AuQPsIAA/XIchAAIAAfXg");
	var mask_graphics_65 = new cjs.Graphics().p("AugPsIAA/XIdBAAIAAfXg");
	var mask_graphics_66 = new cjs.Graphics().p("AuwPsIAA/XIdhAAIAAfXg");
	var mask_graphics_67 = new cjs.Graphics().p("AvAPsIAA/XIeBAAIAAfXg");
	var mask_graphics_68 = new cjs.Graphics().p("AvPPsIAA/XIefAAIAAfXg");
	var mask_graphics_69 = new cjs.Graphics().p("AvfPsIAA/XIe/AAIAAfXg");
	var mask_graphics_70 = new cjs.Graphics().p("AvvPsIAA/XIffAAIAAfXg");
	var mask_graphics_71 = new cjs.Graphics().p("Av/PsIAA/XIf/AAIAAfXg");
	var mask_graphics_72 = new cjs.Graphics().p("AwPXoIAA/YMAgfAAAIAAfYg");
	var mask_graphics_101 = new cjs.Graphics().p("AwPXoIAA/YMAgfAAAIAAfYg");
	var mask_graphics_102 = new cjs.Graphics().p("AwvPsIAA/XMAhfAAAIAAfXg");
	var mask_graphics_103 = new cjs.Graphics().p("AxQPsIAA/XMAihAAAIAAfXg");
	var mask_graphics_104 = new cjs.Graphics().p("AxxPsIAA/XMAjjAAAIAAfXg");
	var mask_graphics_105 = new cjs.Graphics().p("AySPsIAA/XMAkkAAAIAAfXg");
	var mask_graphics_106 = new cjs.Graphics().p("AyyPsIAA/XMAllAAAIAAfXg");
	var mask_graphics_107 = new cjs.Graphics().p("AzTPsIAA/XMAmnAAAIAAfXg");
	var mask_graphics_108 = new cjs.Graphics().p("Az0PsIAA/XMAnpAAAIAAfXg");
	var mask_graphics_109 = new cjs.Graphics().p("A0VPsIAA/XMAoqAAAIAAfXg");
	var mask_graphics_110 = new cjs.Graphics().p("A01PsIAA/XMAprAAAIAAfXg");
	var mask_graphics_111 = new cjs.Graphics().p("A1WPsIAA/XMAqtAAAIAAfXg");
	var mask_graphics_112 = new cjs.Graphics().p("A13PsIAA/XMArvAAAIAAfXg");
	var mask_graphics_113 = new cjs.Graphics().p("A2YPsIAA/XMAswAAAIAAfXg");
	var mask_graphics_114 = new cjs.Graphics().p("A24PsIAA/XMAtxAAAIAAfXg");
	var mask_graphics_115 = new cjs.Graphics().p("A3ZPsIAA/XMAuzAAAIAAfXg");
	var mask_graphics_116 = new cjs.Graphics().p("A36PsIAA/XMAv1AAAIAAfXg");
	var mask_graphics_117 = new cjs.Graphics().p("A4bPsIAA/XMAw3AAAIAAfXg");
	var mask_graphics_118 = new cjs.Graphics().p("A47PsIAA/XMAx3AAAIAAfXg");
	var mask_graphics_119 = new cjs.Graphics().p("A5cPsIAA/XMAy5AAAIAAfXg");
	var mask_graphics_120 = new cjs.Graphics().p("A59PsIAA/XMAz7AAAIAAfXg");
	var mask_graphics_121 = new cjs.Graphics().p("A6ePsIAA/XMA09AAAIAAfXg");
	var mask_graphics_122 = new cjs.Graphics().p("A6+PsIAA/XMA19AAAIAAfXg");
	var mask_graphics_123 = new cjs.Graphics().p("A7fPsIAA/XMA2/AAAIAAfXg");
	var mask_graphics_124 = new cjs.Graphics().p("A8APsIAA/XMA4BAAAIAAfXg");
	var mask_graphics_125 = new cjs.Graphics().p("A8hPsIAA/XMA5DAAAIAAfXg");
	var mask_graphics_126 = new cjs.Graphics().p("A9BPsIAA/XMA6DAAAIAAfXg");
	var mask_graphics_127 = new cjs.Graphics().p("A9iPsIAA/XMA7FAAAIAAfXg");
	var mask_graphics_128 = new cjs.Graphics().p("A+DPsIAA/XMA8HAAAIAAfXg");
	var mask_graphics_129 = new cjs.Graphics().p("A+kPsIAA/XMA9JAAAIAAfXg");
	var mask_graphics_130 = new cjs.Graphics().p("A/EXoIAA/YMA+JAAAIAAfYg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-18.4,y:202}).wait(1).to({graphics:mask_graphics_1,x:-16.3,y:202}).wait(1).to({graphics:mask_graphics_2,x:-14.2,y:202}).wait(1).to({graphics:mask_graphics_3,x:-12.1,y:202}).wait(1).to({graphics:mask_graphics_4,x:-10,y:202}).wait(1).to({graphics:mask_graphics_5,x:-7.9,y:202}).wait(1).to({graphics:mask_graphics_6,x:-5.8,y:202}).wait(1).to({graphics:mask_graphics_7,x:-3.7,y:202}).wait(1).to({graphics:mask_graphics_8,x:-1.7,y:202}).wait(1).to({graphics:mask_graphics_9,x:0.3,y:202}).wait(1).to({graphics:mask_graphics_10,x:2.4,y:202}).wait(1).to({graphics:mask_graphics_11,x:4.5,y:202}).wait(1).to({graphics:mask_graphics_12,x:6.6,y:202}).wait(1).to({graphics:mask_graphics_13,x:8.7,y:202}).wait(1).to({graphics:mask_graphics_14,x:10.8,y:202}).wait(1).to({graphics:mask_graphics_15,x:12.8,y:202}).wait(1).to({graphics:mask_graphics_16,x:14.9,y:202}).wait(1).to({graphics:mask_graphics_17,x:17,y:202}).wait(1).to({graphics:mask_graphics_18,x:19.1,y:202}).wait(1).to({graphics:mask_graphics_19,x:21.2,y:202}).wait(1).to({graphics:mask_graphics_20,x:23.3,y:202}).wait(1).to({graphics:mask_graphics_21,x:25.4,y:202}).wait(1).to({graphics:mask_graphics_22,x:27.4,y:202}).wait(1).to({graphics:mask_graphics_23,x:29.5,y:202}).wait(1).to({graphics:mask_graphics_24,x:31.6,y:202}).wait(1).to({graphics:mask_graphics_25,x:33.7,y:202}).wait(1).to({graphics:mask_graphics_26,x:35.8,y:202}).wait(1).to({graphics:mask_graphics_27,x:37.9,y:202}).wait(1).to({graphics:mask_graphics_28,x:40,y:202}).wait(1).to({graphics:mask_graphics_29,x:42.1,y:151.3}).wait(24).to({graphics:mask_graphics_53,x:42.1,y:151.3}).wait(1).to({graphics:mask_graphics_54,x:43.6,y:202}).wait(1).to({graphics:mask_graphics_55,x:45.2,y:202}).wait(1).to({graphics:mask_graphics_56,x:46.8,y:202}).wait(1).to({graphics:mask_graphics_57,x:48.4,y:202}).wait(1).to({graphics:mask_graphics_58,x:49.9,y:202}).wait(1).to({graphics:mask_graphics_59,x:51.5,y:202}).wait(1).to({graphics:mask_graphics_60,x:53.1,y:202}).wait(1).to({graphics:mask_graphics_61,x:54.7,y:202}).wait(1).to({graphics:mask_graphics_62,x:56.3,y:202}).wait(1).to({graphics:mask_graphics_63,x:57.8,y:202}).wait(1).to({graphics:mask_graphics_64,x:59.4,y:202}).wait(1).to({graphics:mask_graphics_65,x:61,y:202}).wait(1).to({graphics:mask_graphics_66,x:62.6,y:202}).wait(1).to({graphics:mask_graphics_67,x:64.2,y:202}).wait(1).to({graphics:mask_graphics_68,x:65.7,y:202}).wait(1).to({graphics:mask_graphics_69,x:67.3,y:202}).wait(1).to({graphics:mask_graphics_70,x:68.9,y:202}).wait(1).to({graphics:mask_graphics_71,x:70.5,y:202}).wait(1).to({graphics:mask_graphics_72,x:72.1,y:151.3}).wait(29).to({graphics:mask_graphics_101,x:72.1,y:151.3}).wait(1).to({graphics:mask_graphics_102,x:75.3,y:202}).wait(1).to({graphics:mask_graphics_103,x:78.6,y:202}).wait(1).to({graphics:mask_graphics_104,x:81.9,y:202}).wait(1).to({graphics:mask_graphics_105,x:85.1,y:202}).wait(1).to({graphics:mask_graphics_106,x:88.4,y:202}).wait(1).to({graphics:mask_graphics_107,x:91.7,y:202}).wait(1).to({graphics:mask_graphics_108,x:94.9,y:202}).wait(1).to({graphics:mask_graphics_109,x:98.2,y:202}).wait(1).to({graphics:mask_graphics_110,x:101.5,y:202}).wait(1).to({graphics:mask_graphics_111,x:104.7,y:202}).wait(1).to({graphics:mask_graphics_112,x:108,y:202}).wait(1).to({graphics:mask_graphics_113,x:111.3,y:202}).wait(1).to({graphics:mask_graphics_114,x:114.6,y:202}).wait(1).to({graphics:mask_graphics_115,x:117.8,y:202}).wait(1).to({graphics:mask_graphics_116,x:121.1,y:202}).wait(1).to({graphics:mask_graphics_117,x:124.4,y:202}).wait(1).to({graphics:mask_graphics_118,x:127.6,y:202}).wait(1).to({graphics:mask_graphics_119,x:130.9,y:202}).wait(1).to({graphics:mask_graphics_120,x:134.2,y:202}).wait(1).to({graphics:mask_graphics_121,x:137.4,y:202}).wait(1).to({graphics:mask_graphics_122,x:140.7,y:202}).wait(1).to({graphics:mask_graphics_123,x:144,y:202}).wait(1).to({graphics:mask_graphics_124,x:147.3,y:202}).wait(1).to({graphics:mask_graphics_125,x:150.5,y:202}).wait(1).to({graphics:mask_graphics_126,x:153.8,y:202}).wait(1).to({graphics:mask_graphics_127,x:157.1,y:202}).wait(1).to({graphics:mask_graphics_128,x:160.3,y:202}).wait(1).to({graphics:mask_graphics_129,x:163.6,y:202}).wait(1).to({graphics:mask_graphics_130,x:166.9,y:151.3}).wait(125));

	// 7
	this.instance = new lib.mc_7();
	this.instance.setTransform(69.5,220,1,1,0,0,0,15.5,28);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(152).to({_off:false},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:1},0).wait(1).to({x:75.5,y:218.8},0).wait(1).to({x:81.5,y:217.6},0).wait(1).to({x:87.6,y:216.4},0).wait(1).to({x:93.6,y:215.2},0).wait(1).to({x:99.6,y:213.9},0).wait(1).to({x:105.7,y:212.7},0).wait(1).to({x:111.7,y:211.5},0).wait(1).to({x:117.7,y:210.3},0).wait(1).to({x:123.8,y:209.1},0).wait(1).to({x:129.8,y:207.9},0).wait(1).to({x:135.8,y:206.7},0).wait(1).to({x:141.9,y:205.5},0).wait(1).to({x:147.9,y:204.3},0).wait(1).to({x:153.9,y:203.1},0).wait(1).to({x:160,y:201.8},0).wait(1).to({x:166,y:200.6},0).wait(1).to({x:172.1,y:199.4},0).wait(1).to({x:178.1,y:198.2},0).wait(1).to({x:184.1,y:197},0).wait(1).to({x:190.2,y:195.8},0).wait(1).to({x:196.2,y:194.6},0).wait(1).to({x:202.2,y:193.4},0).wait(1).to({x:208.3,y:192.2},0).wait(1).to({x:214.3,y:191},0).wait(70));

	// 2
	this.instance_1 = new lib.mc_2();
	this.instance_1.setTransform(70.2,148,1,1,0,0,0,15.5,28);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(204).to({_off:false},0).wait(1).to({alpha:0.077},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:1},0).wait(1).to({x:83.7,y:150.7},0).wait(1).to({x:97.2,y:153.4},0).wait(1).to({x:110.6,y:156.1},0).wait(1).to({x:124.1,y:158.8},0).wait(1).to({x:137.6,y:161.5},0).wait(1).to({x:151.1,y:164.2},0).wait(1).to({x:164.5,y:166.9},0).wait(1).to({x:178,y:169.6},0).wait(1).to({x:191.5,y:172.3},0).wait(1).to({x:205,y:174.9},0).wait(1).to({x:218.5,y:177.6},0).wait(1).to({x:231.9,y:180.3},0).wait(1).to({x:245.4,y:183},0).wait(1).to({x:258.9,y:185.7},0).wait(1).to({x:272.4,y:188.4},0).wait(1).to({x:285.8,y:191.1},0).wait(1).to({x:299.3,y:193.8},0).wait(1).to({x:312.8,y:196.5},0).wait(20));

	// Formula_p4.png
	this.instance_2 = new lib.Formula_p4();
	this.instance_2.setTransform(0,121.1);

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(255000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,121.1,344,162);


(lib.mc_p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});
var inc=incremento-5;
	// Num_3
	this.instance = new lib.mc_Num_3();
	this.instance.setTransform(255.7,211.1,4.095,4.095,0,0,0,14.5,16);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(181).to({_off:false},0).wait(1).to({regX:48.3,regY:7,scaleX:4,scaleY:4,x:404,y:172.9+inc},0).wait(1).to({scaleX:3.9,scaleY:3.9,x:413.8,y:171.6+inc},0).wait(1).to({scaleX:3.81,scaleY:3.81,x:423.7,y:170.3+inc},0).wait(1).to({scaleX:3.71,scaleY:3.71,x:433.5,y:168.9+inc},0).wait(1).to({scaleX:3.61,scaleY:3.61,x:443.4,y:167.6+inc},0).wait(1).to({scaleX:3.52,scaleY:3.52,x:453.2,y:166.3+inc},0).wait(1).to({scaleX:3.42,scaleY:3.42,x:463.1,y:165+inc},0).wait(1).to({scaleX:3.32,scaleY:3.32,x:472.9,y:163.6+inc},0).wait(1).to({scaleX:3.23,scaleY:3.23,x:482.8,y:162.3+inc},0).wait(1).to({scaleX:3.13,scaleY:3.13,x:492.6,y:161+inc},0).wait(1).to({scaleX:3.03,scaleY:3.03,x:502.5,y:159.7+inc},0).wait(1).to({scaleX:2.94,scaleY:2.94,x:512.3,y:158.4+inc},0).wait(1).to({scaleX:2.84,scaleY:2.84,x:522.2,y:157+inc},0).wait(1).to({scaleX:2.74,scaleY:2.74,x:532,y:155.7+inc},0).wait(1).to({scaleX:2.64,scaleY:2.64,x:541.9,y:154.4+inc},0).wait(1).to({scaleX:2.55,scaleY:2.55,x:551.7,y:153.1+inc},0).wait(1).to({scaleX:2.45,scaleY:2.45,x:561.6,y:151.7+inc},0).wait(1).to({scaleX:2.35,scaleY:2.35,x:571.4,y:150.4+inc},0).wait(1).to({scaleX:2.26,scaleY:2.26,x:581.3,y:149.1+inc},0).wait(1).to({scaleX:2.16,scaleY:2.16,x:591.1,y:147.8+inc},0).wait(1).to({scaleX:2.06,scaleY:2.06,x:601,y:146.5+inc},0).wait(1).to({scaleX:1.97,scaleY:1.97,x:610.8,y:145.1+inc},0).wait(1).to({scaleX:1.87,scaleY:1.87,x:620.7,y:143.8+inc},0).wait(1).to({scaleX:1.77,scaleY:1.77,x:630.6,y:142.5+inc},0).wait(1).to({scaleX:1.68,scaleY:1.68,x:640.4,y:141.2+inc},0).wait(1).to({scaleX:1.58,scaleY:1.58,x:650.3,y:139.8+inc},0).wait(1).to({scaleX:1.48,scaleY:1.48,x:660.1,y:138.5+inc},0).wait(1).to({scaleX:1.39,scaleY:1.39,x:670,y:137.2+inc},0).wait(1).to({scaleX:1.29,scaleY:1.29,x:679.8,y:135.9+inc},0).wait(1).to({scaleX:1.19,scaleY:1.19,x:689.7,y:134.6+inc},0).wait(1).to({scaleX:1.1,scaleY:1.1,x:699.5,y:133.3+inc},0).wait(1).to({scaleX:1,scaleY:1,x:709.4,y:131.9+inc},0).wait(22).wait(1).to({alpha:0.952},0).wait(1).to({alpha:0.905},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:0.81},0).wait(1).to({alpha:0.762},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.619},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.524},0).wait(1).to({alpha:0.476},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.381},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.238},0).wait(1).to({alpha:0.19},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.095},0).wait(1).to({alpha:0.048},0).wait(1).to({alpha:0},0).wait(80));

	// Num_2
	this.instance_1 = new lib.mc_Num_2();
	this.instance_1.setTransform(419.8,148.1,7.141,7.141,0,0,0,14.5,16);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(51).to({_off:false},0).wait(1).to({scaleX:6.98,scaleY:6.98,x:426.4,y:145.4+inc},0).wait(1).to({scaleX:6.82,scaleY:6.82,x:433,y:142.8+inc},0).wait(1).to({scaleX:6.66,scaleY:6.66,x:439.6,y:140.2+inc},0).wait(1).to({scaleX:6.49,scaleY:6.49,x:446.2,y:137.5+inc},0).wait(1).to({scaleX:6.33,scaleY:6.33,x:452.8,y:134.9+inc},0).wait(1).to({scaleX:6.17,scaleY:6.17,x:459.5,y:132.3+inc},0).wait(1).to({scaleX:6.01,scaleY:6.01,x:466.1,y:129.7+inc},0).wait(1).to({scaleX:5.85,scaleY:5.85,x:472.7,y:127+inc},0).wait(1).to({scaleX:5.69,scaleY:5.69,x:479.3,y:124.4+inc},0).wait(1).to({scaleX:5.53,scaleY:5.53,x:485.9,y:121.8+inc},0).wait(1).to({scaleX:5.36,scaleY:5.36,x:492.5,y:119.2+inc},0).wait(1).to({scaleX:5.2,scaleY:5.2,x:499.1,y:116.5+inc},0).wait(1).to({scaleX:5.04,scaleY:5.04,x:505.8,y:113.9+inc},0).wait(1).to({scaleX:4.88,scaleY:4.88,x:512.4,y:111.3+inc},0).wait(1).to({scaleX:4.72,scaleY:4.72,x:519,y:108.7+inc},0).wait(1).to({scaleX:4.56,scaleY:4.56,x:525.6,y:106.1+inc},0).wait(1).to({scaleX:4.39,scaleY:4.39,x:532.2,y:103.4+inc},0).wait(1).to({scaleX:4.23,scaleY:4.23,x:538.8,y:100.8+inc},0).wait(1).to({scaleX:4.07,scaleY:4.07,x:545.4,y:98.1+inc},0).wait(1).to({scaleX:3.91,scaleY:3.91,x:552.1,y:95.6+inc},0).wait(1).to({scaleX:3.75,scaleY:3.75,x:558.7,y:92.9+inc},0).wait(1).to({scaleX:3.59,scaleY:3.59,x:565.3,y:90.3+inc},0).wait(1).to({scaleX:3.42,scaleY:3.42,x:571.9,y:87.7+inc},0).wait(1).to({scaleX:3.26,scaleY:3.26,x:578.5,y:85.1+inc},0).wait(1).to({scaleX:3.1,scaleY:3.1,x:585.1,y:82.4+inc},0).wait(1).to({scaleX:2.94,scaleY:2.94,x:591.7,y:79.8+inc},0).wait(1).to({scaleX:2.78,scaleY:2.78,x:598.3,y:77.2+inc},0).wait(1).to({scaleX:2.62,scaleY:2.62,x:605,y:74.5+inc},0).wait(1).to({scaleX:2.45,scaleY:2.45,x:611.6,y:71.9+inc},0).wait(1).to({scaleX:2.29,scaleY:2.29,x:618.2,y:69.3+inc},0).wait(1).to({scaleX:2.13,scaleY:2.13,x:624.8,y:66.7+inc},0).wait(1).to({scaleX:1.97,scaleY:1.97,x:631.4,y:64+inc},0).wait(1).to({scaleX:1.81,scaleY:1.81,x:638,y:61.4+inc},0).wait(1).to({scaleX:1.65,scaleY:1.65,x:644.6,y:58.8+inc},0).wait(1).to({scaleX:1.49,scaleY:1.49,x:651.3,y:56.2+inc},0).wait(1).to({scaleX:1.32,scaleY:1.32,x:657.9,y:53.5+inc},0).wait(1).to({scaleX:1.16,scaleY:1.16,x:664.5,y:50.9+inc},0).wait(1).to({scaleX:1,scaleY:1,x:671.1,y:48.3+inc},0).wait(15).wait(1).to({x:675.3,y:47.4+inc},0).wait(1).to({x:679.5,y:46.6+inc},0).wait(1).to({x:683.7,y:45.7+inc},0).wait(1).to({x:687.9,y:44.9+inc},0).wait(1).to({x:692.1,y:44+inc},0).wait(1).to({x:696.3,y:43.2+inc},0).wait(1).to({x:700.5,y:42.4+inc},0).wait(1).to({x:704.7,y:41.5+inc},0).wait(1).to({x:708.9,y:40.6+inc},0).wait(1).to({x:713.1,y:39.8+inc},0).wait(1).to({x:717.3,y:38.9+inc},0).wait(1).to({x:721.5,y:38.1+inc},0).wait(1).to({x:725.6,y:37.2+inc},0).wait(1).to({x:729.8,y:36.4+inc},0).wait(1).to({x:734,y:35.5+inc},0).wait(1).to({x:738.2,y:34.7+inc},0).wait(21).wait(1).to({alpha:0.962},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:0.885},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.808},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.731},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.654},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.577},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.423},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.346},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.269},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.192},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.115},0).wait(1).to({alpha:0.077},0).wait(1).to({alpha:0.038},0).wait(1).to({alpha:0},0).wait(169));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EguJAByIAAjjMBcTAAAIAADjg");
	var mask_graphics_14 = new cjs.Graphics().p("EguJAByIAAjjMBcTAAAIAADjg");
	var mask_graphics_15 = new cjs.Graphics().p("EguJACEIAAkHMBcTAAAIAAEHg");
	var mask_graphics_16 = new cjs.Graphics().p("EguJACWIAAkrMBcTAAAIAAErg");
	var mask_graphics_17 = new cjs.Graphics().p("EguJACoIAAlPMBcTAAAIAAFPg");
	var mask_graphics_18 = new cjs.Graphics().p("EguJAC6IAAlzMBcTAAAIAAFzg");
	var mask_graphics_19 = new cjs.Graphics().p("EguJADMIAAmXMBcTAAAIAAGXg");
	var mask_graphics_20 = new cjs.Graphics().p("EguJADeIAAm7MBcTAAAIAAG7g");
	var mask_graphics_21 = new cjs.Graphics().p("EguJADwIAAnfMBcTAAAIAAHfg");
	var mask_graphics_22 = new cjs.Graphics().p("EguJAECIAAoDMBcTAAAIAAIDg");
	var mask_graphics_23 = new cjs.Graphics().p("EguJAEUIAAonMBcTAAAIAAIng");
	var mask_graphics_24 = new cjs.Graphics().p("EguJAEmIAApLMBcTAAAIAAJLg");
	var mask_graphics_25 = new cjs.Graphics().p("EguJAE4IAApvMBcTAAAIAAJvg");
	var mask_graphics_26 = new cjs.Graphics().p("EguJAFKIAAqTMBcTAAAIAAKTg");
	var mask_graphics_27 = new cjs.Graphics().p("EguJAFcIAAq3MBcTAAAIAAK3g");
	var mask_graphics_28 = new cjs.Graphics().p("EguJAFuIAArbMBcTAAAIAALbg");
	var mask_graphics_29 = new cjs.Graphics().p("EguJAGAIAAr/MBcTAAAIAAL/g");
	var mask_graphics_30 = new cjs.Graphics().p("EguJAGSIAAsjMBcTAAAIAAMjg");
	var mask_graphics_31 = new cjs.Graphics().p("EguJAGjIAAtGMBcTAAAIAANGg");
	var mask_graphics_274 = new cjs.Graphics().p("EguJAGjIAAtGMBcTAAAIAANGg");
	var mask_graphics_275 = new cjs.Graphics().p("EguJAHYIAAuvMBcTAAAIAAOvg");
	var mask_graphics_276 = new cjs.Graphics().p("EguJAINIAAwZMBcTAAAIAAQZg");
	var mask_graphics_277 = new cjs.Graphics().p("EguJAJBIAAyBMBcTAAAIAASBg");
	var mask_graphics_278 = new cjs.Graphics().p("EguJAJ2IAAzrMBcTAAAIAATrg");
	var mask_graphics_279 = new cjs.Graphics().p("EguJAKrIAA1VMBcTAAAIAAVVg");
	var mask_graphics_280 = new cjs.Graphics().p("EguJALfIAA29MBcTAAAIAAW9g");
	var mask_graphics_281 = new cjs.Graphics().p("EguJAMUIAA4nMBcTAAAIAAYng");
	var mask_graphics_282 = new cjs.Graphics().p("EguJANJIAA6RMBcTAAAIAAaRg");
	var mask_graphics_283 = new cjs.Graphics().p("EguJAN9IAA75MBcTAAAIAAb5g");
	var mask_graphics_284 = new cjs.Graphics().p("EguJAOyIAA9jMBcTAAAIAAdjg");
	var mask_graphics_285 = new cjs.Graphics().p("EguJAPnIAA/NMBcTAAAIAAfNg");
	var mask_graphics_286 = new cjs.Graphics().p("EguJAQbMAAAgg1MBcTAAAMAAAAg1g");
	var mask_graphics_287 = new cjs.Graphics().p("EguJARQMAAAgifMBcTAAAMAAAAifg");
	var mask_graphics_288 = new cjs.Graphics().p("EguJASFMAAAgkJMBcTAAAMAAAAkJg");
	var mask_graphics_289 = new cjs.Graphics().p("EguJAS5MAAAglxMBcTAAAMAAAAlxg");
	var mask_graphics_290 = new cjs.Graphics().p("EguJATuMAAAgnbMBcTAAAMAAAAnbg");
	var mask_graphics_291 = new cjs.Graphics().p("EguJAUjMAAAgpFMBcTAAAMAAAApFg");
	var mask_graphics_292 = new cjs.Graphics().p("EguJAVXMAAAgqtMBcTAAAMAAAAqtg");
	var mask_graphics_293 = new cjs.Graphics().p("EguJAWMMAAAgsXMBcTAAAMAAAAsXg");
	var mask_graphics_294 = new cjs.Graphics().p("EguJAXBMAAAguBMBcTAAAMAAAAuBg");
	var mask_graphics_295 = new cjs.Graphics().p("EguJAX1MAAAgvpMBcTAAAMAAAAvpg");
	var mask_graphics_296 = new cjs.Graphics().p("EguJAYqMAAAgxTMBcTAAAMAAAAxTg");
	var mask_graphics_297 = new cjs.Graphics().p("EguJAZfMAAAgy9MBcTAAAMAAAAy9g");
	var mask_graphics_298 = new cjs.Graphics().p("EguJAaTMAAAg0lMBcTAAAMAAAA0lg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:283.6,y:-13}).wait(14).to({graphics:mask_graphics_14,x:283.6,y:-13}).wait(1).to({graphics:mask_graphics_15,x:283.6,y:-11.2}).wait(1).to({graphics:mask_graphics_16,x:283.6,y:-9.4}).wait(1).to({graphics:mask_graphics_17,x:283.6,y:-7.6}).wait(1).to({graphics:mask_graphics_18,x:283.6,y:-5.8}).wait(1).to({graphics:mask_graphics_19,x:283.6,y:-4}).wait(1).to({graphics:mask_graphics_20,x:283.6,y:-2.2}).wait(1).to({graphics:mask_graphics_21,x:283.6,y:-0.4}).wait(1).to({graphics:mask_graphics_22,x:283.6,y:1.3}).wait(1).to({graphics:mask_graphics_23,x:283.6,y:3}).wait(1).to({graphics:mask_graphics_24,x:283.6,y:4.8}).wait(1).to({graphics:mask_graphics_25,x:283.6,y:6.6}).wait(1).to({graphics:mask_graphics_26,x:283.6,y:8.4}).wait(1).to({graphics:mask_graphics_27,x:283.6,y:10.2}).wait(1).to({graphics:mask_graphics_28,x:283.6,y:12}).wait(1).to({graphics:mask_graphics_29,x:283.6,y:13.8}).wait(1).to({graphics:mask_graphics_30,x:283.6,y:15.6}).wait(1).to({graphics:mask_graphics_31,x:283.6,y:17.4}).wait(243).to({graphics:mask_graphics_274,x:283.6,y:17.4}).wait(1).to({graphics:mask_graphics_275,x:283.6,y:22.7}).wait(1).to({graphics:mask_graphics_276,x:283.6,y:27.9}).wait(1).to({graphics:mask_graphics_277,x:283.6,y:33.2}).wait(1).to({graphics:mask_graphics_278,x:283.6,y:38.5}).wait(1).to({graphics:mask_graphics_279,x:283.6,y:43.7}).wait(1).to({graphics:mask_graphics_280,x:283.6,y:49}).wait(1).to({graphics:mask_graphics_281,x:283.6,y:54.2}).wait(1).to({graphics:mask_graphics_282,x:283.6,y:59.5}).wait(1).to({graphics:mask_graphics_283,x:283.6,y:64.8}).wait(1).to({graphics:mask_graphics_284,x:283.6,y:70}).wait(1).to({graphics:mask_graphics_285,x:283.6,y:75.3}).wait(1).to({graphics:mask_graphics_286,x:283.6,y:80.6}).wait(1).to({graphics:mask_graphics_287,x:283.6,y:85.8}).wait(1).to({graphics:mask_graphics_288,x:283.6,y:91.1}).wait(1).to({graphics:mask_graphics_289,x:283.6,y:96.4}).wait(1).to({graphics:mask_graphics_290,x:283.6,y:101.6}).wait(1).to({graphics:mask_graphics_291,x:283.6,y:106.9}).wait(1).to({graphics:mask_graphics_292,x:283.6,y:112.1}).wait(1).to({graphics:mask_graphics_293,x:283.6,y:117.4}).wait(1).to({graphics:mask_graphics_294,x:283.6,y:122.7}).wait(1).to({graphics:mask_graphics_295,x:283.6,y:127.9}).wait(1).to({graphics:mask_graphics_296,x:283.6,y:133.2}).wait(1).to({graphics:mask_graphics_297,x:283.6,y:138.5}).wait(1).to({graphics:mask_graphics_298,x:283.6,y:143.7}).wait(38));

	// MsNs
	this.instance_2 = new lib.mc_MsNs();
	this.instance_2.setTransform(407.6,131.3,1,1,0,0,0,104,43.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(316).to({_off:false},0).wait(1).to({regX:-190.7,regY:45.9,x:112.8,y:133.6,alpha:0.053},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:1},0).wait(1));

	// txt_2_01
	this.txt_3_01 = new cjs.Text(txt['txt_3_01'], "20px Verdana");
	this.txt_3_01.lineHeight = 22;
	this.txt_3_01.lineWidth = 474;

	this.txt_3_01.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_3_01}]}).wait(336));

	// Formula_p3.png
	this.instance_3 = new lib.Formula_p3();
	this.instance_3.setTransform(0.7,99,0.8,0.8);

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(3360000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,477.6,315.4);


(lib.mc_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhAFAIMIAAwXMCALAAAIAAQXg");
	var mask_graphics_38 = new cjs.Graphics().p("EhAFAIMIAAwXMCALAAAIAAQXg");
	var mask_graphics_39 = new cjs.Graphics().p("EhAFAIoIAAxPMCALAAAIAARPg");
	var mask_graphics_40 = new cjs.Graphics().p("EhAFAJDIAAyFMCALAAAIAASFg");
	var mask_graphics_41 = new cjs.Graphics().p("EhAFAJfIAAy9MCALAAAIAAS9g");
	var mask_graphics_42 = new cjs.Graphics().p("EhAFAJ6IAAzzMCALAAAIAATzg");
	var mask_graphics_43 = new cjs.Graphics().p("EhAFAKWIAA0rMCALAAAIAAUrg");
	var mask_graphics_44 = new cjs.Graphics().p("EhAFAKyIAA1jMCALAAAIAAVjg");
	var mask_graphics_45 = new cjs.Graphics().p("EhAFALNIAA2ZMCALAAAIAAWZg");
	var mask_graphics_46 = new cjs.Graphics().p("EhAFALpIAA3RMCALAAAIAAXRg");
	var mask_graphics_47 = new cjs.Graphics().p("EhAFAMEIAA4HMCALAAAIAAYHg");
	var mask_graphics_48 = new cjs.Graphics().p("EhAFAMgIAA4/MCALAAAIAAY/g");
	var mask_graphics_49 = new cjs.Graphics().p("EhAFAM8IAA53MCALAAAIAAZ3g");
	var mask_graphics_50 = new cjs.Graphics().p("EhAFANXIAA6tMCALAAAIAAatg");
	var mask_graphics_51 = new cjs.Graphics().p("EhAFANzIAA7lMCALAAAIAAblg");
	var mask_graphics_52 = new cjs.Graphics().p("EhAFAOOIAA8bMCALAAAIAAcbg");
	var mask_graphics_53 = new cjs.Graphics().p("EhAFAOqIAA9TMCALAAAIAAdTg");
	var mask_graphics_54 = new cjs.Graphics().p("EhAFAPGIAA+LMCALAAAIAAeLg");
	var mask_graphics_55 = new cjs.Graphics().p("EhAFAPhIAA/BMCALAAAIAAfBg");
	var mask_graphics_56 = new cjs.Graphics().p("EhAFAP9IAA/5MCALAAAIAAf5g");
	var mask_graphics_57 = new cjs.Graphics().p("EhAFAQYMAAAggwMCALAAAMAAAAgwg");
	var mask_graphics_104 = new cjs.Graphics().p("EhAFAQYMAAAggwMCALAAAMAAAAgwg");
	var mask_graphics_105 = new cjs.Graphics().p("EhAFAQ2MAAAghrMCALAAAMAAAAhrg");
	var mask_graphics_106 = new cjs.Graphics().p("EhAFARUMAAAginMCALAAAMAAAAing");
	var mask_graphics_107 = new cjs.Graphics().p("EhAFARyMAAAgjjMCALAAAMAAAAjjg");
	var mask_graphics_108 = new cjs.Graphics().p("EhAFASQMAAAgkfMCALAAAMAAAAkfg");
	var mask_graphics_109 = new cjs.Graphics().p("EhAFASuMAAAglbMCALAAAMAAAAlbg");
	var mask_graphics_110 = new cjs.Graphics().p("EhAFATMMAAAgmXMCALAAAMAAAAmXg");
	var mask_graphics_111 = new cjs.Graphics().p("EhAFATqMAAAgnTMCALAAAMAAAAnTg");
	var mask_graphics_112 = new cjs.Graphics().p("EhAFAUIMAAAgoPMCALAAAMAAAAoPg");
	var mask_graphics_113 = new cjs.Graphics().p("EhAFAUmMAAAgpLMCALAAAMAAAApLg");
	var mask_graphics_114 = new cjs.Graphics().p("EhAFAVEMAAAgqHMCALAAAMAAAAqHg");
	var mask_graphics_115 = new cjs.Graphics().p("EhAFAViMAAAgrDMCALAAAMAAAArDg");
	var mask_graphics_116 = new cjs.Graphics().p("EhAFAV/MAAAgr9MCALAAAMAAAAr9g");
	var mask_graphics_117 = new cjs.Graphics().p("EhAFAWdMAAAgs5MCALAAAMAAAAs5g");
	var mask_graphics_118 = new cjs.Graphics().p("EhAFAW7MAAAgt1MCALAAAMAAAAt1g");
	var mask_graphics_119 = new cjs.Graphics().p("EhAFAXZMAAAguxMCALAAAMAAAAuxg");
	var mask_graphics_120 = new cjs.Graphics().p("EhAFAX3MAAAgvtMCALAAAMAAAAvtg");
	var mask_graphics_121 = new cjs.Graphics().p("EhAFAYVMAAAgwpMCALAAAMAAAAwpg");
	var mask_graphics_122 = new cjs.Graphics().p("EhAFAYzMAAAgxlMCALAAAMAAAAxlg");
	var mask_graphics_123 = new cjs.Graphics().p("EhAFAZRMAAAgyhMCALAAAMAAAAyhg");
	var mask_graphics_124 = new cjs.Graphics().p("EhAFAZvMAAAgzdMCALAAAMAAAAzdg");
	var mask_graphics_125 = new cjs.Graphics().p("EhAFAaNMAAAg0ZMCALAAAMAAAA0Zg");
	var mask_graphics_126 = new cjs.Graphics().p("EhAFAarMAAAg1VMCALAAAMAAAA1Vg");
	var mask_graphics_127 = new cjs.Graphics().p("EhAFAbJMAAAg2RMCALAAAMAAAA2Rg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:406.4,y:51}).wait(38).to({graphics:mask_graphics_38,x:406.4,y:51}).wait(1).to({graphics:mask_graphics_39,x:406.4,y:53.7}).wait(1).to({graphics:mask_graphics_40,x:406.4,y:56.5}).wait(1).to({graphics:mask_graphics_41,x:406.4,y:59.2}).wait(1).to({graphics:mask_graphics_42,x:406.4,y:62}).wait(1).to({graphics:mask_graphics_43,x:406.4,y:64.8}).wait(1).to({graphics:mask_graphics_44,x:406.4,y:67.5}).wait(1).to({graphics:mask_graphics_45,x:406.4,y:70.3}).wait(1).to({graphics:mask_graphics_46,x:406.4,y:73}).wait(1).to({graphics:mask_graphics_47,x:406.4,y:75.8}).wait(1).to({graphics:mask_graphics_48,x:406.4,y:78.6}).wait(1).to({graphics:mask_graphics_49,x:406.4,y:81.3}).wait(1).to({graphics:mask_graphics_50,x:406.4,y:84.1}).wait(1).to({graphics:mask_graphics_51,x:406.4,y:86.8}).wait(1).to({graphics:mask_graphics_52,x:406.4,y:89.6}).wait(1).to({graphics:mask_graphics_53,x:406.4,y:92.4}).wait(1).to({graphics:mask_graphics_54,x:406.4,y:95.1}).wait(1).to({graphics:mask_graphics_55,x:406.4,y:97.9}).wait(1).to({graphics:mask_graphics_56,x:406.4,y:100.6}).wait(1).to({graphics:mask_graphics_57,x:406.4,y:103.4}).wait(47).to({graphics:mask_graphics_104,x:406.4,y:103.4}).wait(1).to({graphics:mask_graphics_105,x:406.4,y:106.4}).wait(1).to({graphics:mask_graphics_106,x:406.4,y:109.4}).wait(1).to({graphics:mask_graphics_107,x:406.4,y:112.4}).wait(1).to({graphics:mask_graphics_108,x:406.4,y:115.4}).wait(1).to({graphics:mask_graphics_109,x:406.4,y:118.4}).wait(1).to({graphics:mask_graphics_110,x:406.4,y:121.4}).wait(1).to({graphics:mask_graphics_111,x:406.4,y:124.4}).wait(1).to({graphics:mask_graphics_112,x:406.4,y:127.3}).wait(1).to({graphics:mask_graphics_113,x:406.4,y:130.3}).wait(1).to({graphics:mask_graphics_114,x:406.4,y:133.3}).wait(1).to({graphics:mask_graphics_115,x:406.4,y:136.3}).wait(1).to({graphics:mask_graphics_116,x:406.4,y:139.3}).wait(1).to({graphics:mask_graphics_117,x:406.4,y:142.3}).wait(1).to({graphics:mask_graphics_118,x:406.4,y:145.3}).wait(1).to({graphics:mask_graphics_119,x:406.4,y:148.3}).wait(1).to({graphics:mask_graphics_120,x:406.4,y:151.3}).wait(1).to({graphics:mask_graphics_121,x:406.4,y:154.3}).wait(1).to({graphics:mask_graphics_122,x:406.4,y:157.3}).wait(1).to({graphics:mask_graphics_123,x:406.4,y:160.3}).wait(1).to({graphics:mask_graphics_124,x:406.4,y:163.3}).wait(1).to({graphics:mask_graphics_125,x:406.4,y:166.3}).wait(1).to({graphics:mask_graphics_126,x:406.4,y:169.3}).wait(1).to({graphics:mask_graphics_127,x:406.4,y:172.2}).wait(55));

	// Capa 4
	this.instance = new lib.mc_formula_p2();
	this.instance.setTransform(120.9,294,1,1,0,0,0,120.4,39.5);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:39.4,y:293.9},0).wait(146).wait(1).to({x:139.5,y:289.1},0).wait(1).to({x:158.1,y:284.4},0).wait(1).to({x:176.8,y:279.7},0).wait(1).to({x:195.4,y:275},0).wait(1).to({x:214.1,y:270.3},0).wait(1).to({x:232.7,y:265.6},0).wait(1).to({x:251.4,y:260.8},0).wait(1).to({x:270,y:256.1},0).wait(1).to({x:288.7,y:251.4},0).wait(1).to({x:307.3,y:246.7},0).wait(1).to({x:326,y:242},0).wait(1).to({x:344.6,y:237.3},0).wait(1).to({x:363.3,y:232.5},0).wait(1).to({x:381.9,y:227.8},0).wait(1).to({x:400.6,y:223.1},0).wait(1).to({x:419.2,y:218.4},0).wait(1).to({x:437.9,y:213.7},0).wait(1).to({x:456.5,y:209},0).wait(1).to({x:475.2,y:204.2},0).wait(1).to({x:493.8,y:199.5},0).wait(1).to({x:512.5,y:194.8},0).wait(1).to({x:531.1,y:190.1},0).wait(1).to({x:549.8,y:185.4},0).wait(1).to({x:568.4,y:180.7},0).wait(1).to({x:587.1,y:175.9},0).wait(1).to({x:605.7,y:171.2},0).wait(1).to({x:624.4,y:166.5},0).wait(1).to({x:643,y:161.8},0).wait(1).to({x:661.7,y:157.1},0).wait(1).to({x:680.3,y:152.4},0).wait(1).to({x:699,y:147.6},0).wait(1).to({x:717.6,y:142.9},0).wait(1).to({x:736.3,y:138.2},0).wait(1).to({x:754.9,y:133.5},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.Formula_p2();
	this.instance_1.setTransform(0.5,254.5,0.453,0.453);

	this.instance_2 = new lib.ImatgeBotons_4();
	this.instance_2.setTransform(0,153.6,0.549,0.549);

	this.instance_3 = new lib.ImatgeBotons_3();
	this.instance_3.setTransform(0,48.9,0.549,0.549);

	this.txt_2_01 = new cjs.Text(txt['txt_2_01'], "20px Verdana");
	this.txt_2_01.lineHeight = 22;
	this.txt_2_01.lineWidth = 715;

	this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.txt_2_01.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_2_01},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(182000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,719.5,333.4);


(lib.mc_p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg98AIQIAAwfMB75AAAIAAQfg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg98AIQIAAwfMB75AAAIAAQfg");
	var mask_graphics_60 = new cjs.Graphics().p("Eg98AIsIAAxXMB75AAAIAARXg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg98AJIIAAyPMB75AAAIAASPg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg98AJlIAAzJMB75AAAIAATJg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg98AKBIAA0BMB75AAAIAAUBg");
	var mask_graphics_64 = new cjs.Graphics().p("Eg98AKdIAA05MB75AAAIAAU5g");
	var mask_graphics_65 = new cjs.Graphics().p("Eg98AK5IAA1xMB75AAAIAAVxg");
	var mask_graphics_66 = new cjs.Graphics().p("Eg98ALWIAA2rMB75AAAIAAWrg");
	var mask_graphics_67 = new cjs.Graphics().p("Eg98ALyIAA3jMB75AAAIAAXjg");
	var mask_graphics_68 = new cjs.Graphics().p("Eg98AMOIAA4bMB75AAAIAAYbg");
	var mask_graphics_69 = new cjs.Graphics().p("Eg98AMrIAA5VMB75AAAIAAZVg");
	var mask_graphics_70 = new cjs.Graphics().p("Eg98ANHIAA6NMB75AAAIAAaNg");
	var mask_graphics_71 = new cjs.Graphics().p("Eg98ANjIAA7FMB75AAAIAAbFg");
	var mask_graphics_72 = new cjs.Graphics().p("Eg98AN/IAA79MB75AAAIAAb9g");
	var mask_graphics_73 = new cjs.Graphics().p("Eg98AOcIAA83MB75AAAIAAc3g");
	var mask_graphics_74 = new cjs.Graphics().p("Eg98AO4IAA9vMB75AAAIAAdvg");
	var mask_graphics_75 = new cjs.Graphics().p("Eg98APUIAA+nMB75AAAIAAeng");
	var mask_graphics_76 = new cjs.Graphics().p("Eg98APwIAA/fMB75AAAIAAffg");
	var mask_graphics_77 = new cjs.Graphics().p("Eg98AQNMAAAggZMB75AAAMAAAAgZg");
	var mask_graphics_78 = new cjs.Graphics().p("Eg98AQpMAAAghRMB75AAAMAAAAhRg");
	var mask_graphics_128 = new cjs.Graphics().p("Eg98AQpMAAAghRMB75AAAMAAAAhRg");
	var mask_graphics_129 = new cjs.Graphics().p("Eg98ARTMAAAgilMB75AAAMAAAAilg");
	var mask_graphics_130 = new cjs.Graphics().p("Eg98AR8MAAAgj3MB75AAAMAAAAj3g");
	var mask_graphics_131 = new cjs.Graphics().p("Eg98ASmMAAAglLMB75AAAMAAAAlLg");
	var mask_graphics_132 = new cjs.Graphics().p("Eg98ATQMAAAgmfMB75AAAMAAAAmfg");
	var mask_graphics_133 = new cjs.Graphics().p("Eg98AT5MAAAgnxMB75AAAMAAAAnxg");
	var mask_graphics_134 = new cjs.Graphics().p("Eg98AUjMAAAgpFMB75AAAMAAAApFg");
	var mask_graphics_135 = new cjs.Graphics().p("Eg98AVNMAAAgqZMB75AAAMAAAAqZg");
	var mask_graphics_136 = new cjs.Graphics().p("Eg98AV2MAAAgrrMB75AAAMAAAArrg");
	var mask_graphics_137 = new cjs.Graphics().p("Eg98AWgMAAAgs/MB75AAAMAAAAs/g");
	var mask_graphics_138 = new cjs.Graphics().p("Eg98AXKMAAAguTMB75AAAMAAAAuTg");
	var mask_graphics_139 = new cjs.Graphics().p("Eg98AXzMAAAgvlMB75AAAMAAAAvlg");
	var mask_graphics_140 = new cjs.Graphics().p("Eg98AYdMAAAgw5MB75AAAMAAAAw5g");
	var mask_graphics_141 = new cjs.Graphics().p("Eg98AZHMAAAgyNMB75AAAMAAAAyNg");
	var mask_graphics_142 = new cjs.Graphics().p("Eg98AZwMAAAgzfMB75AAAMAAAAzfg");
	var mask_graphics_143 = new cjs.Graphics().p("Eg98AaaMAAAg0zMB75AAAMAAAA0zg");
	var mask_graphics_144 = new cjs.Graphics().p("Eg98AbEMAAAg2HMB75AAAMAAAA2Hg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:390.2,y:45.2}).wait(59).to({graphics:mask_graphics_59,x:390.2,y:45.2}).wait(1).to({graphics:mask_graphics_60,x:390.2,y:48.1}).wait(1).to({graphics:mask_graphics_61,x:390.2,y:50.9}).wait(1).to({graphics:mask_graphics_62,x:390.2,y:53.7}).wait(1).to({graphics:mask_graphics_63,x:390.2,y:56.5}).wait(1).to({graphics:mask_graphics_64,x:390.2,y:59.4}).wait(1).to({graphics:mask_graphics_65,x:390.2,y:62.2}).wait(1).to({graphics:mask_graphics_66,x:390.2,y:65}).wait(1).to({graphics:mask_graphics_67,x:390.2,y:67.8}).wait(1).to({graphics:mask_graphics_68,x:390.2,y:70.7}).wait(1).to({graphics:mask_graphics_69,x:390.2,y:73.5}).wait(1).to({graphics:mask_graphics_70,x:390.2,y:76.3}).wait(1).to({graphics:mask_graphics_71,x:390.2,y:79.2}).wait(1).to({graphics:mask_graphics_72,x:390.2,y:82}).wait(1).to({graphics:mask_graphics_73,x:390.2,y:84.8}).wait(1).to({graphics:mask_graphics_74,x:390.2,y:87.6}).wait(1).to({graphics:mask_graphics_75,x:390.2,y:90.5}).wait(1).to({graphics:mask_graphics_76,x:390.2,y:93.3}).wait(1).to({graphics:mask_graphics_77,x:390.2,y:96.1}).wait(1).to({graphics:mask_graphics_78,x:390.2,y:99}).wait(50).to({graphics:mask_graphics_128,x:390.2,y:99}).wait(1).to({graphics:mask_graphics_129,x:390.2,y:103.1}).wait(1).to({graphics:mask_graphics_130,x:390.2,y:107.3}).wait(1).to({graphics:mask_graphics_131,x:390.2,y:111.5}).wait(1).to({graphics:mask_graphics_132,x:390.2,y:115.6}).wait(1).to({graphics:mask_graphics_133,x:390.2,y:119.8}).wait(1).to({graphics:mask_graphics_134,x:390.2,y:124}).wait(1).to({graphics:mask_graphics_135,x:390.2,y:128.1}).wait(1).to({graphics:mask_graphics_136,x:390.2,y:132.3}).wait(1).to({graphics:mask_graphics_137,x:390.2,y:136.5}).wait(1).to({graphics:mask_graphics_138,x:390.2,y:140.6}).wait(1).to({graphics:mask_graphics_139,x:390.2,y:144.8}).wait(1).to({graphics:mask_graphics_140,x:390.2,y:149}).wait(1).to({graphics:mask_graphics_141,x:390.2,y:153.1}).wait(1).to({graphics:mask_graphics_142,x:390.2,y:157.3}).wait(1).to({graphics:mask_graphics_143,x:390.2,y:161.5}).wait(1).to({graphics:mask_graphics_144,x:390.2,y:165.6}).wait(65));

	// Formula
	this.instance = new lib.mc_formula_p1();
	this.instance.setTransform(121,294.6,1,1,0,0,0,121,39.8);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(181).wait(1).to({x:144.4,y:284.8},0).wait(1).to({x:167.8,y:275.1},0).wait(1).to({x:191.2,y:265.4},0).wait(1).to({x:214.6,y:255.7},0).wait(1).to({x:238,y:246},0).wait(1).to({x:261.5,y:236.3},0).wait(1).to({x:284.8,y:226.5},0).wait(1).to({x:308.3,y:216.8},0).wait(1).to({x:331.7,y:207.1},0).wait(1).to({x:355.1,y:197.4},0).wait(1).to({x:378.5,y:187.7},0).wait(1).to({x:401.9,y:178},0).wait(1).to({x:425.3,y:168.2},0).wait(1).to({x:448.7,y:158.5},0).wait(1).to({x:472.1,y:148.8},0).wait(1).to({x:495.5,y:139.1},0).wait(1).to({x:519,y:129.4},0).wait(1).to({x:542.4,y:119.7},0).wait(1).to({x:565.8,y:109.9},0).wait(1).to({x:589.2,y:100.2},0).wait(1).to({x:612.6,y:90.5},0).wait(1).to({x:636,y:80.8},0).wait(1).to({x:659.4,y:71.1},0).wait(1).to({x:682.8,y:61.4},0).wait(1).to({x:706.2,y:51.6},0).wait(1).to({x:729.6,y:41.9},0).wait(1).to({x:753.1,y:32.2},0).wait(1));

	// Capa 1
	this.instance_1 = new lib.mc_formula_p1();
	this.instance_1.setTransform(121,294.6,1,1,0,0,0,121,39.8);

	this.instance_2 = new lib.ImatgeBotons_2();
	this.instance_2.setTransform(0,154.4,0.5,0.5);

	this.instance_3 = new lib.ImatgeBotons_1();
	this.instance_3.setTransform(0,46.5,0.5,0.5);

	this.txt_1_01 = new cjs.Text(txt['txt_1_01'], "20px Verdana");
	this.txt_1_01.lineHeight = 22;
	this.txt_1_01.lineWidth = 715;
this.txt_1_01.setTransform(0,incremento);
	this.instance_1.mask = this.instance_2.mask = this.instance_3.mask = this.txt_1_01.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_1_01},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(2090000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,719.5,334.3);

 (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    
    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
    
     (lib.btn_practica = function (texto,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);
   
     (lib.fadeText = function (textohtml,espera,delay,mode, startPosition, loop) {
         espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        this.texto=new cjs.DOMElement(textohtml);
        this.texto.alpha=0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
     (lib.fadeElement = function (elemento,espera,delay,mode, startPosition, loop) {
           espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}