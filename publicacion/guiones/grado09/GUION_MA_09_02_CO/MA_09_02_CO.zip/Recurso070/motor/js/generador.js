Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,"#000000",false];
		Random.init(semilla,100);
		
        this.lVariaciones=new Array();
    
        this.lEnunciados_STRING=new Array();
        this.lEnunciados_SPRITE=new Array();
        this.llRespuestas_SPRITE=new Array();
        this.lIndicesOK_INT=new Array();
        
        //this.listAux=new Array();
        this.enun = "";
        this.co_respuestas=new createjs.Sprite();
        this.lTiposVariaciones=new Array();

		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar(this.nOp, Random.integer(0,Motor.lEnunciados[this.nOp].length-1));
			
			
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			
			
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=80;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function(contexto, enfoque)
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
		}
		
        EA._formatoBase=["Verdana",20,"#000000",false];
		this.ea=EA.ini('');
        co_pregunta.addChild(this.ea);
		
		//declara variables internas:
		//var nAux,rr;
		//var sAux;
		//var lAux;
		//var hor,min,seg,signo;
		//var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		//var a1,an;
		var V;
        var base,ind,exp,rad,rad2,coef,ind1,ind2,exp1,exp2;
        var N,M,P,Q,A,B,R,T;
        var ea,ea2,ea3;
        var signo;
        var subEnfoque1,subEnfoque2;
        var sAux;
        var nAux;
        var lAux;
        var i,j,k,suma;
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		
		
		this.enun = Motor.lEnunciados[contexto][enfoque];
		
		//console.log(this.enun);
		
		//var contexto1 = 9;
		
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			
            switch(contexto){
				case 0:
					while(true){
                        M=Random.integer(1,5);
                        N=Random.integer(2,6);
                        P=Random.integer(1,5);
                        Q=Random.integer(2,6);
                        lAux=JL.simplificar([M*Q+P*N,N*Q]);
                        if((M!=N)&&(P!=Q)&&(lAux[0]!=lAux[1])){break}
                    }
                    A=lAux[0];B=lAux[1];
                    switch(enfoque){
                        case 0:
                            //debugger;
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()), ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic('2 ',this.ea);
                            //console.log("Bounds ea2 : " + ea2.getBounds());
                            EA.adcStatic(ea2,this.ea,- ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic(' ·  2 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(P.toString(),Q.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2, this.ea, - ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic(' =   ',this.ea);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            //var sp = EA.pot('2',JL.cursiva('k'));
                            EA.adcStatic(EA.rai(EA.pot('2',JL.cursiva('k')),B),this.ea);
                            //EA.adcStatic(EA.rai(sp, B), this.ea);
                            //EA.adcStatic(sp, this.ea);
                            this.lAlternativas=this.getAlternativas(A,0,3,[1,20]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 1://
                    while(true){
                        M=Random.integer(1,7);
                        N=Random.integer(2,7);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];
                        N=lAux[1];
                        P=Random.integer(2,7);
                        Q=Random.integer(2,7);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];
                        Q=lAux[1];
                        lAux=JL.simplificar([M*Q+P*N,N*Q]);
                        if((N!=1)&&(Q!=1)&&(lAux[1]!=1)){break}
                    }
                    A=lAux[0];B=lAux[1];
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(' 3 ',this.ea);
                            EA.adcStatic(ea2, this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic(' ·   ',this.ea);
                            if(P>1){
                                EA.adcStatic(EA.rai(EA.pot('3',P.toString()),Q),this.ea);
                            }else{
                                EA.adcStatic(EA.rai('3',Q),this.ea);
                            }
                            EA.adcStatic(' =  3',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(JL.cursiva('k'),B.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            
                            
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 2://
                    while(true){
                        M=Random.integer(2,7);
                        N=Random.integer(2,7,[M]);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];N=lAux[1];
                        P=Random.integer(1,5);
                        Q=Random.integer(2,6,[P]);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];Q=lAux[1];
                        lAux=JL.simplificar([M*P,N*Q]);
                        A=lAux[0];B=lAux[1];
                        if((N>1)&&(Q>1)&&(A%B>0)){break}
                    }
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            ea2=EA.ini(' ');
                            if(M>1){
                                EA.adcStatic(EA.rai(EA.pot('5',M.toString()),N),ea2);
                            }else{
                                EA.adcStatic(EA.rai('5',N),ea2);
                            }
                            ea2=EA.par(ea2);
                            EA.adcStatic(ea2,this.ea);
                            EA.adcStatic(" ",this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(P.toString(), Q.toString()),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3,-6);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(' = 5 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(JL.cursiva('k'), B.toString()),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3,-10);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 3://
                    while(true){
                        M=Random.integer(1,7);
                        N=Random.integer(2,7);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];N=lAux[1];
                        P=Random.integer(2,7);
                        Q=Random.integer(2,7);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];Q=lAux[1];
                        lAux=JL.simplificar([M*Q-P*N,N*Q]);
                        if((N!=1)&&(Q!=1)&&(lAux[1]!=1)&&(M*Q>N*P)){break}
                    }
                    A=lAux[0];B=lAux[1];
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic('3 ',this.ea);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic('  :   ',this.ea);
                            if(P>1){
                                EA.adcStatic(EA.rai(EA.pot('3',P.toString()),Q),this.ea);
                            }else{
                                EA.adcStatic(EA.rai('3',Q),this.ea);
                            }
                            EA.adcStatic(' =  3 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(JL.cursiva('k'),B.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 4://
                    switch(enfoque){
                        case 0:
                            while(true){
                                M=Random.integer(3,9);
                                N=Random.integer(1,6);
                                P=Random.integer(2,5);
                                Q=Random.integer(2,5);
                                lAux=JL.simplificar([M*Q+N,P*Q]);
                                A=lAux[0];B=lAux[1];
                                if(B>1){break}
                            }
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            //ea=EA.ini(' ');
                            //addChild(ea);
                            //ea.x=400;ea.y=300;
                            ea2=EA.ini(' ');
                            if(N>1){
                                EA.adcStatic(EA.pot(JL.cursiva('x'),N.toString()),ea2);
                            }else{
                                EA.adcStatic(JL.cursiva('x'),ea2);
                            }
                            //EA.adcStatic(" ", ea2);
                            ea2=EA.rai(ea2,Q);
                            ea3=EA.ini(' ');
                            EA.adcStatic(EA.pot(JL.cursiva('x'),M.toString()),ea3);
                            EA.adcStatic('    ',ea3);
                            EA.adcStatic(ea2,ea3);
                            EA.adcStatic(EA.rai(ea3,P),this.ea);
                            EA.adcStatic('  =  '+JL.cursiva('x'),this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(JL.cursiva('k'),B.toString()),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 5://

                    var nAux;
                    while(true){
                        M=Random.integer(1,5);
                        N=Random.integer(2,6);
                        P=Random.integer(1,5);
                        Q=Random.integer(2,6);
                        lAux=JL.simplificar([M*Q+P*N,N*Q]);
                        A=lAux[0];B=lAux[1];
                        if((M!=N)&&(P!=Q)&&(B!=1)){
                            break;
                        }
                    }
                    
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic('2 ',this.ea);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic('  ·  2 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(P.toString(),Q.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic(' =   ',this.ea);
                            EA.adcStatic(EA.rai(JL.cursiva('k'), B),this.ea);
                            nAux=Math.pow(2,A);
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*nAux+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 6://
                    while(true){
                        M=Random.integer(1,7);
                        N=Random.integer(2,7);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];N=lAux[1];
                        P=Random.integer(2,7);
                        Q=Random.integer(2,7);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];Q=lAux[1];
                        lAux=JL.simplificar([M*Q+P*N,N*Q]);
                        if((N!=1)&&(Q!=1)&&(lAux[1]!=1)){break}
                    }

                    A=lAux[0];B=lAux[1];
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic('4 ',this.ea);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5, -3);
                            EA.adcStatic(' ·   ',this.ea);
                            if(P>1){
                                EA.adcStatic(EA.rai(EA.pot('4',P.toString()),Q),this.ea);
                            }else{
                                EA.adcStatic(EA.rai('4',Q),this.ea);
                            }
                            EA.adcStatic(' =  4 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(A.toString(),JL.cursiva('k')),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            this.lAlternativas=this.getAlternativas(B,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 7://
                    while(true){
                        M=Random.integer(2,7);
                        N=Random.integer(2,7,[M]);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];N=lAux[1];
                        P=Random.integer(1,5);
                        Q=Random.integer(2,6,[P]);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];Q=lAux[1];
                        lAux=JL.simplificar([M*P,N*Q]);
                        A=lAux[0];B=lAux[1];
                        if((N>1)&&(Q>1)&&(A%B>0)){break}
                    }
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            ea2=EA.ini(' ');
                            if(M>1){
                                EA.adcStatic(EA.rai(EA.pot('4',M.toString()),N),ea2);
                            }else{
                                EA.adcStatic(EA.rai('4',N),ea2);
                            }
                            EA.adcStatic(" ",ea2);//separa los parentesis
                            ea2=EA.par(ea2);
                            EA.adcStatic(ea2,this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(P.toString(),Q.toString()),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5, +3);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(' =  4',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(A.toString(),JL.cursiva('k')),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            this.lAlternativas=this.getAlternativas(B,0,3,[2,2*A+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 8://
                    while(true){
                        M=Random.integer(1,7);
                        N=Random.integer(2,7);
                        lAux=JL.simplificar([M,N]);
                        M=lAux[0];N=lAux[1];
                        P=Random.integer(2,7);
                        Q=Random.integer(2,7);
                        lAux=JL.simplificar([P,Q]);
                        P=lAux[0];Q=lAux[1];
                        lAux=JL.simplificar([M*Q-P*N,N*Q]);
                        if((N!=1)&&(Q!=1)&&(lAux[1]!=1)&&(M*Q>N*P)){break}
                    }
                    A=lAux[0];B=lAux[1];
                    switch(enfoque){
                        case 0:
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(M.toString(),N.toString()),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic('3 ',this.ea);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            EA.adcStatic(' :   ',this.ea);
                            if(P>1){
                                EA.adcStatic(EA.rai(EA.pot('3',P.toString()),Q),this.ea);
                            }else{
                                EA.adcStatic(EA.rai('3',Q),this.ea);
                            }
                            EA.adcStatic(' =  3 ',this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(A.toString(),JL.cursiva('k')),ea2);
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            this.lAlternativas=this.getAlternativas(A,0,3,[2,2*B+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
                case 9://
                    switch(enfoque){
                        case 0:
                            while(true){
                                M=Random.integer(3,9);
                                N=Random.integer(1,6);
                                P=Random.integer(2,5);
                                Q=Random.integer(2,5);
                                lAux=JL.simplificar([M*Q+N,P*Q]);
                                A=lAux[0];B=lAux[1];
                                if(B>1){break}
                            }
                            EA._formatoBase=["Verdana",30,"#000000",false];
                            //ea=EA.ini(' ');
                            //addChild(ea);
                            //ea.x=400;ea.y=300;
                            ea2=EA.ini(' ');
                            if(N>1){
                                EA.adcStatic(EA.pot(JL.cursiva('x'),N.toString()),ea2);
                            }else{
                                EA.adcStatic(JL.cursiva('x'),ea2);
                            }
                            ea2=EA.rai(ea2,Q);
                            ea3=EA.ini(' ');
                            EA.adcStatic(EA.pot(JL.cursiva('x'),M.toString()),ea3);
                            EA.adcStatic('   ',ea3);
                            EA.adcStatic(ea2,ea3);
                            EA.adcStatic(EA.rai(ea3,P),this.ea);
                            EA.adcStatic('  =  '+JL.cursiva('x'),this.ea);
                            EA._formatoBase=["Verdana",15,"#000000",false];
                            ea2=EA.ini(' ');
                            EA.adfStatic(EA.fra(A.toString(),JL.cursiva('k')),ea2);
                            EA.adcStatic(ea2,this.ea,-ea2.getBounds().height/3 - 5,-3);
                            this.lAlternativas=this.getAlternativas(B,0,3,[1,2*B+9]);
                            EA._formatoBase=["Verdana",20,"#000000",false];
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                            }
                        break;
                    }
                break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=this.lAlternativas[1];
			//lRespuestasOK[nOp]=lAlts[1];
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}