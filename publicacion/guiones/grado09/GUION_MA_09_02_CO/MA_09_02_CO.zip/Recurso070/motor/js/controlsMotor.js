function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    this.idPregunta = pregunta.id;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciadoParseado ;//pregunta.enunciado;
    this.video = pregunta.video;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = 10 ;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;
	
	
	this.validacio = true;
	this.respostes = new Array();
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    
    this.formula = operacio.preguntaSprite;
    this.contenedor.addChild( this.formula );

    //var num_respuestas =  pregunta.respuestas.length;
    for(var i=0; i < 4; i++)
	{
    	var index = 0;

		var resp = new respuesta();
		resp.id = i;
		//console.log(operacio.RespuestaSprite[i]);
		resp.text = operacio.RespuestaSprite[i];//(i * 2.5).toString();
		resp.correcte = (operacio.solucion == i)?  '1' : '0';
		
		var cb = new CheckBox( resp, this, i, pregunta);
    	cb.contenedor.y = 160 + (275 / 4) * i;
    	cb.contenedor.x = 85;
    	this.contenedor.addChild(cb.contenedor);
    	
    	this.respostes.push(cb);
    }	

}

function CheckBox(resposta, pagina, index, pregunta)
{
	//console.log(resposta.text);
	this.correcte = resposta.correcte;
	this.checked= false;
	this.repostaUnica = Contenedor.datosXML.respuestaunica;
	this.paginaPare = pagina;
	this.contenedor = new createjs.Container();
	this.id = index;
	this.idResposta = resposta.id;
	//debugger;
	this.texte = new createjs.RichText();
    this.texte.text = resposta.text;
    this.texte.font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Arial" : "16px Arial" ;
	this.texte.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 18 : 16 ;
	this.texte.color = "#0D3158";
	this.texte.x = 45;
	this.texte.y = 2 ;
	this.texte.lineWidth = 440;
	this.texte.lineHeight = 22;
	this.texte.mouseEnabled = false;
	
	//this.fonsText = new createjs.Shape();
	//this.fonsText.graphics.beginFill("#fff").drawRoundRect(0, 0, 480, this.texte.getMeasuredHeight() + 12, 3);
	
	//this.marcText = new createjs.Shape();
	//this.marcText.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 480, this.texte.getMeasuredHeight() + 12, 3);
	
	this.areaText = new createjs.Container();
	this.areaText.x = 40;
	this.areaText.y = -3;

	this.areaText.addChild( this.fonsText );
	this.areaText.addChild( this.marcText );
	this.areaText.alpha = 0.01;
	
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawCircle(10,12,16); //.drawRoundRect(0, 0, 30, 30, 3);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawCircle(10,12,16);//.drawRoundRect(0, 0, 30, 30, 3);
	
	this.ok = new createjs.Shape(); //new createjs.Bitmap("motor/images/check_ok.png");
	this.ok.graphics.beginFill("#41A62A").drawCircle(5,4,9);
	this.ko = new createjs.Shape(); //new createjs.Bitmap("motor/images/check_ko.png");
	this.ko.graphics.beginFill("#E1001A").drawCircle(5,4,9);
	this.chk = new createjs.Shape(); //new createjs.Bitmap("motor/images/check_base.png");
	this.chk.graphics.beginFill("#F8B334").drawCircle(5,4,9);
	
	this.correccio = new createjs.Shape();  
	this.correccio.graphics.beginFill("#F8B334").drawCircle(-30,12,9);
	
	this.buit = new createjs.DisplayObject();
	
	this.base = new createjs.Container();
	this.base.x = 5;
	this.base.y = 8;
	this.base.mouseEnabled = true;
	
	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	this.area.addChild( this.base );
	
	
	this.contenedor.addChild( this.areaText );
	//this.contenedor.addChild( this.explicacion );
	//this.contenedor.addChild( this.texte );
	resposta.text.x = 45;
	resposta.text.y = 2 ;
	
	this.contenedor.addChild( this.area );
	this.contenedor.addChild( this.texte );
	
	this.area.on("mousedown", this.pressHandler, this);
	this.area.on("rollover", this.overHandler, this);
	this.area.on("rollout", this.outHandler, this);
	//this.areaText.on("mousedown", this.pressHandler, this);
	//this.desactivar();

}
CheckBox.prototype.pressHandler = function(evt){
	if(evt.primary){
		//deseleccionem en cas de resposta unica
		if(this.repostaUnica == 1)
		{
			for(key in this.paginaPare.respostes)
			{
				if(this.paginaPare.respostes[key].id != this.id)
				{
					this.paginaPare.respostes[key].base.removeAllChildren();
					this.paginaPare.respostes[key].areaText.alpha = 0.01;
					this.paginaPare.respostes[key].checked= false;
				}
			}
		}
		
		//seleccionem o deseleccionem
		if(this.checked) {
			this.base.removeAllChildren();
			this.areaText.alpha = 0.01;
		}
		else 
		{
			this.base.removeAllChildren();
			this.base.addChild(this.chk);
			this.base.alpha = 1;
			this.areaText.alpha = 1;
		}
		
		this.checked = !this.checked;
		
		Contenedor.checkPagina();
	}
}
CheckBox.prototype.overHandler = function(){
	if(!this.checked )
	{
		this.base.addChild(this.chk);
		this.base.alpha = 0.5;
	}
}
CheckBox.prototype.outHandler = function(){
	if(!this.checked) this.base.removeAllChildren();
}
CheckBox.prototype.desactivar = function(){
	this.area.removeAllEventListeners();
	this.areaText.removeAllEventListeners();
}
CheckBox.prototype.activar = function(){
	if( !this.area.hasEventListener("mousedown") )
	{
	   this.area.on("mousedown", this.pressHandler, this);
	   this.areaText.on("mousedown", this.pressHandler, this);
	}
}
CheckBox.prototype.bona = function(){
	this.area.addChild( this.correccio );
}

CheckBox.prototype.clear = function(){
	this.base.removeAllChildren();
	this.areaText.alpha = 0.01;
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawCircle(10,12,16);
	this.checked= false;
}
CheckBox.prototype.error = function(){
	this.base.removeAllChildren();
	this.base.addChild(this.ko);
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawCircle(10,12,16);
}

CheckBox.prototype.correct = function(){
	this.base.removeAllChildren();
	this.base.addChild(this.ok);
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawCircle(10,12,16);
}
