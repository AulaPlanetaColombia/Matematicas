function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciadoJ ;//pregunta.enunciado;
    this.video = pregunta.video;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = "";
	this.formula = operacio.formula;
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    this.contenedor.addChild( this.formula ); 
    
   	this.addLine( operacio  );
   	 

	this.valorNum = operacio.respuestaNum; 
	this.valorStr = operacio.respuestaString; 

	this.exponent= "";
}

Pagina.prototype.addLine = function(operacio){
	
	this.baseNum = new createjs.RichText();
	this.baseNum.text = " =  " + operacio.base.toString();
    this.baseNum.font = (Contenedor.datosXML.plataforma.grado == 1)? "36px Arial" : "26px Arial" ;
	this.baseNum.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 36 : 26 ;
	this.baseNum.color = "#0D3158";
	this.baseNum.x = this.formula.getBounds().x + this.formula.getBounds().width + 25;
	this.baseNum.y = this.formula.getBounds().y + this.formula.getBounds().height / 3;
	
	this.contenedor.addChild( this.baseNum );
    
    this.caja = new CajaTexto();
	this.caja.contenedor.x = this.formula.getBounds().x + this.formula.getBounds().width + this.baseNum.getBounds().width +  30;
	this.caja.contenedor.y = this.formula.getBounds().y + 5;

	this.contenedor.addChild( this.caja.contenedor );
	
	this.correctNum = new createjs.RichText();
	this.correctNum.text = operacio.respuestaNum.toString();
    this.correctNum.font = (Contenedor.datosXML.plataforma.grado == 1)? "20px Arial" : "18px Arial" ;
	this.correctNum.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 20 : 18 ;
	this.correctNum.color = "#E1001A";
	this.correctNum.x = this.caja.contenedor.x  +  65 +  50;
	this.correctNum.y = this.formula.getBounds().y + 12;
	this.correctNum.alpha = 0;
	
	this.contenedor.addChild( this.correctNum );
}

function PuntoP( color )
{
	color =  color || "#000";
	this.contenedor = new createjs.Container();
	this.punto = new createjs.Shape();
	
	this.punto.graphics.beginFill(color).drawCircle(0,0,5);
	
	this.contenedor.addChild( this.punto );
}
function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 65, 40, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 10);
}
