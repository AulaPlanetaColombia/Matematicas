(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,0,0,0);
        titulo1(this, txt['titol']);
      
      this.instance_1 = new lib.shutterstock_35778439();
	this.instance_1.setTransform(354.5,151.8,0.5,0.5);

	this.txt_boto_04 = new cjs.Text(txt['txt_boto_04'], "bold 16px Arial");
	this.txt_boto_04.textAlign = "center";
	this.txt_boto_04.lineHeight = 18;
	this.txt_boto_04.lineWidth = 233;
	this.txt_boto_04.setTransform(199.3,456.6);

	this.txt_boto_03 = new cjs.Text(txt['txt_boto_03'], "bold 16px Arial");
	this.txt_boto_03.textAlign = "center";
	this.txt_boto_03.lineHeight = 18;
	this.txt_boto_03.lineWidth = 233;
	this.txt_boto_03.setTransform(199.5,371.9);

	this.txt_boto_02 = new cjs.Text(txt['txt_boto_02'], "bold 16px Arial");
	this.txt_boto_02.textAlign = "center";
	this.txt_boto_02.lineHeight = 18;
	this.txt_boto_02.lineWidth = 233;
	this.txt_boto_02.setTransform(199.7,287.1);

	this.txt_boto_01 = new cjs.Text(txt['txt_boto_01'], "bold 16px Arial");
	this.txt_boto_01.textAlign = "center";
	this.txt_boto_01.lineHeight = 18;
	this.txt_boto_01.lineWidth = 233;
	this.txt_boto_01.setTransform(199.9,202.4);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(155.3,221.5,1,1,0,0,0,87.5,23.5);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);
        
	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(155.3,306.2,1,1,0,0,0,87.5,23.5);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_03 = new lib.mc_01();
	this.mc_boto_03.setTransform(155.3,475.6,1,1,0,0,0,87.5,23.5);
new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_04 = new lib.mc_01();
	this.mc_boto_04.setTransform(155.3,390.9,1,1,0,0,0,87.5,23.5);
new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_01(), 3);
        
        this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });

        this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.mc_boto_04.on("click", function (evt) {
            
            putStage(new lib.frame3_1());
        });


        this.addChild(this.logo, this.titulo, this.anterior,this.mc_boto_03,this.mc_boto_04,this.mc_boto_02,this.mc_boto_01,this.txt_boto_01,this.txt_boto_02,this.txt_boto_03,this.txt_boto_04,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['e1_titol']);
      
     	this.instance = new lib.SinPegatinas();
	this.instance.setTransform(217,119,0.5,0.5);

	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.siguiente,this.titulo,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['p1_01']);
      
     	this.instance = new lib.mc_p1();
	this.instance.setTransform(83.5,292.6);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt['p2_01']);
      
     	this.instance = new lib.mc_p2();
	this.instance.setTransform(83.5,292.6);

  var html = createDiv(txt['mc_p2_01'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto1 = new lib.fadeText(html, 740);
        this.texto1.setTransform(100, -220);

        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
       
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['e2_titol']);
      
     	this.instance = new lib.PegatinaVerde();
	this.instance.setTransform(217,119,0.5,0.5);

	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.siguiente,this.titulo,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['f1_01']);
      
     	this.instance = new lib.mc_f1();
	this.instance.setTransform(83.5,192.6);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['f2_01']);
      
     	this.instance = new lib.mc_f2();
	this.instance.setTransform(283.5,160);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame2_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt['f2_01']);
      
     	this.instance = new lib.mc_f2_2();
	this.instance.setTransform(283.5,160);
        var html = createDiv(txt['mc_f2_03'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.tit2=new lib.fadeText(html,223);
        this.tit2.setTransform(90, -588);

        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
       
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.titulo,this.instance,this.texto1,this.tit2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['e3_titol']);
      
     	this.instance = new lib.PegatinaAmarilla();
	this.instance.setTransform(217,119,0.5,0.5);

	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.siguiente,this.titulo,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['h1_01']);
      
     	this.instance = new lib.mc_h1();
	this.instance.setTransform(83.5,192.6);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame3_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['h2_01']);
      
     	this.instance = new lib.mc_f2();
	this.instance.setTransform(283.5,160);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame3_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt['h2_01']);
      
     	this.instance = new lib.mc_h2_2();
	this.instance.setTransform(283.5,160);
        var html = createDiv(txt['mc_h2_03'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.tit2=new lib.fadeText(html,223);
        this.tit2.setTransform(90, -588);

        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
       
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.titulo,this.instance,this.texto1,this.tit2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame4_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo2(this, txt['e4_titol']);
      
     	this.instance = new lib.PegatinaRosa();
	this.instance.setTransform(217,119,0.5,0.5);

	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.siguiente,this.titulo,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['g1_01']);
      
     	this.instance = new lib.mc_g1();
	this.instance.setTransform(83.5,192.6);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame4_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['g2_01']);
      
     	this.instance = new lib.mc_f2();
	this.instance.setTransform(283.5,160);
        
  
        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
       	  this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_4());
        }); 
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.siguiente,this.titulo,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame4_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
        titulo2(this, txt['g2_01']);
      
     	this.instance = new lib.mc_g2_2();
	this.instance.setTransform(283.5,160);
        var html = createDiv(txt['mc_g2_03'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.tit2=new lib.fadeText(html,223);
        this.tit2.setTransform(90, -588);

        
	  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
       
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.home,this.anterior,this.titulo,this.instance,this.texto1,this.tit2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


  
  
(lib.mc_g2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	
	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_101 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_102 = new cjs.Graphics().p("AmNApIAAhRIMbAAIAABRg");
	var mask_graphics_103 = new cjs.Graphics().p("AmNA5IAAhxIMbAAIAABxg");
	var mask_graphics_104 = new cjs.Graphics().p("AmNBKIAAiTIMbAAIAACTg");
	var mask_graphics_105 = new cjs.Graphics().p("AmNBaIAAizIMbAAIAACzg");
	var mask_graphics_106 = new cjs.Graphics().p("AmNBrIAAjVIMbAAIAADVg");
	var mask_graphics_107 = new cjs.Graphics().p("AmNB7IAAj1IMbAAIAAD1g");
	var mask_graphics_108 = new cjs.Graphics().p("AmNCMIAAkXIMbAAIAAEXg");
	var mask_graphics_109 = new cjs.Graphics().p("AmNCdIAAk5IMbAAIAAE5g");
	var mask_graphics_110 = new cjs.Graphics().p("AmNCtIAAlZIMbAAIAAFZg");
	var mask_graphics_111 = new cjs.Graphics().p("AmNC+IAAl7IMbAAIAAF7g");
	var mask_graphics_112 = new cjs.Graphics().p("AmNDOIAAmbIMbAAIAAGbg");
	var mask_graphics_113 = new cjs.Graphics().p("AmNDfIAAm9IMbAAIAAG9g");
	var mask_graphics_114 = new cjs.Graphics().p("AmNDwIAAnfIMbAAIAAHfg");
	var mask_graphics_115 = new cjs.Graphics().p("AmNEAIAAn/IMbAAIAAH/g");
	var mask_graphics_116 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_183 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_184 = new cjs.Graphics().p("AmNEfIAAo9IMbAAIAAI9g");
	var mask_graphics_185 = new cjs.Graphics().p("AmNEtIAApZIMbAAIAAJZg");
	var mask_graphics_186 = new cjs.Graphics().p("AmNE7IAAp1IMbAAIAAJ1g");
	var mask_graphics_187 = new cjs.Graphics().p("AmNFJIAAqRIMbAAIAAKRg");
	var mask_graphics_188 = new cjs.Graphics().p("AmNFXIAAqtIMbAAIAAKtg");
	var mask_graphics_189 = new cjs.Graphics().p("AmNFkIAArHIMbAAIAALHg");
	var mask_graphics_190 = new cjs.Graphics().p("AmNFyIAArjIMbAAIAALjg");
	var mask_graphics_191 = new cjs.Graphics().p("AmNGAIAAr/IMbAAIAAL/g");
	var mask_graphics_192 = new cjs.Graphics().p("AmNGOIAAsbIMbAAIAAMbg");
	var mask_graphics_193 = new cjs.Graphics().p("AmNGcIAAs3IMbAAIAAM3g");
	var mask_graphics_194 = new cjs.Graphics().p("AOYY6IAAtVIMeAAIAANVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:303.8,y:235.9}).wait(101).to({graphics:mask_graphics_101,x:303.8,y:235.9}).wait(1).to({graphics:mask_graphics_102,x:303.8,y:237.6}).wait(1).to({graphics:mask_graphics_103,x:303.8,y:239.2}).wait(1).to({graphics:mask_graphics_104,x:303.8,y:240.9}).wait(1).to({graphics:mask_graphics_105,x:303.8,y:242.5}).wait(1).to({graphics:mask_graphics_106,x:303.8,y:244.2}).wait(1).to({graphics:mask_graphics_107,x:303.8,y:245.9}).wait(1).to({graphics:mask_graphics_108,x:303.8,y:247.5}).wait(1).to({graphics:mask_graphics_109,x:303.8,y:249.2}).wait(1).to({graphics:mask_graphics_110,x:303.8,y:250.8}).wait(1).to({graphics:mask_graphics_111,x:303.8,y:252.5}).wait(1).to({graphics:mask_graphics_112,x:303.8,y:254.1}).wait(1).to({graphics:mask_graphics_113,x:303.8,y:255.8}).wait(1).to({graphics:mask_graphics_114,x:303.8,y:257.5}).wait(1).to({graphics:mask_graphics_115,x:303.8,y:259.1}).wait(1).to({graphics:mask_graphics_116,x:171.8,y:144}).wait(67).to({graphics:mask_graphics_183,x:171.8,y:144}).wait(1).to({graphics:mask_graphics_184,x:303.8,y:262.2}).wait(1).to({graphics:mask_graphics_185,x:303.8,y:263.6}).wait(1).to({graphics:mask_graphics_186,x:303.8,y:265}).wait(1).to({graphics:mask_graphics_187,x:303.8,y:266.4}).wait(1).to({graphics:mask_graphics_188,x:303.8,y:267.8}).wait(1).to({graphics:mask_graphics_189,x:303.8,y:269.2}).wait(1).to({graphics:mask_graphics_190,x:303.8,y:270.6}).wait(1).to({graphics:mask_graphics_191,x:303.8,y:272}).wait(1).to({graphics:mask_graphics_192,x:303.8,y:273.5}).wait(1).to({graphics:mask_graphics_193,x:303.8,y:274.9}).wait(1).to({graphics:mask_graphics_194,x:171.8,y:159.5}).wait(89));

	// Formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(313.1,283.5,0.207,1);

	this.text = new cjs.Text("4", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(304.2,283.1+incremento);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(304.3,252.6+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(265.7,267.7+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(283));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AhGZAIAAr0IBOAAIAAL0g");
	var mask_1_graphics_1 = new cjs.Graphics().p("AhOF5IAAryICdAAIAALyg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Ah2F5IAAryIDtAAIAALyg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AieF5IAAryIE9AAIAALyg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AjGF5IAAryIGNAAIAALyg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AjuF5IAAryIHdAAIAALyg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AkWF5IAAryIItAAIAALyg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Ak+F5IAAryIJ9AAIAALyg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AlmF5IAAryILNAAIAALyg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AmOF5IAAryIMdAAIAALyg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Am2F5IAAryINtAAIAALyg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AneF5IAAryIO9AAIAALyg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AoFF5IAAryIQLAAIAALyg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AotF5IAAryIRbAAIAALyg");
	var mask_1_graphics_14 = new cjs.Graphics().p("ApVF5IAAryISrAAIAALyg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Ap9F5IAAryIT7AAIAALyg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AqlF5IAAryIVLAAIAALyg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArNF5IAAryIWbAAIAALyg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Ar1F5IAAryIXrAAIAALyg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AsdF5IAAryIY7AAIAALyg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AtFF5IAAryIaLAAIAALyg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AttF5IAAryIbbAAIAALyg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AuVF5IAAryIcrAAIAALyg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Au9F5IAAryId7AAIAALyg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AvlF5IAAryIfLAAIAALyg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AwNF5IAAryMAgbAAAIAALyg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aw1F5IAAryMAhrAAAIAALyg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AxcF5IAAryMAi5AAAIAALyg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AyEF5IAAryMAkJAAAIAALyg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AysF5IAAryMAlZAAAIAALyg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AzUF5IAAryMAmpAAAIAALyg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Az8F5IAAryMAn5AAAIAALyg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A0kF5IAAryMApJAAAIAALyg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A1MF5IAAryMAqZAAAIAALyg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A10ZAIAAr0MArpAAAIAAL0g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-7,y:160.1}).wait(1).to({graphics:mask_1_graphics_1,x:-6.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_2,x:-2.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_3,x:1.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_4,x:5.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_5,x:9.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_6,x:13.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_7,x:17.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_8,x:21.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_9,x:25.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_10,x:29.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_11,x:33.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_12,x:37.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_13,x:41.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_14,x:45.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_15,x:49.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_16,x:53.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_17,x:57.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_18,x:61.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_19,x:65.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_20,x:69.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_21,x:73.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_22,x:77.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_23,x:81.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_24,x:85.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_25,x:89.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_26,x:93.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_27,x:97,y:282.4}).wait(1).to({graphics:mask_1_graphics_28,x:101,y:282.4}).wait(1).to({graphics:mask_1_graphics_29,x:105,y:282.4}).wait(1).to({graphics:mask_1_graphics_30,x:109,y:282.4}).wait(1).to({graphics:mask_1_graphics_31,x:112.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_32,x:116.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_33,x:120.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_34,x:124.8,y:160.1}).wait(249));

	// Formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(168.7,283.5);

	this.mc_g2_02 = new cjs.Text(txt['mc_g2_02'], "20px Verdana");
	this.mc_g2_02.textAlign = "center";
	this.mc_g2_02.lineHeight = 20;
	this.mc_g2_02.lineWidth = 175;
	this.mc_g2_02.setTransform(166.9,282.3+incremento);

	this.mc_g2_01 = new cjs.Text(txt['mc_g2_01'], "20px Verdana");
	this.mc_g2_01.textAlign = "center";
	this.mc_g2_01.lineHeight = 20;
	this.mc_g2_01.lineWidth = 175;
	this.mc_g2_01.setTransform(166.6,252.6+incremento);

	this.text_3 = new cjs.Text("tg α =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 84;
	this.text_3.setTransform(2.3,267.7+incremento);

	this.shape_1.mask = this.mc_g2_02.mask = this.mc_g2_01.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3,p:{x:2.3}},{t:this.mc_g2_01,p:{lineWidth:175,x:166.6}},{t:this.mc_g2_02,p:{x:166.9,lineWidth:175}},{t:this.shape_1}]}).to({state:[{t:this.mc_g2_01,p:{lineWidth:174,x:166.6}},{t:this.mc_g2_02,p:{x:166.6,lineWidth:174}},{t:this.shape_1},{t:this.text_3,p:{x:0.3}}]},68).to({state:[{t:this.mc_g2_01,p:{lineWidth:175,x:166.8}},{t:this.mc_g2_02,p:{x:166.8,lineWidth:175}},{t:this.shape_1},{t:this.text_3,p:{x:3.3}}]},80).to({state:[{t:this.mc_g2_01,p:{lineWidth:174,x:166.5}},{t:this.mc_g2_02,p:{x:166.5,lineWidth:174}},{t:this.shape_1},{t:this.text_3,p:{x:3.3}}]},75).wait(60));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuWIAAct");
	this.shape_2.setTransform(307.5,91.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AXvAAMgvdAAA");
	this.shape_3.setTransform(155.1,182.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},68).to({state:[{t:this.shape_3}]},80).to({state:[]},75).wait(60));

	// mc_f2_01
	this.instance_1 = new lib.mc_h2_01();
	this.instance_1.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:162,x:165.1},0).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.3,0,326,314.1);


(lib.mc_g2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mc_f2_01
	this.instance = new lib.mc_g2_01();
	this.instance.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:162,x:165.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,0,325.1,214.9);


(lib.mc_g1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_280 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_379 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_380 = new cjs.Graphics().p("Al/BAIAAh/IL/AAIAAB/g");
	var mask_graphics_381 = new cjs.Graphics().p("Al/BKIAAiTIL/AAIAACTg");
	var mask_graphics_382 = new cjs.Graphics().p("Al/BVIAAipIL/AAIAACpg");
	var mask_graphics_383 = new cjs.Graphics().p("Al/BgIAAi/IL/AAIAAC/g");
	var mask_graphics_384 = new cjs.Graphics().p("Al/BrIAAjVIL/AAIAADVg");
	var mask_graphics_385 = new cjs.Graphics().p("Al/B2IAAjrIL/AAIAADrg");
	var mask_graphics_386 = new cjs.Graphics().p("Al/CBIAAkBIL/AAIAAEBg");
	var mask_graphics_387 = new cjs.Graphics().p("Al/CLIAAkVIL/AAIAAEVg");
	var mask_graphics_388 = new cjs.Graphics().p("Al/CWIAAkrIL/AAIAAErg");
	var mask_graphics_389 = new cjs.Graphics().p("Al/ChIAAlBIL/AAIAAFBg");
	var mask_graphics_390 = new cjs.Graphics().p("Al/CsIAAlXIL/AAIAAFXg");
	var mask_graphics_391 = new cjs.Graphics().p("Al/C3IAAltIL/AAIAAFtg");
	var mask_graphics_392 = new cjs.Graphics().p("Al/DBIAAmBIL/AAIAAGBg");
	var mask_graphics_393 = new cjs.Graphics().p("Al/DMIAAmXIL/AAIAAGXg");
	var mask_graphics_394 = new cjs.Graphics().p("Al/DXIAAmtIL/AAIAAGtg");
	var mask_graphics_395 = new cjs.Graphics().p("Al/DiIAAnDIL/AAIAAHDg");
	var mask_graphics_396 = new cjs.Graphics().p("EAtBAVIIAAnbIMBAAIAAHbg");
	var mask_graphics_467 = new cjs.Graphics().p("EAtBAVIIAAnbIMBAAIAAHbg");
	var mask_graphics_468 = new cjs.Graphics().p("Al/D7IAAn1IL/AAIAAH1g");
	var mask_graphics_469 = new cjs.Graphics().p("Al/EKIAAoTIL/AAIAAITg");
	var mask_graphics_470 = new cjs.Graphics().p("Al/EYIAAovIL/AAIAAIvg");
	var mask_graphics_471 = new cjs.Graphics().p("Al/EmIAApLIL/AAIAAJLg");
	var mask_graphics_472 = new cjs.Graphics().p("Al/E1IAAppIL/AAIAAJpg");
	var mask_graphics_473 = new cjs.Graphics().p("Al/FDIAAqFIL/AAIAAKFg");
	var mask_graphics_474 = new cjs.Graphics().p("Al/FRIAAqhIL/AAIAAKhg");
	var mask_graphics_475 = new cjs.Graphics().p("Al/FgIAAq/IL/AAIAAK/g");
	var mask_graphics_476 = new cjs.Graphics().p("Al/FuIAArbIL/AAIAALbg");
	var mask_graphics_477 = new cjs.Graphics().p("Al/F9IAAr5IL/AAIAAL5g");
	var mask_graphics_478 = new cjs.Graphics().p("EAtBAXmIAAsXIMBAAIAAMXg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_graphics_280,x:691.6,y:228.2}).wait(99).to({graphics:mask_graphics_379,x:691.6,y:228.2}).wait(1).to({graphics:mask_graphics_380,x:691.6,y:229.3}).wait(1).to({graphics:mask_graphics_381,x:691.6,y:230.4}).wait(1).to({graphics:mask_graphics_382,x:691.6,y:231.5}).wait(1).to({graphics:mask_graphics_383,x:691.6,y:232.6}).wait(1).to({graphics:mask_graphics_384,x:691.6,y:233.7}).wait(1).to({graphics:mask_graphics_385,x:691.6,y:234.7}).wait(1).to({graphics:mask_graphics_386,x:691.6,y:235.8}).wait(1).to({graphics:mask_graphics_387,x:691.6,y:236.9}).wait(1).to({graphics:mask_graphics_388,x:691.6,y:238}).wait(1).to({graphics:mask_graphics_389,x:691.6,y:239.1}).wait(1).to({graphics:mask_graphics_390,x:691.6,y:240.2}).wait(1).to({graphics:mask_graphics_391,x:691.6,y:241.2}).wait(1).to({graphics:mask_graphics_392,x:691.6,y:242.3}).wait(1).to({graphics:mask_graphics_393,x:691.6,y:243.4}).wait(1).to({graphics:mask_graphics_394,x:691.6,y:244.5}).wait(1).to({graphics:mask_graphics_395,x:691.6,y:245.6}).wait(1).to({graphics:mask_graphics_396,x:365,y:135.2}).wait(71).to({graphics:mask_graphics_467,x:365,y:135.2}).wait(1).to({graphics:mask_graphics_468,x:691.6,y:248.1}).wait(1).to({graphics:mask_graphics_469,x:691.6,y:249.6}).wait(1).to({graphics:mask_graphics_470,x:691.6,y:251}).wait(1).to({graphics:mask_graphics_471,x:691.6,y:252.4}).wait(1).to({graphics:mask_graphics_472,x:691.6,y:253.9}).wait(1).to({graphics:mask_graphics_473,x:691.6,y:255.3}).wait(1).to({graphics:mask_graphics_474,x:691.6,y:256.7}).wait(1).to({graphics:mask_graphics_475,x:691.6,y:258.2}).wait(1).to({graphics:mask_graphics_476,x:691.6,y:259.6}).wait(1).to({graphics:mask_graphics_477,x:691.6,y:261.1}).wait(1).to({graphics:mask_graphics_478,x:365,y:151}).wait(65));

	// formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(701.9,267.5,0.207,1);

	this.text = new cjs.Text("b", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(693,266.4+incremento);

	this.text_1 = new cjs.Text("c", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 14;
	this.text_1.setTransform(693.1,236.7+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(654.5,251.8+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]},280).wait(263));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_280 = new cjs.Graphics().p("AhNFbIAAq1ICbAAIAAK1g");
	var mask_1_graphics_281 = new cjs.Graphics().p("AhzFbIAAq1IDnAAIAAK1g");
	var mask_1_graphics_282 = new cjs.Graphics().p("AiYFbIAAq1IExAAIAAK1g");
	var mask_1_graphics_283 = new cjs.Graphics().p("Ai+FbIAAq1IF9AAIAAK1g");
	var mask_1_graphics_284 = new cjs.Graphics().p("AjkFbIAAq1IHJAAIAAK1g");
	var mask_1_graphics_285 = new cjs.Graphics().p("AkKFbIAAq1IIVAAIAAK1g");
	var mask_1_graphics_286 = new cjs.Graphics().p("AkvFbIAAq1IJfAAIAAK1g");
	var mask_1_graphics_287 = new cjs.Graphics().p("AlVFbIAAq1IKrAAIAAK1g");
	var mask_1_graphics_288 = new cjs.Graphics().p("Al7FbIAAq1IL3AAIAAK1g");
	var mask_1_graphics_289 = new cjs.Graphics().p("AmhFbIAAq1INDAAIAAK1g");
	var mask_1_graphics_290 = new cjs.Graphics().p("AnGFbIAAq1IONAAIAAK1g");
	var mask_1_graphics_291 = new cjs.Graphics().p("AnsFbIAAq1IPZAAIAAK1g");
	var mask_1_graphics_292 = new cjs.Graphics().p("AoSFbIAAq1IQlAAIAAK1g");
	var mask_1_graphics_293 = new cjs.Graphics().p("Ao4FbIAAq1IRxAAIAAK1g");
	var mask_1_graphics_294 = new cjs.Graphics().p("ApdFbIAAq1IS7AAIAAK1g");
	var mask_1_graphics_295 = new cjs.Graphics().p("AqDFbIAAq1IUHAAIAAK1g");
	var mask_1_graphics_296 = new cjs.Graphics().p("AqpFbIAAq1IVTAAIAAK1g");
	var mask_1_graphics_297 = new cjs.Graphics().p("ArPFbIAAq1IWfAAIAAK1g");
	var mask_1_graphics_298 = new cjs.Graphics().p("Ar0FbIAAq1IXpAAIAAK1g");
	var mask_1_graphics_299 = new cjs.Graphics().p("AsaFbIAAq1IY1AAIAAK1g");
	var mask_1_graphics_300 = new cjs.Graphics().p("AtAFbIAAq1IaBAAIAAK1g");
	var mask_1_graphics_301 = new cjs.Graphics().p("AtmFbIAAq1IbNAAIAAK1g");
	var mask_1_graphics_302 = new cjs.Graphics().p("AuLFbIAAq1IcXAAIAAK1g");
	var mask_1_graphics_303 = new cjs.Graphics().p("AuxFbIAAq1IdjAAIAAK1g");
	var mask_1_graphics_304 = new cjs.Graphics().p("AvXFbIAAq1IevAAIAAK1g");
	var mask_1_graphics_305 = new cjs.Graphics().p("Av9FbIAAq1If7AAIAAK1g");
	var mask_1_graphics_306 = new cjs.Graphics().p("AwiFbIAAq1MAhFAAAIAAK1g");
	var mask_1_graphics_307 = new cjs.Graphics().p("AxIFbIAAq1MAiRAAAIAAK1g");
	var mask_1_graphics_308 = new cjs.Graphics().p("AxuFbIAAq1MAjdAAAIAAK1g");
	var mask_1_graphics_309 = new cjs.Graphics().p("AyUFbIAAq1MAkpAAAIAAK1g");
	var mask_1_graphics_310 = new cjs.Graphics().p("Ay5FbIAAq1MAlzAAAIAAK1g");
	var mask_1_graphics_311 = new cjs.Graphics().p("AzfFbIAAq1MAm/AAAIAAK1g");
	var mask_1_graphics_312 = new cjs.Graphics().p("A0FFbIAAq1MAoLAAAIAAK1g");
	var mask_1_graphics_313 = new cjs.Graphics().p("A0rFbIAAq1MApXAAAIAAK1g");
	var mask_1_graphics_314 = new cjs.Graphics().p("A1QFbIAAq1MAqhAAAIAAK1g");
	var mask_1_graphics_315 = new cjs.Graphics().p("AHNXgIAAq3MArvAAAIAAK3g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_1_graphics_280,x:380.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_281,x:383.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_282,x:387.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_283,x:391.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_284,x:395.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_285,x:398.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_286,x:402.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_287,x:406.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_288,x:410.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_289,x:414,y:266.1}).wait(1).to({graphics:mask_1_graphics_290,x:417.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_291,x:421.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_292,x:425.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_293,x:429.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_294,x:432.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_295,x:436.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_296,x:440.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_297,x:444.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_298,x:448,y:266.1}).wait(1).to({graphics:mask_1_graphics_299,x:451.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_300,x:455.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_301,x:459.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_302,x:463.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_303,x:466.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_304,x:470.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_305,x:474.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_306,x:478.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_307,x:482,y:266.1}).wait(1).to({graphics:mask_1_graphics_308,x:485.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_309,x:489.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_310,x:493.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_311,x:497.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_312,x:500.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_313,x:504.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_314,x:508.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_315,x:326,y:150.5}).wait(228));

	// formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(557.5,267.5);

	this.mc_g1_04 = new cjs.Text(txt['mc_g1_04'], "20px Verdana");
	this.mc_g1_04.textAlign = "center";
	this.mc_g1_04.lineHeight = 20;
	this.mc_g1_04.lineWidth = 175;
	this.mc_g1_04.setTransform(555.2,266.4+incremento);

	this.mc_g1_03 = new cjs.Text(txt['mc_g1_03'], "20px Verdana");
	this.mc_g1_03.textAlign = "center";
	this.mc_g1_03.lineHeight = 20;
	this.mc_g1_03.lineWidth = 175;
	this.mc_g1_03.setTransform(555.3,236.7+incremento);

	this.text_3 = new cjs.Text("tg  ß =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 74;
	this.text_3.setTransform(391.3,251.8+incremento);

	this.shape_1.mask = this.mc_g1_04.mask = this.mc_g1_03.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3,p:{x:391.3,text:"tg  ß ="}},{t:this.mc_g1_03,p:{x:555.3}},{t:this.mc_g1_04,p:{x:555.2}},{t:this.shape_1}]},280).to({state:[{t:this.mc_g1_03,p:{x:555.1}},{t:this.mc_g1_04,p:{x:555}},{t:this.shape_1},{t:this.text_3,p:{x:393.3,text:"tg ß ="}}]},74).to({state:[{t:this.mc_g1_03,p:{x:555.1}},{t:this.mc_g1_04,p:{x:555}},{t:this.shape_1},{t:this.text_3,p:{x:392.3,text:"tg ß ="}}]},70).to({state:[{t:this.mc_g1_03,p:{x:555.1}},{t:this.mc_g1_04,p:{x:555}},{t:this.shape_1},{t:this.text_3,p:{x:392.3,text:"tg ß ="}}]},76).wait(43));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AX0AAMgvnAAA");
	this.shape_2.setTransform(556.4,181.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuRIAAcj");
	this.shape_3.setTransform(708.4,89.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},354).to({state:[{t:this.shape_3}]},70).to({state:[]},76).wait(43));

	// triangulo_2
	this.instance = new lib.mc_g1_02();
	this.instance.setTransform(565.9,105.5,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(263).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(263));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_18 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AmBAuIAAhbIMDAAIAABbg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AmBA5IAAhxIMDAAIAABxg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AmBBFIAAiJIMDAAIAACJg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AmBBQIAAifIMDAAIAACfg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AmBBbIAAi1IMDAAIAAC1g");
	var mask_2_graphics_119 = new cjs.Graphics().p("AmBBnIAAjNIMDAAIAADNg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AmBByIAAjjIMDAAIAADjg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AmBB9IAAj5IMDAAIAAD5g");
	var mask_2_graphics_122 = new cjs.Graphics().p("AmBCJIAAkRIMDAAIAAERg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AmBCUIAAknIMDAAIAAEng");
	var mask_2_graphics_124 = new cjs.Graphics().p("AmBCfIAAk9IMDAAIAAE9g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AmBCrIAAlVIMDAAIAAFVg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AmBC2IAAlrIMDAAIAAFrg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AmBDBIAAmBIMDAAIAAGBg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AmBDNIAAmZIMDAAIAAGZg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AmBDYIAAmvIMDAAIAAGvg");
	var mask_2_graphics_130 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_197 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_198 = new cjs.Graphics().p("AmBDsIAAnXIMDAAIAAHXg");
	var mask_2_graphics_199 = new cjs.Graphics().p("AmBD0IAAnnIMDAAIAAHng");
	var mask_2_graphics_200 = new cjs.Graphics().p("AmBD9IAAn5IMDAAIAAH5g");
	var mask_2_graphics_201 = new cjs.Graphics().p("AmBEFIAAoJIMDAAIAAIJg");
	var mask_2_graphics_202 = new cjs.Graphics().p("AmBEOIAAobIMDAAIAAIbg");
	var mask_2_graphics_203 = new cjs.Graphics().p("AmBEWIAAorIMDAAIAAIrg");
	var mask_2_graphics_204 = new cjs.Graphics().p("AmBEfIAAo9IMDAAIAAI9g");
	var mask_2_graphics_205 = new cjs.Graphics().p("AmBEnIAApNIMDAAIAAJNg");
	var mask_2_graphics_206 = new cjs.Graphics().p("AmBEwIAApfIMDAAIAAJfg");
	var mask_2_graphics_207 = new cjs.Graphics().p("AmBE4IAApvIMDAAIAAJvg");
	var mask_2_graphics_208 = new cjs.Graphics().p("AmBFBIAAqBIMDAAIAAKBg");
	var mask_2_graphics_209 = new cjs.Graphics().p("AmBFJIAAqRIMDAAIAAKRg");
	var mask_2_graphics_210 = new cjs.Graphics().p("AmBFSIAAqjIMDAAIAAKjg");
	var mask_2_graphics_211 = new cjs.Graphics().p("AmBFaIAAqzIMDAAIAAKzg");
	var mask_2_graphics_212 = new cjs.Graphics().p("AmBFjIAArFIMDAAIAALFg");
	var mask_2_graphics_213 = new cjs.Graphics().p("AmBFrIAArVIMDAAIAALVg");
	var mask_2_graphics_214 = new cjs.Graphics().p("AmBF0IAArnIMDAAIAALng");
	var mask_2_graphics_215 = new cjs.Graphics().p("AOOXrIAAr6IMGAAIAAL6g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_2_graphics_18,x:298.2,y:230.4}).wait(95).to({graphics:mask_2_graphics_113,x:298.2,y:230.4}).wait(1).to({graphics:mask_2_graphics_114,x:298.2,y:231.5}).wait(1).to({graphics:mask_2_graphics_115,x:298.2,y:232.6}).wait(1).to({graphics:mask_2_graphics_116,x:298.2,y:233.8}).wait(1).to({graphics:mask_2_graphics_117,x:298.2,y:234.9}).wait(1).to({graphics:mask_2_graphics_118,x:298.2,y:236}).wait(1).to({graphics:mask_2_graphics_119,x:298.2,y:237.2}).wait(1).to({graphics:mask_2_graphics_120,x:298.2,y:238.3}).wait(1).to({graphics:mask_2_graphics_121,x:298.2,y:239.4}).wait(1).to({graphics:mask_2_graphics_122,x:298.2,y:240.6}).wait(1).to({graphics:mask_2_graphics_123,x:298.2,y:241.7}).wait(1).to({graphics:mask_2_graphics_124,x:298.2,y:242.8}).wait(1).to({graphics:mask_2_graphics_125,x:298.2,y:244}).wait(1).to({graphics:mask_2_graphics_126,x:298.2,y:245.1}).wait(1).to({graphics:mask_2_graphics_127,x:298.2,y:246.2}).wait(1).to({graphics:mask_2_graphics_128,x:298.2,y:247.4}).wait(1).to({graphics:mask_2_graphics_129,x:298.2,y:248.5}).wait(1).to({graphics:mask_2_graphics_130,x:168.4,y:136.2}).wait(67).to({graphics:mask_2_graphics_197,x:168.4,y:136.2}).wait(1).to({graphics:mask_2_graphics_198,x:298.2,y:250.5}).wait(1).to({graphics:mask_2_graphics_199,x:298.2,y:251.3}).wait(1).to({graphics:mask_2_graphics_200,x:298.2,y:252.2}).wait(1).to({graphics:mask_2_graphics_201,x:298.2,y:253}).wait(1).to({graphics:mask_2_graphics_202,x:298.2,y:253.9}).wait(1).to({graphics:mask_2_graphics_203,x:298.2,y:254.7}).wait(1).to({graphics:mask_2_graphics_204,x:298.2,y:255.6}).wait(1).to({graphics:mask_2_graphics_205,x:298.2,y:256.4}).wait(1).to({graphics:mask_2_graphics_206,x:298.2,y:257.3}).wait(1).to({graphics:mask_2_graphics_207,x:298.2,y:258.2}).wait(1).to({graphics:mask_2_graphics_208,x:298.2,y:259}).wait(1).to({graphics:mask_2_graphics_209,x:298.2,y:259.9}).wait(1).to({graphics:mask_2_graphics_210,x:298.2,y:260.7}).wait(1).to({graphics:mask_2_graphics_211,x:298.2,y:261.6}).wait(1).to({graphics:mask_2_graphics_212,x:298.2,y:262.4}).wait(1).to({graphics:mask_2_graphics_213,x:298.2,y:263.3}).wait(1).to({graphics:mask_2_graphics_214,x:298.2,y:264.1}).wait(1).to({graphics:mask_2_graphics_215,x:168.4,y:151.5}).wait(328));

	// formula_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("Ai1AAIFrAA");
	this.shape_4.setTransform(306,267.2);

	this.text_4 = new cjs.Text("c", "italic 20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 14;
	this.text_4.setTransform(297.1,266.1+incremento);

	this.text_5 = new cjs.Text("b", "italic 20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 14;
	this.text_5.setTransform(297.2,236.4+incremento);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 16;
	this.text_6.setTransform(258.6,251.5+incremento);

	this.shape_4.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_4}]},18).wait(525));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_18 = new cjs.Graphics().p("AgrGUIAAsnIBYAAIAAMng");
	var mask_3_graphics_19 = new cjs.Graphics().p("AhMGUIAAsnICZAAIAAMng");
	var mask_3_graphics_20 = new cjs.Graphics().p("AhtGUIAAsnIDbAAIAAMng");
	var mask_3_graphics_21 = new cjs.Graphics().p("AiOGUIAAsnIEdAAIAAMng");
	var mask_3_graphics_22 = new cjs.Graphics().p("AivGUIAAsnIFfAAIAAMng");
	var mask_3_graphics_23 = new cjs.Graphics().p("AjQGUIAAsnIGhAAIAAMng");
	var mask_3_graphics_24 = new cjs.Graphics().p("AjxGUIAAsnIHjAAIAAMng");
	var mask_3_graphics_25 = new cjs.Graphics().p("AkSGUIAAsnIIlAAIAAMng");
	var mask_3_graphics_26 = new cjs.Graphics().p("AkzGUIAAsnIJnAAIAAMng");
	var mask_3_graphics_27 = new cjs.Graphics().p("AlTGUIAAsnIKnAAIAAMng");
	var mask_3_graphics_28 = new cjs.Graphics().p("Al0GUIAAsnILpAAIAAMng");
	var mask_3_graphics_29 = new cjs.Graphics().p("AmVGUIAAsnIMrAAIAAMng");
	var mask_3_graphics_30 = new cjs.Graphics().p("Am2GUIAAsnINtAAIAAMng");
	var mask_3_graphics_31 = new cjs.Graphics().p("AnXGUIAAsnIOvAAIAAMng");
	var mask_3_graphics_32 = new cjs.Graphics().p("An4GUIAAsnIPxAAIAAMng");
	var mask_3_graphics_33 = new cjs.Graphics().p("AoZGUIAAsnIQzAAIAAMng");
	var mask_3_graphics_34 = new cjs.Graphics().p("Ao6GUIAAsnIR1AAIAAMng");
	var mask_3_graphics_35 = new cjs.Graphics().p("ApbGUIAAsnIS3AAIAAMng");
	var mask_3_graphics_36 = new cjs.Graphics().p("Ap7GUIAAsnIT3AAIAAMng");
	var mask_3_graphics_37 = new cjs.Graphics().p("AqcGUIAAsnIU5AAIAAMng");
	var mask_3_graphics_38 = new cjs.Graphics().p("Aq9GUIAAsnIV7AAIAAMng");
	var mask_3_graphics_39 = new cjs.Graphics().p("AreGUIAAsnIW9AAIAAMng");
	var mask_3_graphics_40 = new cjs.Graphics().p("Ar/GUIAAsnIX/AAIAAMng");
	var mask_3_graphics_41 = new cjs.Graphics().p("AsgGUIAAsnIZBAAIAAMng");
	var mask_3_graphics_42 = new cjs.Graphics().p("AtBGUIAAsnIaDAAIAAMng");
	var mask_3_graphics_43 = new cjs.Graphics().p("AtiGUIAAsnIbFAAIAAMng");
	var mask_3_graphics_44 = new cjs.Graphics().p("AuCGUIAAsnIcFAAIAAMng");
	var mask_3_graphics_45 = new cjs.Graphics().p("AujGUIAAsnIdHAAIAAMng");
	var mask_3_graphics_46 = new cjs.Graphics().p("AvEGUIAAsnIeJAAIAAMng");
	var mask_3_graphics_47 = new cjs.Graphics().p("AvlGUIAAsnIfLAAIAAMng");
	var mask_3_graphics_48 = new cjs.Graphics().p("AwGGUIAAsnMAgNAAAIAAMng");
	var mask_3_graphics_49 = new cjs.Graphics().p("AwnGUIAAsnMAhPAAAIAAMng");
	var mask_3_graphics_50 = new cjs.Graphics().p("AxIGUIAAsnMAiRAAAIAAMng");
	var mask_3_graphics_51 = new cjs.Graphics().p("AxpGUIAAsnMAjTAAAIAAMng");
	var mask_3_graphics_52 = new cjs.Graphics().p("AyKGUIAAsnMAkVAAAIAAMng");
	var mask_3_graphics_53 = new cjs.Graphics().p("AyqGUIAAsnMAlVAAAIAAMng");
	var mask_3_graphics_54 = new cjs.Graphics().p("AzLGUIAAsnMAmXAAAIAAMng");
	var mask_3_graphics_55 = new cjs.Graphics().p("AzsGUIAAsnMAnZAAAIAAMng");
	var mask_3_graphics_56 = new cjs.Graphics().p("A0NGUIAAsnMAobAAAIAAMng");
	var mask_3_graphics_57 = new cjs.Graphics().p("A0uGUIAAsnMApdAAAIAAMng");
	var mask_3_graphics_58 = new cjs.Graphics().p("A1PGUIAAsnMAqfAAAIAAMng");
	var mask_3_graphics_59 = new cjs.Graphics().p("A1wXyIAAsoMArhAAAIAAMog");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_3_graphics_18,x:-17.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_19,x:-14,y:264.2}).wait(1).to({graphics:mask_3_graphics_20,x:-10.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_21,x:-7.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_22,x:-4.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_23,x:-0.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_24,x:2.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_25,x:5.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_26,x:8.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_27,x:12.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_28,x:15.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_29,x:18.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_30,x:22.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_31,x:25.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_32,x:28.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_33,x:31.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_34,x:35.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_35,x:38.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_36,x:41.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_37,x:45.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_38,x:48.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_39,x:51.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_40,x:54.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_41,x:58.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_42,x:61.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_43,x:64.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_44,x:68.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_45,x:71.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_46,x:74.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_47,x:78,y:264.2}).wait(1).to({graphics:mask_3_graphics_48,x:81.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_49,x:84.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_50,x:87.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_51,x:91.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_52,x:94.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_53,x:97.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_54,x:101,y:264.2}).wait(1).to({graphics:mask_3_graphics_55,x:104.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_56,x:107.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_57,x:110.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_58,x:114.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_59,x:117.4,y:152.3}).wait(484));

	// formula_1
	this.mc_g1_01 = new cjs.Text(txt['mc_g1_01'], "20px Verdana");
	this.mc_g1_01.textAlign = "center";
	this.mc_g1_01.lineHeight = 20;
	this.mc_g1_01.lineWidth = 177;
	this.mc_g1_01.setTransform(160.5,236.4+incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_5.setTransform(161.6,267.2);

	this.mc_g1_02 = new cjs.Text(txt['mc_g1_02'], "20px Verdana");
	this.mc_g1_02.textAlign = "center";
	this.mc_g1_02.lineHeight = 20;
	this.mc_g1_02.lineWidth = 177;
	this.mc_g1_02.setTransform(160.4,266.1+incremento);

	this.text_7 = new cjs.Text("tg α =", "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 86;
	this.text_7.setTransform(-2.2,251.5+incremento);

	this.mc_g1_01.mask = this.shape_5.mask = this.mc_g1_02.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7,p:{x:-2.2}},{t:this.mc_g1_02,p:{x:160.4,y:266.1+incremento,text:"cateto adyacente",lineWidth:177}},{t:this.shape_5},{t:this.mc_g1_01,p:{x:160.5,y:236.4+incremento,text:"cateto opuesto",lineWidth:177}}]},18).to({state:[{t:this.mc_g1_02,p:{x:159.7,y:236.4+incremento,text:"cateto opuesto",lineWidth:175}},{t:this.mc_g1_01,p:{x:159.8,y:266.1+incremento,text:"cateto adyacente",lineWidth:175}},{t:this.shape_5},{t:this.text_7,p:{x:-2.2}}]},72).to({state:[{t:this.mc_g1_02,p:{x:159.4,y:236.4+incremento,text:"cateto opuesto",lineWidth:174}},{t:this.mc_g1_01,p:{x:159.3,y:266.1+incremento,text:"cateto adyacente",lineWidth:174}},{t:this.shape_5},{t:this.text_7,p:{x:-1.2}}]},70).to({state:[{t:this.mc_g1_02,p:{x:159.7,y:236.4+incremento,text:"cateto opuesto",lineWidth:175}},{t:this.mc_g1_01,p:{x:159.7,y:266.1+incremento,text:"cateto adyacente",lineWidth:175}},{t:this.shape_5},{t:this.text_7,p:{x:-2.2}}]},93).wait(290));

	// Resaltados
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuQIAAch");
	this.shape_6.setTransform(304.6,91.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00FF00").ss(3,1,1).p("AXwAAMgvfAAA");
	this.shape_7.setTransform(152.3,182.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6}]},90).to({state:[{t:this.shape_7}]},70).to({state:[]},93).wait(290));

	// Capa 1
	this.instance_1 = new lib.mc_g1_01();
	this.instance_1.setTransform(161.9,106.8,1,1,0,0,0,161.9,106.8);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:0.056},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.278},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.389},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.611},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.722},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:0.944},0).wait(1).to({alpha:1},0).wait(525));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,324.9,214.9);


(lib.mc_h2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	
	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_101 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_102 = new cjs.Graphics().p("AmNApIAAhRIMbAAIAABRg");
	var mask_graphics_103 = new cjs.Graphics().p("AmNA5IAAhxIMbAAIAABxg");
	var mask_graphics_104 = new cjs.Graphics().p("AmNBKIAAiTIMbAAIAACTg");
	var mask_graphics_105 = new cjs.Graphics().p("AmNBaIAAizIMbAAIAACzg");
	var mask_graphics_106 = new cjs.Graphics().p("AmNBrIAAjVIMbAAIAADVg");
	var mask_graphics_107 = new cjs.Graphics().p("AmNB7IAAj1IMbAAIAAD1g");
	var mask_graphics_108 = new cjs.Graphics().p("AmNCMIAAkXIMbAAIAAEXg");
	var mask_graphics_109 = new cjs.Graphics().p("AmNCdIAAk5IMbAAIAAE5g");
	var mask_graphics_110 = new cjs.Graphics().p("AmNCtIAAlZIMbAAIAAFZg");
	var mask_graphics_111 = new cjs.Graphics().p("AmNC+IAAl7IMbAAIAAF7g");
	var mask_graphics_112 = new cjs.Graphics().p("AmNDOIAAmbIMbAAIAAGbg");
	var mask_graphics_113 = new cjs.Graphics().p("AmNDfIAAm9IMbAAIAAG9g");
	var mask_graphics_114 = new cjs.Graphics().p("AmNDwIAAnfIMbAAIAAHfg");
	var mask_graphics_115 = new cjs.Graphics().p("AmNEAIAAn/IMbAAIAAH/g");
	var mask_graphics_116 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_183 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_184 = new cjs.Graphics().p("AmNEfIAAo9IMbAAIAAI9g");
	var mask_graphics_185 = new cjs.Graphics().p("AmNEtIAApZIMbAAIAAJZg");
	var mask_graphics_186 = new cjs.Graphics().p("AmNE7IAAp1IMbAAIAAJ1g");
	var mask_graphics_187 = new cjs.Graphics().p("AmNFJIAAqRIMbAAIAAKRg");
	var mask_graphics_188 = new cjs.Graphics().p("AmNFXIAAqtIMbAAIAAKtg");
	var mask_graphics_189 = new cjs.Graphics().p("AmNFkIAArHIMbAAIAALHg");
	var mask_graphics_190 = new cjs.Graphics().p("AmNFyIAArjIMbAAIAALjg");
	var mask_graphics_191 = new cjs.Graphics().p("AmNGAIAAr/IMbAAIAAL/g");
	var mask_graphics_192 = new cjs.Graphics().p("AmNGOIAAsbIMbAAIAAMbg");
	var mask_graphics_193 = new cjs.Graphics().p("AmNGcIAAs3IMbAAIAAM3g");
	var mask_graphics_194 = new cjs.Graphics().p("AOYY6IAAtVIMeAAIAANVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:303.8,y:235.9}).wait(101).to({graphics:mask_graphics_101,x:303.8,y:235.9}).wait(1).to({graphics:mask_graphics_102,x:303.8,y:237.6}).wait(1).to({graphics:mask_graphics_103,x:303.8,y:239.2}).wait(1).to({graphics:mask_graphics_104,x:303.8,y:240.9}).wait(1).to({graphics:mask_graphics_105,x:303.8,y:242.5}).wait(1).to({graphics:mask_graphics_106,x:303.8,y:244.2}).wait(1).to({graphics:mask_graphics_107,x:303.8,y:245.9}).wait(1).to({graphics:mask_graphics_108,x:303.8,y:247.5}).wait(1).to({graphics:mask_graphics_109,x:303.8,y:249.2}).wait(1).to({graphics:mask_graphics_110,x:303.8,y:250.8}).wait(1).to({graphics:mask_graphics_111,x:303.8,y:252.5}).wait(1).to({graphics:mask_graphics_112,x:303.8,y:254.1}).wait(1).to({graphics:mask_graphics_113,x:303.8,y:255.8}).wait(1).to({graphics:mask_graphics_114,x:303.8,y:257.5}).wait(1).to({graphics:mask_graphics_115,x:303.8,y:259.1}).wait(1).to({graphics:mask_graphics_116,x:171.8,y:144}).wait(67).to({graphics:mask_graphics_183,x:171.8,y:144}).wait(1).to({graphics:mask_graphics_184,x:303.8,y:262.2}).wait(1).to({graphics:mask_graphics_185,x:303.8,y:263.6}).wait(1).to({graphics:mask_graphics_186,x:303.8,y:265}).wait(1).to({graphics:mask_graphics_187,x:303.8,y:266.4}).wait(1).to({graphics:mask_graphics_188,x:303.8,y:267.8}).wait(1).to({graphics:mask_graphics_189,x:303.8,y:269.2}).wait(1).to({graphics:mask_graphics_190,x:303.8,y:270.6}).wait(1).to({graphics:mask_graphics_191,x:303.8,y:272}).wait(1).to({graphics:mask_graphics_192,x:303.8,y:273.5}).wait(1).to({graphics:mask_graphics_193,x:303.8,y:274.9}).wait(1).to({graphics:mask_graphics_194,x:171.8,y:159.5}).wait(89));

	// Formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(313.1,283.5,0.207,1);

	this.text = new cjs.Text("5", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(304.2,283.1+incremento);

	this.text_1 = new cjs.Text("4", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(304.3,252.6+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(265.7,267.7+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(283));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AhGZAIAAr0IB7AAIAAL0g");
	var mask_1_graphics_1 = new cjs.Graphics().p("AhkF5IAAryIDJAAIAALyg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AiMF5IAAryIEZAAIAALyg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AizF5IAAryIFnAAIAALyg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AjaF5IAAryIG1AAIAALyg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AkBF5IAAryIIDAAIAALyg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AkpF5IAAryIJTAAIAALyg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AlQF5IAAryIKhAAIAALyg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Al3F5IAAryILvAAIAALyg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AmeF5IAAryIM9AAIAALyg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AnGF5IAAryIONAAIAALyg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AntF5IAAryIPbAAIAALyg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AoUF5IAAryIQpAAIAALyg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Ao7F5IAAryIR3AAIAALyg");
	var mask_1_graphics_14 = new cjs.Graphics().p("ApjF5IAAryITHAAIAALyg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AqKF5IAAryIUVAAIAALyg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AqxF5IAAryIVjAAIAALyg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArYF5IAAryIWyAAIAALyg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AsAF5IAAryIYBAAIAALyg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AsnF5IAAryIZPAAIAALyg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AtOF5IAAryIadAAIAALyg");
	var mask_1_graphics_21 = new cjs.Graphics().p("At2F5IAAryIbtAAIAALyg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AudF5IAAryIc7AAIAALyg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AvEF5IAAryIeJAAIAALyg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AvrF5IAAryIfXAAIAALyg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AwTF5IAAryMAgnAAAIAALyg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aw6F5IAAryMAh1AAAIAALyg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AxhF5IAAryMAjDAAAIAALyg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AyIF5IAAryMAkRAAAIAALyg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AywF5IAAryMAlhAAAIAALyg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AzXF5IAAryMAmvAAAIAALyg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Az+F5IAAryMAn9AAAIAALyg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A0lF5IAAryMApLAAAIAALyg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A1NF5IAAryMAqbAAAIAALyg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A10ZAIAAr0MArpAAAIAAL0g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-7,y:160.1}).wait(1).to({graphics:mask_1_graphics_1,x:-4,y:282.4}).wait(1).to({graphics:mask_1_graphics_2,x:-0.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_3,x:3.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_4,x:7.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_5,x:11.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_6,x:15.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_7,x:19.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_8,x:23.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_9,x:27.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_10,x:31.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_11,x:35,y:282.4}).wait(1).to({graphics:mask_1_graphics_12,x:38.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_13,x:42.8,y:282.4}).wait(1).to({graphics:mask_1_graphics_14,x:46.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_15,x:50.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_16,x:54.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_17,x:58.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_18,x:62.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_19,x:66.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_20,x:70.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_21,x:74.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_22,x:78,y:282.4}).wait(1).to({graphics:mask_1_graphics_23,x:81.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_24,x:85.8,y:282.4}).wait(1).to({graphics:mask_1_graphics_25,x:89.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_26,x:93.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_27,x:97.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_28,x:101.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_29,x:105.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_30,x:109.2,y:282.4}).wait(1).to({graphics:mask_1_graphics_31,x:113.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_32,x:117,y:282.4}).wait(1).to({graphics:mask_1_graphics_33,x:120.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_34,x:124.8,y:160.1}).wait(249));

	// Formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(168.7,283.5);

	this.mc_h2_02 = new cjs.Text(txt['mc_h2_02'], "20px Verdana");
	this.mc_h2_02.textAlign = "center";
	this.mc_h2_02.lineHeight = 20;
	this.mc_h2_02.lineWidth = 155;
	this.mc_h2_02.setTransform(166.7,282.3+incremento);

	this.mc_h2_01 = new cjs.Text(txt['mc_h2_01'], "20px Verdana");
	this.mc_h2_01.textAlign = "center";
	this.mc_h2_01.lineHeight = 20;
	this.mc_h2_01.lineWidth = 175;
	this.mc_h2_01.setTransform(166.6,252.6+incremento);

	this.text_3 = new cjs.Text("cos α =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 81;
	this.text_3.setTransform(-2.2,267.7+incremento);

	this.shape_1.mask = this.mc_h2_02.mask = this.mc_h2_01.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.mc_h2_01,p:{lineWidth:175,x:166.6}},{t:this.mc_h2_02},{t:this.shape_1}]}).to({state:[{t:this.mc_h2_01,p:{lineWidth:174,x:166.6}},{t:this.mc_h2_02},{t:this.shape_1},{t:this.text_3}]},68).to({state:[{t:this.mc_h2_01,p:{lineWidth:175,x:166.8}},{t:this.mc_h2_02},{t:this.shape_1},{t:this.text_3}]},80).to({state:[{t:this.mc_h2_01,p:{lineWidth:174,x:166.5}},{t:this.mc_h2_02},{t:this.shape_1},{t:this.text_3}]},75).wait(60));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AXzAAMgvlAAA");
	this.shape_2.setTransform(155.5,182.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AX5uRMgvxAcj");
	this.shape_3.setTransform(154.6,91.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},68).to({state:[{t:this.shape_3}]},80).to({state:[]},75).wait(60));

	// mc_f2_01
	this.instance_1 = new lib.mc_h2_01();
	this.instance_1.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:162,x:165.1},0).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,0,330.5,330.1);


(lib.mc_h2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mc_f2_01
	this.instance = new lib.mc_h2_01();
	this.instance.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:162,x:165.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,0,325.1,214.9);


(lib.mc_h1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_280 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_379 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_380 = new cjs.Graphics().p("Al/BBIAAiBIL/AAIAACBg");
	var mask_graphics_381 = new cjs.Graphics().p("Al/BNIAAiZIL/AAIAACZg");
	var mask_graphics_382 = new cjs.Graphics().p("Al/BZIAAixIL/AAIAACxg");
	var mask_graphics_383 = new cjs.Graphics().p("Al/BmIAAjLIL/AAIAADLg");
	var mask_graphics_384 = new cjs.Graphics().p("Al/ByIAAjjIL/AAIAADjg");
	var mask_graphics_385 = new cjs.Graphics().p("Al/B+IAAj7IL/AAIAAD7g");
	var mask_graphics_386 = new cjs.Graphics().p("Al/CKIAAkTIL/AAIAAETg");
	var mask_graphics_387 = new cjs.Graphics().p("Al/CWIAAkrIL/AAIAAErg");
	var mask_graphics_388 = new cjs.Graphics().p("Al/CiIAAlDIL/AAIAAFDg");
	var mask_graphics_389 = new cjs.Graphics().p("Al/CvIAAldIL/AAIAAFdg");
	var mask_graphics_390 = new cjs.Graphics().p("Al/C7IAAl1IL/AAIAAF1g");
	var mask_graphics_391 = new cjs.Graphics().p("Al/DHIAAmNIL/AAIAAGNg");
	var mask_graphics_392 = new cjs.Graphics().p("Al/DTIAAmlIL/AAIAAGlg");
	var mask_graphics_393 = new cjs.Graphics().p("Al/DfIAAm9IL/AAIAAG9g");
	var mask_graphics_394 = new cjs.Graphics().p("Al/DsIAAnXIL/AAIAAHXg");
	var mask_graphics_395 = new cjs.Graphics().p("Al/D4IAAnvIL/AAIAAHvg");
	var mask_graphics_396 = new cjs.Graphics().p("EAtBAVeIAAoJIMBAAIAAIJg");
	var mask_graphics_467 = new cjs.Graphics().p("EAtBAVeIAAoJIMBAAIAAIJg");
	var mask_graphics_468 = new cjs.Graphics().p("Al/EPIAAodIL/AAIAAIdg");
	var mask_graphics_469 = new cjs.Graphics().p("Al/EbIAAo1IL/AAIAAI1g");
	var mask_graphics_470 = new cjs.Graphics().p("Al/EmIAApLIL/AAIAAJLg");
	var mask_graphics_471 = new cjs.Graphics().p("Al/ExIAAphIL/AAIAAJhg");
	var mask_graphics_472 = new cjs.Graphics().p("Al/E9IAAp5IL/AAIAAJ5g");
	var mask_graphics_473 = new cjs.Graphics().p("Al/FIIAAqPIL/AAIAAKPg");
	var mask_graphics_474 = new cjs.Graphics().p("Al/FTIAAqlIL/AAIAAKlg");
	var mask_graphics_475 = new cjs.Graphics().p("Al/FfIAAq9IL/AAIAAK9g");
	var mask_graphics_476 = new cjs.Graphics().p("Al/FqIAArTIL/AAIAALTg");
	var mask_graphics_477 = new cjs.Graphics().p("Al/F1IAArpIL/AAIAALpg");
	var mask_graphics_478 = new cjs.Graphics().p("EAtBAXbIAAsDIMBAAIAAMDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_graphics_280,x:691.6,y:228.2}).wait(99).to({graphics:mask_graphics_379,x:691.6,y:228.2}).wait(1).to({graphics:mask_graphics_380,x:691.6,y:229.4}).wait(1).to({graphics:mask_graphics_381,x:691.6,y:230.7}).wait(1).to({graphics:mask_graphics_382,x:691.6,y:231.9}).wait(1).to({graphics:mask_graphics_383,x:691.6,y:233.1}).wait(1).to({graphics:mask_graphics_384,x:691.6,y:234.3}).wait(1).to({graphics:mask_graphics_385,x:691.6,y:235.5}).wait(1).to({graphics:mask_graphics_386,x:691.6,y:236.8}).wait(1).to({graphics:mask_graphics_387,x:691.6,y:238}).wait(1).to({graphics:mask_graphics_388,x:691.6,y:239.2}).wait(1).to({graphics:mask_graphics_389,x:691.6,y:240.4}).wait(1).to({graphics:mask_graphics_390,x:691.6,y:241.6}).wait(1).to({graphics:mask_graphics_391,x:691.6,y:242.9}).wait(1).to({graphics:mask_graphics_392,x:691.6,y:244.1}).wait(1).to({graphics:mask_graphics_393,x:691.6,y:245.3}).wait(1).to({graphics:mask_graphics_394,x:691.6,y:246.5}).wait(1).to({graphics:mask_graphics_395,x:691.6,y:247.7}).wait(1).to({graphics:mask_graphics_396,x:365,y:137.5}).wait(71).to({graphics:mask_graphics_467,x:365,y:137.5}).wait(1).to({graphics:mask_graphics_468,x:691.6,y:250.1}).wait(1).to({graphics:mask_graphics_469,x:691.6,y:251.2}).wait(1).to({graphics:mask_graphics_470,x:691.6,y:252.3}).wait(1).to({graphics:mask_graphics_471,x:691.6,y:253.5}).wait(1).to({graphics:mask_graphics_472,x:691.6,y:254.6}).wait(1).to({graphics:mask_graphics_473,x:691.6,y:255.7}).wait(1).to({graphics:mask_graphics_474,x:691.6,y:256.9}).wait(1).to({graphics:mask_graphics_475,x:691.6,y:258}).wait(1).to({graphics:mask_graphics_476,x:691.6,y:259.1}).wait(1).to({graphics:mask_graphics_477,x:691.6,y:260.2}).wait(1).to({graphics:mask_graphics_478,x:365,y:149.9}).wait(65));

	// formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(701.9,267.5,0.207,1);

	this.text = new cjs.Text("a", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(693,266.4+incremento);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 14;
	this.text_1.setTransform(693.1,236.7+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(654.5,251.8+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]},280).wait(263));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_280 = new cjs.Graphics().p("AhNFbIAAq1ICbAAIAAK1g");
	var mask_1_graphics_281 = new cjs.Graphics().p("AhzFbIAAq1IDnAAIAAK1g");
	var mask_1_graphics_282 = new cjs.Graphics().p("AiYFbIAAq1IExAAIAAK1g");
	var mask_1_graphics_283 = new cjs.Graphics().p("Ai+FbIAAq1IF9AAIAAK1g");
	var mask_1_graphics_284 = new cjs.Graphics().p("AjkFbIAAq1IHJAAIAAK1g");
	var mask_1_graphics_285 = new cjs.Graphics().p("AkKFbIAAq1IIVAAIAAK1g");
	var mask_1_graphics_286 = new cjs.Graphics().p("AkvFbIAAq1IJfAAIAAK1g");
	var mask_1_graphics_287 = new cjs.Graphics().p("AlVFbIAAq1IKrAAIAAK1g");
	var mask_1_graphics_288 = new cjs.Graphics().p("Al7FbIAAq1IL3AAIAAK1g");
	var mask_1_graphics_289 = new cjs.Graphics().p("AmhFbIAAq1INDAAIAAK1g");
	var mask_1_graphics_290 = new cjs.Graphics().p("AnGFbIAAq1IONAAIAAK1g");
	var mask_1_graphics_291 = new cjs.Graphics().p("AnsFbIAAq1IPZAAIAAK1g");
	var mask_1_graphics_292 = new cjs.Graphics().p("AoSFbIAAq1IQlAAIAAK1g");
	var mask_1_graphics_293 = new cjs.Graphics().p("Ao4FbIAAq1IRxAAIAAK1g");
	var mask_1_graphics_294 = new cjs.Graphics().p("ApdFbIAAq1IS7AAIAAK1g");
	var mask_1_graphics_295 = new cjs.Graphics().p("AqDFbIAAq1IUHAAIAAK1g");
	var mask_1_graphics_296 = new cjs.Graphics().p("AqpFbIAAq1IVTAAIAAK1g");
	var mask_1_graphics_297 = new cjs.Graphics().p("ArPFbIAAq1IWfAAIAAK1g");
	var mask_1_graphics_298 = new cjs.Graphics().p("Ar0FbIAAq1IXpAAIAAK1g");
	var mask_1_graphics_299 = new cjs.Graphics().p("AsaFbIAAq1IY1AAIAAK1g");
	var mask_1_graphics_300 = new cjs.Graphics().p("AtAFbIAAq1IaBAAIAAK1g");
	var mask_1_graphics_301 = new cjs.Graphics().p("AtmFbIAAq1IbNAAIAAK1g");
	var mask_1_graphics_302 = new cjs.Graphics().p("AuLFbIAAq1IcXAAIAAK1g");
	var mask_1_graphics_303 = new cjs.Graphics().p("AuxFbIAAq1IdjAAIAAK1g");
	var mask_1_graphics_304 = new cjs.Graphics().p("AvXFbIAAq1IevAAIAAK1g");
	var mask_1_graphics_305 = new cjs.Graphics().p("Av9FbIAAq1If7AAIAAK1g");
	var mask_1_graphics_306 = new cjs.Graphics().p("AwiFbIAAq1MAhFAAAIAAK1g");
	var mask_1_graphics_307 = new cjs.Graphics().p("AxIFbIAAq1MAiRAAAIAAK1g");
	var mask_1_graphics_308 = new cjs.Graphics().p("AxuFbIAAq1MAjdAAAIAAK1g");
	var mask_1_graphics_309 = new cjs.Graphics().p("AyUFbIAAq1MAkpAAAIAAK1g");
	var mask_1_graphics_310 = new cjs.Graphics().p("Ay5FbIAAq1MAlzAAAIAAK1g");
	var mask_1_graphics_311 = new cjs.Graphics().p("AzfFbIAAq1MAm/AAAIAAK1g");
	var mask_1_graphics_312 = new cjs.Graphics().p("A0FFbIAAq1MAoLAAAIAAK1g");
	var mask_1_graphics_313 = new cjs.Graphics().p("A0rFbIAAq1MApXAAAIAAK1g");
	var mask_1_graphics_314 = new cjs.Graphics().p("A1QFbIAAq1MAqhAAAIAAK1g");
	var mask_1_graphics_315 = new cjs.Graphics().p("AHNXgIAAq3MArvAAAIAAK3g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_1_graphics_280,x:380.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_281,x:383.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_282,x:387.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_283,x:391.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_284,x:395.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_285,x:398.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_286,x:402.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_287,x:406.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_288,x:410.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_289,x:414,y:266.1}).wait(1).to({graphics:mask_1_graphics_290,x:417.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_291,x:421.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_292,x:425.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_293,x:429.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_294,x:432.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_295,x:436.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_296,x:440.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_297,x:444.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_298,x:448,y:266.1}).wait(1).to({graphics:mask_1_graphics_299,x:451.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_300,x:455.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_301,x:459.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_302,x:463.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_303,x:466.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_304,x:470.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_305,x:474.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_306,x:478.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_307,x:482,y:266.1}).wait(1).to({graphics:mask_1_graphics_308,x:485.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_309,x:489.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_310,x:493.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_311,x:497.1,y:266.1}).wait(1).to({graphics:mask_1_graphics_312,x:500.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_313,x:504.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_314,x:508.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_315,x:326,y:150.5}).wait(228));

	// formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(557.5,267.5);

	this.mc_h1_04 = new cjs.Text(txt['mc_h1_04'], "20px Verdana");
	this.mc_h1_04.textAlign = "center";
	this.mc_h1_04.lineHeight = 20;
	this.mc_h1_04.lineWidth = 155;
	this.mc_h1_04.setTransform(555.5,266.4+incremento);

	this.mc_h1_03 = new cjs.Text(txt['mc_h1_03'], "20px Verdana");
	this.mc_h1_03.textAlign = "center";
	this.mc_h1_03.lineHeight = 20;
	this.mc_h1_03.lineWidth = 175;
	this.mc_h1_03.setTransform(555.3,236.7+incremento);

	this.text_3 = new cjs.Text("cos ß =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 89;
	this.text_3.setTransform(385.8,251.8+incremento);

	this.shape_1.mask = this.mc_h1_04.mask = this.mc_h1_03.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.mc_h1_03,p:{x:555.3}},{t:this.mc_h1_04},{t:this.shape_1}]},280).to({state:[{t:this.mc_h1_03,p:{x:555.1}},{t:this.mc_h1_04},{t:this.shape_1},{t:this.text_3}]},74).to({state:[{t:this.mc_h1_03,p:{x:555.1}},{t:this.mc_h1_04},{t:this.shape_1},{t:this.text_3}]},70).to({state:[{t:this.mc_h1_03,p:{x:555.1}},{t:this.mc_h1_04},{t:this.shape_1},{t:this.text_3}]},76).wait(43));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuPIAAcf");
	this.shape_2.setTransform(708.6,89.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AX0uSMgvnAcl");
	this.shape_3.setTransform(556.3,90.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},354).to({state:[{t:this.shape_3}]},70).to({state:[]},76).wait(43));

	// triangulo_2
	this.instance = new lib.mc_h1_02();
	this.instance.setTransform(565.9,105.5,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(263).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(263));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_18 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AmBAuIAAhbIMDAAIAABbg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AmBA5IAAhxIMDAAIAABxg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AmBBFIAAiJIMDAAIAACJg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AmBBQIAAifIMDAAIAACfg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AmBBbIAAi1IMDAAIAAC1g");
	var mask_2_graphics_119 = new cjs.Graphics().p("AmBBnIAAjNIMDAAIAADNg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AmBByIAAjjIMDAAIAADjg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AmBB9IAAj5IMDAAIAAD5g");
	var mask_2_graphics_122 = new cjs.Graphics().p("AmBCJIAAkRIMDAAIAAERg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AmBCUIAAknIMDAAIAAEng");
	var mask_2_graphics_124 = new cjs.Graphics().p("AmBCfIAAk9IMDAAIAAE9g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AmBCrIAAlVIMDAAIAAFVg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AmBC2IAAlrIMDAAIAAFrg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AmBDBIAAmBIMDAAIAAGBg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AmBDNIAAmZIMDAAIAAGZg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AmBDYIAAmvIMDAAIAAGvg");
	var mask_2_graphics_130 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_197 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_198 = new cjs.Graphics().p("AmBDsIAAnXIMDAAIAAHXg");
	var mask_2_graphics_199 = new cjs.Graphics().p("AmBD0IAAnnIMDAAIAAHng");
	var mask_2_graphics_200 = new cjs.Graphics().p("AmBD9IAAn5IMDAAIAAH5g");
	var mask_2_graphics_201 = new cjs.Graphics().p("AmBEFIAAoJIMDAAIAAIJg");
	var mask_2_graphics_202 = new cjs.Graphics().p("AmBEOIAAobIMDAAIAAIbg");
	var mask_2_graphics_203 = new cjs.Graphics().p("AmBEWIAAorIMDAAIAAIrg");
	var mask_2_graphics_204 = new cjs.Graphics().p("AmBEfIAAo9IMDAAIAAI9g");
	var mask_2_graphics_205 = new cjs.Graphics().p("AmBEnIAApNIMDAAIAAJNg");
	var mask_2_graphics_206 = new cjs.Graphics().p("AmBEwIAApfIMDAAIAAJfg");
	var mask_2_graphics_207 = new cjs.Graphics().p("AmBE4IAApvIMDAAIAAJvg");
	var mask_2_graphics_208 = new cjs.Graphics().p("AmBFBIAAqBIMDAAIAAKBg");
	var mask_2_graphics_209 = new cjs.Graphics().p("AmBFJIAAqRIMDAAIAAKRg");
	var mask_2_graphics_210 = new cjs.Graphics().p("AmBFSIAAqjIMDAAIAAKjg");
	var mask_2_graphics_211 = new cjs.Graphics().p("AmBFaIAAqzIMDAAIAAKzg");
	var mask_2_graphics_212 = new cjs.Graphics().p("AmBFjIAArFIMDAAIAALFg");
	var mask_2_graphics_213 = new cjs.Graphics().p("AmBFrIAArVIMDAAIAALVg");
	var mask_2_graphics_214 = new cjs.Graphics().p("AmBF0IAArnIMDAAIAALng");
	var mask_2_graphics_215 = new cjs.Graphics().p("AOOXrIAAr6IMGAAIAAL6g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_2_graphics_18,x:298.2,y:230.4}).wait(95).to({graphics:mask_2_graphics_113,x:298.2,y:230.4}).wait(1).to({graphics:mask_2_graphics_114,x:298.2,y:231.5}).wait(1).to({graphics:mask_2_graphics_115,x:298.2,y:232.6}).wait(1).to({graphics:mask_2_graphics_116,x:298.2,y:233.8}).wait(1).to({graphics:mask_2_graphics_117,x:298.2,y:234.9}).wait(1).to({graphics:mask_2_graphics_118,x:298.2,y:236}).wait(1).to({graphics:mask_2_graphics_119,x:298.2,y:237.2}).wait(1).to({graphics:mask_2_graphics_120,x:298.2,y:238.3}).wait(1).to({graphics:mask_2_graphics_121,x:298.2,y:239.4}).wait(1).to({graphics:mask_2_graphics_122,x:298.2,y:240.6}).wait(1).to({graphics:mask_2_graphics_123,x:298.2,y:241.7}).wait(1).to({graphics:mask_2_graphics_124,x:298.2,y:242.8}).wait(1).to({graphics:mask_2_graphics_125,x:298.2,y:244}).wait(1).to({graphics:mask_2_graphics_126,x:298.2,y:245.1}).wait(1).to({graphics:mask_2_graphics_127,x:298.2,y:246.2}).wait(1).to({graphics:mask_2_graphics_128,x:298.2,y:247.4}).wait(1).to({graphics:mask_2_graphics_129,x:298.2,y:248.5}).wait(1).to({graphics:mask_2_graphics_130,x:168.4,y:136.2}).wait(67).to({graphics:mask_2_graphics_197,x:168.4,y:136.2}).wait(1).to({graphics:mask_2_graphics_198,x:298.2,y:250.5}).wait(1).to({graphics:mask_2_graphics_199,x:298.2,y:251.3}).wait(1).to({graphics:mask_2_graphics_200,x:298.2,y:252.2}).wait(1).to({graphics:mask_2_graphics_201,x:298.2,y:253}).wait(1).to({graphics:mask_2_graphics_202,x:298.2,y:253.9}).wait(1).to({graphics:mask_2_graphics_203,x:298.2,y:254.7}).wait(1).to({graphics:mask_2_graphics_204,x:298.2,y:255.6}).wait(1).to({graphics:mask_2_graphics_205,x:298.2,y:256.4}).wait(1).to({graphics:mask_2_graphics_206,x:298.2,y:257.3}).wait(1).to({graphics:mask_2_graphics_207,x:298.2,y:258.2}).wait(1).to({graphics:mask_2_graphics_208,x:298.2,y:259}).wait(1).to({graphics:mask_2_graphics_209,x:298.2,y:259.9}).wait(1).to({graphics:mask_2_graphics_210,x:298.2,y:260.7}).wait(1).to({graphics:mask_2_graphics_211,x:298.2,y:261.6}).wait(1).to({graphics:mask_2_graphics_212,x:298.2,y:262.4}).wait(1).to({graphics:mask_2_graphics_213,x:298.2,y:263.3}).wait(1).to({graphics:mask_2_graphics_214,x:298.2,y:264.1}).wait(1).to({graphics:mask_2_graphics_215,x:168.4,y:151.5}).wait(328));

	// formula_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_4.setTransform(306,267.2,0.207,1);

	this.text_4 = new cjs.Text("a", "italic 20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 14;
	this.text_4.setTransform(297.1,266.1+incremento);

	this.text_5 = new cjs.Text("c", "italic 20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 14;
	this.text_5.setTransform(297.2,236.4+incremento);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 16;
	this.text_6.setTransform(258.6,251.5+incremento);

	this.shape_4.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_4}]},18).wait(525));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_18 = new cjs.Graphics().p("AgrGUIAAsnIBYAAIAAMng");
	var mask_3_graphics_19 = new cjs.Graphics().p("AhMGUIAAsnICZAAIAAMng");
	var mask_3_graphics_20 = new cjs.Graphics().p("AhtGUIAAsnIDbAAIAAMng");
	var mask_3_graphics_21 = new cjs.Graphics().p("AiOGUIAAsnIEdAAIAAMng");
	var mask_3_graphics_22 = new cjs.Graphics().p("AivGUIAAsnIFfAAIAAMng");
	var mask_3_graphics_23 = new cjs.Graphics().p("AjQGUIAAsnIGhAAIAAMng");
	var mask_3_graphics_24 = new cjs.Graphics().p("AjxGUIAAsnIHjAAIAAMng");
	var mask_3_graphics_25 = new cjs.Graphics().p("AkSGUIAAsnIIlAAIAAMng");
	var mask_3_graphics_26 = new cjs.Graphics().p("AkzGUIAAsnIJnAAIAAMng");
	var mask_3_graphics_27 = new cjs.Graphics().p("AlTGUIAAsnIKnAAIAAMng");
	var mask_3_graphics_28 = new cjs.Graphics().p("Al0GUIAAsnILpAAIAAMng");
	var mask_3_graphics_29 = new cjs.Graphics().p("AmVGUIAAsnIMrAAIAAMng");
	var mask_3_graphics_30 = new cjs.Graphics().p("Am2GUIAAsnINtAAIAAMng");
	var mask_3_graphics_31 = new cjs.Graphics().p("AnXGUIAAsnIOvAAIAAMng");
	var mask_3_graphics_32 = new cjs.Graphics().p("An4GUIAAsnIPxAAIAAMng");
	var mask_3_graphics_33 = new cjs.Graphics().p("AoZGUIAAsnIQzAAIAAMng");
	var mask_3_graphics_34 = new cjs.Graphics().p("Ao6GUIAAsnIR1AAIAAMng");
	var mask_3_graphics_35 = new cjs.Graphics().p("ApbGUIAAsnIS3AAIAAMng");
	var mask_3_graphics_36 = new cjs.Graphics().p("Ap7GUIAAsnIT3AAIAAMng");
	var mask_3_graphics_37 = new cjs.Graphics().p("AqcGUIAAsnIU5AAIAAMng");
	var mask_3_graphics_38 = new cjs.Graphics().p("Aq9GUIAAsnIV7AAIAAMng");
	var mask_3_graphics_39 = new cjs.Graphics().p("AreGUIAAsnIW9AAIAAMng");
	var mask_3_graphics_40 = new cjs.Graphics().p("Ar/GUIAAsnIX/AAIAAMng");
	var mask_3_graphics_41 = new cjs.Graphics().p("AsgGUIAAsnIZBAAIAAMng");
	var mask_3_graphics_42 = new cjs.Graphics().p("AtBGUIAAsnIaDAAIAAMng");
	var mask_3_graphics_43 = new cjs.Graphics().p("AtiGUIAAsnIbFAAIAAMng");
	var mask_3_graphics_44 = new cjs.Graphics().p("AuCGUIAAsnIcFAAIAAMng");
	var mask_3_graphics_45 = new cjs.Graphics().p("AujGUIAAsnIdHAAIAAMng");
	var mask_3_graphics_46 = new cjs.Graphics().p("AvEGUIAAsnIeJAAIAAMng");
	var mask_3_graphics_47 = new cjs.Graphics().p("AvlGUIAAsnIfLAAIAAMng");
	var mask_3_graphics_48 = new cjs.Graphics().p("AwGGUIAAsnMAgNAAAIAAMng");
	var mask_3_graphics_49 = new cjs.Graphics().p("AwnGUIAAsnMAhPAAAIAAMng");
	var mask_3_graphics_50 = new cjs.Graphics().p("AxIGUIAAsnMAiRAAAIAAMng");
	var mask_3_graphics_51 = new cjs.Graphics().p("AxpGUIAAsnMAjTAAAIAAMng");
	var mask_3_graphics_52 = new cjs.Graphics().p("AyKGUIAAsnMAkVAAAIAAMng");
	var mask_3_graphics_53 = new cjs.Graphics().p("AyqGUIAAsnMAlVAAAIAAMng");
	var mask_3_graphics_54 = new cjs.Graphics().p("AzLGUIAAsnMAmXAAAIAAMng");
	var mask_3_graphics_55 = new cjs.Graphics().p("AzsGUIAAsnMAnZAAAIAAMng");
	var mask_3_graphics_56 = new cjs.Graphics().p("A0NGUIAAsnMAobAAAIAAMng");
	var mask_3_graphics_57 = new cjs.Graphics().p("A0uGUIAAsnMApdAAAIAAMng");
	var mask_3_graphics_58 = new cjs.Graphics().p("A1PGUIAAsnMAqfAAAIAAMng");
	var mask_3_graphics_59 = new cjs.Graphics().p("A1wXyIAAsoMArhAAAIAAMog");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_3_graphics_18,x:-17.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_19,x:-14,y:264.2}).wait(1).to({graphics:mask_3_graphics_20,x:-10.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_21,x:-7.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_22,x:-4.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_23,x:-0.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_24,x:2.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_25,x:5.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_26,x:8.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_27,x:12.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_28,x:15.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_29,x:18.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_30,x:22.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_31,x:25.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_32,x:28.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_33,x:31.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_34,x:35.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_35,x:38.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_36,x:41.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_37,x:45.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_38,x:48.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_39,x:51.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_40,x:54.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_41,x:58.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_42,x:61.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_43,x:64.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_44,x:68.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_45,x:71.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_46,x:74.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_47,x:78,y:264.2}).wait(1).to({graphics:mask_3_graphics_48,x:81.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_49,x:84.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_50,x:87.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_51,x:91.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_52,x:94.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_53,x:97.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_54,x:101,y:264.2}).wait(1).to({graphics:mask_3_graphics_55,x:104.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_56,x:107.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_57,x:110.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_58,x:114.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_59,x:117.4,y:152.3}).wait(484));

	// formula_1
	this.mc_h1_01 = new cjs.Text(txt['mc_h1_01'], "20px Verdana");
	this.mc_h1_01.textAlign = "center";
	this.mc_h1_01.lineHeight = 20;
	this.mc_h1_01.lineWidth = 177;
	this.mc_h1_01.setTransform(160.5,236.4+incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_5.setTransform(161.6,267.2);

	this.mc_h1_02 = new cjs.Text(txt['mc_h1_02'], "20px Verdana");
	this.mc_h1_02.textAlign = "center";
	this.mc_h1_02.lineHeight = 20;
	this.mc_h1_02.lineWidth = 155;
	this.mc_h1_02.setTransform(159.6,266.1+incremento);

	this.text_7 = new cjs.Text("cos α =", "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 93;
	this.text_7.setTransform(-11.5,251.5+incremento);

	this.mc_h1_01.mask = this.shape_5.mask = this.mc_h1_02.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.mc_h1_02,p:{x:159.6,y:266.1+incremento,text:"hipotenusa",lineWidth:155}},{t:this.shape_5},{t:this.mc_h1_01,p:{x:160.5,y:236.4+incremento,text:"cateto adyacente",lineWidth:177}}]},18).to({state:[{t:this.mc_h1_02,p:{x:159.7,y:236.4+incremento,text:"cateto adyacente",color:'green',lineWidth:175}},{t:this.mc_h1_01,p:{x:159.6,y:266.1+incremento,text:"hipotenusa",lineWidth:155}},{t:this.shape_5},{t:this.text_7}]},72).to({state:[{t:this.mc_h1_02,p:{x:159.4,y:236.4+incremento,text:"cateto adyacente",color:'black',lineWidth:174}},{t:this.mc_h1_01,p:{x:159.6,y:266.1+incremento,text:"hipotenusa",color:'green',lineWidth:155}},{t:this.shape_5},{t:this.text_7}]},70).to({state:[{t:this.mc_h1_02,p:{x:159.7,y:236.4+incremento,text:"cateto adyacente",color:'black',lineWidth:175}},{t:this.mc_h1_01,p:{x:159.6,y:266.1+incremento,text:"hipotenusa",color:'black',lineWidth:155}},{t:this.shape_5},{t:this.text_7}]},93).wait(290));

	// Resaltados
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#00FF00").ss(3,1,1).p("AXzAAMgvlAAA");
	this.shape_6.setTransform(152.4,183.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00FF00").ss(3,1,1).p("AXvuOMgvcAcd");
	this.shape_7.setTransform(152.5,91.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6}]},90).to({state:[{t:this.shape_7}]},70).to({state:[]},93).wait(290));

	// Capa 1
	this.instance_1 = new lib.mc_h1_01();
	this.instance_1.setTransform(161.9,106.8,1,1,0,0,0,161.9,106.8);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:0.056},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.278},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.389},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.611},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.722},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:0.944},0).wait(1).to({alpha:1},0).wait(525));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,324.9,214.9);


(lib.mc_f2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_101 = new cjs.Graphics().p("AmNAYIAAgvIMbAAIAAAvg");
	var mask_graphics_102 = new cjs.Graphics().p("AmNApIAAhRIMbAAIAABRg");
	var mask_graphics_103 = new cjs.Graphics().p("AmNA5IAAhxIMbAAIAABxg");
	var mask_graphics_104 = new cjs.Graphics().p("AmNBKIAAiTIMbAAIAACTg");
	var mask_graphics_105 = new cjs.Graphics().p("AmNBaIAAizIMbAAIAACzg");
	var mask_graphics_106 = new cjs.Graphics().p("AmNBrIAAjVIMbAAIAADVg");
	var mask_graphics_107 = new cjs.Graphics().p("AmNB7IAAj1IMbAAIAAD1g");
	var mask_graphics_108 = new cjs.Graphics().p("AmNCMIAAkXIMbAAIAAEXg");
	var mask_graphics_109 = new cjs.Graphics().p("AmNCdIAAk5IMbAAIAAE5g");
	var mask_graphics_110 = new cjs.Graphics().p("AmNCtIAAlZIMbAAIAAFZg");
	var mask_graphics_111 = new cjs.Graphics().p("AmNC+IAAl7IMbAAIAAF7g");
	var mask_graphics_112 = new cjs.Graphics().p("AmNDOIAAmbIMbAAIAAGbg");
	var mask_graphics_113 = new cjs.Graphics().p("AmNDfIAAm9IMbAAIAAG9g");
	var mask_graphics_114 = new cjs.Graphics().p("AmNDwIAAnfIMbAAIAAHfg");
	var mask_graphics_115 = new cjs.Graphics().p("AmNEAIAAn/IMbAAIAAH/g");
	var mask_graphics_116 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_183 = new cjs.Graphics().p("AOYWgIAAojIMeAAIAAIjg");
	var mask_graphics_184 = new cjs.Graphics().p("AmNEfIAAo9IMbAAIAAI9g");
	var mask_graphics_185 = new cjs.Graphics().p("AmNEtIAApZIMbAAIAAJZg");
	var mask_graphics_186 = new cjs.Graphics().p("AmNE7IAAp1IMbAAIAAJ1g");
	var mask_graphics_187 = new cjs.Graphics().p("AmNFJIAAqRIMbAAIAAKRg");
	var mask_graphics_188 = new cjs.Graphics().p("AmNFXIAAqtIMbAAIAAKtg");
	var mask_graphics_189 = new cjs.Graphics().p("AmNFkIAArHIMbAAIAALHg");
	var mask_graphics_190 = new cjs.Graphics().p("AmNFyIAArjIMbAAIAALjg");
	var mask_graphics_191 = new cjs.Graphics().p("AmNGAIAAr/IMbAAIAAL/g");
	var mask_graphics_192 = new cjs.Graphics().p("AmNGOIAAsbIMbAAIAAMbg");
	var mask_graphics_193 = new cjs.Graphics().p("AmNGcIAAs3IMbAAIAAM3g");
	var mask_graphics_194 = new cjs.Graphics().p("AOYY6IAAtVIMeAAIAANVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:303.8,y:235.9}).wait(101).to({graphics:mask_graphics_101,x:303.8,y:235.9}).wait(1).to({graphics:mask_graphics_102,x:303.8,y:237.6}).wait(1).to({graphics:mask_graphics_103,x:303.8,y:239.2}).wait(1).to({graphics:mask_graphics_104,x:303.8,y:240.9}).wait(1).to({graphics:mask_graphics_105,x:303.8,y:242.5}).wait(1).to({graphics:mask_graphics_106,x:303.8,y:244.2}).wait(1).to({graphics:mask_graphics_107,x:303.8,y:245.9}).wait(1).to({graphics:mask_graphics_108,x:303.8,y:247.5}).wait(1).to({graphics:mask_graphics_109,x:303.8,y:249.2}).wait(1).to({graphics:mask_graphics_110,x:303.8,y:250.8}).wait(1).to({graphics:mask_graphics_111,x:303.8,y:252.5}).wait(1).to({graphics:mask_graphics_112,x:303.8,y:254.1}).wait(1).to({graphics:mask_graphics_113,x:303.8,y:255.8}).wait(1).to({graphics:mask_graphics_114,x:303.8,y:257.5}).wait(1).to({graphics:mask_graphics_115,x:303.8,y:259.1}).wait(1).to({graphics:mask_graphics_116,x:171.8,y:144}).wait(67).to({graphics:mask_graphics_183,x:171.8,y:144}).wait(1).to({graphics:mask_graphics_184,x:303.8,y:262.2}).wait(1).to({graphics:mask_graphics_185,x:303.8,y:263.6}).wait(1).to({graphics:mask_graphics_186,x:303.8,y:265}).wait(1).to({graphics:mask_graphics_187,x:303.8,y:266.4}).wait(1).to({graphics:mask_graphics_188,x:303.8,y:267.8}).wait(1).to({graphics:mask_graphics_189,x:303.8,y:269.2}).wait(1).to({graphics:mask_graphics_190,x:303.8,y:270.6}).wait(1).to({graphics:mask_graphics_191,x:303.8,y:272}).wait(1).to({graphics:mask_graphics_192,x:303.8,y:273.5}).wait(1).to({graphics:mask_graphics_193,x:303.8,y:274.9}).wait(1).to({graphics:mask_graphics_194,x:171.8,y:159.5}).wait(89));

	// Formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(313.1,283.5,0.207,1);

	this.text = new cjs.Text("5", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(304.2,283.1+incremento);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(304.3,252.6+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(265.7,267.7+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]}).wait(283));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AhuZAIAAr0IB7AAIAAL0g");
	var mask_1_graphics_1 = new cjs.Graphics().p("AhkF5IAAryIDJAAIAALyg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AiMF5IAAryIEZAAIAALyg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AizF5IAAryIFnAAIAALyg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AjaF5IAAryIG1AAIAALyg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AkBF5IAAryIIDAAIAALyg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AkpF5IAAryIJTAAIAALyg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AlQF5IAAryIKhAAIAALyg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Al3F5IAAryILvAAIAALyg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AmeF5IAAryIM9AAIAALyg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AnGF5IAAryIONAAIAALyg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AntF5IAAryIPbAAIAALyg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AoUF5IAAryIQpAAIAALyg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Ao7F5IAAryIR3AAIAALyg");
	var mask_1_graphics_14 = new cjs.Graphics().p("ApjF5IAAryITHAAIAALyg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AqKF5IAAryIUVAAIAALyg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AqxF5IAAryIVjAAIAALyg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArZF5IAAryIWyAAIAALyg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AsAF5IAAryIYBAAIAALyg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AsnF5IAAryIZPAAIAALyg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AtOF5IAAryIadAAIAALyg");
	var mask_1_graphics_21 = new cjs.Graphics().p("At2F5IAAryIbtAAIAALyg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AudF5IAAryIc7AAIAALyg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AvEF5IAAryIeJAAIAALyg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AvrF5IAAryIfXAAIAALyg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AwTF5IAAryMAgnAAAIAALyg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aw6F5IAAryMAh1AAAIAALyg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AxhF5IAAryMAjDAAAIAALyg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AyIF5IAAryMAkRAAAIAALyg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AywF5IAAryMAlhAAAIAALyg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AzXF5IAAryMAmvAAAIAALyg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Az+F5IAAryMAn9AAAIAALyg");
	var mask_1_graphics_32 = new cjs.Graphics().p("A0lF5IAAryMApLAAAIAALyg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A1NF5IAAryMAqbAAAIAALyg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A10ZAIAAr0MArpAAAIAAL0g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-11,y:160.1}).wait(1).to({graphics:mask_1_graphics_1,x:-11.8,y:282.4}).wait(1).to({graphics:mask_1_graphics_2,x:-7.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_3,x:-3.5,y:282.4}).wait(1).to({graphics:mask_1_graphics_4,x:0.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_5,x:4.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_6,x:8.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_7,x:13,y:282.4}).wait(1).to({graphics:mask_1_graphics_8,x:17.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_9,x:21.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_10,x:25.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_11,x:29.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_12,x:33.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_13,x:37.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_14,x:42,y:282.4}).wait(1).to({graphics:mask_1_graphics_15,x:46.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_16,x:50.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_17,x:54.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_18,x:58.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_19,x:62.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_20,x:66.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_21,x:71,y:282.4}).wait(1).to({graphics:mask_1_graphics_22,x:75.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_23,x:79.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_24,x:83.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_25,x:87.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_26,x:91.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_27,x:95.9,y:282.4}).wait(1).to({graphics:mask_1_graphics_28,x:100,y:282.4}).wait(1).to({graphics:mask_1_graphics_29,x:104.1,y:282.4}).wait(1).to({graphics:mask_1_graphics_30,x:108.3,y:282.4}).wait(1).to({graphics:mask_1_graphics_31,x:112.4,y:282.4}).wait(1).to({graphics:mask_1_graphics_32,x:116.6,y:282.4}).wait(1).to({graphics:mask_1_graphics_33,x:120.7,y:282.4}).wait(1).to({graphics:mask_1_graphics_34,x:124.8,y:160.1}).wait(249));

	// Formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(168.7,283.5);

this.mc_f1_02b = new cjs.Text(txt['mc_f1_02'], "20px Verdana","#00FF00");
	this.mc_f1_02b.textAlign = "center";
	this.mc_f1_02b.lineHeight = 20;
	this.mc_f1_02b.lineWidth = 155;
	this.mc_f1_02b.alpha= 0;
	this.mc_f1_02b.setTransform(166.7,282.3+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_02b).wait(140).to({alpha: 1}, 10).wait(80).to({alpha: 0}, 10).wait(140));
         this.mc_f1_01b = new cjs.Text(txt['mc_f1_01'], "20px Verdana","#00FF00");
	this.mc_f1_01b.textAlign = "center";
	this.mc_f1_01b.lineHeight = 20;
	this.mc_f1_01b.lineWidth = 155;
	this.mc_f1_01b.alpha= 0;
	this.mc_f1_01b.setTransform(166.7,252.6+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_01b).wait(70).to({alpha: 1}, 10).wait(60).to({alpha: 0}, 10).wait(140));
	this.mc_f2_02 = new cjs.Text(txt['mc_f2_02'], "20px Verdana");
	this.mc_f2_02.textAlign = "center";
	this.mc_f2_02.lineHeight = 20;
	this.mc_f2_02.lineWidth = 155;
	this.mc_f2_02.setTransform(166.7,282.3+incremento);

	this.mc_f2_01 = new cjs.Text(txt['mc_f2_01'], "20px Verdana");
	this.mc_f2_01.textAlign = "center";
	this.mc_f2_01.lineHeight = 20;
	this.mc_f2_01.lineWidth = 155;
	this.mc_f2_01.setTransform(166.7,252.6+incremento);

	this.text_3 = new cjs.Text("sen α =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 88;
	this.text_3.setTransform(-6.9,267.7+incremento);

	this.shape_1.mask = this.mc_f2_02.mask = this.mc_f2_01.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.mc_f2_01},{t:this.mc_f2_02},{t:this.shape_1}]}).to({state:[{t:this.mc_f2_01},{t:this.mc_f2_02},{t:this.shape_1},{t:this.text_3}]},68).to({state:[{t:this.mc_f2_01},{t:this.mc_f2_02},{t:this.shape_1},{t:this.text_3}]},80).to({state:[{t:this.mc_f2_01},{t:this.mc_f2_02},{t:this.shape_1},{t:this.text_3}]},75).wait(60));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuRIAAcj");
	this.shape_2.setTransform(306.8,91.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AX5uRMgvxAcj");
	this.shape_3.setTransform(154.6,91.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},68).to({state:[{t:this.shape_3}]},80).to({state:[]},75).wait(60));

	// mc_f2_01
	this.instance_1 = new lib.mc_f2_01();
	this.instance_1.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:162,x:165.1},0).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.9,0,335.2,314.1);


(lib.mc_f2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mc_f2_01
	this.instance = new lib.mc_f2_01();
	this.instance.setTransform(165,106.8,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:162,x:165.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3.1,0,325.1,214.9);


(lib.mc_f1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_280 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_379 = new cjs.Graphics().p("Al/A1IAAhpIL/AAIAABpg");
	var mask_graphics_380 = new cjs.Graphics().p("Al/BBIAAiBIL/AAIAACBg");
	var mask_graphics_381 = new cjs.Graphics().p("Al/BNIAAiZIL/AAIAACZg");
	var mask_graphics_382 = new cjs.Graphics().p("Al/BZIAAixIL/AAIAACxg");
	var mask_graphics_383 = new cjs.Graphics().p("Al/BmIAAjLIL/AAIAADLg");
	var mask_graphics_384 = new cjs.Graphics().p("Al/ByIAAjjIL/AAIAADjg");
	var mask_graphics_385 = new cjs.Graphics().p("Al/B+IAAj7IL/AAIAAD7g");
	var mask_graphics_386 = new cjs.Graphics().p("Al/CKIAAkTIL/AAIAAETg");
	var mask_graphics_387 = new cjs.Graphics().p("Al/CWIAAkrIL/AAIAAErg");
	var mask_graphics_388 = new cjs.Graphics().p("Al/CiIAAlDIL/AAIAAFDg");
	var mask_graphics_389 = new cjs.Graphics().p("Al/CvIAAldIL/AAIAAFdg");
	var mask_graphics_390 = new cjs.Graphics().p("Al/C7IAAl1IL/AAIAAF1g");
	var mask_graphics_391 = new cjs.Graphics().p("Al/DHIAAmNIL/AAIAAGNg");
	var mask_graphics_392 = new cjs.Graphics().p("Al/DTIAAmlIL/AAIAAGlg");
	var mask_graphics_393 = new cjs.Graphics().p("Al/DfIAAm9IL/AAIAAG9g");
	var mask_graphics_394 = new cjs.Graphics().p("Al/DsIAAnXIL/AAIAAHXg");
	var mask_graphics_395 = new cjs.Graphics().p("Al/D4IAAnvIL/AAIAAHvg");
	var mask_graphics_396 = new cjs.Graphics().p("EAtBAVeIAAoJIMBAAIAAIJg");
	var mask_graphics_467 = new cjs.Graphics().p("EAtBAVeIAAoJIMBAAIAAIJg");
	var mask_graphics_468 = new cjs.Graphics().p("Al/EPIAAodIL/AAIAAIdg");
	var mask_graphics_469 = new cjs.Graphics().p("Al/EbIAAo1IL/AAIAAI1g");
	var mask_graphics_470 = new cjs.Graphics().p("Al/EmIAApLIL/AAIAAJLg");
	var mask_graphics_471 = new cjs.Graphics().p("Al/ExIAAphIL/AAIAAJhg");
	var mask_graphics_472 = new cjs.Graphics().p("Al/E9IAAp5IL/AAIAAJ5g");
	var mask_graphics_473 = new cjs.Graphics().p("Al/FIIAAqPIL/AAIAAKPg");
	var mask_graphics_474 = new cjs.Graphics().p("Al/FTIAAqlIL/AAIAAKlg");
	var mask_graphics_475 = new cjs.Graphics().p("Al/FfIAAq9IL/AAIAAK9g");
	var mask_graphics_476 = new cjs.Graphics().p("Al/FqIAArTIL/AAIAALTg");
	var mask_graphics_477 = new cjs.Graphics().p("Al/F1IAArpIL/AAIAALpg");
	var mask_graphics_478 = new cjs.Graphics().p("EAtBAXbIAAsDIMBAAIAAMDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_graphics_280,x:691.6,y:228.2}).wait(99).to({graphics:mask_graphics_379,x:691.6,y:228.2}).wait(1).to({graphics:mask_graphics_380,x:691.6,y:229.4}).wait(1).to({graphics:mask_graphics_381,x:691.6,y:230.7}).wait(1).to({graphics:mask_graphics_382,x:691.6,y:231.9}).wait(1).to({graphics:mask_graphics_383,x:691.6,y:233.1}).wait(1).to({graphics:mask_graphics_384,x:691.6,y:234.3}).wait(1).to({graphics:mask_graphics_385,x:691.6,y:235.5}).wait(1).to({graphics:mask_graphics_386,x:691.6,y:236.8}).wait(1).to({graphics:mask_graphics_387,x:691.6,y:238}).wait(1).to({graphics:mask_graphics_388,x:691.6,y:239.2}).wait(1).to({graphics:mask_graphics_389,x:691.6,y:240.4}).wait(1).to({graphics:mask_graphics_390,x:691.6,y:241.6}).wait(1).to({graphics:mask_graphics_391,x:691.6,y:242.9}).wait(1).to({graphics:mask_graphics_392,x:691.6,y:244.1}).wait(1).to({graphics:mask_graphics_393,x:691.6,y:245.3}).wait(1).to({graphics:mask_graphics_394,x:691.6,y:246.5}).wait(1).to({graphics:mask_graphics_395,x:691.6,y:247.7}).wait(1).to({graphics:mask_graphics_396,x:365,y:137.5}).wait(71).to({graphics:mask_graphics_467,x:365,y:137.5}).wait(1).to({graphics:mask_graphics_468,x:691.6,y:250.1}).wait(1).to({graphics:mask_graphics_469,x:691.6,y:251.2}).wait(1).to({graphics:mask_graphics_470,x:691.6,y:252.3}).wait(1).to({graphics:mask_graphics_471,x:691.6,y:253.5}).wait(1).to({graphics:mask_graphics_472,x:691.6,y:254.6}).wait(1).to({graphics:mask_graphics_473,x:691.6,y:255.7}).wait(1).to({graphics:mask_graphics_474,x:691.6,y:256.9}).wait(1).to({graphics:mask_graphics_475,x:691.6,y:258}).wait(1).to({graphics:mask_graphics_476,x:691.6,y:259.1}).wait(1).to({graphics:mask_graphics_477,x:691.6,y:260.2}).wait(1).to({graphics:mask_graphics_478,x:365,y:149.9}).wait(65));

	// formula_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape.setTransform(701.9,267.5,0.207,1);

	this.text = new cjs.Text("a", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(693,266.4+incremento);

	this.text_1 = new cjs.Text("c", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 14;
	this.text_1.setTransform(693.1,236.7+incremento);

	this.text_2 = new cjs.Text("=", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 16;
	this.text_2.setTransform(654.5,251.8+incremento);

	this.shape.mask = this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape}]},280).wait(263));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_280 = new cjs.Graphics().p("AbiXgIAAq3ICdAAIAAK3g");
	var mask_1_graphics_281 = new cjs.Graphics().p("AhzFbIAAq1IDnAAIAAK1g");
	var mask_1_graphics_282 = new cjs.Graphics().p("AiYFbIAAq1IExAAIAAK1g");
	var mask_1_graphics_283 = new cjs.Graphics().p("Ai+FbIAAq1IF9AAIAAK1g");
	var mask_1_graphics_284 = new cjs.Graphics().p("AjkFbIAAq1IHJAAIAAK1g");
	var mask_1_graphics_285 = new cjs.Graphics().p("AkKFbIAAq1IIVAAIAAK1g");
	var mask_1_graphics_286 = new cjs.Graphics().p("AkvFbIAAq1IJfAAIAAK1g");
	var mask_1_graphics_287 = new cjs.Graphics().p("AlVFbIAAq1IKrAAIAAK1g");
	var mask_1_graphics_288 = new cjs.Graphics().p("Al7FbIAAq1IL3AAIAAK1g");
	var mask_1_graphics_289 = new cjs.Graphics().p("AmhFbIAAq1INDAAIAAK1g");
	var mask_1_graphics_290 = new cjs.Graphics().p("AnGFbIAAq1IONAAIAAK1g");
	var mask_1_graphics_291 = new cjs.Graphics().p("AnsFbIAAq1IPZAAIAAK1g");
	var mask_1_graphics_292 = new cjs.Graphics().p("AoSFbIAAq1IQlAAIAAK1g");
	var mask_1_graphics_293 = new cjs.Graphics().p("Ao4FbIAAq1IRxAAIAAK1g");
	var mask_1_graphics_294 = new cjs.Graphics().p("ApdFbIAAq1IS7AAIAAK1g");
	var mask_1_graphics_295 = new cjs.Graphics().p("AqDFbIAAq1IUHAAIAAK1g");
	var mask_1_graphics_296 = new cjs.Graphics().p("AqpFbIAAq1IVTAAIAAK1g");
	var mask_1_graphics_297 = new cjs.Graphics().p("ArPFbIAAq1IWfAAIAAK1g");
	var mask_1_graphics_298 = new cjs.Graphics().p("Ar0FbIAAq1IXpAAIAAK1g");
	var mask_1_graphics_299 = new cjs.Graphics().p("AsaFbIAAq1IY1AAIAAK1g");
	var mask_1_graphics_300 = new cjs.Graphics().p("AtAFbIAAq1IaBAAIAAK1g");
	var mask_1_graphics_301 = new cjs.Graphics().p("AtmFbIAAq1IbNAAIAAK1g");
	var mask_1_graphics_302 = new cjs.Graphics().p("AuLFbIAAq1IcXAAIAAK1g");
	var mask_1_graphics_303 = new cjs.Graphics().p("AuxFbIAAq1IdjAAIAAK1g");
	var mask_1_graphics_304 = new cjs.Graphics().p("AvXFbIAAq1IevAAIAAK1g");
	var mask_1_graphics_305 = new cjs.Graphics().p("Av9FbIAAq1If7AAIAAK1g");
	var mask_1_graphics_306 = new cjs.Graphics().p("AwiFbIAAq1MAhFAAAIAAK1g");
	var mask_1_graphics_307 = new cjs.Graphics().p("AxIFbIAAq1MAiRAAAIAAK1g");
	var mask_1_graphics_308 = new cjs.Graphics().p("AxuFbIAAq1MAjdAAAIAAK1g");
	var mask_1_graphics_309 = new cjs.Graphics().p("AyUFbIAAq1MAkpAAAIAAK1g");
	var mask_1_graphics_310 = new cjs.Graphics().p("Ay5FbIAAq1MAlzAAAIAAK1g");
	var mask_1_graphics_311 = new cjs.Graphics().p("AzfFbIAAq1MAm/AAAIAAK1g");
	var mask_1_graphics_312 = new cjs.Graphics().p("A0FFbIAAq1MAoLAAAIAAK1g");
	var mask_1_graphics_313 = new cjs.Graphics().p("A0rFbIAAq1MApXAAAIAAK1g");
	var mask_1_graphics_314 = new cjs.Graphics().p("A1QFbIAAq1MAqhAAAIAAK1g");
	var mask_1_graphics_315 = new cjs.Graphics().p("AHNXgIAAq3MArvAAAIAAK3g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(280).to({graphics:mask_1_graphics_280,x:192,y:150.5}).wait(1).to({graphics:mask_1_graphics_281,x:379.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_282,x:383.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_283,x:387.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_284,x:391.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_285,x:395.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_286,x:399.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_287,x:403.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_288,x:407.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_289,x:411,y:266.1}).wait(1).to({graphics:mask_1_graphics_290,x:414.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_291,x:418.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_292,x:422.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_293,x:426.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_294,x:430.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_295,x:434.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_296,x:438.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_297,x:442.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_298,x:446,y:266.1}).wait(1).to({graphics:mask_1_graphics_299,x:449.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_300,x:453.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_301,x:457.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_302,x:461.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_303,x:465.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_304,x:469.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_305,x:473.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_306,x:477.2,y:266.1}).wait(1).to({graphics:mask_1_graphics_307,x:481,y:266.1}).wait(1).to({graphics:mask_1_graphics_308,x:484.9,y:266.1}).wait(1).to({graphics:mask_1_graphics_309,x:488.8,y:266.1}).wait(1).to({graphics:mask_1_graphics_310,x:492.7,y:266.1}).wait(1).to({graphics:mask_1_graphics_311,x:496.6,y:266.1}).wait(1).to({graphics:mask_1_graphics_312,x:500.5,y:266.1}).wait(1).to({graphics:mask_1_graphics_313,x:504.4,y:266.1}).wait(1).to({graphics:mask_1_graphics_314,x:508.3,y:266.1}).wait(1).to({graphics:mask_1_graphics_315,x:326,y:150.5}).wait(228));

this.mc_f1_03b = new cjs.Text(txt['mc_f1_03'], "20px Verdana","#00FF00");
	this.mc_f1_03b.textAlign = "center";
	this.mc_f1_03b.lineHeight = 20;
	this.mc_f1_03b.lineWidth = 155;
	this.mc_f1_03b.alpha= 0;
	this.mc_f1_03b.setTransform(555.5,236.7+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_03b).wait(360).to({alpha: 1}, 10).wait(60).to({alpha: 0}, 10).wait(140));
         this.mc_f1_04b = new cjs.Text(txt['mc_f1_04'], "20px Verdana","#00FF00");
	this.mc_f1_04b.textAlign = "center";
	this.mc_f1_04b.lineHeight = 20;
	this.mc_f1_04b.lineWidth = 155;
	this.mc_f1_04b.alpha= 0;
	this.mc_f1_04b.setTransform(555.5,266.4+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_04b).wait(420).to({alpha: 1}, 10).wait(60).to({alpha: 0}, 10).wait(140));
         
	// formula_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_1.setTransform(557.5,267.5);

	this.mc_f1_04 = new cjs.Text(txt['mc_f1_04'], "20px Verdana");
	this.mc_f1_04.textAlign = "center";
	this.mc_f1_04.lineHeight = 20;
	this.mc_f1_04.lineWidth = 155;
	this.mc_f1_04.setTransform(555.5,266.4+incremento);

	this.mc_f1_03 = new cjs.Text(txt['mc_f1_03'], "20px Verdana");
	this.mc_f1_03.textAlign = "center";
	this.mc_f1_03.lineHeight = 20;
	this.mc_f1_03.lineWidth = 155;
	this.mc_f1_03.setTransform(555.5,236.7+incremento);

	this.text_3 = new cjs.Text("sen ß =", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 88;
	this.text_3.setTransform(382.8,251.8+incremento);

	this.shape_1.mask = this.mc_f1_04.mask = this.mc_f1_03.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.mc_f1_03},{t:this.mc_f1_04},{t:this.shape_1}]},280).to({state:[{t:this.mc_f1_03},{t:this.mc_f1_04},{t:this.shape_1},{t:this.text_3}]},74).to({state:[{t:this.mc_f1_03},{t:this.mc_f1_04},{t:this.shape_1},{t:this.text_3}]},70).to({state:[{t:this.mc_f1_03},{t:this.mc_f1_04},{t:this.shape_1},{t:this.text_3}]},76).wait(43));

	// Resaltados
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00FF00").ss(3,1,1).p("AXvAAMgvdAAA");
	this.shape_2.setTransform(556.3,181.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(3,1,1).p("AX0uSMgvnAcl");
	this.shape_3.setTransform(556.3,90.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},354).to({state:[{t:this.shape_3}]},70).to({state:[]},76).wait(43));

	// triangulo_2
	this.instance = new lib.mc_f1_02();
	this.instance.setTransform(565.9,105.5,1,1,0,0,0,161.9,106.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(263).to({_off:false},0).wait(1).to({alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(263));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_18 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_113 = new cjs.Graphics().p("AmBAiIAAhDIMDAAIAABDg");
	var mask_2_graphics_114 = new cjs.Graphics().p("AmBAuIAAhbIMDAAIAABbg");
	var mask_2_graphics_115 = new cjs.Graphics().p("AmBA5IAAhxIMDAAIAABxg");
	var mask_2_graphics_116 = new cjs.Graphics().p("AmBBFIAAiJIMDAAIAACJg");
	var mask_2_graphics_117 = new cjs.Graphics().p("AmBBQIAAifIMDAAIAACfg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AmBBbIAAi1IMDAAIAAC1g");
	var mask_2_graphics_119 = new cjs.Graphics().p("AmBBnIAAjNIMDAAIAADNg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AmBByIAAjjIMDAAIAADjg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AmBB9IAAj5IMDAAIAAD5g");
	var mask_2_graphics_122 = new cjs.Graphics().p("AmBCJIAAkRIMDAAIAAERg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AmBCUIAAknIMDAAIAAEng");
	var mask_2_graphics_124 = new cjs.Graphics().p("AmBCfIAAk9IMDAAIAAE9g");
	var mask_2_graphics_125 = new cjs.Graphics().p("AmBCrIAAlVIMDAAIAAFVg");
	var mask_2_graphics_126 = new cjs.Graphics().p("AmBC2IAAlrIMDAAIAAFrg");
	var mask_2_graphics_127 = new cjs.Graphics().p("AmBDBIAAmBIMDAAIAAGBg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AmBDNIAAmZIMDAAIAAGZg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AmBDYIAAmvIMDAAIAAGvg");
	var mask_2_graphics_130 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_197 = new cjs.Graphics().p("AOOVRIAAnHIMGAAIAAHHg");
	var mask_2_graphics_198 = new cjs.Graphics().p("AmBDsIAAnXIMDAAIAAHXg");
	var mask_2_graphics_199 = new cjs.Graphics().p("AmBD0IAAnnIMDAAIAAHng");
	var mask_2_graphics_200 = new cjs.Graphics().p("AmBD9IAAn5IMDAAIAAH5g");
	var mask_2_graphics_201 = new cjs.Graphics().p("AmBEFIAAoJIMDAAIAAIJg");
	var mask_2_graphics_202 = new cjs.Graphics().p("AmBEOIAAobIMDAAIAAIbg");
	var mask_2_graphics_203 = new cjs.Graphics().p("AmBEWIAAorIMDAAIAAIrg");
	var mask_2_graphics_204 = new cjs.Graphics().p("AmBEfIAAo9IMDAAIAAI9g");
	var mask_2_graphics_205 = new cjs.Graphics().p("AmBEnIAApNIMDAAIAAJNg");
	var mask_2_graphics_206 = new cjs.Graphics().p("AmBEwIAApfIMDAAIAAJfg");
	var mask_2_graphics_207 = new cjs.Graphics().p("AmBE4IAApvIMDAAIAAJvg");
	var mask_2_graphics_208 = new cjs.Graphics().p("AmBFBIAAqBIMDAAIAAKBg");
	var mask_2_graphics_209 = new cjs.Graphics().p("AmBFJIAAqRIMDAAIAAKRg");
	var mask_2_graphics_210 = new cjs.Graphics().p("AmBFSIAAqjIMDAAIAAKjg");
	var mask_2_graphics_211 = new cjs.Graphics().p("AmBFaIAAqzIMDAAIAAKzg");
	var mask_2_graphics_212 = new cjs.Graphics().p("AmBFjIAArFIMDAAIAALFg");
	var mask_2_graphics_213 = new cjs.Graphics().p("AmBFrIAArVIMDAAIAALVg");
	var mask_2_graphics_214 = new cjs.Graphics().p("AmBF0IAArnIMDAAIAALng");
	var mask_2_graphics_215 = new cjs.Graphics().p("AOOXrIAAr6IMGAAIAAL6g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_2_graphics_18,x:298.2,y:230.4}).wait(95).to({graphics:mask_2_graphics_113,x:298.2,y:230.4}).wait(1).to({graphics:mask_2_graphics_114,x:298.2,y:231.5}).wait(1).to({graphics:mask_2_graphics_115,x:298.2,y:232.6}).wait(1).to({graphics:mask_2_graphics_116,x:298.2,y:233.8}).wait(1).to({graphics:mask_2_graphics_117,x:298.2,y:234.9}).wait(1).to({graphics:mask_2_graphics_118,x:298.2,y:236}).wait(1).to({graphics:mask_2_graphics_119,x:298.2,y:237.2}).wait(1).to({graphics:mask_2_graphics_120,x:298.2,y:238.3}).wait(1).to({graphics:mask_2_graphics_121,x:298.2,y:239.4}).wait(1).to({graphics:mask_2_graphics_122,x:298.2,y:240.6}).wait(1).to({graphics:mask_2_graphics_123,x:298.2,y:241.7}).wait(1).to({graphics:mask_2_graphics_124,x:298.2,y:242.8}).wait(1).to({graphics:mask_2_graphics_125,x:298.2,y:244}).wait(1).to({graphics:mask_2_graphics_126,x:298.2,y:245.1}).wait(1).to({graphics:mask_2_graphics_127,x:298.2,y:246.2}).wait(1).to({graphics:mask_2_graphics_128,x:298.2,y:247.4}).wait(1).to({graphics:mask_2_graphics_129,x:298.2,y:248.5}).wait(1).to({graphics:mask_2_graphics_130,x:168.4,y:136.2}).wait(67).to({graphics:mask_2_graphics_197,x:168.4,y:136.2}).wait(1).to({graphics:mask_2_graphics_198,x:298.2,y:250.5}).wait(1).to({graphics:mask_2_graphics_199,x:298.2,y:251.3}).wait(1).to({graphics:mask_2_graphics_200,x:298.2,y:252.2}).wait(1).to({graphics:mask_2_graphics_201,x:298.2,y:253}).wait(1).to({graphics:mask_2_graphics_202,x:298.2,y:253.9}).wait(1).to({graphics:mask_2_graphics_203,x:298.2,y:254.7}).wait(1).to({graphics:mask_2_graphics_204,x:298.2,y:255.6}).wait(1).to({graphics:mask_2_graphics_205,x:298.2,y:256.4}).wait(1).to({graphics:mask_2_graphics_206,x:298.2,y:257.3}).wait(1).to({graphics:mask_2_graphics_207,x:298.2,y:258.2}).wait(1).to({graphics:mask_2_graphics_208,x:298.2,y:259}).wait(1).to({graphics:mask_2_graphics_209,x:298.2,y:259.9}).wait(1).to({graphics:mask_2_graphics_210,x:298.2,y:260.7}).wait(1).to({graphics:mask_2_graphics_211,x:298.2,y:261.6}).wait(1).to({graphics:mask_2_graphics_212,x:298.2,y:262.4}).wait(1).to({graphics:mask_2_graphics_213,x:298.2,y:263.3}).wait(1).to({graphics:mask_2_graphics_214,x:298.2,y:264.1}).wait(1).to({graphics:mask_2_graphics_215,x:168.4,y:151.5}).wait(328));

	// formula_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_4.setTransform(306,267.2,0.207,1);

	this.text_4 = new cjs.Text("a", "italic 20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 14;
	this.text_4.setTransform(297.1,266.1+incremento);

	this.text_5 = new cjs.Text("b", "italic 20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 14;
	this.text_5.setTransform(297.2,236.4+incremento);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 16;
	this.text_6.setTransform(258.6,251.5+incremento);

	this.shape_4.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_4}]},18).wait(525));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_18 = new cjs.Graphics().p("AgrGUIAAsnIBYAAIAAMng");
	var mask_3_graphics_19 = new cjs.Graphics().p("AhMGUIAAsnICZAAIAAMng");
	var mask_3_graphics_20 = new cjs.Graphics().p("AhtGUIAAsnIDbAAIAAMng");
	var mask_3_graphics_21 = new cjs.Graphics().p("AiOGUIAAsnIEdAAIAAMng");
	var mask_3_graphics_22 = new cjs.Graphics().p("AivGUIAAsnIFfAAIAAMng");
	var mask_3_graphics_23 = new cjs.Graphics().p("AjQGUIAAsnIGhAAIAAMng");
	var mask_3_graphics_24 = new cjs.Graphics().p("AjxGUIAAsnIHjAAIAAMng");
	var mask_3_graphics_25 = new cjs.Graphics().p("AkSGUIAAsnIIlAAIAAMng");
	var mask_3_graphics_26 = new cjs.Graphics().p("AkzGUIAAsnIJnAAIAAMng");
	var mask_3_graphics_27 = new cjs.Graphics().p("AlTGUIAAsnIKnAAIAAMng");
	var mask_3_graphics_28 = new cjs.Graphics().p("Al0GUIAAsnILpAAIAAMng");
	var mask_3_graphics_29 = new cjs.Graphics().p("AmVGUIAAsnIMrAAIAAMng");
	var mask_3_graphics_30 = new cjs.Graphics().p("Am2GUIAAsnINtAAIAAMng");
	var mask_3_graphics_31 = new cjs.Graphics().p("AnXGUIAAsnIOvAAIAAMng");
	var mask_3_graphics_32 = new cjs.Graphics().p("An4GUIAAsnIPxAAIAAMng");
	var mask_3_graphics_33 = new cjs.Graphics().p("AoZGUIAAsnIQzAAIAAMng");
	var mask_3_graphics_34 = new cjs.Graphics().p("Ao6GUIAAsnIR1AAIAAMng");
	var mask_3_graphics_35 = new cjs.Graphics().p("ApbGUIAAsnIS3AAIAAMng");
	var mask_3_graphics_36 = new cjs.Graphics().p("Ap7GUIAAsnIT3AAIAAMng");
	var mask_3_graphics_37 = new cjs.Graphics().p("AqcGUIAAsnIU5AAIAAMng");
	var mask_3_graphics_38 = new cjs.Graphics().p("Aq9GUIAAsnIV7AAIAAMng");
	var mask_3_graphics_39 = new cjs.Graphics().p("AreGUIAAsnIW9AAIAAMng");
	var mask_3_graphics_40 = new cjs.Graphics().p("Ar/GUIAAsnIX/AAIAAMng");
	var mask_3_graphics_41 = new cjs.Graphics().p("AsgGUIAAsnIZBAAIAAMng");
	var mask_3_graphics_42 = new cjs.Graphics().p("AtBGUIAAsnIaDAAIAAMng");
	var mask_3_graphics_43 = new cjs.Graphics().p("AtiGUIAAsnIbFAAIAAMng");
	var mask_3_graphics_44 = new cjs.Graphics().p("AuCGUIAAsnIcFAAIAAMng");
	var mask_3_graphics_45 = new cjs.Graphics().p("AujGUIAAsnIdHAAIAAMng");
	var mask_3_graphics_46 = new cjs.Graphics().p("AvEGUIAAsnIeJAAIAAMng");
	var mask_3_graphics_47 = new cjs.Graphics().p("AvlGUIAAsnIfLAAIAAMng");
	var mask_3_graphics_48 = new cjs.Graphics().p("AwGGUIAAsnMAgNAAAIAAMng");
	var mask_3_graphics_49 = new cjs.Graphics().p("AwnGUIAAsnMAhPAAAIAAMng");
	var mask_3_graphics_50 = new cjs.Graphics().p("AxIGUIAAsnMAiRAAAIAAMng");
	var mask_3_graphics_51 = new cjs.Graphics().p("AxpGUIAAsnMAjTAAAIAAMng");
	var mask_3_graphics_52 = new cjs.Graphics().p("AyKGUIAAsnMAkVAAAIAAMng");
	var mask_3_graphics_53 = new cjs.Graphics().p("AyqGUIAAsnMAlVAAAIAAMng");
	var mask_3_graphics_54 = new cjs.Graphics().p("AzLGUIAAsnMAmXAAAIAAMng");
	var mask_3_graphics_55 = new cjs.Graphics().p("AzsGUIAAsnMAnZAAAIAAMng");
	var mask_3_graphics_56 = new cjs.Graphics().p("A0NGUIAAsnMAobAAAIAAMng");
	var mask_3_graphics_57 = new cjs.Graphics().p("A0uGUIAAsnMApdAAAIAAMng");
	var mask_3_graphics_58 = new cjs.Graphics().p("A1PGUIAAsnMAqfAAAIAAMng");
	var mask_3_graphics_59 = new cjs.Graphics().p("A1wXyIAAsoMArhAAAIAAMog");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_3_graphics_18,x:-17.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_19,x:-14,y:264.2}).wait(1).to({graphics:mask_3_graphics_20,x:-10.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_21,x:-7.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_22,x:-4.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_23,x:-0.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_24,x:2.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_25,x:5.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_26,x:8.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_27,x:12.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_28,x:15.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_29,x:18.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_30,x:22.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_31,x:25.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_32,x:28.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_33,x:31.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_34,x:35.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_35,x:38.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_36,x:41.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_37,x:45.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_38,x:48.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_39,x:51.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_40,x:54.9,y:264.2}).wait(1).to({graphics:mask_3_graphics_41,x:58.2,y:264.2}).wait(1).to({graphics:mask_3_graphics_42,x:61.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_43,x:64.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_44,x:68.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_45,x:71.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_46,x:74.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_47,x:78,y:264.2}).wait(1).to({graphics:mask_3_graphics_48,x:81.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_49,x:84.5,y:264.2}).wait(1).to({graphics:mask_3_graphics_50,x:87.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_51,x:91.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_52,x:94.4,y:264.2}).wait(1).to({graphics:mask_3_graphics_53,x:97.7,y:264.2}).wait(1).to({graphics:mask_3_graphics_54,x:101,y:264.2}).wait(1).to({graphics:mask_3_graphics_55,x:104.3,y:264.2}).wait(1).to({graphics:mask_3_graphics_56,x:107.6,y:264.2}).wait(1).to({graphics:mask_3_graphics_57,x:110.8,y:264.2}).wait(1).to({graphics:mask_3_graphics_58,x:114.1,y:264.2}).wait(1).to({graphics:mask_3_graphics_59,x:117.4,y:152.3}).wait(484));

this.mc_f1_02b = new cjs.Text(txt['mc_f1_02'], "20px Verdana","#00FF00");
	this.mc_f1_02b.textAlign = "center";
	this.mc_f1_02b.lineHeight = 20;
	this.mc_f1_02b.lineWidth = 155;
	this.mc_f1_02b.alpha= 0;
	this.mc_f1_02b.setTransform(159.6,266.1+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_02b).wait(140).to({alpha: 1}, 10).wait(80).to({alpha: 0}, 10).wait(140));
         this.mc_f1_01b = new cjs.Text(txt['mc_f1_01'], "20px Verdana","#00FF00");
	this.mc_f1_01b.textAlign = "center";
	this.mc_f1_01b.lineHeight = 20;
	this.mc_f1_01b.lineWidth = 155;
	this.mc_f1_01b.alpha= 0;
	this.mc_f1_01b.setTransform(159.6,236.4+incremento);
         this.timeline.addTween(cjs.Tween.get(this.mc_f1_01b).wait(70).to({alpha: 1}, 10).wait(60).to({alpha: 0}, 10).wait(140));
	// formula_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AtzAAIbnAA");
	this.shape_5.setTransform(161.6,267.2);

	this.mc_f1_02 = new cjs.Text(txt['mc_f1_02'], "20px Verdana");
	this.mc_f1_02.textAlign = "center";
	this.mc_f1_02.lineHeight = 20;
	this.mc_f1_02.lineWidth = 155;
	this.mc_f1_02.setTransform(159.6,266.1+incremento);

	this.mc_f1_01 = new cjs.Text(txt['mc_f1_01'], "20px Verdana");
	this.mc_f1_01.textAlign = "center";
	this.mc_f1_01.lineHeight = 20;
	this.mc_f1_01.lineWidth = 155;
	this.mc_f1_01.setTransform(159.6,236.4+incremento);

	this.text_7 = new cjs.Text("sen α =", "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 83;
	this.text_7.setTransform(-14,251.5+incremento);

	this.shape_5.mask = this.mc_f1_02.mask = this.mc_f1_01.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.mc_f1_01},{t:this.mc_f1_02},{t:this.shape_5}]},18).to({state:[{t:this.mc_f1_01},{t:this.mc_f1_02},{t:this.shape_5},{t:this.text_7}]},72).to({state:[{t:this.mc_f1_01},{t:this.mc_f1_02},{t:this.shape_5},{t:this.text_7}]},70).to({state:[{t:this.mc_f1_01},{t:this.mc_f1_02},{t:this.shape_5},{t:this.text_7}]},93).wait(290));

	// Resaltados
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#00FF00").ss(3,1,1).p("AAAuMIAAcZ");
	this.shape_6.setTransform(304.5,91.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00FF00").ss(3,1,1).p("AXvuOMgvcAcd");
	this.shape_7.setTransform(152.5,91.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6}]},90).to({state:[{t:this.shape_7}]},70).to({state:[]},93).wait(290));

	// Capa 1
	this.instance_1 = new lib.mc_f1_01();
	this.instance_1.setTransform(161.9,106.8,1,1,0,0,0,161.9,106.8);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({alpha:0.056},0).wait(1).to({alpha:0.111},0).wait(1).to({alpha:0.167},0).wait(1).to({alpha:0.222},0).wait(1).to({alpha:0.278},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.389},0).wait(1).to({alpha:0.444},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.556},0).wait(1).to({alpha:0.611},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.722},0).wait(1).to({alpha:0.778},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:0.889},0).wait(1).to({alpha:0.944},0).wait(1).to({alpha:1},0).wait(525));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,324.9,214.9);


(lib.mc_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txt
	this.instance = new lib.mc_p2_01();
	this.instance.setTransform(395.3,163.4,1,1,0,0,0,394.7,30.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(745).to({_off:false},0).wait(1).to({alpha:0.043},0).wait(1).to({alpha:0.087},0).wait(1).to({alpha:0.13},0).wait(1).to({alpha:0.174},0).wait(1).to({alpha:0.217},0).wait(1).to({alpha:0.261},0).wait(1).to({alpha:0.304},0).wait(1).to({alpha:0.348},0).wait(1).to({alpha:0.391},0).wait(1).to({alpha:0.435},0).wait(1).to({alpha:0.478},0).wait(1).to({alpha:0.522},0).wait(1).to({alpha:0.565},0).wait(1).to({alpha:0.609},0).wait(1).to({alpha:0.652},0).wait(1).to({alpha:0.696},0).wait(1).to({alpha:0.739},0).wait(1).to({alpha:0.783},0).wait(1).to({alpha:0.826},0).wait(1).to({alpha:0.87},0).wait(1).to({alpha:0.913},0).wait(1).to({alpha:0.957},0).wait(1).to({alpha:1},0).wait(56));

	// Resaltados_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#B30218").ss(3,1,1).p("AI1AAIxpAA");
	this.shape.setTransform(59.4,55.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#B30218").ss(3,1,1).p("AAAlSIAAKl");
	this.shape_1.setTransform(115.7,21.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#B30218").ss(3,1,1).p("ARdAAMgi5AAA");
	this.shape_2.setTransform(114.5,55.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#B30218").ss(3,1,1).p("AAAqeIAAU9");
	this.shape_3.setTransform(226.3,-11.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#B30218").ss(3,1,1).p("AXvAAMgvdAAA");
	this.shape_4.setTransform(154.7,55.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#B30218").ss(3,1,1).p("AAAuOIAAcd");
	this.shape_5.setTransform(306.9,-35.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},527).to({state:[{t:this.shape_3},{t:this.shape_2}]},66).to({state:[{t:this.shape_5},{t:this.shape_4}]},78).to({state:[]},49).wait(104));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_495 = new cjs.Graphics().p("Ag6GXIAAstIB1AAIAAMtg");
	var mask_graphics_496 = new cjs.Graphics().p("AhAGXIAAstICBAAIAAMtg");
	var mask_graphics_497 = new cjs.Graphics().p("AhGGXIAAstICNAAIAAMtg");
	var mask_graphics_498 = new cjs.Graphics().p("AhMGXIAAstICZAAIAAMtg");
	var mask_graphics_499 = new cjs.Graphics().p("AhSGXIAAstIClAAIAAMtg");
	var mask_graphics_500 = new cjs.Graphics().p("AhYGXIAAstICxAAIAAMtg");
	var mask_graphics_501 = new cjs.Graphics().p("AheGXIAAstIC9AAIAAMtg");
	var mask_graphics_502 = new cjs.Graphics().p("AhkGXIAAstIDJAAIAAMtg");
	var mask_graphics_503 = new cjs.Graphics().p("AhrGXIAAstIDXAAIAAMtg");
	var mask_graphics_504 = new cjs.Graphics().p("AhxGXIAAstIDjAAIAAMtg");
	var mask_graphics_505 = new cjs.Graphics().p("Ah3GXIAAstIDvAAIAAMtg");
	var mask_graphics_506 = new cjs.Graphics().p("Ah9GXIAAstID7AAIAAMtg");
	var mask_graphics_507 = new cjs.Graphics().p("AiDGXIAAstIEHAAIAAMtg");
	var mask_graphics_508 = new cjs.Graphics().p("AiJGXIAAstIETAAIAAMtg");
	var mask_graphics_509 = new cjs.Graphics().p("AiPGXIAAstIEfAAIAAMtg");
	var mask_graphics_510 = new cjs.Graphics().p("AiVGXIAAstIErAAIAAMtg");
	var mask_graphics_511 = new cjs.Graphics().p("AibGXIAAstIE3AAIAAMtg");
	var mask_graphics_512 = new cjs.Graphics().p("AiiGXIAAstIFFAAIAAMtg");
	var mask_graphics_513 = new cjs.Graphics().p("AioGXIAAstIFRAAIAAMtg");
	var mask_graphics_514 = new cjs.Graphics().p("AiuGXIAAstIFdAAIAAMtg");
	var mask_graphics_515 = new cjs.Graphics().p("Ai0GXIAAstIFpAAIAAMtg");
	var mask_graphics_516 = new cjs.Graphics().p("Ai6GXIAAstIF1AAIAAMtg");
	var mask_graphics_517 = new cjs.Graphics().p("AjAGXIAAstIGBAAIAAMtg");
	var mask_graphics_518 = new cjs.Graphics().p("AjGGXIAAstIGNAAIAAMtg");
	var mask_graphics_519 = new cjs.Graphics().p("AjMGXIAAstIGZAAIAAMtg");
	var mask_graphics_520 = new cjs.Graphics().p("AjSGXIAAstIGlAAIAAMtg");
	var mask_graphics_521 = new cjs.Graphics().p("AjYGXIAAstIGxAAIAAMtg");
	var mask_graphics_522 = new cjs.Graphics().p("AjfGXIAAstIG/AAIAAMtg");
	var mask_graphics_523 = new cjs.Graphics().p("AjlGXIAAstIHLAAIAAMtg");
	var mask_graphics_524 = new cjs.Graphics().p("AjrGXIAAstIHXAAIAAMtg");
	var mask_graphics_525 = new cjs.Graphics().p("AjxGXIAAstIHjAAIAAMtg");
	var mask_graphics_526 = new cjs.Graphics().p("Aj3GXIAAstIHvAAIAAMtg");
	var mask_graphics_527 = new cjs.Graphics().p("Aj9GXIAAstIH7AAIAAMtg");
	var mask_graphics_528 = new cjs.Graphics().p("AkDGXIAAstIIHAAIAAMtg");
	var mask_graphics_529 = new cjs.Graphics().p("AkJGXIAAstIITAAIAAMtg");
	var mask_graphics_530 = new cjs.Graphics().p("AkPGXIAAstIIfAAIAAMtg");
	var mask_graphics_531 = new cjs.Graphics().p("AkWGXIAAstIItAAIAAMtg");
	var mask_graphics_532 = new cjs.Graphics().p("AkcGXIAAstII5AAIAAMtg");
	var mask_graphics_533 = new cjs.Graphics().p("AkiGXIAAstIJFAAIAAMtg");
	var mask_graphics_534 = new cjs.Graphics().p("AkoGXIAAstIJRAAIAAMtg");
	var mask_graphics_535 = new cjs.Graphics().p("AkuGXIAAstIJdAAIAAMtg");
	var mask_graphics_536 = new cjs.Graphics().p("Ak0GXIAAstIJpAAIAAMtg");
	var mask_graphics_537 = new cjs.Graphics().p("Ak6GXIAAstIJ1AAIAAMtg");
	var mask_graphics_538 = new cjs.Graphics().p("AlAGXIAAstIKBAAIAAMtg");
	var mask_graphics_539 = new cjs.Graphics().p("AlGGXIAAstIKNAAIAAMtg");
	var mask_graphics_540 = new cjs.Graphics().p("AlMGXIAAstIKZAAIAAMtg");
	var mask_graphics_541 = new cjs.Graphics().p("AlTGXIAAstIKnAAIAAMtg");
	var mask_graphics_542 = new cjs.Graphics().p("AlZGXIAAstIKzAAIAAMtg");
	var mask_graphics_543 = new cjs.Graphics().p("AlfGXIAAstIK/AAIAAMtg");
	var mask_graphics_544 = new cjs.Graphics().p("AllGXIAAstILLAAIAAMtg");
	var mask_graphics_545 = new cjs.Graphics().p("AlrGXIAAstILXAAIAAMtg");
	var mask_graphics_546 = new cjs.Graphics().p("AlxGXIAAstILjAAIAAMtg");
	var mask_graphics_547 = new cjs.Graphics().p("Al3GXIAAstILvAAIAAMtg");
	var mask_graphics_548 = new cjs.Graphics().p("Al9GXIAAstIL7AAIAAMtg");
	var mask_graphics_549 = new cjs.Graphics().p("AmDGXIAAstIMHAAIAAMtg");
	var mask_graphics_550 = new cjs.Graphics().p("AmKGXIAAstIMVAAIAAMtg");
	var mask_graphics_551 = new cjs.Graphics().p("AmQGXIAAstIMhAAIAAMtg");
	var mask_graphics_552 = new cjs.Graphics().p("AmWGXIAAstIMtAAIAAMtg");
	var mask_graphics_553 = new cjs.Graphics().p("AmcGXIAAstIM5AAIAAMtg");
	var mask_graphics_554 = new cjs.Graphics().p("AmiGXIAAstINFAAIAAMtg");
	var mask_graphics_555 = new cjs.Graphics().p("AmoGXIAAstINRAAIAAMtg");
	var mask_graphics_556 = new cjs.Graphics().p("AmuGXIAAstINdAAIAAMtg");
	var mask_graphics_557 = new cjs.Graphics().p("Am0GXIAAstINpAAIAAMtg");
	var mask_graphics_558 = new cjs.Graphics().p("Am6GXIAAstIN1AAIAAMtg");
	var mask_graphics_559 = new cjs.Graphics().p("AnAGXIAAstIOBAAIAAMtg");
	var mask_graphics_560 = new cjs.Graphics().p("AnHGXIAAstIOPAAIAAMtg");
	var mask_graphics_561 = new cjs.Graphics().p("AnNGXIAAstIObAAIAAMtg");
	var mask_graphics_562 = new cjs.Graphics().p("AnTGXIAAstIOnAAIAAMtg");
	var mask_graphics_563 = new cjs.Graphics().p("AnZGXIAAstIOzAAIAAMtg");
	var mask_graphics_564 = new cjs.Graphics().p("AnfGXIAAstIO/AAIAAMtg");
	var mask_graphics_565 = new cjs.Graphics().p("AnlGXIAAstIPLAAIAAMtg");
	var mask_graphics_566 = new cjs.Graphics().p("AnrGXIAAstIPXAAIAAMtg");
	var mask_graphics_567 = new cjs.Graphics().p("AnxGXIAAstIPjAAIAAMtg");
	var mask_graphics_568 = new cjs.Graphics().p("An3GXIAAstIPvAAIAAMtg");
	var mask_graphics_569 = new cjs.Graphics().p("An+GXIAAstIP9AAIAAMtg");
	var mask_graphics_570 = new cjs.Graphics().p("AoEGXIAAstIQJAAIAAMtg");
	var mask_graphics_571 = new cjs.Graphics().p("AoKGXIAAstIQVAAIAAMtg");
	var mask_graphics_572 = new cjs.Graphics().p("AoQGXIAAstIQhAAIAAMtg");
	var mask_graphics_573 = new cjs.Graphics().p("AoWGXIAAstIQtAAIAAMtg");
	var mask_graphics_574 = new cjs.Graphics().p("AocGXIAAstIQ5AAIAAMtg");
	var mask_graphics_575 = new cjs.Graphics().p("AoiGXIAAstIRFAAIAAMtg");
	var mask_graphics_576 = new cjs.Graphics().p("AooGXIAAstIRRAAIAAMtg");
	var mask_graphics_577 = new cjs.Graphics().p("AouGXIAAstIRdAAIAAMtg");
	var mask_graphics_578 = new cjs.Graphics().p("Ao0GXIAAstIRpAAIAAMtg");
	var mask_graphics_579 = new cjs.Graphics().p("Ao7GXIAAstIR3AAIAAMtg");
	var mask_graphics_580 = new cjs.Graphics().p("ApBGXIAAstISDAAIAAMtg");
	var mask_graphics_581 = new cjs.Graphics().p("ApHGXIAAstISPAAIAAMtg");
	var mask_graphics_582 = new cjs.Graphics().p("ApNGXIAAstISbAAIAAMtg");
	var mask_graphics_583 = new cjs.Graphics().p("ApTGXIAAstISnAAIAAMtg");
	var mask_graphics_584 = new cjs.Graphics().p("ApZGXIAAstISzAAIAAMtg");
	var mask_graphics_585 = new cjs.Graphics().p("ApfGXIAAstIS/AAIAAMtg");
	var mask_graphics_586 = new cjs.Graphics().p("AplGXIAAstITLAAIAAMtg");
	var mask_graphics_587 = new cjs.Graphics().p("AprGXIAAstITXAAIAAMtg");
	var mask_graphics_588 = new cjs.Graphics().p("ApyGXIAAstITlAAIAAMtg");
	var mask_graphics_589 = new cjs.Graphics().p("Ap4GXIAAstITxAAIAAMtg");
	var mask_graphics_590 = new cjs.Graphics().p("Ap+GXIAAstIT9AAIAAMtg");
	var mask_graphics_591 = new cjs.Graphics().p("AqEGXIAAstIUJAAIAAMtg");
	var mask_graphics_592 = new cjs.Graphics().p("AqKGXIAAstIUVAAIAAMtg");
	var mask_graphics_593 = new cjs.Graphics().p("AqQGXIAAstIUhAAIAAMtg");
	var mask_graphics_594 = new cjs.Graphics().p("AqWGXIAAstIUtAAIAAMtg");
	var mask_graphics_595 = new cjs.Graphics().p("AqcGXIAAstIU5AAIAAMtg");
	var mask_graphics_596 = new cjs.Graphics().p("AqiGXIAAstIVFAAIAAMtg");
	var mask_graphics_597 = new cjs.Graphics().p("AqoGXIAAstIVRAAIAAMtg");
	var mask_graphics_598 = new cjs.Graphics().p("AqvGXIAAstIVfAAIAAMtg");
	var mask_graphics_599 = new cjs.Graphics().p("Aq1GXIAAstIVrAAIAAMtg");
	var mask_graphics_600 = new cjs.Graphics().p("Aq7GXIAAstIV3AAIAAMtg");
	var mask_graphics_601 = new cjs.Graphics().p("ArBGXIAAstIWDAAIAAMtg");
	var mask_graphics_602 = new cjs.Graphics().p("ArHGXIAAstIWPAAIAAMtg");
	var mask_graphics_603 = new cjs.Graphics().p("ArNGXIAAstIWbAAIAAMtg");
	var mask_graphics_604 = new cjs.Graphics().p("ArTGXIAAstIWnAAIAAMtg");
	var mask_graphics_605 = new cjs.Graphics().p("ArZGXIAAstIWzAAIAAMtg");
	var mask_graphics_606 = new cjs.Graphics().p("ArfGXIAAstIW/AAIAAMtg");
	var mask_graphics_607 = new cjs.Graphics().p("ArmGXIAAstIXNAAIAAMtg");
	var mask_graphics_608 = new cjs.Graphics().p("ArsGXIAAstIXZAAIAAMtg");
	var mask_graphics_609 = new cjs.Graphics().p("AryGXIAAstIXlAAIAAMtg");
	var mask_graphics_610 = new cjs.Graphics().p("Ar4GXIAAstIXxAAIAAMtg");
	var mask_graphics_611 = new cjs.Graphics().p("Ar+GXIAAstIX9AAIAAMtg");
	var mask_graphics_612 = new cjs.Graphics().p("AsEGXIAAstIYJAAIAAMtg");
	var mask_graphics_613 = new cjs.Graphics().p("AsKGXIAAstIYVAAIAAMtg");
	var mask_graphics_614 = new cjs.Graphics().p("AsQGXIAAstIYhAAIAAMtg");
	var mask_graphics_615 = new cjs.Graphics().p("AsWGXIAAstIYtAAIAAMtg");
	var mask_graphics_616 = new cjs.Graphics().p("AscGXIAAstIY5AAIAAMtg");
	var mask_graphics_617 = new cjs.Graphics().p("AsjGXIAAstIZHAAIAAMtg");
	var mask_graphics_618 = new cjs.Graphics().p("AspGXIAAstIZTAAIAAMtg");
	var mask_graphics_619 = new cjs.Graphics().p("AsvGXIAAstIZfAAIAAMtg");
	var mask_graphics_620 = new cjs.Graphics().p("As1GXIAAstIZrAAIAAMtg");
	var mask_graphics_621 = new cjs.Graphics().p("As7GXIAAstIZ3AAIAAMtg");
	var mask_graphics_622 = new cjs.Graphics().p("AtBGXIAAstIaDAAIAAMtg");
	var mask_graphics_623 = new cjs.Graphics().p("AtHGXIAAstIaPAAIAAMtg");
	var mask_graphics_624 = new cjs.Graphics().p("AtNGXIAAstIabAAIAAMtg");
	var mask_graphics_625 = new cjs.Graphics().p("AtTGXIAAstIanAAIAAMtg");
	var mask_graphics_626 = new cjs.Graphics().p("AtaGXIAAstIa1AAIAAMtg");
	var mask_graphics_627 = new cjs.Graphics().p("AtgGXIAAstIbBAAIAAMtg");
	var mask_graphics_628 = new cjs.Graphics().p("AtmGXIAAstIbNAAIAAMtg");
	var mask_graphics_629 = new cjs.Graphics().p("AtsGXIAAstIbZAAIAAMtg");
	var mask_graphics_630 = new cjs.Graphics().p("AtyGXIAAstIblAAIAAMtg");
	var mask_graphics_631 = new cjs.Graphics().p("At4GXIAAstIbxAAIAAMtg");
	var mask_graphics_632 = new cjs.Graphics().p("At+GXIAAstIb9AAIAAMtg");
	var mask_graphics_633 = new cjs.Graphics().p("AuEGXIAAstIcJAAIAAMtg");
	var mask_graphics_634 = new cjs.Graphics().p("AuKGXIAAstIcVAAIAAMtg");
	var mask_graphics_635 = new cjs.Graphics().p("AuQGXIAAstIchAAIAAMtg");
	var mask_graphics_636 = new cjs.Graphics().p("AuXGXIAAstIcvAAIAAMtg");
	var mask_graphics_637 = new cjs.Graphics().p("AudGXIAAstIc7AAIAAMtg");
	var mask_graphics_638 = new cjs.Graphics().p("AujGXIAAstIdHAAIAAMtg");
	var mask_graphics_639 = new cjs.Graphics().p("AupGXIAAstIdTAAIAAMtg");
	var mask_graphics_640 = new cjs.Graphics().p("AuvGXIAAstIdfAAIAAMtg");
	var mask_graphics_641 = new cjs.Graphics().p("Au1GXIAAstIdrAAIAAMtg");
	var mask_graphics_642 = new cjs.Graphics().p("Au7GXIAAstId3AAIAAMtg");
	var mask_graphics_643 = new cjs.Graphics().p("AvBGXIAAstIeDAAIAAMtg");
	var mask_graphics_644 = new cjs.Graphics().p("AvHGXIAAstIePAAIAAMtg");
	var mask_graphics_645 = new cjs.Graphics().p("AvOGXIAAstIedAAIAAMtg");
	var mask_graphics_646 = new cjs.Graphics().p("AvUGXIAAstIepAAIAAMtg");
	var mask_graphics_647 = new cjs.Graphics().p("AvaGXIAAstIe1AAIAAMtg");
	var mask_graphics_648 = new cjs.Graphics().p("AvgGXIAAstIfBAAIAAMtg");
	var mask_graphics_649 = new cjs.Graphics().p("AvmGXIAAstIfNAAIAAMtg");
	var mask_graphics_650 = new cjs.Graphics().p("AvsGXIAAstIfZAAIAAMtg");
	var mask_graphics_651 = new cjs.Graphics().p("AvyGXIAAstIflAAIAAMtg");
	var mask_graphics_652 = new cjs.Graphics().p("Av4GXIAAstIfxAAIAAMtg");
	var mask_graphics_653 = new cjs.Graphics().p("Av+GXIAAstIf9AAIAAMtg");
	var mask_graphics_654 = new cjs.Graphics().p("AwEGXIAAstMAgJAAAIAAMtg");
	var mask_graphics_655 = new cjs.Graphics().p("AwLGXIAAstMAgXAAAIAAMtg");
	var mask_graphics_656 = new cjs.Graphics().p("AwRGXIAAstMAgjAAAIAAMtg");
	var mask_graphics_657 = new cjs.Graphics().p("AwXGXIAAstMAgvAAAIAAMtg");
	var mask_graphics_658 = new cjs.Graphics().p("AwdGXIAAstMAg7AAAIAAMtg");
	var mask_graphics_659 = new cjs.Graphics().p("AwjGXIAAstMAhHAAAIAAMtg");
	var mask_graphics_660 = new cjs.Graphics().p("AwpGXIAAstMAhTAAAIAAMtg");
	var mask_graphics_661 = new cjs.Graphics().p("AwvGXIAAstMAhfAAAIAAMtg");
	var mask_graphics_662 = new cjs.Graphics().p("Aw1GXIAAstMAhrAAAIAAMtg");
	var mask_graphics_663 = new cjs.Graphics().p("Aw7GXIAAstMAh3AAAIAAMtg");
	var mask_graphics_664 = new cjs.Graphics().p("AxCGXIAAstMAiFAAAIAAMtg");
	var mask_graphics_665 = new cjs.Graphics().p("AxIGXIAAstMAiRAAAIAAMtg");
	var mask_graphics_666 = new cjs.Graphics().p("AxOGXIAAstMAidAAAIAAMtg");
	var mask_graphics_667 = new cjs.Graphics().p("AxUGXIAAstMAipAAAIAAMtg");
	var mask_graphics_668 = new cjs.Graphics().p("AxaGXIAAstMAi1AAAIAAMtg");
	var mask_graphics_669 = new cjs.Graphics().p("AxgGXIAAstMAjBAAAIAAMtg");
	var mask_graphics_670 = new cjs.Graphics().p("AxmGXIAAstMAjNAAAIAAMtg");
	var mask_graphics_671 = new cjs.Graphics().p("AxsGXIAAstMAjZAAAIAAMtg");
	var mask_graphics_672 = new cjs.Graphics().p("AxyGXIAAstMAjlAAAIAAMtg");
	var mask_graphics_673 = new cjs.Graphics().p("Ax4GXIAAstMAjxAAAIAAMtg");
	var mask_graphics_674 = new cjs.Graphics().p("Ax/GXIAAstMAj/AAAIAAMtg");
	var mask_graphics_675 = new cjs.Graphics().p("AyFGXIAAstMAkLAAAIAAMtg");
	var mask_graphics_676 = new cjs.Graphics().p("AyLGXIAAstMAkXAAAIAAMtg");
	var mask_graphics_677 = new cjs.Graphics().p("AyRGXIAAstMAkjAAAIAAMtg");
	var mask_graphics_678 = new cjs.Graphics().p("AyXGXIAAstMAkvAAAIAAMtg");
	var mask_graphics_679 = new cjs.Graphics().p("AydGXIAAstMAk7AAAIAAMtg");
	var mask_graphics_680 = new cjs.Graphics().p("AyjGXIAAstMAlHAAAIAAMtg");
	var mask_graphics_681 = new cjs.Graphics().p("AypGXIAAstMAlTAAAIAAMtg");
	var mask_graphics_682 = new cjs.Graphics().p("AyvGXIAAstMAlfAAAIAAMtg");
	var mask_graphics_683 = new cjs.Graphics().p("Ay2GXIAAstMAltAAAIAAMtg");
	var mask_graphics_684 = new cjs.Graphics().p("Ay8GXIAAstMAl5AAAIAAMtg");
	var mask_graphics_685 = new cjs.Graphics().p("AzCGXIAAstMAmFAAAIAAMtg");
	var mask_graphics_686 = new cjs.Graphics().p("AzIGXIAAstMAmRAAAIAAMtg");
	var mask_graphics_687 = new cjs.Graphics().p("AzOGXIAAstMAmdAAAIAAMtg");
	var mask_graphics_688 = new cjs.Graphics().p("AzUGXIAAstMAmpAAAIAAMtg");
	var mask_graphics_689 = new cjs.Graphics().p("AzaGXIAAstMAm1AAAIAAMtg");
	var mask_graphics_690 = new cjs.Graphics().p("AzgGXIAAstMAnBAAAIAAMtg");
	var mask_graphics_691 = new cjs.Graphics().p("AzmGXIAAstMAnNAAAIAAMtg");
	var mask_graphics_692 = new cjs.Graphics().p("AzsGXIAAstMAnZAAAIAAMtg");
	var mask_graphics_693 = new cjs.Graphics().p("AzzGXIAAstMAnnAAAIAAMtg");
	var mask_graphics_694 = new cjs.Graphics().p("Az5GXIAAstMAnzAAAIAAMtg");
	var mask_graphics_695 = new cjs.Graphics().p("Az/GXIAAstMAn/AAAIAAMtg");
	var mask_graphics_696 = new cjs.Graphics().p("A0FGXIAAstMAoLAAAIAAMtg");
	var mask_graphics_697 = new cjs.Graphics().p("AQHHKIAAstMAoZAAAIAAMtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(495).to({graphics:mask_graphics_495,x:470.8,y:51}).wait(1).to({graphics:mask_graphics_496,x:471.4,y:51}).wait(1).to({graphics:mask_graphics_497,x:472,y:51}).wait(1).to({graphics:mask_graphics_498,x:472.7,y:51}).wait(1).to({graphics:mask_graphics_499,x:473.3,y:51}).wait(1).to({graphics:mask_graphics_500,x:473.9,y:51}).wait(1).to({graphics:mask_graphics_501,x:474.5,y:51}).wait(1).to({graphics:mask_graphics_502,x:475.1,y:51}).wait(1).to({graphics:mask_graphics_503,x:475.7,y:51}).wait(1).to({graphics:mask_graphics_504,x:476.3,y:51}).wait(1).to({graphics:mask_graphics_505,x:476.9,y:51}).wait(1).to({graphics:mask_graphics_506,x:477.5,y:51}).wait(1).to({graphics:mask_graphics_507,x:478.2,y:51}).wait(1).to({graphics:mask_graphics_508,x:478.8,y:51}).wait(1).to({graphics:mask_graphics_509,x:479.4,y:51}).wait(1).to({graphics:mask_graphics_510,x:480,y:51}).wait(1).to({graphics:mask_graphics_511,x:480.6,y:51}).wait(1).to({graphics:mask_graphics_512,x:481.2,y:51}).wait(1).to({graphics:mask_graphics_513,x:481.8,y:51}).wait(1).to({graphics:mask_graphics_514,x:482.4,y:51}).wait(1).to({graphics:mask_graphics_515,x:483,y:51}).wait(1).to({graphics:mask_graphics_516,x:483.6,y:51}).wait(1).to({graphics:mask_graphics_517,x:484.3,y:51}).wait(1).to({graphics:mask_graphics_518,x:484.9,y:51}).wait(1).to({graphics:mask_graphics_519,x:485.5,y:51}).wait(1).to({graphics:mask_graphics_520,x:486.1,y:51}).wait(1).to({graphics:mask_graphics_521,x:486.7,y:51}).wait(1).to({graphics:mask_graphics_522,x:487.3,y:51}).wait(1).to({graphics:mask_graphics_523,x:487.9,y:51}).wait(1).to({graphics:mask_graphics_524,x:488.5,y:51}).wait(1).to({graphics:mask_graphics_525,x:489.1,y:51}).wait(1).to({graphics:mask_graphics_526,x:489.8,y:51}).wait(1).to({graphics:mask_graphics_527,x:490.4,y:51}).wait(1).to({graphics:mask_graphics_528,x:491,y:51}).wait(1).to({graphics:mask_graphics_529,x:491.6,y:51}).wait(1).to({graphics:mask_graphics_530,x:492.2,y:51}).wait(1).to({graphics:mask_graphics_531,x:492.8,y:51}).wait(1).to({graphics:mask_graphics_532,x:493.4,y:51}).wait(1).to({graphics:mask_graphics_533,x:494,y:51}).wait(1).to({graphics:mask_graphics_534,x:494.6,y:51}).wait(1).to({graphics:mask_graphics_535,x:495.2,y:51}).wait(1).to({graphics:mask_graphics_536,x:495.9,y:51}).wait(1).to({graphics:mask_graphics_537,x:496.5,y:51}).wait(1).to({graphics:mask_graphics_538,x:497.1,y:51}).wait(1).to({graphics:mask_graphics_539,x:497.7,y:51}).wait(1).to({graphics:mask_graphics_540,x:498.3,y:51}).wait(1).to({graphics:mask_graphics_541,x:498.9,y:51}).wait(1).to({graphics:mask_graphics_542,x:499.5,y:51}).wait(1).to({graphics:mask_graphics_543,x:500.1,y:51}).wait(1).to({graphics:mask_graphics_544,x:500.7,y:51}).wait(1).to({graphics:mask_graphics_545,x:501.4,y:51}).wait(1).to({graphics:mask_graphics_546,x:502,y:51}).wait(1).to({graphics:mask_graphics_547,x:502.6,y:51}).wait(1).to({graphics:mask_graphics_548,x:503.2,y:51}).wait(1).to({graphics:mask_graphics_549,x:503.8,y:51}).wait(1).to({graphics:mask_graphics_550,x:504.4,y:51}).wait(1).to({graphics:mask_graphics_551,x:505,y:51}).wait(1).to({graphics:mask_graphics_552,x:505.6,y:51}).wait(1).to({graphics:mask_graphics_553,x:506.2,y:51}).wait(1).to({graphics:mask_graphics_554,x:506.8,y:51}).wait(1).to({graphics:mask_graphics_555,x:507.5,y:51}).wait(1).to({graphics:mask_graphics_556,x:508.1,y:51}).wait(1).to({graphics:mask_graphics_557,x:508.7,y:51}).wait(1).to({graphics:mask_graphics_558,x:509.3,y:51}).wait(1).to({graphics:mask_graphics_559,x:509.9,y:51}).wait(1).to({graphics:mask_graphics_560,x:510.5,y:51}).wait(1).to({graphics:mask_graphics_561,x:511.1,y:51}).wait(1).to({graphics:mask_graphics_562,x:511.7,y:51}).wait(1).to({graphics:mask_graphics_563,x:512.3,y:51}).wait(1).to({graphics:mask_graphics_564,x:513,y:51}).wait(1).to({graphics:mask_graphics_565,x:513.6,y:51}).wait(1).to({graphics:mask_graphics_566,x:514.2,y:51}).wait(1).to({graphics:mask_graphics_567,x:514.8,y:51}).wait(1).to({graphics:mask_graphics_568,x:515.4,y:51}).wait(1).to({graphics:mask_graphics_569,x:516,y:51}).wait(1).to({graphics:mask_graphics_570,x:516.6,y:51}).wait(1).to({graphics:mask_graphics_571,x:517.2,y:51}).wait(1).to({graphics:mask_graphics_572,x:517.8,y:51}).wait(1).to({graphics:mask_graphics_573,x:518.4,y:51}).wait(1).to({graphics:mask_graphics_574,x:519.1,y:51}).wait(1).to({graphics:mask_graphics_575,x:519.7,y:51}).wait(1).to({graphics:mask_graphics_576,x:520.3,y:51}).wait(1).to({graphics:mask_graphics_577,x:520.9,y:51}).wait(1).to({graphics:mask_graphics_578,x:521.5,y:51}).wait(1).to({graphics:mask_graphics_579,x:522.1,y:51}).wait(1).to({graphics:mask_graphics_580,x:522.7,y:51}).wait(1).to({graphics:mask_graphics_581,x:523.3,y:51}).wait(1).to({graphics:mask_graphics_582,x:523.9,y:51}).wait(1).to({graphics:mask_graphics_583,x:524.6,y:51}).wait(1).to({graphics:mask_graphics_584,x:525.2,y:51}).wait(1).to({graphics:mask_graphics_585,x:525.8,y:51}).wait(1).to({graphics:mask_graphics_586,x:526.4,y:51}).wait(1).to({graphics:mask_graphics_587,x:527,y:51}).wait(1).to({graphics:mask_graphics_588,x:527.6,y:51}).wait(1).to({graphics:mask_graphics_589,x:528.2,y:51}).wait(1).to({graphics:mask_graphics_590,x:528.8,y:51}).wait(1).to({graphics:mask_graphics_591,x:529.4,y:51}).wait(1).to({graphics:mask_graphics_592,x:530,y:51}).wait(1).to({graphics:mask_graphics_593,x:530.7,y:51}).wait(1).to({graphics:mask_graphics_594,x:531.3,y:51}).wait(1).to({graphics:mask_graphics_595,x:531.9,y:51}).wait(1).to({graphics:mask_graphics_596,x:532.5,y:51}).wait(1).to({graphics:mask_graphics_597,x:533.1,y:51}).wait(1).to({graphics:mask_graphics_598,x:533.7,y:51}).wait(1).to({graphics:mask_graphics_599,x:534.3,y:51}).wait(1).to({graphics:mask_graphics_600,x:534.9,y:51}).wait(1).to({graphics:mask_graphics_601,x:535.5,y:51}).wait(1).to({graphics:mask_graphics_602,x:536.2,y:51}).wait(1).to({graphics:mask_graphics_603,x:536.8,y:51}).wait(1).to({graphics:mask_graphics_604,x:537.4,y:51}).wait(1).to({graphics:mask_graphics_605,x:538,y:51}).wait(1).to({graphics:mask_graphics_606,x:538.6,y:51}).wait(1).to({graphics:mask_graphics_607,x:539.2,y:51}).wait(1).to({graphics:mask_graphics_608,x:539.8,y:51}).wait(1).to({graphics:mask_graphics_609,x:540.4,y:51}).wait(1).to({graphics:mask_graphics_610,x:541,y:51}).wait(1).to({graphics:mask_graphics_611,x:541.6,y:51}).wait(1).to({graphics:mask_graphics_612,x:542.3,y:51}).wait(1).to({graphics:mask_graphics_613,x:542.9,y:51}).wait(1).to({graphics:mask_graphics_614,x:543.5,y:51}).wait(1).to({graphics:mask_graphics_615,x:544.1,y:51}).wait(1).to({graphics:mask_graphics_616,x:544.7,y:51}).wait(1).to({graphics:mask_graphics_617,x:545.3,y:51}).wait(1).to({graphics:mask_graphics_618,x:545.9,y:51}).wait(1).to({graphics:mask_graphics_619,x:546.5,y:51}).wait(1).to({graphics:mask_graphics_620,x:547.1,y:51}).wait(1).to({graphics:mask_graphics_621,x:547.8,y:51}).wait(1).to({graphics:mask_graphics_622,x:548.4,y:51}).wait(1).to({graphics:mask_graphics_623,x:549,y:51}).wait(1).to({graphics:mask_graphics_624,x:549.6,y:51}).wait(1).to({graphics:mask_graphics_625,x:550.2,y:51}).wait(1).to({graphics:mask_graphics_626,x:550.8,y:51}).wait(1).to({graphics:mask_graphics_627,x:551.4,y:51}).wait(1).to({graphics:mask_graphics_628,x:552,y:51}).wait(1).to({graphics:mask_graphics_629,x:552.6,y:51}).wait(1).to({graphics:mask_graphics_630,x:553.2,y:51}).wait(1).to({graphics:mask_graphics_631,x:553.9,y:51}).wait(1).to({graphics:mask_graphics_632,x:554.5,y:51}).wait(1).to({graphics:mask_graphics_633,x:555.1,y:51}).wait(1).to({graphics:mask_graphics_634,x:555.7,y:51}).wait(1).to({graphics:mask_graphics_635,x:556.3,y:51}).wait(1).to({graphics:mask_graphics_636,x:556.9,y:51}).wait(1).to({graphics:mask_graphics_637,x:557.5,y:51}).wait(1).to({graphics:mask_graphics_638,x:558.1,y:51}).wait(1).to({graphics:mask_graphics_639,x:558.7,y:51}).wait(1).to({graphics:mask_graphics_640,x:559.4,y:51}).wait(1).to({graphics:mask_graphics_641,x:560,y:51}).wait(1).to({graphics:mask_graphics_642,x:560.6,y:51}).wait(1).to({graphics:mask_graphics_643,x:561.2,y:51}).wait(1).to({graphics:mask_graphics_644,x:561.8,y:51}).wait(1).to({graphics:mask_graphics_645,x:562.4,y:51}).wait(1).to({graphics:mask_graphics_646,x:563,y:51}).wait(1).to({graphics:mask_graphics_647,x:563.6,y:51}).wait(1).to({graphics:mask_graphics_648,x:564.2,y:51}).wait(1).to({graphics:mask_graphics_649,x:564.8,y:51}).wait(1).to({graphics:mask_graphics_650,x:565.5,y:51}).wait(1).to({graphics:mask_graphics_651,x:566.1,y:51}).wait(1).to({graphics:mask_graphics_652,x:566.7,y:51}).wait(1).to({graphics:mask_graphics_653,x:567.3,y:51}).wait(1).to({graphics:mask_graphics_654,x:567.9,y:51}).wait(1).to({graphics:mask_graphics_655,x:568.5,y:51}).wait(1).to({graphics:mask_graphics_656,x:569.1,y:51}).wait(1).to({graphics:mask_graphics_657,x:569.7,y:51}).wait(1).to({graphics:mask_graphics_658,x:570.3,y:51}).wait(1).to({graphics:mask_graphics_659,x:571,y:51}).wait(1).to({graphics:mask_graphics_660,x:571.6,y:51}).wait(1).to({graphics:mask_graphics_661,x:572.2,y:51}).wait(1).to({graphics:mask_graphics_662,x:572.8,y:51}).wait(1).to({graphics:mask_graphics_663,x:573.4,y:51}).wait(1).to({graphics:mask_graphics_664,x:574,y:51}).wait(1).to({graphics:mask_graphics_665,x:574.6,y:51}).wait(1).to({graphics:mask_graphics_666,x:575.2,y:51}).wait(1).to({graphics:mask_graphics_667,x:575.8,y:51}).wait(1).to({graphics:mask_graphics_668,x:576.4,y:51}).wait(1).to({graphics:mask_graphics_669,x:577.1,y:51}).wait(1).to({graphics:mask_graphics_670,x:577.7,y:51}).wait(1).to({graphics:mask_graphics_671,x:578.3,y:51}).wait(1).to({graphics:mask_graphics_672,x:578.9,y:51}).wait(1).to({graphics:mask_graphics_673,x:579.5,y:51}).wait(1).to({graphics:mask_graphics_674,x:580.1,y:51}).wait(1).to({graphics:mask_graphics_675,x:580.7,y:51}).wait(1).to({graphics:mask_graphics_676,x:581.3,y:51}).wait(1).to({graphics:mask_graphics_677,x:581.9,y:51}).wait(1).to({graphics:mask_graphics_678,x:582.6,y:51}).wait(1).to({graphics:mask_graphics_679,x:583.2,y:51}).wait(1).to({graphics:mask_graphics_680,x:583.8,y:51}).wait(1).to({graphics:mask_graphics_681,x:584.4,y:51}).wait(1).to({graphics:mask_graphics_682,x:585,y:51}).wait(1).to({graphics:mask_graphics_683,x:585.6,y:51}).wait(1).to({graphics:mask_graphics_684,x:586.2,y:51}).wait(1).to({graphics:mask_graphics_685,x:586.8,y:51}).wait(1).to({graphics:mask_graphics_686,x:587.4,y:51}).wait(1).to({graphics:mask_graphics_687,x:588,y:51}).wait(1).to({graphics:mask_graphics_688,x:588.7,y:51}).wait(1).to({graphics:mask_graphics_689,x:589.3,y:51}).wait(1).to({graphics:mask_graphics_690,x:589.9,y:51}).wait(1).to({graphics:mask_graphics_691,x:590.5,y:51}).wait(1).to({graphics:mask_graphics_692,x:591.1,y:51}).wait(1).to({graphics:mask_graphics_693,x:591.7,y:51}).wait(1).to({graphics:mask_graphics_694,x:592.3,y:51}).wait(1).to({graphics:mask_graphics_695,x:592.9,y:51}).wait(1).to({graphics:mask_graphics_696,x:593.5,y:51}).wait(1).to({graphics:mask_graphics_697,x:361.7,y:45.9}).wait(127));

	// 3a_Formula
	this.text = new cjs.Text("A\"B\"", "italic 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 51;
	this.text.setTransform(678.1,21.1+incremento);

	this.text_1 = new cjs.Text("B\"C", "italic 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 45;
	this.text_1.setTransform(678.1,53.3+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_6.setTransform(680.1,51.2,1.19,1);

	this.text_2 = new cjs.Text("B'C", "italic 20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 45;
	this.text_2.setTransform(588.3,53.3+incremento);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 16;
	this.text_3.setTransform(631.5,35.5+incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_7.setTransform(590.3,51.2,1.19,1);

	this.text_4 = new cjs.Text("A'B'", "italic 20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 45;
	this.text_4.setTransform(588.3,21.1+incremento);

	this.text_5 = new cjs.Text("=", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 16;
	this.text_5.setTransform(543.9,35.6+incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_8.setTransform(506.5,51.2);

	this.text_6 = new cjs.Text("BC", "italic 20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 38;
	this.text_6.setTransform(504.5,53.3+incremento);

	this.text_7 = new cjs.Text("AB", "italic 20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 38;
	this.text_7.setTransform(504.5,21.1+incremento);

	this.text.mask = this.text_1.mask = this.shape_6.mask = this.text_2.mask = this.text_3.mask = this.shape_7.mask = this.text_4.mask = this.text_5.mask = this.shape_8.mask = this.text_6.mask = this.text_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.text_6},{t:this.shape_8},{t:this.text_5},{t:this.text_4},{t:this.shape_7},{t:this.text_3},{t:this.text_2},{t:this.shape_6},{t:this.text_1},{t:this.text}]},495).wait(329));

	// Resaltados_2
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#B30218").ss(3,1,1).p("AI3ABIxtgB");
	this.shape_9.setTransform(59,55.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#B30218").ss(3,1,1).p("AI1lRIxpKj");
	this.shape_10.setTransform(59.2,21.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#B30218").ss(3,1,1).p("ARfABMgi9gAB");
	this.shape_11.setTransform(114.3,55.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#B30218").ss(3,1,1).p("ARdqbMgi5AU3");
	this.shape_12.setTransform(114.3,-11.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#B30218").ss(3,1,1).p("AXzABMgvlgAB");
	this.shape_13.setTransform(154.6,55.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#B30218").ss(3,1,1).p("AXwuPMgvfAcf");
	this.shape_14.setTransform(154.7,-36.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10},{t:this.shape_9}]},292).to({state:[{t:this.shape_12},{t:this.shape_11}]},63).to({state:[{t:this.shape_14},{t:this.shape_13}]},68).to({state:[]},51).wait(350));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_256 = new cjs.Graphics().p("Ag2FuIAArbIBtAAIAALbg");
	var mask_1_graphics_257 = new cjs.Graphics().p("Ag8FuIAArbIB5AAIAALbg");
	var mask_1_graphics_258 = new cjs.Graphics().p("AhDFuIAArbICHAAIAALbg");
	var mask_1_graphics_259 = new cjs.Graphics().p("AhJFuIAArbICTAAIAALbg");
	var mask_1_graphics_260 = new cjs.Graphics().p("AhQFuIAArbIChAAIAALbg");
	var mask_1_graphics_261 = new cjs.Graphics().p("AhWFuIAArbICtAAIAALbg");
	var mask_1_graphics_262 = new cjs.Graphics().p("AhdFuIAArbIC7AAIAALbg");
	var mask_1_graphics_263 = new cjs.Graphics().p("AhjFuIAArbIDHAAIAALbg");
	var mask_1_graphics_264 = new cjs.Graphics().p("AhpFuIAArbIDTAAIAALbg");
	var mask_1_graphics_265 = new cjs.Graphics().p("AhwFuIAArbIDhAAIAALbg");
	var mask_1_graphics_266 = new cjs.Graphics().p("Ah2FuIAArbIDtAAIAALbg");
	var mask_1_graphics_267 = new cjs.Graphics().p("Ah9FuIAArbID7AAIAALbg");
	var mask_1_graphics_268 = new cjs.Graphics().p("AiDFuIAArbIEHAAIAALbg");
	var mask_1_graphics_269 = new cjs.Graphics().p("AiKFuIAArbIEVAAIAALbg");
	var mask_1_graphics_270 = new cjs.Graphics().p("AiQFuIAArbIEhAAIAALbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("AiXFuIAArbIEvAAIAALbg");
	var mask_1_graphics_272 = new cjs.Graphics().p("AidFuIAArbIE7AAIAALbg");
	var mask_1_graphics_273 = new cjs.Graphics().p("AijFuIAArbIFHAAIAALbg");
	var mask_1_graphics_274 = new cjs.Graphics().p("AiqFuIAArbIFVAAIAALbg");
	var mask_1_graphics_275 = new cjs.Graphics().p("AiwFuIAArbIFhAAIAALbg");
	var mask_1_graphics_276 = new cjs.Graphics().p("Ai3FuIAArbIFvAAIAALbg");
	var mask_1_graphics_277 = new cjs.Graphics().p("Ai9FuIAArbIF7AAIAALbg");
	var mask_1_graphics_278 = new cjs.Graphics().p("AjEFuIAArbIGJAAIAALbg");
	var mask_1_graphics_279 = new cjs.Graphics().p("AjKFuIAArbIGVAAIAALbg");
	var mask_1_graphics_280 = new cjs.Graphics().p("AjQFuIAArbIGhAAIAALbg");
	var mask_1_graphics_281 = new cjs.Graphics().p("AjXFuIAArbIGvAAIAALbg");
	var mask_1_graphics_282 = new cjs.Graphics().p("AjdFuIAArbIG7AAIAALbg");
	var mask_1_graphics_283 = new cjs.Graphics().p("AjkFuIAArbIHJAAIAALbg");
	var mask_1_graphics_284 = new cjs.Graphics().p("AjqFuIAArbIHVAAIAALbg");
	var mask_1_graphics_285 = new cjs.Graphics().p("AjxFuIAArbIHjAAIAALbg");
	var mask_1_graphics_286 = new cjs.Graphics().p("Aj3FuIAArbIHvAAIAALbg");
	var mask_1_graphics_287 = new cjs.Graphics().p("Aj9FuIAArbIH7AAIAALbg");
	var mask_1_graphics_288 = new cjs.Graphics().p("AkEFuIAArbIIJAAIAALbg");
	var mask_1_graphics_289 = new cjs.Graphics().p("AkKFuIAArbIIVAAIAALbg");
	var mask_1_graphics_290 = new cjs.Graphics().p("AkRFuIAArbIIjAAIAALbg");
	var mask_1_graphics_291 = new cjs.Graphics().p("AkXFuIAArbIIvAAIAALbg");
	var mask_1_graphics_292 = new cjs.Graphics().p("AkeFuIAArbII9AAIAALbg");
	var mask_1_graphics_293 = new cjs.Graphics().p("AkkFuIAArbIJJAAIAALbg");
	var mask_1_graphics_294 = new cjs.Graphics().p("AkrFuIAArbIJXAAIAALbg");
	var mask_1_graphics_295 = new cjs.Graphics().p("AkxFuIAArbIJjAAIAALbg");
	var mask_1_graphics_296 = new cjs.Graphics().p("Ak3FuIAArbIJvAAIAALbg");
	var mask_1_graphics_297 = new cjs.Graphics().p("Ak+FuIAArbIJ9AAIAALbg");
	var mask_1_graphics_298 = new cjs.Graphics().p("AlEFuIAArbIKJAAIAALbg");
	var mask_1_graphics_299 = new cjs.Graphics().p("AlLFuIAArbIKXAAIAALbg");
	var mask_1_graphics_300 = new cjs.Graphics().p("AlRFuIAArbIKjAAIAALbg");
	var mask_1_graphics_301 = new cjs.Graphics().p("AlYFuIAArbIKxAAIAALbg");
	var mask_1_graphics_302 = new cjs.Graphics().p("AleFuIAArbIK9AAIAALbg");
	var mask_1_graphics_303 = new cjs.Graphics().p("AlkFuIAArbILJAAIAALbg");
	var mask_1_graphics_304 = new cjs.Graphics().p("AlrFuIAArbILXAAIAALbg");
	var mask_1_graphics_305 = new cjs.Graphics().p("AlxFuIAArbILjAAIAALbg");
	var mask_1_graphics_306 = new cjs.Graphics().p("Al4FuIAArbILxAAIAALbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("Al+FuIAArbIL9AAIAALbg");
	var mask_1_graphics_308 = new cjs.Graphics().p("AmFFuIAArbIMLAAIAALbg");
	var mask_1_graphics_309 = new cjs.Graphics().p("AmLFuIAArbIMXAAIAALbg");
	var mask_1_graphics_310 = new cjs.Graphics().p("AmRFuIAArbIMjAAIAALbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("AmYFuIAArbIMxAAIAALbg");
	var mask_1_graphics_312 = new cjs.Graphics().p("AmeFuIAArbIM9AAIAALbg");
	var mask_1_graphics_313 = new cjs.Graphics().p("AmlFuIAArbINLAAIAALbg");
	var mask_1_graphics_314 = new cjs.Graphics().p("AmrFuIAArbINXAAIAALbg");
	var mask_1_graphics_315 = new cjs.Graphics().p("AmyFuIAArbINlAAIAALbg");
	var mask_1_graphics_316 = new cjs.Graphics().p("Am4FuIAArbINxAAIAALbg");
	var mask_1_graphics_317 = new cjs.Graphics().p("Am+FuIAArbIN9AAIAALbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("AnFFuIAArbIOLAAIAALbg");
	var mask_1_graphics_319 = new cjs.Graphics().p("AnLFuIAArbIOXAAIAALbg");
	var mask_1_graphics_320 = new cjs.Graphics().p("AnSFuIAArbIOlAAIAALbg");
	var mask_1_graphics_321 = new cjs.Graphics().p("AnYFuIAArbIOxAAIAALbg");
	var mask_1_graphics_322 = new cjs.Graphics().p("AnfFuIAArbIO/AAIAALbg");
	var mask_1_graphics_323 = new cjs.Graphics().p("AnlFuIAArbIPLAAIAALbg");
	var mask_1_graphics_324 = new cjs.Graphics().p("AnsFuIAArbIPZAAIAALbg");
	var mask_1_graphics_325 = new cjs.Graphics().p("AnyFuIAArbIPlAAIAALbg");
	var mask_1_graphics_326 = new cjs.Graphics().p("An4FuIAArbIPxAAIAALbg");
	var mask_1_graphics_327 = new cjs.Graphics().p("An/FuIAArbIP/AAIAALbg");
	var mask_1_graphics_328 = new cjs.Graphics().p("AoFFuIAArbIQLAAIAALbg");
	var mask_1_graphics_329 = new cjs.Graphics().p("AoMFuIAArbIQZAAIAALbg");
	var mask_1_graphics_330 = new cjs.Graphics().p("AoSFuIAArbIQlAAIAALbg");
	var mask_1_graphics_331 = new cjs.Graphics().p("AoZFuIAArbIQzAAIAALbg");
	var mask_1_graphics_332 = new cjs.Graphics().p("AofFuIAArbIQ/AAIAALbg");
	var mask_1_graphics_333 = new cjs.Graphics().p("AolFuIAArbIRLAAIAALbg");
	var mask_1_graphics_334 = new cjs.Graphics().p("AosFuIAArbIRZAAIAALbg");
	var mask_1_graphics_335 = new cjs.Graphics().p("AoyFuIAArbIRlAAIAALbg");
	var mask_1_graphics_336 = new cjs.Graphics().p("Ao5FuIAArbIRzAAIAALbg");
	var mask_1_graphics_337 = new cjs.Graphics().p("Ao/FuIAArbIR/AAIAALbg");
	var mask_1_graphics_338 = new cjs.Graphics().p("ApGFuIAArbISNAAIAALbg");
	var mask_1_graphics_339 = new cjs.Graphics().p("ApMFuIAArbISZAAIAALbg");
	var mask_1_graphics_340 = new cjs.Graphics().p("ApSFuIAArbISlAAIAALbg");
	var mask_1_graphics_341 = new cjs.Graphics().p("ApZFuIAArbISzAAIAALbg");
	var mask_1_graphics_342 = new cjs.Graphics().p("ApfFuIAArbIS/AAIAALbg");
	var mask_1_graphics_343 = new cjs.Graphics().p("ApmFuIAArbITNAAIAALbg");
	var mask_1_graphics_344 = new cjs.Graphics().p("ApsFuIAArbITZAAIAALbg");
	var mask_1_graphics_345 = new cjs.Graphics().p("ApzFuIAArbITnAAIAALbg");
	var mask_1_graphics_346 = new cjs.Graphics().p("Ap5FuIAArbITzAAIAALbg");
	var mask_1_graphics_347 = new cjs.Graphics().p("AqAFuIAArbIUBAAIAALbg");
	var mask_1_graphics_348 = new cjs.Graphics().p("AqGFuIAArbIUNAAIAALbg");
	var mask_1_graphics_349 = new cjs.Graphics().p("AqMFuIAArbIUZAAIAALbg");
	var mask_1_graphics_350 = new cjs.Graphics().p("AqTFuIAArbIUnAAIAALbg");
	var mask_1_graphics_351 = new cjs.Graphics().p("AqZFuIAArbIUzAAIAALbg");
	var mask_1_graphics_352 = new cjs.Graphics().p("AqgFuIAArbIVBAAIAALbg");
	var mask_1_graphics_353 = new cjs.Graphics().p("AqmFuIAArbIVNAAIAALbg");
	var mask_1_graphics_354 = new cjs.Graphics().p("AqtFuIAArbIVbAAIAALbg");
	var mask_1_graphics_355 = new cjs.Graphics().p("AqzFuIAArbIVnAAIAALbg");
	var mask_1_graphics_356 = new cjs.Graphics().p("Aq5FuIAArbIVzAAIAALbg");
	var mask_1_graphics_357 = new cjs.Graphics().p("ArAFuIAArbIWBAAIAALbg");
	var mask_1_graphics_358 = new cjs.Graphics().p("ArGFuIAArbIWNAAIAALbg");
	var mask_1_graphics_359 = new cjs.Graphics().p("ArNFuIAArbIWbAAIAALbg");
	var mask_1_graphics_360 = new cjs.Graphics().p("ArTFuIAArbIWnAAIAALbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("AraFuIAArbIW1AAIAALbg");
	var mask_1_graphics_362 = new cjs.Graphics().p("ArgFuIAArbIXBAAIAALbg");
	var mask_1_graphics_363 = new cjs.Graphics().p("ArmFuIAArbIXNAAIAALbg");
	var mask_1_graphics_364 = new cjs.Graphics().p("ArtFuIAArbIXbAAIAALbg");
	var mask_1_graphics_365 = new cjs.Graphics().p("ArzFuIAArbIXnAAIAALbg");
	var mask_1_graphics_366 = new cjs.Graphics().p("Ar6FuIAArbIX1AAIAALbg");
	var mask_1_graphics_367 = new cjs.Graphics().p("AsAFuIAArbIYBAAIAALbg");
	var mask_1_graphics_368 = new cjs.Graphics().p("AsHFuIAArbIYPAAIAALbg");
	var mask_1_graphics_369 = new cjs.Graphics().p("AsNFuIAArbIYbAAIAALbg");
	var mask_1_graphics_370 = new cjs.Graphics().p("AsUFuIAArbIYpAAIAALbg");
	var mask_1_graphics_371 = new cjs.Graphics().p("AsaFuIAArbIY1AAIAALbg");
	var mask_1_graphics_372 = new cjs.Graphics().p("AsgFuIAArbIZBAAIAALbg");
	var mask_1_graphics_373 = new cjs.Graphics().p("AsnFuIAArbIZPAAIAALbg");
	var mask_1_graphics_374 = new cjs.Graphics().p("AstFuIAArbIZbAAIAALbg");
	var mask_1_graphics_375 = new cjs.Graphics().p("As0FuIAArbIZpAAIAALbg");
	var mask_1_graphics_376 = new cjs.Graphics().p("As6FuIAArbIZ1AAIAALbg");
	var mask_1_graphics_377 = new cjs.Graphics().p("AtBFuIAArbIaDAAIAALbg");
	var mask_1_graphics_378 = new cjs.Graphics().p("AtHFuIAArbIaPAAIAALbg");
	var mask_1_graphics_379 = new cjs.Graphics().p("AtNFuIAArbIabAAIAALbg");
	var mask_1_graphics_380 = new cjs.Graphics().p("AtUFuIAArbIapAAIAALbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("AtaFuIAArbIa1AAIAALbg");
	var mask_1_graphics_382 = new cjs.Graphics().p("AthFuIAArbIbDAAIAALbg");
	var mask_1_graphics_383 = new cjs.Graphics().p("AtnFuIAArbIbPAAIAALbg");
	var mask_1_graphics_384 = new cjs.Graphics().p("AtuFuIAArbIbdAAIAALbg");
	var mask_1_graphics_385 = new cjs.Graphics().p("At0FuIAArbIbpAAIAALbg");
	var mask_1_graphics_386 = new cjs.Graphics().p("At6FuIAArbIb1AAIAALbg");
	var mask_1_graphics_387 = new cjs.Graphics().p("AuBFuIAArbIcDAAIAALbg");
	var mask_1_graphics_388 = new cjs.Graphics().p("AuHFuIAArbIcPAAIAALbg");
	var mask_1_graphics_389 = new cjs.Graphics().p("AuOFuIAArbIcdAAIAALbg");
	var mask_1_graphics_390 = new cjs.Graphics().p("AuUFuIAArbIcpAAIAALbg");
	var mask_1_graphics_391 = new cjs.Graphics().p("AubFuIAArbIc3AAIAALbg");
	var mask_1_graphics_392 = new cjs.Graphics().p("AuhFuIAArbIdDAAIAALbg");
	var mask_1_graphics_393 = new cjs.Graphics().p("AunFuIAArbIdPAAIAALbg");
	var mask_1_graphics_394 = new cjs.Graphics().p("AuuFuIAArbIddAAIAALbg");
	var mask_1_graphics_395 = new cjs.Graphics().p("Au0FuIAArbIdpAAIAALbg");
	var mask_1_graphics_396 = new cjs.Graphics().p("Au7FuIAArbId3AAIAALbg");
	var mask_1_graphics_397 = new cjs.Graphics().p("AvBFuIAArbIeDAAIAALbg");
	var mask_1_graphics_398 = new cjs.Graphics().p("AvIFuIAArbIeRAAIAALbg");
	var mask_1_graphics_399 = new cjs.Graphics().p("AvOFuIAArbIedAAIAALbg");
	var mask_1_graphics_400 = new cjs.Graphics().p("AvVFuIAArbIerAAIAALbg");
	var mask_1_graphics_401 = new cjs.Graphics().p("AvbFuIAArbIe3AAIAALbg");
	var mask_1_graphics_402 = new cjs.Graphics().p("AvhFuIAArbIfDAAIAALbg");
	var mask_1_graphics_403 = new cjs.Graphics().p("AvoFuIAArbIfRAAIAALbg");
	var mask_1_graphics_404 = new cjs.Graphics().p("AvuFuIAArbIfdAAIAALbg");
	var mask_1_graphics_405 = new cjs.Graphics().p("Av1FuIAArbIfrAAIAALbg");
	var mask_1_graphics_406 = new cjs.Graphics().p("Av7FuIAArbIf3AAIAALbg");
	var mask_1_graphics_407 = new cjs.Graphics().p("AwCFuIAArbMAgFAAAIAALbg");
	var mask_1_graphics_408 = new cjs.Graphics().p("AwIFuIAArbMAgRAAAIAALbg");
	var mask_1_graphics_409 = new cjs.Graphics().p("AwOFuIAArbMAgdAAAIAALbg");
	var mask_1_graphics_410 = new cjs.Graphics().p("AwVFuIAArbMAgrAAAIAALbg");
	var mask_1_graphics_411 = new cjs.Graphics().p("AwbFuIAArbMAg3AAAIAALbg");
	var mask_1_graphics_412 = new cjs.Graphics().p("AwiFuIAArbMAhFAAAIAALbg");
	var mask_1_graphics_413 = new cjs.Graphics().p("AwoFuIAArbMAhRAAAIAALbg");
	var mask_1_graphics_414 = new cjs.Graphics().p("AwvFuIAArbMAhfAAAIAALbg");
	var mask_1_graphics_415 = new cjs.Graphics().p("Aw1FuIAArbMAhrAAAIAALbg");
	var mask_1_graphics_416 = new cjs.Graphics().p("Aw7FuIAArbMAh3AAAIAALbg");
	var mask_1_graphics_417 = new cjs.Graphics().p("AxCFuIAArbMAiFAAAIAALbg");
	var mask_1_graphics_418 = new cjs.Graphics().p("AxIFuIAArbMAiRAAAIAALbg");
	var mask_1_graphics_419 = new cjs.Graphics().p("AxPFuIAArbMAifAAAIAALbg");
	var mask_1_graphics_420 = new cjs.Graphics().p("AxVFuIAArbMAirAAAIAALbg");
	var mask_1_graphics_421 = new cjs.Graphics().p("AxcFuIAArbMAi5AAAIAALbg");
	var mask_1_graphics_422 = new cjs.Graphics().p("AxiFuIAArbMAjFAAAIAALbg");
	var mask_1_graphics_423 = new cjs.Graphics().p("AxpFuIAArbMAjTAAAIAALbg");
	var mask_1_graphics_424 = new cjs.Graphics().p("AxvFuIAArbMAjfAAAIAALbg");
	var mask_1_graphics_425 = new cjs.Graphics().p("Ax1FuIAArbMAjrAAAIAALbg");
	var mask_1_graphics_426 = new cjs.Graphics().p("Ax8FuIAArbMAj5AAAIAALbg");
	var mask_1_graphics_427 = new cjs.Graphics().p("AyCFuIAArbMAkFAAAIAALbg");
	var mask_1_graphics_428 = new cjs.Graphics().p("AyJFuIAArbMAkTAAAIAALbg");
	var mask_1_graphics_429 = new cjs.Graphics().p("AyPFuIAArbMAkfAAAIAALbg");
	var mask_1_graphics_430 = new cjs.Graphics().p("AyWFuIAArbMAktAAAIAALbg");
	var mask_1_graphics_431 = new cjs.Graphics().p("AycFuIAArbMAk5AAAIAALbg");
	var mask_1_graphics_432 = new cjs.Graphics().p("AyiFuIAArbMAlFAAAIAALbg");
	var mask_1_graphics_433 = new cjs.Graphics().p("AypFuIAArbMAlTAAAIAALbg");
	var mask_1_graphics_434 = new cjs.Graphics().p("AyvFuIAArbMAlfAAAIAALbg");
	var mask_1_graphics_435 = new cjs.Graphics().p("Ay2FuIAArbMAltAAAIAALbg");
	var mask_1_graphics_436 = new cjs.Graphics().p("Ay8FuIAArbMAl5AAAIAALbg");
	var mask_1_graphics_437 = new cjs.Graphics().p("AzDFuIAArbMAmHAAAIAALbg");
	var mask_1_graphics_438 = new cjs.Graphics().p("AzJFuIAArbMAmTAAAIAALbg");
	var mask_1_graphics_439 = new cjs.Graphics().p("AzPFuIAArbMAmfAAAIAALbg");
	var mask_1_graphics_440 = new cjs.Graphics().p("AzWFuIAArbMAmtAAAIAALbg");
	var mask_1_graphics_441 = new cjs.Graphics().p("AzcFuIAArbMAm5AAAIAALbg");
	var mask_1_graphics_442 = new cjs.Graphics().p("AzjFuIAArbMAnHAAAIAALbg");
	var mask_1_graphics_443 = new cjs.Graphics().p("AzpFuIAArbMAnTAAAIAALbg");
	var mask_1_graphics_444 = new cjs.Graphics().p("AzwFuIAArbMAnhAAAIAALbg");
	var mask_1_graphics_445 = new cjs.Graphics().p("Az2FuIAArbMAntAAAIAALbg");
	var mask_1_graphics_446 = new cjs.Graphics().p("Az9FuIAArbMAn7AAAIAALbg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A0DFuIAArbMAoHAAAIAALbg");
	var mask_1_graphics_448 = new cjs.Graphics().p("A0JFuIAArbMAoTAAAIAALbg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A0QFuIAArbMAohAAAIAALbg");
	var mask_1_graphics_450 = new cjs.Graphics().p("AP7FuIAArbMAovAAAIAALbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(256).to({graphics:mask_1_graphics_256,x:470.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_257,x:470.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_258,x:471.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_259,x:472.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_260,x:472.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_261,x:473.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_262,x:474.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_263,x:474.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_264,x:475.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_265,x:476,y:-33.9}).wait(1).to({graphics:mask_1_graphics_266,x:476.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_267,x:477.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_268,x:477.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_269,x:478.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_270,x:479.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_271,x:479.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_272,x:480.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_273,x:481.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_274,x:481.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_275,x:482.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_276,x:483.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_277,x:483.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_278,x:484.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_279,x:485,y:-33.9}).wait(1).to({graphics:mask_1_graphics_280,x:485.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_281,x:486.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_282,x:486.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_283,x:487.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_284,x:488.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_285,x:488.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_286,x:489.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_287,x:490.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_288,x:490.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_289,x:491.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_290,x:492.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_291,x:492.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_292,x:493.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_293,x:494,y:-33.9}).wait(1).to({graphics:mask_1_graphics_294,x:494.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_295,x:495.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_296,x:495.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_297,x:496.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_298,x:497.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_299,x:497.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_300,x:498.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_301,x:499.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_302,x:499.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_303,x:500.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_304,x:501.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_305,x:501.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_306,x:502.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_307,x:503,y:-33.9}).wait(1).to({graphics:mask_1_graphics_308,x:503.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_309,x:504.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_310,x:504.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_311,x:505.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_312,x:506.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_313,x:506.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_314,x:507.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_315,x:508.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_316,x:508.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_317,x:509.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_318,x:510.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_319,x:510.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_320,x:511.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_321,x:512,y:-33.9}).wait(1).to({graphics:mask_1_graphics_322,x:512.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_323,x:513.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_324,x:514,y:-33.9}).wait(1).to({graphics:mask_1_graphics_325,x:514.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_326,x:515.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_327,x:515.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_328,x:516.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_329,x:517.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_330,x:517.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_331,x:518.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_332,x:519.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_333,x:519.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_334,x:520.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_335,x:521,y:-33.9}).wait(1).to({graphics:mask_1_graphics_336,x:521.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_337,x:522.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_338,x:523,y:-33.9}).wait(1).to({graphics:mask_1_graphics_339,x:523.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_340,x:524.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_341,x:524.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_342,x:525.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_343,x:526.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_344,x:526.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_345,x:527.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_346,x:528.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_347,x:528.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_348,x:529.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_349,x:530,y:-33.9}).wait(1).to({graphics:mask_1_graphics_350,x:530.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_351,x:531.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_352,x:532,y:-33.9}).wait(1).to({graphics:mask_1_graphics_353,x:532.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_354,x:533.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_355,x:533.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_356,x:534.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_357,x:535.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_358,x:535.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_359,x:536.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_360,x:537.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_361,x:537.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_362,x:538.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_363,x:539,y:-33.9}).wait(1).to({graphics:mask_1_graphics_364,x:539.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_365,x:540.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_366,x:541,y:-33.9}).wait(1).to({graphics:mask_1_graphics_367,x:541.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_368,x:542.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_369,x:542.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_370,x:543.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_371,x:544.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_372,x:544.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_373,x:545.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_374,x:546.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_375,x:546.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_376,x:547.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_377,x:548.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_378,x:548.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_379,x:549.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_380,x:550,y:-33.9}).wait(1).to({graphics:mask_1_graphics_381,x:550.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_382,x:551.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_383,x:551.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_384,x:552.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_385,x:553.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_386,x:553.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_387,x:554.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_388,x:555.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_389,x:555.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_390,x:556.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_391,x:557.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_392,x:557.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_393,x:558.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_394,x:559,y:-33.9}).wait(1).to({graphics:mask_1_graphics_395,x:559.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_396,x:560.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_397,x:560.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_398,x:561.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_399,x:562.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_400,x:562.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_401,x:563.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_402,x:564.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_403,x:564.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_404,x:565.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_405,x:566.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_406,x:566.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_407,x:567.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_408,x:568,y:-33.9}).wait(1).to({graphics:mask_1_graphics_409,x:568.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_410,x:569.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_411,x:569.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_412,x:570.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_413,x:571.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_414,x:571.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_415,x:572.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_416,x:573.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_417,x:573.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_418,x:574.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_419,x:575.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_420,x:575.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_421,x:576.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_422,x:577,y:-33.9}).wait(1).to({graphics:mask_1_graphics_423,x:577.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_424,x:578.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_425,x:578.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_426,x:579.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_427,x:580.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_428,x:580.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_429,x:581.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_430,x:582.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_431,x:582.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_432,x:583.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_433,x:584.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_434,x:584.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_435,x:585.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_436,x:586,y:-33.9}).wait(1).to({graphics:mask_1_graphics_437,x:586.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_438,x:587.3,y:-33.9}).wait(1).to({graphics:mask_1_graphics_439,x:587.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_440,x:588.6,y:-33.9}).wait(1).to({graphics:mask_1_graphics_441,x:589.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_442,x:589.9,y:-33.9}).wait(1).to({graphics:mask_1_graphics_443,x:590.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_444,x:591.2,y:-33.9}).wait(1).to({graphics:mask_1_graphics_445,x:591.8,y:-33.9}).wait(1).to({graphics:mask_1_graphics_446,x:592.5,y:-33.9}).wait(1).to({graphics:mask_1_graphics_447,x:593.1,y:-33.9}).wait(1).to({graphics:mask_1_graphics_448,x:593.7,y:-33.9}).wait(1).to({graphics:mask_1_graphics_449,x:594.4,y:-33.9}).wait(1).to({graphics:mask_1_graphics_450,x:362.7,y:-33.9}).wait(374));

	// 2a_Formula
	this.text_8 = new cjs.Text("B\"C", "italic 20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 20;
	this.text_8.lineWidth = 51;
	this.text_8.setTransform(678.1,-65+incremento);

	this.text_9 = new cjs.Text("A\"C", "italic 20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 20;
	this.text_9.lineWidth = 45;
	this.text_9.setTransform(678.1,-32.7+incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_15.setTransform(680.1,-34.9,1.19,1);

	this.text_10 = new cjs.Text("A'C", "italic 20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 20;
	this.text_10.lineWidth = 45;
	this.text_10.setTransform(588.3,-32.7+incremento);

	this.text_11 = new cjs.Text("=", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 20;
	this.text_11.lineWidth = 16;
	this.text_11.setTransform(631.5,-50.6+incremento);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_16.setTransform(590.3,-34.9,1.19,1);

	this.text_12 = new cjs.Text("B'C", "italic 20px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 20;
	this.text_12.lineWidth = 45;
	this.text_12.setTransform(588.3,-65+incremento);

	this.text_13 = new cjs.Text("=", "20px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 20;
	this.text_13.lineWidth = 16;
	this.text_13.setTransform(543.9,-50.5+incremento);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_17.setTransform(506.5,-34.9);

	this.text_14 = new cjs.Text("AC", "italic 20px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 20;
	this.text_14.lineWidth = 38;
	this.text_14.setTransform(504.5,-32.7+incremento);

	this.text_15 = new cjs.Text("BC", "italic 20px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 20;
	this.text_15.lineWidth = 38;
	this.text_15.setTransform(504.5,-65+incremento);

	this.text_8.mask = this.text_9.mask = this.shape_15.mask = this.text_10.mask = this.text_11.mask = this.shape_16.mask = this.text_12.mask = this.text_13.mask = this.shape_17.mask = this.text_14.mask = this.text_15.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_15},{t:this.text_14},{t:this.shape_17},{t:this.text_13},{t:this.text_12},{t:this.shape_16},{t:this.text_11},{t:this.text_10},{t:this.shape_15},{t:this.text_9},{t:this.text_8}]},256).wait(568));

	// Resaltados_1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#B30218").ss(3,1,1).p("AI2lRIxrKj");
	this.shape_18.setTransform(59.2,21.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#B30218").ss(3,1,1).p("AAAlSIAAKl");
	this.shape_19.setTransform(115.9,21.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#B30218").ss(3,1,1).p("ARfqbMgi9AU3");
	this.shape_20.setTransform(114.5,-11.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#B30218").ss(3,1,1).p("AAAqZIAAUz");
	this.shape_21.setTransform(226.4,-11.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#B30218").ss(3,1,1).p("AXzuOMgvlAcd");
	this.shape_22.setTransform(154.9,-35.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#B30218").ss(3,1,1).p("AACuOIgDcd");
	this.shape_23.setTransform(306.9,-35.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_19},{t:this.shape_18}]},85).to({state:[{t:this.shape_21},{t:this.shape_20}]},57).to({state:[{t:this.shape_23},{t:this.shape_22}]},67).to({state:[]},37).wait(578));

	// Mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_49 = new cjs.Graphics().p("AgwF0IAArnIBhAAIAALng");
	var mask_2_graphics_50 = new cjs.Graphics().p("Ag3F0IAArnIBvAAIAALng");
	var mask_2_graphics_51 = new cjs.Graphics().p("Ag9F0IAArnIB7AAIAALng");
	var mask_2_graphics_52 = new cjs.Graphics().p("AhEF0IAArnICJAAIAALng");
	var mask_2_graphics_53 = new cjs.Graphics().p("AhKF0IAArnICVAAIAALng");
	var mask_2_graphics_54 = new cjs.Graphics().p("AhRF0IAArnICjAAIAALng");
	var mask_2_graphics_55 = new cjs.Graphics().p("AhYF0IAArnICxAAIAALng");
	var mask_2_graphics_56 = new cjs.Graphics().p("AheF0IAArnIC9AAIAALng");
	var mask_2_graphics_57 = new cjs.Graphics().p("AhlF0IAArnIDLAAIAALng");
	var mask_2_graphics_58 = new cjs.Graphics().p("AhsF0IAArnIDZAAIAALng");
	var mask_2_graphics_59 = new cjs.Graphics().p("AhyF0IAArnIDlAAIAALng");
	var mask_2_graphics_60 = new cjs.Graphics().p("Ah5F0IAArnIDzAAIAALng");
	var mask_2_graphics_61 = new cjs.Graphics().p("Ah/F0IAArnID/AAIAALng");
	var mask_2_graphics_62 = new cjs.Graphics().p("AiGF0IAArnIENAAIAALng");
	var mask_2_graphics_63 = new cjs.Graphics().p("AiNF0IAArnIEbAAIAALng");
	var mask_2_graphics_64 = new cjs.Graphics().p("AiTF0IAArnIEnAAIAALng");
	var mask_2_graphics_65 = new cjs.Graphics().p("AiaF0IAArnIE1AAIAALng");
	var mask_2_graphics_66 = new cjs.Graphics().p("AigF0IAArnIFBAAIAALng");
	var mask_2_graphics_67 = new cjs.Graphics().p("AinF0IAArnIFPAAIAALng");
	var mask_2_graphics_68 = new cjs.Graphics().p("AiuF0IAArnIFdAAIAALng");
	var mask_2_graphics_69 = new cjs.Graphics().p("Ai0F0IAArnIFpAAIAALng");
	var mask_2_graphics_70 = new cjs.Graphics().p("Ai7F0IAArnIF3AAIAALng");
	var mask_2_graphics_71 = new cjs.Graphics().p("AjCF0IAArnIGFAAIAALng");
	var mask_2_graphics_72 = new cjs.Graphics().p("AjIF0IAArnIGRAAIAALng");
	var mask_2_graphics_73 = new cjs.Graphics().p("AjPF0IAArnIGfAAIAALng");
	var mask_2_graphics_74 = new cjs.Graphics().p("AjVF0IAArnIGrAAIAALng");
	var mask_2_graphics_75 = new cjs.Graphics().p("AjcF0IAArnIG5AAIAALng");
	var mask_2_graphics_76 = new cjs.Graphics().p("AjjF0IAArnIHHAAIAALng");
	var mask_2_graphics_77 = new cjs.Graphics().p("AjpF0IAArnIHTAAIAALng");
	var mask_2_graphics_78 = new cjs.Graphics().p("AjwF0IAArnIHhAAIAALng");
	var mask_2_graphics_79 = new cjs.Graphics().p("Aj3F0IAArnIHvAAIAALng");
	var mask_2_graphics_80 = new cjs.Graphics().p("Aj9F0IAArnIH7AAIAALng");
	var mask_2_graphics_81 = new cjs.Graphics().p("AkEF0IAArnIIJAAIAALng");
	var mask_2_graphics_82 = new cjs.Graphics().p("AkKF0IAArnIIVAAIAALng");
	var mask_2_graphics_83 = new cjs.Graphics().p("AkRF0IAArnIIjAAIAALng");
	var mask_2_graphics_84 = new cjs.Graphics().p("AkYF0IAArnIIxAAIAALng");
	var mask_2_graphics_85 = new cjs.Graphics().p("AkeF0IAArnII9AAIAALng");
	var mask_2_graphics_86 = new cjs.Graphics().p("AklF0IAArnIJLAAIAALng");
	var mask_2_graphics_87 = new cjs.Graphics().p("AkrF0IAArnIJXAAIAALng");
	var mask_2_graphics_88 = new cjs.Graphics().p("AkyF0IAArnIJlAAIAALng");
	var mask_2_graphics_89 = new cjs.Graphics().p("Ak5F0IAArnIJzAAIAALng");
	var mask_2_graphics_90 = new cjs.Graphics().p("Ak/F0IAArnIJ/AAIAALng");
	var mask_2_graphics_91 = new cjs.Graphics().p("AlGF0IAArnIKNAAIAALng");
	var mask_2_graphics_92 = new cjs.Graphics().p("AlNF0IAArnIKbAAIAALng");
	var mask_2_graphics_93 = new cjs.Graphics().p("AlTF0IAArnIKnAAIAALng");
	var mask_2_graphics_94 = new cjs.Graphics().p("AlaF0IAArnIK1AAIAALng");
	var mask_2_graphics_95 = new cjs.Graphics().p("AlgF0IAArnILBAAIAALng");
	var mask_2_graphics_96 = new cjs.Graphics().p("AlnF0IAArnILPAAIAALng");
	var mask_2_graphics_97 = new cjs.Graphics().p("AluF0IAArnILdAAIAALng");
	var mask_2_graphics_98 = new cjs.Graphics().p("Al0F0IAArnILpAAIAALng");
	var mask_2_graphics_99 = new cjs.Graphics().p("Al7F0IAArnIL3AAIAALng");
	var mask_2_graphics_100 = new cjs.Graphics().p("AmBF0IAArnIMDAAIAALng");
	var mask_2_graphics_101 = new cjs.Graphics().p("AmIF0IAArnIMRAAIAALng");
	var mask_2_graphics_102 = new cjs.Graphics().p("AmPF0IAArnIMfAAIAALng");
	var mask_2_graphics_103 = new cjs.Graphics().p("AmVF0IAArnIMrAAIAALng");
	var mask_2_graphics_104 = new cjs.Graphics().p("AmcF0IAArnIM5AAIAALng");
	var mask_2_graphics_105 = new cjs.Graphics().p("AmjF0IAArnINHAAIAALng");
	var mask_2_graphics_106 = new cjs.Graphics().p("AmpF0IAArnINTAAIAALng");
	var mask_2_graphics_107 = new cjs.Graphics().p("AmwF0IAArnINhAAIAALng");
	var mask_2_graphics_108 = new cjs.Graphics().p("Am2F0IAArnINtAAIAALng");
	var mask_2_graphics_109 = new cjs.Graphics().p("Am9F0IAArnIN7AAIAALng");
	var mask_2_graphics_110 = new cjs.Graphics().p("AnEF0IAArnIOJAAIAALng");
	var mask_2_graphics_111 = new cjs.Graphics().p("AnKF0IAArnIOVAAIAALng");
	var mask_2_graphics_112 = new cjs.Graphics().p("AnRF0IAArnIOjAAIAALng");
	var mask_2_graphics_113 = new cjs.Graphics().p("AnXF0IAArnIOvAAIAALng");
	var mask_2_graphics_114 = new cjs.Graphics().p("AneF0IAArnIO9AAIAALng");
	var mask_2_graphics_115 = new cjs.Graphics().p("AnlF0IAArnIPLAAIAALng");
	var mask_2_graphics_116 = new cjs.Graphics().p("AnrF0IAArnIPXAAIAALng");
	var mask_2_graphics_117 = new cjs.Graphics().p("AnyF0IAArnIPlAAIAALng");
	var mask_2_graphics_118 = new cjs.Graphics().p("An5F0IAArnIPzAAIAALng");
	var mask_2_graphics_119 = new cjs.Graphics().p("An/F0IAArnIP/AAIAALng");
	var mask_2_graphics_120 = new cjs.Graphics().p("AoGF0IAArnIQNAAIAALng");
	var mask_2_graphics_121 = new cjs.Graphics().p("AoMF0IAArnIQZAAIAALng");
	var mask_2_graphics_122 = new cjs.Graphics().p("AoTF0IAArnIQnAAIAALng");
	var mask_2_graphics_123 = new cjs.Graphics().p("AoaF0IAArnIQ1AAIAALng");
	var mask_2_graphics_124 = new cjs.Graphics().p("AogF0IAArnIRBAAIAALng");
	var mask_2_graphics_125 = new cjs.Graphics().p("AonF0IAArnIRPAAIAALng");
	var mask_2_graphics_126 = new cjs.Graphics().p("AouF0IAArnIRdAAIAALng");
	var mask_2_graphics_127 = new cjs.Graphics().p("Ao0F0IAArnIRpAAIAALng");
	var mask_2_graphics_128 = new cjs.Graphics().p("Ao7F0IAArnIR3AAIAALng");
	var mask_2_graphics_129 = new cjs.Graphics().p("ApBF0IAArnISDAAIAALng");
	var mask_2_graphics_130 = new cjs.Graphics().p("ApIF0IAArnISRAAIAALng");
	var mask_2_graphics_131 = new cjs.Graphics().p("ApPF0IAArnISfAAIAALng");
	var mask_2_graphics_132 = new cjs.Graphics().p("ApVF0IAArnISrAAIAALng");
	var mask_2_graphics_133 = new cjs.Graphics().p("ApcF0IAArnIS5AAIAALng");
	var mask_2_graphics_134 = new cjs.Graphics().p("ApiF0IAArnITFAAIAALng");
	var mask_2_graphics_135 = new cjs.Graphics().p("AppF0IAArnITTAAIAALng");
	var mask_2_graphics_136 = new cjs.Graphics().p("ApwF0IAArnIThAAIAALng");
	var mask_2_graphics_137 = new cjs.Graphics().p("Ap2F0IAArnITtAAIAALng");
	var mask_2_graphics_138 = new cjs.Graphics().p("Ap9F0IAArnIT7AAIAALng");
	var mask_2_graphics_139 = new cjs.Graphics().p("AqEF0IAArnIUJAAIAALng");
	var mask_2_graphics_140 = new cjs.Graphics().p("AqKF0IAArnIUVAAIAALng");
	var mask_2_graphics_141 = new cjs.Graphics().p("AqRF0IAArnIUjAAIAALng");
	var mask_2_graphics_142 = new cjs.Graphics().p("AqXF0IAArnIUvAAIAALng");
	var mask_2_graphics_143 = new cjs.Graphics().p("AqeF0IAArnIU9AAIAALng");
	var mask_2_graphics_144 = new cjs.Graphics().p("AqlF0IAArnIVLAAIAALng");
	var mask_2_graphics_145 = new cjs.Graphics().p("AqrF0IAArnIVXAAIAALng");
	var mask_2_graphics_146 = new cjs.Graphics().p("AqyF0IAArnIVlAAIAALng");
	var mask_2_graphics_147 = new cjs.Graphics().p("Aq4F0IAArnIVxAAIAALng");
	var mask_2_graphics_148 = new cjs.Graphics().p("Aq/F0IAArnIV/AAIAALng");
	var mask_2_graphics_149 = new cjs.Graphics().p("ArGF0IAArnIWNAAIAALng");
	var mask_2_graphics_150 = new cjs.Graphics().p("ArMF0IAArnIWZAAIAALng");
	var mask_2_graphics_151 = new cjs.Graphics().p("ArTF0IAArnIWnAAIAALng");
	var mask_2_graphics_152 = new cjs.Graphics().p("AraF0IAArnIW1AAIAALng");
	var mask_2_graphics_153 = new cjs.Graphics().p("ArgF0IAArnIXBAAIAALng");
	var mask_2_graphics_154 = new cjs.Graphics().p("ArnF0IAArnIXPAAIAALng");
	var mask_2_graphics_155 = new cjs.Graphics().p("ArtF0IAArnIXbAAIAALng");
	var mask_2_graphics_156 = new cjs.Graphics().p("Ar0F0IAArnIXpAAIAALng");
	var mask_2_graphics_157 = new cjs.Graphics().p("Ar7F0IAArnIX3AAIAALng");
	var mask_2_graphics_158 = new cjs.Graphics().p("AsBF0IAArnIYDAAIAALng");
	var mask_2_graphics_159 = new cjs.Graphics().p("AsIF0IAArnIYRAAIAALng");
	var mask_2_graphics_160 = new cjs.Graphics().p("AsOF0IAArnIYdAAIAALng");
	var mask_2_graphics_161 = new cjs.Graphics().p("AsVF0IAArnIYrAAIAALng");
	var mask_2_graphics_162 = new cjs.Graphics().p("AscF0IAArnIY5AAIAALng");
	var mask_2_graphics_163 = new cjs.Graphics().p("AsiF0IAArnIZFAAIAALng");
	var mask_2_graphics_164 = new cjs.Graphics().p("AspF0IAArnIZTAAIAALng");
	var mask_2_graphics_165 = new cjs.Graphics().p("AswF0IAArnIZhAAIAALng");
	var mask_2_graphics_166 = new cjs.Graphics().p("As2F0IAArnIZtAAIAALng");
	var mask_2_graphics_167 = new cjs.Graphics().p("As9F0IAArnIZ7AAIAALng");
	var mask_2_graphics_168 = new cjs.Graphics().p("AtDF0IAArnIaHAAIAALng");
	var mask_2_graphics_169 = new cjs.Graphics().p("AtKF0IAArnIaVAAIAALng");
	var mask_2_graphics_170 = new cjs.Graphics().p("AtRF0IAArnIajAAIAALng");
	var mask_2_graphics_171 = new cjs.Graphics().p("AtXF0IAArnIavAAIAALng");
	var mask_2_graphics_172 = new cjs.Graphics().p("AteF0IAArnIa9AAIAALng");
	var mask_2_graphics_173 = new cjs.Graphics().p("AtlF0IAArnIbKAAIAALng");
	var mask_2_graphics_174 = new cjs.Graphics().p("AtrF0IAArnIbXAAIAALng");
	var mask_2_graphics_175 = new cjs.Graphics().p("AtyF0IAArnIblAAIAALng");
	var mask_2_graphics_176 = new cjs.Graphics().p("At4F0IAArnIbxAAIAALng");
	var mask_2_graphics_177 = new cjs.Graphics().p("At/F0IAArnIb/AAIAALng");
	var mask_2_graphics_178 = new cjs.Graphics().p("AuGF0IAArnIcNAAIAALng");
	var mask_2_graphics_179 = new cjs.Graphics().p("AuMF0IAArnIcZAAIAALng");
	var mask_2_graphics_180 = new cjs.Graphics().p("AuTF0IAArnIcnAAIAALng");
	var mask_2_graphics_181 = new cjs.Graphics().p("AuZF0IAArnIczAAIAALng");
	var mask_2_graphics_182 = new cjs.Graphics().p("AugF0IAArnIdBAAIAALng");
	var mask_2_graphics_183 = new cjs.Graphics().p("AunF0IAArnIdPAAIAALng");
	var mask_2_graphics_184 = new cjs.Graphics().p("AutF0IAArnIdbAAIAALng");
	var mask_2_graphics_185 = new cjs.Graphics().p("Au0F0IAArnIdpAAIAALng");
	var mask_2_graphics_186 = new cjs.Graphics().p("Au7F0IAArnId3AAIAALng");
	var mask_2_graphics_187 = new cjs.Graphics().p("AvBF0IAArnIeDAAIAALng");
	var mask_2_graphics_188 = new cjs.Graphics().p("AvIF0IAArnIeRAAIAALng");
	var mask_2_graphics_189 = new cjs.Graphics().p("AvOF0IAArnIedAAIAALng");
	var mask_2_graphics_190 = new cjs.Graphics().p("AvVF0IAArnIerAAIAALng");
	var mask_2_graphics_191 = new cjs.Graphics().p("AvcF0IAArnIe5AAIAALng");
	var mask_2_graphics_192 = new cjs.Graphics().p("AviF0IAArnIfFAAIAALng");
	var mask_2_graphics_193 = new cjs.Graphics().p("AvpF0IAArnIfTAAIAALng");
	var mask_2_graphics_194 = new cjs.Graphics().p("AvvF0IAArnIffAAIAALng");
	var mask_2_graphics_195 = new cjs.Graphics().p("Av2F0IAArnIftAAIAALng");
	var mask_2_graphics_196 = new cjs.Graphics().p("Av9F0IAArnIf7AAIAALng");
	var mask_2_graphics_197 = new cjs.Graphics().p("AwDF0IAArnMAgHAAAIAALng");
	var mask_2_graphics_198 = new cjs.Graphics().p("AwKF0IAArnMAgVAAAIAALng");
	var mask_2_graphics_199 = new cjs.Graphics().p("AwRF0IAArnMAgjAAAIAALng");
	var mask_2_graphics_200 = new cjs.Graphics().p("AwXF0IAArnMAgvAAAIAALng");
	var mask_2_graphics_201 = new cjs.Graphics().p("AweF0IAArnMAg9AAAIAALng");
	var mask_2_graphics_202 = new cjs.Graphics().p("AwkF0IAArnMAhJAAAIAALng");
	var mask_2_graphics_203 = new cjs.Graphics().p("AwrF0IAArnMAhXAAAIAALng");
	var mask_2_graphics_204 = new cjs.Graphics().p("AwyF0IAArnMAhlAAAIAALng");
	var mask_2_graphics_205 = new cjs.Graphics().p("Aw4F0IAArnMAhxAAAIAALng");
	var mask_2_graphics_206 = new cjs.Graphics().p("Aw/F0IAArnMAh/AAAIAALng");
	var mask_2_graphics_207 = new cjs.Graphics().p("AxFF0IAArnMAiLAAAIAALng");
	var mask_2_graphics_208 = new cjs.Graphics().p("AxMF0IAArnMAiZAAAIAALng");
	var mask_2_graphics_209 = new cjs.Graphics().p("AxTF0IAArnMAinAAAIAALng");
	var mask_2_graphics_210 = new cjs.Graphics().p("AxZF0IAArnMAizAAAIAALng");
	var mask_2_graphics_211 = new cjs.Graphics().p("AxgF0IAArnMAjBAAAIAALng");
	var mask_2_graphics_212 = new cjs.Graphics().p("AxnF0IAArnMAjPAAAIAALng");
	var mask_2_graphics_213 = new cjs.Graphics().p("AxtF0IAArnMAjbAAAIAALng");
	var mask_2_graphics_214 = new cjs.Graphics().p("Ax0F0IAArnMAjpAAAIAALng");
	var mask_2_graphics_215 = new cjs.Graphics().p("Ax6F0IAArnMAj1AAAIAALng");
	var mask_2_graphics_216 = new cjs.Graphics().p("AyBF0IAArnMAkDAAAIAALng");
	var mask_2_graphics_217 = new cjs.Graphics().p("AyIF0IAArnMAkRAAAIAALng");
	var mask_2_graphics_218 = new cjs.Graphics().p("AyOF0IAArnMAkdAAAIAALng");
	var mask_2_graphics_219 = new cjs.Graphics().p("AyVF0IAArnMAkrAAAIAALng");
	var mask_2_graphics_220 = new cjs.Graphics().p("AybF0IAArnMAk4AAAIAALng");
	var mask_2_graphics_221 = new cjs.Graphics().p("AyiF0IAArnMAlFAAAIAALng");
	var mask_2_graphics_222 = new cjs.Graphics().p("AypF0IAArnMAlTAAAIAALng");
	var mask_2_graphics_223 = new cjs.Graphics().p("AyvF0IAArnMAlfAAAIAALng");
	var mask_2_graphics_224 = new cjs.Graphics().p("Ay2F0IAArnMAltAAAIAALng");
	var mask_2_graphics_225 = new cjs.Graphics().p("Ay9F0IAArnMAl7AAAIAALng");
	var mask_2_graphics_226 = new cjs.Graphics().p("AzDF0IAArnMAmHAAAIAALng");
	var mask_2_graphics_227 = new cjs.Graphics().p("AzKF0IAArnMAmVAAAIAALng");
	var mask_2_graphics_228 = new cjs.Graphics().p("AzQF0IAArnMAmhAAAIAALng");
	var mask_2_graphics_229 = new cjs.Graphics().p("AzXF0IAArnMAmvAAAIAALng");
	var mask_2_graphics_230 = new cjs.Graphics().p("AzeF0IAArnMAm9AAAIAALng");
	var mask_2_graphics_231 = new cjs.Graphics().p("AzkF0IAArnMAnJAAAIAALng");
	var mask_2_graphics_232 = new cjs.Graphics().p("AzrF0IAArnMAnXAAAIAALng");
	var mask_2_graphics_233 = new cjs.Graphics().p("AzyF0IAArnMAnlAAAIAALng");
	var mask_2_graphics_234 = new cjs.Graphics().p("Az4F0IAArnMAnxAAAIAALng");
	var mask_2_graphics_235 = new cjs.Graphics().p("AQmggIAArpMAoAAAAIAALpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(49).to({graphics:mask_2_graphics_49,x:473.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_50,x:474.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_51,x:474.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_52,x:475.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_53,x:476,y:-118.3}).wait(1).to({graphics:mask_2_graphics_54,x:476.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_55,x:477.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_56,x:478,y:-118.3}).wait(1).to({graphics:mask_2_graphics_57,x:478.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_58,x:479.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_59,x:480,y:-118.3}).wait(1).to({graphics:mask_2_graphics_60,x:480.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_61,x:481.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_62,x:482,y:-118.3}).wait(1).to({graphics:mask_2_graphics_63,x:482.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_64,x:483.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_65,x:484,y:-118.3}).wait(1).to({graphics:mask_2_graphics_66,x:484.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_67,x:485.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_68,x:486,y:-118.3}).wait(1).to({graphics:mask_2_graphics_69,x:486.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_70,x:487.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_71,x:488,y:-118.3}).wait(1).to({graphics:mask_2_graphics_72,x:488.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_73,x:489.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_74,x:489.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_75,x:490.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_76,x:491.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_77,x:491.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_78,x:492.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_79,x:493.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_80,x:493.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_81,x:494.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_82,x:495.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_83,x:495.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_84,x:496.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_85,x:497.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_86,x:497.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_87,x:498.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_88,x:499.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_89,x:499.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_90,x:500.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_91,x:501.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_92,x:501.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_93,x:502.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_94,x:503.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_95,x:503.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_96,x:504.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_97,x:505.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_98,x:505.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_99,x:506.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_100,x:507.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_101,x:507.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_102,x:508.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_103,x:509.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_104,x:509.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_105,x:510.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_106,x:511.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_107,x:511.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_108,x:512.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_109,x:513.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_110,x:513.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_111,x:514.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_112,x:515.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_113,x:515.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_114,x:516.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_115,x:517.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_116,x:517.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_117,x:518.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_118,x:519.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_119,x:519.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_120,x:520.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_121,x:521,y:-118.3}).wait(1).to({graphics:mask_2_graphics_122,x:521.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_123,x:522.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_124,x:523,y:-118.3}).wait(1).to({graphics:mask_2_graphics_125,x:523.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_126,x:524.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_127,x:525,y:-118.3}).wait(1).to({graphics:mask_2_graphics_128,x:525.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_129,x:526.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_130,x:527,y:-118.3}).wait(1).to({graphics:mask_2_graphics_131,x:527.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_132,x:528.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_133,x:529,y:-118.3}).wait(1).to({graphics:mask_2_graphics_134,x:529.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_135,x:530.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_136,x:531,y:-118.3}).wait(1).to({graphics:mask_2_graphics_137,x:531.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_138,x:532.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_139,x:533,y:-118.3}).wait(1).to({graphics:mask_2_graphics_140,x:533.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_141,x:534.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_142,x:534.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_143,x:535.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_144,x:536.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_145,x:536.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_146,x:537.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_147,x:538.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_148,x:538.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_149,x:539.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_150,x:540.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_151,x:540.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_152,x:541.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_153,x:542.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_154,x:542.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_155,x:543.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_156,x:544.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_157,x:544.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_158,x:545.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_159,x:546.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_160,x:546.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_161,x:547.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_162,x:548.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_163,x:548.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_164,x:549.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_165,x:550.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_166,x:550.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_167,x:551.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_168,x:552.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_169,x:552.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_170,x:553.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_171,x:554.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_172,x:554.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_173,x:555.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_174,x:556.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_175,x:556.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_176,x:557.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_177,x:558.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_178,x:558.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_179,x:559.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_180,x:560.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_181,x:560.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_182,x:561.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_183,x:562.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_184,x:562.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_185,x:563.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_186,x:564.1,y:-118.3}).wait(1).to({graphics:mask_2_graphics_187,x:564.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_188,x:565.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_189,x:566,y:-118.3}).wait(1).to({graphics:mask_2_graphics_190,x:566.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_191,x:567.4,y:-118.3}).wait(1).to({graphics:mask_2_graphics_192,x:568,y:-118.3}).wait(1).to({graphics:mask_2_graphics_193,x:568.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_194,x:569.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_195,x:570,y:-118.3}).wait(1).to({graphics:mask_2_graphics_196,x:570.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_197,x:571.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_198,x:572,y:-118.3}).wait(1).to({graphics:mask_2_graphics_199,x:572.7,y:-118.3}).wait(1).to({graphics:mask_2_graphics_200,x:573.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_201,x:574,y:-118.3}).wait(1).to({graphics:mask_2_graphics_202,x:574.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_203,x:575.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_204,x:576,y:-118.3}).wait(1).to({graphics:mask_2_graphics_205,x:576.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_206,x:577.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_207,x:577.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_208,x:578.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_209,x:579.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_210,x:579.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_211,x:580.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_212,x:581.3,y:-118.3}).wait(1).to({graphics:mask_2_graphics_213,x:581.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_214,x:582.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_215,x:583.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_216,x:583.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_217,x:584.6,y:-118.3}).wait(1).to({graphics:mask_2_graphics_218,x:585.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_219,x:585.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_220,x:586.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_221,x:587.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_222,x:587.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_223,x:588.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_224,x:589.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_225,x:589.9,y:-118.3}).wait(1).to({graphics:mask_2_graphics_226,x:590.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_227,x:591.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_228,x:591.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_229,x:592.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_230,x:593.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_231,x:593.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_232,x:594.5,y:-118.3}).wait(1).to({graphics:mask_2_graphics_233,x:595.2,y:-118.3}).wait(1).to({graphics:mask_2_graphics_234,x:595.8,y:-118.3}).wait(1).to({graphics:mask_2_graphics_235,x:362.3,y:-77.7}).wait(589));

	// 1a_Formula
	this.text_16 = new cjs.Text("A\"B\"", "italic 20px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 20;
	this.text_16.lineWidth = 51;
	this.text_16.setTransform(678.1,-147.5+incremento);

	this.text_17 = new cjs.Text("A\"C", "italic 20px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 20;
	this.text_17.lineWidth = 45;
	this.text_17.setTransform(678.1,-115.3+incremento);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_24.setTransform(680.1,-117.4,1.19,1);

	this.text_18 = new cjs.Text("A'C", "italic 20px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 20;
	this.text_18.lineWidth = 45;
	this.text_18.setTransform(588.3,-115.3+incremento);

	this.text_19 = new cjs.Text("=", "20px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 20;
	this.text_19.lineWidth = 16;
	this.text_19.setTransform(631.5,-133.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_25.setTransform(590.3,-117.4,1.19,1);

	this.text_20 = new cjs.Text("A'B'", "italic 20px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 20;
	this.text_20.lineWidth = 45;
	this.text_20.setTransform(588.3,-147.5+incremento);

	this.text_21 = new cjs.Text("=", "20px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 20;
	this.text_21.lineWidth = 16;
	this.text_21.setTransform(543.9,-133);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,1,1).p("AjoAAIHRAA");
	this.shape_26.setTransform(506.5,-117.4);

	this.text_22 = new cjs.Text("AC", "italic 20px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 20;
	this.text_22.lineWidth = 38;
	this.text_22.setTransform(504.5,-115.3+incremento);

	this.text_23 = new cjs.Text("AB", "italic 20px Verdana");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 20;
	this.text_23.lineWidth = 38;
	this.text_23.setTransform(504.5,-147.5+incremento);

	this.text_16.mask = this.text_17.mask = this.shape_24.mask = this.text_18.mask = this.text_19.mask = this.shape_25.mask = this.text_20.mask = this.text_21.mask = this.shape_26.mask = this.text_22.mask = this.text_23.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_23},{t:this.text_22},{t:this.shape_26},{t:this.text_21},{t:this.text_20},{t:this.shape_25},{t:this.text_19},{t:this.text_18},{t:this.shape_24},{t:this.text_17},{t:this.text_16}]},49).wait(775));

	// Letras
	this.instance_1 = new lib.mc_letras();
	this.instance_1.setTransform(154.4,-35.1,1,1,0,0,0,172.3,117.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({_off:false},0).wait(1).to({alpha:0.067},0).wait(1).to({alpha:0.133},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.267},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.467},0).wait(1).to({alpha:0.533},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.733},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.867},0).wait(1).to({alpha:0.933},0).wait(1).to({alpha:1},0).wait(791));

	// Vertical_3
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape_27.setTransform(307.2,-35.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27}]}).wait(824));

	// Vertical_2
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,1,1).p("AAAKdIAA05");
	this.shape_28.setTransform(226.5,-11.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28}]}).wait(824));

	// Vertical_1
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(2,1,1).p("AAAFSIAAqj");
	this.shape_29.setTransform(115.9,21.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29}]}).wait(824));

	// Angulo
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_30.setTransform(154.5,-35.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_30}]}).wait(824));

	// Base
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_31.setTransform(154.9,55.5,1.065,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31}]}).wait(824));

	// Alfa
	this.text_24 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 20;
	this.text_24.lineWidth = 10;
	this.text_24.setTransform(36,32.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_32.setTransform(17.2,47.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_33.setTransform(17.2,47.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32},{t:this.text_24}]}).wait(824));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.5,-127.3,304.8,188.6);


(lib.mc_g2_03 = function() {
	this.initialize();

	// Capa 1
	this.mc_g2_03 = new cjs.Text("¿Crees que el valor de la tangente cambiará si hacemos más pequeño o más grande el triángulo rectángulo?", "23px Verdana");
	this.mc_g2_03.lineHeight = 25;
	this.mc_g2_03.lineWidth = 785;
	this.mc_g2_03.setTransform(0,-3.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg9iAFxIAArhMB7FAAAIAALhg");
	this.shape.setTransform(393.1,27.1);

	this.addChild(this.shape,this.mc_g2_03);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,-9.8,789.9,76.4);


(lib.mc_g2_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("4", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 13;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 13;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325.1,214.9);


(lib.mc_g1_02 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("ß", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 12;
	this.text_3.setTransform(285.6,27.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ABSgwQBNBVgWBTIkVgEICNjrIAaATQAfAZAYAbg");
	this.shape_3.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiMB0ICNjrIAaATQAfAZAYAbQBNBVgWBTg");
	this.shape_4.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_g1_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_g0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.PegatinaRosa();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,515.5,375);


(lib.mc_h2_03 = function() {
	this.initialize();

	// Capa 1
	this.mc_h2_03 = new cjs.Text("¿Crees que el valor del coseno cambiará si hacemos más pequeño o más grande el triángulo rectángulo?", "23px Verdana");
	this.mc_h2_03.lineHeight = 25;
	this.mc_h2_03.lineWidth = 785;
	this.mc_h2_03.setTransform(0,-3.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg9iAFxIAArhMB7FAAAIAALhg");
	this.shape.setTransform(393.1,27.1);

	this.addChild(this.shape,this.mc_h2_03);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,-9.8,789.9,75.9);


(lib.mc_h2_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("4", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 13;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 13;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325.1,214.9);


(lib.mc_h1_02 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("ß", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 12;
	this.text_3.setTransform(285.6,27.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ABSgwQBNBVgWBTIkVgEICNjrIAaATQAfAZAYAbg");
	this.shape_3.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiMB0ICNjrIAaATQAfAZAYAbQBNBVgWBTg");
	this.shape_4.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_h1_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_h0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.PegatinaAmarilla();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,515.5,375);


(lib.mc_f2_03 = function() {
	this.initialize();

	// Capa 1
	this.mc_f2_03 = new cjs.Text(txt['mc_f2_03'], "23px Verdana");
	this.mc_f2_03.lineHeight = 25;
	this.mc_f2_03.lineWidth = 743;
	this.mc_f2_03.setTransform(40,-30);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg9iAFxIAArhMB7FAAAIAALhg");
	this.shape.setTransform(393.1,27.1);

	this.addChild(this.shape,this.mc_f2_03);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,-9.8,788,73.9);


(lib.mc_f2_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("4", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 13;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 13;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,325.1,214.9);


(lib.mc_f1_02 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("ß", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 12;
	this.text_3.setTransform(284.6,29.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ABSgwQBNBVgWBTIkVgEICNjrIAaATQAfAZAYAbg");
	this.shape_3.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiMB0ICNjrIAaATQAfAZAYAbQBNBVgWBTg");
	this.shape_4.setTransform(292.3,14.5,1,1,0,-89.9,90);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_f1_01 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("c", "italic 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 12;
	this.text.setTransform(158.6,186.6);

	this.text_1 = new cjs.Text("b", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 12;
	this.text_1.setTransform(308.4,77.2);

	this.text_2 = new cjs.Text("a", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 12;
	this.text_2.setTransform(157.2,45.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape.setTransform(304.7,91.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_1.setTransform(152,91.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_2.setTransform(152.4,182.8,1.065,1);

	this.text_3 = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 10;
	this.text_3.setTransform(38.3,159.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_3.setTransform(14.7,175.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_4.setTransform(14.7,175.1);

	this.addChild(this.shape_4,this.shape_3,this.text_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,324.8,214.9);


(lib.mc_f0 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.PegatinaVerde();
	this.instance.setTransform(0,0,0.5,0.5);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,515.5,375);


(lib.mc_p2_01 = function() {
	this.initialize();

	// Capa 1
	this.mc_p2_01 = new cjs.Text('', "20px Verdana");
	this.mc_p2_01.lineHeight = 20;
	this.mc_p2_01.lineWidth = 785;

	this.addChild(this.mc_p2_01);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,789.4,61.1);


(lib.mc_letras = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("A\"", "italic 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 31;
	this.text.setTransform(324.8,0);

	this.text_1 = new cjs.Text("A'", "italic 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 23;
	this.text_1.setTransform(242.7,45.1);

	this.text_2 = new cjs.Text("A", "italic 20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 14;
	this.text_2.setTransform(132.1,110);

	this.text_3 = new cjs.Text("B\"", "italic 20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 31;
	this.text_3.setTransform(324.8,207.5);

	this.text_4 = new cjs.Text("B'", "italic 20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 23;
	this.text_4.setTransform(242.7,207.5);

	this.text_5 = new cjs.Text("B", "italic 20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.lineWidth = 14;
	this.text_5.setTransform(132.1,207.5);

	this.text_6 = new cjs.Text("C", "italic 20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.lineWidth = 14;
	this.text_6.setTransform(7,194.2);

	this.addChild(this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,344.5,235.8);


(lib.mc_p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiCR7MAAAgj1ICgAAMAAAAj1g");
	var mask_graphics_1 = new cjs.Graphics().p("Ah1R8MAAAgj2IDrAAMAAAAj2g");
	var mask_graphics_2 = new cjs.Graphics().p("AiaR8MAAAgj2IE1AAMAAAAj2g");
	var mask_graphics_3 = new cjs.Graphics().p("AjAR8MAAAgj2IGBAAMAAAAj2g");
	var mask_graphics_4 = new cjs.Graphics().p("AjlR8MAAAgj2IHLAAMAAAAj2g");
	var mask_graphics_5 = new cjs.Graphics().p("AkKR8MAAAgj2IIVAAMAAAAj2g");
	var mask_graphics_6 = new cjs.Graphics().p("AkvR8MAAAgj2IJfAAMAAAAj2g");
	var mask_graphics_7 = new cjs.Graphics().p("AlVR8MAAAgj2IKrAAMAAAAj2g");
	var mask_graphics_8 = new cjs.Graphics().p("Al6R8MAAAgj2IL1AAMAAAAj2g");
	var mask_graphics_9 = new cjs.Graphics().p("AmfR8MAAAgj2IM/AAMAAAAj2g");
	var mask_graphics_10 = new cjs.Graphics().p("AnFR8MAAAgj2IOLAAMAAAAj2g");
	var mask_graphics_11 = new cjs.Graphics().p("AnqR8MAAAgj2IPVAAMAAAAj2g");
	var mask_graphics_12 = new cjs.Graphics().p("AoPR8MAAAgj2IQfAAMAAAAj2g");
	var mask_graphics_13 = new cjs.Graphics().p("Ao0R8MAAAgj2IRpAAMAAAAj2g");
	var mask_graphics_14 = new cjs.Graphics().p("ApaR8MAAAgj2IS1AAMAAAAj2g");
	var mask_graphics_15 = new cjs.Graphics().p("Ap/R8MAAAgj2IT/AAMAAAAj2g");
	var mask_graphics_16 = new cjs.Graphics().p("AqkR8MAAAgj2IVJAAMAAAAj2g");
	var mask_graphics_17 = new cjs.Graphics().p("ArKR8MAAAgj2IWVAAMAAAAj2g");
	var mask_graphics_18 = new cjs.Graphics().p("ArvR8MAAAgj2IXfAAMAAAAj2g");
	var mask_graphics_19 = new cjs.Graphics().p("AsUR8MAAAgj2IYpAAMAAAAj2g");
	var mask_graphics_20 = new cjs.Graphics().p("As5R8MAAAgj2IZzAAMAAAAj2g");
	var mask_graphics_21 = new cjs.Graphics().p("AtfR8MAAAgj2Ia/AAMAAAAj2g");
	var mask_graphics_22 = new cjs.Graphics().p("AuER8MAAAgj2IcJAAMAAAAj2g");
	var mask_graphics_23 = new cjs.Graphics().p("AupR8MAAAgj2IdTAAMAAAAj2g");
	var mask_graphics_24 = new cjs.Graphics().p("AvPR8MAAAgj2IefAAMAAAAj2g");
	var mask_graphics_25 = new cjs.Graphics().p("Av0R8MAAAgj2IfpAAMAAAAj2g");
	var mask_graphics_26 = new cjs.Graphics().p("AwZR8MAAAgj2MAgzAAAMAAAAj2g");
	var mask_graphics_27 = new cjs.Graphics().p("Aw+R8MAAAgj2MAh9AAAMAAAAj2g");
	var mask_graphics_28 = new cjs.Graphics().p("AxkR8MAAAgj2MAjJAAAMAAAAj2g");
	var mask_graphics_29 = new cjs.Graphics().p("AyJR8MAAAgj2MAkTAAAMAAAAj2g");
	var mask_graphics_30 = new cjs.Graphics().p("AyuR8MAAAgj2MAldAAAMAAAAj2g");
	var mask_graphics_31 = new cjs.Graphics().p("AzUR8MAAAgj2MAmpAAAMAAAAj2g");
	var mask_graphics_32 = new cjs.Graphics().p("Az5R8MAAAgj2MAnzAAAMAAAAj2g");
	var mask_graphics_33 = new cjs.Graphics().p("A0eR8MAAAgj2MAo9AAAMAAAAj2g");
	var mask_graphics_34 = new cjs.Graphics().p("A1DR8MAAAgj2MAqHAAAMAAAAj2g");
	var mask_graphics_35 = new cjs.Graphics().p("A1pR8MAAAgj2MArTAAAMAAAAj2g");
	var mask_graphics_36 = new cjs.Graphics().p("A2OR8MAAAgj2MAsdAAAMAAAAj2g");
	var mask_graphics_37 = new cjs.Graphics().p("A2zR8MAAAgj2MAtnAAAMAAAAj2g");
	var mask_graphics_38 = new cjs.Graphics().p("A3YR8MAAAgj2MAuxAAAMAAAAj2g");
	var mask_graphics_39 = new cjs.Graphics().p("A3+R8MAAAgj2MAv9AAAMAAAAj2g");
	var mask_graphics_40 = new cjs.Graphics().p("A4jR8MAAAgj2MAxHAAAMAAAAj2g");
	var mask_graphics_41 = new cjs.Graphics().p("A5IR8MAAAgj2MAyRAAAMAAAAj2g");
	var mask_graphics_42 = new cjs.Graphics().p("A5uR8MAAAgj2MAzdAAAMAAAAj2g");
	var mask_graphics_43 = new cjs.Graphics().p("A6TR8MAAAgj2MA0nAAAMAAAAj2g");
	var mask_graphics_44 = new cjs.Graphics().p("A64R8MAAAgj2MA1xAAAMAAAAj2g");
	var mask_graphics_45 = new cjs.Graphics().p("A7dR8MAAAgj2MA27AAAMAAAAj2g");
	var mask_graphics_46 = new cjs.Graphics().p("A8DR8MAAAgj2MA4HAAAMAAAAj2g");
	var mask_graphics_47 = new cjs.Graphics().p("A8oR8MAAAgj2MA5RAAAMAAAAj2g");
	var mask_graphics_48 = new cjs.Graphics().p("A9NR8MAAAgj2MA6bAAAMAAAAj2g");
	var mask_graphics_49 = new cjs.Graphics().p("A9zR8MAAAgj2MA7nAAAMAAAAj2g");
	var mask_graphics_50 = new cjs.Graphics().p("A+YR8MAAAgj2MA8xAAAMAAAAj2g");
	var mask_graphics_51 = new cjs.Graphics().p("A+9R8MAAAgj2MA97AAAMAAAAj2g");
	var mask_graphics_52 = new cjs.Graphics().p("A/iR8MAAAgj2MA/FAAAMAAAAj2g");
	var mask_graphics_53 = new cjs.Graphics().p("EggIAR8MAAAgj2MBARAAAMAAAAj2g");
	var mask_graphics_54 = new cjs.Graphics().p("EggtAR7MAAAgj1MBBbAAAMAAAAj1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-13.1,y:-32.5}).wait(1).to({graphics:mask_graphics_1,x:-14.3,y:-32.6}).wait(1).to({graphics:mask_graphics_2,x:-10.6,y:-32.6}).wait(1).to({graphics:mask_graphics_3,x:-6.9,y:-32.6}).wait(1).to({graphics:mask_graphics_4,x:-3.2,y:-32.6}).wait(1).to({graphics:mask_graphics_5,x:0.5,y:-32.6}).wait(1).to({graphics:mask_graphics_6,x:4.2,y:-32.6}).wait(1).to({graphics:mask_graphics_7,x:7.9,y:-32.6}).wait(1).to({graphics:mask_graphics_8,x:11.7,y:-32.6}).wait(1).to({graphics:mask_graphics_9,x:15.4,y:-32.6}).wait(1).to({graphics:mask_graphics_10,x:19.1,y:-32.6}).wait(1).to({graphics:mask_graphics_11,x:22.8,y:-32.6}).wait(1).to({graphics:mask_graphics_12,x:26.6,y:-32.6}).wait(1).to({graphics:mask_graphics_13,x:30.3,y:-32.6}).wait(1).to({graphics:mask_graphics_14,x:34,y:-32.6}).wait(1).to({graphics:mask_graphics_15,x:37.7,y:-32.6}).wait(1).to({graphics:mask_graphics_16,x:41.5,y:-32.6}).wait(1).to({graphics:mask_graphics_17,x:45.2,y:-32.6}).wait(1).to({graphics:mask_graphics_18,x:48.9,y:-32.6}).wait(1).to({graphics:mask_graphics_19,x:52.7,y:-32.6}).wait(1).to({graphics:mask_graphics_20,x:56.4,y:-32.6}).wait(1).to({graphics:mask_graphics_21,x:60.1,y:-32.6}).wait(1).to({graphics:mask_graphics_22,x:63.8,y:-32.6}).wait(1).to({graphics:mask_graphics_23,x:67.6,y:-32.6}).wait(1).to({graphics:mask_graphics_24,x:71.3,y:-32.6}).wait(1).to({graphics:mask_graphics_25,x:75,y:-32.6}).wait(1).to({graphics:mask_graphics_26,x:78.8,y:-32.6}).wait(1).to({graphics:mask_graphics_27,x:82.5,y:-32.6}).wait(1).to({graphics:mask_graphics_28,x:86.2,y:-32.6}).wait(1).to({graphics:mask_graphics_29,x:89.9,y:-32.6}).wait(1).to({graphics:mask_graphics_30,x:93.7,y:-32.6}).wait(1).to({graphics:mask_graphics_31,x:97.4,y:-32.6}).wait(1).to({graphics:mask_graphics_32,x:101.1,y:-32.6}).wait(1).to({graphics:mask_graphics_33,x:104.9,y:-32.6}).wait(1).to({graphics:mask_graphics_34,x:108.6,y:-32.6}).wait(1).to({graphics:mask_graphics_35,x:112.3,y:-32.6}).wait(1).to({graphics:mask_graphics_36,x:116,y:-32.6}).wait(1).to({graphics:mask_graphics_37,x:119.8,y:-32.6}).wait(1).to({graphics:mask_graphics_38,x:123.5,y:-32.6}).wait(1).to({graphics:mask_graphics_39,x:127.2,y:-32.6}).wait(1).to({graphics:mask_graphics_40,x:131,y:-32.6}).wait(1).to({graphics:mask_graphics_41,x:134.7,y:-32.6}).wait(1).to({graphics:mask_graphics_42,x:138.4,y:-32.6}).wait(1).to({graphics:mask_graphics_43,x:142.1,y:-32.6}).wait(1).to({graphics:mask_graphics_44,x:145.9,y:-32.6}).wait(1).to({graphics:mask_graphics_45,x:149.6,y:-32.6}).wait(1).to({graphics:mask_graphics_46,x:153.3,y:-32.6}).wait(1).to({graphics:mask_graphics_47,x:157.1,y:-32.6}).wait(1).to({graphics:mask_graphics_48,x:160.8,y:-32.6}).wait(1).to({graphics:mask_graphics_49,x:164.5,y:-32.6}).wait(1).to({graphics:mask_graphics_50,x:168.2,y:-32.6}).wait(1).to({graphics:mask_graphics_51,x:172,y:-32.6}).wait(1).to({graphics:mask_graphics_52,x:175.7,y:-32.6}).wait(1).to({graphics:mask_graphics_53,x:179.4,y:-32.6}).wait(1).to({graphics:mask_graphics_54,x:183.1,y:-32.5}).wait(196));

	// Vertical_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAAcIAAg3");
	this.shape.setTransform(307.1,52.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AAAAFIAAgJ");
	this.shape_1.setTransform(307.1,49.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AAAAnIAAhN");
	this.shape_2.setTransform(307.1,46.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAABIIAAiP");
	this.shape_3.setTransform(307.1,43);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AAABqIAAjT");
	this.shape_4.setTransform(307.1,39.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AAACLIAAkV");
	this.shape_5.setTransform(307.1,36.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("AAACtIAAlZ");
	this.shape_6.setTransform(307.1,33.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AAADPIAAmd");
	this.shape_7.setTransform(307.1,30.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AAADwIAAnf");
	this.shape_8.setTransform(307.1,27.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("AAAESIAAoj");
	this.shape_9.setTransform(307.1,24.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AAAE0IAApn");
	this.shape_10.setTransform(307.1,20.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AAAFVIAAqp");
	this.shape_11.setTransform(307.1,17.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("AAAF3IAArt");
	this.shape_12.setTransform(307.1,14.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AAAGYIAAsv");
	this.shape_13.setTransform(307.1,11.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("AAAG6IAAtz");
	this.shape_14.setTransform(307.2,8.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,1,1).p("AAAHcIAAu3");
	this.shape_15.setTransform(307.2,5.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,1,1).p("AAAH9IAAv5");
	this.shape_16.setTransform(307.2,1.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,1,1).p("AAAIfIAAw9");
	this.shape_17.setTransform(307.2,-1.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("AAAJBIAAyB");
	this.shape_18.setTransform(307.2,-4.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,1,1).p("AAAJiIAAzD");
	this.shape_19.setTransform(307.2,-7.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,1,1).p("AAAKEIAA0H");
	this.shape_20.setTransform(307.2,-10.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,1,1).p("AAAKmIAA1L");
	this.shape_21.setTransform(307.2,-13.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,1,1).p("AAALHIAA2N");
	this.shape_22.setTransform(307.2,-16.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,1,1).p("AAALpIAA3R");
	this.shape_23.setTransform(307.2,-20.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,1,1).p("AAAMKIAA4T");
	this.shape_24.setTransform(307.2,-23.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,1,1).p("AAAMsIAA5X");
	this.shape_25.setTransform(307.2,-26.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,1,1).p("AAANOIAA6b");
	this.shape_26.setTransform(307.2,-29.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(2,1,1).p("AAANvIAA7d");
	this.shape_27.setTransform(307.2,-32.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,1,1).p("AAAORIAA8h");
	this.shape_28.setTransform(307.2,-35.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},176).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).wait(46));

	// Vertical_2
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(2,1,1).p("AAAAcIAAg3");
	this.shape_29.setTransform(226.6,52.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(2,1,1).p("AAAgwIAABh");
	this.shape_30.setTransform(226.6,50.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(2,1,1).p("AAAhFIAACL");
	this.shape_31.setTransform(226.6,48.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(2,1,1).p("AAAhbIAAC3");
	this.shape_32.setTransform(226.6,46.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(2,1,1).p("AAAhwIAADh");
	this.shape_33.setTransform(226.6,44);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(2,1,1).p("AAAiGIAAEN");
	this.shape_34.setTransform(226.6,41.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(2,1,1).p("AAAibIAAE3");
	this.shape_35.setTransform(226.6,39.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(2,1,1).p("AAAiwIAAFh");
	this.shape_36.setTransform(226.6,37.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(2,1,1).p("AAAjGIAAGN");
	this.shape_37.setTransform(226.6,35.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(2,1,1).p("AAAjbIAAG3");
	this.shape_38.setTransform(226.6,33.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(2,1,1).p("AAAjwIAAHh");
	this.shape_39.setTransform(226.6,31.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#000000").ss(2,1,1).p("AAAkGIAAIN");
	this.shape_40.setTransform(226.6,29);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(2,1,1).p("AAAkbIAAI3");
	this.shape_41.setTransform(226.6,26.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#000000").ss(2,1,1).p("AAAkwIAAJh");
	this.shape_42.setTransform(226.6,24.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(2,1,1).p("AAAlGIAAKN");
	this.shape_43.setTransform(226.6,22.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#000000").ss(2,1,1).p("AAAlbIAAK3");
	this.shape_44.setTransform(226.6,20.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(2,1,1).p("AAAlwIAALh");
	this.shape_45.setTransform(226.6,18.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(2,1,1).p("AAAmGIAAMN");
	this.shape_46.setTransform(226.6,16.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(2,1,1).p("AAAmbIAAM3");
	this.shape_47.setTransform(226.6,14.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#000000").ss(2,1,1).p("AAAmxIAANj");
	this.shape_48.setTransform(226.6,11.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(2,1,1).p("AAAnGIAAON");
	this.shape_49.setTransform(226.6,9.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#000000").ss(2,1,1).p("AAAnbIAAO3");
	this.shape_50.setTransform(226.5,7.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#000000").ss(2,1,1).p("AAAnxIAAPj");
	this.shape_51.setTransform(226.5,5.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#000000").ss(2,1,1).p("AAAoGIAAQN");
	this.shape_52.setTransform(226.5,3.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#000000").ss(2,1,1).p("AAAobIAAQ3");
	this.shape_53.setTransform(226.5,1.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#000000").ss(2,1,1).p("AAAoxIAARj");
	this.shape_54.setTransform(226.5,-0.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#000000").ss(2,1,1).p("AAApGIAASN");
	this.shape_55.setTransform(226.5,-2.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#000000").ss(2,1,1).p("AAApbIAAS3");
	this.shape_56.setTransform(226.5,-5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#000000").ss(2,1,1).p("AAApxIAATj");
	this.shape_57.setTransform(226.5,-7.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#000000").ss(2,1,1).p("AAAqGIAAUN");
	this.shape_58.setTransform(226.5,-9.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#000000").ss(2,1,1).p("AAAKdIAA05");
	this.shape_59.setTransform(226.5,-11.5);

	this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_29}]},158).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).wait(62));

	// Vertical_1
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#000000").ss(2,1,1).p("AAAAcIAAg3");
	this.shape_60.setTransform(115.9,52.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#000000").ss(2,1,1).p("AAAglIAABL");
	this.shape_61.setTransform(115.9,51.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#000000").ss(2,1,1).p("AAAgwIAABh");
	this.shape_62.setTransform(115.9,50.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#000000").ss(2,1,1).p("AAAg7IAAB3");
	this.shape_63.setTransform(115.9,49.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#000000").ss(2,1,1).p("AAAhFIAACL");
	this.shape_64.setTransform(115.9,48.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(2,1,1).p("AAAhQIAACh");
	this.shape_65.setTransform(115.9,47.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#000000").ss(2,1,1).p("AAAhbIAAC3");
	this.shape_66.setTransform(115.9,46.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#000000").ss(2,1,1).p("AAAhmIAADN");
	this.shape_67.setTransform(115.9,45);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(2,1,1).p("AAAhwIAADh");
	this.shape_68.setTransform(115.9,44);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#000000").ss(2,1,1).p("AAAh7IAAD3");
	this.shape_69.setTransform(115.9,42.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#000000").ss(2,1,1).p("AAAiGIAAEN");
	this.shape_70.setTransform(115.9,41.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#000000").ss(2,1,1).p("AAAiQIAAEh");
	this.shape_71.setTransform(115.9,40.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#000000").ss(2,1,1).p("AAAibIAAE3");
	this.shape_72.setTransform(115.9,39.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#000000").ss(2,1,1).p("AAAimIAAFN");
	this.shape_73.setTransform(115.9,38.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(2,1,1).p("AAAiwIAAFh");
	this.shape_74.setTransform(115.9,37.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#000000").ss(2,1,1).p("AAAi7IAAF3");
	this.shape_75.setTransform(115.9,36.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(2,1,1).p("AAAjGIAAGN");
	this.shape_76.setTransform(115.9,35.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#000000").ss(2,1,1).p("AAAjQIAAGh");
	this.shape_77.setTransform(115.9,34.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#000000").ss(2,1,1).p("AAAjbIAAG3");
	this.shape_78.setTransform(115.9,33.3);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#000000").ss(2,1,1).p("AAAjmIAAHN");
	this.shape_79.setTransform(115.9,32.2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#000000").ss(2,1,1).p("AAAjwIAAHh");
	this.shape_80.setTransform(115.9,31.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#000000").ss(2,1,1).p("AAAj7IAAH3");
	this.shape_81.setTransform(115.9,30.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#000000").ss(2,1,1).p("AAAkGIAAIN");
	this.shape_82.setTransform(115.9,29);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#000000").ss(2,1,1).p("AAAkQIAAIh");
	this.shape_83.setTransform(115.9,28);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#000000").ss(2,1,1).p("AAAkbIAAI3");
	this.shape_84.setTransform(115.9,26.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#000000").ss(2,1,1).p("AAAkmIAAJN");
	this.shape_85.setTransform(115.9,25.8);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#000000").ss(2,1,1).p("AAAkwIAAJh");
	this.shape_86.setTransform(115.9,24.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#000000").ss(2,1,1).p("AAAk7IAAJ3");
	this.shape_87.setTransform(115.9,23.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#000000").ss(2,1,1).p("AAAlGIAAKN");
	this.shape_88.setTransform(115.9,22.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#000000").ss(2,1,1).p("AAAFSIAAqj");
	this.shape_89.setTransform(115.9,21.6);

	this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = this.shape_64.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = this.shape_69.mask = this.shape_70.mask = this.shape_71.mask = this.shape_72.mask = this.shape_73.mask = this.shape_74.mask = this.shape_75.mask = this.shape_76.mask = this.shape_77.mask = this.shape_78.mask = this.shape_79.mask = this.shape_80.mask = this.shape_81.mask = this.shape_82.mask = this.shape_83.mask = this.shape_84.mask = this.shape_85.mask = this.shape_86.mask = this.shape_87.mask = this.shape_88.mask = this.shape_89.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_60}]},139).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).wait(82));

	// Angulo
	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#000000").ss(2,1,1).p("AnSEWIOkor");
	this.shape_90.setTransform(49.2,27.8);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#000000").ss(2,1,1).p("AnpEkIPTpH");
	this.shape_91.setTransform(51.6,26.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#000000").ss(2,1,1).p("AoBEyIQDpj");
	this.shape_92.setTransform(54,24.9);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#000000").ss(2,1,1).p("AoZFBIQzqB");
	this.shape_93.setTransform(56.4,23.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#000000").ss(2,1,1).p("AoxFPIRjqd");
	this.shape_94.setTransform(58.8,22);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#000000").ss(2,1,1).p("ApJFeISTq7");
	this.shape_95.setTransform(61.2,20.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#000000").ss(2,1,1).p("AphFsITDrX");
	this.shape_96.setTransform(63.6,19.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#000000").ss(2,1,1).p("Ap5F7ITzr1");
	this.shape_97.setTransform(66,17.7);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#000000").ss(2,1,1).p("AqRGJIUjsR");
	this.shape_98.setTransform(68.4,16.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#000000").ss(2,1,1).p("AqpGYIVTsv");
	this.shape_99.setTransform(70.7,14.8);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#000000").ss(2,1,1).p("ArBGmIWDtL");
	this.shape_100.setTransform(73.1,13.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#000000").ss(2,1,1).p("ArZG0IWztn");
	this.shape_101.setTransform(75.5,11.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#000000").ss(2,1,1).p("ArxHDIXjuF");
	this.shape_102.setTransform(77.9,10.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#000000").ss(2,1,1).p("AsJHRIYTuh");
	this.shape_103.setTransform(80.3,9);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#000000").ss(2,1,1).p("AshHgIZDu/");
	this.shape_104.setTransform(82.7,7.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#000000").ss(2,1,1).p("As5HuIZzvb");
	this.shape_105.setTransform(85.1,6.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#000000").ss(2,1,1).p("AtRH9Iajv5");
	this.shape_106.setTransform(87.5,4.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#000000").ss(2,1,1).p("AtoILIbRwV");
	this.shape_107.setTransform(89.9,3.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#000000").ss(2,1,1).p("AuAIaIcBwz");
	this.shape_108.setTransform(92.3,1.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#000000").ss(2,1,1).p("AuYIoIcxxP");
	this.shape_109.setTransform(94.7,0.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#000000").ss(2,1,1).p("AuwI2Idhxr");
	this.shape_110.setTransform(97.1,-1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#000000").ss(2,1,1).p("AvIJFIeRyJ");
	this.shape_111.setTransform(99.5,-2.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#000000").ss(2,1,1).p("AvgJTIfByl");
	this.shape_112.setTransform(101.9,-3.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#000000").ss(2,1,1).p("Av4JiIfxzD");
	this.shape_113.setTransform(104.3,-5.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#000000").ss(2,1,1).p("AwQJwMAghgTf");
	this.shape_114.setTransform(106.7,-6.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#000000").ss(2,1,1).p("AwoJ/MAhRgT9");
	this.shape_115.setTransform(109,-8.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#000000").ss(2,1,1).p("AxAKNMAiBgUZ");
	this.shape_116.setTransform(111.4,-9.7);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#000000").ss(2,1,1).p("AxYKcMAixgU3");
	this.shape_117.setTransform(113.8,-11.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#000000").ss(2,1,1).p("AxwKqMAjhgVT");
	this.shape_118.setTransform(116.2,-12.6);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#000000").ss(2,1,1).p("AyIK5MAkRgVx");
	this.shape_119.setTransform(118.6,-14);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#000000").ss(2,1,1).p("AygLHMAlBgWN");
	this.shape_120.setTransform(121,-15.4);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#000000").ss(2,1,1).p("Ay4LVMAlxgWp");
	this.shape_121.setTransform(123.4,-16.9);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#000000").ss(2,1,1).p("AzQLkMAmhgXH");
	this.shape_122.setTransform(125.8,-18.3);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#000000").ss(2,1,1).p("AznLyMAnPgXj");
	this.shape_123.setTransform(128.2,-19.8);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#000000").ss(2,1,1).p("Az/MBMAn/gYB");
	this.shape_124.setTransform(130.6,-21.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#000000").ss(2,1,1).p("A0XMPMAovgYd");
	this.shape_125.setTransform(133,-22.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#000000").ss(2,1,1).p("A0vMeMApfgY7");
	this.shape_126.setTransform(135.4,-24.1);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#000000").ss(2,1,1).p("A1HMsMAqPgZX");
	this.shape_127.setTransform(137.8,-25.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#000000").ss(2,1,1).p("A1fM7MAq/gZ1");
	this.shape_128.setTransform(140.2,-27);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#000000").ss(2,1,1).p("A13NJMArvgaR");
	this.shape_129.setTransform(142.6,-28.5);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#000000").ss(2,1,1).p("A2PNXMAsfgat");
	this.shape_130.setTransform(145,-29.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#000000").ss(2,1,1).p("A2nNmMAtPgbL");
	this.shape_131.setTransform(147.3,-31.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#000000").ss(2,1,1).p("A2/N0MAt/gbn");
	this.shape_132.setTransform(149.7,-32.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#000000").ss(2,1,1).p("A3XODMAuvgcF");
	this.shape_133.setTransform(152.1,-34.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#000000").ss(2,1,1).p("A3vORMAvfgch");
	this.shape_134.setTransform(154.5,-35.7);

	this.shape_90.mask = this.shape_91.mask = this.shape_92.mask = this.shape_93.mask = this.shape_94.mask = this.shape_95.mask = this.shape_96.mask = this.shape_97.mask = this.shape_98.mask = this.shape_99.mask = this.shape_100.mask = this.shape_101.mask = this.shape_102.mask = this.shape_103.mask = this.shape_104.mask = this.shape_105.mask = this.shape_106.mask = this.shape_107.mask = this.shape_108.mask = this.shape_109.mask = this.shape_110.mask = this.shape_111.mask = this.shape_112.mask = this.shape_113.mask = this.shape_114.mask = this.shape_115.mask = this.shape_116.mask = this.shape_117.mask = this.shape_118.mask = this.shape_119.mask = this.shape_120.mask = this.shape_121.mask = this.shape_122.mask = this.shape_123.mask = this.shape_124.mask = this.shape_125.mask = this.shape_126.mask = this.shape_127.mask = this.shape_128.mask = this.shape_129.mask = this.shape_130.mask = this.shape_131.mask = this.shape_132.mask = this.shape_133.mask = this.shape_134.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_90}]}).to({state:[{t:this.shape_90}]},74).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).wait(132));

	// Base
	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#000000").ss(2,1,1).p("Am1AAINrAA");
	this.shape_135.setTransform(49.2,55.6,1.065,1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#000000").ss(2,1,1).p("AnqAAIPVAA");
	this.shape_136.setTransform(51.6,55.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#000000").ss(2,1,1).p("AoCAAIQFAA");
	this.shape_137.setTransform(54,55.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#000000").ss(2,1,1).p("AoaAAIQ1AA");
	this.shape_138.setTransform(56.4,55.6);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#000000").ss(2,1,1).p("AoyAAIRlAA");
	this.shape_139.setTransform(58.8,55.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#000000").ss(2,1,1).p("ApKAAISVAA");
	this.shape_140.setTransform(61.2,55.6);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#000000").ss(2,1,1).p("ApiAAITFAA");
	this.shape_141.setTransform(63.6,55.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#000000").ss(2,1,1).p("Ap6AAIT1AA");
	this.shape_142.setTransform(66,55.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#000000").ss(2,1,1).p("AqSAAIUlAA");
	this.shape_143.setTransform(68.4,55.6);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#000000").ss(2,1,1).p("AqqAAIVVAA");
	this.shape_144.setTransform(70.8,55.6);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#000000").ss(2,1,1).p("ArCAAIWFAA");
	this.shape_145.setTransform(73.2,55.6);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#000000").ss(2,1,1).p("AraAAIW1AA");
	this.shape_146.setTransform(75.6,55.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#000000").ss(2,1,1).p("AryAAIXlAA");
	this.shape_147.setTransform(78,55.6);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#000000").ss(2,1,1).p("AsKAAIYVAA");
	this.shape_148.setTransform(80.4,55.6);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#000000").ss(2,1,1).p("AsiAAIZFAA");
	this.shape_149.setTransform(82.8,55.6);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#000000").ss(2,1,1).p("As6AAIZ1AA");
	this.shape_150.setTransform(85.2,55.6);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#000000").ss(2,1,1).p("AtSAAIalAA");
	this.shape_151.setTransform(87.6,55.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#000000").ss(2,1,1).p("AtqAAIbVAA");
	this.shape_152.setTransform(90,55.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#000000").ss(2,1,1).p("AuCAAIcFAA");
	this.shape_153.setTransform(92.4,55.5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#000000").ss(2,1,1).p("AuaAAIc1AA");
	this.shape_154.setTransform(94.8,55.5);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#000000").ss(2,1,1).p("AuyAAIdlAA");
	this.shape_155.setTransform(97.2,55.5);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#000000").ss(2,1,1).p("AvKAAIeVAA");
	this.shape_156.setTransform(99.6,55.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#000000").ss(2,1,1).p("AviAAIfFAA");
	this.shape_157.setTransform(102.1,55.5);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#000000").ss(2,1,1).p("Av6AAIf1AA");
	this.shape_158.setTransform(104.5,55.5);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#000000").ss(2,1,1).p("AwSAAMAglAAA");
	this.shape_159.setTransform(106.9,55.5);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#000000").ss(2,1,1).p("AwqAAMAhVAAA");
	this.shape_160.setTransform(109.3,55.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#000000").ss(2,1,1).p("AxCAAMAiFAAA");
	this.shape_161.setTransform(111.7,55.5);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#000000").ss(2,1,1).p("AxaAAMAi1AAA");
	this.shape_162.setTransform(114.1,55.5);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#000000").ss(2,1,1).p("AxyAAMAjlAAA");
	this.shape_163.setTransform(116.5,55.5);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#000000").ss(2,1,1).p("AyKAAMAkVAAA");
	this.shape_164.setTransform(118.9,55.5);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#000000").ss(2,1,1).p("AyiAAMAlFAAA");
	this.shape_165.setTransform(121.3,55.5);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#000000").ss(2,1,1).p("Ay6AAMAl1AAA");
	this.shape_166.setTransform(123.7,55.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#000000").ss(2,1,1).p("AzSAAMAmlAAA");
	this.shape_167.setTransform(126.1,55.5);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#000000").ss(2,1,1).p("AzqAAMAnVAAA");
	this.shape_168.setTransform(128.5,55.5);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#000000").ss(2,1,1).p("A0CAAMAoFAAA");
	this.shape_169.setTransform(130.9,55.5);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#000000").ss(2,1,1).p("A0aAAMAo1AAA");
	this.shape_170.setTransform(133.3,55.5);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#000000").ss(2,1,1).p("A0yABMAplgAB");
	this.shape_171.setTransform(135.7,55.5);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#000000").ss(2,1,1).p("A1KABMAqVgAB");
	this.shape_172.setTransform(138.1,55.5);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#000000").ss(2,1,1).p("A1iABMArFgAB");
	this.shape_173.setTransform(140.5,55.5);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#000000").ss(2,1,1).p("A16ABMAr1gAB");
	this.shape_174.setTransform(142.9,55.5);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#000000").ss(2,1,1).p("A2SABMAslgAB");
	this.shape_175.setTransform(145.3,55.5);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#000000").ss(2,1,1).p("A2qABMAtVgAB");
	this.shape_176.setTransform(147.7,55.5);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#000000").ss(2,1,1).p("A3CABMAuFgAB");
	this.shape_177.setTransform(150.1,55.5);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#000000").ss(2,1,1).p("A3aABMAu1gAB");
	this.shape_178.setTransform(152.5,55.5);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#000000").ss(2,1,1).p("A2VABMAssgAB");
	this.shape_179.setTransform(154.9,55.5,1.065,1);

	this.shape_135.mask = this.shape_136.mask = this.shape_137.mask = this.shape_138.mask = this.shape_139.mask = this.shape_140.mask = this.shape_141.mask = this.shape_142.mask = this.shape_143.mask = this.shape_144.mask = this.shape_145.mask = this.shape_146.mask = this.shape_147.mask = this.shape_148.mask = this.shape_149.mask = this.shape_150.mask = this.shape_151.mask = this.shape_152.mask = this.shape_153.mask = this.shape_154.mask = this.shape_155.mask = this.shape_156.mask = this.shape_157.mask = this.shape_158.mask = this.shape_159.mask = this.shape_160.mask = this.shape_161.mask = this.shape_162.mask = this.shape_163.mask = this.shape_164.mask = this.shape_165.mask = this.shape_166.mask = this.shape_167.mask = this.shape_168.mask = this.shape_169.mask = this.shape_170.mask = this.shape_171.mask = this.shape_172.mask = this.shape_173.mask = this.shape_174.mask = this.shape_175.mask = this.shape_176.mask = this.shape_177.mask = this.shape_178.mask = this.shape_179.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_135}]}).to({state:[{t:this.shape_135}]},74).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).wait(132));

	// Alfa
	this.text = new cjs.Text("α", "20px Arial", "#334BEF");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 10;
	this.text.setTransform(36,32.9);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#000000").ss(1,1,1).p("ACCgfQAWAygQA4IkVgEID1iRg");
	this.shape_180.setTransform(17.2,47.8);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#334BEF").s().p("AiNBHID1iRIAaArQAWAygQA4g");
	this.shape_181.setTransform(17.2,47.8);

	this.text.mask = this.shape_180.mask = this.shape_181.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_181},{t:this.shape_180},{t:this.text}]}).wait(250));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AhaOBIAAsZIBQAAIAAMZg");
	var mask_1_graphics_204 = new cjs.Graphics().p("AhaOBIAAsZIBQAAIAAMZg");
	var mask_1_graphics_205 = new cjs.Graphics().p("AiBGMIAAsXIEDAAIAAMXg");
	var mask_1_graphics_206 = new cjs.Graphics().p("AjcGMIAAsXIG5AAIAAMXg");
	var mask_1_graphics_207 = new cjs.Graphics().p("Ak2GMIAAsXIJtAAIAAMXg");
	var mask_1_graphics_208 = new cjs.Graphics().p("AmRGMIAAsXIMjAAIAAMXg");
	var mask_1_graphics_209 = new cjs.Graphics().p("AnsGMIAAsXIPZAAIAAMXg");
	var mask_1_graphics_210 = new cjs.Graphics().p("ApGGMIAAsXISNAAIAAMXg");
	var mask_1_graphics_211 = new cjs.Graphics().p("AqhGMIAAsXIVDAAIAAMXg");
	var mask_1_graphics_212 = new cjs.Graphics().p("Ar8GMIAAsXIX5AAIAAMXg");
	var mask_1_graphics_213 = new cjs.Graphics().p("AtWGMIAAsXIatAAIAAMXg");
	var mask_1_graphics_214 = new cjs.Graphics().p("AuxGMIAAsXIdjAAIAAMXg");
	var mask_1_graphics_215 = new cjs.Graphics().p("AwMGMIAAsXMAgZAAAIAAMXg");
	var mask_1_graphics_216 = new cjs.Graphics().p("AxmGMIAAsXMAjNAAAIAAMXg");
	var mask_1_graphics_217 = new cjs.Graphics().p("AzBGMIAAsXMAmDAAAIAAMXg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A0cGMIAAsXMAo5AAAIAAMXg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A12GMIAAsXMArtAAAIAAMXg");
	var mask_1_graphics_220 = new cjs.Graphics().p("A3RGMIAAsXMAujAAAIAAMXg");
	var mask_1_graphics_221 = new cjs.Graphics().p("A4sGMIAAsXMAxZAAAIAAMXg");
	var mask_1_graphics_222 = new cjs.Graphics().p("A6GGMIAAsXMA0NAAAIAAMXg");
	var mask_1_graphics_223 = new cjs.Graphics().p("A7hGMIAAsXMA3DAAAIAAMXg");
	var mask_1_graphics_224 = new cjs.Graphics().p("A88GMIAAsXMA55AAAIAAMXg");
	var mask_1_graphics_225 = new cjs.Graphics().p("A+WGMIAAsXMA8tAAAIAAMXg");
	var mask_1_graphics_226 = new cjs.Graphics().p("A/xGMIAAsXMA/jAAAIAAMXg");
	var mask_1_graphics_227 = new cjs.Graphics().p("EghLAGMIAAsXMBCXAAAIAAMXg");
	var mask_1_graphics_228 = new cjs.Graphics().p("EgimAGMIAAsXMBFNAAAIAAMXg");
	var mask_1_graphics_229 = new cjs.Graphics().p("EgkBAGMIAAsXMBIDAAAIAAMXg");
	var mask_1_graphics_230 = new cjs.Graphics().p("EglbAGMIAAsXMBK3AAAIAAMXg");
	var mask_1_graphics_231 = new cjs.Graphics().p("Egm2AGMIAAsXMBNtAAAIAAMXg");
	var mask_1_graphics_232 = new cjs.Graphics().p("EgoRAGMIAAsXMBQjAAAIAAMXg");
	var mask_1_graphics_233 = new cjs.Graphics().p("EgprAGMIAAsXMBTXAAAIAAMXg");
	var mask_1_graphics_234 = new cjs.Graphics().p("EgrGAGMIAAsXMBWNAAAIAAMXg");
	var mask_1_graphics_235 = new cjs.Graphics().p("EgshAGMIAAsXMBZDAAAIAAMXg");
	var mask_1_graphics_236 = new cjs.Graphics().p("Egt7AGMIAAsXMBb3AAAIAAMXg");
	var mask_1_graphics_237 = new cjs.Graphics().p("EgvWAGMIAAsXMBetAAAIAAMXg");
	var mask_1_graphics_238 = new cjs.Graphics().p("EgwxAGMIAAsXMBhjAAAIAAMXg");
	var mask_1_graphics_239 = new cjs.Graphics().p("EgyLAGMIAAsXMBkXAAAIAAMXg");
	var mask_1_graphics_240 = new cjs.Graphics().p("EgzmAGMIAAsXMBnNAAAIAAMXg");
	var mask_1_graphics_241 = new cjs.Graphics().p("Eg1BAGMIAAsXMBqDAAAIAAMXg");
	var mask_1_graphics_242 = new cjs.Graphics().p("Eg2bAGMIAAsXMBs3AAAIAAMXg");
	var mask_1_graphics_243 = new cjs.Graphics().p("Eg32AGMIAAsXMBvtAAAIAAMXg");
	var mask_1_graphics_244 = new cjs.Graphics().p("Eg5RAGMIAAsXMByjAAAIAAMXg");
	var mask_1_graphics_245 = new cjs.Graphics().p("Eg6rAGMIAAsXMB1XAAAIAAMXg");
	var mask_1_graphics_246 = new cjs.Graphics().p("Eg8GAGMIAAsXMB4NAAAIAAMXg");
	var mask_1_graphics_247 = new cjs.Graphics().p("Eg9gAGMIAAsXMB7BAAAIAAMXg");
	var mask_1_graphics_248 = new cjs.Graphics().p("Eg+7AGMIAAsXMB93AAAIAAMXg");
	var mask_1_graphics_249 = new cjs.Graphics().p("EhAWAOBIAAsZMCAtAAAIAAMZg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-9,y:89.8}).wait(204).to({graphics:mask_1_graphics_204,x:-9,y:89.8}).wait(1).to({graphics:mask_1_graphics_205,x:-5.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_206,x:3.9,y:139.8}).wait(1).to({graphics:mask_1_graphics_207,x:12.9,y:139.8}).wait(1).to({graphics:mask_1_graphics_208,x:22,y:139.8}).wait(1).to({graphics:mask_1_graphics_209,x:31.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_210,x:40.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_211,x:49.2,y:139.8}).wait(1).to({graphics:mask_1_graphics_212,x:58.3,y:139.8}).wait(1).to({graphics:mask_1_graphics_213,x:67.3,y:139.8}).wait(1).to({graphics:mask_1_graphics_214,x:76.4,y:139.8}).wait(1).to({graphics:mask_1_graphics_215,x:85.5,y:139.8}).wait(1).to({graphics:mask_1_graphics_216,x:94.5,y:139.8}).wait(1).to({graphics:mask_1_graphics_217,x:103.6,y:139.8}).wait(1).to({graphics:mask_1_graphics_218,x:112.7,y:139.8}).wait(1).to({graphics:mask_1_graphics_219,x:121.7,y:139.8}).wait(1).to({graphics:mask_1_graphics_220,x:130.8,y:139.8}).wait(1).to({graphics:mask_1_graphics_221,x:139.9,y:139.8}).wait(1).to({graphics:mask_1_graphics_222,x:148.9,y:139.8}).wait(1).to({graphics:mask_1_graphics_223,x:158,y:139.8}).wait(1).to({graphics:mask_1_graphics_224,x:167.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_225,x:176.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_226,x:185.2,y:139.8}).wait(1).to({graphics:mask_1_graphics_227,x:194.2,y:139.8}).wait(1).to({graphics:mask_1_graphics_228,x:203.3,y:139.8}).wait(1).to({graphics:mask_1_graphics_229,x:212.4,y:139.8}).wait(1).to({graphics:mask_1_graphics_230,x:221.4,y:139.8}).wait(1).to({graphics:mask_1_graphics_231,x:230.5,y:139.8}).wait(1).to({graphics:mask_1_graphics_232,x:239.6,y:139.8}).wait(1).to({graphics:mask_1_graphics_233,x:248.6,y:139.8}).wait(1).to({graphics:mask_1_graphics_234,x:257.7,y:139.8}).wait(1).to({graphics:mask_1_graphics_235,x:266.8,y:139.8}).wait(1).to({graphics:mask_1_graphics_236,x:275.8,y:139.8}).wait(1).to({graphics:mask_1_graphics_237,x:284.9,y:139.8}).wait(1).to({graphics:mask_1_graphics_238,x:294,y:139.8}).wait(1).to({graphics:mask_1_graphics_239,x:303,y:139.8}).wait(1).to({graphics:mask_1_graphics_240,x:312.1,y:139.8}).wait(1).to({graphics:mask_1_graphics_241,x:321.2,y:139.8}).wait(1).to({graphics:mask_1_graphics_242,x:330.2,y:139.8}).wait(1).to({graphics:mask_1_graphics_243,x:339.3,y:139.8}).wait(1).to({graphics:mask_1_graphics_244,x:348.4,y:139.8}).wait(1).to({graphics:mask_1_graphics_245,x:357.4,y:139.8}).wait(1).to({graphics:mask_1_graphics_246,x:366.5,y:139.8}).wait(1).to({graphics:mask_1_graphics_247,x:375.5,y:139.8}).wait(1).to({graphics:mask_1_graphics_248,x:384.6,y:139.8}).wait(1).to({graphics:mask_1_graphics_249,x:393.7,y:89.8}).wait(1));

	// mc_p1_01
	this.mc_p1_01 = new cjs.Text(txt['mc_p1_01'], "20px Verdana");
	this.mc_p1_01.textAlign = "center";
	this.mc_p1_01.lineHeight = 20;
	this.mc_p1_01.lineWidth = 783;
	this.mc_p1_01.setTransform(391.4,130.9);

	this.mc_p1_01.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_p1_01}]}).wait(250));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,786.8,167.5);



(lib.mc_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-118.5,-12.6,237,25.2,6);
	this.shape.setTransform(133.9,12.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-118.5,-12.6,237,25.2,6);
	this.shape_1.setTransform(133.9,12.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-118.5,-12.6,237,25.2,6);
	this.shape_2.setTransform(133.9,12.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15.4,0,237,25.2);


  (lib.PegatinaAmarilla = function() {
	this.initialize(img.PegatinaAmarilla);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1031,750);


(lib.PegatinaRosa = function() {
	this.initialize(img.PegatinaRosa);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1031,750);


(lib.PegatinaVerde = function() {
	this.initialize(img.PegatinaVerde);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1031,750);


(lib.shutterstock_35778439 = function() {
	this.initialize(img.shutterstock_35778439);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1031,750);


(lib.SinPegatinas = function() {
	this.initialize(img.SinPegatinas);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1031,750);



 (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    
    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
    
     (lib.btn_practica = function (texto,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);
   
     (lib.fadeText = function (textohtml,espera,delay,mode, startPosition, loop) {
         espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        this.texto=new cjs.DOMElement(textohtml);
        this.texto.alpha=0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    
 
     (lib.fadeElement = function (elemento,espera,delay,mode, startPosition, loop) {
           espera=espera||0;
         delay=delay||20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({ alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "#FFFFFF";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";
    

    document.body.appendChild(html);
    return html;
}