(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

	this.instance_6 = new lib.shutterstock_60772996();
	this.instance_6.setTransform(169.9,106.5,0.65,0.65);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.instance_6);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit2']);
        	this.instance_1 = new lib.mc_pant_2();
	this.instance_1.setTransform(80,152);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3']);

	var html = document.createElement('img');
    html.src = "images/mc_p2.gif";
    html.id="mc_p2";
    document.body.appendChild(html);
    
    
        this.instance_2= new cjs.DOMElement(html);
        
        if (isSurface)
        this.instance_2.setTransform(80,-550);
    else
                this.instance_2.setTransform(-850,60);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild( this.titulo, this.home, this.anterior, this.siguiente,this.instance_2,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit4']);
   	this.instance_1 = new lib.mc_pant_4();
	this.instance_1.setTransform(80,152);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
   	this.instance_1 = new lib.mc_pant_5();
	this.instance_1.setTransform(80,152);

  var html = createDiv(txt['text5'], "Verdana", "20px", '500px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 400);
    this.texto1.setTransform(300, -190);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        texto(this, txt['text6'],0,-40);
        	this.instance_5 = new lib.mc_pant_6();
	this.instance_5.setTransform(200,318,1,1,0,0,0,179.3,144);

  var html = createDiv(txt['text6b'], "Verdana", "20px", '500px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 54);
    this.texto1.setTransform(90, -220);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior,this.instance_5,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

 
 
(lib.shutterstock_60772996 = function() {
	this.initialize(img.shutterstock_60772996);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,667);


(lib.shutterstock_93381388 = function() {
	this.initialize(img.shutterstock_93381388);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,747,1000);


(lib.text_final = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Al principio, Luis se encontraba a 5 m de distancia del faro.\nPara averiguar la altura del faro, hay que sustituir la x en alguna de las ecuaciones.", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 581;
	this.text.setTransform(-386.1,95.1);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-386.1,95.1,584.9,73.7);



(lib.PERSONA = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.shutterstock_93381388();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,747,1000);


(lib.frase3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['frase3'], "20px Verdana");
	this.text.lineHeight = 22;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,181.4,54.6);


(lib.frase1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['frase1'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 444;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,448,28.3);


(lib.frase_2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['frase2'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 222;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,225.9,80.9);


(lib.formula_11 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("5,8", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(38.1,-6.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjlAAIHLAA");
	this.shape.setTransform(58.3,21.9);

	this.text_1 = new cjs.Text("1,15", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(34.1,20.7+incremento);

	this.text_2 = new cjs.Text("x = ", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(-3.9,5.8+incremento);

	this.addChild(this.text_2,this.text_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,-6.6,87.7,55.6);


(lib.formula_10 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("1,15x = 5,8", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-3.9,5.8+incremento);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,5.8,124.6,28.3);


(lib.formula_9 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(" = 5,8", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(139.9,6.8+incremento);

	this.text_1 = new cjs.Text("1,73x – 0,58x", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(-3.9,5.8+incremento);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,5.8,211.3,29.4);


(lib.formula_7 = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(69,6+incremento);

	// Capa 1
	this.text_1 = new cjs.Text("5,8 + 0,58x", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(94,3.8+incremento);

	this.text_2 = new cjs.Text("1,73x ", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(3,6.8+incremento);

	this.addChild(this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3,3.8,215.6,31.2);


(lib.formula_5b = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("0,58 (10 + x)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(96,5.8+incremento);

	this.text_1 = new cjs.Text("1,73x =", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(3,6.8+incremento);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3,5.8,235.5,29.2);


(lib.formula_3b = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(112,6+incremento);

	// Capa 1
	this.text_1 = new cjs.Text("tg 30º (10 + x)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(137,3.8+incremento);

	this.text_2 = new cjs.Text("x", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(89,4+incremento);

	this.text_3 = new cjs.Text("tg 60º · ", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(3,6.8+incremento);

	this.addChild(this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3,3.8,294.8,31.2);


(lib.formula_3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("tg 30º (10 + x)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(0,67.8+incremento);

	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(89,0+incremento);

	this.text_2 = new cjs.Text("tg 60º · ", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(3,2.8+incremento);

	this.addChild(this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,160.9,96.1);


(lib.formula_2b = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("h = tg 30º (10 + x)", "italic 20px Verdana");
	this.text.lineHeight = 22;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,204,28.3);


(lib.formula_2 = function() {
	this.initialize();

	// Capa 3
	/*this.text = new cjs.Text("10 + x", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(91.4,18.3+incremento);*/
	
	 var html = createDiv(txt['texto_formula'], "Verdana", "20px", '170px', '400px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(100, -600);

	this.text_1 = new cjs.Text("h", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(117.4,-14.2+incremento);

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjQAAIGhAA");
	this.shape.setTransform(130.5,15.2,1.447,1);

	// Capa 1
	this.text_2 = new cjs.Text("tg 30º = ", "20px Verdana");
	this.text_2.lineHeight = 22;
        this.text_2.setTransform(0,+incremento);

	this.addChild(this.text_2,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-14.2,163.3,60.8);


(lib.formula_1b = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("h = tg 60º · x ", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-9.9,0+incremento);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.9,0,151.3,28.3);


(lib.formula_1_2 = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("x", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(112.3,12.6+incremento);

	this.text_1 = new cjs.Text("h", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(112.3,-14.2+incremento);

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjQAAIGhAA");
	this.shape.setTransform(120.9,15.2);

	// Capa 1
	this.text_2 = new cjs.Text("tg 60º = ", "20px Verdana");
	this.text_2.setTransform(0,+incremento);

	this.addChild(this.text_2,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-14.2,129.2,55.1);


(lib.formula_1 = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("x", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(112.3,9.6+incremento);

	this.text_1 = new cjs.Text("h", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(112.3,-14.2+incremento);

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjQAAIGhAA");
	this.shape.setTransform(120.9,15.2);

	// Capa 1
	this.text_2 = new cjs.Text("tg 60º = ", "20px Verdana");
	this.text_2.setTransform(0,+incremento);

	this.addChild(this.text_2,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-14.2,129.2,52.1);


(lib.far = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("Ag+ByIAAimQABgaASgRQATgSAYAAQAaAAASASQATARAAAaIgBCmg");
	this.shape.setTransform(153.4,274.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ACAA8C").s().p("Ag+ByIAAimQAAgaATgSQATgSAYABQAaAAATASQASARAAAaIAACmg");
	this.shape_1.setTransform(154.3,274.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ACAA8C").s().p("AglA9IBEgBIgChPQAAgPgHgMQgHgMgLgFQAOADAJANQAKANAAARIABBQIhLABg");
	this.shape_2.setTransform(144.3,100.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgmgPQAAgUALgOQALgOAQAAQAOAAAMAOQAMANAAAUIABBPIhLABg");
	this.shape_3.setTransform(144.2,100.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ACAA8C").s().p("AglA9IBEgBIgChPQAAgPgHgMQgHgLgLgGQAOADAJANQAKANAAARIABBQIhLABg");
	this.shape_4.setTransform(144.3,143.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgmgPQAAgUALgOQALgOAQAAQAOAAAMAOQAMANAAAUIABBPIhLABg");
	this.shape_5.setTransform(144.2,143.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#ACAA8C").s().p("AglA9IBEgBIgChPQAAgPgHgMQgHgMgLgFQAOADAJANQAKANAAARIABBPIhLACg");
	this.shape_6.setTransform(144.3,186.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#333333").s().p("AgmgPQAAgUALgOQALgOAQAAQAOAAAMANQAMAOAAAUIABBPIhLABg");
	this.shape_7.setTransform(144.2,186.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#ACAA8C").s().p("AglA9IBEgBIgChPQAAgPgHgMQgHgMgLgFQAOADAJANQAKANAAARIABBQIhLABg");
	this.shape_8.setTransform(144.3,230.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AgmgPQAAgUALgOQALgOAQAAQAOAAAMAOQAMANAAAUIABBPIhLABg");
	this.shape_9.setTransform(144.2,230.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#E90822","#A00E1A"],[0,1],-22.7,0,22.9,0).s().p("AjJB2QgUAAgFgKQgFgLAOgOIC4i5QAPgPASAAQAUAAAOAPIC4C5QANAOgEALQgEAKgVAAg");
	this.shape_10.setTransform(143.4,12.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#E90822","#A00E1A"],[0,1],-30.4,0,30.5,0).s().p("AkvCfIAUlBII1gUIAWFug");
	this.shape_11.setTransform(143.5,234.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#E90822","#A00E1A"],[0,1],-21.9,0,22.1,0).s().p("AjbBuIAPjuIGYgEIAQEJg");
	this.shape_12.setTransform(143.5,104.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#E90822","#A00E1A"],[0,1],-26.5,0,26.7,0).s().p("AkJCbIAUlCIHogPIAXFtg");
	this.shape_13.setTransform(143.5,173.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#E90822","#A00E1A"],[0,1],-18.5,0,18.6,0).s().p("AivhMIFgAAIAICDIlyAVg");
	this.shape_14.setTransform(143.4,54.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#D30A1E","#910E18"],[0,1],-18.8,0,19,0).s().p("AiyhMIFnAAIAICDIl5AVg");
	this.shape_15.setTransform(143.7,54.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#D30A1E","#910E18"],[0,1],-21.9,0,22.1,0).s().p("AjbBuIAOjuIGZgEIAREJg");
	this.shape_16.setTransform(144.2,104.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#D30A1E","#910E18"],[0,1],-26.9,0,27,0).s().p("AkNCbIAUlCIHwgPIAXFtg");
	this.shape_17.setTransform(143.9,173.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#D30A1E","#910E18"],[0,1],-30.7,0,30.9,0).s().p("AkzCfIAUlBII8gUIAXFug");
	this.shape_18.setTransform(143.9,234.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#524741").s().p("AgCB3IAAjtIAGAAIAADtg");
	this.shape_19.setTransform(137.5,35.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#524741").s().p("AgCB3IAAjtIAFAAIAADtg");
	this.shape_20.setTransform(149.3,35.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#524741").s().p("AgCB3IAAjtIAFAAIAADtg");
	this.shape_21.setTransform(160.7,35.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#524741").s().p("AgCB3IAAjtIAFAAIAADtg");
	this.shape_22.setTransform(126.1,35.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#4A413B").s().p("AgGB3IAAjtIANAAIAADtg");
	this.shape_23.setTransform(161.1,35.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["#F5D85C","#F5D75A","#F4D553","#F4D148","#F4CB39","#F3C328","#F3BD1D"],[0,0.4,0.584,0.718,0.831,0.933,1],0,0,0,0,0,16).s().p("AivB0IAAjnIFfAAIAADng");
	this.shape_24.setTransform(143.4,35.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#F1F1F1","#E4E4E5"],[0,1],-32.5,0,32.7,0).s().p("AlFStMACWglZIFfAAMACWAlZg");
	this.shape_25.setTransform(143.4,166.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#D30A1E","#910E18"],[0,1],-22.7,0,22.9,0).s().p("AjJB2QgVAAgEgKQgEgLANgOIC4i5QAOgPATAAQATAAAOAPIC5C5QAOAOgFALQgFAKgUAAg");
	this.shape_26.setTransform(144.2,12.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#DADADA","#CECECF"],[0,1],-32.5,0,32.7,0).s().p("AlFStMACWglZIFgAAMACVAlZg");
	this.shape_27.setTransform(144.1,166.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D3F956").s().p("A3OJgQDXpuGjk/QGBknHUAXQHLAWGME6QGdFGDaIng");
	this.shape_28.setTransform(148.8,342.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#BCDD53").s().p("A3SJmQBpkvCdjtQEOmbGLiqQF0ihGSBUQGTBTFNEuQFdE7DAHmIACAHIgGAFg");
	this.shape_29.setTransform(149.1,341.7);

	this.addChild(this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.5,298.2,402.7);




(lib.angle_primer = function() {
	this.initialize();

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.angle_60_pant2b = function() {
	this.initialize();

	// angle_60
	this.text = new cjs.Text("60º", "18px Verdana");
        this.text.color="#FF0000";
	this.text.lineHeight = 20;
	this.text.setTransform(136.5,264.5+incremento);

	// corva_angle
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1,1,1).p("AgYBEQgNgTABgaQADgzBGgn");
	this.shape.setTransform(175.5,284.4);

	// x_h
	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.color="#FF0000";
	this.text_1.setTransform(99.4,289+incremento);

	this.text_2 = new cjs.Text("h", "italic 20px Verdana");
	this.text_2.color="#FF0000";
	this.text_2.setTransform(14.9,135.8+incremento);

	// triangle
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(1,1,1).p("Art2pMAXbAtT");
	this.shape_1.setTransform(112,146.2,1,1.008);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,1,1).p("AAA2kMAAAAtJ");
	this.shape_2.setTransform(36.8,145.2,1,1.004);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FF0000").ss(1,1,1).p("AOYAAI8vAA");
	this.shape_3.setTransform(111.7,291.4,0.807,1);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.text_2,this.text_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(14.9,0,172,317.3);


(lib.angle_60_pant2 = function() {
	this.initialize();

	// angle_60
	this.text = new cjs.Text("60º", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(136.5,264.5+incremento);

	// corva_angle
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgYBEQgNgTABgaQADgzBGgn");
	this.shape.setTransform(175.5,284.4);

	// x_h
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag6AAIB1gsIAABZg");
	this.shape_1.setTransform(45.2,304);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag6gsIB1AsIh1Atg");
	this.shape_2.setTransform(170.8,303.7);

	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(99.4,289+incremento);

	this.text_2 = new cjs.Text("h", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(14.2,137.2+incremento);

	// triangle
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("Art2pMAXbAtT");
	this.shape_3.setTransform(112,146.2,1,1.008);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAA2kMAAAAtJ");
	this.shape_4.setTransform(36.8,145.2,1,1.004);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AOYAAI8vAA");
	this.shape_5.setTransform(111.7,291.4,0.807,1);

	// Capa 5
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.3,1,1).p("AEXAAIotAA");
	this.shape_6.setTransform(143.9,303.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(0.3,1,1).p("AEXAAIotAA");
	this.shape_7.setTransform(71,303.7);

	this.addChild(this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.text_2,this.text_1,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(14.2,0,172.8,317.3);


(lib.angle_60 = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("30º", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(319.6,263.6);

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgYBEQgNgTABgaQADgzBGgn");
	this.shape.setTransform(358.6,283.5);

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(0.5,1,1).p("A6t2mMA1bAtN");
	this.shape_1.setTransform(209.1,146);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAA2kMAAAAtJ");
	this.shape_2.setTransform(36.8,145.2,1,1.004);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AOYAAI8vAA");
	this.shape_3.setTransform(189.7,291.4,2.055,1);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(38,1.3,342.2,289.5);


(lib.angle_30 = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("60º", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(136.5,264.5);

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AgYBEQgNgTABgaQADgzBGgn");
	this.shape.setTransform(175.5,284.4);

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Art2pMAXbAtT");
	this.shape_1.setTransform(112,146.2,1,1.008);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAA2kMAAAAtJ");
	this.shape_2.setTransform(36.8,145.2,1,1.004);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AOYAAI8vAA");
	this.shape_3.setTransform(111.7,291.4,0.807,1);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(37,0,150,292.4);


(lib.altura_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// formula1
	this.text = new cjs.Text("h = 8,65 m", "italic 20px Verdana");
	this.text.lineHeight = 22;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"h = 8,65 m",lineWidth:215}}]}).to({state:[{t:this.text,p:{text:"h = tg · x",lineWidth:197}}]},49).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,119.2,28.3);


(lib.altura_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// formula1
	this.text = new cjs.Text("h = 1,73 · 5", "italic 20px Verdana");
	this.text.lineHeight = 22;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"h = 1,73 · 5",lineWidth:123}}]}).to({state:[{t:this.text,p:{text:"h = tg · x",lineWidth:97}}]},49).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,126.8,28.3);


(lib.altura_1 = function() {
	this.initialize();

	// formula1
	this.text = new cjs.Text("h = tg 60° · x", "italic 20px Verdana");
	this.text.lineHeight = 22;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,144.2,28.3);


(lib.mc_pant_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// formula_3
	this.instance = new lib.altura_3("synched",17);
	this.instance.setTransform(78.3,101.7);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AADBeIARhAIAYAAIgbBAgAhuAxQgPgNAAgSQABgMAGgJQAIgKAMgFIAAgBQgLgGgGgHQgFgIAAgLQAAgRANgKQANgLAVAAQAWAAANAKQANALAAAQQAAAKgGAJQgHAJgLAGIAAAAQAOAHAGAIQAIAGAAAOQAAATgPANQgPAMgWAAQgYAAgNgMgAhkgBQgFAHAAAKQAAANAJAJQAKAIANABQAPAAAIgIQAJgHAAgNQAAgJgFgGQgDgEgMgEIgKgFIgOgEQgJAEgGAIgAhdhFQgIAGAAAKQAAAHAEAFQAEAFAIAEIAKAEIANAGQAKgHAEgHQAEgHgBgJQAAgLgIgFQgHgHgNAAQgMAAgIAGgADiA6QgLgDgIgDIAAgVIABAAQAIAFALAEQALADAKAAQAHAAAHgCQAGgCAFgEQAEgEADgGQACgGAAgIQgBgHgCgEQgCgFgFgDQgFgDgIgCQgHgCgIABIgRABIgOACIAAhLIBYAAIAAARIhFAAIAAAnIAIgBIAIAAQAMAAAJACQAJACAHAFQAIAFAEAJQAEAIAAAMQAAAJgDAJQgEAKgHAHQgGAGgKAEQgKAEgNgBQgMAAgKgCgABsA5QgJgDgGgGQgJgJgFgNQgEgOAAgQQAAgUAEgPQAEgOAKgMQAIgLANgHQAOgFASAAIAKAAIAIACIAAATIgBAAIgIgDQgGgCgGAAQgVAAgMAOQgNANgCAWQAIgFAJgDQAHgCALAAQAJAAAHACQAHABAHAFQAJAGAFAJQAEAKAAALQAAAVgOAPQgPANgVAAQgLABgJgEgABugPQgIACgHADIgBAFIAAAFQABANADAJQADAJAFAGQAFADAFACQAFACAHABQAOAAAIgJQAIgIAAgRQAAgJgCgEQgDgGgGgFQgFgCgFgBIgMgCQgIABgHACgAIhA5IAAg8IgBgNQAAgGgCgFQgCgEgFgCQgEgCgIAAQgIAAgHAEQgIAEgIAGIAAAFIABAFIAABEIgTAAIAAg8IAAgNQgBgHgCgEQgCgEgFgCQgEgCgHAAQgIAAgIAEIgPAJIAABPIgSAAIAAhqIASAAIAAALQAJgGAIgFQAJgDAKAAQALgBAHAFQAJAFADAIQALgKAJgEQAKgDAKAAQASAAAJALQAIAKAAATIAABFgAnpA5IAOg8IACgJIABgIQAAgHgFgEQgDgFgLAAQgHAAgJAFQgKADgIAGIgSBPIgTAAIAjiWIATAAIgOA3QALgHAJgEQAJgDAKAAQAOAAAIAGQAIAIAAAOIAAAFIgBAHIgRBFgAlXAWIAAgQIB0AAIAAAQgAlXgRIAAgPIB0AAIAAAPg");
	this.shape.setTransform(137.2,166.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},39).to({state:[{t:this.shape}]},7).wait(12));

	// formula2
	this.instance_1 = new lib.altura_2("synched",9);
	this.instance_1.setTransform(80.6,58.2);
	this.instance_1.alpha = 0;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgjBeIARhBIAXAAIgaBBgAIPA6QgLgCgIgEIAAgUIABAAQAIAFALADQALADAKABQAHgBAHgBQAGgCAFgFQAFgFACgFQACgGAAgIQAAgIgDgDQgCgEgFgEQgFgEgHgBQgHgCgJAAIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJAAIAHgBQAMAAAJACQAJACAHAFQAIAFAEAJQAFAIAAALQAAAKgEAKQgEAJgGAGQgHAHgKAEQgKADgMABQgMgBgLgCgAC4A6QgLgDgIgDIAAgVIACAAQAIAGALADQALADALABQAGgBAHgBQAHgDAEgEQAFgEACgFQACgFAAgIQAAgIgDgFQgCgDgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgHQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAJQAAAMgJAJQgIAJgMADIAAABIALADQAGADAEAEQAFAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDgAAyA6IBGh/IhTAAIAAgRIBjAAIAAAWIhCB6gAiVA6IAAgPIAeAAIAAhgIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACCIAeAAIAAAPgAoRA6IAOg8IACgJIABgIQAAgIgEgFQgEgEgLAAQgHAAgJAEQgJAFgJAFIgSBQIgTAAIAjiWIATAAIgNA3QAKgIAJgDQAKgFAJAAQAPAAAHAIQAIAGAAAOIAAAHIgBAHIgRBFgAl+AWIAAgPIB0AAIAAAPgAFzAHIAAgZIAXAAIAAAZgAl+gRIAAgQIB0AAIAAAQg");
	this.shape_1.setTransform(141.2,118);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},21).to({state:[{t:this.shape_1}]},8).wait(29));

	// formules
	this.instance_2 = new lib.altura_1("synched",0);
	this.instance_2.setTransform(80.6,58.2);
	this.instance_2.alpha = 0;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AicBfQgJgBgHgDIAAgSIAAAAIAPAEQAKADAJAAQAKAAAGgDQAGgCAEgEQADgEABgFQACgFgBgHIAAgKQgHAHgIADQgIADgMAAQgTAAgLgOQgMgOAAgZQAAgNAEgKQAEgKAHgIQAGgHAJgDQAJgEAKAAQAJAAAGACQAHABAGAEIACgEIARAAIAABeQAAAcgMANQgNANgaAAQgJAAgIgBgAicgdQgJAKAAATQAAARAGAKQAHAJAPAAQAIAAAIgDQAIgDAGgFIAAg6QgGgDgHgBQgGgCgHAAQgPAAgIAKgACXAnQgMgSAAglQAAgnAMgSQAMgTAaAAQAbAAAMATQALATABAmQgBAlgLATQgNASgaAAQgaAAgMgTgACuhIQgGAEgDAIQgEAHgBAMQgCALABAOQgBAPACAJQABAKAEAIQACAIAHAEQAFAEAKAAQAJAAAGgEQAGgEAEgIQADgIACgKIABgYIgBgaQgCgLgEgHQgDgIgGgEQgGgDgJAAQgJAAgGADgAAtA2QgJgDgGgGQgJgJgFgNQgEgNAAgRQAAgTAEgPQAEgPAKgMQAIgLANgGQAOgGASAAIAKAAIAHACIAAATIgBAAIgIgDQgFgCgGAAQgVAAgNAOQgMANgCAWQAIgFAJgCQAHgDALAAQAJAAAHACQAHABAHAFQAJAGAFAKQAEAJAAALQAAAWgPAOQgPAOgVAAQgKAAgJgEgAAugSQgGACgIAEIAAAEIAAAFQgBAOAEAIQADAJAFAGQAFAEAFACQAGACAFAAQAPAAAIgJQAIgIAAgRQAAgIgCgFQgEgGgFgEQgFgDgGgBIgLgBQgIAAgIACgAj2AwQgJgJAAgUIAAg4IgNAAIAAgPIANAAIAAggIATAAIAAAgIAlAAIAAAPIglAAIAAAwIAAANQAAAFACAEQACAEAFACQADACAIAAIAJgBIAHgDIABAAIAAARIgLACIgLABQgRAAgIgJgAKOA3IgXgqIgoAqIgXAAIA5g3Igfg0IAVAAIAWApIApgpIAWAAIg3A1IAeA2gApyA3IAOg8IACgJIAAgIQAAgIgDgEQgEgFgLAAQgIAAgJAFQgIAEgJAFIgTBQIgSAAIAjiWIASAAIgMA3QAKgIAJgDQAJgEAKAAQAPAAAHAHQAIAHAAAOIAAAGIgCAHIgQBFgAnfATIAAgPIB0AAIAAAPgAHHAFIAHgaIAXAAIgHAagAEXgYQgMgMABgQQgBgRAMgLQALgLAQAAQASAAAKALQAMALAAARQAAAQgMAMQgLALgRAAQgQAAgLgLgAEihFQgGAHAAAKQgBAKAIAHQAGAGAJAAQAKAAAHgHQAGgGABgKQgBgKgGgHQgHgHgKAAQgJAAgHAHgAnfgUIAAgPIB0AAIAAAPg");
	this.shape_2.setTransform(153.2,74.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.shape_2}]},9).wait(49));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(80.6,58.2,144.2,28.3);


(lib.formula_11 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("5,8", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(38.1,-6.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjlAAIHLAA");
	this.shape.setTransform(58.3,21.9);

	this.text_1 = new cjs.Text("1,15", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(34.1,20.7);

	this.text_2 = new cjs.Text("x = ", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(-3.9,5.8);

	this.addChild(this.text_2,this.text_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,-6.6,87.7,55.6);


(lib.formula_10 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("1,15x = 5,8", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-3.9,5.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,5.8,124.6,28.3);


(lib.formula_9 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(" = 5,8", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(139.9,6.8);

	this.text_1 = new cjs.Text("1,73x – 0,58x", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(-3.9,5.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-3.9,5.8,211.3,29.4);


(lib.formula_5b = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("0,58 (10 + x)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(96,5.8);

	this.text_1 = new cjs.Text("1,73x =", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(3,6.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3,5.8,235.5,29.2);


(lib.formula_3b = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(112,6);

	// Capa 1
	this.text_1 = new cjs.Text("tg 30º (10 + x)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(137,3.8);

	this.text_2 = new cjs.Text("x", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(89,4);

	this.text_3 = new cjs.Text("tg 60º · ", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(3,6.8);

	this.addChild(this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3,3.8,294.8,31.2);


(lib.formula_3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("tg 30º (10 + x)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(0,67.8);

	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(89,0);

	this.text_2 = new cjs.Text("tg 60º · ", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(3,2.8);

	this.addChild(this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,160.9,96.1);


(lib.formula_2b = function() {
	this.initialize();

	// Capa 3
	this.text = new cjs.Text("h = tg 30º (10 + x)", "italic 20px Verdana");
	this.text.lineHeight = 22;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,204,28.3);


(lib.formula_1b = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("h = tg 60º · x ", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-9.9,0);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-9.9,0,151.3,28.3);


(lib.mc_pant_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// resultat
	/*this.text = new cjs.Text("x ≈ 5 ", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(60.3,350);*/
	
	var html = createDiv(txt['texto_formula2'], "Verdana", "20px", '770px', '40px',"20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(65, -270);
	
	
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},395).wait(7));

	// formula_10
	this.instance = new lib.formula_11("synched",0);
	this.instance.setTransform(170.1,356.9,1,1,0,0,0,80.4,47.9);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AjlAAIHLAA");
	this.shape.setTransform(122.6,316.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABzDkIARhAIAYAAIgbBAgAFRDBQgLgDgHgDIAAgVIABAAQAIAFALAEQAKADALAAQAHAAAGgCQAHgCAFgEQAEgFACgFQACgGAAgIQAAgIgCgFQgDgFgEgDQgFgEgIgBQgHgCgJAAIgQABIgOADIAAhLIBXAAIAAARIhEAAIAAAnIAIgBIAIAAQAMAAAJACQAIACAIAFQAIAFAEAJQAEAIAAANQAAAKgDAJQgEAKgHAGQgHAHgJAEQgKADgNAAQgMAAgLgCgADIDAIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgAAADAIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgAlHArIgWgpIgpApIgWAAIA4g1Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA0gAi9AIIAAgOIB0AAIAAAOgAi9gfIAAgQIB0AAIAAAQgACagrIARhAIAZAAIgcBAgADvhYQgOgMAAgTQAAgMAHgKQAHgKANgFIAAgBQgMgGgGgIQgFgHAAgLQAAgRANgLQAOgKAUAAQAWAAANAKQANAKAAARQAAAJgGAKQgGAJgMAGIAAAAQAOAGAHAJQAHAIAAAOQAAATgPAMQgOANgXAAQgXAAgOgNgAD6iLQgGAIAAALQAAANAJAIQAKAJAOAAQAOAAAIgHQAJgIAAgMQAAgJgEgGQgEgFgMgGIgKgEIgOgFQgJAFgFAIgAEAjPQgIAGAAAKQAAAHAEAFQAEAFAIAEIALAEIANAFQAJgGAEgHQAEgHAAgJQAAgLgIgGQgIgGgNAAQgMAAgIAGgAAyhOQgLgDgIgDIAAgVIABAAQAIAFALAEQALADAKAAQAHAAAHgCQAGgCAFgEQAFgFACgFQACgGAAgIQAAgIgDgFQgCgFgFgDQgFgEgHgBQgHgCgJAAIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAFAEAJQAFAIAAANQAAAKgEAJQgEAKgGAGQgHAHgKAEQgKADgMAAQgMAAgLgCg");
	this.shape_1.setTransform(103,318.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},354).to({state:[{t:this.shape_1},{t:this.shape}]},8).wait(40));

	// formula9
	this.instance_1 = new lib.formula_10("synched",0);
	this.instance_1.setTransform(142.4,353.1,1,1,0,0,0,80.4,47.9);
	this.instance_1.alpha = 0;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AGYBcIARhAIAZAAIgbBAgAnSBcIARhAIAYAAIgcBAgAHtAvQgOgMAAgTQAAgMAHgIQAHgKANgGIAAAAQgMgHgGgHQgFgIAAgLQAAgQANgLQAOgLAVAAQAWAAANAKQANALgBAQQAAAKgGAJQgGAKgMAFIAAABQAOAGAHAIQAHAHAAANQAAATgOANQgPAMgWAAQgYAAgOgMgAH4gCQgGAGAAAKQABANAIAJQAKAJAOAAQAOAAAIgIQAJgHAAgNQAAgJgEgFQgEgEgMgFIgKgEIgOgFQgJAEgFAJgAH/hHQgJAGABAKQAAAHADAFQAFAFAIAEIAKAFIANAFQAJgHAFgHQADgHAAgJQAAgKgIgGQgIgHgMAAQgNAAgHAGgAEwA4QgLgCgHgEIAAgUIABAAQAHAFAMADQAKAEAKAAQAIAAAGgCQAHgCAEgFQAFgEACgGQACgGAAgIQAAgHgCgDQgDgFgEgEQgFgDgIgCQgHgBgJAAIgQABIgPACIAAhLIBYAAIAAARIhFAAIAAAnIAJAAIAHgBQAMAAAKACQAIACAHAFQAIAGAFAIQAEAJAAALQAAAKgDAJQgFAJgGAHQgHAGgJAEQgKAEgNAAQgMAAgLgDgAj0A4QgLgCgHgEIAAgUIABAAQAHAFAMADQAKAEAKAAQAIAAAGgCQAHgCAFgFQAEgEACgGQACgGAAgIQAAgHgCgDQgDgFgEgEQgGgDgHgCQgHgBgJAAIgQABIgPACIAAhLIBYAAIAAARIhFAAIAAAnIAJAAIAHgBQANAAAIACQAJACAHAFQAIAGAFAIQAEAJAAALQAAAKgDAJQgFAJgGAHQgHAGgJAEQgKAEgNAAQgMAAgLgDgAhLA4IgWgqIgpAqIgWAAIA3g3Igeg0IAUAAIAXApIApgpIAWAAIg4A1IAfA2gAl9A4IAAgPIAfAAIAAhgIgfAAIAAgNIAOgBQAGgBAEgCQAEgCADgEQADgEAAgGIAPAAIAACBIAeAAIAAAPgApFA4IAAgPIAfAAIAAhgIgfAAIAAgNIAOgBQAGgBAEgCQAFgCACgEQACgEABgGIAPAAIAACBIAeAAIAAAPgAA9AUIAAgPIB0AAIAAAPgAA9gTIAAgPIB0AAIAAAPg");
	this.shape_2.setTransform(121,270.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},328).to({state:[{t:this.shape_2}]},7).wait(67));

	// formula8
	this.instance_2 = new lib.formula_9("synched",0);
	this.instance_2.setTransform(142.4,295.1,1,1,0,0,0,80.4,47.9);
	this.instance_2.alpha = 0;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("ANKBhIARhAIAYAAIgbBAgAg7BXIARhAIAYAAIgbBAgAuEBXIARhAIAZAAIgcBAgAOeA0QgOgMAAgTQAAgMAHgJQAHgJANgGIAAAAQgMgHgFgHQgGgIAAgKQAAgRAOgLQANgLAVAAQAWAAANALQANAKAAARQAAAJgHAKQgGAJgMAFIAAABQAOAGAHAIQAHAHAAANQAAAUgOAMQgPAMgWAAQgYAAgOgMgAOpABQgFAIAAAKQAAAOAJAIQAJAJAOAAQAOAAAJgHQAIgIAAgMQAAgKgEgFQgEgFgLgEIgKgEIgPgFQgIAFgGAGgAOwhBQgIAGAAAJQAAAHAEAGQAEAEAIAFIAKAEIANAFQAKgGAEgIQADgHAAgIQAAgLgIgGQgIgGgMgBQgNAAgHAHgALhA9QgLgCgHgEIAAgUIABAAQAIAFALADQAKAEALAAQAHAAAGgCQAHgCAFgFQAEgEACgGQACgGAAgHQAAgIgCgFQgDgDgEgEQgFgDgIgBQgHgCgJAAIgQABIgOACIAAhKIBXAAIAAARIhEAAIAAAmIAIAAIAIAAQAMAAAJABQAIADAIAFQAIAFAEAIQAEAHAAANQAAAKgDAJQgEAKgHAGQgHAHgJAEQgKADgNAAQgMAAgLgDgACWAqQgOgMAAgUQAAgKAHgJQAHgLANgFIAAgBQgMgGgFgHQgGgIAAgLQAAgQAOgMQANgKAVAAQAWAAANAKQANALAAAQQAAAKgHAJQgGAJgMAGIAAAAQAOAHAHAIQAHAJAAALQAAATgOANQgPAMgWAAQgYAAgOgMgAChgIQgFAIAAAJQAAANAJAJQAJAIAOABQAOAAAJgIQAIgHAAgNQAAgJgEgDQgEgGgLgFIgKgFIgPgEQgIAEgGAIgACohMQgIAGAAAKQAAAHAEAFQAEAFAIAEIAKAEIANAGQAKgHAEgHQADgHAAgJQAAgLgIgFQgIgHgMAAQgNAAgHAGgAAiAzQgLgDgHgDIAAgUIABAAQAIAEALAEQAKAEALgBQAHAAAGgBQAHgDAFgEQAEgFACgFQACgGAAgIQAAgFgCgGQgDgEgEgEQgFgDgIgCQgHgBgJAAIgQABIgOACIAAhLIBXAAIAAARIhEAAIAAAnIAIAAIAIgBQAMAAAJACQAIACAIAFQAIAGAEAIQAEAIAAAMQAAAJgDAKQgEAJgHAHQgHAGgJAEQgKADgNAAQgMABgLgDgAivAjQgMgTAAgkQAAgnAMgTQAMgSAaAAQAaAAAMATQAMATAAAmQAAAlgMASQgMASgaAAQgaAAgMgSgAiYhMQgGAEgEAIQgDAHgBAMQgCALAAAOQAAAPACAJQABAJADAJQADAIAGAEQAGADAKAAQAJAAAGgDQAGgEAEgIQADgIABgKIABgYIgBgaQgBgLgEgHQgDgIgGgEQgGgDgJgBQgJABgGADgAqnAzQgLgDgIgEIAAgUIACAAQAIAGALADQALAEALgBQAGAAAHgBQAHgCAEgFQAFgEACgFQACgFAAgIQAAgGgDgFQgCgFgEgDQgFgDgGgBQgGgCgIABIgIAAIAAgRIAGAAQAPABAJgHQAJgGAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKACgKAHIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAJQAAAMgJAKQgIAIgMADIAAABIALADQAGADAEADQAFAEADAHQADAGAAAJQAAAJgEAIQgDAJgHAGQgHAHgKAEQgKACgMAAQgMAAgMgCgAFKAzIgWgqIgpAqIgWAAIA4g1Igfg2IAVAAIAWApIApgpIAWAAIg3A3IAeA0gAn8AzIgXgqIgoAqIgXAAIA4g1Igeg2IAUAAIAXApIAogpIAXAAIg4A3IAfA0gAstAzIBGh/IhTAAIAAgRIBjAAIAAAWIhCB6gAv2AzIAAgQIAeAAIAAhfIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgGIAPAAIAACAIAeAAIAAAQgAHuAZIAAgPIB0AAIAAAPgAl/gDIAEgQIBhAAIgEAQgAHugOIAAgPIB0AAIAAAPg");
	this.shape_3.setTransform(164.3,235);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},287).to({state:[{t:this.shape_3}]},9).wait(106));

	// formula7
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AuiBrIARhAIAYAAIgbBAgAJgBNIARhAIAZAAIgbBAgAgVBNIARhAIAXAAIgaBAgArFBHQgMgDgIgEIAAgUIACAAQAIAGAMADQALAEAKgBQAGAAAHgCQAHgBAFgFQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgIAAIgIAAIAAgPIAHAAQAOAAAKgFQAIgHABgMQAAgFgDgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKACgKAHIAAAAIAAgVIASgGQAMgDAKAAQALAAAIACQAJACAGAEQAHAFADAHQAEAGAAAJQAAAMgIAKQgJAIgLADIAAABIAKADQAGADAFABQAEAEADAHQADAGAAAKQAAALgDAHQgEAJgGAGQgIAHgKAEQgKACgMAAQgMAAgLgCgAobBHIgXgqIgoAqIgXAAIA4g3Igeg0IAUAAIAXAnIAognIAXAAIg4A1IAfA2gAtMBHIBGh/IhTAAIAAgRIBjAAIAAAWIhBB6gAwVBHIAAgQIAfAAIAAhfIgfAAIAAgNIAOgBQAGgBAEgCQAFgCACgEQADgEAAgGIAPAAIAACAIAeAAIAAAQgAM0AgQgOgMAAgTQAAgKAHgKQAHgKANgGIAAAAQgMgHgGgHQgFgIAAgLQAAgQANgLQAOgLAVAAQAWAAANAKQANALgBAQQAAAKgGAJQgGAKgMAFIAAABQAOAGAHAJQAHAIAAALQAAAUgOAMQgPAMgWAAQgYAAgOgMgAM/gRQgGAIAAAJQABAMAIAJQAKAJAOAAQAOAAAIgHQAJgIAAgNQAAgGgEgGQgEgGgMgFIgKgEIgOgFQgJAEgFAJgANGhWQgJAGABAKQAAAIADAEQAFAGAIADIAKAFIANAFQAJgGAFgHQADgIAAgJQAAgKgIgGQgIgHgMABQgNAAgHAFgAA9AgQgOgMABgTQgBgKAIgKQAGgKAOgGIAAAAQgMgHgGgHQgGgIAAgLQAAgQAOgLQAOgLAUAAQAWAAANAKQANALAAAQQAAAKgHAJQgFAKgNAFIAAABQAOAGAIAJQAGAIAAALQAAAUgOAMQgOAMgXAAQgYAAgOgMgABJgRQgGAIAAAJQAAAMAJAJQAJAJAPAAQAOAAAIgHQAIgIAAgNQAAgGgDgGQgFgGgLgFIgKgEIgPgFQgIAEgFAJgABPhWQgIAGAAAKQAAAIAEAEQAEAGAIADIAKAFIAOAFQAJgGAEgHQADgIABgJQgBgKgHgGQgJgHgMABQgNAAgHAFgALAAqQgLgDgHgDIAAgVIABAAQAHAFALAEQALADAKAAQAIAAAGgCQAHgCAEgFQAFgEACgGQACgFAAgHQAAgHgCgFQgDgFgFgEQgEgDgIgBQgHgCgJAAIgRABIgOADIAAhMIBYAAIAAARIhEAAIAAAoIAIgBIAHAAQAMAAAKACQAIABAHAGQAIAFAFAIQAEAJAAANQAAAIgDAJQgEAJgHAHQgHAGgJAFQgLADgMAAQgMAAgLgCgAHsAaQgMgTAAgkQAAgnAMgTQANgTAaAAQAaABAMASQAMAUAAAlQAAAmgMASQgNASgZAAQgaAAgNgSgAIEhWQgGAFgEAHQgEAIgBALQgBAMAAAOQAAAPABAKQABAIAEAIQADAIAGAEQAGAEAKAAQAJAAAGgEQAGgDADgJQAEgHABgJIABgaIgBgZQgCgLgDgIQgDgHgGgFQgGgDgJAAQgKAAgFADgAh+AqQgKgDgIgDIAAgVIABAAQAIAFALAEQALADAKAAQAHAAAGgCQAHgCAFgFQAFgEABgGQADgFAAgHQAAgHgDgFQgDgFgEgEQgFgDgIgBQgGgCgKAAIgQABIgOADIAAhMIBYAAIAAARIhFAAIAAAoIAIgBIAIAAQAMAAAJACQAIABAIAGQAIAFAEAIQAEAJABANQgBAIgDAJQgEAJgHAHQgGAGgKAFQgKADgNAAQgMAAgLgCgAPoApIgXgpIgoApIgXAAIA4g1Igeg2IAUAAIAXApIAogpIAXAAIg3A3IAeA0gAEzAmIAAgzIg1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAAzgAmEAbIAAgPIBzAAIAAAPgAmEgLIAAgQIBzAAIAAAQg");
	this.shape_4.setTransform(168.4,198.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},234).to({state:[{t:this.shape_4}]},10).wait(158));

	// formula6
	this.instance_3 = new lib.formula_5b("synched",0);
	this.instance_3.setTransform(136.4,265.2,1,1,0,0,0,80.4,47.9);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(234).to({startPosition:0,_off:false},0).to({y:227.6,alpha:0},10).wait(158));

	// formula_5
	this.instance_4 = new lib.formula_5b("synched",0);
	this.instance_4.setTransform(136.4,215.6,1,1,0,0,0,80.4,47.9);
	this.instance_4.alpha = 0;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Av6BiIARhAIAYAAIgbBAgAQzBdIAAgBQAHgHAIgJQAIgKAFgMQAHgNADgOQADgNABgPQgBgQgDgPQgEgOgGgMQgGgMgHgKQgHgJgIgHIAAgBIAWAAQASAUAJAXQAKAXAAAeQAAAbgKAYQgJAXgSAUgAFaBdQgQgUgLgXQgJgYAAgbQAAgeAJgXQALgXAQgUIAXAAIAAABQgIAHgHAJQgIAKgFAMQgHAMgDAOQgDAPgBAQQABAPADANQADAOAHANQAFAMAIAKQAIAJAHAHIAAABgAhYBZIARhAIAYAAIgcBAgAsdA+QgLgCgIgEIAAgUIABAAQAJAFALAEQALADALAAQAGAAAGgCQAIgCAEgEQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgBQgEgDgHgBQgFgCgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgGAAgMQAAgFgCgEQgDgEgEgDIgJgDIgKgBQgKAAgKADQgKADgKAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAHAEQAGAFAEAGQAEAHgBAJQAAAMgIAJQgJAJgLACIAAACIAKADQAHADAEADQAEAEADAFQADAGABAKQAAAKgEAIQgEAJgGAGQgHAHgLADQgKADgLAAQgMAAgMgDgApzA+IgWgpIgpApIgWAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAukA+IBHh+IhTAAIAAgRIBjAAIAAAWIhCB5gAxsA+IAAgPIAeAAIAAhfIgeAAIAAgNIANgBQAHgBADgCQAFgDACgDQADgEABgHIAOAAIAACBIAfAAIAAAPgAB5AsQgOgMAAgTQAAgMAHgIQAHgKANgGIAAAAQgMgHgFgHQgGgIAAgLQAAgQAOgLQANgLAUAAQAWAAANAKQANALABAQQgBAKgGAJQgGAKgMAFIAAABQAOAGAHAIQAHAIAAAMQAAATgOANQgPAMgXAAQgXAAgOgMgACEgFQgFAGAAAKQgBANAKAJQAJAJAOAAQAOAAAJgIQAIgHAAgNQAAgJgEgFQgEgEgLgFIgKgEIgPgFQgJAEgFAJgACKhKQgHAGgBAKQAAAHAFAFQAEAFAHAEIALAFIANAFQAKgHADgHQAEgHAAgJQAAgKgIgGQgIgHgNAAQgMAAgIAGgAIYAlQgMgSAAglQAAgnAMgSQAMgTAaAAQAaAAANATQAMATgBAmQABAlgMATQgNASgaAAQgaAAgMgTgAIvhKQgGAEgDAIQgEAHgBAMQgBALgBAOQABAPABAJQABAKAEAIQACAIAHAEQAFAEAKAAQAKAAAFgEQAHgEADgIQADgIACgKIAAgYIAAgaQgCgLgEgHQgCgIgHgEQgFgDgKAAQgJAAgGADgAAFA1QgJgCgIgEIAAgUIABAAQAJAFAJADQAKAEALAAQAGAAAHgCQAGgCAGgFQAEgEACgGQACgGAAgIQAAgGgDgEQgCgFgEgEQgGgDgHgCQgHgBgJAAIgQABIgNACIAAhLIBWAAIAAARIhFAAIAAAnIAJAAIAIgBQAMAAAIACQAJACAHAFQAJAGADAIQAFAJAAALQAAAKgEAJQgEAJgGAHQgHAGgKAEQgJAEgNAAQgMAAgLgDgAjMAlQgMgSAAglQAAgnAMgSQAMgTAZAAQAbAAAMATQAMATAAAmQAAAlgMATQgNASgaAAQgZAAgMgTgAi2hKQgGAEgDAIQgDAHgBAMQgCALAAAOQAAAPACAJQABAKADAIQADAIAGAEQAGAEAJAAQAKAAAGgEQAGgEAEgIQADgIABgKIABgYIgBgaQgBgLgEgHQgDgIgGgEQgGgDgKAAQgJAAgGADgAP9A1IgWgqIgpAqIgWAAIA3g1Igeg2IAVAAIAWApIApgpIAWAAIg4A2IAfA1gAGaA1IAAgPIAfAAIAAhgIgfAAIAAgNIAOgBQAHgBADgCQAFgCADgEQACgEAAgGIAQAAIAACBIAdAAIAAAPgAMOAyIAAgzIg1AAIAAgQIA1AAIAAg1IAQAAIAAA1IA1AAIAAAQIg1AAIAAAzgAnpAbIAAgQIB0AAIAAAQgAnpgMIAAgQIB0AAIAAAQg");
	this.shape_5.setTransform(177.1,161.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},181).to({state:[{t:this.shape_5}]},9).wait(212));

	// formula_4
	this.instance_5 = new lib.formula_3b("synched",0);
	this.instance_5.setTransform(137.4,151.6,1,1,0,0,0,80.4,47.9);
	this.instance_5.alpha = 0;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("A0wBtQgIAAgJgDIAAgSIABAAIAPAEQAKADAJAAQAKAAAGgDQAGgCAEgEQADgEABgFQABgGAAgHIAAgKQgHAIgIACQgIAEgLAAQgUAAgMgOQgLgPAAgZQAAgOAEgIQAEgLAHgHQAGgHAJgDQAKgFAIAAQAKAAAGADQAHABAGAEIACgEIARAAIAABeQAAAcgNANQgMANgaAAQgJAAgIgCgA0wgOQgJAKAAASQAAASAHAKQAGAJAPAAQAIAAAIgDQAIgDAGgGIAAg5QgGgEgHgBQgGgBgGAAQgQAAgIAKgAAKBQQgJgBgGgCIAAgTIABAAIAMAEQAKADAKAAQAJAAAHgDQAGgBADgFQADgEABgFQACgFAAgHIAAgKQgIAHgHADQgIAEgMgBQgUAAgJgNQgLgPAAgYQAAgOADgKQAEgKAHgHQAEgIAJgDQAKgEAJAAQAJAAAHACQAGACAHAEIABgFIARAAIAABeQAAAdgMANQgMANgbgBQgJABgHgCgAAJgsQgIAKAAAUQAAAQAGAKQAGAKAQgBQAHAAAJgDQAHgDAHgFIAAg5QgHgEgGgBQgHgCgGABQgPgBgJAKgAVmBQIAAAAQAHgIAIgJQAIgKAFgMQAHgMADgOQADgOABgPQgBgQgDgOQgEgPgGgMQgGgMgHgJQgHgKgIgHIAAgBIAWAAQASAUAJAXQAKAYAAAdQAAAbgKAYQgJAXgSAUgAKNBQQgQgUgLgXQgJgYAAgbQAAgdAJgYQALgXAQgUIAXAAIAAABQgIAHgHAKQgIAJgFAMQgHAMgDAPQgDAOgBAQQABAPADAOQADAOAHAMQAFAMAIAKQAHAJAIAIIAAAAgAv7A2QgMgTAAgkQAAgnAMgTQANgSAZAAQAbAAAMATQAMATgBAmQABAlgMASQgNASgaAAQgaAAgMgSgAvkg5QgGAEgDAIQgEAHgBAMQgBALgBAOQABANABALQABAJAEAJQACAIAHAEQAFADAKAAQAKAAAFgDQAHgEADgIQADgIACgKIABgYIgBgaQgCgLgEgHQgCgIgHgEQgFgDgKgBQgJABgGADgAxlBFQgJgDgGgGQgJgJgFgNQgEgOAAgSQAAgSAEgOQAEgPAKgMQAIgLANgHQAOgFASgBIAKABIAIACIAAATIgBAAIgIgEQgGgBgGAAQgVAAgMAOQgNAMgCAXQAIgFAJgCQAHgDALgBQAJABAHACQAHABAHAFQAJAGAFAHQAEAKAAANQAAAVgOAPQgQAOgUgBQgLAAgJgDgAxjgEQgIADgHABIgBAFIAAAFQABAQADAIQADAJAFAFQAFAFAFABQAFACAHAAQAOABAIgJQAIgJAAgQQAAgJgCgGQgDgGgGgCQgFgDgFgCIgMgBQgIAAgHACgA2KA+QgJgIAAgUIAAg4IgMAAIAAgPIAMAAIAAggIASAAIAAAgIAmAAIAAAPIgmAAIAAAwIAAANQABAFACAEQACAEAEACQAEACAIgBIAJgBIAHgCIABAAIAAARIgLACIgLABQgQAAgJgKgANLAZQgMgTAAglQAAgmAMgTQAMgTAaABQAaAAANASQAMAUgBAlQABAmgMASQgNASgaAAQgaAAgMgSgANihXQgGAFgDAHQgEAIgBALQgBALgBAOQABAQABAKQABAIAEAIQACAIAHAEQAFAEAKAAQAKAAAFgEQAHgDADgJQADgHACgJIAAgaIAAgZQgCgLgEgIQgCgHgHgFQgFgDgKAAQgJAAgGADgAE+AZQgMgTABglQgBgmAMgTQANgTAZABQAbAAAMASQAMAUAAAlQAAAmgMASQgNASgaAAQgaAAgMgSgAFWhXQgHAFgDAHQgDAIgCALQgBALAAAOQAAAQABAKQACAIADAIQADAIAGAEQAGAEAJAAQAKAAAGgEQAGgDADgJQADgHACgJIABgaIgBgZQgBgLgEgIQgDgHgGgFQgGgDgKAAQgIAAgGADgADJAoQgLgCgIgEIAAgUIACAAQAIAFALAEQALADALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgEAAgGQAAgJgDgFQgCgFgEgDQgEgCgHgBQgGgCgHAAIgJAAIAAgQIAGAAQAQAAAIgGQAKgHgBgMQABgFgDgEQgCgDgEgDIgJgEIgLAAQgJAAgLADQgKADgJAGIgCAAIAAgUIATgHQALgCALAAQALgBAIACQAJACAGAFQAHAFAEAGQADAGAAAKQAAAMgJAJQgIAJgMACIAAACIALADQAGADAEADQAFAEADAHQADAGAAAKQAAAIgEAIQgDAJgHAFQgHAIgKADQgKADgLAAQgMAAgNgDgAhPAhQgIgJAAgTIAAg5IgNAAIAAgPIANAAIAAgfIASAAIAAAfIAlAAIAAAPIglAAIAAAyIAAALQAAAFADAEQACAEAEADQAEABAHAAIAJgBIAIgCIAAAAIAAAQIgKADIgLAAQgRAAgJgJgAn7AqIgWgqIgpAqIgWAAIA4g1Igfg2IAVAAIAWApIApgpIAWAAIg4A3IAfA0gAUwAoIgWgoIgpAoIgWAAIA4g1Igfg2IAVAAIAWApIApgpIAWAAIg4A3IAfA0gALNAoIAAgPIAfAAIAAhgIgfAAIAAgMIAOgCQAHgBADgCQAFgCADgEQACgEAAgGIAQAAIAACBIAdAAIAAAPgARBAlIAAgzIg1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAAzgAlLAbIAAgQIBzAAIAAAQgArKATIAAgZIAYAAIAAAZgAt+AFQgLgLAAgWQAAgXALgNQAMgNATAAQATAAAMANQAMAMAAAYQAAAWgMALQgMAMgTAAQgTAAgMgMgAtxg1QgHAIAAARQAAAQAHAIQAGAHAMAAQAMAAAHgHQAGgIAAgQQAAgSgGgIQgHgIgMAAQgMAAgGAJgAG8gXQgMgMAAgXQAAgXAMgNQALgNATABQAUgBAMANQAMANgBAXQABAXgMAMQgMANgUAAQgTAAgLgNgAHIhTQgHAJABAQQgBAQAHAJQAHAIALAAQANAAAGgIQAGgJAAgQQAAgRgGgIQgGgIgNAAQgLgBgHAJgAlLgNIAAgPIBzAAIAAAPg");
	this.shape_6.setTransform(206.7,125.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},111).to({state:[{t:this.shape_6}]},24).wait(267));

	// formula_3
	this.instance_6 = new lib.formula_3("synched",0);
	this.instance_6.setTransform(397.4,32.6,1,1,0,0,0,80.4,47.9);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(109).to({startPosition:0,_off:false},0).to({x:151.4,y:154.6,alpha:0},23).wait(270));

	// formula2b
	this.instance_7 = new lib.formula_2b("synched",0);
	this.instance_7.setTransform(317.1,53.4);
	this.instance_7.alpha = 0;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Am7BfQgIgBgIgDIAAgSIABAAIAOAEQAKADAKAAQAJAAAHgDQAFgCAEgEQAEgEAAgFQACgFAAgHIAAgKQgIAHgHADQgJADgLAAQgTAAgMgOQgLgOAAgZQAAgNADgKQAFgKAHgIQAGgHAIgDQAKgEAJAAQAJAAAGACQAHABAHAEIACgEIARAAIAABeQAAAcgNANQgNANgaAAQgIAAgJgBgAm7gdQgIAKgBATQABARAGAKQAHAJAOAAQAIAAAJgDQAHgDAHgFIAAg6QgHgDgHgBQgFgCgHAAQgPAAgJAKgAOgBfIAAgBQAIgHAHgJQAHgKAHgMQAFgNAEgOQADgNAAgQQAAgPgDgPQgEgOgFgMQgHgMgHgKQgHgJgIgHIAAgBIAWAAQASAUAJAXQAJAXAAAdQAAAcgJAYQgJAXgSAUgADIBfQgSgUgJgXQgKgYAAgcQAAgdAKgXQAJgXASgUIAWAAIAAABQgIAHgHAJQgIAKgFAMQgGAMgEAOQgEAPAAAPQAAAQAEANQAEAOAGANQAFAMAIAKQAHAJAIAHIAAABgAGFAnQgMgSAAglQAAgnAMgSQAMgTAaAAQAaAAAMATQAMATAAAmQAAAlgMATQgMASgaAAQgaAAgMgTgAGchIQgGAEgEAIQgDAHgBAMQgCALAAAOQAAAPACAJQABAKADAIQAEAIAFAEQAHAEAJAAQAJAAAHgEQAGgEADgIQADgIABgKIABgYIgBgaQgBgLgDgHQgEgIgFgEQgHgDgJAAQgJAAgGADgAiGAnQgMgSAAglQAAgnAMgSQANgTAaAAQAaAAAMATQAMATAAAmQAAAlgMATQgNASgZAAQgaAAgNgTgAhuhIQgGAEgEAIQgEAHgBAMQgBALAAAOQAAAPABAJQABAKAEAIQADAIAGAEQAGAEAKAAQAJAAAGgEQAGgEADgIQAEgIABgKIABgYIgBgaQgCgLgDgHQgDgIgGgEQgGgDgJAAQgKAAgFADgAj7A3QgLgDgIgDIAAgVIACAAQAIAGAMADQAKAEALAAQAGAAAHgCQAHgCAFgEQAEgFACgFQACgFAAgIQAAgIgDgDQgCgFgEgDQgFgDgGgBQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKADgJAGIgBAAIAAgVIASgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgIAKQgJAJgMACIAAABIALAEQAGACAFAEQAEAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDgAoVAwQgIgJgBgUIAAg4IgMAAIAAgPIAMAAIAAggIATAAIAAAgIAlAAIAAAPIglAAIAAAwIAAANQABAFACAEQACAEAEACQAEACAHAAIAJgBIAHgDIABAAIAAARIgLACIgKABQgRAAgJgJgANqA3IgXgqIgoAqIgWAAIA3g3Igeg0IAUAAIAXApIAogpIAXAAIg4A1IAfA2gAEIA3IAAgPIAeAAIAAhgIgeAAIAAgNIANgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACBIAeAAIAAAPgAuQA3IANg8IADgJIAAgIQAAgIgEgEQgEgFgKAAQgIAAgJAFQgJAEgIAFIgTBQIgSAAIAjiWIASAAIgNA3QAKgIAJgDQAKgEAJAAQAPAAAIAHQAHAHABAOIAAAGIgCAHIgQBFgAJ7A0IAAg0Ig2AAIAAgPIA2AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA0gAr+ATIAAgPIB0AAIAAAPgAgJgIQgLgNAAgWQAAgXALgNQAKgNAUAAQASAAAMANQAMANAAAXQAAAXgMAMQgMALgSAAQgUAAgKgLgAAChEQgEAIAAARQAAAQAEAJQAHAIAMAAQAMAAAGgIQAHgJgBgQQABgRgHgJQgGgIgMAAQgMAAgHAJgAr+gUIAAgPIB0AAIAAAPg");
	this.shape_7.setTransform(418.4,70);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},54).to({state:[{t:this.shape_7}]},7).wait(341));

	// formula1b
	this.instance_8 = new lib.formula_1b("synched",0);
	this.instance_8.setTransform(320.7,-10);
	this.instance_8.alpha = 0;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AicBfQgJgBgIgDIAAgSIABAAIAOAEQAKADAKAAQAJAAAHgDQAGgCADgEQAEgEABgFQABgFAAgHIAAgKQgIAHgHADQgIADgMAAQgTAAgMgOQgLgOAAgZQAAgNAEgKQAEgKAHgIQAGgHAJgDQAJgEAJAAQAKAAAGACQAGABAHAEIACgEIARAAIAABeQAAAcgNANQgMANgbAAQgIAAgIgBgAidgdQgIAKAAATQAAARAGAKQAHAJAPAAQAIAAAIgDQAIgDAGgFIAAg6QgHgDgGgBQgGgCgHAAQgPAAgJAKgACXAnQgMgSAAglQAAgnAMgSQAMgTAaAAQAaAAAMATQAMATAAAmQAAAlgMATQgMASgaAAQgaAAgMgTgACuhIQgGAEgEAIQgDAHgBAMQgCALAAAOQAAAPACAJQABAKADAIQADAIAGAEQAGAEAKAAQAJAAAGgEQAGgEAEgIQADgIABgKIABgYIgBgaQgBgLgEgHQgDgIgGgEQgGgDgJAAQgJAAgGADgAAtA2QgJgDgHgGQgIgJgFgNQgEgNAAgRQAAgTAEgPQAEgPAJgMQAJgLANgGQAOgGASAAIAJAAIAIACIAAATIgBAAIgIgDQgFgCgGAAQgVAAgNAOQgMANgCAWQAIgFAIgCQAIgDAKAAQAKAAAHACQAHABAHAFQAJAGAEAKQAFAJAAALQAAAWgPAOQgPAOgVAAQgLAAgIgEgAAugSQgHACgHAEIgBAEIAAAFQAAAOAEAIQADAJAFAGQAFAEAFACQAFACAGAAQAPAAAIgJQAIgIAAgRQAAgIgDgFQgDgGgGgEQgEgDgGgBIgLgBQgIAAgIACgAj3AwQgIgJAAgUIAAg4IgNAAIAAgPIANAAIAAggIASAAIAAAgIAmAAIAAAPIgmAAIAAAwIAAANQABAFACAEQACAEAEACQAEACAIAAIAJgBIAHgDIABAAIAAARIgLACIgLABQgRAAgJgJgAKOA3IgWgqIgpAqIgWAAIA4g3Igfg0IAVAAIAWApIApgpIAWAAIg3A1IAeA2gApyA3IAOg8IACgJIAAgIQAAgIgEgEQgEgFgKAAQgIAAgJAFQgJAEgIAFIgTBQIgSAAIAjiWIASAAIgNA3QALgIAJgDQAJgEAKAAQAOAAAIAHQAIAHAAAOIAAAGIgCAHIgQBFgAngATIAAgPIB0AAIAAAPgAHIAFIAAgaIAYAAIAAAagAEUgIQgMgNAAgWQAAgXAMgNQALgNAUAAQATAAAMANQAMANAAAXQAAAXgMAMQgMALgTAAQgUAAgLgLgAEghEQgGAIAAARQAAAQAGAJQAHAIAMAAQAMAAAGgIQAHgJAAgQQAAgRgHgJQgGgIgMAAQgMAAgHAJgAnggUIAAgPIB0AAIAAAPg");
	this.shape_8.setTransform(383.3,4.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},26).to({state:[{t:this.shape_8}]},8).wait(368));

	// 1alinia
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAwADIiRAAIAAgFICRAAIAAgwIAzAyIgzAyg");
	this.shape_9.setTransform(294.7,3.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAwADIiSAAIAAgFICSAAIAAgwIAyAyIgyAzg");
	this.shape_10.setTransform(293.8,67.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAwADIiRAAIAAgFICRAAIAAgvIAzAxIgzAyg");
	this.shape_11.setTransform(294.7,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},19).to({state:[{t:this.shape_11},{t:this.shape_10}]},28).wait(355));

	// parentesi
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAZD/IAAiJQAAg1gTgYQgRgZgvgFIAAgWQAvgFARgYQATgZAAg0IAAiJIAhAAIAACHQABA/gaAaQgZAbg6ACIAAADQA7ADAZAaQAYAaAAA/IAACHg");
	this.shape_12.setTransform(64.3,36.8,1,1.631);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).wait(402));

	// formula2
	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(230.5,72.5);

	this.text_2 = new cjs.Text("+", "italic 20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(207.1,72.5);

	this.text_3 = new cjs.Text("0", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(187.4,72.5);

	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(174.7,72.5);

	this.text_5 = new cjs.Text("=", "20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(154,54.3);

	this.text_6 = new cjs.Text("º", "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(136.1,54.3);

	this.text_7 = new cjs.Text("0", "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(123.4,54.3);

	this.text_8 = new cjs.Text("3", "20px Verdana");
	this.text_8.lineHeight = 20;
	this.text_8.setTransform(110.7,54.3);

	this.text_9 = new cjs.Text("g", "20px Verdana");
	this.text_9.lineHeight = 20;
	this.text_9.setTransform(91.2,54.3);

	this.text_10 = new cjs.Text("t", "20px Verdana");
	this.text_10.lineHeight = 20;
	this.text_10.setTransform(83.3,54.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("AktAAIJbAA");
	this.shape_13.setTransform(213.8,69.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AASBLIAOg+IACgJIAAgGQAAgHgDgEQgFgFgKAAQgIAAgIAFQgHADgJAGIgTBPIgSAAIAjiWIASAAIgMA3QAKgHAHgEQAJgDAKAAQAOAAAIAGQAIAIAAAOIAAAFIgCAFIgQBHg");
	this.shape_14.setTransform(208.7,54.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1}]}).wait(402));

	// text
	

	// formules
	this.text_11 = new cjs.Text("=", "20px Verdana");
	this.text_11.lineHeight = 20;
	this.text_11.setTransform(151.4,-9.3);

	this.text_12 = new cjs.Text("º", "20px Verdana");
	this.text_12.lineHeight = 20;
	this.text_12.setTransform(133.4,-9.3);

	this.text_13 = new cjs.Text("0", "20px Verdana");
	this.text_13.lineHeight = 20;
	this.text_13.setTransform(120.7,-9.3);

	this.text_14 = new cjs.Text("6", "20px Verdana");
	this.text_14.lineHeight = 20;
	this.text_14.setTransform(108,-9.3);

	this.text_15 = new cjs.Text("g", "20px Verdana");
	this.text_15.lineHeight = 20;
	this.text_15.setTransform(88.5,-9.3);

	this.text_16 = new cjs.Text("t", "20px Verdana");
	this.text_16.lineHeight = 20;
	this.text_16.setTransform(80.6,-9.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("AjQAAIGhAA");
	this.shape_15.setTransform(201.5,5.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AATDSIgUgqIgpAqIgWAAIA4g4Igfg2IAVAAIAUAqIApgqIAWAAIg3A4IAeA2gAATg4IAOg+IACgJIAAgJQAAgIgEgDQgEgFgKAAQgIAAgJAFQgHAEgIAFIgTBSIgSAAIAjiYIARAAIgMA2QALgHAHgDQAJgFAKAAQAOABAIAGQAIAIAAANIAAAGIgCAIIgQBHg");
	this.shape_16.setTransform(200.8,4.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11}]}).wait(402));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(58.4,-16.7,188.2,117.6);


(lib.mc_pant_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// frase_3
	this.instance = new lib.frase3("synched",0);
	this.instance.setTransform(88.5,150.7,1,1,0,0,0,90.6,27);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(177).to({startPosition:0,_off:false},0).to({alpha:1},6).wait(6));

	// frase2
	this.instance_1 = new lib.frase_2("synched",0);
	this.instance_1.setTransform(112.1,111.2,1,1,0,0,0,112.9,66);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(93).to({startPosition:0,_off:false},0).to({alpha:1},7).wait(89));

	// mascara_angle1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_43 = new cjs.Graphics().p("AzDAkQgUAAAAgUIAAgfQAAgUAUAAMAmHAAAQAUAAAAAUIAAAfQAAAUgUAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AzDB3QgUAAAAhCIAAhpQAAhCAUAAMAmHAAAQAUAAAABCIAABpQAABCgUAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AzDDLQgUAAAAhwIAAi1QAAhwAUAAMAmHAAAQAUAAAABwIAAC1QAABwgUAAg");
	var mask_graphics_46 = new cjs.Graphics().p("AzDEfQgUAAAAifIAAj/QAAifAUAAMAmHAAAQAUAAAACfIAAD/QAACfgUAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AzDFzQgUAAAAjNIAAlLQAAjNAUAAMAmHAAAQAUAAAADNIAAFLQAADNgUAAg");
	var mask_graphics_48 = new cjs.Graphics().p("AzDHGQgUAAAAj7IAAmVQAAj7AUAAMAmHAAAQAUAAAAD7IAAGVQAAD7gUAAg");
	var mask_graphics_49 = new cjs.Graphics().p("AzDIaQgUAAAAkpIAAnhQAAkpAUAAMAmHAAAQAUAAAAEpIAAHhQAAEpgUAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AzDJuQgUAAAAlXIAAosQAAlYAUAAMAmHAAAQAUAAAAFYIAAIsQAAFXgUAAg");
	var mask_graphics_51 = new cjs.Graphics().p("AzDLBQgUAAAAmFIAAp3QAAmFAUAAMAmHAAAQAUAAAAGFIAAJ3QAAGFgUAAg");
	var mask_graphics_52 = new cjs.Graphics().p("AzDMVQgUAAAAmzIAArCQAAm0AUAAMAmHAAAQAUAAAAG0IAALCQAAGzgUAAg");
	var mask_graphics_53 = new cjs.Graphics().p("AzDNpQgUAAAAniIAAsNQAAniAUAAMAmHAAAQAUAAAAHiIAAMNQAAHigUAAg");
	var mask_graphics_54 = new cjs.Graphics().p("AzDO9QgUAAAAoQIAAtYQAAoRAUAAMAmHAAAQAUAAAAIRIAANYQAAIQgUAAg");
	var mask_graphics_55 = new cjs.Graphics().p("AzDQQQgUAAAAo+IAAujQAAo+AUAAMAmHAAAQAUAAAAI+IAAOjQAAI+gUAAg");
	var mask_graphics_56 = new cjs.Graphics().p("AzDRkQgUAAAApsIAAvuQAAptAUAAMAmHAAAQAUAAAAJtIAAPuQAAJsgUAAg");
	var mask_graphics_57 = new cjs.Graphics().p("AzDS4QgUAAAAqbIAAw5QAAqbAUAAMAmHAAAQAUAAAAKbIAAQ5QAAKbgUAAg");
	var mask_graphics_58 = new cjs.Graphics().p("AzDULQgUAAAArIIAAyEQAArJAUAAMAmHAAAQAUAAAALJIAASEQAALIgUAAg");
	var mask_graphics_59 = new cjs.Graphics().p("AzDVfQgUAAAAr3IAAzPQAAr3AUAAMAmHAAAQAUAAAAL3IAATPQAAL3gUAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AzDWzQgUAAAAslIAA0aQAAsmAUAAMAmHAAAQAUAAAAMmIAAUaQAAMlgUAAg");
	var mask_graphics_61 = new cjs.Graphics().p("Ag/dTQgUAAAAtTIAA1mQAAtTAUAAMAmHAAAQAUAAAANTIAAVmQAANTgUAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(43).to({graphics:mask_graphics_43,x:355.3,y:70.1}).wait(1).to({graphics:mask_graphics_44,x:355.3,y:78.5}).wait(1).to({graphics:mask_graphics_45,x:355.3,y:86.9}).wait(1).to({graphics:mask_graphics_46,x:355.3,y:95.2}).wait(1).to({graphics:mask_graphics_47,x:355.3,y:103.6}).wait(1).to({graphics:mask_graphics_48,x:355.3,y:112}).wait(1).to({graphics:mask_graphics_49,x:355.3,y:120.4}).wait(1).to({graphics:mask_graphics_50,x:355.3,y:128.7}).wait(1).to({graphics:mask_graphics_51,x:355.3,y:137.1}).wait(1).to({graphics:mask_graphics_52,x:355.3,y:145.5}).wait(1).to({graphics:mask_graphics_53,x:355.3,y:153.8}).wait(1).to({graphics:mask_graphics_54,x:355.3,y:162.2}).wait(1).to({graphics:mask_graphics_55,x:355.3,y:170.6}).wait(1).to({graphics:mask_graphics_56,x:355.3,y:178.9}).wait(1).to({graphics:mask_graphics_57,x:355.3,y:187.3}).wait(1).to({graphics:mask_graphics_58,x:355.3,y:195.7}).wait(1).to({graphics:mask_graphics_59,x:355.3,y:204.1}).wait(1).to({graphics:mask_graphics_60,x:355.3,y:212.4}).wait(1).to({graphics:mask_graphics_61,x:239.7,y:187.6}).wait(128));

	// angle1
	this.instance_2 = new lib.angle_30("synched",0);
	this.instance_2.setTransform(358.5,229.9,1,1,0,0,0,93.5,146.2);
	this.instance_2._off = true;

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(43).to({startPosition:0,_off:false},0).wait(146));

	// mascra_Far (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_31 = new cjs.Graphics().p("AwOZ2QgUAAAAgUMAAAgzDQAAgUAUAAMAgdAAAQAUAAAAAUMAAAAzDQAAAUgUAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_1_graphics_31,x:272,y:215.5}).wait(158));

	// FlashAICB
	this.instance_3 = new lib.far("synched",0);
	this.instance_3.setTransform(275.5,262.9,0.896,0.896,0,0,0,154.2,202.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({startPosition:0,_off:false},0).to({alpha:1},5).wait(153));

	// angle2
	this.instance_4 = new lib.angle_60("synched",0);
	this.instance_4.setTransform(358.5,229.9,1,1,0,0,0,93.5,146.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(155).to({startPosition:0,_off:false},0).wait(34));

	// senyor2
	this.instance_5 = new lib.PERSONA("synched",0);
	this.instance_5.setTransform(458,350,0.052,0.052,0,0,0,373.7,500.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(115).to({startPosition:0,_off:false},0).to({x:652.8,y:351.3},24).wait(50));

	// senyor
	this.instance_6 = new lib.PERSONA("synched",0);
	this.instance_6.setTransform(458,350,0.052,0.052,0,0,0,373.7,500.2);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(31).to({startPosition:0,_off:false},0).to({alpha:1},5).wait(79).to({alpha:0.488},0).wait(74));

	// frase1
	this.instance_7 = new lib.frase1("synched",0);
	this.instance_7.setTransform(224,14,1,1,0,0,0,224,14);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(19).to({startPosition:0,_off:false},0).to({alpha:1},6).wait(164));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.angle_gran = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("30º", "18px Verdana");
	this.text.color="#FF0000";
	this.text.setTransform(318.9,265.3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1,1,1).p("AgYBEQgNgTABgaQADgzBGgn");
	this.shape.setTransform(357.9,285.1);

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(1,1,1).p("A9223MA7tAtv");
	this.shape_1.setTransform(191.2,146.4);

	this.addChild(this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,382.3,292.9);


(lib.angle_gra2 = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("h", "italic 20px Verdana");
	this.text.lineHeight = 22;
        this.text.color="#FF0000";
	this.text.setTransform(-214.1,-24.4+incremento);

	// Capa 1
	/*this.text_1 = new cjs.Text("10 + x", "20px Verdana");
	this.text_1.textAlign = "center";
    this.text_1.color="#FF0000";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 377;
	this.text_1.setTransform(-1.4,132+incremento);*/
	
	var html = createDiv(txt['texto_formula'], "Verdana", "20px", '170px', '400px', "20px", "185px", "left", "#FF0000");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(-50, -480);
	
	

	this.instance = new lib.angle_gran("synched",0);
	this.instance.setTransform(0.1,-11.9,1,1,0,0,0,191.2,146.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(0.3,1,1).p("AAA23MAAAAtv");
	this.shape.setTransform(-191.9,-12.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(0.3,1,1).p("AyNAAMAkbAAA");
	this.shape_1.setTransform(0.5,133.7,1.641,1);

	this.addChild(this.shape_1,this.shape,this.instance,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-214.1,-158.3,405.3,318.7);


(lib.angle_gra = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("h", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-214.1,-21+incremento);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().ss(1,1,1).p("Ag6AAIB1gsIAABZg");
	this.shape.setTransform(99.9,148.5,1,1,0,0,0,145.9,3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AFmAAIrLAA");
	this.shape_1.setTransform(137.2,148.2,1,1,0,0,0,140.6,2.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().ss(1,1,1).p("Ag6gsIB1AsIh1Atg");
	this.shape_2.setTransform(179.1,147.2);

	this.text_1 = new cjs.Text("10 m", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(30.9,132+incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AEXAAIotAA");
	this.shape_3.setTransform(133.7,147.2,1.517,1);

	this.instance = new lib.angle_gran("synched",0);
	this.instance.setTransform(0.1,-11.9,1,1,0,0,0,191.2,146.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAA23MAAAAtv");
	this.shape_4.setTransform(-191.9,-12.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AyNAAMAkbAAA");
	this.shape_5.setTransform(0.5,133.7,1.641,1);

	this.addChild(this.shape_5,this.shape_4,this.instance,this.shape_3,this.text_1,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-214.1,-158.3,405.3,318.7);


(lib.Angle_2_gran = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.angle_gran("synched",0);
	this.instance.setTransform(0.1,-11.9,1,1,0,0,0,191.2,146.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.3,1,1).p("AAA23MAAAAtv");
	this.shape.setTransform(-191.9,-12.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(0.3,1,1).p("AyNAAMAkbAAA");
	this.shape_1.setTransform(0.5,133.7,1.641,1);

	this.addChild(this.shape_1,this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-191.1,-158.3,382.3,292.9);


(lib.mc_pant_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// angle2_petit
	this.instance = new lib.angle_60_pant2b("synched",0);
	this.instance.setTransform(78.8,195.1,1,1,0,0,0,93.5,146.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},7).wait(31));

	// formula2
	this.instance_1 = new lib.formula_2("synched",0);
	this.instance_1.setTransform(472.3,58.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(27).to({startPosition:0,_off:false},0).to({alpha:1},7).wait(4));

	// formules
	this.instance_2 = new lib.formula_1("synched",0);
	this.instance_2.setTransform(80.6,58.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({startPosition:0,_off:false},0).to({alpha:1},6).wait(18));

	// anhle_gram
	this.instance_3 = new lib.angle_gra2("synched",0);
	this.instance_3.setTransform(592.5,209.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(38));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,48.9,784.3,321.1);



(lib.mc_pant_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// angle2_petit
	this.instance = new lib.angle_60_pant2b("synched",0);
	this.instance.setTransform(81.9,203.2,1,1,0,0,0,93.5,146.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(34).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(23).to({startPosition:0},0).to({x:684.1,y:32.8},23).wait(101));

	// anhle_gram
	this.instance_1 = new lib.angle_gra2("synched",0);
	this.instance_1.setTransform(620.4,221.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(162).to({startPosition:0,_off:false},0).wait(27));

	// anhle_gram
	
	// angle2_gran
	this.instance_5 = new lib.angle_gra("synched",0);
	this.instance_5.setTransform(217.3,215);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(5).to({startPosition:0,_off:false},0).wait(184));

	// angle1
	this.instance_6 = new lib.angle_60_pant2("synched",0);
	this.instance_6.setTransform(81.9,203.2,1,1,0,0,0,93.5,146.2);
	this.instance_6.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({alpha:1},5).wait(184));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.6,55.8,405.7,318.5);

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV' || childNodes[i].id == 'mc_p2') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, color, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";
    html.style.color = color;
    
    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}