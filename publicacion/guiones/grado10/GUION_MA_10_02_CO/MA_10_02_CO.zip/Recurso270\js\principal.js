(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
     this.text = new cjs.Text(txt['titulo'], "72px Georgia", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 74;
	this.text.setTransform(473.5,133.6);

	this.instance = new lib._93533186arreglo();
	this.instance.setTransform(0.5,0);
           this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
     
        this.addChild(this.instance,this.text,this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.audioplay);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit1']);
this.instance=new lib.pagina1();
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         titulo2(this, txt['tit2']);
this.instance=new lib.pagina2();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3']);
this.instance=new lib.pagina3();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit4']);
this.instance=new lib.pagina4();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
this.instance=new lib.pagina5();
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
this.instance=new lib.pagina6();

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
this.instance=new lib.pagina7();

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
this.instance=new lib.pagina8();

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit5']);
this.instance=new lib.pagina9();

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame11());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame11 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
         titulo2(this, txt['tit5']);
this.instance=new lib.pagina10();

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.pagina10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Convexos: 0º < Â < 180º", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 299;
	this.text.setTransform(50.2,120.1);
 var html = createDiv(txt['text6'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(65));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(482,417.3,0.998,0.998,0.1,0,0,130.9,-124.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({regX:131.4,regY:-124.1,rotation:1.3,x:482.5,y:417.8},0).to({regX:130.9,rotation:-149.7,x:482,y:417.7},53).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(65));

	// Capa 5
	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(467.3,247.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AQaIzQAAgBAAgCQAAnSlJlGQlKlKnQAAQnSAAlJFKQhsBshJB6");
	this.shape.setTransform(489.3,361.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],-7.3,55.5,0,-7.3,55.5,113.8).s().p("AsaI2IAMAAIgOACIACgCgAPrItIgJgCIkhgBIgXgCIgXgCIiyADQgMAEgGAAIgSgHQgPgGgYAIIiJABQgGABgVAAQgVAAgFgBIh7gBIh4gMIhmAAIgGABQgugniohnIhIglQgwgZgVgSQgOgMg2gaQg0gYgSgSQgTgTgygXQg2gWgRgJQgQgIgogeQghgZghgLQgZgJgtgdIg+goQgOgNgNgIQBJh7BshsQFJlJHSAAQHQAAFKFJQFJFHAAHSIAAACgAlDIVQAFACAHAIIgGAAIgGABQABgFgBgGgAnQIMIAAAAIABAAgAkBIIIgJgHIAQAJIgHgCgAlfICIACAAIgCABIAAgBgApNHkIACgCIAFgGQACgDAGALg");
	this.shape_1.setTransform(489.3,361.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},64).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50.2,120.1,691.7,298);

   (lib.pagina9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Cóncavos: 180º < Â < 360º", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 330;
	this.text.setTransform(49.9,120.1);
 var html = createDiv(txt['text5'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(30));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(482.2,417.6,0.998,0.998,-179.8,0,0,130.6,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:130.7,regY:-124.1,scaleX:0.61,rotation:-299.8,x:481.8,y:417.5},29).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(30));

	// Capa 5
	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(330.6,325.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AI4PNQj9CXk7AAQnQAAlKlJQjLjMhPkAQgvidAAiyQAAixAvieQBPj/DLjMQFKlJHQAAQHSAAFJFJQFJFJAAHRQAAADAAAE");
	this.shape.setTransform(481.9,417.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],0,0,0,0,0,113.8).s().p("AsaMbQjMjLhNkBQgwidAAiyQAAixAwieQBNj/DMjLQFKlKHQAAQHSAAFJFKQFJFIAAHRIAAAHIimAAIgKACIj7AAQgkgHgXgCIgjgEInRAAQgQAEhBAGQggADAAAYIAjA/QAnBGAQAwQAQArA2BHQAdAlAQAQQAGAPAeAuQAfA0AbAnQATAcAcAxIAvBRQAMAVA6B0QAtBaAjA3Qj9CXk7AAQnQAAlKlJg");
	this.shape_1.setTransform(481.9,417.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},29).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(49.9,120.1,431.3,297.6);

   (lib.pagina8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Llanos: Â = 180º", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 265;
	this.text.setTransform(50,120.1);
 var html = createDiv(txt['text4'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(30));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(481.8,417.5,1,1,-139.6,0,0,131.1,-124.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({regX:130.6,regY:-124,scaleX:1,scaleY:1,rotation:-179.7,x:482.2,y:417.6},26).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(30));

	// Capa 5
	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(477.4,250.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AxjIuQABivAuibQBPj9DLjLQFKlKHQAAQHSAAFJFKQFHFEACHO");
	this.shape.setTransform(481.9,361);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],0,55.7,0,0,55.7,113.8).s().p("AtJIyQgggFgYAAQgjAAgJAEQgIADgOAAQgQAAgagIIgbgJQgegDgQAFQgMAGgEAAIgOgDIgMgCIgDAAQABiuAvibQBNj+DMjLQFKlJHQAAQHSAAFJFJQFHFFACHOIgXACQghAEgPAEIiPAAQgUgFgRgBIiMAAIgKABIheAAIgVgEIlhgBQgIgBgdAAQgeAAgHABIhzABIgKACIiYAAIgJgCIiugBQgRgBgUgDQgUgEgRgBIhNAAQgkAHhwAHIiBABQgfAJgyAAQgWAAgfgEg");
	this.shape_1.setTransform(481.9,361.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},29).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,120.1,431.4,297.1);

   (lib.pagina7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Obtusos: 90º < Â < 180º", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 336;
	this.text.setTransform(50,119.1);
 var html = createDiv(txt['text3'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(35));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(482,417.6,1,1,-89.9,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:131.1,regY:-124.1,rotation:-139.5,x:481.8,y:417.5},34).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(35));

	// Capa 5
	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(527.4,250.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AvdirQAdgiAgggQFKlKHSAAQHQAAFJFKQFJFGAAHSQAAAHAAAG");
	this.shape.setTransform(495.3,361.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],-13.2,55.5,0,-13.2,55.5,113.8).s().p("AHrI1IgngIIiFAAIgVAJIgMgDIgMgDIhMgBIgVgEIhiAAIgQADQgPADgVAAQgQAAg4gGQhBgHgLgGQgNgHgRgQIgYgZQgTgUgngfIhCg0QgugnhShAIiEhlIg/gvQgmgdgUgXQgOgPgkgiIg4g0QigiDgJgGQgTgOgPgIQAdgiAgggQFKlKHSAAQHQAAFJFKQFJFGAAHSIAAANQg0gFgYgFIjUAAIgKACIhLABQgpAJgjAAQgZAAgZgEg");
	this.shape_1.setTransform(495.3,362);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},34).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,119.1,432.1,297.7);

   (lib.pagina6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Rectos: Â = 90º", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 262;
	this.text.setTransform(50,120.1);
 var html = createDiv(txt['text2'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(35));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(481.9,417.6,1,1,-39.6,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-89.8,x:482},34).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(35));

	// Capa 5
	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(577.4,287.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AIvIxQAAnRlJlHQlFlHnPgC");
	this.shape.setTransform(538.4,361.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],-55.6,55.9,0,-55.6,55.9,113.8).s().p("AjOI1QgYgGgVgCIgYgBIihgBIgJgCIhMgBQgRgDgEgHQgBgDAAgOIADgkQABgWgKgNQgMgPgDgUQgBgJAAgcQAAgLAGgvIAGgwIAAmsIADg2IACg8QAAgQgGhKIgGhHQAAgRAJh4QHPACFFFIQFJFGAAHSIkZABQgkACgGABIjsAAIgLgEQgFgCgXAAQgZgBgNABQgTABgfAIg");
	this.shape_1.setTransform(537.7,361.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},2).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},32).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,120.1,632.2,297);


   (lib.pagina5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// texto
	this.text = new cjs.Text("Agudos: Â < 90º ", "bold 22px Verdana");
	this.text.lineHeight = 24;
	this.text.setTransform(50.2,119.2);
 var html = createDiv(txt['text1'], "Verdana", "23px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 120-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(35));

	// Capa 3
	this.instance = new lib.linea2();
	this.instance.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-39.5},34).wait(1));

	// lineaabajo
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(481.9,417.6,1,1,0,0,0,130.9,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(35));


	// Capa 10
	this.text_2 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(604.4,349.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EBH3AGuIAAAAQAAmdkDkvEg2RgRjQHSAAFJFJQFJFJAAHRQAAHSlJFJQlJFJnSAAQnSAAlKlJQjLjMhOkAQgwidAAiyQAAixAwieQBOj/DLjMQFKlJHSAAg");
	this.shape.setTransform(134.5,374.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],0,0,0,0,0,113.8).s().p("AsaMbQjMjMhNkAQgwidAAiyQAAixAwieQBNkADMjLQFKlJHQAAQHSAAFJFJQFJFJAAHRQAAHSlJFJQlJFJnSAAQnQAAlKlJg");
	this.shape_1.setTransform(-212.9,374.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],-56.5,35,0,-56.5,35,113.8).s().p("AoPFoQgXgIgHgMQAegYBLhBQBJg+A2gkQA4gmA9g9IBYhYQAZgYAkgZIA9gtIA9goQAlgcAHgXQADgLBwhOQAzgjAbgXQECExAAGbIAAAAIhcgBIgUgEIgRgCIhGAAIgUAEIhXABIgmAGIkGABIgSAEIiJABQgIABgKAEIhCgBIgZgCIgZgCIiEADQgRAEgGAAQgQAAgTgHg");
	this.shape_2.setTransform(538.5,382.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFFFF","rgba(255,255,0,0.439)"],[0,1],56.7,112.3,0,56.7,112.3,151.7).s().p("ApIETIAYgiQAMgPAPgKQgIAGgPAUIgaAkgAFUjwIAsgHIADAAQAAAGgnAFQgeAEgPAAQADgDAigFgAG8kEQAegKBfgHIAQAAQgRAGhHAJQhDAIgSAAg");
	this.shape_3.setTransform(293.3,388.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_2}]},34).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50.2,69,516.5,81);

   (lib.pagina4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.text = new cjs.Text("0º", "bold 14px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(643.2,350.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0.306)").ss(6,1,1).p("AgDXbIAA3MI3MAAAgD3aIAAXpIXSAA");
	this.shape.setTransform(473.6,366.9);

	this.text_1 = new cjs.Text("0º", "bold 14px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(643.2,350.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,0,0,0.302)").ss(6,1,1).p("AgD3aIAAXpI3MAAAgDXbIAA3MIXSAA");
	this.shape_1.setTransform(473.6,366.9);

	this.text_2 = new cjs.Text("0º", "bold 14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(643.2,350.3);

	this.text_3 = new cjs.Text("0º", "bold 14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(643.2,350.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{x:643.2,y:350.3,text:"0º",lineWidth:19}}]}).to({state:[{t:this.shape_1},{t:this.text_1,p:{x:643.2,y:350.3,text:"0º",lineWidth:19}},{t:this.text,p:{x:459.6,y:179.1,text:"90º",lineWidth:28}}]},19).to({state:[{t:this.shape_1},{t:this.text_2,p:{x:643.2,y:350.3,text:"0º",lineWidth:19}},{t:this.text_1,p:{x:459.6,y:179.1,text:"90º",lineWidth:28}},{t:this.text,p:{x:257.8,y:350.3,text:"180º",lineWidth:38}}]},22).to({state:[{t:this.shape_1},{t:this.text_3,p:{x:643.2,text:"0º",lineWidth:19}},{t:this.text_2,p:{x:459.6,y:179.1,text:"90º",lineWidth:28}},{t:this.text_1,p:{x:257.8,y:350.3,text:"180º",lineWidth:38}},{t:this.text,p:{x:454.8,y:529.5,text:"270º",lineWidth:38}}]},19).to({state:[{t:this.shape_1},{t:this.text_3,p:{x:633.6,text:"360º",lineWidth:38}},{t:this.text_2,p:{x:459.6,y:179.1,text:"90º",lineWidth:28}},{t:this.text_1,p:{x:257.8,y:350.3,text:"180º",lineWidth:38}},{t:this.text,p:{x:454.8,y:529.5,text:"270º",lineWidth:38}}]},20).wait(1));

	// Capa 4
	this.instance = new lib.circulolineas();
	this.instance.setTransform(470.3,364.7,1,1,90,0,0,149.1,149.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60).to({_off:false},0).wait(21));

	// Capa 5
	this.instance_1 = new lib.circulolineas();
	this.instance_1.setTransform(477.1,364.9,1,1,180,0,0,149.1,149.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(41).to({_off:false},0).wait(40));

	// Capa 6
	this.instance_2 = new lib.circulolineas();
	this.instance_2.setTransform(477.7,369.5,1,1,-89.9,0,0,149.1,149.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off:false},0).wait(62));

	// Capa 7
	this.instance_3 = new lib.circulolineas();
	this.instance_3.setTransform(469.9,369.9,1,1,0,0,0,149.1,149.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(81));

	
	
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,217,621.8,344.8);


   (lib.pagina3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// transportador
	this.instance = new lib.Símbolo10("synched",0);
	this.instance.setTransform(355.4,399.4,0.853,0.853,-179.9,0,0,195.3,193.1);
	this.instance.alpha = 0.762;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:196.7,regY:193.2,rotation:0,x:356.5,y:399.7},13).wait(1));

	
	// Capa 13
	this.text = new cjs.Text("= 30º", "bold 24px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(482.1,467);

	this.text_1 = new cjs.Text("Â", "bold 24px Verdana");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(451.2,467.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},13).wait(1));

	// Capa 14
	this.instance_2 = new lib.Símbolo3();
	this.instance_2.setTransform(400.4,336.9,1,1,0,0,0,201.1,99.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:0},13).wait(1));

	// Capa 15
	this.instance_3 = new lib.linea2();
	this.instance_3.setTransform(359.3,397.1,1,1,-29.9,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14));

	// lineaabajo
	this.instance_4 = new lib.linea2();
	this.instance_4.setTransform(359.3,397.1,1,1,0,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(14));

	// Capa 18
	this.instance_5 = new lib.Símbolo1();
	this.instance_5.setTransform(433.3,359.3,1,1,0,0,0,76.8,37.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).wait(14));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,76.1,685.2,488.1);

   (lib.pagina2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt

	// Capa 14
	this.instance_1 = new lib.Símbolo3();
	this.instance_1.setTransform(400.4,336.9,1,1,0,0,0,201.1,99.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({alpha:1},11).wait(1));

	// Capa 15
	this.instance_2 = new lib.linea2();
	this.instance_2.setTransform(359.3,397.1,1,1,-29.9,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(20));

	// lineaabajo
	this.instance_3 = new lib.linea2();
	this.instance_3.setTransform(359.3,397.1,1,1,0,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(20));

	// Capa 17
	this.text = new cjs.Text("Â", "bold 24px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(464.1,348.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).to({state:[{t:this.text}]},19).wait(1));

	// Capa 18
	this.instance_4 = new lib.Símbolo1();
	this.instance_4.setTransform(433.3,359.3,1,1,0,0,0,76.8,37.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(20));


}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,267.1,540.4,294.7);

   (lib.pagina1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	
	// Capa 15
	this.instance_1 = new lib.linea2();
	this.instance_1.setTransform(359.3,397.1,1,1,0,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({rotation:-29.8},33).wait(1));

	// lineaabajo
	this.instance_2 = new lib.linea2();
	this.instance_2.setTransform(359.3,397.1,1,1,0,0,0,131.3,-124.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(34));

	// Capa 17
	this.text = new cjs.Text("Â", "bold 24px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(464.1,348.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},33).wait(1));

	// Capa 18
	this.instance_3 = new lib.Símbolo1();
	this.instance_3.setTransform(433.3,359.3,1,1,0,0,0,76.8,37.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(33).to({_off:false},0).wait(1));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,530,101.7,31.8);

   
   (lib._93533186arreglo = function() {
	this.initialize(img._93533186arreglo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,632);


(lib._95249249Convertido = function() {
	this.initialize(img._95249249Convertido);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,381,217);


(lib.txt1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Dos semirrectas que parten del mismo punto forman un ángulo.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.setTransform(-66.9,-95.9);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-66.9,-95.9,725.8,30.7);


(lib.Símbolo10 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._95249249Convertido();
	this.instance.setTransform(6.8,0);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(6.8,0,381,217);


(lib.Símbolo6 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("La principal unidad para medir ángulos es el grado.", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(284.2,6);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-4.3,6,581.1,30.7);


(lib.Símbolo5 = function() {
	this.initialize();

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Símbolo4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Para medir ángulos se utiliza el transportador de ángulos.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.setTransform(-102.9,-93.9);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-102.9,-93.9,679.2,30.7);


(lib.Símbolo3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Lado", "bold 19px Verdana");
	this.text.lineHeight = 21;
	this.text.setTransform(134.4,41.9);

	this.text_1 = new cjs.Text("Vértice", "bold 19px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 21;
	this.text_1.setTransform(43.8,113);

	this.text_2 = new cjs.Text("Lado", "bold 19px Verdana");
	this.text_2.lineHeight = 21;
	this.text_2.setTransform(250.8,212.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4.3,1,1).p("AC1rlIHSC2AuWAAIHSC3AOXLmIAAly");
	this.shape.setTransform(186.5,138.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgwAxQgUgVAAgcQAAgcAUgUQAVgVAbAAQAdAAAUAVQAVAUgBAcQABAcgVAVQgUAUgdABQgbgBgVgUg");
	this.shape_1.setTransform(127.8,170);

	this.addChild(this.shape_1,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(6,41.9,300.2,198.1);


(lib.Símbolo2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Las semirrectas que forman el ángulo reciben el nombre de lados y el punto común del que parten, vértice.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 846;
	this.text.setTransform(-98.9,-95.9);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-98.9,-95.9,850,59.4);


(lib.Símbolo1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Ag+jxQBlDiAZEB");
	this.shape.setTransform(91.4,51.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFF00","#CCCCCC"],[0,1],0,0,0,0,0,54.6).s().p("AnnDxINPniQBnDiAZEBg");
	this.shape_1.setTransform(48.9,51.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,27.1,97.8,48.5);


(lib.linea2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(5,1,1).p("AzcAAMAm5AAA");
	this.shape.setTransform(261.5,-124.1,1.043,1);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.circulolineas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("ALfANI29AyIFwgDIRNgVALaglIxKBNIRKg0ALRg+I2vB9IFugX");
	this.shape.setTransform(222.6,141.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("ALTgyI2yCvIFugjIRGhyALKhlIw+CsIRAiTALRAAI2vB+IFugWIRJhPAlwBoIRJg2ALfBMI29AyIFwgDIROgVALAh9I2fD6IFrg2");
	this.shape_1.setTransform(222.6,135.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AK+hyI2dEtIEPgxISTjiALAg+IyQDIAKwijIwqEJIQvjwAl6BmIllBVIFugjIRGh0ALKgmIw+CrIRAiSALRA+I2vB+IFugWIRJhPAlwCmIRJg2ALfCKI29AyIFwgDIROgVALTAKI2yCxAKki7I2DF2IFrg2");
	this.shape_2.setTransform(222.6,129);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AKSjKIwWFPIlZBzIEKhJIR3lIAKlh+Ix4EtAK/g1I2cEtIEOgxISSjiALAgBIyPDIAKxhmIwrEJIQvjwAKMjiIwQFnALUBHI2yCxIFugjIRGh0ALKAVIw+CtIRAiUALSB7I2vB+IFugWIRJhPAlvDjIRJg2ALgDHI29AyIFwgDIROgVArdD4IgBAAIAAAAIAAAAIgCABIABgBIABAAIgBAAIAAAAIABAAIgCABAreD4IAAAAIAAAAIABAAIgBAAIABAAIAAAAIFjhVAKdiyI16GqIAAAAIFpg2AJ9j4I1bHw");
	this.shape_3.setTransform(222.5,122.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AJekfIvsHAIP0moAJ0jxI1SIkIFYiBIQDmKAKSiPIwWFPIlZBzIEKhIIR3lIAKlhCIx4EtAK/AFI2cEuIEOgwISSjlALAA4IyPDLAKxgqIwrEJIQvjxAKMinIwQFnALUCDI2yCxIFugjIRGh0ALKBQIw+CuIRAiVALSC3I2vB+IFugWIRJhPAlvEfIRJg2ALgEDI29AyIFwgDIROgVArdEzIgBABIAAAAIAAAAIgCAAIABAAIABAAIgBAAIAAAAIABAAIgCAAAreE0IAAAAIAAAAIABAAIgBAAIABgBIAAAAIFjhUAKdh2I16GpIAAABIFpg2AJOk0I0sJnIFQiSAJ9i9I1bHx");
	this.shape_4.setTransform(222.5,116.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIllZIvBIWIPMn/AI/ksI0eKWIFNidIPcniAJejnIvsHAIP0moAJ0i5I1SIkIFYiBIQDmKAKShXIwWFPIlWByIgDABIEKhIIR3lIAKlgKIx4EtAKMhvIwQFnAK/A9I2cEuIEOgwISSjlALABwIyPDLAKxAMIwrELIQvjzALUC7I2yCxIFugjIRGh0ALKCIIw+CuIRAiVALSDvI2vB+IFugWIRJhPAlvFXIRJg2ALgE7I29AyIFwgDIROgVAJ9iFI1bHxIgBAAIABAAIAAAAIAAAAIAAAAIAAAAIABAAIAAgBIgBABIAAAAIABAAIFpg2AreFsIgBAAIAAAAIgBAAIACAAArdFrIAAAAIADgBIV3moArgFsIACAAAITlsIzyLWIFDitAJOj8I0sJnIFQiSArdFrIFjhU");
	this.shape_5.setTransform(222.5,111.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBlnIydLgIBNgrICXhYIPGpGAHjmQIuOJoIObpTALgFxI29AyIFwgEIROgUALaE9IxJBPIRJg2ALKC+Iw+CuIRAiVAl0FsIlnA1IgBAAIFsgjIRGh0AKxBBIwrELIQvjyAraGgIAEgCIgIACIAKgEIADgCIAEgDIgDACIgEADIgBAAIACgBIgCABIACAAIABgBIADgBIgCABIgCABIgBABIgBAAIgEACIAAAAIgBABIgBAAIABAAIgBAAIAAABIEMgwISSjlALACmIyPDLAKMg5IwQFnIQWlPArbGhIAAAAIAAAAIAAAAIAAAAIABgBIEHhHIR3lKAKlApIx4EwAJ0iDI1GIeIgBABIFNh8IQDmLAJeixIvsHAIP0mpAI/j3Iz5KEIgKAGIEyiQIPcniAIlkjIvBIVIPMn+Am4D2IPLosArbGhIAAAAIgCAAIgBAAIAAAAIAAAAIAEgBAreGhIgCABIABgBIABAAIAAAAIAAAAIAAAAIgBAAIAAAAIABAAAreGhIABAAIAAAAIACgBIAAAAIABAAIAAAAIFWhyAreGhIABAAIAAAAArbGhIgBAAIAAAAIgBABIABgBIgCAAArbGhIAAgBIgCABArdGhIACAAALUDwI2wCxIABAAAreGhIgCABAmrDYIkNCyIgMAHIAKgFIAegTIgcARIgPAIIgFADIgTALIARgJIAEgCIgDACIAEgCIAFgCIgIAFIgDACIFBiLArRGaIADgBIAFgEIAGgDIgHADIAGgEIgIAEIgCACIgCACAJOjGI0aJeIgCABIgDACIgCAAIACgBArWGeIABgBIAAgBIgBABgArVGcIgBABIgIADgAraGgIAAAAIABgBIAGgDIgBABIgFACgArHGSIgYAOIAPgHArbGgIABAAAq6GMIAWgMIBVgyAq6GMIgJAGIAJgFIAWgNIEIiOAHQmiIyXM0AK/BzI2ZEtIFghUALSEkI2vB/IFugXAKdgJI13GpAJ9hPI1WHu");
	this.shape_6.setTransform(222.5,105.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBk1IydLgIBNgsICXhYIPGpGAG5mdIx4NbIAzgjICwh8IOkqnAHQlwIusKPAGYnEItVK1INjqgAIljyIvBIWIPMn/AI/jFIz5KEIgKAFIEyiQIPcniAJeiAIvsHAIP0moArQHMIABgBIACgBIgBAAIgCABIgBABIABAAIAAAAIAAAAIgBAAIFLh7IQDmKArdHSIgBABIABAAIAAgBIAAAAIACAAIAAAAIAAAAIABgBIAAABIgBAAIAAAAIAAAAIAAAAIACgBIgBABIgBAAIABgBIABAAIgBAAIAEgCIAAgBIgIAEIAIgDIABgBIgDACIgBABIgBAAIACAAIAAAAIAAAAIABAAIgBAAIAAAAIAAAAIABAAIEEhHIR3lKAKlBbIx4EvAKMgIIwQFnIQWlRAK/CkI2XEtIAAAAIEJgvISSjlALADXIyPDLAKxBzIwrELIQvjzALUEiI2tCwIFpgiIRGh0ALKDvIw+CuIRAiVALaFvIxJBPIRJg2ALgGiI27AyIFugDIROgVAHjlfIuOJoIObpSAm4EnIPLosAreHTIACAAIABgBIgBABIABgBIAAAAIgCABIgBAAIAAAAIAAAAIgBAAIABAAIAAAAIAAAAIAAAAIgBAAIAAAAIgBAAIACAAArdHSIACAAIgCAAArcHTIAAAAIACgBIAAAAIgBAAIAAAAIAAAAArZHSIgBAAIAAAAIgBACIgBAAIABAAIAAAAIWth+ArYHRIAAAAIAAAAIgBAAIABAAIgBAAIAAABIAAAAIAAAAIgCACIAAAAIgCAAIABAAIgBABIACgBIFsgWArcHTIgBAAIABAAArgHTIACAAArKHGIgCABIgCACIABgBIADgCIADgBIADgCIACgBIgFADIAEgCIAJgGIgIAFIAIgGIAughArHHFIgDACIABAAIgDACIgBABIABgBIgDACIFBiLArKHGIABgBIgDACIgBABIgCABIgQAIIAPgHIgDACIgBABIgBABIgJAEIAKgFAGDnUIxPOaIAEgBIgBAAIACgBIgBABIELjUArOHJIgCABIABAAIACgBIAAAAIADgCIgCACIgCABIgDACIgBAAIABAAIAAAAArPHKIgDACIgBAAIgBABIABAAIABgBIABAAIABgBIADgCIADgCIgBAAIAEgCIADgDIgDACArNHJIACgCIgCABIgCACArMHGIgTALIASgJgAJOiVI0aJeIAIgFIgFADIAGgEIAJgEIAWgNIBVgzArKHHIAGgEIAKgHIgKAGArHHFIgDACArOHJIgBAAIgBABAJ0hSI1FIeIABAAIAAAAArTHNIgBABIAAAAIABgBIABAAgArRHMIgBABIAAAAIABgBIgEAEIVSnuArTHNIgCABIABAAIABgBIABgBIgBABArNHJIgEADIgCABArUHOIgCABIgDACIAAAAIABgBIACgBIABAAIABgBIgBAAIAAAAArVHOIAAAAArWHOIABAAIABgBIgBABgArVHOIAAAAIgBABIgCABIABAAIACgBIACgCArbHUIABgCIABAAIAAAAIAAgBIAAAAIgBABIABAAAraHRIACAAIAAAAIAAgBIgBABArZHRIAAAAIgBABArZHSIABgBIgBAAIABAAAraHSIABAAAraHRIAAAAIgBABArSHNIgEADIgBABIABgBIABAAIgBAAIgBAAArWHQIgBABIV0mqArXHRIAAAAIAAAAIgBAAIABgBAraHSIgBACAraHRIgEACAraHRIgBABAmcEkIkICOIgWALAq6G8IACgBIENiyAqcGrIgeASAqcGrIgcAQAq/G+IgFAEAq/G+IgIAGArWHQIFShxArYHRIFehTArZHSIFlg1");
	this.shape_7.setTransform(222.5,101);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBkEIydLfIBNgrICXhYIPGpGAFDn2IsWL8IMmrpAFnnTIxAPSIEUjrIM9rTAG5lsIx4NbIAzgjICwh9IOkqmAHQk/IusKOAGYmTItVK1INjqgAIljBIvBIVIPMn+AI/iVIz5KEIgKAGIEyiQIPcniAJehPIvsHAIP0moAJ0ghI1FIeIAAAAIFLh7IQDmLAJ9ARI1SHvIgBABIgBAAIgBABIgBAAIAAAAIAAAAIgBAAIgBABIABAAIABgBIgBABIABAAIAAgBIABAAIAAAAIABAAIEEhHIR3lKAKlCMIx4EvAKMAnIwQFpIQWlRArZIDIgBAAIABAAIAAAAIABAAIEJgwISSjlALAEIIyPDLAKxCkIwrEKIQvjyAreIDIAAAAIAAABIABgBIgBAAIAAABIACgBIABAAIAAAAIgCAAIAAAAIACAAIAAAAIAAAAIAAAAIgBAAIAAAAIgBABIABgBIABAAIAAAAIABAAIAAAAIAAAAIAAAAIABAAIAAAAIAAAAIFpgjIRGhzALKEgIw+CuIRAiVALaGfIxJBQIRJg3ALgHTI27AyIFugDIROgVAHjkuIuOJoIObpSAm4FYIPLosAreIEIgCAAIABAAIABgBIgBABIAAAAIABAAIAAAAIAAAAArbIAIgEACIAEgCIAAAAIABAAIQGwFArfICIAFgCIABgBIgBABIAAAAIgCACIAAAAIgBAAIACgCIABAAIAKgFIgDACIgBABIABAAIAAAAIACgCIABAAIADgDIADgBIABAAIgCABIABgBIADgCIgDABIgBABIgBABIgBAAIAAAAIABAAIACgCIAGgDIgDABIADgCIgDABIAIgFIgFAEIAKgGIACgBIENiyAreIDIAEgBIAEgCIgGACIgBABIAAgBIABAAIAHgEIABAAIgIAEAraICIAAABIgBAAIAAAAIAAAAIABgBIABAAArbIDIAAAAIABAAArbIDIgCAAIAAAAIgBAAArWIBIgBAAIgBAAIAAAAIgBABIAAAAIgBAAIgBABIgCAAALSGGI2tB+IAAAAIgBABIgBABIACgBIgBAAArbIFIAAgBIABgBIABAAIgCABIFsgVAraIDIgBABIgCABIABAAAreIEIgCAAAqMHMIguAhIgKAHIACgBIgFADIAEgCIAJgGIAWgMIBVgyAm9EiIkMDUIgCABIAEgDIgCACIgDABIgBABIABAAIgCABIADgBIAEgDIgEACIgBABArQH8IACgBIADgCIgDACIACgBIAIgFIgFADAq6HvIgJAFIgGAEArOH5IAAAAIgBABIgBABIAAAAIgCACIgBAAIgBABArOH5IgCACIADgCIgEADIgBABIgBABIgBAAIABAAIABAAIABgBIAAAAIgBABIAAAAIgBAAIgBABIABgBIgDADArRH9IgCABArTH+IABAAIAAAAIADgCIgCABIgBABIABgBIgEADIgBABIFShxArUH+IgBAAIgBABIAAABIABgBIAAgBIABAAIgBABIgCABIAEgCArYIBIACgBIABgBIAAAAIgBABIgCABIgBABIABgBIgBABIABAAIAAAAIABgBIAAgBArUH+IgBAAIACAAArUH/IgBAAIAAgBIgBABIgGADAK/DVI2WEtIgBABIgBAAIFlg1ArcIDIACAAIAAAAIAAAAArXICIgBAAIgBABIAAAAArYICIgBAAArYICIAAAAArXICIAAgBIAAABIgBAAArYIBIgBABAraICIAAAAIABAAAraIDIAAAAIgBABArXIBIABAAIgBAAIV0mpArXICIAAAAIFdhUArYIBIABgBArXICIAAgBArMH6IgDACIgCABArPH8IABgBIAAAAIgDACArMH3IgIAFIAHgEIgCACIgLAGIgBAAArQH8IgBABArUH8IgFADArdICIADgCAraICIgBABAq6HvIAWgNAqcHbIgeATIgIAFIAIgGAqcHbIgcARAraIAIEHj6AGDmjIxPOaArPH8IFBiLAJOhkI0aJeALUFTI2tCwAmcFUIkICO");
	this.shape_8.setTransform(222.5,96.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBjbIydLgIBNgrICXhYIPGpGAD2oRIrhMuIjrEIIgBACIAEgEIAHgHIARgRICsiuIMttNAEsnbIs7M4ADkojIrPNAAFnmpIw7PNIgCACIERjoIM9rTAFDnNIsWL9IMmrpAG5lCIx4NbIAzgjICwh9IOkqmAHQkWIusKPAGYlpItVK0INjqgAIliXIvBIVIPMn+AI/hrIz5KEIgKAGIEyiQIPcniAJeglIvsHAIP0mpAJ0AHI1FIgIAAAAIFLh7IQDmNAKdCCI10GpIAAABIEEhHIR3lKAKlC1Ix4EwAKMBRIwQFpIQWlRAK/D/I2WEtIAAAAIgBAAIAAAAIAAAAIgBAAIAAAAIgBABIABAAIAAgBIABAAIEJgvISSjlALAEyIyPDLAKxDNIwrELIQvjyArbItIgCAAIAAAAIABgBIAAAAIgBABIAAAAIAAAAIAAAAIACgBIAAABIAAAAIAAAAIAAAAIgBAAIABAAIABAAIAAAAIAAAAIAAAAIABAAIAAAAIAAAAIFpgjIRGh0ALKFKIw+CuIRAiVALaHJIxJBPIRJg2ALSGwI2tB+IAAAAIgBABIABAAIFugDIROgVAHjkEIuOJoIObpTAm4GCIPLosArfItIABAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAAAIABAAIAAAAIAAAAIABAAIAAAAIAAAAArUIoIABAAIgCAAIABAAIABAAIABgBIgBAAIgBABIgBAAIgBABIgFACIAAABIgCABIADgBIgBAAIAAAAIABAAIgBAAIgCABIAAAAIAAAAIgBAAArbIrIAGgDIABAAIgHADIAAAAIAAAAIAAAAIAAAAIABgBIABgBIAAgBIABgBIgBACIAAgBIABAAIACgCAraIqIgBABIgBAAIABAAIgBABIABAAIAFgCIABgBIAAgBIAAABIABAAIABgBIgBAAIgBABIAAAAIgBABIgCABIABgBIACgBArcIrIgBABIAAAAIABAAIAAgBIAAABIgBAAIgBAAIABAAArbItIAAAAIAAAAIAAgBArbItIgCAAArbItIgBAAIAAAAIACAAIAAAAIAAgBIgBABIABgBIAAAAIABAAIAAAAIgBAAIAAAAIgBAAIABAAIABAAIgBAAIABAAArcIsIACgCIgBAAIgBACIgCAAAreItIABAAIABAAIgBABIABgBArdItIAAAAIgBAAArbIqIABgBIgFADgALgH9I27AyIAAgBIABgBIABAAIgCABIFsgWArcIvIgBABIACgBAraItIgBABIgCABIABAAArfItIgBABIACgBAreItIAAACIABgCArgIuIACgBAqMH2IguAhIgKAGIACAAIgFADIAEgCIAJgGIgIAFIAIgGArHIgIgDACIABAAIgCABIgDACIACgBIgDACIgCABIADgCIgCABIgBABIgCAAIACgBIgBABIACgCIADgCIAAAAIABgBIgBABIgEADArHIgIgDABIgCABIABAAIAEgDIgEACIgBABIgBAAIgHAEIgEACIgBABIAJgEIABgBIABgBIAAAAIACgBAm9FLIkMDVIgCABIAEgDIgCACIgDABIgBABIgCACIgKAFArOIjIADgBIABgBIAGgEIgDACIADgCIgDABIAIgFIgFAEIAKgGIACgBIENiyArNIjIADgBIgBABIgDACIAAAAIgBABIFBiLAJOg6I0aJeIAIgFIgFADIAGgEIAJgFIAWgNIBVgyArXInIgBABIACgCIACgCIAIgIIgHAHIgDADIgCABIACgBArQIlIAAAAIACgCArTIoIAAgBArUIpIABgBIABAAIAAgBIADgBIgCABIgBAAIABAAIgEADIVSnvArTIoIABAAIAAgBgArRInIgBAAIABAAgArZIsIgBAAIAEgCIAAgBArZIsIABgBIACgBIABgBArUIoIgBAAIgBABArbIrIACgCIAAAAAraIqIAAgBIAAAAIAAABIABgBIgBABIAAAAIgCABArYIoIgCABIABAAgArWIlIgEAEIAAAAArYIsIABgBIgBAAIgBABIgBAAArYIsIgBAAIAAAAIAAAAIABAAArZIsIABAAIAAAAIABAAIAAgBIgBABArYIsIABAAIgBAAIgBAAIAAAAArYIrIAAAAIgBABgArZIsIABgBArYIsIgBABIFlg1AraItIAAAAIgBABArXIsIAAgBIABAAIABgBIgBABIgBAAIAAgBIAEgCIgDADIgBAAIABAAIFShxArXInIgDACArUIoIABgBIADgCArMIcIgKAJArQImIgBAAArUImIAIgFIRPuaArQImIADgDAmcF+IkICOIgWAMAqcIFIgeATAqcIFIgcARAq7ILIgRARID5jsAEMoCIvYQeArXIsIFdhUALUF8I2tCxADNovIunRY");
	this.shape_9.setTransform(222.5,91.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBi0IydLgIBNgsICXhXIPGpGACCpLIqFN6IKYtqAoDEvIjYEhIDnkWIK0tYAD2nqIrhMtIjrEJIgBABIAEgEIAHgHIARgRICsitIMttOAEsm0Is7M4ADkn9IrPNAAFnmDIw7POIgCABIERjoIM9rTAFDmmIsWL9IMmrqAG5kcIx4NbIAzgiICwh9IOkqnAHQjvIusKPAGYlDItVK1INjqgAIlhwIvBIVIPMn+AI/hEIz5KEIgKAGIEyiRIPcnhAJeAAIvsHCIP0mrAJ0AuI1FIgIAAAAIFLh7IQDmNAraJTIABgBIgBAAIgBABIABAAIgBAAIABAAIABAAIAAAAIABAAIAAgBIABAAIEEhHIR3lKAKlDcIx4EvAKMB4IwQFpIQWlRArYJSIABAAIAAAAIgBAAIgBABIAAAAIgBAAIABAAIAAAAIABAAIEJgwISSjkALAFZIyPDKAKxD0IwrELIQvjyArZJUIgBAAIgBABIACgBIFpgjIRGh0ALKFxIw+CtIRAiUALaHwIxJBPIRJg2ArbJVIgCAAIABAAIABAAIABgBIAAAAIgBABIAAAAIAAAAIFugDIROgVAHjjdIuOJoIObpTAm4GpIPLosABqpVItGSmIABgBIAAABIAAgBIAAAAIgBABIAAAAIAAAAIgDACIADgCIgBABIAAABIgBABIABgBIAAgBIAAAAIgBABIABAAArfJUIABAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAAAIABAAIAAAAAreJUIAAAAIAAAAIABAAIAAAAIABAAIAAAAIACAAIAAgBIAAAAIABAAIAAAAArbJRIgBABIgBAAIAAABIAAAAIABgBIAAAAIgBAAIABgBIABAAIAAAAIgBABArZJTIgBAAIgBAAIAAAAIAAAAIgCABIAAAAIAAgBIACgBIgBAAIgBACIAAAAIAAAAArdJUIgBAAIAAABIABgBIAAAAIAAAAIgBAAArOJKIACgCIABgBIACgBIACgBIADgCIAFgEIgIAGIgEACIAEgBIADgCIAKgHIgKAGIgDADIgEACIgDACIAAAAIgCABIgCACIgBABIAAAAIACgBIgBAAIgBABIgBAAIgBABIABAAIgBAAIACgBIgBABIgBABIgBAAIABAAIgBAAIgEACIgDABIAAABIABgCIAAAAIABAAIAAgBIAFgBIABgBArWJMIgEAEIAAAAIgBABIABgBIgCACIABAAIAAgBIgBABIAAAAIACgCIABgBIgBABIgBABArdJUIACAAIgBAAIABAAIABgBIAAAAIAAABIAAAAIABgBIAAAAIAAABArbJTIAAABIAAAAIgBAAIgBABIABgBArZJTIAAgBIABAAIAAAAIABgBIgBAAIgBABIgBABIgBAAIAAAAIgCABArbJTIAAABIAAgBArbJTIgCABArXJRIAAAAIgBAAIAAAAIgBABIgBABIAAAAIgBAAIAAAAAreJUIABAAIAAAAArbJSIAFgCIAAAAIABgBIgGACIAAAAIAAAAArbJRIAAABALgIjI27AyIgBAAIgBABIACgBArfJUIgBABIACgBArgJVIACgBArEJEIACgBIgFAEIAEgCIAJgGIAWgMIBVgzArQJLIADgBIAAAAIABgBIgBABIgEADIABgBIADgCIADgBIABgBIgCACIgDABIACAAIgDABIgCABIAAAAIgCABArTJOIADgCIgJAEIAKgGIACgBIABgBArJJGIgDACIgBABIgHADIgEADIgBABArRJNIgBABIgBABIABgBIAAAAIABgBIADgBIADgCIABgBIADgCIgDABIgCABIABgBIABAAIAGgEAJOgTI0aJeIAIgFIgFACAq6JAIgJAFIgGADArXJNIgBACIACgDIACgBIAIgIIgHAGIgDADIgCACIACgCIgCADIgBAAIAAABArQJMIAAgBArOJKIgBAAIgBACArOJMIgCAAIgBABArSJOIAAAAIADgCIgCACIgBAAIABAAIgEADIVSnwArXJRIABAAIADgCIABgBArUJPIgBAAArVJQIAAgBIAAABIgCABIAEgCIgBAAIgBABgAraJQIgBABIACgBIAAAAIgBAAIAAAAIAAAAIAAAAIAAAAArYJPIgCABIABgBgArZJPIABgBIgBABgAK/ElI2WEtIgBABIgBAAIFlg1ArZJSIAAAAIABgBgArXJSIgBABIgBAAArYJSIgBABArWJQIgCABIgBABAraJTIAAAAArYJSIAAAAAKdCoI10GqIAAAAIAAAAIFdhTArXJSIABgBIABAAIgBAAgArXJSIAAAAIABgBIFShwArYJRIACgBArXJNIgDADIOnxYArTJOIgBABIABgBArUJPIABAAIgBAAArMJCIgKAKArUJMIAIgEIRPubArOJMIAAgBIgBABIFBiKAraJQIgBAAArbJRIAHgDAq6I/IgIAEIAIgGIAuggAq6JAIAWgNAq6I9IACgBIENixAqcIsIgeATAqcIsIgcAQAq7IxIgRASID5jsALUGjI2tCxAEMnbIvYQdALSHXI2tB+IFsgWACsouIuHR+ArJJGIEMjUAmcGlIkICO");
	this.shape_10.setTransform(222.5,88.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBiSIydLgIBNgsICXhYIPGpGABEpVIsLSqIApg7IB3iqIKBu3AonFwIKRujAAYpvIo1OvIJKugACCopIqFN5IKYtpACsoMIt8RxIDckKIK0tXAD2nJIrhMuIjrEIIgBACIAEgEIAHgHIARgRICsitIMttOAEsmSIs7M4ADknbIrPNAAFnlhIw7PNIgCACIERjoIM9rTAFDmEIsWL8IMmrpAG5j6Ix4NbIAzgjICwh8IOkqnAHQjNIusKPAGYkhItVK1INjqgAIlhPIvBIWIPMn/AI/giIz5KEIgKAFIEyiQIPcniAJeAhIvsHCIP0mqAJ0BPI1FIgIAAAAIFLh7IQDmMArXJ0IAAAAIAAAAIgBAAIABAAIABgBIgBAAIgBABIAAAAIgBAAIABAAIAAAAIABAAIEEhHIR3lKAKlD+Ix4EvAKMCZIwQFpIQWlRArYJ0IAAAAIgBAAIAAAAIgBABIABAAIgBAAIABAAIAAAAIABAAIEJgwISSjlALAF6IyPDLAKxEWIwrELIQvjzArYJ1IgBAAIAAAAIFpgiIRGh0ALKGSIw+CuIRAiVALaISIxJBPIRJg2ALgJFI27AyIFugDIROgVAHji8IuOJoIObpSAm4HKIPLosArHJVIgHAKIgHAKIgDAFIgDAEIgBAAIAAABIgBABIAAAAIABAAIABgBIAAABIAAAAIAAgBIABgBIABgBIgBAAIAAABIAAgBIABgBIAAAAIADgEIABgCIAHgLICxkfArdJ0IAAAAIgBACIABgBIABgBIgBAAIAAAAIABgBIABAAIAAgBIAAAAIABAAIAAgBIAAAAIABAAIABgBIAAgBIgBABIABgBIACgDIAAAAIABgCIADgEIgDAEIgDAEAraJyIgBAAIgBACIAAAAIACgCIgCACIgBAAIAAAAIAAAAIgBACIgBAAIAAAAIABAAIgCAAIACAAIAAAAIgBAAIgBAAAreJ2IAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIABAAIAAAAIAAAAIABgBIAAAAIABAAIAAAAIAAAAIAAAAIABAAIgCACIFsgWAm9GUIkMDUIgCABIAEgCIgCABIgDACIgBAAIgHAEIgEADIgBAAIAJgEIgDACIABAAIACgCIADgBIAAAAIABgBIgBABIgEADIABgBIgBABIgCABIAAAAIgBAAIgBABIgBAAIgEACIAAAAIgBABIgBABIAAAAIAAAAIAAAAIAAAAIABAAIgBAAIAAAAArbJ0IAAAAIgBABAreJ2IABAAIAAAAIAAgBIABAAIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIABgBIgBABIAAAAIAAAAIAAAAIABgBIAAABIABgBIAAAAIABAAArbJ0IAAAAIAAAAIAAgBIAAAAIAAAAArcJ0IABAAIgBAAIAAAAArcJyIgDACIADgBIAAAAIABgBIADgDIAAgBArbJyIAAABIAAgBIADgDIACgDArdJ2IAAgBIAAAAIACgBIgBABIgBAAIAAAAArbJ0IAAgBIAAABArbJzIAAAAIABAAIAAAAIAAAAIgBAAIAAAAIABAAIgBAAArcJ1IAAAAIAAABIAAAAIAAAAIAAAAIgBABIACAAIgBAAIgBABIACgBIgBAAArcJ0IABAAArdJ1IABgBArbJ1IAAAAIgBAAIAAABIAAgBIgBABIAAgBArcJ1IABAAArbJ1IAAAAIgBABIABgBIAAAAIABAAArcJ2IgBAAIAAABIABAAALSH5I2tB+IAAAAIABgCIgCABIAAAAIAAAAIgBAAArcJ2IAAAAArcJ1IAAAAAreJ2IABAAIAAAAArcJ0IAAAAArbJzIgBABArdJ0IgBABIABgBArbJ3IAAAAIABgCIABAAIAAAAIFlg1AreJ2IAAABIABgBAqMI+IguAhIgKAHIACgBIgFADIAEgCIAJgGIgIAFIAIgGArKJqIgDACIgDACIACgBIADgCIABgBIABAAIgCABIgDACIAAAAIgDACIgBABIAAAAIgBAAIgEADIAAAAIgBAAIgBABIgBAAIABAAIAAAAIgBAAIAAAAArKJqIADgCIgDACIgCABIABgBIAEgCIgEABIgBABIgBAAArOJtIACgBIgDACIgCABIAAAAIgBABIgBAAIgBABIABgBIgDADIABAAIVSnwArMJqIgCABIADgBIABAAIAGgEIgDACIADgDIgDACIAIgGIgFAEIAKgGIACgBIENiyAJOAMI0aJgIAIgFIgFADIAGgEIAJgEIAWgNIBVgzArWJsIABgCIAFgFIAMgSIgOATIALgRArQJtIAAAAIACgBIgBAAgArZJxIgBABIAAAAIABgBIAAAAIABgBIAAABIAAgBIACgCIACgCIAIgHIgHAGIgDADIgCACIABgBIgBAAIABAAIACgDIOixSArYJvIADgDIAFgHArRJvIgCABArRJvIgBAAIgBABArSJwIAAAAIADgCIgCABIgBABIABgBIgEAEIgBAAIgBABIAAAAArWJxIAAABIABgBIAAAAIABAAIABgBIABAAArbJ1IABgBIABAAIABgBIACgBIABgBIAAAAIgBABIgCABIABAAIACgCIABAAArUJwIgBABIACgBIgBABIgBAAIAAAAIgBAAAraJzIAFgCIABgBIgGADIABgBIAAAAIgBAAIAAABIAAAAArYJvIgBABIgBABArZJxIABAAIgBAAgArZJyIAAgBIAAABIAAgBIAKgFIACgCAraJyIAAAAIAAABIABgBArZJxIgBABArZJxIAAAAArWJtIgBACIgCABIAAABArYJvIgCACArYJxIgBAAAK/FHI2WEtIgBABArXJ0IgBAAIgBABIAAAAIAAgBAraJ1IAAAAIAAAAArYJzIAAAAIgBABgArZJ0IABgBArbJzIABAAIAAAAArbJ3IABgCIAAAAArXJ0IABgBIFShxArXJ0IAAAAIFdhTAraJ0IAEgCIgEABIgBACgArTJvIgBABArUJwIABgBArMJkIgKAJArUJuIAIgEIRPubArOJrIAAABArYJwIACgCIgCADArOJtIgBABIFBiLArbJ1IABAAIgBAAAraJyIgBAAArVJpIgHAJAmcHHIkICOIgWALAqcJOIgeASAqcJOIgcAQAq7JTIgRASID5jtArEJTIAmg5AEMm6IvYQeArEJTIDBkDAKdDKI10GqALUHFI2tCwAAAp3IrVTg");
	this.shape_11.setTransform(222.5,84.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBh0IydLgIBNgrICXhYIPGpGArcKSIAAgBIgDACIADgBIAAgBIABAAIABgCIAAABIAAAAIAAgBIADgFICuk0IITvEAhbqQInfPeIH0vSABEo3IsLSrIApg7IB3irIKBu2AonGOIKRujAAYpQIo1OvIJKuhACCoLIqFN6IKYtpACsnuIt8RyIDckKIK0tXAEMmbIvYQeIARgRICsiuIMttNAEsl0Is7M4ADkm8IrPNAILhsuAFnlCIw7PNIgCACIERjpIM9rSAFDlmIsWL9IMmrpAG5jbIx4NbIAzgjICwh9IOkqmAHQivIusKPAGYkCItVK0INjqgAIlgwIvBIVIPMn+AI/gEIz5KEIgKAGIEyiQIPcnkAJeBAIvsHCIP0mrAJ0BuI1FIgIAAAAIFLh7IQDmNAraKTIAAABIgBAAIAAAAIAAgBIABAAIABAAIgBAAIABAAIAAAAIABAAIAAAAIABgBIEEhGIR3lKAKlEcIx4EwAKMC4IwQFpIQWlRArZKTIgBABIABAAIAAgBIABAAIEJgvISSjlALAGZIyPDLAKxE0IwrELIQvjyAraKUIAAAAIAAAAIAAAAIABAAIAAAAIAAAAIFpgjIRGh0ALKGxIw+CuIRAiVALaIwIxJBPIRJg2ALgJkI27AyIFugEIROgUAHjidIuOJoIObpTAm4HpIPLosArHJ0IgHAKIgHAJIgDAFIgCADIAAAAIABgCIKs0IAraKRIAAAAIAAAAIAAAAIAAAAIABgBIgBAAIAAABIAAgBIAAAAIgBABIAAAAIAAAAIABgBIgBABIABgDIAAABIgBACIAAAAIAAAAIAAAAIAAAAIAAAAIgBABIAAAAIAAAAIAAABIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAAAIgBAAIgBACIABgBIAAAAIAAAAIABgBIAAAAIgBAAArdKUIAAAAIABAAIAAAAIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIABgBIAAAAIAAAAIgBAAIgBABIgBAAIABAAIgCABIACgBIAAAAIABAAIABgBIAAAAIAAAAIAAAAIAAABIAAgBIAAAAIAAAAAreKUIAAAAIAAAAIABAAAreKUIAAAAIAAAAIAAAAIABAAIAAAAAreKUIAAAAIgBAAIAAAAIgBABArdKUIAAAAIgBADIABgDgArcKTIgBABIAAAAIABAAArdKTIAAAAIAAAAIAAAAIABgBIAAAAArcKSIAAAAArbKRIAAAAIABAAIgCABIABAAArdKUIABAAIAAAAIAAAAIAAgBIAAABIgBAAArcKUIAAAAIAAAAIAAAAIABAAIAAgBIgBABIABgBIgBAAIAAABIAAAAgArbKTIABgBIAAAAIgBAAIAAAAIgBABIABgBIABAAIAEgBIAAgBIABgBIABAAIABgBIgBABIgBAAIABAAIABAAArcKUIAAAAIAAAAIAAAAIAAABIgBAAIAAABIABgBIAAgBIABAAIAAAAArbKSIAAAAIgBABIAAAAArbKSIAAAAArbKSIAAAAIABAAIAAAAIABgCIAAAAIAAgBIABAAIgBABIAJgEIABgBIgKAFIAAAAIgBABIAAABIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAABArbKSIAAAAArbKSIAAAAArcKSIgBABIAAAAIgBABArdKTIAAAAIgBAAIABAAArbKUIgBAAIAAAAIAAAAIAAAAIACAAIAAAAArbKUIAAAAIAAAAArcKUIABAAAraKTIgBABIAAAAArcKUIABAAArdKUIABAAIAAAAIAAAAIAAAAArcKVIAAgBIAAAAIgBABArbKTIAAAAIABAAIAEgCIABgBIAAgBIACAAIAAgBIACgBIABAAIADgDIADgBIABgBIgCACIgDACIACgBIgDACIgCABIADgCIADgCIABgBIADgCIgDABIgCABIABAAIAEgDIgEACIgBAAIgBABIABgBIgIAFIAHgEIgCACIABgBIAAAAIACgCArcKTIAAgBIABAAgArcKTIAAAAIABgBgAreKUIABAAIAAAAALSIXI2tB+IAAAAIgBABIgBABIACgBIgBAAAraKUIgBABIgCABIABAAArbKWIAAgBIABgBIABAAIgCABIFsgWAreKUIAAACIABgCAqMJdIguAhIgKAGIACgBIgFAEIAEgCIAJgGIAWgMIBVgyArUKPIgBAAIAAABIAAAAIgBABIABgBIABAAIABgBIgBAAIABAAIABgCIABAAIAEgDIAAAAIABgBIgBABIgDACIACgCAm9GyIkMDVIgCABIAEgDIgCACIgDABArOKKIADgBIABgBIAGgEIgDACIADgDIgDACIAIgFIgFADIAKgFIACgBIENiyAJOArI0aJgIAIgFIgFACAq6KAIgJAFIgGADArWKKIABgBIADgEIgDADIgBADIAAgBIgCAEIADgDIAFgHIgFAFIgBACIgCACIgCADIgBABIABgBArZKNIACgDArVKHIgCADArYKOIgBAAIAAABIgBABIACgDIAAgBIADgEIAHgKICxkfArQKMIAAAAIgCABIgBABgArOKMIgCABIgBABIgBAAIABAAIAAAAIgCAAArUKLIAIgIIgHAHIgDADgArTKPIABgBIAAABIAAgBIADgBIgCABIgBAAIABAAIgEADIVSnvArUKQIABgBIABAAIgBAAArWKRIgCABIgBAAIABAAIABAAIAAgBIACgBIABgBArWKQIABgBIgFADgArZKQIgBABIABgBIABgBIAAAAIAAgBIACgBIgCACIABgCIgBABIgBABIAAAAIAAABIAAAAIAAgBIABAAIgBABAraKRIABgBIgBABArZKPIAAABAraKQIAAAAArZKPIgBABArZKPIABAAIAAgBIABgBIABgBIDrkIArYKOIgBABIACgCIACgCIOixTArZKOIgBACArbKTIABAAIAAAAIABAAIABAAIgBAAIABAAIAAAAIAAAAAK/FmI2WEtIgBAAIgBABIFlg1ArZKTIAAAAIAAAAIABgBIAAAAArXKTIgBAAIgBAAIAAAAArWKRIgCABIgBAAIgBABIAAAAIgBABArYKTIABgBArXKSIAAAAIAAAAIgBABIABgBIABAAIgBAAIV0mqArbKTIABAAIABgBIAAAAArUKPIgGADIAAAAAraKRIgBABIABAAIAAgBArYKSIgBAAIgBABIgBAAAraKUIAAAAIgBABArVKRIgBABIgBAAArVKRIgBABIFShxArXKRIgBABArXKSIAAABIFdhUArWKSIgBAAArXKSIAAAAArXKRIAEgCIgDADArWKLIgDADArZKNIgBABICglAArXKNIABgBIAKgJIgHAHgArWKNIgCABArYKPIACgCArUKNIgEACArOKMIAAAAIgBABIFBiLAraKTIgBAAArQKEIAMgSIgOATIALgRArbKSIABAAArbKRIABAAAraKPIgCACAq6KAIAWgNAqcJsIgeATIgIAEIAIgFAqcJsIgcARAq7JyIgRARID5jsArEJyIAmg5AAApYIrVTfArEJyIDBkDAGDkSIxPOaALUHjI2tCxAh1qWIplUlAmcHlIkICO");
	this.shape_12.setTransform(222.5,81.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBhbIydLgIBNgsICXhYIPGpGAjRqrImGQFIGdv6AgtpjIqsUIIgBADIAAAAIAAAAIAAgBIABgCIACgCICuk1IITvEAhbp4InfPfIH0vSABEoeIsLSqIApg7IB3iqIKBu3AonGnIKRujAAYo4Io1OvIJKugACCnyIqFN5IKYtpACsnVIt8RxIDckKIK0tXAEMmDIvYQeIARgRICsitIMttOAEslbIs7M4ADkmkIrPNAILhsuAFnkqIw7PNIgCACIERjoIM9rTAFDlNIsWL8IMmrpAG5jDIx4NbIAzgjICwh8IOkqnAHQiWIusKPAGYjqItVK1INjqgAIlgYIvBIWIPMn/AI/ATIz5KGIgKAFIEyiQIPcnkAJeBYIvsHCIP0mqAJ0CGI1FIgIAAAAIFLh7IQDmMAKdEBI10GqIAAAAIEEhHIR3lKAKlE1Ix4EvAKMDQIwQFpIQWlRAK/F+I2WEtIAAAAIgBAAIgBAAIAAABIgBAAIABAAIAAAAIABAAIEJgwISSjlALAGxIyPDLAKxFNIwrELIQvjzArYKsIgBAAIAAAAIFpgiIRGh0ALKHJIw+CuIRAiVALaJJIxJBPIRJg2ALSIwI2tB+IAAAAIgBAAIABAAIFugDIROgVAHjiFIuOJoIObpSAm4IBIPLosArHKMIgHAKIgHAKIgDAFIgCACIAAABIABgCIABgCIADgIIgFAKIAAABIAAAAIAAgBICDlMAraKnIgBABIAAABIAAAAIAAgBIABAAAraKoIgBABIAAAAIgBAAIgDACIADgBIAAAAIABAAIAAgBIgBABIgBABIABAAIAAAAIAAgBIAAABArZKlIAAABIgBABIAAABIgBAAIAAABIAAAAIAAABIAAAAIAAgBIAAAAIABAAIgBABIAAgBIAAABArbKpIAAAAIABgBIgBABIABgBIACgCIAAgBIADgEIAHgLICxkfArbKqIAAgBIAAAAIAAAAIABAAIAAgBArfKtIABAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAAAIABAAIAAAAAreKtIAAAAIAAAAIABAAIAAAAIAAAAIAAgBIAAAAIABAAIgBAAIAAAAIAAAAIAAAAIABAAIgBAAArcKsIAAgBIAAAAIAAABIAAgBIAAAAIAAAAIAAAAIAAAAIAAABIAAAAIAAAAIAAAAIAAAAIAAABIAAAAIAAgBIgBABIAAgBIABAAIgBABIABAAIAAAAIAAAAIAAAAIAAAAIgBAAIABAAArdKuIABgBIgBABIAAAAIACAAIABgCIAAAAIgBAAIAAAAIABAAIgBAAIAAAAIABgBIABAAIgBAAIAEgCIgEABIgBABIgBABIAAAAIAAAAIAAAAIAAgBIAAAAIAAAAIABAAIAAAAIAAgBIAAABIAAAAIAAgBIAAAAIABAAIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIABAAIAAAAArcKrIAAAAIABAAIgBAAIAAAAIAAAAgArcKrIABAAIAAAAIAAgBIAAAAIABAAIAAAAIAAAAIAAAAIAAAAArbKrIAAAAIAAAAIgBAAIAAABIAAgBIAAAAArbKqIAAAAAraKqIgBACIABgBIgBABIgBAAIABAAIgBAAIABgBIAAAAIAAAAIAAAAArbKsIAAAAIgBAAIAAABIABgBIgBABIABgBIAAAAIgBAAIAAAAIAAABIAAAAIAAAAIgBABIABAAIgBABIACgBArdKrIABAAIAAAAIAAAAIABgBArcKqIAAAAArcKrIAAgBArcKrIAAAAArcKrIAAAAIgBAAIAAAAIAAAAIAAAAIgBABIABgBArcKrIAAAAIAAAAArdKtIAAAAArdKsIAAABIAAAAIgBACIABgCArcKsIAAAAIAAAAgArbKrIAAAAIAAgBgArcKrIABAAAraKqIgBAAIAAAAgArdKrIAAAAIgBACIABgBIABgBArbKoIgBABIAAABIgBABIAAAAIgBACArdKtIAAgBIAAABArdKtIgBAAIAAABIABgBIAAAAIAAAAIgBAAArcKsIAAAAArcKsIAAAAArcKsIAAAAIAAAAArcKsIAAAAIAAAAIAAAAArbKsIAAAAArbKsIAAAAArEKeIgIAFIgCABIAAAAIgDACIAAAAIgBABIAAAAIgBAAIgEADIAAAAIABAAIADgDIgBABIgBAAIgCACIgBAAIAAAAIgBABIgBAAIAAAAIgBABIAAAAIAAAAArbKuIABgCIAAAAIgCABIAAAAIAAAAArcKtIAAAAArbKpIAAAAIAAAAIAAAAArbKqIAAAAArcKrIABgBIAAABAraKqIABgBIAAgBIABAAIgBAAIABAAIgBAAIABgBIAAABIAAgBIACgCIgCACIABgBIgBAAIgBABIAAAAIgBABIAAAAIABAAIAAgBIABgBIACgDIAAAAIgCADIgCACIAAABIgBAAIAAAAIABAAIABgBIgBAAIAAABIAAgBIABgBIACgBIACgDIOixSALgJ8I27AyIAAAAIABgCIABAAIgCACIFsgWAreKtIgCAAIACAAArdKtIAAABArfKtIgBAAAqMJ1IguAhIgKAHIACgBIgFADIAEgCIAJgGIgIAFIAIgGArHKfIgDACIABAAIgCABIgDACIgBABIFBiLArHKfIgDACIgCABIABgBIAEgCIgEABIgBABIgBAAIABAAIgIAEIAHgEIgCACIABAAIgCABIgCACIgBABIAAAAIACgBIgBAAIgBAAIgBABIABAAIgCABIABAAIgBAAIAAAAIAAAAIAAAAIgBABIgCABArTKnIACgBIABgBIgBABIAEgDIAAAAIABgBIgBABIgDABIAAAAIgJAEIAKgFAm9HLIkMDUIgCABIAEgCIgCABIgDACIRPubArMKhIgCABIADgBIABAAIAGgEIgDACIADgDIgDACIAIgGIgFAEIAKgGIACgBIENiyArNKjIADgCIgBABIgDACIgCABgArEKeIgFADIAGgEIAJgEIAWgNIBVgzAraKnIAAAAIACgDIABgCIgCADArWKjIABgCIADgEIgDAEIgBACIgDAEIABgBIADgDIAFgHIgFAFIgBACArVKgIgCADIgDAEAraKqIAGgDIABgBIADgCIABgBArWKlIACgCIAIgHIgHAGgArSKnIAAAAIADgCIgCABIgBABIABgBIgEAEIVSnwArUKoIABgBIABAAArRKmIgBABIgBAAIgBABArVKoIgBABIgCABAraKqIAEgCIAAABIABgBArVKoIgBAAIABAAIABgBAraKqIAAAAIAFgCIABgBIgBABArbKpIABgBIAAgBArYKnIAAgBIABAAIABgCIDrkIArZKoIABgBArZKoIAAAAIgBABIAAAAIABAAIAAgBArZKoIAAAAArZKoIgBABIABgBgAraKpIAAAAIAAABIAAgBArZKpIAAAAIgBABArZKpIAAgBArbKsIABAAIABAAArbKsIABgBIAAABIABgBIgBABIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIFlg1ArZKrIAAAAIAAAAIABgBIABAAIgBABArYKrIAAAAIAAAAIgBAAIgBAAArZKrIABAAIAAAAIABAAIAAAAIgBAAArYKsIABgBIgBAAIgBABIAAAAArZKrIABgBIgBABIAAAAIABgBArYKrIgBAAArXKrIAAAAIABgBIABAAIgBAAIgBABIABgBIFShxArTKnIgBABArYKnIACgCIgCADIAEgDArMKjIgDACIgCABArOKiIAAABArXKmIABgCIAKgJIgHAHgArQKcIAMgSIgOATIALgRAh1p9InxQmIhpDmIgIATICdk7AigqaIo1U2IAGgNAmcH+IkICOIgWALAqcKFIgeASAqcKFIgcAQAq7KKIgRASID5jtArEKKIAmg5ApmGpIHdw4AAApAIrVTgArEKKIDBkDAJOBDI0aJgArXKrIFdhTALUH8I2tCwAjrquInwVW");
	this.shape_13.setTransform(222.5,79.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBhJIydLgIBNgsICXhXIPGpGAjRqYImGQEIGdv6AgtpQIqsUHIgBADIADgFICuk0IITvEAhbplInfPeIH0vSABEoMIsLSrIApg7IB3irIKBu2AonG5IKRujAAYolIo1OvIJKuhACCngIqFN6IKYtpACsnDIt8RyIDckKIK0tXAEMlwIvYQeIARgSICsitIMttNAEslJIs7M4ADkmRIrPM/ILhstAFnkXIw7PNIgCACIERjpIM9rSAFDk7IsWL9IMmrpAG5iwIx4NbIAzgjICwh9IOkqmAHQiEIusKPAGYjXItVK0INjqgAIlgFIvBIVIPMoAAI/AlIz5KGIgKAGIEyiRIPcnjAJeBrIvsHCIP0mrAJ0CZI1FIgIAAAAIFLh7IQDmNALaJ0IxJA2IlsAWIAAAAIgBAAIABAAIAAAAIABgBIAAAAIgBABIgCAAIABgBIgBABIAAAAIABgBIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIAAgBIABAAIABAAIAAAAIABAAIAAAAIABgBIEEhHIR3lKAKlFHIx4EvAKMDjIwQFpIQWlRArYK+IABgBIAAAAIgBABIgBAAIAAAAIgBABIABAAIAAgBIABAAIEJgwISSjkALAHEIyPDKAKxFfIwrELIQvjyArbLAIACgBIFpgjIRGh0ALKHcIw+CtIRAiUALaJbIxJBPArbLAIFugDIROgVAHjhyIuOJoIObpTAm4IUIPLosArHKfIgHAJIgHAKIgDAFIgCADIAAAAIgBABIAAABIAAAAIAAgBIAAABIAAAAIAAAAIAAgBIAAAAIAAAAIAAAAIAAAAIABgBIAAAAIAAgCIAAACIAAAAIAAgBIACgDIgBADIAAgCIACgCIgBABIADgHIgFAJICDlMAraK6IgBAAIAAABIgBABIAAAAIAAAAIAAAAIAAABIgBAAIABAAIAAAAArVK6IgFADIAEgCIAAAAIABAAIAAgBIgBABIABgBIABAAIgGACIABgBIAAAAIgBAAIABgBIAAABIgBAAIgBAAIABAAIgBAAIABAAIgBAAIAAAAIABAAIAAgBIAAAAAraK7IAAAAIAAAAIAAAAIAAAAIAAAAIgBABIAAAAIAAAAIAAAAIAAgBIAAABIAAgBIAAAAAreK/IgBAAIAAAAIABAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAAreK/IgCABIACgBIAAAAIgBAAIgBABArbK8IAAAAIAAAAIAAAAIgBABIAAAAIAAABIAAAAIAAAAIgBABIAAAAIAAgBIAAAAIABgBIAAgBIAAABIgBABIAAAAIgBABIABAAIAAgBIAAAAIABAAIAAgBIAAAAIAAABArcK9IAAAAIAAAAIAAgBIAAAAIAAABArdK/IAAAAIAAAAArdK/IAAAAIAAAAIAAAAIABAAIAAAAIAAAAIAAgBIAAABIgBAAIAAAAIABgBIgBABIABgBIgBAAIAAAAIgBAAIABAAIAAAAIAAAAIAAAAIgBABArdK/IAAAAIABAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAArUK6IABgBIADgCIgJAEIAAAAIgBABIAAABIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAABIAAAAIABAAIAAgBIgBABIABgBIgBAAIABAAIAAgBIAAAAIAAAAIgBABIAAAAIAAAAArbK8IAAAAIAAABIAAgBIAAABIAAAAIAAAAIAAABIAAAAIgBAAIABAAArcK/IAAAAIgBAAIABAAIAAAAArbK9IAAAAIgBAAIAAAAIAAABIAAAAIAAgBIAAAAArbK9IAAABArcK+IABgBIAAAAIAAAAIAAAAIABgBIgBABIAAAAIAAgBIABgBArcK+IAAAAIAAAAIAAABIAAgBArcK9IAAAAArcK+IAAAAIAAAAgArcK9IAAABArbK8IgBABIABAAIAAgBArdK/IAAAAIAAAAArcK/IAAAAIAAAAIAAAAArbK9IAAAAIAAAAgArbK+IAAAAIABAAIAEgDIgEACIgBAAIgBABIAAABArcK/IAAAAIAAAAArdK/IABAAIgBAAIABAAIAAAAArcK9IAAAAArbK8IgBABArbK7IgBABIABAAAj8qpIlmQQIh6FVIAAAAIABgCIHw1VArdK/IAAAAArdK/IAAAAIAAAAgArcK/IABAAIAAAAIgBAAIACAAIAAAAIgBAAIAAAAIAAAAIAAAAIgBAAArcK/IAAAAArbK9IAAAAArdK9IAAABArdK/IgBAAIAAABIABgBIgBACIABgCAkuq3IlHQZIhnFaIgDACIADgBArcLAIgBABIACgBIW7gyArdLAIABAAAreLBIABgCArdK/IAAABAreLBIABgCAqMKIIguAhIgKAGIACgBIgFAEIAEgCIAJgGIAWgMIBVgzArVK6IABAAIgBAAIACAAIAAgBIACgBIABAAIADgDIADgBIABgBIgCACIgDABIACAAIgDACIgCABIADgCIADgCIABgBIADgCIgDABIgCABIABAAIAEgDIgEACIgBAAIgBABIgHAEIgEACIgBABIAKgGIACgBIABgBIgIAFArRK4IAEgDIAAAAIABgBIgBABIgDABIAAABAm9HdIkMDUIgCACIAEgDIgCABIgDACArMKzIgCACIADgBIABgBIAGgEIgDACIADgDIgDACIAIgFIgFADIAKgFIACgCIENixAJOBWI0aJgIAIgFIgFACAq6KrIgJAFIgGADArVK0IADgEIgDADIgBADIAAgBIABgBIgBACIgDADIABAAIgBABIACgCIACgDIOixSArZK3IACgCArVKyIgCADAraK6IACgCIAAgBIADgEIAHgLICxkeArQK2IACgBIgBAAIgBACArOK3IgCABIgBABIAAAAIgBAAIgBABIgBAAIABAAIABgCIgBABIgBABIABAAArUK2IAIgIIgHAHIgDACgArWK1IgCAEIADgEIAFgGIgFAFArTK6IgEACIAAABIABgBIADgCIABAAIAAgBIABAAIgCAAArTK6IABAAIAAgBIADgBIgCABIgBAAIABAAIgEADIVSnvArRK4IgBAAIACgCArUK6IgBAAIAAABIgBAAIgCACIgBAAIAAAAIgBABIgBAAAraK9IgBABIABAAIABgBIABAAIACgCIABAAIAAAAIABgBArVK7IABgBIABAAAraK6IgBABIABgBIABgBIgBAAgAraK7IABgBIAAgBgArZK6IABAAIAAAAIAAgBIACgCIgCADIABgCIgBABIgBABIAAAAIABAAIAAgBIABgBIABgBIDrkJArZK6IAAABArYK6IgBAAIAAAAgAraK7IABAAIgBAAIAAABIAAgBIABAAArWK2IgCACIgCADIAAAAIAAgBIAAABArZK6IgBABArZK6IAAABArZK7IAAgBIABAAIACgCIgCABAK/GQI2WEuIgBAAIgBABIFlg2ArZK+IABAAIAAAAIABgBIgBAAIgBAAIgBABIABAAIABgBIAAAAAraK+IAAAAIgBAAIABAAIAAAAIgBABIABgBIABAAIAAAAArZK+IgBAAIAAABIAAAAIAAAAIAAAAIgBABAraK/IABAAIAAAAIAAAAArZK+IABAAArZK+IAAAAArXK+IgBAAIgBAAArZK9IABAAAraK9IAAAAIgBAAIABAAIAAgBIAAABAraK8IAAAAArYK+IAAAAAraK/IABAAIWtixAKdETI10GqIAAAAIAAABIFdhUArXK9IABAAIABgBIgBAAgArXK9IAAAAIABAAIFShxArXK8IgBABArVK7IgCABArTK6IgBAAArOK1IAAAAAraK6IABgDArXK4IABgBIAKgJIgHAHgArOK3IAAgBIgBACIFBiLArQKvIAMgTIgOAUIALgRAh1prInxQmIhpDmIgIAUICdk8AigqHIo1U2IAGgOAq6KrIAWgNAqcKXIgeATIgIAEIAIgFAqcKXIgcAQAq7KcIgRASID5jsArEKcIAmg4ApmG7IHdw3AkUqyInIVuALSJCI2tB+AlFq/IkwQhAAAotIrVTfArEKcIDBkCAGDjnIxPOaAlfrAIl9V8AmcIQIkICO");
	this.shape_14.setTransform(222.5,77.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBg5IydLfIBNgrICXhYIPGpGAjRqJImGQFIGdv7AgtpBIqsUIIgBACIAAAAIABgCIACgDICuk0IITvEAhbpWInfPfIH0vTABEn9IsLSrIApg7IB3iqIKBu3AonHJIKRujAAYoWIo1OvIJKuhACCnQIqFN5IKYtpACsmzIt8RxIDckKIK0tXAEMlhIvYQeIARgRICsiuIMttNAEsk6Is7M4ADkmCIrPNAILhsuAFnkIIw7PNIgCACIERjoIM9rTAFDkrIsWL8IMmrpAG5ihIx4NbIAzgjICwh9IOkqmAHQh0IusKOAGYjIItVK1INjqgAIlAIIvBIXIPMoAAI/A0Iz5KGIgKAGIEyiQIPcnkAJeB6IvsHCIP0mqAJ0CoI1FIgIAAAAIFLh7IQDmNAraLOIAAAAIgBABIgCABIABAAIABgBIAAAAIABgBIABAAIAAAAIABAAIABgBIgBAAIgBABIAAAAIAAgBIABAAIAAAAIABAAIEEhHIR3lKAKlFXIx4EvAKMDyIwQFpIQWlRArYLNIAAAAIABgBIgBAAIgBABIABAAIgBAAIAAAAIgBABIABAAIgBAAIABAAIAAAAIABAAIEJgwISSjlALAHTIyPDLAKxFvIwrEKIQvjyArZLOIAAAAIFpgjIRGhzALKHrIw+CuIRAiVALaJqIxJBQIRJg3ALgKeI27AyIFugDIROgVAHjhjIuOJoIObpSAm4IjIPLosArHKuIgHAKIgHAKIADgDgArbLLIgBAAIAAABIAAAAIAAAAIABAAIgBAAIABgBIAAAAIAAAAIAAAAIAAgBIAAABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAABIAAgBIAAABArbLLIAAAAIAAAAIgBAAIABgDIgBACIABgBIABgDIgBACIABgEIABgEIgBAGIAAgEIgBAFIAAACIgBADIgDABIADgBIAAAAIAAgBIAAABIAAgBIAAAAIAAAAIAAAAIAAAAIAAABIAAABIAAgBIAAAAAraLJIAAABIgBABIAAAAIAAgBIABgBIABgBIABgCIADgIIgFAJIAAACIAAAAIAAgCICDlLArZLHIAAABIgBABIAAAAIgBABIAAAAIABAAIgBABIABgBIACgDIACgCIABgDIgDAEIADgFIgCADIgDAFIACgDIAAABIgCADIAAAAIABgBIAAAAIABgBIABgBIABgBIDrkIAraLJIgBAAIAAACIAAAAArcLLIABgBIAAABAj8qaIlmQQIh4FOIgBAGIAAgBIHw1VArdLNIABAAIgBAAIAAAAIAAAAIAAAAIAAAAIgBABIABgBIAAAAIAAAAIgBABIgBAAIAAAAIABAAIAAAAIAAAAIgBAAIgBABIACgBArdLOIgBADIABgDIAAAAIAAAAIAAAAIgBAAIAAAAIAAAAIAAAAIABAAAreLOIAAAAIAAAAArdLNIABgBIAAAAIAAAAIABgFIAAgBIgBAGIAAgBIAAgBIAAABIAAAAArcLMIgBAAIABAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAABIAAAAIAAgBIAAAAIAAAAAreLRIABgDIAAAAIAAAAIAAAAIABAAIAAAAIAAAAIAAAAIAAAAIABgBIAAAAIgBAAIAAAAIAAAAIABAAIAAAAIAAAAIAAgBIAAABIAAgBIAAAAIAAAAIAAAAIgBABIAAAAIAAAAIAAAAIAAAAIAAABIAAAAIgBAAIAAAAIAAAAIAAAAIABAAIAAAAIAAgBIAAABIAAgBArcLLIAAABArcLNIAAAAIAAAAIAAAAIAAAAIAAABIgBAAIABAAArcLNIAAgBIAAABIAAAAIAAgBIABAAIAAAAIgBAAIAAABIAAAAIAAAAIAAABIAAAAArcLMIAAABIAAgBIAAAAIAAABIAAAAArcLOIAAAAIAAAAIAAAAIAAAAgArdLOIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIAAACIABgCIgBADArbLNIAAAAIAAgBArbLMIAAAAIAAgBIAAAAIAAAAIABAAIAAAAIAAAAIAAABIgBAAIAAAAIAAAAIAAAAArbLOIAAAAIgBAAIAAAAIAAAAIAAABIAAgBIAAAAIABAAIgBAAIAAAAIABAAIgBAAIAAAAArcLOIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIABgBIgBABIABgCIAAAAIgBAAIAAAAIABAAIAEgBIgEACIABAAArdLNIAAAAIgBABIABAAIAAAAIAAAAIAAAAArcLNIAAABIgBAAgArdLNIABAAIAAAAIAAAAIAAAAArcLOIAAgBArcLNIgBABArbLLIAAAAIAAAAIABAAIgBAAArbLMIAAAAIAAAAIABgBIgBAAIAAABIAAAAIAAAAArcLOIABgCIAAAAIAAAAIABAAIAAAAIABgCIAAgBIABAAIAEgCIAIgFIRPuaArdLPIAAABIABgBgArdLOIABAAIAAAAIAAAAIAAAAIAAABArcLOIAAAAIgBABArcLOIAAAAArbLNIgBAAIABAAArcLMIAAAAIAAAAgArbLMIAAAAIAAAAIABAAIAAgBIAAAAIAAAAIABgBIgBABIAAgBIABAAIAAgBIABAAIgBABIAAgBIAAABIgBABArdLOIAAAAIAAAAIAAgBArcLOIAAAAArbLOIgBAAArbLOIABgBIAAAAIgBABgArRLIIgBABIAAAAIgBAAIABAAIABgBIAAAAIgBABIAAAAIgBAAIgEACIAAABIABAAIADgDIgBABIgBAAIgCABIgBABIAAAAIgBABIgBAAIABAAIAAAAIgBABIgBAAIAAAAIAAAAIAAAAIABAAArZLNIAAAAIgBAAIgBABIAAAAIAAAAIABAAIAAAAIAAAAIAAAAIAAAAIAAAAArbLPIABgBIgCAAIAAAAIgBACIAAABIABgBIABAAIAAgBIWth+ArbLOIgBAAArcLOIAAAAArdLNIAAABArdLMIAAABArcLLIABAAIAAAAIAAAAArdLRIACgBArdLQIAAAAIABgBArgLPIACgBAqMKXIguAhIgKAHIACgBIgFADIgDACIgBABIACgBIAFgDArKLDIABAAIAGgEIgEACIgDABIgCACIABgBIAEgDIgEACIgBABIgBAAIABgBArZLKIAAAAIgBABIABgBIABgBIAAAAIACgCIACgCIAIgIIgHAHIgDADIgCACIACgCIgCACIgBABIAJgEIAAAAIACgCIgBABIgBABIgDACIABAAIACgCIADgCIAAAAIABAAIgBAAIgEADIgCACIAAAAIgBAAIgBAAIgBABIgEACArLLEIgDACIACgBIgDACIgCABIADgCIAAAAIgBABIFBiLAm9HtIkMDUIgCABIAEgDIgCACIgDABArMLDIgCABIADgBIABgBIAGgDIgDABIADgCIgDABIAIgFIgFAEIAKgGIACgBIENiyArNLEIADgBAJOBlI0aJgIAIgFAraLJIAAAAIACgDIABgCIgCADArWLFIAAgBIgCAEIADgDIAFgHIgFAFIgBACIgDAEIABgBIgBABIACgCIACgCIOixTArWLEIABgBIADgEIAOgTIAmg5ArLLEIgDACIgCABIgBABIgCABAkuqoIlHQaIhiFGIgDAKIABgEIFF2GAlfqxIlISzIgrClIgFARIgCAIIHF1jArRLHIgBABIgBABIgCAAIAAABIABgBIgBAAIAAABIgBABIABgBIAAAAIgBABIAAgBIABgBIABAAIABgBIgBABIgBAAArRLIIgBABIADgCgArbLLIABgCIAAAAAraLKIAAAAIAAgBArYLJIAAgBAraLLIAAgBIABgBIAAAAIgBABIAAABIAAgBArYLJIAAAAArPLFIgKAFIAAAAIAAAAArZLJIABAAArZLNIABgBIACgBIgCABgAraLNIAAABIgBAAArYLMIgBABArZLNIABAAIAAAAArXLNIAAgBIAAABIgBAAIABgBIABAAIABgBIVSnvArULJIgGADIAAAAIAFgDAraLOIABAAIgCABIFsgVArRLIIgEADIgBABIgBAAIAAABArXLMIABAAIFShxArZLKIgBABArXLNIAAAAIFdhUArYLJIABgBIgBAAArTLJIgBABArULJIABAAArTLJIgBAAArQLHIgBAAArNLDIgHAEArPLFIACgCArOLEIAAAAArQLHIADgDArXLIIABgCIAKgJIgHAHgAmurJIjmQyIhHFdIACgIIAHgXAAAoeIrVTfIAHgJICxkfAraLMIgBAAAh1pcInxQnIhpDlIgIAUICdk7Aigp4Io1U2IAGgOArQK+IAMgSIDBkDAmcIfIkICOIgWAMIgJAGIAJgFIAWgNIBVgyAqcKmIgeATIgIAFIAIgGAqcKmIgcARAq7KsIgRARID5jsApmHLIHdw4AnGrQIjOQ5Al6rBIktTDAlFqwIkwQiAKdEjI10GpAK/GgI2WEtALUIeI2tCwArZLOIFlg1AngrOIj7WU");
	this.shape_15.setTransform(222.5,75.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBgxIydLgIBNgsICXhXIPGpGAjRqAImGQEIGdv6Agto4IqsUHIACgCICuk0IITvEAhbpNInfPeIH0vSABEn0IsLSqIApg6IB3irIKBu2AonHRIKRujAAYoNIo1OvIJKuhACCnIIqFN6IKYtpACsmrIt8RxIDckJIK0tXAEMlYIvYQdIARgRICsitIMttNAEskxIs7M4ADkl5IrPM/ILhstAFnj/Iw7PNIgCACIERjpIM9rSAFDkjIsWL9IMmrpAG5iYIx4NaIAzgiICwh9IOkqmAHQhsIusKPAGYi/ItVK0INjqgAIlARIvBIXIPMoAAI/A9Iz5KGIgKAGIEyiRIPcnjAJeCDIvsHCIP0mrAJ0CxI1FIgIAAAAIFLh7IQDmNAraLWIAAAAIgBABIAAgBIAAAAIABAAIABAAIgBAAIABAAIAAAAIABAAIAAgBIABAAIEEhHIR3lKAKlFfIx4EvAKMD7IwQFpIQWlRArZLWIgBAAIABAAIAAAAIABAAIEJgwISSjkALAHcIyPDKAKxF3IwrELIQvjyAraLWIAAAAIAAABIAAAAIABgBIAAAAIAAABIFpgjIRGh0ALKH0Iw+CtIRAiUALaJzIxJBPIRJg2ALgKmI27AyIFugDIROgVAHjhaIuOJoIObpTAm4IsIPLosArHK2IgHAKIgHAKIgDAFIAAABIACgCIgDADIABAAIgBABIACgCIACgDIOixSArbLUIAAAAIAAgBIAAAAIAAAAIAAABIAAgBIAAAAIAAABIAAAAIAAAAIAAAAIAAAAIAAAAIgBABIAAAAIAAAAIAAgBIAAAAIAAAAIAAAAIAAAAIAAAAIAAABIAAgBIgCABIAAABIABgBIAAAAIABgBIAAAAIAAAAIAAAAIAAABIAAAAIAAAAIAAgBIAAAAIABAAAraLRIAAAAIACgDIgBACIAAgBIACgDIgBACIADgHIgFAJIAAABIAAABIgBAAIAAABIAAAAIgBABIABgEIgBACIABgBIABgDIgBACIABgDIABgEIgBAFIAAgEIgBAGIAAABIgBADIAAAAIAAgCIAAACIAAAAIABgBIAAAAIAAABIAAgBIAAABIgBAAIAAAAIABAAIAAAAArYLPIgCACIAAABIAAABIgBAAIAAAAIAAAAIABgBIABgCIgBABIAAABIgBABIAAAAIABAAIgBAAIABgBIACgCIgCADIABgBIAAAAIAAABIAAgBIAAAAIABAAIgBAAAj8qRIlmQQIh4FOIgBAGIAAgBIHw1VArgLYIABgBIABAAIgCABIACgBIAAAAIABgBIgBAAIAAAAIAAAAIAAABIAAgBIAAgBICD2qAreLWIAAABIAAAAIABAAIAAAAIAAgBIAAAAIABgBIgBABIABAAIAAgBIgBAAIAAABIAAABAreLWIAAAAIAAAAAreLWIAAgBIAAAAAoorVIiLRCIgrFoIAAAAIDR2pAreLYIAAAAIAAAAIAAAAIAAAAIAAACIAAgCIAAgBIAAAAIABAAIgBACIABgCIAAAAIAAAAIgBAAIAAAAAreLXIAAAAIAAAAIAAAAAreLYIAAgBIAAAAIAAAAIAAAAIAAAAIAAAAArcLXIAAAAIABAAIgBAAIABgBIAAAAIgBAAIABAAIgBAAIABAAIAAgBIAAAAIAAAAIAAAAIAAABIgBAAIAAAAIAAAAIAAgBIAAAAIAAABIAAAAIAAgBIAAAAArcLVIAAAAIAAAAIAAAAIAAABIAAAAIAAgBIAAAAIAAAAIAAAAIAAAAAraLUIAFgCIABgBIgGADIAAAAIAAABIgBAAIgBABIAAAAIAAAAIAAABIAAAAIAAAAIAAAAIAAAAIAAgBIAAAAIAAAAIAAAAIgBABIAAgBIABAAIgBAAArcLWIAAgBIAAAAIAAAAIAAAAIAAAAIAAAAArcLUIAAABIAAAAIAAAAArbLUIgBAAIAAABAreLZIABgCIAAAAIAAAAIAAAAIAAAAIAAAAIgBABIAAgBIAAABArdLWIAAgBIAAAAIAAABIAAAAIgBABIABAAIAAgBIAAABIAAgBIABAAIAAAAIAAAAIAAAAIABgBIgBAAArdLXIAAAAIAAAAIAAAAIAAAAArbLVIAAAAIAAAAIAAAAIAAAAIAAAAIAAgBIABAAIgBAAIAAABIAAAAIAAgBIAAAAIABgBIgBABIAAAAIAAABArcLVIABAAIAAgBIAAAAArcLVIABAAIAAAAIAAgBIAAAAIAAgBIABAAIAAAAIABAAIgBAAIAAAAIAAAAIAAAAArcLXIAAAAIgBABIAAABIABgBIgBAAIABgBIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIABAAIgBABIAAAAArcLVIAAAAIAAAAArcLVIABAAArbLVIAAAAIAAAAIABgBArbLVIAAABArbLUIAAAAIAAABArbLVIAAAAIAAAAgArcLWIABgBArcLWIAAAAIAAAAgArcLXIAAgBIAAAAIAAAAAraLTIAAAAIABAAIAAgBIABAAIgBABIAJgEIABgCIgKAGIAAAAIgBABIAAAAIgBAAIAAABIABgBIAAAAIABgBIAAgBArcLVIgBAAIABAAIAAAAIAAAAIAAAAArdLVIAAABArdLXIABAAIAAgBIAAABIAAAAIAAAAIAAAAIAAAAIgBAAgAreLZIABgCIABAAIAAAAArdLXIAAAAArcLXIABAAIAAAAIgBAAIACAAIAAgBAraLWIgBAAIAAAAIAAABIAAgBArcLXIAAAAArcLXIAAgBIAAABgArbLWIAAAAIABgBIAEgCIgEACIgBABIABgBIABAAIABgBIACgBIABAAIAAgBIABAAIABAAIABgBIAAAAIADgBIgCABIgBAAIABAAIgEADIVSnvArdLXIAAAAArcLUIAAAAArcLUIAAAAIABgGID72UArcLVIgBAAAn0rQIitQ/Ig9FmIACgBIABgEIAAgCIBHlcIDOw5ArbLUIAAgBIABAAIgBAAALSJaI2tB+IAAAAIgBAAIABAAIAAAAIABgBIABAAIgCABIFsgWAraLXIgBABIgCAAArdLZIACgBArdLXIAAABAqMKgIguAhIgKAGIACgBIgFAEIAEgCIAJgGIAWgMIBVgzArQLPIAAgBIgCACIABAAIABgBIADgCIADgBIABgBIgCACIgDABIACAAIgDACIgCAAIADgBIgCAAIgBABIAAAAArOLPIADgCIABgBIADgCIgDABIgCABIABgBIAEgCIgEACIgBAAIgBABIABgBIgIAEIAHgDIgCABIABAAIAAAAIACgCArRLQIAEgDIAAAAIABgBIgBABIgDABIACgBAm9H1IkMDUIgCACIAEgDIgCABIgDACArOLNIADgCIABAAIAGgEIgDACIADgDIgDACIAIgGIgFAEIAKgFIACgCIENixAJOBuI0aJgIAIgFIgFACAq6LDIgJAFIgGADArVLMIADgFIgDAEIgBADIAAgBgArWLNIgCAEIADgEIAFgHIgFAGIgBACArYLPIADgEIAHgLICxkeArVLKIgCADIgDAEIAAABArULOIAIgIIgHAGIgDADgAkuqfIlHQZIhiFHIgDAJIABgEIFF2FAlfqoIlISyIgrCmIgFARIgCAIIHF1jArSLRIgBABIgBAAIABAAIABgBIAAAAIABgBArSLQIgBABIAAAAIACgBArRLQIgBABArTLRIACgBArWLTIAAAAIABgBIABAAIABgBIABgBArULSIABgBIgBABIgBAAIgBABIgEABArVLSIAAABIAAAAIABgBArULSIgBABIgCABIgBAAArWLTIABAAIgBAAIgCABIgBABIABAAIABgBIgBABIAAAAArbLTIABgBIAAgBAraLSIAAgCICDlMAraLUIAAAAIAAgBIABgBIABAAIAAAAIAAgBIACgCIgCADIABgCIgBABIgBABIAAgBIgBACIAAAAIAAgBArZLTIAAAAArZLTIgBAAArZLSIgBABIABAAArZLSIABAAIAAgBIABgBIABgBIDrkJAraLTIAAgBIABgDIgBACArbLWIABAAIAAAAIABgBIABAAIgBABIABgBAK/GoI2WEtIgBABIgBAAIFlg1ArZLWIAAAAIAAgBIABAAIAAgBArXLVIgBABIgBAAIAAAAArYLUIgBABIgBABIAAAAIgBAAArYLVIAAAAArXLVIAAAAIAAAAIgBAAIABAAIABAAIgBAAIV0mqArZLVIAAAAAraLXIAAAAIgBABArZLVIgBABIgBAAArVLUIgBAAIgBABArVLUIgBABIFShxAraLTIAAABArXLVIAAAAIFdhTArXLUIAAAAIAEgCIgDACgArXLVIAAAAArULRIABAAIADgCArVLSIACgBArOLPIAAgBIgBACIFBiLArXLQIABgBIAKgKIgHAHgArWLQIgCABArYLSIACgCArULPIgEADAraLWIgBAAArQLGIAMgSIgOATIALgRAh1pTInxQmIhpDmIgIATICdk7AigpvIo1U2IAGgOArbLOIACgIIAHgWAq6LDIAWgNAqcKvIgeATIgIAEIAIgFAqcKvIgcAQAq7K0IgRASID5jsArEK0IAmg4AmurBIjmQzApmHTIHdw3Al6q4IktTCApBrYIhyRFAlFqoIkwQiAAAoVIrVTfArEK0IDBkCAGDjPIxPOaALUImI2tCxAmcIoIkICO");
	this.shape_16.setTransform(222.5,75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(0,255,255,0.816)").ss(0.5,1,1).p("AIBgsIydLfIBNgrICXhYIPGpGAjRp8ImGQFIGdv7Agto0IqsUIIgBACIADgFICuk0IITvEAhbpJInfPeIH0vSABEnwIsLSrIApg7IB3iqIKBu3AonHWIKRukAAYoJIo1OvIJKuhACCnEIqFN6IKYtpACsmnIt8RyIDckKIK0tXAD2ljIrhMuIjrEIIgBACIAEgEIAHgHIARgRICsiuIMttNAEsktIs7M4ADkl1IrPNAAFnj7Iw7PNIgCACIERjoIM9rTAFDkfIsWL9IMmrpAG5iUIx4NbIAzgjICwh9IOkqmAHQhoIusKPAGYi7ItVK0INjqfAIlAVIvBIXIPMoAAI/BBIz5KGIgKAGIEyiQIPcnkAJeCHIvsHCIP0mqAJ0C1I1FIgIAAAAIFLh7IQDmNAKdEwI10GpIAAABIEEhHIR3lKAKlFjIx4EwAKMD/IwQFpIQWlRAK/GtI2WEtIAAAAIgBAAIgBAAIAAABIgBAAIABAAIAAAAIABAAIEJgwISSjlALAHgIyPDLAKxF8IwrEKIQvjyArYLbIgBAAIAAAAIFpgjIRGhzALKH4Iw+CuIRAiVALaJ3IxJBQIRJg3ArdLdIAAgBIABgBIAAAAIAAAAIAAAAIAAABIgBABIAAAAIACgBIgBABIABAAIFugDIROgVAHjhWIuOJoIObpSAm4IwIPLouArHK7IgHAKIgHAJIgDAFIgCADIAAAAIABgBIABgCIADgIIgFAJIAAACIAAAAIAAgCICDlLAreLbIAAAAIAAABIAAgBIAAAAIAAABIAAAAIAAAAIAAgBIABAAIgBADIABgDIAAAAIAAAAIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAIgBABIACgBIAAAAIAAgBIAAAAIAAgEIAAgCIAAAFIABgNIgBAIIASlmIAlxLArbLYIAAAAIAAAAIAAgBIAAABIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAABIgBAAIAAAAIAAAAIABAAIAAgBIAAAAIAAAAIAAAAIgBAAIABgDIgBACIABgBIABgDIAAgEIgBAFIAAACIgBADIABgGIBHldIDOw5ArbLXIABgBIABgCIAAABIgBABIAAAAIgBABIAAAAIABAAIgBABIABgBIAAABIAAgBIACgDIgCADIAAAAIgBABIAAAAgArcLXIAAABIAAAAIABgBIAAABIAAAAIAAAAIABgCIAAAAIAAAAIACgDIABgCIgCADIACgDAkUqWInFVjIgBAEIgBAGIAAgBIHw1VAraLWIgBAAIAAACArdLbIAAAAIAAgBIAAAAIAAABIgBAAIAAAAIAAAAIgCABAreLbIAAAAIAAAAIAAAAIAAgBIAAAAIAAAAIAAAAIAAgBIAAAAIA9llICtw/AreLbIAAAAArdLaIAAAAIAAAAIgBAAIAAgBIACgNIgCANIAAABAreLaIAAAAIAAABAreLbIABgBIgBAAIAAABIAAAAIAAAAIABgBIAAAAIAAAAIAAAAAreLbIAAgBArdLaIAAgBIABAAIgCAAIACAAIABgFIAAgBIACgIIFF2GArcLZIAAgBIAAAAIAAAAIAAABIAAgBIAAgBAraLZIAAAAIgBAAIAAAAIABAAIgBACIABgBIgBABIgBAAIABAAIgBAAIABgBIAAgBIAAABIAAAAIAAAAIAAAAIgBAAIAAAAIAAAAIAAAAIAAABIAAAAIgBAAIAAAAIAAAAIAAAAIAAAAArcLaIAAABIAAAAIAAAAIAAAAIAAgBgArcLbIAAgBIAAAAIAAgBIAAAAIAAgBIAAAAArbLZIAAAAIgBABIAAAAIAAAAIAAAAIAAAAIAAgBIAAAAIAAgBIAAABIAAAAIAAAAIAAABIAAgBIAAABIAAAAIAAAAIgBABIABgBIAAAAIAAAAIAAAAArcLbIAAAAIAAAAIAAAAIAAAAArcLaIAAgBIAAAAIgBAAArdLaIABAAArcLZIAAAAIAAAAIgBABIABAAIAAAAArcLZIAAAAArdLbIAAAAIAAAAIAAAAIABAAIAAgBIAAAAIAAAAArdLbIAAAAIgBADIABgDIABAAIAAAAIgBAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIgBAAArcLbIgBAAArcLbIAAAAIAAAAIAAAAIAAAAIAAAAIAAAAIAAgBIABAAIgBAAIAAAAIAAABgArbLaIAAgBIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIgBAAIAAAAIAAAAIABgBIABgBIgBAAIAAABIAAgBArbLZIgBAAIABAAArdLcIABAAIAAgBIAAAAIAAAAIACAAIgBABIAAAAIABgBIAAAAIgBABArcLZIAAABIAAAAArbLZIAAAAIAAAAIAAAAIAAAAIAAgBIAAABIAAgBIAAAAArbLaIAAgBIAAAAIAAAAIAAAAIgBACArbLaIAAAAArcLZIAAAAIAAAAIAAAAIAAABArcLbIAAAAIAAAAIAAAAArcLaIABAAArcLbIAAgBArcLbIAAAAIAAAAIAAAAIAAAAIAAAAIABAAIAAAAIgBAAArbLYIAAAAIAAAAIABAAIAAAAIABgBIgBABIAAAAIAAABIgBAAIAAAAIABAAIAAAAIAAAAAraLbIAAAAIAAAAIgBAAIABAAIgBAAIAAAAIABgBIABAAIgBAAIAEgCIgEABArbLbIAAAAArbLbIAAAAArRLVIgBABIAAAAIAAAAIgBAAIABAAIgBAAIgEACIAAABIABAAIADgDIgBABIgBAAIgCABIgBABIAAAAIgBABIgBAAIAAAAIgBABIAAAAIAAAAIgBAAIABAAIAAAAArcLbIABAAIAAAAIABAAIAAAAIAAAAIAAAAArcLbIAAAAIgBACIAAABIABgBIgBAAIABgBIAAgBAreLcIABgBIAAAAArcLaIgBAAIAAAAArcLYIAAAAArcLYIABAAIgBABIAAgBIABAAIAAAAArcLZIAAAAArdLbIABAAIAAAAgAraLYIgBAAIAAAAIABAAAreLZIAAgDIAd2uALgKrI27AyIAAgBIWth+ArdLeIACgBAreLcIAAABIAAABgAreLcIAAABIAAAAgAreLcIAAABAqMKkIguAhIgKAHIACgBIgFADIgDACIgBABIACgBIAFgDArKLQIABAAIAGgEIgEACIgDABIgCACIABgBIAEgDIgEACIgBABIgBAAIABgBIgIAFIAHgEIgCACIABgBIgCACIADgCIgEADIABAAIgBABIgCABIAAAAIgCAAIABAAIABAAIgBABArNLRIAAAAIABAAgArLLRIgDACIACgBIgDACIgCABIADgCgAm9H5IkMDVIgCABIAEgDIgCACIgDABIRPuaArMLQIgCABIADgBIABgBIAGgDIgDABIADgCIgDABIAIgFIgFAEIAKgGIACgBIENiyArNLRIADgBAJOByI0aJgIAIgFArMLKIgKAJIgBABIgCACIgBABIAAAAIABgBIAAAAIAAAAIADgEIAAgBIABgBIgBACIgCACArVLQIADgEIgDADIgDAEIAAABArWLSIABgDIAHgKICxkfArVLOIgCADArbLVIABgCIABgGIACgIIAFgRIgHAXIgBAEIADgKIBilGIEwwiArULUIgEACIgBABIAJgEIABgBIgKAFIAAAAIgBABIAAAAIAAAAIABgBIABgBIAAAAIAAAAIACgCIACgCIAIgIIgHAHIgDADIgCACIABgBIgBAAIAAABIgBAAIAAABIAAAAIAAgBIABAAIgBABArTLWIACgCIgBABIACgCIAAAAIgDACIABAAIgBABArOLTIgCABIADgDArWLRIgCAEIADgDIAFgHIgFAFArSLWIABgBIAAAAgArRLVIgBABIADgCgArWLYIAAgBIABgBIABAAIABgBIgBABIgBAAIABAAArZLaIABgBIACgBIABgBIAAgBIAAABIAAAAIABgBIABAAIgBAAArVLXIgBABIgCABArWLYIABgBArWLXIABgBIgFADgArYLVIgBABIgBABAraLWIAAABArZLXIAAAAIgBABArYLVIgBABIABgBIABgBIACgCIOixTAraLXIAAgBArZLXIAAgBIAAABIgBACIAGgDArYLWIgBAAArbLbIABgBIAAABIABgBIgBABIABAAArZLaIAAAAIAAAAIABgBIABAAIgBABArYLaIAAAAIAAAAIgBAAIgBAAArZLaIABAAIAAAAIABAAIAAgBIgBABArYLbIABgBIgBAAIgBABIAAAAAraLbIABAAIAAAAIFlg1ArZLaIAAAAIABgBArZLaIABgBArYLaIgBAAAraLbIABAAIgCABIFsgVAraLZIAAgBArXLaIAAgBIABAAIABgBIgBABIgBAAIABAAIFShxArRLVIgEADIVSnvArOLRIAAAAArYLWIACgCIgCACArOLTIAAAAIgBABIFBiLArQLLIAMgSIgOATIALgRAparaIiBWPIgBAXIAplaIByxGAraLYIgBAAArbLVIABgEIB4lOIFmwQArbK1IgCAXIBp2pAh1pPInxQnIhpDlIgIAUICdk8AigprIo1U2IAGgOAmcIsIkICOIgWAMIgJAGIAJgFIAWgNIBVgyAqcKzIgeATIgIAFIAIgGAqcKzIgcARAq7K5IgRARID5jsArSK0IArilIEtzDArEK5IAmg5ArMFuIA+xJAmuq8IjmQyApmHYIHdw4Ap1F/IFHwaAEMlUIvYQeAqnIPIFIyzArbLTID72UAoNrQIjRWpAqzFyICLxCAAAoRIrVTfArEK5IDBkDArXLaIFdhUALUIrI2tCw");
	this.shape_17.setTransform(222.5,74.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).wait(1));

	// Capa 1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AgMhuQATBsAGBw");
	this.shape_18.setTransform(296.6,128.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AgdiuQAtCaAMCoQABANABAO");
	this.shape_19.setTransform(295,122.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AgnjOQBDDEAMDZ");
	this.shape_20.setTransform(293.9,119.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AhEkVQB5EAAQEr");
	this.shape_21.setTransform(291,112.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AhrlcQDDE5AUGA");
	this.shape_22.setTransform(287.1,105.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AiImGQD6FYAXG0");
	this.shape_23.setTransform(284.3,101.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("Aiwm4QFHF7AaH1");
	this.shape_24.setTransform(280.3,96.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("Ajyn8QAbAZAaAaQAkAkAhAlQFRF/AaH+");
	this.shape_25.setTransform(273.6,89.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AkcofQBHA5BCBCQGTGVAdIu");
	this.shape_26.setTransform(269.4,85.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AlTpIQCCBWB1B1QGTGUAdIy");
	this.shape_27.setTransform(263.9,81.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AlcpCQCMBaB+B9QGKGLAlIi");
	this.shape_28.setTransform(262.9,80.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("Amzp9QDvBtDGDIQGVGUAdIy");
	this.shape_29.setTransform(254.3,76.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AnzqWQE6BqD7D9QGVGUAdIy");
	this.shape_30.setTransform(247.9,74.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("AodqjQFsBjEdEeQGVGUAdIy");
	this.shape_31.setTransform(243.7,72.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("ApnqzQHIBKFVFXQGVGUAdIy");
	this.shape_32.setTransform(236.3,71.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("Aqtq7QIgAmGJGLQGVGUAdIy");
	this.shape_33.setTransform(229.3,70.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(0,255,255,0.816)").ss(12.6,1,1).p("ArGq8QJAAWGbGdQGVGUAdIy");
	this.shape_34.setTransform(226.8,70.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.1,135.2,147,12.6);


(lib.home = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAWBNIAAhTIgqAAIAABTIguAAIAAhYIggAAIBihBIBjBBIgeAAIAABYg");
	this.shape.setTransform(15.3,15.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaBeIAAhmIgyAAIAABmIg5AAIAAhsIgmAAIB3hPIB4BPIglAAIAABsg");
	this.shape_1.setTransform(15.3,15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AhzjEQhHAAAABMIAADyQAABLBHAAIDnAAQBHAAAAhLIAAjyQAAhMhHAAg");
	this.shape_4.setTransform(15.1,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhyDEQhIAAAAhKIAAjyQAAhMBIAAIDmAAQBHAAAABMIAADyQAABKhHAAg");
	this.shape_5.setTransform(15.1,15.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,31.8);


(lib.btnadelanteatras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(15.1,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhZAAIAAAAIB/hlIAAAnIA1AAIAAB9Ig1AAIAAAlIABAAIAAACg");
	this.shape_1.setTransform(13.2,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAhsAAIAAAAICABmIAAgCIgBAAIAAglIA1AAIAAh9Ig1AAIAAgng");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AhzjEQhHAAAABMIAADyQAABLBHAAIDnAAQBHAAAAhLIAAjyQAAhMhHAAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ah+AAIC1iNIAAAtIBIAAIAAC/IhIAAIAAAvg");
	this.shape_4.setTransform(12.7,17.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhyDEQhIAAAAhKIAAjyQAAhMBIAAIDmAAQBHAAAABMIAADyQAABKhHAAgAiWAOIC1CPIAAgwIBIAAIAAi+IhIAAIAAgtg");
	this.shape_5.setTransform(15.1,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_6.setTransform(15.1,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAh4ALICRBzIAAgmIA6AAIAAiZIg6AAIAAglg");
	this.shape_7.setTransform(15.1,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhlAAICRhxIAAAkIA6AAIAACZIg6AAIAAAmg");
	this.shape_8.setTransform(13.2,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape},{t:this.shape_1}]},1).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,31.8);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}