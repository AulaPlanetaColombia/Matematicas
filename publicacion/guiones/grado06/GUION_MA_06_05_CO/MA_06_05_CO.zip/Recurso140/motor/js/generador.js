Generador = new function()
{
	this.nPreg;
			
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.plano = "";
	this.co_pizarra = "";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,"#000000",false];
		Random.init(semilla,100);
		
		this.llPreguntas=new Array();
        this.llRespuestas=new Array();
        this.llPreguntasVar=new Array();
        this.llRespuestasVar=new Array();
        this.llPreguntasVar[0]=new Array();
        this.llPreguntasVar[1]=new Array();
        this.llPreguntasVar[2]=new Array();
        this.llPreguntasVar[3]=new Array();
        this.llRespuestasVar[0]=new Array();
        this.llRespuestasVar[1]=new Array();
        this.llRespuestasVar[2]=new Array();
        this.llRespuestasVar[3]=new Array();
		
		for( this.nPreg = 0; this.nPreg < Motor.qOperaciones; this.nPreg++ ) {
			this.enunciar();
		}		
	}
	
	this.enunciar = function()
	{
	    var entero;
	    var denom;
	    var numer;
        var nVariacion = Motor.lVariaciones[this.nPreg];
        switch(nVariacion) {
            case 1://mixto--->fracción
                while(true) {
                    entero = Random.integer(1,9);
                    denom = Random.integer(2,20);
                    numer = Random.integer(1,denom-1);
                    if( this.llPreguntasVar[nVariacion-1].indexOf([entero,numer,denom])==-1) {
                        this.llPreguntasVar[nVariacion-1].push([entero,numer,denom]);
                        this.llRespuestasVar[nVariacion-1].push([entero*denom+numer,denom]);
                        this.llPreguntas.push([entero,numer,denom]);
                        this.llRespuestas.push(JL.simplificar([entero*denom+numer,denom]));
                        break;
                    }
                }
            break;
            case 2://fracción--->mixto
                while(true) {
                    entero=Random.integer(1,9);
                    denom=Random.integer(2,20);
                    numer=Random.integer(1,denom-1);
                    if( this.llRespuestasVar[nVariacion-1].indexOf([entero,numer,denom])==-1) {
                        this.llRespuestasVar[nVariacion-1].push([entero,numer,denom]);
                        this.llPreguntas.push([entero*denom+numer,denom]);
                        var auxL = JL.simplificar([numer,denom]);
                        this.llRespuestas.push([entero,auxL[0],auxL[1]]);
                        break;
                    }
                }
            break;
            case 3://fracción--->irreductible
                while(true) {
                    var factor = Random.integer(2,15);
                    var a = Random.integer(1,9)*factor;
                    var b = Random.integer(2,9)*factor;
                    if(( this.llPreguntasVar[nVariacion-1].indexOf([a,b])==-1)&&(this.llPreguntasVar[nVariacion-1].indexOf([a,b])==-1)) {
                        this.llPreguntasVar[nVariacion-1].push([a,b]);
                        this.llPreguntas.push([a,b]);
                        this.llRespuestas.push(JL.simplificar([a,b]));
                        break;
                    }
                }
            break;
            case 4://fracción--->equivalente
                while(true) {
                    a=Random.integer(1,12);
                    b=Random.integer(2,12);
                    if(( this.llPreguntasVar[nVariacion-1].indexOf([a,b])==-1)&&(this.llPreguntasVar[nVariacion-1].indexOf([a,b])==-1)) {
                        this.llPreguntasVar[nVariacion-1].push([a,b]);
                        this.llPreguntas.push([a,b]);
                        this.llRespuestas.push([Number(a/b)]);
                        break;
                    }
                }
            break;
        }
        
        Motor.lOperaciones[this.nPreg] = new Object();
        Motor.lOperaciones[this.nPreg].pregunta = this.llPreguntas[this.nPreg];
        Motor.lOperaciones[this.nPreg].respuesta = this.llRespuestas[this.nPreg];
        Motor.lOperaciones[this.nPreg].variacion = nVariacion;
        Motor.lOperaciones[this.nPreg].enunciado = Motor.lEnunciados[nVariacion-1];
        Motor.lOperaciones[this.nPreg].in_entero = "";
        Motor.lOperaciones[this.nPreg].in_numerador = "";
        Motor.lOperaciones[this.nPreg].in_denominador = "";
        Motor.lOperaciones[this.nPreg].estaListo = false;
        Motor.lOperaciones[this.nPreg].correcto = false;
        Motor.lOperaciones[this.nPreg].enunciado = Motor.lEnunciados[nVariacion-1];
	};
	

}