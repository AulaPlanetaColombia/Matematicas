(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0,1,0,0,0);
        titulo1(this,txt['titulo']);
this.mc_1 = new lib.mc_1();
	this.mc_1.setTransform(556.9,342,1,1,-57.1,0,0,0.1,-0.1);

	this.mc_pastel2 = new lib.mc_pastel2();
	this.mc_pastel2.setTransform(480.8,334.4,1,1,-82.3,0,0,0.1,-0.1);
           this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
    
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.mc_pastel2,this.mc_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit1'],"23px");
	this.instance = new lib.mc_divisiondesple();
	this.instance.setTransform(406,326,1,1,0,0,0,20,36);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit2'],"23px");
    this.instance = new lib.mc_division2();
	this.instance.setTransform(462.5,326,1,1,0,0,0,20,36);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3'],"23px");
    this.instance = new lib.mc_division2();
	this.instance.setTransform(462.5,326,1,1,0,0,0,20,36);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['tit4'],"23px");
this.btn_02 = new lib.btn02();
	this.btn_02.setTransform(587.3,316,1,1,0,0,0,76.4,28.3);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn02(), 3);

	this.btn_01 = new lib.btn01();
	this.btn_01.setTransform(362.2,315.4,1,1,0,0,0,76.4,28.3);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn01(), 3);
        this.btn_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.btn_01,this.btn_02);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['text1'],0,-40);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(400,373-incremento);

	this.text = new cjs.Text("c\nd", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 38;
	this.text.setTransform(397.2,339.5);

	this.text_1 = new cjs.Text("=", "25px Verdana");
	this.text_1.lineHeight = 33;
	this.text_1.lineWidth = 20;
	this.text_1.setTransform(338.5,355.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(304.4,373-incremento);

	this.text_2 = new cjs.Text("a\nb", "25px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 33;
	this.text_2.lineWidth = 37;
	this.text_2.setTransform(302,339.5);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar, this.siguiente,this.text_2,this.shape_1,this.text_1,this.text,this.shape );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
        texto(this, txt['text1'],0,-40);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(400,373-incremento);

	this.text = new cjs.Text("c\nd", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 38;
	this.text.setTransform(397.2,339.5);

	this.text_1 = new cjs.Text("=", "25px Verdana");
	this.text_1.lineHeight = 33;
	this.text_1.lineWidth = 20;
	this.text_1.setTransform(338.5,355.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(304.4,373-incremento);

	this.text_2 = new cjs.Text("a\nb", "25px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 33;
	this.text_2.lineWidth = 37;
	this.text_2.setTransform(302,339.5);
        this.text_3 = new cjs.Text("a · d = b · c", "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 33;
	this.text_3.lineWidth = 187;
	this.text_3.setTransform(602.5,353.4);

	this.Flecha_25 = new lib.Flecha25();
	this.Flecha_25.setTransform(473.3,375-incremento);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
         this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar,this.anterior, this.siguiente,this.text_2,this.shape_1,this.text_1,this.text,this.shape,this.Flecha_25,this.text_3 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
      
        this.instance = new lib.mc_ejemplo1();
	this.instance.setTransform(216.7,294.2,1,1,0,0,0,67.8,36);

	this.text = new cjs.Text(txt['text2'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 785;
	this.text.setTransform(78.6,145.7);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
         this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar,this.anterior, this.siguiente,this.text,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
      

this.instance = new lib.mc_resultado2();
	this.instance.setTransform(658.7,463.2,1,1,0,0,0,150,25);

	this.instance_1 = new lib.mc_resultado1();
	this.instance_1.setTransform(277.9,463.2,1,1,0,0,0,150,25);

	this.instance_2 = new lib.mc_ejemplo1despleOK();
	this.instance_2.setTransform(217.7,294.2,1,1,0,0,0,67.8,36);
        this.instance_2 = new lib.mc_ejemplo1("single",114);
	this.instance_2.setTransform(216.7,294.2,1,1,0,0,0,67.8,36);
        
	this.text = new cjs.Text(txt['text2'], "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 785;
	this.text.setTransform(78.6,145.7);
      
      this.text1 = new cjs.Text("=", "20px Verdana");
	this.text1.textAlign = "center";
	this.text1.lineHeight = 28;
	this.text1.setTransform(471.3,450.8);
        
         this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.text1,this.cerrar,this.anterior, this.siguiente,this.text,this.instance,this.instance_2,this.instance_1 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        texto(this, txt['text3'],0,-40);
	this.instance = new lib.mc_simplifica2correccion("single",0);
	this.instance.setTransform(115.2,289.8,1,1,0,0,0,20,36);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar, this.siguiente,this.text_2,this.shape_1,this.text_1,this.text,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
        texto(this, txt['text3'],0,-40);
	this.instance = new lib.mc_simplifica2correccion();
	this.instance.setTransform(115.2,289.8,1,1,0,0,0,20,36);
     this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
    
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar,this.anterior, this.siguiente,this.text_2,this.shape_1,this.text_1,this.text,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1,0, 0, 1);
        texto(this, txt['text3'],0,-40);
	this.instance = new lib.mc_simplifica2correccion("single",129);
	this.instance.setTransform(115.2,289.8,1,1,0,0,0,20,36);
     this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
    
       this.text = new cjs.Text("=", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 186;
	this.text.setTransform(661,413.4);

	this.instance2 = new lib.mc_simplificado2();
	this.instance2.setTransform(804.9,415.5,0.859,0.859,90,0,0,101.8,-75.9);

	this.instance_1 = new lib.mc_simplificado1();
	this.instance_1.setTransform(572,441,0.859,0.859,90,0,0,101.8,-75.9);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });

        this.addChild(this.logo, this.texto, this.cerrar,this.anterior, this.siguiente,this.text_2,this.shape_1,this.text_1,this.text,this.instance,this.instance_1,this.instance2 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        texto=texto || "La fracción irreducible";
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
(lib.mc_simplificado2 = function() {
	this.initialize();

	// simplificado
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape.setTransform(205.4,-110.2,0.687,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_1.setTransform(205.4,-75.8,0.687,0.687);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_2.setTransform(205.4,-41.5,0.687,0.687);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_3.setTransform(171,-110.2,0.687,0.687);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_4.setTransform(136.3,-110.2,0.687,0.687);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_5.setTransform(101.8,-110.2,0.687,0.687);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_6.setTransform(67.3,-110.2,0.687,0.687);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_7.setTransform(32.6,-110.2,0.687,0.687);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,2,1).p("AwLCsIAAlXMAgXAAAIAAFX");
	this.shape_8.setTransform(114.9,-110.1,1.125,1,0,0,0,0.1,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_9.setTransform(171,-75.8,0.687,0.687);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_10.setTransform(136.3,-75.8,0.687,0.687);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_11.setTransform(101.8,-75.8,0.687,0.687);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_12.setTransform(67.3,-75.8,0.687,0.687);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_13.setTransform(32.6,-75.8,0.687,0.687);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,2,1).p("AQMCrIAAlWAwLCrIAAlW");
	this.shape_14.setTransform(114.9,-75.7,1.125,1,0,0,0,0.1,0);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_15.setTransform(171,-41.5,0.687,0.687);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_16.setTransform(136.3,-41.5,0.687,0.687);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_17.setTransform(101.8,-41.5,0.687,0.687);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_18.setTransform(67.3,-41.5,0.687,0.687);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_19.setTransform(32.6,-41.5,0.687,0.687);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,2,1).p("Ah9CsIUJAAIAAlWAh9CsIwOAAIAAlW");
	this.shape_20.setTransform(114.8,-41.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(185,0,0,0.329)").s().p("AoGICIAAlYIAAqrIQNAAIAAQDg");
	this.shape_21.setTransform(50.3,-75.4);

	this.addChild(this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.6,-127.4,233,103.5);


(lib.mc_simplificado1 = function() {
	this.initialize();

	// simplificado
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape.setTransform(175.2,-51.6,0.687,0.687);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_1.setTransform(175.2,-17.2,0.687,0.687);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_2.setTransform(175.2,17,0.687,0.687);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_3.setTransform(141.4,-51.6,0.687,0.687);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_4.setTransform(106.7,-51.6,0.687,0.687);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_5.setTransform(72.1,-51.6,0.687,0.687);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_6.setTransform(37.6,-51.6,0.687,0.687);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_7.setTransform(2.9,-51.6,0.687,0.687);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,2,1).p("AimCsIVSAAIAAlXI1SAAIwFAAIAAFXg");
	this.shape_8.setTransform(88.2,-51.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(185,0,0,0.341)").s().p("AoBCrIAAlVIQDAAIAAFVg");
	this.shape_9.setTransform(20,-51.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_10.setTransform(141.4,-17.2,0.687,0.687);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_11.setTransform(106.7,-17.2,0.687,0.687);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_12.setTransform(72.1,-17.2,0.687,0.687);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_13.setTransform(37.6,-17.2,0.687,0.687);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_14.setTransform(2.9,-17.2,0.687,0.687);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,2,1).p("AiiCrIVOAAIAAlWI1OAAIwJAAIAAFWg");
	this.shape_15.setTransform(88.2,-17.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(185,0,0,0.341)").s().p("AoDCrIAAlWIQHAAIAAFWg");
	this.shape_16.setTransform(20.2,-17.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_17.setTransform(141.4,17,0.687,0.687);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_18.setTransform(106.7,17,0.687,0.687);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_19.setTransform(72.1,17,0.687,0.687);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_20.setTransform(37.6,17,0.687,0.687);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_21.setTransform(2.9,17,0.687,0.687);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,2,1).p("AiiCrIVOAAIAAlWI1OAAIwJAAIAAFWg");
	this.shape_22.setTransform(88.2,17);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(185,0,0,0.341)").s().p("AoDCrIAAlWIQHAAIAAFWg");
	this.shape_23.setTransform(20.2,17);

	this.addChild(this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-31.4,-68.8,239.3,103.1);


(lib.mc_simplifica = function() {
	this.initialize();

	// texte
	this.text = new cjs.Text("se divide por un\ndivisor común: 3", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 29;
	this.text.lineWidth = 235;
	this.text.setTransform(178.3,1.3);

	// fraccio
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(20,36);

	this.text_1 = new cjs.Text("9\n21", "25px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 33;
	this.text_1.lineWidth = 33;
	this.text_1.setTransform(17.5,0);

	this.addChild(this.text_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,299.8,72.8);


(lib.mc_resultado2 = function() {
	this.initialize();

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape.setTransform(251.5,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_1.setTransform(201,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_2.setTransform(150.7,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_3.setTransform(100.5,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_4.setTransform(50,25);

	// Capa 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,2,1).p("AyKAAMAkVAAA");
	this.shape_5.setTransform(151,24.9,1.286,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_6.setTransform(251.5,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_7.setTransform(201,25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_8.setTransform(150.7,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_9.setTransform(100.5,25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_10.setTransform(50,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,2,1).p("An4j5IfcAAIAAHzI/cAAIvrAAIAAnzg");
	this.shape_11.setTransform(150.8,25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFF66").s().p("An0D6IAAnzIPpAAIAAHzg");
	this.shape_12.setTransform(50.2,25);

	this.addChild(this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,301.6,50.1);


(lib.mc_resultado1 = function() {
	this.initialize();

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape.setTransform(251.5,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_1.setTransform(201,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_2.setTransform(150.7,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_3.setTransform(100.5,25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_4.setTransform(50,25);

	// Capa 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_5.setTransform(251.5,25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_6.setTransform(201,25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_7.setTransform(150.7,25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_8.setTransform(100.5,25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,2,1).p("AAAj6IAAH1");
	this.shape_9.setTransform(50,25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,2,1).p("An4j5IfcAAIAAHzI/cAAIvrAAIAAnzg");
	this.shape_10.setTransform(150.8,25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF66").s().p("An0D6IAAnzIPpAAIAAHzg");
	this.shape_11.setTransform(50.2,25);

	this.addChild(this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,301.6,50.1);


(lib.mc_ejemplo1despleOK = function() {
	this.initialize();

	// clau3
	this.text = new cjs.Text("24", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 44;
	this.text.setTransform(601.9,84.7);

	this.text_1 = new cjs.Text("{", "80px Arial");
	this.text_1.lineHeight = 88;
	this.text_1.lineWidth = 51;
	this.text_1.setTransform(647.5,79.3,1,1,0,90,-89.9);

	// clau2
	this.text_2 = new cjs.Text("{", "80px Arial");
	this.text_2.lineHeight = 88;
	this.text_2.lineWidth = 51;
	this.text_2.setTransform(542.8,79.3,1,1,0,90,-89.9);

	this.text_3 = new cjs.Text("24", "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 33;
	this.text_3.lineWidth = 44;
	this.text_3.setTransform(491.5,84.7);

	// 2x12
	this.text_4 = new cjs.Text("2 · 12 = 6 · 4", "25px Verdana");
	this.text_4.lineHeight = 33;
	this.text_4.lineWidth = 200;
	this.text_4.setTransform(460.6,13.5);

	// texte
	this.text_5 = new cjs.Text("son equivalentes porque", "20px Verdana");
	this.text_5.lineHeight = 28;
	this.text_5.lineWidth = 255;
	this.text_5.setTransform(188,18.4);

	// clau
	this.text_6 = new cjs.Text("{", "60px Arial");
	this.text_6.lineHeight = 68;
	this.text_6.lineWidth = 38;
	this.text_6.setTransform(167.8,-10,1,1,0,0,180);

	// fracciones
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(99.5,36);

	this.text_7 = new cjs.Text("4\n12", "25px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 33;
	this.text_7.lineWidth = 33;
	this.text_7.setTransform(97,0);

	this.text_8 = new cjs.Text("=", "25px Verdana");
	this.text_8.lineHeight = 33;
	this.text_8.lineWidth = 24;
	this.text_8.setTransform(38,15.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(3.8,36);

	this.text_9 = new cjs.Text("2\n6", "25px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 33;
	this.text_9.lineWidth = 33;
	this.text_9.setTransform(1.3,0);

	this.addChild(this.text_9,this.shape_1,this.text_8,this.text_7,this.shape,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-16.1,0,680.3,119.1);


(lib.mc_ejemplo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// clau3
	this.text = new cjs.Text("{", "40px Georgia");
	this.text.lineHeight = 88;
	this.text.lineWidth = 51;
	this.text.setTransform(647.5,69.3,1,2,0,90,-89.9);

	this.text_1 = new cjs.Text("24", "25px Verdana");
	this.text_1.lineHeight = 88;
	this.text_1.lineWidth = 51;
	this.text_1.setTransform(590,79.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},102).to({state:[{t:this.text_1},{t:this.text}]},9).wait(4));

	// clau2
	this.text_2 = new cjs.Text("{", "40px Georgia");
	this.text_2.lineHeight = 88;
	this.text_2.lineWidth = 51;
	this.text_2.setTransform(542.8,69.3,1,2,0,90,-89.9);

	this.text_3 = new cjs.Text("24", "25px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 33;
	this.text_3.lineWidth = 44;
	this.text_3.setTransform(500,79.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2}]},81).to({state:[{t:this.text_3},{t:this.text_2}]},11).wait(23));

	// 2x12
	this.text_4 = new cjs.Text("2 · 12", "25px Verdana");
	this.text_4.lineHeight = 33;
	this.text_4.lineWidth = 90;
	this.text_4.setTransform(465.6,16+incremento);
var textobq="2 · 12 = 6 · 4";
if (isbq) textobq="2 · 12 =    6 · 4"
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_4,p:{text:"2 · 12",lineWidth:90}}]},42).to({state:[{t:this.text_4,p:{text:"2 · 12 =",lineWidth:120}}]},14).to({state:[{t:this.text_4,p:{text:textobq,lineWidth:200}}]},13).wait(46));

	// texte
	this.text_5 = new cjs.Text("son equivalentes porque", "20px Verdana");
	this.text_5.lineHeight = 28;
	this.text_5.lineWidth = 255;
	this.text_5.setTransform(188,18.4+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_5}]},32).wait(83));

	// clau
	this.text_6 = new cjs.Text("{", "30px Georgia");
	this.text_6.lineHeight = 68;
	this.text_6.lineWidth = 38;
	this.text_6.setTransform(167.8,2,1,2,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_6}]},14).wait(101));

	// fracciones
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(99.5,36);

	this.text_7 = new cjs.Text("4\n12", "25px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 33;
	this.text_7.lineWidth = 33;
	this.text_7.setTransform(97,4+incremento);

	this.text_8 = new cjs.Text("=", "25px Verdana");
	this.text_8.lineHeight = 33;
	this.text_8.lineWidth = 24;
	this.text_8.setTransform(38,19+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(3.8,36);

	this.text_9 = new cjs.Text("2\n6", "25px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 33;
	this.text_9.lineWidth = 33;
	this.text_9.setTransform(1.3,4+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_9},{t:this.shape_1},{t:this.text_8},{t:this.text_7},{t:this.shape}]}).wait(115));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.1,0,135.7,72.8);


(lib.mc_division2 = function() {
	this.initialize();

	// fraccion1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AkUAAIIpAA");
	this.shape.setTransform(26.6,33-incremento,1,1,0,0,0,-3.4,0);

	this.text = new cjs.Text(" 15\n  8", "bold  25px Verdana");
	this.text.lineHeight = 33;
	this.text.lineWidth = 76;
	this.text.setTransform(1,0);

	this.addChild(this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(1,0,80,72.8);


(lib.Flecha25 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A171B").s().p("AAAAfIjjAAIAAg9IDjAAIAAhkIDkCCIjkCDg");

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-22.8,-13.1,45.8,26.4);


(lib.mc_1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F6CDCE").s().p("AgcAAQAHgHAUAIQANAIABgLQAAgKAGAGQAGAFAEAKg");
	this.shape.setTransform(-3.2,-20.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B22632").s().p("AhiAAQB5hIBMBmg");
	this.shape_1.setTransform(-6,-22.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D74F32").s().p("AgKAkQgEgHgDgTQgBgJgGgOQgEgOAJgLIACgDIAsA4QgCAQgPAIQgHADgDAAQgHAAgDgGg");
	this.shape_2.setTransform(-22.9,-6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F6CDCE").s().p("AgMAeIgNgVQgMgLASgTQASgSAQANQASAOgDAPQgCARgVAJQgHADgGAAQgEAAgCgCg");
	this.shape_3.setTransform(-20.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B22632").s().p("Ag8A+QgTghABgoQAAgrAWgqICICqQgvAXghAAQgoAAgUgjg");
	this.shape_4.setTransform(-20.3,-2.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F8DC9B").s().p("AABAGIgIgGQgCgBAJgFQADgCADACQAFABgEAFQgBABABAGQAAAAAAAAQAAABgBAAQAAAAAAAAQAAAAAAAAIgFgCg");
	this.shape_5.setTransform(146.3,1.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E6BA7F").s().p("AAAANQgHgGgDgHQgDgIAJgFQAIgFAFAIQAFAIgFAIIgCAIQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAQgCAAgDgDg");
	this.shape_6.setTransform(146.4,1.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#924B30").s().p("AgEAPQgIgGgCgJQgCgKAJgFQAIgFAJAKQAKAKgIAGIgJALIgDABQgBAAgDgDg");
	this.shape_7.setTransform(146.7,1.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F8DC9B").s().p("AgBAIQgHgCACgGQADgJAEACQAIADgCACIgFACIgCAFQAAABAAABQAAAAAAABQAAAAAAAAQAAAAgBAAIAAAAg");
	this.shape_8.setTransform(74.3,113);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E6BA7F").s().p("AgEAOQgLgCAEgNQAEgPAIAEQAJAFACADQADAEgGAEQgLAKgCAAIAAAAg");
	this.shape_9.setTransform(74.4,113.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#924B30").s().p("AgLAMQgJgIAHgKQAHgMAHAEIANAGQAEACgCAGQgEAJgIAFQgEACgBAAQgFAAgFgEg");
	this.shape_10.setTransform(74.4,113.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F8DC9B").s().p("AgDAKQgBgHAEgHQACgJACAFQACAFgFAHQgCAHgBAAIgBgBg");
	this.shape_11.setTransform(120.8,95.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E6BA7F").s().p("AgNARQgCgKALgOQAJgRAHAFQAFAEgHAFQgHAHABACQACAEgHAMQgGAGgDAAQgCAAgBgEg");
	this.shape_12.setTransform(121.6,94.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#924B30").s().p("AgNARQgCgKALgOQAJgRAHAFQAFAEgFAHQgFAIABAAQACAGgKAKQgGAGgDAAQgDAAgBgFg");
	this.shape_13.setTransform(121.6,94.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#F8DC9B").s().p("AAAAGQgEgCAAgEQABgGAEABQAFAAgBAIQAAABgBAAQAAABAAAAQgBABgBAAQAAAAgBAAIgBAAg");
	this.shape_14.setTransform(133.4,64.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E6BA7F").s().p("AgJgDQABgIAJACQALADgCAIQgBAHgJABIgCAAQgJAAACgNg");
	this.shape_15.setTransform(133.7,64.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#924B30").s().p("AgHAKQgHgFABgDQAEgDABgFQACgIAJACQAMACgBAKQAAAIgHAEIgGABQgDAAgFgDg");
	this.shape_16.setTransform(133.5,64.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F8DC9B").s().p("AAAAGQgHgEACgEQABgFAEABQAEACACAHQAAABAAABQAAAAAAABQAAAAgBABQAAAAgBAAIgEgBg");
	this.shape_17.setTransform(-33.2,135.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E6BA7F").s().p("AgHAGQgDgEACgHQACgEAGAAQAGABADAIQACAIgHABIgEABQgEAAgDgEg");
	this.shape_18.setTransform(-33,135.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#924B30").s().p("AgHAKQgHgFABgDQAEgDABgFQACgIAJACQAMACgBAKQAAAIgHAEIgGABQgDAAgFgDg");
	this.shape_19.setTransform(-33,135.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#F8DC9B").s().p("AACALQgOgJgDgCQgDgDAQgIQAHgFAHADQAHADgGAKIgBAMQAAABAAAAQAAABAAABQAAAAgBAAQAAAAgBAAQgCAAgGgEg");
	this.shape_20.setTransform(-81.6,130);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#E6BA7F").s().p("AAAAZQgNgNgFgMQgGgPAQgJQAQgKAJAPQAIAOgHAQIgEAOQgCAEgDAAQgEAAgFgEg");
	this.shape_21.setTransform(-81.5,130.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#924B30").s().p("AgJAcQgPgMgDgQQgEgTARgJQARgKAQATQARATgNALQgJAIgIAMQgDACgDAAQgDAAgGgFg");
	this.shape_22.setTransform(-80.9,130.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F8DC9B").s().p("AgDAPQgOgDAGgNQAFgQAJAEQANAFgCADIgJAFIgEAKQgBAFgCAAIgBAAg");
	this.shape_23.setTransform(70.9,104.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#E6BA7F").s().p("AgJAaQgUgDAIgaQAIgcAOAIQASAJAEAGQAEAIgLAIQgSASgGAAIgBAAg");
	this.shape_24.setTransform(71.2,104.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#924B30").s().p("AgWAWQgPgOANgUQAMgWAPAIQALAGANAEQAHAEgEAMQgGAQgQAJQgHAEgFAAQgJAAgJgHg");
	this.shape_25.setTransform(71,104.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F8DC9B").s().p("AAAALQgOgFADgLQADgJAIADQAHACAEAPQADAHgGAAIgIgCg");
	this.shape_26.setTransform(146.2,-12.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#E6BA7F").s().p("AgNAMQgGgJAEgNQACgJANACQAMACAEAPQAEAOgNADIgHABQgJAAgEgGg");
	this.shape_27.setTransform(146.5,-12);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#924B30").s().p("AgOASQgMgIACgGIAIgQQADgOATAEQAUADAAASQgBARgNAGQgFACgFAAQgGAAgKgGg");
	this.shape_28.setTransform(146.6,-11.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F8DC9B").s().p("AAEARQgXgOgEgDQgGgFAZgNQAMgHALAEQALAFgJAQIgBATQgBAFgDAAQgEAAgIgHg");
	this.shape_29.setTransform(133.8,-4.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#E6BA7F").s().p("AAAAmQgWgTgHgTQgKgXAagPQAZgQAOAXQANAWgMAaQgDAQgDAHQgCAFgFAAQgFAAgJgHg");
	this.shape_30.setTransform(134,-3.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#924B30").s().p("AgPArQgWgSgFgZQgGgdAagPQAagQAaAdQAZAegUASQgTAZgHAFQgEAEgFAAQgFAAgKgIg");
	this.shape_31.setTransform(134.9,-3.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F8DC9B").s().p("AgMAcQgCgTALgXQAIgZAGANQAGANgOAZQgJATgEAAQAAAAAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBg");
	this.shape_32.setTransform(56.1,114.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#E6BA7F").s().p("AgnAxQgFgdAegsQAdgvATAPQAPAKgUAQQgXARAEAIQAHANgZAiQgOASgIAAQgGAAgDgLg");
	this.shape_33.setTransform(58.3,112.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#924B30").s().p("AgoAxQgFgdAegsQAdgvATAPQAPALgNATQgPAWADAFQAHAQggAdQgRAPgKAAQgIAAgDgMg");
	this.shape_34.setTransform(58.4,112.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F8DC9B").s().p("AgBARQgPgFACgNQACgRAOABQAQACgEAYQgBAJgIAAIgGgBg");
	this.shape_35.setTransform(-61.6,132.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#E6BA7F").s().p("AgcgMQADgWAdAHQAeAIgEAZQgBAHgLAHQgMAIgJABIgEABQgcAAAHgqg");
	this.shape_36.setTransform(-60.8,133.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#924B30").s().p("AgWAcQgUgMAEgJQAJgMADgOQAFgWAeAFQAgAGgBAbQgBAbgUAKQgHAEgIAAQgLAAgPgKg");
	this.shape_37.setTransform(-61.3,133.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#F8DC9B").s().p("AAAARQgWgJAFgRQADgNANADQAMAEAHAXQADAMgKAAQgEAAgHgDg");
	this.shape_38.setTransform(-93,122.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#E6BA7F").s().p("AgVASQgJgNAGgWQAEgNAUADQATACAHAZQAGAWgUAEQgIACgEAAQgOAAgHgKg");
	this.shape_39.setTransform(-92.7,123.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#924B30").s().p("AgXAcQgTgMADgJQAKgMADgOQAFgWAeAFQAgAGgBAbQgBAbgUAKQgIAEgIAAQgLAAgPgKg");
	this.shape_40.setTransform(-92.4,123.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F6CDCE").s().p("AgJA0IgKgMQgcgpAnglQAMgNAPgFQAOgEgBAJQgEAtgGAaQgIAmgNAAQgEAAgGgGg");
	this.shape_41.setTransform(-13.2,-2.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#D74F32").s().p("AACAvQgRgIgngFQgfgJgGgcIgGgRQgbgoAzgDIBUAFQAwACAZARQAhAWgNApQgMAngfABIgBAAQgSAAgogRg");
	this.shape_42.setTransform(-9.1,-13.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#F6CDCE").s().p("AglAkQgLgQAGgMQAQgfACgGQADgJADgDIA6AIQAHARgDALQgEAMgSgCQgZgEgQAbIgIANIgCABQgEAAgEgGg");
	this.shape_43.setTransform(-4.3,-16.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#D74F32").s().p("AgWgTIADgEQAIgWALARIAOAeQAKAUgBAPg");
	this.shape_44.setTransform(-22.5,-8.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#F6CDCE").s().p("AgMAdIgNgUQgMgLASgTQASgSAQANQASAOgDAPQgCARgVAJQgHAEgFgBQgFAAgCgDg");
	this.shape_45.setTransform(-5.5,-5.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#F6CDCE").s().p("AgiATQgNgTAWgWQAWgVAPAPQAUAPAFAFQAHAHgJALQgOATgUAFIgJABQgQAAgKgQg");
	this.shape_46.setTransform(-13.3,-18.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F6CDCE").s().p("AgIAdIgdgjQgBgLAFgGQAGgHAMABQAjADAOARQAOARghASQgJAEgGAAIgIgBg");
	this.shape_47.setTransform(-19.7,-8.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#B22632").s().p("AicghQAcgzA0gmIAYgOIDBAdIAEAGQAYAggYA7QgYA5g2AmQgxAigkASg");
	this.shape_48.setTransform(-10.3,-8.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FCDE49").s().p("Ag2BNQgHgEgEghQgEggAEgLQABgEATAAQAUABACgDQAFgGgDgNQgCgOAEgGQADgEgHgKQgHgMAAgEIBTANIgHAUQgDANAFAKIARAOQAKANgdAFQgXAFgjAlQgaAbgLAAIgFgCg");
	this.shape_49.setTransform(85.9,0.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FCDE49").s().p("AgUAnQgOgDAAgIQABgLgKgHQgNgJAIgDQAEgCAHgBQgBgMAIgMQALgQAVAHQATAHAIgEQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAABQAGASAFAGQACACgKAKQgHAHANgDQAOgEgEAHIgFALQgSANgUAFQgIACgHAAQgHAAgGgCg");
	this.shape_50.setTransform(33.7,31.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#EB9546").s().p("AAFAdQgFgFgEgNQgCgGgUgFQgQgFAGgGIAagNQAFgQAPAKQAQAKACATQABACAJAWQAEAIgOADIgHABQgKAAgGgGg");
	this.shape_51.setTransform(65.5,30);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FCDE49").s().p("AAEAaQg6gbgGglIBvARQgEAUAFAEQAIAHAAAFQACAYgTAAQgOAAgZgNg");
	this.shape_52.setTransform(-20.7,-20);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#D17530").s().p("AgTAQQgNgHAAgJIAEgRIA9AKQgNANgQAHQgHAFgHAAQgFAAgEgCg");
	this.shape_53.setTransform(57.7,-9.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#7F9D31").s().p("AAbBNIgGgUQgBAAAAAAQAAAAAAABQgBAAAAABQgBABgBABQAAABAAABQgBABAAABQgBAAAAAAQAAAAAAgBIABgIIABgJQgGgPgCABQgCAAgIAQQgJAOgDgDQgBgBAHgIQAHgJAAgFQABgBgGACQgHABAAgBQAAgDALgCQAJgDAAgDQABgCgFgLIgGgOIgeASQgeATgCgDQAAgBgBgBQAAAAAAgBQAAAAAAgBQABAAAAAAQASgCApgeQgDgHgGgBQgHgIgCABQgCAAgBAFIgCAEQgCgBACgHQABgGgDAAQgDAAgHAGQgHAGgCABQgCAAAFgFQAEgEgCAAIgVAEQgNACgBgDQAAgCAOgCIAUgDQACAAgHgCQgHgDABAAIAIAAQAEABAAgCQAAgDgEgCQgIgCgBgBIAGAAQAGABAAgBIgUgPQgLgJADgCQACgBAJAKQAMAKAFACQAAABgBgHIgBgGQABAAADAIIAFAHQAEgCgDgPQgEgPACAAQABAAAGAfQAAACAEgJQADgKAAACIgBALQgBAIAAACQACADAFgDQAEgEACACQABACgEADQgDADAAABQAAAGAGAGQAFAGAIABQAEABgBgaQgCgIAAgDIACAAQAAABABAAQABAAAAAAQABgBAAAAQAAAAAAAAIAAgRQgBgIADgBQADgBgBAGIgBAPQAAAAAAAAQABABAAAAQABAAABAAQAAAAACgBQABAAAAAAQABAAABAAQAAAAAAAAQAAABAAAAQAAADgHAJQAAAGADACQAEABAFgDQALgHADgZQAEgWACAAQABABgDAVQAAAAAAAAQAAAAABAAQAAAAABAAQABAAABgBQAAAAABAAQABgBAAAAQABAAAAAAQAAAAAAAAQgBADgGAJQgCAEACACQAAABAAAAQAAABAAAAQABAAAAAAQAAAAABAAQAEABAQgPQARgNAAABQABABgRAOQgPAOACADQAAABAFgBIAIgCQAAAAAAAAQABAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQASABgBAGQgRgFgOACQgPADgFAJIgLAFQgKAEADABIAVgCQASgCADACQAEACgGADIgGACIAQAFQAJAAgBABQAAACgMgCIgYgDQgBAAAAAAQAAAAAAAAQgBABAAAAQAAAAAAABIgCAAIgEgBIgFgEQgPgDgEAIQgBABAFAKQAEAKADABQABAAAEgGQAFgGABACQACABgFAGQgFAGACABQACABAMgCIAMgCQACABgJADQgIACABABIASAIQALAEAAACQAAABgPgGQgOgGgDAAQgBAAAIAIQAIAHgBAAQgFgCgKgIQgHgGAAABIAEAQQABADAGAGIAFAGQAAACgFgFQgGgFABABIAEARQADAIAAACIgBABQgBAAgCgIg");
	this.shape_54.setTransform(62.8,7.2);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#9BBE33").s().p("AAdBdIgGgKQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQgBgBgBgEIgCgHIgCgCIgDgCIgEgIIAAgEQgBAGgDACIgJAGQgEADgDgCQgLgIAGgHQABgCgBgDIgBgGQAHgJACgEQACgFABgIIACgJIgZARQgaASgGgDQgEgCABgEQAAAAAAgBQABgBAAAAQAAAAABAAQAAgBAAAAQAPgBAngaQgTgEgPACQgDABgGgBQgFAAgEAAQgDAAgDgBQgDgEgCABQgEAAgDgDQgDgDAAgEQgBgCABgDQACgCADgBIAHgDQADgCACABQAIABAAgGQgJgIgFgKIgFgGQgEgEAAgCIAAgFQAAgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAIAEABIAIADQADAAAEAEQAFAFAEAAQAFABAAgRQAAgFAIgBQAEAAAHAGQAFABACAEIADAHQACACABAHQABAHACACQAIAKADANQgDgOABgPQAAAAAAAAQAAgBAAAAQABAAAAAAQAAgBABAAIACgCQAAgBgBgEIgCgGIADgCIACgDIABgHIACgEQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAABIACAFIAEACIADADIAAAGIAAAGQABAFADACQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAQAAgHABgGQABgBAAAAQAAAAABgBQAAAAABAAQAAgBABAAIADgDQABgEgCgKQACgHADgFQADgEABABQADAAADAJQABACgBAIQAAACAFADQACAEAAAFIADgEIAJgIQADgBAGABIAIgDQAEgBACACQABACgDAEIgGAHQgBAGgDADIgJAIIAHAFIAKAEQADACgBAIQAAAAAAABQgBAAAAABQgBAAAAAAQgBABgBAAIgIAAIgCACQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgHgCIgHgDIgLAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAAAIAGADIAMAFQADACABAHIAIAGQADADAAADQgBACgEgBIgLgBIgDACQAAABAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQgLgFgFgBIgDABIgEACQgHgBgJgDIgGgDIAZAOQABABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQABABAAAAQADACANAFIABAEIAAADIAHAHIAFAGQAAADgFgBIgNAAIgCACIgCACIgEACQgBABAAAAQgBAAAAAAQAAABAAAAQAAAAAAABIADAKQAAABAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABQAAABAAAAQABABAAAAQAAAAgBABQAAACgFAEIAAAGIAAABIgCgCg");
	this.shape_55.setTransform(63,7.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#7F9D31").s().p("AAFAeQgHgIgFgCQgBAAABAIQACAHgCAAQgCgBgCgLQgCgLgDAAQgDgBgRAIIgCgCQAOgEACgFQABgBgGgFQgGgCABgBQACgCAGADQAGAFABgCQABgCgCgJIgCgNQABgBADAIQACAIABgBIAIgSQAFgLAAABQABAAgEAOQgHAPAAACQAAACAIgIIAFgHQgBAEgHAKQgHAGACgBIANgCIAJgGIAHgFQACAAgFAFQgFAFABAAQAFAAALgEQAJgCACAAQADABgKACIgUAEQAAABAAAAQAAAAAAABQAAAAABABQABAAACAAQABABABABQAAAAABAAQAAABAAAAQAAAAAAAAQgCABgHgCIgJgBQgNAEABACQABADANAKQANAKgDADIAAAAQgBAAgHgGg");
	this.shape_56.setTransform(5.9,21.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#7F9D31").s().p("AgGASIgBgbQACgEADAHIACAGQAFgZACABQACABgIAhIACACIABACQAAABgDADIgBAFIgBACg");
	this.shape_57.setTransform(0.9,19);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#7F9D31").s().p("AgEAFIAAgDIACgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAgQAFABQgFAOABAPg");
	this.shape_58.setTransform(-2,16.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#9BBE33").s().p("AACArQgCgCgBACIgGAAQgJgHgEgCIgIgDIgRgVQAEgKAKgNQAAAAAAgBQABAAAAAAQAAAAAAAAQABgBAAABQAAAAABAAQAAAAAAAAQAAgBABAAQAAAAAAAAIAIgQQAAgBABAAQAAAAAAAAQABAAAAAAQABAAABAAIADAAIAHgHQAEgEABAAQAEgCgDATQAAADAEABIACAFQAAABAAAAQAAABABAAQAAAAAAAAQABAAAAAAQAGgDAFAAQAAAAAAAAQABAAAAAAQABABAAAAQAAAAABABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABgBAAAAIAEgBQADAAADAFQACABAFgBQAAAAAAAAQABABgBAAQAAAAAAABQgBAAgBABIgKAFQgBAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAAAQgDACgJABQgCACgCAEQgGADgGABIADABQADABABAEIAGAJQADAEgCADQgGAHgFAAQgCAAgCgCg");
	this.shape_59.setTransform(6.1,21.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#9BBE33").s().p("AgbgTIAFgHQACgIACgCQACgCAIABQABAAAAAAQABAAAAABQABAAAAABQAAABAAABIAAAHIACADIACACQAAAEgFAKIgBAIQAAABABABQAAABAAAAQAAAAAAAAQABAAAAAAQADgIADgHQAAgBABAAQAAAAABgBQAAAAABAAQABAAAAAAIAEgCIAIgIQAEgDADAAQACABgBAFIgCAKIADADQAAABABAAQAAAAABABQAAAAAAAAQAAABAAAAQAAAEgGAKIABAEQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgBALgFALg");
	this.shape_60.setTransform(-0.3,18.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#F6CDCE").s().p("AgqgNQALgwARgMQASgOAVApQAUAmgCAeQgCAkgLAUg");
	this.shape_61.setTransform(26,49.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#B22632").s().p("AhWhLIAIgDQAKgDAZgNQAVgLALgCQAXgDAdAUQAEACAFALQAFALADADQAEADAKAFQAHAEACAGQAOAngXA/QgDAIgDARIgGAag");
	this.shape_62.setTransform(24.5,48);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#A78F72").s().p("AglA2QgWgEAyg6QAwg9AFAWQAGAWghAoQgdAngVAAIgEAAg");
	this.shape_63.setTransform(38.6,18.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#E6CBAB").s().p("AhlDPQgRgEgUgTQgagagJgkQgahpCFiPQBLhRBVgCQAhgBAXAMQAWAMADASQANA0grAjQgNALgSAIIgPAFQgKAAgJgDQgRgHALgOQAFgFAogPQAcgLgQgUQgVgagsAXQgrAWgGAmQgBAKA+AtQBBAsADAOQAGAXghAqQghAqgXgEQgQgCgvg0QgugzgHABQgPADgQA5QgRA7AUALQASALAHgMQAHgUAHgNQAKgQAGAIQADADABAHIABAPQAAARgGANQgMAfgkAAQgMAAgOgEg");
	this.shape_64.setTransform(28.4,9.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#64544B").s().p("AhnDPQgNgFgRgSQgagagKgjQgehrCDiOQBLhRBVgCQAhgBAXAMQAWAMADASQANA0grAjQgNALgSAIIgPAFQgKAAgJgDQgRgHALgOQAHgHAggLQAbgJgDgNQAAgBgUAJQgWAKgSAMQg1AjAdAUQAaASgmA2QglA4gTgWQgMgNgOAvQgQA2APgZQAKgQAGAIQADADABAHIABAPQAAARgGANQgMAfgkAAQgMAAgOgEg");
	this.shape_65.setTransform(28.6,9.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#704735").s().p("AhfDVQgMgDgVgRQgXgSgNgSQgegrASg7QAVhIBfhnQBPhWBJgIQBEgIAUA7QAOA0grAjQgNALgSAIIgPAGQgPgEgNgGQgagNALgNQAHgJAvgGQAkgFgQgTQgSgXgsAkQgqAjgBAUQAAAPggArQgjApgMACQgOACgQA6QgRA7ATALQARAJACgUQADghAFgJQAKgQAMARQAHAIAEAMIAAAOQAAARgFANQgMAfgkAAQgMAAgOgDg");
	this.shape_66.setTransform(29.4,10.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#EFDC69").s().p("AAyAWQiJhAgOADQgHABABAeQABAbgPACQgSACgUgGIgSgHQgRgFAPgKQAXgRABgLQgBgYAFgTIFSCXQAAABAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgTAAhzg3g");
	this.shape_67.setTransform(35.5,-9.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#A09434").s().p("AgtAvIgSgHQgTgGAGgWQADgMAJgZIgBgZICPAVIgDAJQgIARgLAGQgMAKgWAFQgGABgFAPQgFAPgNACIgJAAQgOAAgPgEg");
	this.shape_68.setTransform(24.1,-12.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#EFDC69").s().p("AgaBMIgNgJQgMgGAKgMQAPgTAAgMQgDgwALgbQAMgdAXAEQAPAJAJATQAKAWgHAXQgEANgGAEIgXAGQgFACADAhQACAhgLABIgCAAQgLAAgNgHg");
	this.shape_69.setTransform(53.2,19.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#A09434").s().p("AgeBVIgNgJQgPgIAEgYQAGgdAAgOQgJhYAWgEQANgCAjAUQAcAEAKAeQAJAagIAbQgFASgHAJQgIALgPAEQgFABgDARQgCAQgJACIgEAAQgLAAgNgHg");
	this.shape_70.setTransform(53.6,18.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#EFDC69").s().p("AAeAoQgDgCgEAAIg/hQIA8AKQAQAYAEAcQADAXgHAAQgCAAgEgDg");
	this.shape_71.setTransform(-32.7,-21.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#C29E30").s().p("AAMAoQgDgCgDABIhAhRIB0ASQAFAZgTAZQgNARgLAAQgEAAgEgDg");
	this.shape_72.setTransform(-30.8,-21.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#C9623B","#F1A328"],[0,1],0.7,-21.4,-0.4,13.1).s().p("AhdBOQgxgxgKgzQgKg4AwgKQAJgEA+gNQAdgHAEgRICFAUQAaAqAFAkQAGApgZAoQgyBQhFAAQg4AAg1g0g");
	this.shape_73.setTransform(5.9,-6.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#C9623B","#F1A328"],[0,1],-7.4,2.3,15.7,-13.8).s().p("AACA4QgfgGgogiQgpgigPgmID6AmQgTAfgkAXQggAVgaAAIgKgBg");
	this.shape_74.setTransform(69.4,-5.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#C9623B","#F1A328"],[0,1],-14.6,6.8,12.4,-12).s().p("AhlB8QgQg1gTgaQgPgVAEgHQADgEAPgEQAegIgdgsQgUggAjgfQAhgcA5gMQA7gMAuAQQA1ASAMAzQAMA3gvAwQgaAbhCAqIgpAfQgeAVgOABIgDAAQgZAAgIgcg");
	this.shape_75.setTransform(52.5,38.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F9C21E").s().p("Aqim0IU/DIQAJAugFAgQgHAqgeAkQgQAUhrAJQhmAKgNAYQgKARAkBTQAlBVgIAaQgaBfgkArQgoAxhYAdQgTAGhcgrQhbgqgVAKQgMAGgDAdQgCAQABAtg");
	this.shape_76.setTransform(30.6,18.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#C26A33").s().p("AqtnFIVbDNQABCHg+BKQgRAUhagNQhYgOgNAaQgKAUAgBKQAgBQgHAcQgbBdg+A/Qg+BCheAfQgUAGg8gNQg6gLgVAKQgPAHgFAUg");
	this.shape_77.setTransform(31.7,20);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F8DC9B").s().p("ArFnzIWLDTQgMBchBBPQg2BAggA5QglBEgaBaQggB0hqBRQhGA2iiBLIgXAMg");
	this.shape_78.setTransform(34.1,24.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F2CF9E").s().p("ArcoJIW5DaQgNBZg6BbQg5BWgbArQguBNgYBWQgfBuh4BTQghAXhQAvQhPAugqAdIgVAQg");
	this.shape_79.setTransform(36.4,26.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#E6BA7F").s().p("ArlopIXLDdQgPBWghBpQgPAvg+BbQg9BXgVBKQghB0h4BrQg2Avi3B+g");
	this.shape_80.setTransform(37.3,30);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#924B30").s().p("ArzpCIXmDhQgJArgSA6IgfBiQgPAwg1BfQgyBagVBNQgjB4h1B0QhLBKihBxg");
	this.shape_81.setTransform(38.7,32.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#C7C8C9").s().p("Ar/pPIX/DlQgKAwgUBBIgiBuQgPAwg0BdQgzBcgVBMQgiB5h1BzQhLBKigBwg");
	this.shape_82.setTransform(40,33.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#F1F1F2").s().p("AsNpeIYbDpQgKA2gVBJIgnB7QgPAxg0BdQgyBcgWBMQgiB4hzByQhMBLifBwg");
	this.shape_83.setTransform(41.3,35.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#F6CDCE").s().p("AgcABQAHgHAUAHQANAIABgLQAAgJAGAFQAFAFAFAKg");
	this.shape_84.setTransform(-3.2,-21);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FCDE49").s().p("AgOBBQACgMgJgJQgKgKgKACQgLABgMgKQgPgOAPgUIAcghIAZgeQAPgLAgAbQAlAggBAlQAAAggYAbg");
	this.shape_85.setTransform(56.3,-18.3);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#7F9D31").s().p("AgiBAIABgSQgBgCgFALIgFAIQAAgEAFgNIADgIIgOAIQgCACgEAIQgEAHgBAAQgBAAADgGQADgHgBAAQgGADgIAGQgIAGgBAAQgEAAAJgGIARgLQAAgBAAAAQAAAAgBAAQAAgBgBAAQgBAAgBAAQgCgBgBAAQgBAAAAAAQgBAAAAgBQAAAAABAAIAIgCQAIAAABgBQANgJgCgCQgBgCgSgFQgQgFACgEQABgBAJAEQALAFAFAAQACAAgEgHQgEgGACgBQACAAAGAKQAFAJADAAQAFAAASgUIgbgVQgagXACgDIAEgBQAHAQArAcQAFgDAAgGIACgFQABgEgBgBQAAgCgEAAQgCAAAAAAQgBAAgBAAQAAAAAAgBQgBAAABAAQAAgCAHAAQAEgBAAgDQgBgCgGgFQgIgFgCgCQAAgCAGADQAGADgBgBIgKgTQgGgMACgCQACgBAGANIAJATQAAABAAgHIAAgHIACAIQAAAFADgBQACgBAAgFQAAgHABgCIACAFQABAHABgBIAIgXQAGgOACADQABABgGAMQgGAOgBAFQAAABAFgDQAFgEABABQAAACgGAFIgGAGQAEAEANgIQANgIABACQAAACgcAOIAIABQAKAAgBABQgCACgJABIgLACQgCACAFAEQAFADgCACQAAAAgBAAQAAABgBgBQAAAAgBAAQgBgBAAAAQgFgDgBAAQgGADgDAHQgDAHABAFQABAHAXgJIAJgFQAAAAAAAAQAAAAAAAAQABABAAAAQAAABAAAAIABADIARgEQAHgCACACQACABgHABIgOADQgBAAAAAAQAAAAAAABQAAAAABABQAAABABABQAAABABABQAAABAAAAQAAABAAAAQAAAAAAABQgBAAgGgCIgIgCQgGABAAAEQAAAEAFAEQAJAIAagDQAWgEAAACQgBACgHABIgOACIACADQABABAAAAQAAABABAAQAAAAAAAAQAAABAAAAQgDAAgLgEQgEAAgCACQAAAAgBAAQAAABAAAAQAAABAAAAQAAABAAAAQABADATANQARALgBABIgSgLQgSgLgDADQgBABADAEIAEAHQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAABQAFARgGABQAAgSgGgNQgHgNgKgDIgJgJQgHgHABACQAAACAHASQAHAQAAAEQgBAFgEgGIgFgFIABARQAAAJgBgBQgCAAgBgLIgDgZQgBgBgBAAQAAAAAAAAQAAAAAAgBQAAAAAAAAQgBgCABgDIABgGQgBgOgIgCQgCgBgJAIQgIAHAAADQAAACAHACQAHACgBABQgBADgHgDQgHgDAAADIAFALQAGALgBABQAAACgFgHIgFgGIgDATQgBAMgBAAQgCAAACgPg");
	this.shape_86.setTransform(-43.8,40.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#9BBE33").s().p("AgnBUIgDgMQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAgBAAIgCgBIgEgEQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQgFAFgEACQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgCABgFgEIgGACQgBAAAAAAQgBAAABgBQAAAAAAgBQABAAABgBIAIgIIAAgEQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAHgEADgDIACgDIABgEQACgDAFgCIADgCIgDAAQgEAAgCgDQgCgDgGgEQgEgDABgDQADgNAJADQADABACgCQADgCADAAIAHACIAIACQAFABAIgCIAJgBIgYgQQgYgUABgHQABgEAEAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQAFAOAlAcIgCgMQgBgLgGgIQgBgDAAgGQAAgFgDgDQgCgDADgEQACgEgBgCQgDgHAJgGQACgBADABQAEAAABADIAEAGIAEAFQAAAIAFgCQAEgMAIgHQACgBADgGQACgEADgBIAEgCQABAAAAAAQAAgBABABQAAAAAAAAQABAAAAAAIAAAFQgBAFABAEQABACgDAGQgCAFAAAEQAAAFARgFQAEgCADAIQABACgBAEIgBAHQAAAFgDADIgGAEQgCADgGADQgGADgCACQgGAKgLAEQANgEAMgDQAAAAABAAQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAAAQABAAAAAAIAFgDIAFgDQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAABIAEACIAHAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABIgEACQgCACgCAGQgBABgEABIgGABQgEADgCADQgBABAAABQAAAAAAABQAAAAAAABQAAAAAAAAIAFAAIAJgCIAEACIAEACIAGgCIAGgCQAHgBAGACQAFABAAACQAAACgHAGQgDACgHABQgCABgCAFQgDAEgFABIAFACQAGADAEAEQACACABAFIAGAIQACADgCACQgBACgFgCIgIgDQgCgBgDAAIgFAAQgFgDgGgFIgDAKIAAAKQgCADgHABQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAgBAAAAIgDgIQAAAAgBAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgDgCIABgOQgBgHgCgDQAAgBgBgBQAAgBAAAAQgBAAAAgBQgBAAAAABIAAAHIgCAMQAAAAAAABQgBAAAAABQgBAAAAAAQgBABAAAAQgBABgBAAQAAAAgBABQAAAAgBAAQAAABAAAAIgEAKQgDAEgDABQgCAAgBgFIgCgKQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAAAIABgRQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAAAgBIgDgDIgBgQIABgHIgGAdQgBAAAAABQAAAAAAAAQAAABgBAAQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAQgBAEgBAOQgBACgGACIgEAIIgFAGIgBAAQgBAAgBgEg");
	this.shape_87.setTransform(-43.7,40.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#7F9D31").s().p("AADBCIgCgVQgBgBAAAHQgCAGgBgBIABgHQABgFgDAAQgDgBgBAGQgCAGgCACQgBABABgHQABgGgBAAIgPAUQgKALgBgEQgBgBAKgKQALgLACgFIgGABQgGACAAgBQAAgCAHgDIAIgEQgCgFgQAEQgOADAAgCQAAgBANgCIASgDQACAAgJgEQgKgDACgBQACAAAJACQAIACACgBQADgCgDgEQgDgGACgBQAAAAABAAQAAAAAAABQABAAABABQAAAAABABQADAEABAAQAEAAAGgGQAHgGABgHQABgDgYgBQgCAAgJACQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAgBIAAgEIgRAAQgIAAgBgDQgBgCAGAAIAPACQAAAAAAAAQABgBAAAAQAAgBAAgBQgBAAAAgCQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAABAAQABAAAFAEQAFAEABAAQAGABACgEQABgDgDgGQgGgLgagEQgWgEABgCQAAgBAIABIAOACQAAABAAgBQAAAAAAAAQAAgBAAAAQAAgBgBgBQAAgBgBgBQAAAAAAgBQAAAAAAAAQAAgBAAAAIAGAEIAGAEQAIADAAgFQABgEgOgRQgNgQABgBIAOAQQAOARADgCIgCgLIAIAKQACAPAHAGIAFALQAEAJABgCIgBgOIAGAHQgCANAHAEQACAAAFgBIACABIgIADIASAfQASAegDACQgBAAgBABQAAAAgBAAQAAAAgBAAQAAgBAAAAQgBgMgQgZQgPgYgBABQgHADgBAGIgEAEQgEADABABQAAACAFACIAEACQgCABgGgBQgGgBAAADQgBACAGAHQAHAIAAACQABACgFgFQgFgFAAACIAEAVQACAOgDAAIAAABQgCAAgCgOg");
	this.shape_88.setTransform(-1.1,23.3);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#9BBE33").s().p("AAGBXQgCgCgBgDIgCgHQgBgEAAgCQABgEgBgCIgEgBIgFAFQgGAFgGADIgHAFQgEAEgCAAIgFAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAgBABgBIACgIQABgCAEgEQAEgFABgDQABgGgRAAQgFAAAAgIQgBgCADgEIADgGQABgEAFgCIAHgDQACgCAHAAQAGgBADgCQAJgHAMgDQgLACgQgBIgCgCQAAgBAAAAQAAAAgBgBQAAAAAAAAQgBAAAAAAQgBgBgEACIgFABQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAgBIgDgCQgKgBgBgCQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAABgBIAFgCQADgGADgBQAJABADgBQAEgBADgCQABgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAIgNgCIgDgDQgBgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAgBIgHABIgHAAQgHgCgFgDQgEgDABgCQACgDAHgCIAKAAIADgCIADgDIAJgCQgIgFgEgIQAAAAAAAAQAAgBgBAAQAAgBAAAAQAAgBABgBIAAgEIgDgJQgBgEACgBQADgBAKAJQADACAFACIAIAKIABAAIA+BPIgNgDIARAZQAQAbgDAGQgDAGgFgGQgBgJgMgYQgNgYAAADIgDANQgCALACAJQABAEgBAFQgCAGABADQABADgEADQgDADAAADQAAAEgDADQgDACgEABIgBAAIgEgBg");
	this.shape_89.setTransform(-1.6,23.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#F6CDCE").s().p("AgKA3QgWgHgFgkQgEgdAIgoIBJBbQgNAYgWAAQgGAAgJgDg");
	this.shape_90.setTransform(25,53.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#F6CDCE").s().p("AgiATQgNgTAWgWQAWgVAPAPQALAKAOAKQAHAHgJAMQgOASgUAFIgJABQgQAAgKgQg");
	this.shape_91.setTransform(13.9,57.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#F6CDCE").s().p("AglAKQgOgMgFgOQgFgPAJABIBPAIQA3AMgoAcQgTANgSAAQgVAAgVgVg");
	this.shape_92.setTransform(13.8,48.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#D74F32").s().p("AAaBJQgWgCgSgOIgugeQgNgNAKgWQAKgWgFgFIgGAAQgEgLAQgMQANgKANgDQAcgGAPAgIAUAXQANAPgEAKQgDAMAEAGQAGAJABAEQACANAMAQQgOAKgTAAIgJAAg");
	this.shape_93.setTransform(4.7,61.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#F6CDCE").s().p("AghAFQgHgNAEgKQAFgMAQABQAkADANARQAOARghARQgKAGgHAAQgTAAgMgag");
	this.shape_94.setTransform(11.6,67.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#F6CDCE").s().p("AgqAvQgPg1A3grQASgPARgFQAQgEgEALIgoBgQgQAlgNAAQgLAAgHgYg");
	this.shape_95.setTransform(1,59);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#F6CDCE").s().p("AgMAeQgFgMgIgJQgMgLASgTQASgSAQANQASAOgDAPQgCARgVAJQgHADgGAAQgEAAgCgCg");
	this.shape_96.setTransform(3.3,69.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#B22632").s().p("AhOCoQgTgKgGAAIgnAAQgUgCgLgPQgWgfgBgpQgBgsAZglQAFgJAWgLQAYgNAGgIQAGgHAIgUQAKgVAEgHQAJgMAPgKIAegUQASgMAXgGQAOgDAbgFICUC4QgFAQgJAJQgKALgWANIgmAXQgKAHgPASQgOARgJAGQg4Aog8AIIgCABQgIAAgRgJg");
	this.shape_97.setTransform(10.8,58);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#E6CBAB").s().p("AhFCpQg7gGgGglQgMgtAhgZIAkgQIAQAFQANAHgJAKQgDAEggAJQgVAGANATQAQAYAjgPQAigOAEggQAAgIgxgsQg0grgDgNQgFgTAZggQAZghASAGQANAEAnAxQAkAvAGAAQALgBAMgvQAMgwgPgLQgPgLgFAJQgDAGgIAVQgIAMgEgHIgEgJQgDgUAGgRQAMgiAuASQAOAFAQATQAVAYAIAfQAWBZhmBtQg2A2g6AAIgMAAg");
	this.shape_98.setTransform(-45.6,66.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#64544B").s().p("AhECpQg7gGgGglQgMgtAigZIAkgQIAPAFQAOAHgJAKQgFAGAHgBQAIAAAHgFQAXgPgYgUQgVgSAdgpQAdgsAPAVQAJAMAKgmQAMgsgMAUQgHAMgFgHIgDgJQgDgUAGgRQAMgiAuASQAKAFAOASQAVAZAJAeQAaBbhmBsQg2A2g5AAIgNAAg");
	this.shape_99.setTransform(-45.7,66.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#704735").s().p("AhFCyQg8AAgRg0QgGgaASgMQATgNAQAYQAPAVAigaQAhgZAAgRQAAgMAYghQAbgfAJAAQALgBAMgvQANgwgQgLQgUgPgEgSQgFgTAcAJQAJAEAZAWQAaAXALARQAYAngNAwQgPA5hJBOQg9BAg/AAIgBAAg");
	this.shape_100.setTransform(-44.1,67.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#EFDC69").s().p("AgyARQAPgzAxADQATAHALAQQAMAQgKAWIgBACg");
	this.shape_101.setTransform(25.4,-18.7);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#A09434").s().p("AhJASQAAg4AeAAQASgBAsANQAiACAOAWQALAQgIAZg");
	this.shape_102.setTransform(24.9,-19.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#EFDC69").s().p("AheAzQgIgLADgUIADgTQACgPATADQAcAEANgHQA1ghAkgGQAmgGAIAcQgDAUgRASQgUAXgdAIQgTAFgIgEIgQgTQgDgEglAXQgZAQgLAAQgFAAgCgEg");
	this.shape_103.setTransform(-0.8,39.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#A09434").s().p("AgQBRQgRgCgLgNQgEgEgUAIQgUAIgHgLQgIgLADgUIADgTQACgRAdgLQAlgMAPgIQBDgtAagEIAUAaIgBAUQAAAMACAHQAIAcgdAcQgYAZglAKQgSAFgLAAIgFAAg");
	this.shape_104.setTransform(-0.7,37.7);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#EFDC69").s().p("AgMBQQgHgFADgbQACgYgHgBQgGAAgSAWQgNAQgEgRQgFhJApgiQAigfAjAYQAJAFAIANIg8gJIBABPQgMAAgfAjQgXAcgIAAIgCgBg");
	this.shape_105.setTransform(-36.7,-19.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#C29E30").s().p("AgsBrQgHgFgCgfQgCgbgHgBQgDAAgNAJQgGAEgFgSQgFhTApgoQAsgqBFAoQAZAOAFAYIh0gSIBABQQgNACggAyQgcArgIAAIgBgBg");
	this.shape_106.setTransform(-34.1,-18.6);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#342D2C").s().p("AgOAvQgUgBgKgPQgKgOAGgSQAGgTATgNQATgOATABQAUABAKAOQAKAPgGASQgGATgTANQgTANgRAAIgCAAg");
	this.shape_107.setTransform(-26.9,22.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#427136").s().p("AgVBxQghgEgjglQgegrAGgrQAFguArgeQAsgeAuAMQAvAMAeArQAUAhgLAkQgMAogsAeQgnAbgdAAIgIAAg");
	this.shape_108.setTransform(-26.6,22.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#342D2C").s().p("AgYB9Qg1gIgdgrQgegqALgyQALg0AsgfQAtgfAyAIQA0AIAeAqQAdAqgKAyQgLA0gsAfQgkAZgnAAIgUgBg");
	this.shape_109.setTransform(-26.7,22.5);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#342D2C").s().p("AgOAuQgUAAgKgOQgKgPAGgRQAGgUATgOQATgNATACQAUAAAKAPQAKAOgGARQgGAUgTANQgSANgRAAIgDgBg");
	this.shape_110.setTransform(40.1,-34.5);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#427136").s().p("AgUBxQghgEgjglQgfgrAGgrQAGguArgfQArgeAvANQAuALAfAsQAUAggMAlQgMAogrAeQgoAbgdAAIgHAAg");
	this.shape_111.setTransform(40.3,-34);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#342D2C").s().p("AgYB9Qg1gIgdgqQgegrALgxQALg0AtgfQArgfAzAHQA1AIAdAqQAdArgKAyQgLAzgsAfQgkAZgnAAIgUgBg");
	this.shape_112.setTransform(40.2,-34);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#C9623B","#F1A328"],[0,1],-13.7,11.1,-4.9,-17.6).s().p("AABhBIARAXQAWAcgGANQgSAkgzAfg");
	this.shape_113.setTransform(-59.9,70.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FCDE49").s().p("ArOKIQgkgIgjgbIAIggQAhATAXABQALAAAqAMQAlAKAQgDQAkgGAdgZQAPgNAKgOQAMgVANAAQAOgBAFAJQAEAJgEAOQgHAcgDAGQgHANgSACIgSABQgEgCgEADQgEADgDAAIg3ARQgkAJggAAQgWAAgUgEgAj4JNQgLgIgJACIgTgFQgKgFAAgbQgBgbAMgHIADgBQAGgCAQAAQAUABAFAEQADACADAHIABAFIAAAGQgBAIACAEQACAEAHAFQAJAKgDAIQgCAIgNAIQgFAEgFAAQgFAAgFgEgAkFCdQgEgPgKACIgfAJQgIgEgcgKQgngNgWgCQgFgBgMATQgMASgCgBQgagGACgUQAIgUAAgFQABgEAmAEQAwAEASgCQAVgBAKgLIAJgMQAHgEAeATIAJgLIARgXQAPgTAGgBQADAAgEAXQgFAZABABQAGAGgNAIQgPAIACADQABACAJAAQAJABABACQAIAJgHALQgGAIgQAKQgDADgDAAQgFAAgDgKgAMNlVIhOgLIAAAAIABgDQAMgWAZgBQAVgBATANQANAKgFAQgAmIoEIAAAAQgBgHACgGQASgDBNgJQAVAbgCAHIgCAIIAAAAgAJyp8IgPgJIAlgGQAVAZgBAIQAAABAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAQgHAAgggUg");
	this.shape_114.setTransform(12.4,27.7);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#D17530").s().p("AAhA9IgEgBQgQgFgRAEQgdAFgcgeQgXgZgBgPQAAgTAJgRQALgXAWgBQApAAAeAXQAdAVgDATQAAAFAYAjQAGAIABAGQAEANgRACIgKABQgPAAgOgGg");
	this.shape_115.setTransform(-22.7,50);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#C9623B","#F1A328"],[0,1],0.3,-5,-0.8,29.5).s().p("Ag/AgIAAAAQADgMgFgVQgNg2AkAEQAlAEArA3QASAXANAVIABAAg");
	this.shape_116.setTransform(11.2,-22.5);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#F4B54F").s().p("AhUCNQgTgTgVgNIgZgOQgIgFADgHQADgGASgUQAZgJAYgOQAxgbgBgTQAAgQgegRQgZgOAIgSQATgnBQgkQA/gbAVAvQAHAPAHAjQAIAmAGAQQAIAWARAiQAJAfgVAYQgMANgjAMQgqAOgKAGQgrAdgUAFQgHABgHAAQgaAAgXgWg");
	this.shape_117.setTransform(-25.9,15.4);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#C9623B","#F1A328"],[0,1],-10.9,9.7,10,-4.9).s().p("ABfCGQgRgBgmgHIglgIIgBgFQgCgGgBgCQgGgEgTgBQgQgBgHACQgUgIgUgKQhFgigCgkQgBgYApgBQAnAAgEgVQgNhEABgCQABgOAKgIIAEACQATAHAUgCQARgCgEgNQBGAHAkAsQAYAdAcBRQAHASAVAgQAOAagYAUQgMAKgdAAIgKAAg");
	this.shape_118.setTransform(-11,68.6);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["#C9623B","#F1A328"],[0,1],-10.9,11.4,12.2,-4.7).s().p("AiBBOIAAAAQgLgdAJgUQAOgeATgBQAbgBAOgOQATgSgIgSQgKgVAJgPQAPgZAxAAQA1gBAZAgQAQAUACAeQACAnADALIAPAkQAGAOgHAZQgDALgHAMIgBABg");
	this.shape_119.setTransform(69.8,-19.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#F9C21E").s().p("AqeKdQhTgHhGglIAGgXQAjAbAkAIQAwALA+gPIA4gRQACAAAEgEQAFgCADACIASgBQASgDAHgMQADgGAHgdQAFgOgFgIQgFgJgOAAQgMABgNAUQgKAPgPANQgdAYgkAGQgQADglgKQgqgLgLgBQgXgBghgTIAXhZQA0gfATgnQAGgMgWgcIgSgYIBakxIBmlyIAujDIAGgBIAVAaIAYAeIJ/MgQAAAggBANQgBAXgGALQgtBVglApQg5BBgrgZQgPgHgXAMIgwAgQhIAzg8gIQgVgDgrghQgygmgbgKQgggMgcAOQgLAGg4AuQg3AshXAAIgfgCgAkUJDQAJAGALgGQANgJACgIQADgIgIgKQgIgEgBgFQgCgDAAgIIAAgHIAlAIQAmAHARABQAlACAOgMQAYgUgOgaQgVgggHgSQgdhTgXgdQglgthHgGQgBgGgGgIQgYgkAAgGQACgUgdgVQgfgWgqAAQgVAAgLAXQgJARAAAUQAAAQAYAaQAbAeAegGQATgEAQAFQgKAIgCAOQAAACANBEQAEAVgnAAQgpABABAaQACAkBFAiQATAKAVAIIgDABQgLAIAAAbQAAAaAKAGIATAEIAEAAQAHAAAJAHgAkhCTQAEANAKgGQAQgLAGgIQAIgLgJgJQgBgBgJgBQgJgBgBgCQgBgCAOgIQANgIgGgGQgBgCAFgYQAEgYgCABQgHAAgPATIgRAXIgJALQgegTgHAFIgJAMQgKAKgVACQgSABgwgEQgmgDgBADQABAFgJAVQgCAUAaAGQADAAALgSQAMgSAFAAQAWACAnAOQAcAJAIAEIAfgIIADgBQAIAAADAOgAmKkdQhSAjgSAnQgJASAaAPQAeARAAAPQABAVgxAcQgYANgZAKQgSATgDAHQgDAHAIAFIAZANQAVANATARQAdAdAhgIQAVgFAtgaQAKgGApgOQAkgMALgOQAVgYgIgeQgRglgIgVQgGgQgIgmQgIgjgGgPQgNgegfAAQgRAAgYAKgALxlfIAIABQAFgRgNgJQgSgOgWABQgZABgMAXIgBACIgHgBQAIgMADgMQAGgYgFgOIgPgkQgDgLgCgqQgCgdgQgVQgagfg1AAQgzABgOAZQgJAPAKAVQAHASgSASQgOANgbACQgTABgOAfQgJAVALAdImCg6QgOgVgQgXQgtg5glgEQgkgEANA2QAFAXgCAMIjNgeIACgIQACgHgVgbIDUgXIEwgeIETgeIB0gVIAPAJQApAZABgHQABgJgVgZIAjgGIBegCQAOAZAHAXQAFAPgxAzQgyA0AEAQQACAKA+ATQA9ASABALQACARAHAcIAJAsgAnFoTQAZgFAEgDIAGgBQgDAGACAIg");
	this.shape_120.setTransform(15.2,28.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#C26A33").s().p("AoqpVIABAAIV8ilIApgFIAxgFIAEAAIgEADIgWAXIgWAFIgsAKIgMADIgzAAIg0ACQAXAwAKAgQAFARgbAiQgbAiADAQQACALApAUQApAUACALQAFA0ABAmIgFgBIgXgDIgJgtQgGgbgCgRQgCgLg8gTQg/gSgCgLQgEgQAygzQAxgzgFgQQgHgXgOgYIhdABIgjAGIglAHIh0AVIkUAeIkwAfIjTAWQhNAJgSACIgFACQgEACgaAFIgRADIgjAFIgFAAIguDEIhnF0IhaEvIglCFIgWBaIgJAfIgGAXQBGAlBTAIQBtAJBAg0QA4gtAMgGQAbgPAhAMQAaALAyAmQArAhAVADQA8AIBJg0IAvggQAXgMAPAIQAuAYA3hBQAlgpAthVQAFgKACgXQABgOAAgfIATAYIAHAJIgFAkQgCAYgIAPQglBDgvAuQg5A2g0AEQgQACgYAPIgwAgQhEArhAgJQgVgDgzgrQg4gvgcgLQgbgKghAjQgoAqgVAGQhdAXhcgIQhRgHg+gdIAAACIgQAvIgQA1IgBAEIgIAnIgHAcIgOAGIgSAHIgCABg");
	this.shape_121.setTransform(18.6,34.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#F9E3B0").s().p("AmlKyQg3gVhHgCQgcgBhfAHQhMAFgtgGQgrgGgmgRIAPgvIABgDQA+AeBQAHQBdAIBdgXQAVgGAogqQAggjAcAKQAcALA4AvQAyArAWADQBAAJBEgrIAvggQAZgPAQgCQA0gEA5g2QAvguAkhDQAIgPADgYIAFgkIgIgJIBPBiIAEAFQgdASglAlIg9BAQhLBNg/AFQgVACgrAYQg+AigXAKQhAAbhCAAQg/AAhCgZgAMxl8IAGABQgBgmgGg0QgBgLgpgUQgpgUgCgLQgEgQAcgiQAbgigFgRQgKgggYgxIA1gBQAXAxAKAgQAaBZAIApQAPBIgHA7IAAAAg");
	this.shape_122.setTransform(18,33);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#F2CF9E").s().p("AmzLYQg1gJhNACQgrAAhVAEQh9ABhWgoIAQg0QAmARArAFQAtAHBMgGQBfgGAcABQBHABA3AVQCGAzB9g1QAXgKA+giQArgYAVgBQA/gFBLhNIA9hBQAlgkAdgTIgEgEIAnAwQgsAkhWBbQhRBMhGAFQgoADg2ASQggAJhAAXQhWAchOAAQgkAAgjgGgAN2l/IgfgFQAHg6gPhJQgIgpgahYQgKghgXgwIAzgBIAMgDIAYBTQAYBSAIA0QALBIgJA/g");
	this.shape_123.setTransform(19.6,34.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#E6BA7F").s().p("ArEMHQh3gFhegvIAJgnIABgDQBWAoB9gCQBVgEArAAQBNgCA1AJQBtASB+goQBAgXAggJQA2gSAogDQBGgFBRhMQBWhbAsgkIAzBAIgUANQgxAjhZBIQhQA5hPAGQhIAGiTAiQiPAhhMAEIiHAJQg1AEgqAAIgmgBgANvmFIAPACQAJg/gLhIQgIg0gYhSIgYhSIAsgKQAKA1AMAmQAiB2gZCbIAAAAgANqsHIABABIgpAEg");
	this.shape_124.setTransform(20.3,35.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#924B30").s().p("ArYMaQh/gKhfgpIAOgGIAGgdQBeAvB3AFQA2ADBPgFICHgJQBMgECPghQCTgjBIgFQBPgGBQg5QBZhJAxgiIAUgOIAjAtIAEAEIgWAPQiIBfgMAIQhXAyhWAHQhIAGiYAjQiTAihPAEQh0AGhOAAQgzAAgjgDgAOGmPQAZiagih3QgMgmgKg1IAWgFIAWgXQAHBKAOAsQAiBzgoCkgANhsWIAygGIAAACIgxAFIgBgBg");
	this.shape_125.setTransform(21.2,36.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#C7C8C9").s().p("ArGMpQiYgMhsg6IAAgBIATgIQBfApB/AKQBZAHC+gKQBPgECTgiQCZgjBHgGQBXgHBWgyQANgICIhfIAVgPIgDgEIAZAfIAAAAIgYAQQiGBegOAJQhWAyhXAHQhIAGiYAjQiTAihPAEQhvAGhOAAQg1AAgmgDgAoipNIgVgaIAjgFIARgDIAhAFIAAAAIBxARIAAAAIDMAfIAAAAICHAUIAAAAIGAA5IAAAAID8AmIAAAAIAHABIAAAAIBOALIBHALIAWADIA1AIIAAAAIAgAFIAgAFIAAAAIAcAEQAnikgihzQgNgsgHhKIADgDIgDAAIgBgCIARgCIAAABQAIBhAQA2QARA8AABUQgBBNgPBFg");
	this.shape_126.setTransform(21.4,37.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#F1F1F2").s().p("Aq2M6QiagLhsg7IgZgOIAFgSQBrA7CZALQBaAHC+gKQBPgECTgiQCYgjBIgGQBXgHBWgyQAOgICGhfIAXgQIAZAfIgZARQiJBggMAHQhWAyhXAHQhIAGiYAjQiTAihPAEQhxAGhNAAQg2AAgkgDgAoRo+IgYgeIXeDdQAPhFABhNQAAhVgRg7QgQg2gIhiIAAAAIAUgDIADAjQAHBiAQA2QAPAygDBXQgCBIgMBEg");
	this.shape_127.setTransform(22,39.3);

	this.addChild(this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-96.5,-46.7,245.8,184.3);


(lib.mc_pastel2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A0ZNAQiTifAAgNQAAgUBKoIISOu3IWsMLIDVMKQghA1gjA1g");
	this.shape.setTransform(3.6,37.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#F8E3B5").ss(1,0,0,4).p("AAQLGIgf2L");
	this.shape_1.setTransform(-20,-115.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#232323").ss(1,0,0,4).p("AAQLGIgf2L");
	this.shape_2.setTransform(-19.3,-116.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C26A33").s().p("AzBG+IRSuDIUxLKIglAHIhJgfIi4h7IithQIjziDIkMiXQkLiWgHAAQgGABglgTIglgSIiWCFIkoD3Ik6D4IiqCTIhWBCIgyAvg");
	this.shape_3.setTransform(-6.5,-2.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F6CDCE").s().p("AgVgTQALgDAKATQAGANAIgKQAGgGACAGQABAHgDANg");
	this.shape_4.setTransform(7,-24.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#B22632").s().p("AhHhEQCNAKACB/g");
	this.shape_5.setTransform(4.8,-26.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D74F32").s().p("AgEApQgRgCABgNQAAgIAJgRQAFgGADgRQADgNAOgEIADgCIAFBIQgKALgMAAIgEgBg");
	this.shape_6.setTransform(-18.2,-24.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F6CDCE").s().p("AgKAcQgSgEAAgHIABgWQgCgSAZgFQAXgFAHAVQAIAUgMANQgJAJgNAAIgKgCg");
	this.shape_7.setTransform(-19.1,-17.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B22632").s().p("Ag1ASQADgkAZghQAZgkAogWIAODbQhxgTAGhJg");
	this.shape_8.setTransform(-20.6,-19.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F8DC9B").s().p("AgHAHQgHgPgBgDQgBgGAQADQAKABAEAGQAEAHgKADIgIALIgBACQgDAAgDgJg");
	this.shape_9.setTransform(-143.1,54.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#E6BA7F").s().p("AgRASQgFgSADgMQAEgRARACQAVACgCARQgBAPgQAKQgEACgGAIIgDABQgFAAgDgKg");
	this.shape_10.setTransform(-143.2,54.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#924B30").s().p("AgYATQgFgSAHgOQAIgSARACQAVACADAZQADAXgTADQgLACgMAFIgBAAQgHAAgEgMg");
	this.shape_11.setTransform(-143.3,54.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F8DC9B").s().p("AgPALQAGgLANgIQAPgJgCAJQgCAIgQAIQgKAFgDAAQgBAAAAAAQgBAAAAAAQAAgBAAAAQAAgBABAAg");
	this.shape_12.setTransform(145.6,-57.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E6BA7F").s().p("AgmANQAIgPAfgOQAigNAFAPQADALgQABQgSABgBADQgDALgYAIQgJACgFAAQgKAAAFgKg");
	this.shape_13.setTransform(147.5,-57.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#924B30").s().p("AgmALQAIgPAfgNQAigOAFAPQADALgOAFQgQAFgBAFQgCALgbADIgIAAQgTAAAGgNg");
	this.shape_14.setTransform(147.5,-57.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#F8DC9B").s().p("AgHAHQgGgHAHgGQAGgIAHAGQAIAGgMALQgCADgBAAQgDAAgEgFg");
	this.shape_15.setTransform(147.1,-42.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E6BA7F").s().p("AgKAPQgTgKAVgUQAJgLANAPQANANgMAOQgEAEgHAAQgFAAgJgFg");
	this.shape_16.setTransform(147,-41.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#924B30").s().p("AgBAZQgOgCgHgRQgGgMAFgEIARgKQAJgKAPAPQAPAPgLAMQgKANgLAAIgCAAg");
	this.shape_17.setTransform(146.8,-41.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F8DC9B").s().p("AgSASQgOgPAUgOQATgQAKAPQAMARgGABQgLgBgGACIgMAJQgFAEgDAAQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAg");
	this.shape_18.setTransform(149.5,-72.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#E6BA7F").s().p("AgeAeQgYgVAigaQAhgdAOAZQAPAZgBALQgBAOgXACIgXACIgHAAQgOAAgDgDg");
	this.shape_19.setTransform(149.3,-72.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#924B30").s().p("AgKArQgfgDgHgdQgIgdAkgRQAhgRAOAZQAJAQANAQQAGAMgRAMQgVAOgVAAIgGAAg");
	this.shape_20.setTransform(149.3,-72.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F8DC9B").s().p("AgLALQgJgLAKgKQAKgNAMAKQAMAKgTARQgEAEgCAAQgFAAgFgHg");
	this.shape_21.setTransform(-145.4,-125);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6BA7F").s().p("AgRAZQgdgQAhggQAOgQAUAXQAUAWgTAUQgEAFgNAAQgMgBgKgFg");
	this.shape_22.setTransform(-145.5,-124.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#924B30").s().p("AgDAmQgWgDgLgaQgIgUAIgFQAPgGALgKQAOgPAXAXQAYAXgRAUQgPAUgSAAIgEgBg");
	this.shape_23.setTransform(-145.8,-123.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F8DC9B").s().p("AgIAMQgOgSAQgNQAIgJAIAKQAKALgJAXQgDAIgEAAQgEAAgIgMg");
	this.shape_24.setTransform(-148.9,41.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#E6BA7F").s().p("AgCAeQgYgKAAgRQABgOASgQQAJgIAPANQAQAOgJAXQgGAQgOAAIgGgBg");
	this.shape_25.setTransform(-149,42);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#924B30").s().p("AgDAmQgWgDgLgaQgIgUAIgFQAPgGALgKQAOgPAXAXQAYAXgRAUQgPAUgSAAIgEgBg");
	this.shape_26.setTransform(-148.6,42.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F6CDCE").s().p("AguAeIgCgQQACgxA0gHQATgDAOAFQAOAEgGAHQgdAhgTAUQgWAUgLAAQgKAAgCgOg");
	this.shape_27.setTransform(-10.6,-15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D74F32").s().p("AAEBdQgOgKgXgmQgLgRgdgbQgVgXANgcIAFgRQABgwArAaIBBA2QAmAdAMAaQAOAlgkAbQgTAPgRAAQgLAAgKgGg");
	this.shape_28.setTransform(-0.8,-22.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F6CDCE").s().p("AAPAcQgSgTgcANIgPAGQgFAAAAgKQABgSAKgFQAhgSAFgEQAGgGAEgBIAsAoQgEARgJAIQgFAEgFAAQgHAAgHgHg");
	this.shape_29.setTransform(3.8,-23);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D74F32").s().p("AgKgfIAEgCQARgOAAAUIgGAiQgCAWgJALg");
	this.shape_30.setTransform(-15.3,-25.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#F6CDCE").s().p("AgKAcQgSgEAAgHIABgWQgCgSAZgFQAXgFAHAVQAIAUgMANQgJAJgNAAIgKgCg");
	this.shape_31.setTransform(-3.6,-13.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F6CDCE").s().p("AgPAeQgXgJABgWQABgaAfgFQAdgEAEAWQAJAVABAHQABAKgPAGQgLAEgKAAQgJAAgJgEg");
	this.shape_32.setTransform(-2.5,-28.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#F6CDCE").s().p("AgEAiQgOgBgIgKIgDgtQAFgKAIgCQAJgCAIAIQAdAXAAAUQABAUgaAAIgJgBg");
	this.shape_33.setTransform(-13.3,-24.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B22632").s().p("AiAB3IgOjZQA0gbBAAAQAOgBAMACICPCFIAAAIQABAog1AiQg2AkhAgBQg8ABgpgIg");
	this.shape_34.setTransform(-2.2,-20.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FCDE49").s().p("AAkA5QgWgKgyAJQgrAIgFgLQgDgIAPgdQAPgbAKgIQAEgCAPALQAQAKAEAAQAHgCADgMQAGgNAHgCQAFgCAAgMQABgPACgCIA/A7IgSALQgKAIgBALIAFAVQABALgLAAQgGAAgKgEg");
	this.shape_35.setTransform(67.7,41.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FCDE49").s().p("AgOAlQgQgHgJgKQgKgLAFgGQAHgHgEgLQgGgQAKABQAFABAGADQAFgKAOgFQAQgHAOATQANAQAIACQABAAAAAAQABAAAAABQAAAAAAABQAAAAAAABQgGAQABAIQAAADgOAEQgLACANAFQAOAFgIADIgKAGIgDAAQgUAAgQgHg");
	this.shape_36.setTransform(7.3,39.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EB9546").s().p("AACAkQgMgGgCgLQgCgHADgMQACgGgNgRQgKgOAJgBIAaAEQANgKAIASQAIASgJAOQgCAEgEAXQgBAGgFAAQgEAAgFgDg");
	this.shape_37.setTransform(34.5,57);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FCDE49").s().p("AgVAbQghg4ARghIBRBMQgQAOACAIQACAKgCAEQgIANgJAAQgOAAgUgkg");
	this.shape_38.setTransform(-6.5,-34.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#D17530").s().p("AgEAWQgRgDgFgKQgHgLAGgIQADgFAKgHIAtAqQgNADgKAAIgMgBg");
	this.shape_39.setTransform(51.1,18.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#7F9D31").s().p("AgkBTQAFgOABgGQAAAAAAgBQgBAAAAAAQgBAAgBABQAAAAgCABQgBABgBAAQgBAAAAABQgBAAAAAAQAAgBAAAAQAAgCAGgFIAGgGQAEgOgCgCQgCgBgSAHQgPAHgBgEQAAgCAKgCQAMgEADgDQABAAgHgDQgHgDABgBQACgCALAEQAKAFACgDQAEgEACgaIgkgBQgjAAAAgEQAAgBAAgBQABgBAAAAQAAgBABAAQAAAAABABQAPAHA1gBQAAgJgDgDQgCgKgCgBQgCgBgEAEQgBAAAAABQgBAAAAABQgBAAAAAAQAAAAAAAAQgBgCAFgFQAEgEgCgCQgCgCgJABQgKACgCgBQgCgBAHgBQAGgCgBgBIgUgJQgMgFABgDQABgCAMAGIATAKQABAAgEgFQgEgGABAAQABAAAFAFQADADACgCQABgCgDgEIgFgIQAAgBAFAEQAFAFAAgBIgIgYQgEgOAEABQACAAACANQAEAQACAEIADgFQACgGABAAQABABgCAIIgBAIQAGABAFgOQAGgOABABQACABgOAcIAHgEQAIgGAAACQgBACgGAGIgHAIQgBADAGAAQAHAAAAADQAAAAgBAAQAAABAAAAQgBAAgBAAQgBABgBAAQgFAAgBABQgDAGABAIQACAIAFAFQAEADANgUQABgCABgKQAAAAABAAQAAAAAAAAQABAAAAABQABAAAAABIADACIAKgOQAEgHADABQADAAgEAGIgKALQAAAAAAAAQAAAAABABQAAAAABABQABAAABABIADACQgBACgFABIgHADQgEAFACADQACAEAGAAQANAAASgSQAPgRABACQABABgFAGIgKAKIAEABQABAAAAAAQABABABAAQAAAAAAAAQAAAAAAABIgNAFQgHAFAEADQADACAWgCQAVgBAAABQAAABgVACQgVACgBADQAAAAAFACIAIADIgBACQgBAAAAABQAAAAAAAAQgBABAAAAQABAAAAABQAOAKgEAFQgLgOgNgHQgNgEgKACIgMgBQgIgBAAAAIASALQAQAJABADQADAEgHgBIgHgCIALANQAFAHgBABQgBAAgIgIIgRgSQgEACgBAAIgCgGIgCgFQgIgKgJAEQgCABgCALQgCALACACQABABAHgCQAGgDABACQABACgIACQgHACABADIALAGQAJAEABACQAAABgGgCQgIgDABABIAIARQAGAKgBABQgBABgGgNQgJgNgCgCQgBgBACALIACAKQgDgDgDgNQgDgKgBACIgGAOIABAMIABAJQgBABgCgHQgBgIgBABIgFAQQgDAJgBABIgBAAQgBAAADgHg");
	this.shape_40.setTransform(46.8,35.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#9BBE33").s().p("AgvBiIACgMQAAAAAAgBQgBAAAAAAQAAgBAAAAQgBAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAAAAAgBIACgGIACgGQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBgBAAIgBgEQAAgDACgFIABgEQgDAFgGgCIgKAAQgFABgCgEQgEgNAIgCQADgBAAgDQABgEACgCQACgBAFgBIAIgDQAIgGAIgJIgegBQgfAAgDgEQgCgEACgCQABgBAAAAQABAAAAgBQABAAAAAAQAAAAABABQANAHAvABIgKgJQgIgIgJgDQgEgBgDgFQgEgEgDgCQgDgBgBgEQAAgFgCgBQgEgCgBgEQAAgEACgDQAAgBAAAAQABgBAAAAQAAgBABAAQABgBAAAAQADgBADABIAHACQAEAAABACQAGAFAEgFQgEgMACgKIgBgJQAAgFABgCIACgEQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABABABIAFAHQACABABAGQACAGACADQAEAEAJgOQADgFAHAFQAEACADAIQABAEAAAEIAAAIQAAADgDAGQgDAGAAADQABANgFANIADgIQAGgKAEgIQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAIACAAQACgCAAgDIACgGQADgCAFABIAFgEQADgDACAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIgBAGIACAEQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAIgEAFIgDAFQgCAFABADQAAABAAABQABAAAAABQAAAAAAABQABAAAAAAIADgEIAGgGQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQABAAABAAQAAAAABAAQABAAAAAAQAAgBABAAIADgFIAEgGQAFgFAGgCQAFgCABACQABACgCAIQgBADgFAFQgBADACAFQgBAFgDADIAGgBQAGgCAGABQADAAAEAEIAJADQAEABgBADQAAACgNAEQgFACgDABIgNABIADAJIAGAJQABADgFAGQgCACgDgCIgHgEIgDAAQAAAAgBABQAAAAAAAAQgBAAAAAAQAAgBAAAAQgCgBgDgEIgEgGIgIgHQgBAAgBgBQgBAAAAAAQgBAAAAAAQAAAAAAABIADAGIAHAKQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBABIgBAEIADALQABAFgDACQgBABgEgDIgIgHIgDABQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgHgLgDgDQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgEgBIgIgMIgEgGIAEAIIAIASQAAABAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAEAHAMQABACgEAEIACAKQABAFgBACQgBADgEgEIgIgHQAAgBgBAAQAAAAAAAAQgBAAAAAAQAAAAgBABIgDABIgFgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgCAIgBACQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQAAAAAAABQgBAAAAAAQAAABAAABQAAAAAAABIgBAEQgBACgGAAIgEAFIgBABQgBAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBg");
	this.shape_41.setTransform(47.3,35.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#7F9D31").s().p("AgJAYQgCgMgEgEQAAgBgEAHQgDAHgBgBQgBgCAEgKQAFgIgDgCQgBgCgTgDIgBgDQAQAEADgCQACgBgDgHQgCgHACAAQACgBACAIQACAHACgBQACgBAFgKIAGgMQAAAAgCAIQgCAIABAAQAYgRACACQABABgNAHQgMAJgBACQgBABAJgCIAKgBQgEADgMADQgJACACABIANAGQADAAAIgBIAJAAQABABgHAAQgIABABAAQAGADAKADIAKAEQACADgJgDQgPgGgFgBQAAAAAAAAQgBAAABABQAAAAAAABQABABAAABQABACAAAAQABABAAABQAAAAAAABQAAAAgBAAQgCgBgEgFIgHgGQgMgEgBADQgBAAAGASQAGAPgEABQgBAAgDgKg");
	this.shape_42.setTransform(-9.7,15.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#7F9D31").s().p("AgRAJQANgUADgCQACgCgBAGIAAAHQARgRABACQABABgIAIIgRAPIABADIABACIgGACIgFACIgCACg");
	this.shape_43.setTransform(-12,10.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#7F9D31").s().p("AgJAAIABgCQAAAAABAAQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAJgNAEAEQgLAJgIALg");
	this.shape_44.setTransform(-13.1,6.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#9BBE33").s().p("AgWAiQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQgEgBgCgCQgBgBgBgGIgDgIIgFgGIgCgaQAKgGAQgGQAAgBABAAQAAAAAAAAQABABAAAAQAAAAAAAAQAAAAAAABQABAAAAAAQAAAAABAAQAAAAABAAQALgIACgBIAEACIADABQANgDAEACQACABgDAEIgIAJQgCADADAEIgBAEQAAABAAAAQAAABAAAAQAAAAAAABQAAAAABAAIAKAEQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAQABAAAAAAIAEABQACACAAAGQABACAFACQAAAAAAAAQAAABAAAAQgBAAAAAAQgBAAgBAAIgMgCIgDADQAAAAAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQgEgBgHgEQgBAAAAAAQAAAAgBAAQAAAAgBAAQgBABAAAAIgDABQgFAAgGgDIACACQACADgBAEQgBADABAIQAAAFgEABIgHABQgGAAgCgGg");
	this.shape_45.setTransform(-9.3,15.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#9BBE33").s().p("AgXggIAKgDQAGgFADgBQADAAADAFQACACgCADIgCAGIAAADIAAADQgCADgJAFQgFAEgCAEQAAABAAABQgBAAAAABQAAAAAAAAQAAAAAAAAIAGgCQAHgFAEgBIADAAIAEABIALgCQAFAAACACQACACgLAJIAAADQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQgCADgMAHQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAABIAAADQgJAJgJAFg");
	this.shape_46.setTransform(-11.8,9.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F6CDCE").s().p("AglgpQAkgiATAAQAZAAgGAvQgGAogTAZQgUAcgVAKg");
	this.shape_47.setTransform(-7.8,49.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#B22632").s().p("Ag7h1IAHADQAKADAcADQAWADAKAFQAXAMAMAhQACAEgCAMQgCAMABAEQABAFAFAKQADAHgBAEQgLAng3ApIgSARQgNANgHAFg");
	this.shape_48.setTransform(-6.2,48);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#A78F72").s().p("Ag9ATQgQgQBLgTQBKgVgIAVQgIATgzAQQgYAIgRAAQgRAAgIgIg");
	this.shape_49.setTransform(19,31.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E6CBAB").s().p("AgnCTQgMgMgJhGQgKhCgGgDQgNgHgvAkQgwAnAKAUQAJATAMgFQASgNANgGQASgHAAAJQABAFgEAGQgKAWgTAMQglAZgogtQgLgNgFgbQgHglANggQAnhkC+grQBugXBGAuQAcASAMAYQALAWgIAQQgSAxg4AEQgRABgTgDIgPgEQgJgFgFgHQgKgPARgFQAHgCAqALQAcAHgCgaQgCgggxgHQgwgHgbAcQgGAHAZBGQAbBLgGAOQgIAVgzAQQgaAIgPAAQgRAAgIgIg");
	this.shape_50.setTransform(16.8,18.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#64544B").s().p("AjXB0QgIgLgEgZQgGglAMgiQAkhnC8gqQBugXBHAuQAbASAMAYQAMAWgIAQQgTAxg3AEQgRABgTgDIgQgEQgIgHgGgHQgKgNARgFQAKgDAhAKQAbAIAEgMQABgCgVgEQgYgEgVAAQhAgCAMAfQALAeg+AYQg+AZgEgfQgDgQgmAeQgsAjAbgMQARgHABAJQAAAFgDAGQgLAWgTAMQgNAJgNAAQgZAAgZgdg");
	this.shape_51.setTransform(17,17.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#704735").s().p("AjSB1QgIgJgIgaQgIgcAAgWQAAgyAwgnQA8gwCGgeQB1gYBAAjQA7AhgRA8QgSAwg4AEQgRACgTgEIgPgEQgLgLgHgLQgNgaARgEQAKgDAqAWQAgAQgBgZQgCgdg5AFQg2AEgMAQQgJAMgzAQQg1AOgLgGQgNgFguAkQgwAnAKAVQAIARANgPQAVgaAKgEQARgIABAVQAAAKgDAMIgIAMQgKAOgMAIQgNAJgNAAQgZAAgZgdg");
	this.shape_52.setTransform(17,19.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#EFDC69").s().p("AAzAlQhKiDgNgGQgHgDgQAZQgPAYgOgHQgQgIgNgRIgLgQQgLgOATgBQAdgBAHgIQANgUAPgNIC9E/IgBAAQgLAAhGh7g");
	this.shape_53.setTransform(29.9,7.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#A09434").s().p("AgjA4QgQgIgNgRIgLgPQgMgQARgNIAhgYIANgWIBpBjIgIAFQgQAJgOABQgPABgUgJQgHgCgKAJQgHAGgHAAQgGAAgGgEg");
	this.shape_54.setTransform(24.6,-4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#EFDC69").s().p("AgrBDQgLgFgIgQIgFgPQgHgNAQgEQAXgGAHgIQAagrAWgQQAagRATATQAHAPgDAUQgFAWgSAQQgMAKgIgBIgWgIQgEgCgQAdQgOAYgJAAIgEgBg");
	this.shape_55.setTransform(30.1,40.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#A09434").s().p("AgvBUQgLgFgIgQIgGgPQgHgOAQgTQAXgSAIgLQAqhPAUAKQALAFAUAmQAUATgJAcQgHAbgXATQgPAMgLADQgNAFgMgGQgFgCgMANQgIAIgHAAQgDAAgDgCg");
	this.shape_56.setTransform(30.6,38.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#EFDC69").s().p("AgKAzQgBgDgEgCIgGhmIArAqQgBAbgOAbQgHARgFAAQgDAAgCgGg");
	this.shape_57.setTransform(-15.5,-42);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#C29E30").s().p("AgfAxQAAgDgEgBIgHhnIBVBPQgLAageAJQgJADgHAAQgOAAgDgKg");
	this.shape_58.setTransform(-13.4,-41.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#C9623B","#F1A328"],[0,1],11.1,-16.7,-9.6,10.8).s().p("AhOB4QgwghgNhKQgNhBAWgyQAYg0AtAUQAKADA5AYQAcALANgMIBiBdQgCAwgRAgQgUAmgrATQgqATghAAQglAAgdgVg");
	this.shape_59.setTransform(8.1,-7.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#C9623B","#F1A328"],[0,1],-9.3,0,18.9,0).s().p("AARBeQgrgCgWgUQgYgXgNgyQgNg1AJgnIC3CtQgfAOgnAAIgHAAg");
	this.shape_60.setTransform(60,26.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#C9623B","#F1A328"],[0,1],-16.4,0,16.5,0).s().p("AgtB6Ig0ABQgmABgMgHQgXgPAKgeQASg0gBgeQgBgaAIgDQAEgCAPAFQAdALADg3QACglAugFQApgFA2AYQA5AZAcAnQAhAsgUAwQgVA0hDAOQgYAFgqAAIgvgCg");
	this.shape_61.setTransform(19.7,52.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F9C21E").s().p("AjQJgQgUgGgzhYQgyhXgWgEQgOgCgTAWQgLANgZAlIhIxcIPZOkQgTAqgWAYQgdAfguAMQgYAHhdg2QhagzgZANQgSAKgSBYQgTBbgVASQhKA+g1APQgYAHgdAAQgsAAg1gQg");
	this.shape_62.setTransform(31.6,14.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#C26A33").s().p("AkOJmQgTgGgrgsQgogrgYgEQgPgDgQANIhMyGIPuO3QhNBwhcAZQgaAHhDg/QhAg9gZAOQgSAKgTBRQgTBUgWASQhKA9hWARQgiAHgiAAQg5AAg7gSg");
	this.shape_63.setTransform(32.6,15.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#F8DC9B").s().p("AmaJzIgbgDIhTz+IQRPZQg9BFhkAbQhRAWg7AdQhGAjhJA8QhaBLiGAHIgVAAQhYAAiagcg");
	this.shape_64.setTransform(34.4,17.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#F2CF9E").s().p("AiWKjQgpgBhcgHQhbgIg0AAIgZABIhW02IQzP5Qg+BChjAqQhgAkgwAWQhSAlhEA4QhXBJiRAAIgBAAg");
	this.shape_65.setTransform(36.1,19.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#E6BA7F").s().p("AnELEIhb2HIQ/QFQg7A9hYBEQgnAehoAnQhlAmg8AxQhcBMifASQg9AHi5AAIgwAAg");
	this.shape_66.setTransform(36.7,23);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#924B30").s().p("AoqrjIRVQZQghAdgwAlIhRA/QgoAfhhAwQheAug+AzQhhBPigAcQhoARjFABg");
	this.shape_67.setTransform(37.7,26.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#C7C8C9").s().p("AozrzIRnQpQgkAhg1ArIhbBHQgoAehhAwQheAvg+AyQhfBQihAaQhpASjDABg");
	this.shape_68.setTransform(38.6,27.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#F1F1F2").s().p("Ao9sHIR7Q9QgnAng7AvIhnBPQgnAfhhAwQheAvg+AyQhfBPigAcQhpASjBAAg");
	this.shape_69.setTransform(39.7,29.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#F6CDCE").s().p("AgWgTQAMgDAKATQAGANAIgKQAGgGACAGQABAHgDANg");
	this.shape_70.setTransform(7,-24.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FCDE49").s().p("AAaA4QgYgDgQgSQgNgMgVgfQgNgVglAJQgkAIAAgDQgCgMAKgLQAMgOAUgDQAKgBA8AwQA1AoAVgUQAQgOAdgEQAVgDAMgaQAIgRAAAMQAAALgHAVQgTA6gagTQgWgPgJATQgLAVgOAAIgCAAg");
	this.shape_71.setTransform(-111.1,-14.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FCDE49").s().p("AgZA4QgHgEgQgRQgNgQgGgJQgXghALgTQAJgSAcAHIAOgFQAPgDAIAMQAGALgBAMQAAAJACABQAGACAEgEQADgCALgQQAJgNAMAPIAXAhQAKAMADAJQADALgMAAQgFAAgOgIQgQgJgGgBQgWgFgGAMQgDATgCAJQgFAMgIAAQgFAAgHgEg");
	this.shape_72.setTransform(19.1,-82);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FCDE49").s().p("AgjgYIACgCQAWgMATAOQATALAHAUQAGAPgPALg");
	this.shape_73.setTransform(73.8,37.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FCDE49").s().p("AATCGQgTgxgJgCQgKgDgCAJQgDAHgIgDQgMgFgKgUQgKgVAGgHIAegVQAdgWAKgSQAEgHgOgMQgKgLAFgGQAEgGAOAIQANAHADgIQADgIgNgZQgQgcAAgHQgCgWAKgQQAIgNAEADQAKAFgEAOQgEAUAEANQACAFASAbQANAUgCANQgHAjgjAjIgdAeQABACADAIQACAGAEADQAEACALAAQALAAABABQALAHAGAuQAFAtgHAIIgBABQgGAAgQgog");
	this.shape_74.setTransform(78.1,-5.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FCDE49").s().p("AgeBBQABgUgCgDQgIgGgJgDIgTgIQABgMANgGQANgGAKAGIANgUQANgXAUAAIAbgaQAZgYAAAGQABALgeAoIgdAlQAFAEgCAMQgCAOAEAJQAGAMgMABIgLgBQACADgLAKQgLAJgEABIgBAAQgEAAABgRg");
	this.shape_75.setTransform(54.4,-115);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FCDE49").s().p("ABfB/QgdgGgagOQgMgFgWgTQgSgRgLgEQgMgEgFANQgEANgFgCQgJgEgFgXQgHgcANgYQAKgTgOgYQgHgMgLgLQgIgMgagDQgOgDARgTQAFgJAIgIQAQgQAPAJQAOAJAQgHQATgHADAAQAZAHgFAUQgBAFgKAJQgLAHABAGQAAADAGAJQAEAHgDAFQgDAEgMAfQgMAeAAADQgDAAAIAMQAKAMAPAJQAEACANgBQANgBAFAEQAFAEAHASQAGAQAGAEQARALAdAKQAVAHAAAEQAAACgGAAQgGAAgOgDg");
	this.shape_76.setTransform(-103.5,-77.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FCDE49").s().p("AhWAxQgHgGgJgRQgJgNgIgBQgBgBAWgSIAJgZQADgHAUgBQARAAAMADQADABAngMQAsgNAaACQAFAAAWAIQAXAHgGAEQgFADgWgFQgZgGgOACQgeAGgaAfQgBAXAnAKQAIACAOgHQAMgHAEADQAEAEgKALIgNAMQgMAPghgSIgdgSQACAOgBAFQgCAJgKgLQgQgRgJAnQgUAAgKgLg");
	this.shape_77.setTransform(-42,-145.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FCDE49").s().p("AhlAoQgCgPAHgLQAHgKgEgPQgFgWAdgMQAYgKAQAEQAMADAIATQAHARgBARQAAAFATAIQAWAJATgDQALgCAPgPQANgLAEACQAHACgIATIgLAUQgJANg0AAQgtAAgQgGQgHgDghAJIgLACQgPAAgBgOg");
	this.shape_78.setTransform(0.5,-155.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FCDE49").s().p("Ag0CIQAAgngDgKQgEgOgTgTQgOgPACgIQACgHAVAGQAWAGAFgHQAFgIABgcQABgZAKgCQAPgDAPALQALAHAJgPIARgMQAPgMABgMQACgMgIgcQgIgZAFgHQAMgVAEAHQAEAHgEAnQAAAGAMAOQANAPAAAJQAAAHgNAPQgPAQgDAJQgBADAQApQAPApgKANQgFAHgXgiQgZglgOAAQgOAAgSBHQgTBIgDABIgCAAQgKAAAAgXg");
	this.shape_79.setTransform(95.3,-57.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FCDE49").s().p("AAjBRQgMgBAFgNQAFgPgJgDIgdgLQgDgHgTgZQgYgfgQgOQgFgEgUAJQgUAIgBgCQgSgUANgPQATgMADgEQACgDAdAZQAkAfAQAJQAQAKAPgCIAOgFQAJAAANAfQAAABAOgFIAbgJQAXgEAGAAQACACgRAQQgSARABADQABAIgQgCQgQgBgBADQAAACAHAGQAIAGAAACQACATgjAAIgHAAg");
	this.shape_80.setTransform(-41.1,15);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FCDE49").s().p("AACAwQgKgBgEgLQgEgNgJgDIgNgPQgFgIAPgWQAQgWAMAAQAGAAAPAMQAQANACAGQACAEgCAGQAAADgGAFQgFAHAAAEQgBAEADAIQABANgGAFQgGAFgMAAIgFAAg");
	this.shape_81.setTransform(-60.7,54.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#EB9546").s().p("AAEAwQgKgBgEgLQgEgNgJgDIgLgNQgKgOAGgJQASgfAVAAQAIAAAPAKQARALAAAKQAAAIgJACQgKADgCADQgDAGAHAJIAIAKQABANgHAFQgFAFgMAAIgFAAg");
	this.shape_82.setTransform(-53.6,-65.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FCDE49").s().p("ABPBzIgPgKQgCgEgFAAQgGAAgCgBIg1gSQg7gYghgjQgsgugIhcQAPgMAOAlQATA2AYASQAJAHAcAgQAZAdAOAHQAgAPAlgDQAVgCAQgHQAWgJALAHQALAHgBAKQgBAKgLAJQgXATgGADQgGADgGAAQgIAAgJgEg");
	this.shape_83.setTransform(-94.1,33.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#EB9546").s().p("AglAZQgjgKAbgGQAZgEgDgHQgCgEgGgDQABgFgPgDQgQgEAAgDQgCgGAHgCIALgCQAMgCAaAQQAUAOANgKQAQgLAGAHQADADAJAWQANAeguAAQgfAAghgKg");
	this.shape_84.setTransform(-108.5,-113.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#EB9546").s().p("AgWAXIAEgXQgEgEgIgEQgFgCAAgDQgBgFAIgHQAIgIAEAAQAJgCAHAMQAJAPAGACQARAGADAJQADALgGAGQgFAGgLgBQgMAAgQAEIgBAAQgLAAACgMg");
	this.shape_85.setTransform(-7.5,-71.6);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#D17530").s().p("Ag8A8QgJgaAPgbQAFgHAEguQADgiAVgFQASgEAIAJQAJAJAVgHQAbgJACAnQABAhgKAUQgNAbgSAXQgYAfgQABIgEAAQgeAAgKgbg");
	this.shape_86.setTransform(-39.5,-36.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FCDE49").s().p("AhAA5QAFgLAMgCQAHgCAvhaQAwhZAGADQALAEgPAwQgYBLgEATQgFAeADAvQACAkgGAFIgGAGg");
	this.shape_87.setTransform(-3.8,-46.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#D17530").s().p("AAGAoQhCgEgLgeQgIgWAmgNQAQgEApgGQAZgDARANQATAOgEAXIAAACQABAeg1AAIgPAAg");
	this.shape_88.setTransform(-41.1,-113.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FCDE49").s().p("AgvAgQAKgIgDgMQgDgMgJgFQgJgFgEgPQgFgUAZgJQANgGAdgGIAkgKQAUABAKApQAMAtgXAgQgSAZgiAJg");
	this.shape_89.setTransform(54.3,12.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#D17530").s().p("AAQBLQgZgBgPgNQgUgPgJgRQgKgTAIgLQAFgIAPgFQAJgDgHgKQgZgjACgJQADgRBaBMQAPALAFAUQAHAXgKAQQgKARgbAAIgBAAg");
	this.shape_90.setTransform(-52.8,-79.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#D17530").s().p("AAeBZQgSgJgLgRQgIgPgVgKQgbgMgFgmQgFgjAJgNQAMgQAQgKQAXgMAQAMQAiAYANAlQALAfgNAPQgEAFAAArQAAAYgMAAQgEAAgGgEg");
	this.shape_91.setTransform(-50.3,22.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#7F9D31").s().p("AAmBBQgJgUgEABQgCABAAANQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgFAQgGgCQAKgPADgOQACgPgIgIIgBgMQgBgKgBACQgCACgEASQgEASgBADQgCADAAgHIgBgGIgKAOQgEAHgCgBQAAgBAFgKIAMgWQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgBgCQAAgCAEgCIADgDQAHgLgHgHQgCgCgJACQgKABgCACQgCACAFAEQAEAFgBABQgCABgEgGQgEgFgDACQgBACgBAJQgBAMgBABQgBABAAgJQAAgJgCABIgNAPQgHAJgCgBQgBgBAKgLQALgMAAgDIgJAFQgJAFAAgBQADgEALgHQAJgDgCAAIgQgCQgEABgGADIgIACQgCgBAGgCIAGgDIgRgBQgKAAgBgBQgCgCAKABIAUAAQAAAAABgBQAAAAgBAAQAAgBAAgBQgBAAgBgBQgBgBgBgBQAAAAgBgBQAAAAAAgBQAAAAAAAAQACAAAGAEIAIADQAQAAAAgCQAAgCgLgPQgLgNAEgCQABAAAGAJQAGAKAEACQABABABgHQAAgIACABQACABgBALQgBALACABQADABALgBIAQgDIgHgiQgKgjAEAAQABAAABAAQABAAAAAAQABAAAAAAQAAAAAAABQgEARAQAyQAIgCACgEQAKgFAAgCQAAgCgEgCQgBgBgBgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQACgBAGADQAFADABgCQABgDgEgIIgDgLQAAgCADAGIADAEIAEgVQABgOADAAQACAAgDAOIgDAVQAAABAEgGQAFgGAAACIgDAHQgCAEACABQADABADgEQAEgGACgBQAAgBgCAGQgDAGABAAIAVgOQAMgJAAAEQABACgMAHQgOAHgDAEQgBABAGAAIAGABQAAABgJABIgIACQABAFAPABQAPABAAACQgBACgfgFQgBAAAIAGQAIAGgCAAQgCAAgIgFIgKgEQgDABABAGQACAGgCAAQgCABgBgFQgCgFgCAAQgGgBgGADQgIAEgDAGQgDAGAYAFIAHAAIAFAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAABgBABIgBADIARAFQAHADABADQAAACgHgCIgNgGQAAAAAAAAQgBAAAAABQAAAAAAABQAAABAAABQgBABAAABQAAABAAAAQAAABgBAAQAAAAAAAAQgBAAgEgFIgFgGQgFgCgDADQgCADABAGQAEAMAWAMQAVAKgCABQgBABgTgJQAAAAAAAAQgBAAAAAAQAAABAAABQAAAAAAABIAAAEQgDgBgGgKQgFgFgEAFQgBADAJAVQAHATAAAAQgCAAgHgTg");
	this.shape_92.setTransform(-63.1,3.6);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#9BBE33").s().p("AAsBZIgFgHIgDgEIgEgDQgDgFgBgHIgIAGIgHAIQgCABgIgDQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAgBABAAIACgIQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAAAQAAgBABAAIAEgGIAEgGQAHgNgEAAIgEAFIgIAJIgDABIgFABIgJAFQgFACgCgBQgCgBACgFIAEgJQAAgBAAAAQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAABAAIAFgHIAFgHQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgEIAIgLIADgGIgUASQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAQAAAAgBABIgGAGQgEAGgCABQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgEgBIgJAFQgEACgDAAQgCAAACgGIAEgLQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAIgCgCIAAgFQgBgBAAgBQAAAAAAgBQAAAAAAAAQgBAAAAAAIgLAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAIgEAAIgCgDQgBgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQgCgCgFAAQAAgBgBAAQAAAAABgBQAAAAABAAQAAAAACAAIALgDQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAgBIACgDIAHAAIAGABQAEgEACAAIAJgBIAEAAQgGgCAAgGQAAgDgDgHQgCgEADgDQALgIAFAIQAAAAABAAQAAABABAAQAAAAABAAQABAAABAAQAEAAACACIAFAGIAFAGQAEAEAHADIAFAEIgGgcQgIgfAEgEQADgDADACQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAABQgDAOALAtIAGgMQAFgKABgJQAAgEADgFQADgEAAgEQAAgDAEgCQAFgCAAgCQACgJAKACQAIABgCAHIABAHQABAEgBACQgEAHAGACQAKgHALgBIAIgDQAEgDADABIAEABQABAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIgDAEIgFAHQgBACgFADQgFADgCADQgDAFAQAFQAFACgCAIQAAACgDACIgFAFQgDAEgEABIgIAAQgDACgGgCQgHgBgDABQgMAFgOgCQAPACAOAFQAAAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQACAAAEAAIAFAAIACADIACADIAGAEQAAABABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAIgFABIgEACIgDADQgCAAgEgCIgGgCQgEAAgEACQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAAAQAHADAGADIACAEQAAABAAAAQAAABAAABQABAAAAAAQAAABABAAIAGACIAGABQAHAEADAFQAEAEgCABQgBADgJAAQgDAAgGgEQgDAAgEAEQgFAAgEgBIADAFQADAFABAFQAAADgCAGIAAAJQAAAEgDABIAAAAQgCAAgDgEg");
	this.shape_93.setTransform(-63,4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#7F9D31").s().p("AAmBBQgJgUgEABQgBABAAAFIgBAIQAAAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAAAAAQgBABAAAAQgGAQgFgCQAKgPACgOQADgPgHgIQgBgBgBgLQgBgKgBACQgCACgEASQgEASgBADQgCADgBgHIAAgGQgOAVgBgBQgBgBAFgKIAMgWIgBgCIgBgCQABgDAFgEQAIgLgHgHQgCgCgJACQgKABgCACQgBACAEAEQAFAFgCABQgCABgEgGQgEgFgCACQgBACgBAJQgCAMgBABQgBABAAgJQAAgJgBABQgUAYgCgBQgCgBAKgLQALgMABgDQAAgCgTALQADgEALgHQAJgDgCAAQgLgCgFAAIgLAEIgIACQgBgBAGgCIAGgDIgRgBQgJAAgCgBQgCgCAJABIAVAAQABAAAAgBQAAAAgBAAQAAgBgBAAQAAgBgBgBQgBgBgBgBQAAgBgBAAQAAgBAAAAQAAAAABAAIAIAEIAHADQAQAAAAgCQAAgCgLgPQgLgNAEgCQABAAAGAJQAGAKAEACQABABABgHQABgIABABQACABgBALQgBALADABQACABAMgBIAOgDIgHgiQgIgjAEAAQABAAAAAAQABAAABAAQAAAAAAAAQAAABAAAAQgCALAGAdQAHAbACAAQAHgCADgEIAFgDQAEgDAAgBQAAgCgEgCQgBgBAAgBQgBAAAAgBQgBAAAAAAQAAgBAAAAQACgBAGADQAFADABgCQABgDgDgIIgEgLQAAgCADAGIAEAEIADgVQABgOADAAQADAAgDAOIgEAVQAAABAFgGIAEgEIgDAHQgCAEACABQADABADgEQAEgGACgBQABgBgDAGQgDAGABAAIAVgOQAMgJAAAEQABACgNAHQgNAHgDAEQgBABAGAAIAGABQAAABgIABIgIACQAAAFAQABQAPABgBACQAAABgNgCIgSgCQgCAAAIAGQAIAGgCAAQgCAAgIgFIgKgEQgDABACAGQABAFgCABQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAgBgBgBQgCgFgBAAQgGgBgIADQgHAEgDAGQgDAGAZAFIAGAAIAFAAIgBADQAAABAAAAQgBABAAAAQAAABAAAAQABAAAAAAIAQAFQAIADAAADQAAACgGgCIgOgGQAAAAAAAAQAAAAgBABQAAAAAAABQAAABAAABQAAABgBABQAAABAAABQAAAAgBAAQAAAAAAAAIgFgFQgDgFgCgBQgFgCgDADQgCADABAGQADAMAXAMQAUAKgBABQgBABgTgJIAAADQAAABAAABQAAABAAAAQAAABAAAAQgBAAAAAAQgBgBgDgEIgEgGQgEgCgCAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAABQgBADAIAVQAIATgBAAIgJgTg");
	this.shape_94.setTransform(54.9,-61.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#9BBE33").s().p("AAsBZIgFgHIgHgHQgDgFgCgHIgHAGQgFAHgCABQgCABgIgDQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAgBAAAAIADgIQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAIgCgDQACgEAHgIQAHgNgEAAIgEAFQgFAGgEADIgCABIgFABIgJAFQgFACgDgBQgCgBADgFIAEgJQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAAAgBIgCgDQACgEAJgKQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgEQAFgKAGgHQgIAIgMAKQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAQAAAAgBABQgIALgEACQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgEgBQgMAHgEAAQgCAAACgGIAEgLQABgDgEgCIAAgFQgBgBAAgBQAAAAAAgBQAAAAgBAAQAAAAAAAAIgLAAQgBgBAAAAQgBAAAAAAQAAgBAAAAQAAAAAAAAIgCgDQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAIgEAAQgCgBgCgFQgCgCgFAAQAAgBgBAAQAAAAABgBQAAAAABAAQAAAAACAAIALgDQAAAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBIACgDIAHAAIAGABQADgBADgDQAGgCAHABIgDgBQgDgDAAgEQAAgDgDgHQgCgEADgDQALgIAFAIQAAAAABAAQAAABABAAQAAAAABAAQABAAABAAQAEAAACACQAGAJAEADQAEAEAHADIAFAEQABABgHgdQgIgfAEgEQADgDADACQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQgCAJAEAaQAFAbABgDIAGgMQAFgKAAgJQABgEADgFQADgEAAgEQAAgDAEgCQAFgCAAgCQACgJAKACQAHABgBAHIABAHQABAEgBACQgDAEADADIACACIAGgEQAIgEAHgBIAIgCQAEgDACABIAFABQABAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIgDAEQgDADgCAEQgBACgFADQgGADgCADQgCAFAQAFQAFACgCAIQAAACgDACIgFAFQgDAEgEABIgIAAQgDACgHgCQgGgBgDABQgIADgKABIgJgBIAKACIAUAFQAAAAAAAAQAAABABAAQAAAAAAABQAAAAAAABIABACQADAAAIAAIACADIACADIAFAEQABABABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAgBAAQAAABAAAAQAAABgBAAQAAAAgBAAIgFABQgFAEgDABQgBAAgEgCIgGgCQgEAAgEACQgBAAgBAAQAAABgBAAQAAAAAAABQAAAAAAAAQAHADAFADQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABIACAEQADACAKABQAGAEAEAFQADAEgBABQgBACgJABIgJgEIgEACIgDACIgJgBQAFAHACAIQAAAAAAABQAAAAAAABQgBABAAAAQAAABAAABIgBAEIAAAJQAAAEgDABIAAAAQgCAAgDgEg");
	this.shape_95.setTransform(54.9,-61.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#7F9D31").s().p("AgrBUQgBAAABgIIACgNQABgBgBAAQAAAAAAAAQAAAAgBAAQgBABgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAQAAAAAAAAQABgDAHgJQADgHgFgBQgDgBgSANQgRANgBgBIARgOQARgNgCgDQgBgBgFABIgIABQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQgRgBABgGQARAGAPgBQAOgBAGgJIALgFQAJgEgCAAIgUAAQgTAAgDgBQgEgDAHgCIAGgCIgQgFQgIgCABgBQAAgBALADIAZAEQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIACgCIAFADIADAEQAPADADgHQABgDgCgIQgDgKgDgBQgCgBgEAGQgFAGgBgCQgCgBAGgGQAFgGgCgBIgNABQgMABgBgBQgBAAAIgCQAJgCgCgBIgRgKQgLgFABgBQAAgCAOAHQAOAIADAAQABAAgIgJIgGgHQAFABAJAJIAHAGIgDgQQgBgDgFgGIgGgHQABgCAFAGQAFAFAAgBIgDgRQgDgJABgBQABgDABAKQADAOADAGQAAAAAAAAQABAAAAAAQAAgBABAAQAAgBABgBQABgCAAgBQABAAAAgBQAAAAABAAQAAAAAAAAQAAACgCAHIgBAIQADAPADAAQACAAAJgPQALgNACADQAAABgGAHQgJAJgBAEQgBACAIgBQAHgCAAACQAAACgMACQgJACAAADQgCAFALAWIAegPQAggRABAEIABACQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgSAAgsAcQAFAHAEACQAHAIABgBQACAAACgFIADgDQABABgBAHQgCAFADABQACAAAIgFQAHgHACAAQACAAgEAEQgGAFACAAIAWgDQANgBAAADQABACgOABIgVABQgBABAGADQAHACgBABIgHgCQgFgBgBADQAAADAFABQAHADABACQABABgHgCIgFAAIASAQQALAKgEACQgBAAgKgKQgKgLgFgCIABAFQABAGgBAAQgBAAgDgIIgDgHQgFACACAPQADAPgCAAQgCAAgCggIgFAIQgEAJAAgCQgBgCADgIQACgJgBgCQgBgDgFADQgFADgBgCQgBgBADgDQAFgDAAgBQAAgGgGgHQgFgGgHgCQgEgBgBAaIABALQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIgEAAIgBARQAAAIgDABQgDABACgHIABgOQABgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAQgCAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQAAgCAEgEQAEgFAAgCQABgGgDgBQgDgCgGADQgMAGgFAZQgFAVgBAAIAAAAg");
	this.shape_96.setTransform(-37.1,-90);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#9BBE33").s().p("AgqBfQgCgBgDgJIABgKQAAgCgFgDQgCgFABgFQgGAHgHAEQgBABAAAAQAAAAgBAAQgBAAAAAAQgBAAgBgBIgEAAIgJADQgEAAgBgCQgBgCADgDIAGgHQADgDACgGQAEgEAGgDIgHgGIgKgFQgCgCACgIQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIAHAAIADgCIACgCIAHADIAGADQAPAEgBgEIgGgDIgLgGQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBIgBgFIgIgFQgDgFABgDQAAgCAFACIALACIACgDQABAAAAgBQABAAAAAAQABgBAAAAQAAAAABAAQALAGAEABQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAIAEgBIAWAGIgZgOQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAgBIgQgIQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAgBIgBgEIgGgHQgEgEAAgCQgBgDAGABIAMABQABAAAAAAQABAAAAAAQAAAAAAAAQABgBAAAAIACgDIAFgBQAAAAABgBQAAAAABAAQAAgBAAAAQAAAAAAgBQgDgGAAgEQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAABgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAgBIgBgEQAAgCAFgDIAAgHQABgBAAAAQAAAAABAAQAAAAAAABQABABAAABIAFAKIADACQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAIABAGIABAGQAAABABAAQAAAAAAABQABAAAAAAQABABAAAAIABACQACADABAFIAAAEQABgFAGgCIAJgGQAEgCADACQAKAIgGAHQgBACABADQABAEgBACIgFAHIgFAGQgCAFgCAHIgCAJIAagPQAbgQAGAEQAEACgCADQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgPAAgpAWIANADQAMACAJgCQADAAAGACQAFACADgBQAEgBACAEQADADADAAQAIAAABAKQABADgCACQgCADgDAAIgGACQgEACgDgBQgHgCgBAHQAJAIAEAKIAFAHQADAEAAACIAAAFQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAAAIgFgCQgEgCgDgBQgDAAgEgEQgEgFgEgBQgFgBgBARQgBAFgHAAQgCAAgEgDQgDgDgDAAQgEgCgCgEIgCgHQgCgDAAgGQgBgHgCgDQgHgKgCgNQACAPgCAOQAAAAAAABQAAAAAAAAQAAAAgBABQAAAAgBAAIgCABIAAAGIABAFIgCADIgCACQgCAKgCABQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAAAIgCgFIgEgDIgDgDIABgGIAAgGQgBgEgCgEQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAAAgBAAIgDAOQAAAAAAABQAAAAAAAAQgBABAAAAQgBAAgBABQAAAAgBAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBACABAFIAAAHQgCAHgEAEQgDAEgBAAIgBAAg");
	this.shape_97.setTransform(-37.4,-89.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#7F9D31").s().p("AAhBZIgCgBQgBAAAAAAQAAAAAAAAQgBgBAAAAQAAAAABgBQAGgKABgeQACgcgCAAQgIAAgDADIgGABIgFACQgBACADAEQABABAAABQAAAAABABQAAAAAAABQAAAAAAAAQgCAAgFgEQgEgFgCACQgCACABAKQABAJgBACQAAACgBgHQgBgHgBACIgIATQgGANgCgBQgDgBAHgMIAKgTQAAgBgFAEQgGAEAAgBIAFgGQAEgDgDgCQgCgBgEADQgFAEgDAAQgBAAAFgEQAEgFgBAAIgYAHQgOAEABgEQAAgCAOgCQAPgDAEgDIgFgCQgGgCABgBQABgBAIABIAIABQABgFgPgGQgNgFABgCQAAgBAMAGIARAIQABAAgFgHQgGgJACABQACAAAGAIQAGAGAAAAQADABAAgGQAAgGADAAQAAAAAAAAQABABAAAAQAAABAAABQABAAAAACQAAAEABABQAFAEAIgCQAJgBAFgFQAEgEgVgNQgCgCgJgBQgBAAAAAAQAAAAABgBQAAAAAAAAQABgBABgBIACgDIgNgJQgGgFABgDQAAgDAGAEIAJAKIACgDQABgBAAgBQAAgBABAAQAAgBAAAAQABAAAAAAQACABABAGIADAHQAEAEAEgCQADgCABgGQAAgNgSgSQgOgQAAgBQABgBAQAPIABgDQAAgBAAgBQAAAAAAgBQAAAAABAAQAAAAAAAAIADAGIACAHQAFAGAEgEQACgCgCgWQgBgVABAAQABAAACAVQACAVADABQABAAAEgJIABAMQgIANAFAKIgCAMQgCAIABgBIAIgKIAAAJQgJAIAFAHIAGADIAAADIgKgBIgCAjQgCAjgEAAIAAAAg");
	this.shape_98.setTransform(-18.8,12.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#9BBE33").s().p("AAhBbQAFgIADgbQADgagCACIgJAJQgIAIgEAJQgBADgEAEQgFADgBAEQgBADgFAAQgEAAAAADQgCADgEABQgEAAgDgCIgEgDQgBgDACgDIABgHQABgEABgBQAEgEgBgDIgCgDIgHACQgJABgGgBIgJAAQgFABgCgCIgEgCQgBgBAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQABAAAAgBQABAAAAAAQABgBABAAQAFgCACgDQABgCAGgBQAHgBACgDQAEgDgOgKQgEgDAFgHQABgCAEgBIAGgDQAEgBAEAAIAHAAQADAAAGADQAEAEADgBQAMAAAKAEQgLgGgKgGQgBgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAAgDQgCgCgGgCQgCgDABgFQgHgHAAgCQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAABAAIAGABQAAAAAAAAQABAAAAAAQABgBABAAQAAAAAAAAIAEgBIAEADIAFAEQAEABAEAAQABgBABAAQAAAAABAAQAAAAAAgBQABAAAAAAQgGgFgEgEQAAgBAAAAQgBAAAAgBQAAgBAAAAQAAgBABgBIgBgEIgGgEIgFgDQgDgGgCgFQgCgFACgBQACgCAGADIAEADIAEADIAEgBIAEAAIAIAEQgDgJABgJIACgDIADgEIACgIQACgFACABQACAAACAFIACAIQABAEAEAFIAHByIgJgJIgBAdQgBAggGADIgEAAQgDAAAAgFg");
	this.shape_99.setTransform(-19.3,11.9);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#F6CDCE").s().p("AAAAfQgPgBgLgUQgJgOAGgFIATgOQAKgOAUAQQAUAQgLARQgLATgQAAIgCAAg");
	this.shape_100.setTransform(1.3,-125);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#F6CDCE").s().p("AgQAcIgKgWQgKgMAUgRQASgQAQAPQAQAQgEAPQgFARgWAGQgFACgFAAQgHAAgCgEg");
	this.shape_101.setTransform(-5,-120.5);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#F6CDCE").s().p("AgHAjQgBgVgGgDQgMgGAHghQAHgiANAOQASAPADAqQAEAsgTAAIgBAAQgMAAgBgSg");
	this.shape_102.setTransform(3.7,-104.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F6CDCE").s().p("AgbAZQgJgUAGgTQAHgXAXgBQAZAAAHAeQAHAcgWAGQgVALgHABIgCABQgJAAgFgOg");
	this.shape_103.setTransform(9.4,-122.5);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#D74F32").s().p("AgfBEQgPgHgHgFQgbgVAFgdQAEgZAZgOIAhgZQAHgHAGgCQAGgDAJABIAXgEQAKAAAMAIQAcASgSAPQgEAEgOADQgPADgFADQgUAMgDAQQACAXgBANQgDAZgPADIgCABQgHAAgOgGg");
	this.shape_104.setTransform(-1.9,-111.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#F6CDCE").s().p("AAMAkQgUgCgQgPQgRgRALgTQALgXAcAHQAeAIgEAWIgEAeQgCAJgNAAIgEAAg");
	this.shape_105.setTransform(-9.4,-113.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#F6CDCE").s().p("AgVATQgWgdAkgWQAMgIALADQANAEABAQQABAjgQAPQgGAGgGAAQgKAAgOgUg");
	this.shape_106.setTransform(-3.2,-103.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#B22632").s().p("AghCrQgxgGgkgnQgrgygJg4QgNhJA+g2QBFg+BUgBQBWgCA0A7QAIAHgNAQQgXAWgOARQg+BEAFBdQABATgCAFQgFARgWAJQggALgcAAIgQAAg");
	this.shape_107.setTransform(2.4,-114);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F6CDCE").s().p("AgWArQgPgSARgeQAOgdAcgbIAIB1QgMAGgKAAQgQAAgOgTg");
	this.shape_108.setTransform(-13.9,51.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#F6CDCE").s().p("AgPAdQgXgJABgWQABgZAfgFQAcgEAFAWQAEAOAGAOQABAKgPAGQgKADgKAAQgJAAgKgEg");
	this.shape_109.setTransform(-23.7,49);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#F6CDCE").s().p("AgrgDQgDgTAEgPQAEgOAHAGIA8AzQAmApgyABIgCAAQgwAAgKgzg");
	this.shape_110.setTransform(-17.8,40.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#D74F32").s().p("AgIBFQgQgOgKgXIgUgxQgDgSAWgOQAUgNgBgGIgFgDQADgMASgBQARgBAMAGQAcAMgFAjIACAeQADASgKAIQgKAIAAAHQAAALgCADQgFALAAAVQgWAAgQgQg");
	this.shape_111.setTransform(-34.4,47.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#F6CDCE").s().p("AgBAjQgmgFAIgnQADgQAKgGQALgHAKAKQAdAYABAUQAAATgZAAIgJAAg");
	this.shape_112.setTransform(-30.9,55.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#F6CDCE").s().p("AhDANQATg0BEgEQAZgCAQAGQARAGgKAHIhXA4QgbAOgMAAQgTAAAKgfg");
	this.shape_113.setTransform(-34.5,43.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#F6CDCE").s().p("AgKAcQgSgEAAgIQADgMgCgKQgCgSAZgEQAXgFAHAVQAIAUgMANQgJAJgNAAIgKgCg");
	this.shape_114.setTransform(-39,53);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#B22632").s().p("AhuBzQgHgEgKgSQgKgTgEgEQgXgOgJgIQgQgNAAgSQAAglAWghQAYgmArgSQAJgEAaAEQAZADALgDQAJgCASgMQASgMAHgDQAPgFASABIAiABQAXAAAYAJQAZANANAEIAPDrQgNALgNACQgOADgagBIgtgDQgMAAgWAFQgWAGgJAAIgDAAQhCAAg3gcg");
	this.shape_115.setTransform(-29.8,47.8);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#F6CDCE").s().p("AgLAcQgRgEAAgHIABgWQgDgSAagFQAXgFAHAVQAHAUgMANQgIAJgNAAIgLgCg");
	this.shape_116.setTransform(-81,-31.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#F6CDCE").s().p("AAWAeIgpgIQgYgBAGgRQAFgNgMABQgLABAGgGQAFgFANgFQAigPACAYQACARAdAHIAPAEQAEADgIAFQgLAIgJAAIgFAAg");
	this.shape_117.setTransform(-88.8,-52.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F6CDCE").s().p("AAGAjQgNgCgRABQgKgCAAgRQAAgUAOgRQAPgSAVAJQAYAJgGAdQgFAcgUAAIgDAAg");
	this.shape_118.setTransform(-78.5,-40.3);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#D74F32").s().p("AAQBmQgUgHgKgSQgJgQgagGQgggHACguQACglAPgTQARgVAYgOQAegUAVALQAnATAJAoQAHAlgUASQgHAHgJAyQgGAegSAAIgJgBg");
	this.shape_119.setTransform(-96.4,-38);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#F6CDCE").s().p("AgZAZQgSgHgKgMQgKgJAJgDQAxgSAbgFQA3gKgaApQgTAegdAAQgMAAgQgHg");
	this.shape_120.setTransform(-90.7,-34.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#F6CDCE").s().p("AAGAjQgNgCgRABQgKgCAAgRQAAgUAOgQQAPgTAUAJQAYAJgFAdQgFAcgUAAIgDAAg");
	this.shape_121.setTransform(-104,-42.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#F6CDCE").s().p("AAUAdQgRgNgEACQgNAEgVgaQgVgbAUgDQAXgDAhAbQAkAZgMAOQgFAGgGAAQgGAAgHgGg");
	this.shape_122.setTransform(-87.7,-45);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#F6CDCE").s().p("AgPAeQgXgJABgWQABgaAfgFQAcgEAFAWQAJAWABAGQABALgPAFQgLAEgKAAQgIAAgKgEg");
	this.shape_123.setTransform(-90,-26.3);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#F6CDCE").s().p("AgPAdQgXgIABgWQABgaAfgFQAdgFAFAXQAIAVABAHQABAKgPAGQgLAEgKAAQgIAAgKgFg");
	this.shape_124.setTransform(-99.1,-49.9);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#F6CDCE").s().p("AggAUQgFgUgKAHQgJAGACgKQABgHAIgNQAWgiARAbQANAXAegFIAQgBQAFABgDAIQgGASgMADQgjAIgFADQgHADgFAAQgNAAgEgRg");
	this.shape_125.setTransform(-100.9,-29.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#B22632").s().p("AgOC+QgbgKgogGQglgFgOgGQgLgFgNgRIgTgZQgXgdAAg+QAAgZALgaQAGgPARggQACgEACgRQABgRADgEQA0hNBzAAIBgA7QAuAcAWAaQAGAIAHASQAIAXADAHQACADgKASQgQAagGAOIgMAkQgIAWgMAOQgGAGgXALQgZAKgFAFIgsAmQgSANgQAAQgHAAgHgDg");
	this.shape_126.setTransform(-90.2,-39.5);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#F6CDCE").s().p("AAAA2QgNgCABgTQACgVgFgEQgLgIAMgfQALghAMAQQAPASgDAqQgDAqgRAAIgBAAg");
	this.shape_127.setTransform(61.3,-31.5);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#F6CDCE").s().p("AgiATQgOgTAXgWQAWgVAPAPQALAKAOAKQAHAHgKALQgNATgUAFIgIABQgRAAgKgQg");
	this.shape_128.setTransform(79.9,-30.3);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#D74F32").s().p("AgTAcIACgRQgCgEgOAEQgOAEgCgCQgEgDACgEIAGgGQAHgIASgCQAVgCAGgDQAGgCAKgIQAKgGAFAEQANAJABAUQABAWgRgRQgNgKgQAQQgLAQgKAAIgFgBg");
	this.shape_129.setTransform(80.6,-38.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#F6CDCE").s().p("AgBAjQgmgFAIgnQADgQAKgGQALgHAKAKQAdAYABAUQABATgaAAIgJAAg");
	this.shape_130.setTransform(85,-37.5);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#D74F32").s().p("AAEAjQgEgDgIgOIgPgQQgHgHAEgLIATgDQABgWAQAFQATAFgOAUQgKANAPANQAOALgJAGQgHAGgGAAQgEAAgEgDg");
	this.shape_131.setTransform(68.4,-30.5);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#F6CDCE").s().p("AAJAfQgJgGgMgBQgSgCABgYQABgZAXgCQAUgCAKAOQAKAPgKASQgIAPgHAAIgBAAg");
	this.shape_132.setTransform(56.8,-37.4);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#F6CDCE").s().p("AgBAjQgmgFAIgnQADgQAKgGQALgHAKAKQAdAYABAUQAAATgZAAIgJAAg");
	this.shape_133.setTransform(71.1,-34);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#F6CDCE").s().p("AgPAeQgXgJABgWQABgaAfgFQAcgEAFAWQAJAVABAHQABAKgPAGQgLAEgKAAQgIAAgKgEg");
	this.shape_134.setTransform(51.1,-31.1);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#B22632").s().p("AA7BsIgvgDQgMAAgdgEQgagEgOABIgzAHQgcAEgQgFQgKgDgNgNIgSgUQgNgNgFgIQgGgMAAgWIABgeQACgTAHgLQADgEALgGQALgFAEgEIAMgTQAHgMAIgEQA3gXBNAzQBGA7AwgtQBCg7ApAfQAkAcAABKQABAigqAQQgGADghAUQgbAQgWAEQgIABgMAAIgWgBg");
	this.shape_135.setTransform(66.2,-35.4);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#E6CBAB").s().p("AiRBnQgTgRgIgVQgIgUAHgOQARgqApgCIAnAIIAJALQAHANgNAEQgFABgfgLQgVgHAAAXQAAAdAkAIQAlAHAVgXQAFgGgQg/QgQhDAFgNQAHgSAngMQAlgMAMAPQAIAKAEA/QAEA6AFADQAJAHAlgeQAmgggHgTQgGgRgJAFIgYAPQgOAGAAgIIADgKQAJgTAPgKQAdgUAbApQAIAMADAYQAEAggMAcQgiBXiQAfQgWAEgUAAQg3AAgmggg");
	this.shape_136.setTransform(-78.5,21.9);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#64544B").s().p("AiPBbQgTgRgIgVQgIgUAHgOQARgqApgBIAnAHIAJANQAHAMgNADQgGACAGAEQAGAEAJAAQAbABgIgdQgHgaAugTQAxgTABAbQACAPAegaQAjgdgVAJQgOAHAAgJIADgKQAJgSAPgKQAdgVAbApQAFAKADAXQADAggLAeQggBZiPAeQgWAEgUAAQg3AAgmggg");
	this.shape_137.setTransform(-78.7,23);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#704735").s().p("AiSBlQgxgiAQg1QAJgXAWABQAXAAAAAbQgBAZAsgBQAogCAKgOQAHgKAngMQAogKAIAFQAKAFAlgeQAlgggGgTQgIgXAHgSQAHgSARAYQAGAIAIAgQAIAjgBATQgCAsgmAgQgvAohnAWQgbAFgYAAQg1AAgkgZg");
	this.shape_138.setTransform(-78.3,24.7);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#E6CBAB").s().p("AhKCNQgggGgZgTQgUgPgGgNQgUgtAggOQARgIAUACQAGABAEACQAHAEgMAJIgaAMQgIAGALAOQANAPAvgPQAugPgBgLQAAgGgxgjQgzgigFgNQgHgRAfgbQAegcAUAEQANACAvAxQAuAvAIgBQAfgGANgjQAMgjgZgPQgTgMgFAWQgGAhgEADQgKAJgIgNQgEgGgCgJIANgkQAXgjAuAIQAmAEAJA6QALBCg5A+QhYBehQAAQgMAAgMgCg");
	this.shape_139.setTransform(-10.7,-68.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#64544B").s().p("AhLCLQg6gMgYglQgUgtAggOQARgIAUACQAGABAEACQAHAEgMAJQgUANAsgPQAmgNgNgIQgWgQAqgdQAngfATATQAWAXANgXQAFgJAAgGQAAgIgFAFQgKAJgIgNQgEgGgCgJIANgkQAXgjAuAIQAmAEAJA6QALBCg5A+QhVBbhPAAQgPAAgOgDg");
	this.shape_140.setTransform(-10.7,-68.8);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#704735").s().p("AhjCNQgRgKgagZQgXgXgEgJQgMgbAUADQATADAPATQANAQAvgQQAugPAAgLQgBgJAegdQAfgaAMgBQARgBAXgiQAYgkgWgNQgYgPALgUQALgTAaAFQA1AOAEA8QAEA/g8BBQhJBOg5ATQgTAHgTAAQgaAAgXgNg");
	this.shape_141.setTransform(-9.5,-67.3);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#E6CBAB").s().p("AjRBTQgYgcgFglQgFgZAHgQQAWg4ArALQAWAFARARQAFAFACAEQADAKgTgCQgbgGgJgBQgNgBgCAVQgDAVA6AUQA5AUAKgLQAFgFgOhCQgPhFAIgPQAKgUA1gDQAzgDAPASQAKALABBQQAABKAJAFQAiARAsgXQAsgWgKgeQgHgYgYAQQgkAYgHAAQgSABAFgRQACgJAGgJIAugXQA2gPAiApQANANgDAXQgDAagUAaQgzBDhvAQQguAGglAAQh/AAg2g+g");
	this.shape_142.setTransform(66.6,-99.1);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#64544B").s().p("AjPApQgXgdgGgiQgFgZAEgNQAWg4ArALQAWAFARARQAFAFACAEQADAKgTgCQgfgCA3ASQAuAQgDgRQgGgeBDACQBCACgBAfQgBAkAigLQAMgEAGgHQAHgGgJAAQgSACAFgSQACgJAGgJIAugXQA2gPAiApQANANgDAZQgDAagUAYQgzBDhvAQQgrAGgiAAQiBAAg3hDg");
	this.shape_143.setTransform(66.7,-95.4);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#704735").s().p("AijBdQg6gUgSgxQgHgVgBgmQAAgmAEgMQAOghAQASQAOAQgDAcQgCAXA6AUQA5ASAKgIQAIgJA3gDQA2gDAMAIQARAKA0gNQA4gPgJgcQgJgfAdgJQAcgKATAYQAkAzgzA2Qg2A8h2ARQg3AHguAAQhBAAgrgOg");
	this.shape_144.setTransform(67.2,-92.9);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#C6A27A").s().p("Ah6CBQgagJgQgRQgPgQADgOQACgsArgNIArgEQAJAEAGAFQAMAKgMAHQgFADglgBQgZgBAIAUQALAcAhgBQAjgBAbghQAFgGgeglQgggnABgMQABgSAlgWQAlgVAPAKQANAHARApQAQAlAFgCQAfgLATgfQAUgfgOgQQgMgNgJAGQgKANgKAHQgMAJgDgHQgBgEABgFIAPggQAYgbArAdQAMAIALAVQAPAcgCAeQgGBViPBEQgwAWgtAAQgdAAgcgKg");
	this.shape_145.setTransform(-23.7,-133.8);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#64544B").s().p("Ah3CBQgbgJgPgRQgPgQACgOQACgsAsgNIArgEQAIAEAHAFQAMAKgNAHQgGAEAHABQAIACAKgCQAcgHgTgZQgCgDAqgcQApgdABADQAGANAXgfQAbgkgTAOQgMAJgCgHQgCgEABgFIAPggQAYgbArAdQAJAIAKATQAOAcgBAeQgDBYiOBDQgwAWgsAAQgeAAgbgKg");
	this.shape_146.setTransform(-23.9,-133.8);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#836C5F").s().p("Ah7CPQg9gRgBgzQgBgoAXAAQAVABALAdQAJAXAtgOQAqgNAGgPQAEgLAlgWQAmgUAKADQAMACAcgmQAdgngNgPQgWgZgBgUQgCgXA0AiQAHAFAOAaQAMAYAGATQAOAqgdAlQgkAxhmAwQg6AbgyAAQgXAAgVgGg");
	this.shape_147.setTransform(-23,-132.4);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#C6A27A").s().p("AiyAgQgPgaABgeQABgYAIgNQAagsAhANQAQAHALAPQAEAFAAAEQABAIgPgDIgbgJQgLgDgEASQgGAUAfAUQAfARAggDQAGAAgCgnQgCgtAIgLQALgRApADQArAEAJAQQAGAKgMAyQgKAtAHADQAnASAggOQAegOgDgbQgCgWgWAMQggARgGgBQgOAAAHgPQADgHAGgHIAogPQAtgIAVAnQAIAMgGASQgHAWgUAUQgzA0haADIgIAAQiWAAgqhKg");
	this.shape_148.setTransform(20.6,-43.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#64544B").s().p("AixAXQgOgZABggQAAgVAFgLQAagsAhANQAQAHALAPQADACAAADQABAGgMAJQgPAKAgAKQAgAJAAgQQAAgDAzAIQAxAIgBAEQgGAdAdgFQAJgCAHgFQAGgEgIgBQgOAAAHgPQADgHAGgHIAogPQAtgIAVAnQAIAMgGASQgHAWgUAUQgzA0haADIgIAAQiUAAgphOg");
	this.shape_149.setTransform(20.8,-42.6);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#836C5F").s().p("AiTBQQgrgXgGgrQgDgTABgaQABgdAFgIQAfg2AJAWQAIATgJAgQgFATArAXQApAUAKgIQAIgFAsACQAqADAJAIQALALAsgHQAvgHgDgXQgCgfATgJQAVgLAQAlQAVAtgwApQgzAthgADIgHAAQhqAAg0gbg");
	this.shape_150.setTransform(21.1,-41.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#8D7155").s().p("AgCAaQgrgFgIgSQgIgRAVgIQARgHAbAEQAcAEAPALQARALgOAQQgJAKgZAAIgSgBg");
	this.shape_151.setTransform(-70.5,-10.4);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#C6A27A").s().p("AgOBqQgrgFgIgSQgFgNALgsQAKglgGgBQgggJgiANQgiALACAVQABASALAAQAQgEAMAAQAPAAgCAIIgFAHIgfARQgjAHgRgxQgFgOADgWQAFgfATgXQA5hCCaAgQBYAUAoA8QAQAWACAXQADAVgLAKQgcAigqgQQgVgIgQgOIgGgQQgEgQAOACQAGABAdAXQATAPAGgUQAIgdgbgRQgdgUgqAKQgHACABAuQACAzgIAJQgIALgaAAIgSgCg");
	this.shape_152.setTransform(-69.3,-18.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#64544B").s().p("ABxBaQgWgIgPgOIgHgQQgDgQAOACQAIABAWAUQASAPAHgIQAEgFgzgZQgwgXABAeQAAAEgygBQgzgCAAgEQADgOglALQgrANAYAAQAPAAgCAIIgGAHIgfARQgjAHgRgxQgCgMADgVQAGgdASgXQA4hHCYAgQBZAUAoA8QAQAWACAXQACAVgKAKQgUAXgZAAQgMAAgNgFg");
	this.shape_153.setTransform(-69.2,-19.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#836C5F").s().p("ABvBkQgQgJgWgcIgGgZQgDgZAOACQAIABAaAgQATAYAGgVQAHgXgsgQQgqgNgNAGQgKAHgqgGQgsgFgHgGQgIgKgtAOQgvAMACAUQABAQAOgHQAYgNAIAAQAPAAgFARIgJAQQgYAYgKACQgdAGgUg5QgDgKABgXQACgXAGgSQAehbDFApQBeAVAmAxQAkAsgdAqQgeAkgZAAQgHAAgIgDg");
	this.shape_154.setTransform(-69.2,-17.3);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#A78F72").s().p("AgJATQgygTgCgWQgCgWBFAfQBIAegUALQgHAEgLAAQgTAAgegNg");
	this.shape_155.setTransform(-81.4,-98);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#E6CBAB").s().p("AhFCOQgygVgCgWQgCgRAlg8QAkg5gDgHQgGgNg8AAQg9AAgGAWQgFAUANADQAVACAPAEQASAEgGAHIgJAGIgOAFQgQAEgOgBQgtgFgCg6QAAgRANgYQASghAggSQBeg1CtBZQBjA0AaBPQAJAfgFAaQgGAYgQAIQgvAbgtggQgWgQgOgWIgBgTQABgSAQAHQAHADAaAjQARAXAPgVQATgaghgkQgigjgmAFQgKABgZBHQgbBKgMAIQgHAEgLAAQgTAAgggNg");
	this.shape_156.setTransform(-75.4,-110.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#64544B").s().p("ABzB+QgWgQgOgWIgBgTQABgSAQAHQAJAEAUAcQAQAXALgGQABAAgOgRQgPgSgQgOQgxgqgLAiQgKAdg+gVQhBgVAQgaQAJgNgxAAQg5gBAdAGQASAFgGAIIgJAGIgOAFQgQAEgOgBQgtgFgCg6QACgNAMgWQATggAfgTQBfg6CrBYQBjA0AaBPQAJAfgFAaQgGAYgQAIQgWAMgVAAQgYAAgZgRg");
	this.shape_157.setTransform(-75.4,-111.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#704735").s().p("ABuCDQgXgQgNgVIACgeQAFgcAQAHQAKAEATAsQAOAhAPgUQARgYgvghQgtgfgTAFQgOAEgxgWQgzgTgFgLQgGgNg8gBQg+AAgFAWQgFASAUgDQAhgGAKADQASAFgNAOIgQAQIgOAEQgQAFgOgCQgtgFgCg5QAAgMAKgZQAMgbAOgRQAhgoA9AAQBNABB7A/QBpA4AcBBQAZA/gzAkQgWANgVAAQgZAAgYgSg");
	this.shape_158.setTransform(-75.8,-109.7);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#EFDC69").s().p("AAoAnQgUgfgUgKQgXgPgOARQgNAOgGgKIgQgaQgIgMAGgCQASgEALgIQARgNAPAKIAiAdQAbAUAMAIQAVATgDALQgDANgHAFQgEADgDAAQgJAAgMgSg");
	this.shape_159.setTransform(-62.4,-85.3);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#A09434").s().p("AAlAvQgUgfgTgNQgYgNgOAQQgOAQgKgJIgUgaQgNgSAAgFQAAgHATgQQAWgTAdAVQAdAfAQAMIAyAiQAgAagDAKQgCAKgTACIgEABQgUAAgPgWg");
	this.shape_160.setTransform(-62.1,-86);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#EFDC69").s().p("AAlAjQgTgagSgFQgVgEgNAaQgLAZgGgIQgEgFgKgVQgIgKAFgFQARgMAKgPQAOgXAOAEQAJACAWAPIAkAQQATALgCAMQgDARgGAKQgFAHgGAAQgGAAgIgLg");
	this.shape_161.setTransform(66.5,-76);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#A09434").s().p("Ag5AzQgGgDgNgUQgMgPAAgFQAAgIAQgaQAUghAaALQAPAGAbAUIAuASQAdALgDAOQgBAMgRANQgVAOgPgUQgTgagRgFQgWgFgMAbQgJAVgIAAIgEgBg");
	this.shape_162.setTransform(66.7,-76.5);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#EFDC69").s().p("AgVBbQgWgGgLgIQgUgPAcgRQAkgWAIgXQAHgbgggTQgegRALgHQAHgFAcgLQAMgJAFAHQAQAXATAPQAcAWgHARQgPAVgKASIgZAtQgMATgPAAIgGgBg");
	this.shape_163.setTransform(38.1,-69.7);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#A09434").s().p("AgkByQgQgEgNgXQgRgcAcgRQAkgWAIgWQAJgcgigTQgfgSAIgMQAFgHAbgOQAUgOAGAAQALABAhAYQAoAegQAhQgdAhgKASQgRAmgLAUQgRAggQAAIgEgBg");
	this.shape_164.setTransform(38.9,-69.4);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#EFDC69").s().p("AAAAuIgmAAQgXgDgDgOQgEgRACgLQACgRAWANQAcAOASgEQAWgEAAgcQABgaAIAEQAOAOAKAFQALAGgDAGQgKARgDATQgEAagOACIgHABQgKAAgTgDg");
	this.shape_165.setTransform(-118.3,-76.7);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#A09434").s().p("AAAAuIgwACQgggBgEgNQgDgMALgSQANgUAVANQAdAOARgEQAWgEABgcQAAgcALACIAaAOQASAJACAEQADAIgEAdQgFAngcABIgCAAQgQAAgggHg");
	this.shape_166.setTransform(-118.4,-76.7);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#EFDC69").s().p("AgeALQAWghAggPQATgIgCAoQgDAngRgDQgmgOgFAIQgCAEgBAIIgJACQgNAAARgcg");
	this.shape_167.setTransform(-77.9,-131.8);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#A09434").s().p("Ag2ArQgFgJAGgPQAQgnA1gZQARgIAMANQALALABATQABASgKALQgNAMgWgIQgjgNgBAMQgBAWgNAEIgHABQgHAAgDgGg");
	this.shape_168.setTransform(-77.1,-131);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#EFDC69").s().p("AgXAYQADgpgJgDQgFgBgIACQgRgYApAMQAmALAZAcQANAQgoAJQgOADgHAAQgSAAgCgMg");
	this.shape_169.setTransform(-104,-100.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#A09434").s().p("AgBAwQgPgIABgZQADgmgNADQgWAEgIgLQgIgLAIgHQAHgHASABQAqAEApAvQAMANgJAPQgIAOgSAHQgKADgIAAQgIAAgFgEg");
	this.shape_170.setTransform(-104.8,-99.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#EFDC69").s().p("Ag0BBIgPgcQgMgeAMgLQA2hSAQAFQAFACALANQAMAMAMADQAhAHgCAQQAAAHgUAbQgeAugNANQgQARgRAAQgQAAgOgRg");
	this.shape_171.setTransform(36.2,-135.9);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#A09434").s().p("AguA/IgHgJQgNgKgagGQgagGASgNIAngZQA2hSAQAFQAFACALANQAMAMAMADQAlAIAPAaQAOAYgOAWQgSAcguATQgWAKgQAAQgbAAgSgVg");
	this.shape_172.setTransform(35.6,-135.7);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#EFDC69").s().p("AgUAQQgYgEAHgNQADgFAFgEQAKgJAIABQAwABACAHQgGAJAEAFQAGAMgIACIgVABQgagBgIgCg");
	this.shape_173.setTransform(-103.3,-63.1);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#A09434").s().p("AAQAfQgQgBgTgKQgZgMAHgNIACgEQABgFgEgJQgEgJAKADQAPAGAHABQAwABACAHQgGAJADAFQAHANgIAJQgGAJgNAAIgBAAg");
	this.shape_174.setTransform(-103.3,-62.7);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#EFDC69").s().p("Ag8AsQgQgCgOgTQgJgLAhgJQAjgIgCgNQgEgTA5gFQA5gFAGARQAPAVgJAIQgDABgfAKQgOAFgbAAQgSABgRANQgTAPgQAAIgEAAg");
	this.shape_175.setTransform(99.9,-40.1);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#A09434").s().p("AhHA3QgQgCgOgTQgJgLAhgJQAjgKgCgLQgEgYA6gRQA/gRAYAjQAPAVgUAUQgQATgcAKQgQAFgbgJQgVgJgQANQgTAPgQAAIgEAAg");
	this.shape_176.setTransform(101,-41.2);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#EFDC69").s().p("AAfAlQgNgFgSgRQgNgMgTgBQgugCADgpQABgNAbANQAeAPAGgKQAKgQAoAhQArAdgGAPQgDAXgLABQgEAAgbgMg");
	this.shape_177.setTransform(-114.8,-55.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#A09434").s().p("AALAuQgNgGgNgXQgKgSgTgBQgugCADgrQABgNAbANQAeAPAHgKQAMgTAxAZQA1AagEAkQgDAYgbAEIgKAAQgSAAgTgIg");
	this.shape_178.setTransform(-113.7,-54.6);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#EFDC69").s().p("AAuBiQgEgBgMgOQgdgkgNAKQgZASgHgEQgKgFAEgsQABgTgBgbQAAgYAMgPQAEgFAOADQAMADAKgWQAIgOACABQABABABAMQABAhAKAHQANAJAIA1QAGApAAAWQAAARgFAAIgBAAg");
	this.shape_179.setTransform(-21.5,-99.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#A09434").s().p("AgvB2QgRgKAEgrQADgiAHgdQAIgjANgQQAEgGAOAEQALADALgXQALgTAHgYQAGgMAPAKQANAJgTAjQgUAjAKAHQANAJAIA1QAGAoAAAWQAAAfgYgKQgigOgLAJQgQALgMAAQgGAAgFgDg");
	this.shape_180.setTransform(-22.4,-100.5);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#EFDC69").s().p("ABPA4QgdgNgKAFQgNAIgwgPQgmgLgSgJQgQgIAEgEQACgDARgEQAqgJgDgRQgEgcAGgEQAIgHAiAVQAPAJAaAKQAUAKAIAOQADAFgIALQgIAJAOAUQAJALgCACIAAAAIgLgDg");
	this.shape_181.setTransform(72.9,-55.8);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#A09434").s().p("AA8BDQgWgfgJAFQgNAIgwgPQgmgLgSgJQgagMASgPQAZgYgCgNQgFgcANgJQAQgLAkAVQAZAQAWASQAcAVAJASQADAEgIAKQgIAJAOAUQANARARAQQAIAJgPAJQgDACgDAAQgLAAgSgZg");
	this.shape_182.setTransform(74,-55.1);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#EFDC69").s().p("AgLBYQgIgCgKgQQgJgPgZgBQgPAAgCgDQAAgCAHgGQAVgTgEgOQgGgQAcglQAVgbANgMQAMgJAEAHQADAFABATQADAwATAKQAiAQAEAJQAFANggATIgfAZQgMAIgMAAIgJAAg");
	this.shape_183.setTransform(89.6,-6.6);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#A09434").s().p("AgEBXQgHgBgKgQQgJgPgagBQgjAEgJAAQgMAAgHgVQgGgSAoACQAoACgEgNQgFgQAcglQAUgbANgMQAUgQAPAeQAVArAQAIQAhARAHARQAJAXggATQgYAOgZAIQgWAHgRAAIgMgBg");
	this.shape_184.setTransform(88.8,-6.6);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#EFDC69").s().p("AAMA1QgLgCgRAAQgPgCgKgMQgDgEACgPQADgNgPgLQgMgMANAAQAVAAAFgKQAGgNAhgHQAagGAOABQASABgRAWQgXAdAGAOQAKAbgCAHQgDAHgNAAIgQgBg");
	this.shape_185.setTransform(-92.6,-6);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#A09434").s().p("AAoA/QgVgEgTgIQgVgKgKgOQgEgEADgPQACgLgOgNQgMgMgPgIQgIgGAHgQQAGgOAWAWQAWAVAEgJQAGgNAhgHQAagGAOABQAUABgHAZQgJAkAFALQAKAagGAPQgFANgSAAIgLgBg");
	this.shape_186.setTransform(-93.6,-5);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#EFDC69").s().p("AgQBAQAGgZgFgIQgZgfgBgZQgBgdAagSQAQgGAQAFQATAHAFAVQACANgEAIIgTAXQgEADARAUQAQAUgKAKQgLAMgSAGQgJAEgGABIgGABQgIAAAEgMg");
	this.shape_187.setTransform(-55.6,-131.6);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#A09434").s().p("AgVBDIgNgjQgwgzAUgUQALgMAsgRQAagTAXAMQAUAKAFAaQAEAQgDAMQgEAMgMAPQgEAEAFAOQAEANgKAKQgLALgSAHQgKADgHABIgGACQgLAAgFgOg");
	this.shape_188.setTransform(-56.5,-132.1);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#EFDC69").s().p("AgugXQAUgQAVgCQATgBAUAQQANAQgBARQAAAXgVALIgCABg");
	this.shape_189.setTransform(28.9,-5.7);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#A09434").s().p("Ag/gfQAhgvAZAQQAMAKAfAlQAbATgBAaQgCAWgVAPg");
	this.shape_190.setTransform(28.6,-6.8);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#EFDC69").s().p("AAGA0QgRgHgDgIIgEgZQgBgGgrgCQgqgCAAgKQAAgOAOgQIANgMQALgNAOANQAVATAPACQA+AEAhAQQAiAPgKAbQgNAPgaAHQgMADgMAAQgRAAgRgGg");
	this.shape_191.setTransform(-25.5,25.6);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#A09434").s().p("AgZA5QgWgHgKgKQgNgKgCgRQgBgGgVgFQgUgDAAgMQAAgOAOgQIANgMQAMgPAfAHQAkAMAQACQBRADAYALIACAhIgMANQgHAKgDAHQgKAdgoAHQgKACgLAAQgWAAgZgJg");
	this.shape_192.setTransform(-24.5,26.1);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#EFDC69").s().p("AgQA5QgPgPgBgWQgBgNAFgGIARgJQAEgDgMgaQgMgbAJgEQAQgIAVAJQAMACgFANQgHAUADAKQARAmgCAaQgBAbgXAEQgNgDgMgNg");
	this.shape_193.setTransform(69.9,-15.3);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#A09434").s().p("AAbBJQgSgCgHABQgWAEgRgWQgPgTgCgaQgBgOADgKQAEgLAMgIQAEgCgDgPQgDgOAJgEQAQgIAVAJQAOACAEAVQADAbAEALQAhBHgRAIQgDACgHAAIgMgBg");
	this.shape_194.setTransform(70.6,-15.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#EFDC69").s().p("AACAaQgGgDgBgEIgCgNQgBgDgSgBQgSgBAAgEQAAgMALgKQAFgGAGAGQAJAKAHABQAaACAOAIQAPAHgFAOQgFAHgLAEIgLABQgHAAgIgDg");
	this.shape_195.setTransform(-128.5,-29);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#A09434").s().p("AgMAdQgTgIgCgPQAAgDgJgCQgIgBgBgGQAAgMAMgKQAFgHANAEQARAFAFABQAzACAAANQgLAOgDAKQgFAPgQADIgKABQgIAAgLgEg");
	this.shape_196.setTransform(-127.9,-28.7);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#EFDC69").s().p("AAHA8QgHgBgEgTQgGgSgFACQgEACgFAUQgEAPgIgKQgbgxASgiQAPggAeAFQATADAWAcQAWAcgRgEQgLgDgLAhQgLAigGAAIAAAAg");
	this.shape_197.setTransform(67.8,-116.8);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#A09434").s().p("AAIBTQgGgBgIgVQgKgSgFACQgCABgGAKQgDAEgJgLQgeg2AQgoQARgqA6AGQAoADABAmQAAAPgFAKQgGALgIgCQgLgCgJAtQgHAugGAAIgBAAg");
	this.shape_198.setTransform(68.3,-116.6);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#EFDC69").s().p("Ag4A+QgDgJASgUQAQgTgGgEQgFgEgbAIQgUAFAGgQQAng+AzgEQAwgFAOAoQAEAIAAAQIgtgqIAHBmQgLgHgqAKQgYAGgLAAQgIAAgBgDg");
	this.shape_199.setTransform(-21.1,-43.1);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#C29E30").s().p("AhmBRQgDgJARgZQAOgYgGgEQgCgCgQgBQgHAAAHgQQAshIA3gJQA8gJAjBJQAMAYgJAWIhWhQIAGBnQgLgGg3AWQgmAPgMAAQgEAAgBgCg");
	this.shape_200.setTransform(-19,-42.6);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#EFDC69").s().p("AgQAxQAHgKgcgbQgdgYAEgFQAEgGAWADQATACAAgGQAAgEgQgOQgNgLAOgDQA5gDAaAhQAYAbgUAbQgLASglAJQgMADgHAAQgMAAAIgJg");
	this.shape_201.setTransform(-112,-2.6);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#A09434").s().p("AAKBDQgMgGgHgKQgIgLAFgGQAIgKgqgbQgpgeAEgFQAEgFAYgBQAWAAAAgGQAAgCgGgLQgDgFAOgDQBBgDAfAhQAhAjghA1QgPAZgWAAQgJAAgMgFg");
	this.shape_202.setTransform(-112.5,-1.1);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#342D2C").s().p("AgmAeQgQgNAAgRQAAgQAQgNQARgMAVAAQAXAAAQAMQAQANAAAQQAAARgQANQgQAMgXAAQgVAAgRgMg");
	this.shape_203.setTransform(-36.8,-3.2);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#427136").s().p("AhRBUQgZgVgIgzQAAgyAegiQAfgiA1AAQAzgBAhAmQAfAlAAAzQgCAmgfAYQghAbgzAAQg1AAgagYg");
	this.shape_204.setTransform(-36.8,-3.2);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#342D2C").s().p("AhbBXQgngkAAgzQAAgyAngkQAmglA1AAQA2AAAmAlQAnAkAAAyQAAAzgnAkQgmAlg2AAQg1AAgmglg");
	this.shape_205.setTransform(-36.9,-2.7);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#342D2C").s().p("AgmAeQgQgNAAgRQAAgQAQgNQAQgMAWAAQAXAAAQAMQAQANAAAQQAAARgQANQgQAMgXAAQgWAAgQgMg");
	this.shape_206.setTransform(27.2,-101.5);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#427136").s().p("AhSBVQgYgWgIgyQAAgzAegiQAfgjA1AAQAzAAAhAmQAfAlAAAzQgCAmgfAZQghAagzAAQg2AAgagXg");
	this.shape_207.setTransform(27.2,-101.5);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#342D2C").s().p("AhbBYQgmglgBgzQABgyAmglQAmgkA1AAQA2AAAmAkQAmAlAAAyQAAAzgmAlQgmAkg2AAQg1AAgmgkg");
	this.shape_208.setTransform(27.1,-101.1);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#342D2C").s().p("AgmAdQgQgMAAgRQAAgQAQgMQARgNAVAAQAXAAAQANQAQAMAAAQQAAARgQAMQgQANgXAAQgVAAgRgNg");
	this.shape_209.setTransform(-73.2,-64.4);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#427136").s().p("AhRBUQgZgVgIgzQAAgzAeggQAfgkA1ABQAzgBAhAmQAfAlAAAzQgCAngfAYQghAZgzABQg1AAgagYg");
	this.shape_210.setTransform(-73.2,-64.4);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#342D2C").s().p("AhbBYQgnglAAgzQAAgyAnglQAmgkA1AAQA2AAAmAkQAnAlgBAyQABAzgnAlQgmAkg2AAQg1AAgmgkg");
	this.shape_211.setTransform(-73.4,-63.9);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.lf(["#C9623B","#F1A328"],[0,1],-2.8,13.8,2.7,-12.3).s().p("AiwBgQgbgOgFgYQgBgEAAgxIgFgFQgCgEADgWQAXgEAYgXQAagdANgNQAbgYAagHQAZgHAnAEQA5AGA3AXQBDAcAcAoQA0BJhZAyQhIAohTAAQh0AAhBgjg");
	this.shape_212.setTransform(-65,-29.6);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.lf(["#C9623B","#F1A328"],[0,1],-24.4,0,24.5,0).s().p("AjhDrQgUgLACgMIAIglQAGgzAdg1QAnhGAzALIBbATQAVgGg1glQg+gtAJgSQALgWAggXQAggYANgTQAbgxAYgNQAYgNA5ADQByAFAOBNQAHAqgrAaQg2AggIATQgKAtgFAPQgGAXgkASQguAZgWAPQggAYgVAfQgZAmgTAIQgQAHg3ABQgIAAggAOQgSAHgKAAQgHAAgDgCg");
	this.shape_213.setTransform(28.8,-66.1);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.lf(["#C9623B","#F1A328"],[0,1],-12.2,8.8,11.4,-9.6).s().p("Ag3BpQhagQADgjQABgZAMgJQAKgJAAgMQAAgQgQgOQgOgMAGgMQAJgVASgDQAZgBASgFQBigeAqAFQApAFAgAsQAOATgVAOQgiAWgGAKQgDAHACApQACAjgMAHQgeASgvAAQgaAAgigHg");
	this.shape_214.setTransform(-96.7,9.5);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.lf(["#C9623B","#F1A328"],[0,1],15.6,0.5,-15.5,-0.5).s().p("AgMBqIhtgGQglgJACg4QACglALgLQAFgFgOgvQgJgYBGgKIBdgJQAzgGA1AfQA7AigKAvQgEARgSAdQgQAagRASQgTAVgfABIgHAAQgTAAgkgEg");
	this.shape_215.setTransform(-88.4,-86);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.lf(["#C9623B","#F1A328"],[0,1],5.3,-4.3,-15.4,23.2).s().p("AgwgMQAJgIAJgXQAUgzAZAYQAcAYAFBHQABAfAAAXg");
	this.shape_216.setTransform(17.8,-17.5);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.lf(["#C9623B","#F1A328"],[0,1],10.3,14.5,-9.3,-15.8).s().p("Ag/B5QgdgIgXgWQgTgSgSgfQgbgvgFgoQgFgvAmAKQAoAJAAgFQAAgDgagkQgTgbBmAaQBzAjAXAFQA8APAFADQAcANAFAkQAFAegCAcQgEAjgOASQgXAchYADIgTABQg6AAgqgLg");
	this.shape_217.setTransform(-4.3,-82.3);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.lf(["#C9623B","#F1A328"],[0,1],13.9,-5.7,-14.4,4.5).s().p("AhcBEQgtgHgGgOQgIgTAggIQAlgIABgMQACgPgPgHQgQgIAAgQQABgVA0gEIBVAAIBPgBQAnAHAAArQgCBQiLANQgSACgTAAQgfAAgdgFg");
	this.shape_218.setTransform(7.3,-141.3);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.lf(["#C9623B","#F1A328"],[0,1],0,9.8,0,-9.6).s().p("AgXBfQhIgIgMgZQgZg0gBgYQgBgoA3AHQAzAGARgVQAJgKgCgMQAQgSAwAIQAyAJAPAXQASAcgSA2QgSA3gfANQgVAJglAAQgSAAgXgCg");
	this.shape_219.setTransform(40,-126.6);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.lf(["#C9623B","#F1A328"],[0,1],-10.3,0,10.4,0).s().p("AARClQgVgLgwgCQgggBgKgWQgUgrAbg+IAVgtQALgZAAgQQABgcANADQAMADgCgQQgEgtAUgSQAQgPAeAKQAdAKAVAaQAXAdgBAgQAAAOgLAbQgLAcgCALIgTAnQgKAXAYAZQAeAggWAcQgOARgUAAQgOAAgRgIg");
	this.shape_220.setTransform(40.9,-38.8);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.lf(["#C9623B","#F1A328"],[0,1],-2.6,11.2,1.8,-9.8).s().p("AAaB5QgqgBgbgUQgggZgQgbQgRggAOgTQAJgNAZgIQAOgEgLgQQgqg3ADgQQAFgbCaB6QAYATAKAhQAKAlgQAaQgQAagtAAIgEAAg");
	this.shape_221.setTransform(89.7,-74);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.lf(["#C9623B","#F1A328"],[0,1],-5.4,5.7,8.3,-5.8).s().p("AgFBtQgggVgEgnQgBgNgggxQgYgnAVgVQARgRATADQARACATgXQAWgcAhAoQAdAiAFAeQAGAkgDAmQgDAygUAOQgTAOgTAAQgRAAgOgLg");
	this.shape_222.setTransform(86.5,-28.7);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.lf(["#C9623B","#F1A328"],[0,1],-14.2,0,14,0).s().p("AiKgnQAHgeAUgLQAdgSAQAKQAXAOATgDQAYgEAEgTQAEgXAPgHQAcgMApAcQAsAeADApQACAagQAXQgXAkgDAKQgGATgCAUQgEAOgTAQQgLAIgMAFg");
	this.shape_223.setTransform(65,21.2);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.lf(["#C9623B","#F1A328"],[0,1],-12.7,0,12.9,0).s().p("AATCUQgLgJgcgdQgygyggg8QglhCASgeQAOgWAiAXQAgAWAJgUIAOgiQAIgVAIgJQAWgbAwAoQA3AvAFA6QADAlgYBSQgGATAAAmQgEAegeACIgDAAQgSAAgbgVg");
	this.shape_224.setTransform(-52.2,45.6);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#F4B54F").s().p("AAYCBQgpgMgLgBQg1gCgTgIQghgNgHgoQgEgagLgXIgMgXQgEgJAHgEQAGgDAagGQAZAHAcACQA4AGALgSQAIgNgOgfQgNgaASgKQAkgWBXASQBEAOgKAzQgDAQgOAhQgQAigEAQQgGAWgHAoQgKAegfAIIgMABQgPAAgagIg");
	this.shape_225.setTransform(-33.1,-6.8);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.lf(["#C9623B","#F1A328"],[0,1],-18.1,10,19,-9.6).s().p("AhUBeQgigagoAFQgpAFAEgJQAJgUgHgIQgMgPAPgPIAbgYQAbgpAJgHQAPgNAqgGQATgEAoALQAmAKAUgDQARgCAigeQAegaAXAFQAfAGALAYQAKAWgIAjQgIAfgjAdQgqAggSASQgeAfgZAHQgRAFgzAAQgQAAglgbg");
	this.shape_226.setTransform(-41,-62.6);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.lf(["#C9623B","#F1A328"],[0,1],-11.6,11,11.3,-14.4).s().p("AgTCGQhIgJgngdQgzgmAXg6QASgtgDgiQgCgYAPgOQAUgUAyAAQBBACAqAAQAyAAAUAGQAlALAKAlQAHAbgUAXQgbAYgJAOQgJAPgDAzQgDArgTAOQgNAJgkgBQgbAAgYgEg");
	this.shape_227.setTransform(-43.7,-117.4);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.lf(["#C9623B","#F1A328"],[0,1],-2.2,11.7,2.5,-11).s().p("AgpBsQg8gegCgrQgBghgHAEQgTAMgOgDQgZgGAkg7QAjg6AYgLQAVgJAQAGQALADATARQAzAuA4AQQBPAYghA2QgbAthBAiQgPAIgSAAQgaAAgkgRg");
	this.shape_228.setTransform(-109.3,-33.3);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#F9C21E").s().p("AkmScQgIgPgagDQgIgBgxAAQhZAAgsgoQgQgPgRg0QgSg8gQgXQgUgdgfgEQgMgBhJAFQhSAFhUhFQhNhBglhaQgthvgIgmQgLgsgQimQgCgXg1gRQg5gSgIgcQgVhGgBhWQgBhqAngPQBFgaAqhCQAlg6gEgvQgFg5gvgEQgMgBgYABQgUAAgHgIQgWgZAogsQA0gwAPgTQAXgeAEgpQADgWgEgzQgDgrAFgTQAIgdAegMQAxgUAVgmQANgaAFgvQAGg1AFgPQAMghAigLQARgGAQAJIAdATQAoAbAzgbQAcgPAXgzQAag7AVgUQAhAOAkABQBJADAbhEQAbhCA4gFQBOAGA1gDQAIAAAfAwQAfAwAKgBQASgDgBgpQAAgqAagHQAOgEA8gfQA5geAXgFQCAgcAcAvQAMAeAIAPQAPAdAdANQAZAMBAgBQBIgCATAEQAqAKArAlQAWATAyA4QAtAzAdAWQAsAiAuAEQBYAJA3A+QAsAyARBOQADAOgeBIQgdBEAHALQAZAnBDAUQA8ATAHAYQARA1APAaQAVAlAmAZQAdATgBAfQAAAXgRAqIgeBGQgNApAIAbIAvBtQAjBTgRATQgKAMhJgWQhFgUAAANQgCAXARAnQAJAWAXAtQAlBSgpAaQg3AigGA4QgCAQgBAjQgCAhgJAaQgFAQhGAOQhGANgFAPQgEAKAoAzQAnAygFAKQgOAagXA5IvZukIBGRcQggAzgRAJQhXAsg0AMQgaAHgUAAQguAAgQggg");
	this.shape_229.setTransform(-10.7,-45);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#C26A33").s().p("Ak0S4QgOgJgdgBIg5gBQhQgDgwgsQgQgPgRhAQgShHgRgZQgRgYgvAKQg6AMgTgIQhagihIg7QhQhDghhSQgTgugcgpIgshAQgwhLgNiLQgDgXgbgMQgegOgIgcQgRg2AGheQAFheAWgqQASglBKhMQA8g9gDgfQgCgPgsgBQgyAAgLgNQgagdAGg8QAGg3AaghQAXgdAPgtIAVhNQAXhZAxgUQBXgiAYhLIASg+QAOgkAagZQAQgPAzANQA5ANAPgHQAegNAXg1QAbg/AVgUQAdgIAggKQBAgTAVgRQA1grBDgEQBUADA2gDQAJAAAUAaQATAaAKgCQATgDAHgcQAGgeAcgIQANgDAmgRQAjgPAWgFQCJgfAxAiQAIAFAeAfQAZAaAcANQAbAMA3ACQBCACASAEQA8AOCJBnQCCBiBKAIQBWAIAkBGQAPAbAXBuQADAOgQBCQgQA+AIAMQAZAmA3AfQAvAaAIAbQARA2APAaQAXAnAnAaQAxAggXBvQgPA9gFAeQgJAwAIAdQAUA/AJAqQARBOgSAUQgLAMg5gZQgzgXgBANQgBAYAMAjIAYA7QAZBFgrAbQg7AkgQBHQgKBUgPAsQgFAQgqAMQgqANgGAPQgEAKAWAoQAWAogGAKQgVApgZAkIvtu4IBJSHIgXAbQgQASgPAIQhEAihBAKQgYAEgVAAQgvAAgggTg");
	this.shape_230.setTransform(-10.5,-44.4);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#F9E3B0").s().p("AlBTsQgTgKgxgGQhGgHgZgFQiFgchQh3Qghgxg5gpQgXgRhSgxQhBgnghggQgxgtgYg6QgUgxgjgqQgUgYgpgqQhJhTgNiNQgGg5gXiGQgOh3AhhBQAjhHAFhFQADgtgKhBQgKhDABgZQACgvAegnQAYgfAQguQAEgNARhDQAYhdA0gVQBagjAZhOIAUhBQAOgmAbgZQA3g1CFgwQCQgzBGg4QAuglAzgJQAcgEBJACQChAECRhDQBigsCFA2IBxAzQBEAfAyALQAsAKA6AlQAbARBMA6QCHBmBOAHQBuALAiB0IAWBiQANA5ASAcQAtBGAtCNQAgBlA/ApQAzAigYB0QgPA/gFAfQgJAyAIAfQAmCRgIBWQgMB3hhA8Qg9AmgRBJQgKBYgPAtQgfBbgPAjQgeBEgnAsIwRvZIBQT/QgggCgzAKIhXASQgnAHggAAQg3AAgjgVg");
	this.shape_231.setTransform(-10.5,-44.6);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#F2CF9E").s().p("AlMUbQgjgVg2gRQgfgKhCgSQh+gnhPhOQgngmg/gqIhshGQiAhXgrhrQgehIhViDQhKhygWhPQgYhXgDhrQgChrAThbQALgzgBhGQAAgogDhNQgDiJA3hGQAigsAihwQAcheAuggQA8grAohRQAthbAmglQA5g3CMgyQCVg1BJg6QBRhCClgNQBcgFAvgFQBSgIA6gSQBrghCJAzIBzAwQBHAdAzALQBWATCKBYIDTCHQBkA4AqBnQAgByAgAxQAvBIA0BsQBFCQAZAsQAdA2gQBzQgSCAALApQAgB5gVBkQgTBehKBwQgjA1gbBFQgIAVgmBwQgbBRgXAvQggBCgsAuIwzv5IBUU2Qg2AFh8AaQggAEgdAAQhCAAgsgZg");
	this.shape_232.setTransform(-10.8,-44);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#E6BA7F").s().p("AlaVBQg+gkiNg5QiHg2hBgpQgngYhNguQhEgpgqghQh3hagxh5QgbhEhSiUQhDh6gXhUQgpiQgHgpQgVhrAShTQALgyADhLIAEh/QAIiVA5hJQAsg4AlheQAphnAZgmIBYiHQA2hPAvgtQBEhCCEg4QDAhPAogXQD+iOEeAAQByAACYAqQCoA0BXATQBfAVCBBbQA6AoCPB1QA8AyA5BaQA9BpAhAxQAuBIA5CGQBBCaAfA6QAkBBAJBwQADApAACLQAABugpByQg4CEgdBMQgPAngpBaQglBQgSA2QgnB1huBwIw/wFIBZWIIgVAAQg9AAhyAJIgCAAQhhAAhFgpg");
	this.shape_233.setTransform(-10.4,-43.8);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#924B30").s().p("AgBWaQioAAgNgBQhjgIhLgsQg/gliSg7QiLg4hEgqQiihmhFg4Qh3hhg3hvQgphThMiJQg+h3gbhgQg0i7AAjHQAAjSAFgyQAPiSBChTQAtg6AmhhQAqhqAagnQBXiEByhuQBRhOBwhIQBDgrCdhXQB3hDCdgdQCGgaCpAAQCBAACRAtQBMAYC0BMQB8A1BsA6QCEBHBRBDQBBA1BABYQARAYBXCFQAvBIAzCOQA5CeAjA/QAlBCACBWQgEBlAAA1QAAEHhdD0QgRAtg0BZQgyBUgSA2QgmBxh+BwIxUwYIBdXGg");
	this.shape_234.setTransform(-10.5,-43.3);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#C7C8C9").s().p("AgBWaQioAAgNgBQhjgIhLgsQg/gliSg7QiLg4hEgqQihhlhGg5Qh3hig3huQgphThMiJQg+h3gbhgQg0i7AAjHQAAjSAFgyQAPiSBChTQAtg6AmhhQAqhqAagnQBXiEByhuQBRhOBwhIQBDgrCdhXQB3hDCdgdQCGgaCpAAQCBAACRAtQBMAYC0BMQB8A1BsA6QCEBHBRBDQBBA1BABYQARAYBXCFQAvBIAzCOQA5CeAjA/QAlBCACBWQgEBlAAA1QAAEHhdD0QgRAtg0BZQgyBUgSA2QgTA6gxBFQgtA/gzAwIxRwQIBdWxg");
	this.shape_235.setTransform(-10.5,-39.9);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#F1F1F2").s().p("AgBWaQimAAgPgBQhjgIhLgsQg/gmiSg6QiLg4hEgqQihhlhGg5Qh3hig3huQgphThMiKQg+h2gbhgQg0i7AAjHQAAjSAFgzQAPiRBChTQAtg6AmhhQAqhrAagnQBXiEByhtQBRhOBwhIQBBgqCfhZQB3hCCdgeQCGgZCpAAQCBAACRAtQBMAYC0BMQB8A1BsA6QCEBHBRBDQBBA1BABYQAUAcBUCBQAvBIAzCOQA5CeAjA/QAlBCACBWQgEBlAAA1QAAEGhdD1QgRAtg0BZQgyBUgSA1QgRAygzBGQgsA7gwAwIxSwFIBcWyg");
	this.shape_236.setTransform(-10.5,-36);

	this.addChild(this.shape_236,this.shape_235,this.shape_234,this.shape_233,this.shape_232,this.shape_231,this.shape_230,this.shape_229,this.shape_228,this.shape_227,this.shape_226,this.shape_225,this.shape_224,this.shape_223,this.shape_222,this.shape_221,this.shape_220,this.shape_219,this.shape_218,this.shape_217,this.shape_216,this.shape_215,this.shape_214,this.shape_213,this.shape_212,this.shape_211,this.shape_210,this.shape_209,this.shape_208,this.shape_207,this.shape_206,this.shape_205,this.shape_204,this.shape_203,this.shape_202,this.shape_201,this.shape_200,this.shape_199,this.shape_198,this.shape_197,this.shape_196,this.shape_195,this.shape_194,this.shape_193,this.shape_192,this.shape_191,this.shape_190,this.shape_189,this.shape_188,this.shape_187,this.shape_186,this.shape_185,this.shape_184,this.shape_183,this.shape_182,this.shape_181,this.shape_180,this.shape_179,this.shape_178,this.shape_177,this.shape_176,this.shape_175,this.shape_174,this.shape_173,this.shape_172,this.shape_171,this.shape_170,this.shape_169,this.shape_168,this.shape_167,this.shape_166,this.shape_165,this.shape_164,this.shape_163,this.shape_162,this.shape_161,this.shape_160,this.shape_159,this.shape_158,this.shape_157,this.shape_156,this.shape_155,this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-154.2,-187.3,308.6,307.9);


(lib.CdP_Flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF6600").ss(4).p("Ag8g3IB5Bv");
	this.shape.setTransform(14.4,6.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF6600").ss(4).p("AAyhEIhjCK");
	this.shape_1.setTransform(5,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF6600").ss(4).p("AH0kLQAADWiTCWQiSCXjPAAQjNAAiTiXQiSiWAAjW");
	this.shape_2.setTransform(59.1,27.5);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,52.3);


(lib.btn02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Simplificación\nde fracciones", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 148;
	this.text.setTransform(74.2,4.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,2,1).p("Ar2DfQAAA8A8AAIV1AAQA8AAAAg8IAAm9QAAg8g8AAI11AAQg8AAAAA8g");
	this.shape.setTransform(76.4,28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_1.setTransform(76.4,28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,2,1).p("AK7kaI11AAQg8AAAAA8IAAG9QAAA8A8AAIV1AAQA8AAAAg8IAAm9QAAg8g8AAg");
	this.shape_2.setTransform(76.4,28.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_3.setTransform(76.4,28.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_4.setTransform(76.4,28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_4},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,152.4,56.7);


(lib.btn01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Fracciones\nequivalentes", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 148;
	this.text.setTransform(74.2,4.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,2,1).p("Ar2DfQAAA8A8AAIV1AAQA8AAAAg8IAAm9QAAg8g8AAI11AAQg8AAAAA8g");
	this.shape.setTransform(76.4,28.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_1.setTransform(76.4,28.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,2,1).p("AK7kaI11AAQg8AAAAA8IAAG9QAAA8A8AAIV1AAQA8AAAAg8IAAm9QAAg8g8AAg");
	this.shape_2.setTransform(76.4,28.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_3.setTransform(76.4,28.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#666666").s().p("Aq6EbQg8AAAAg8IAAm9QAAg8A8AAIV1AAQA8AAAAA8IAAG9QAAA8g8AAg");
	this.shape_4.setTransform(76.4,28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_4},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,152.4,56.7);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", " 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_simplifica3correccion = function() {
	this.initialize();

	// resul2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(425,27.6);

	this.text = new cjs.Text("9\n21", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 33;
	this.text.setTransform(422.5,-8.4);

	// txt
	this.text_1 = new cjs.Text("es equivalente a", "25px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 29;
	this.text_1.setTransform(563.9,3.3);

	// resul1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(706.8,27.6);

	this.text_2 = new cjs.Text("3\n7", "25px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 33;
	this.text_2.lineWidth = 33;
	this.text_2.setTransform(704.3,-8.4);

	// clau
	this.text_3 = new cjs.Text("}", "80px Verdana");
	this.text_3.lineHeight = 84;
	this.text_3.lineWidth = 51;
	this.text_3.setTransform(233.2,129.7);

	// 21/3
	this.text_4 = new cjs.Text("21 : 3 = 7", "25px Verdana");
	this.text_4.lineHeight = 29;
	this.text_4.lineWidth = 142;
	this.text_4.setTransform(77.8,176.3);

	// 9/3
	this.text_5 = new cjs.Text("9 : 3 = 3", "25px Verdana");
	this.text_5.lineHeight = 29;
	this.text_5.lineWidth = 125;
	this.text_5.setTransform(84.2,132.4);

	// flecha
	this.Flecha_25 = new lib.Flecha25();
	this.Flecha_25.setTransform(30,174.1);

	// texte
	this.text_6 = new cjs.Text("se divide por un\ndivisor común: 3", "25px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 29;
	this.text_6.lineWidth = 235;
	this.text_6.setTransform(178.3,-6.7);

	// fraccio
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_2.setTransform(20,28);

	this.text_7 = new cjs.Text("9\n21", "25px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 33;
	this.text_7.lineWidth = 33;
	this.text_7.setTransform(17.5,-7.9);

	this.addChild(this.text_7,this.shape_2,this.text_6,this.Flecha_25,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_1,this.text_1,this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-8.4,726.8,239.4);


(lib.mc_simplifica2correccion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// resul2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(712.5,32-incremento);

	this.text = new cjs.Text("9\n21", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.lineWidth = 33;
	this.text.setTransform(710,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text},{t:this.shape}]},114).wait(16));

	// txt
	this.text_1 = new cjs.Text("es equivalente a", "25px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 29;
	this.text_1.setTransform(557.9,11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},106).wait(24));

	// resul1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(411.9,32-incremento);

	this.text_2 = new cjs.Text("3\n7", "25px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 33;
	this.text_2.lineWidth = 33;
	this.text_2.setTransform(409.4,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_2},{t:this.shape_1}]},96).wait(34));

	// clau
	this.text_3 = new cjs.Text("}", "80px Verdana");
	this.text_3.lineHeight = 84;
	this.text_3.lineWidth = 51;
	this.text_3.setTransform(233.2,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3}]},84).wait(46));

	// 21/3
	this.text_4 = new cjs.Text("21 : 3", "25px Verdana");
	this.text_4.lineHeight = 29;
	this.text_4.lineWidth = 142;
	this.text_4.setTransform(77.8,176.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_4,p:{text:"21 : 3"}}]},52).to({state:[{t:this.text_4,p:{text:"21 : 3 ="}}]},10).to({state:[{t:this.text_4,p:{text:"21 : 3 = 7"}}]},11).wait(57));

	// 9/3
	this.text_5 = new cjs.Text("9 : 3 ", "25px Verdana");
	this.text_5.lineHeight = 29;
	this.text_5.lineWidth = 125;
	this.text_5.setTransform(84.2,132.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_5,p:{text:"9 : 3 "}}]},18).to({state:[{t:this.text_5,p:{text:"9 : 3 = "}}]},11).to({state:[{t:this.text_5,p:{text:"9 : 3 = 3"}}]},11).wait(90));

	// flecha
	this.Flecha_25 = new lib.Flecha25();
	this.Flecha_25.setTransform(30,174.1);
	this.Flecha_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.Flecha_25).wait(8).to({_off:false},0).wait(122));

	// texte
	this.text_6 = new cjs.Text("se divide por un\ndivisor común: 3", "25px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 29;
	this.text_6.lineWidth = 235;
	this.text_6.setTransform(178.3,1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_6}]}).wait(130));

	// fraccio
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_2.setTransform(20,32-incremento);

	this.text_7 = new cjs.Text("9\n21", "25px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 33;
	this.text_7.lineWidth = 33;
	this.text_7.setTransform(17.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_7},{t:this.shape_2}]}).wait(130));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,299.8,72.8);


(lib.mc_divisiondesple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// fraccion1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape.setTransform(28.5,34-incremento,1.31,1);

	this.text = new cjs.Text("150\n 80", "25px Verdana");
	this.text.lineHeight = 33;
	this.text.lineWidth = 58;
	this.text.setTransform(1,0);

	this.text_1 = new cjs.Text("150\n 80", "25px Verdana");
	this.text_1.lineHeight = 33;
	this.text_1.lineWidth = 58;
	this.text_1.setTransform(1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_1.setTransform(28.5,34-incremento,1.31,1);

	this.text_2 = new cjs.Text("150\n 80", "25px Verdana");
	this.text_2.lineHeight = 33;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(1,0);

	this.instance = new lib.CdP_Flecha();
	this.instance.setTransform(79,89.5,0.725,0.656,0,0,180,54.6,26.2);

	this.text_3 = new cjs.Text(":5", "20px Arial");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 21;
	this.text_3.setTransform(74,113);

	this.text_4 = new cjs.Text("150\n 80", "25px Verdana");
	this.text_4.lineHeight = 33;
	this.text_4.lineWidth = 58;
	this.text_4.setTransform(1,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AjHAAIGPAA");
	this.shape_2.setTransform(28.5,34-incremento,1.31,1);

	this.text_5 = new cjs.Text("150\n 80", "25px Verdana");
	this.text_5.lineHeight = 33;
	this.text_5.lineWidth = 58;
	this.text_5.setTransform(1,0);

	this.instance_1 = new lib.CdP_Flecha();
	this.instance_1.setTransform(79,89.5,0.725,0.656,0,0,180,54.6,26.2);

	this.text_6 = new cjs.Text(":5", "20px Arial");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 21;
	this.text_6.setTransform(74,113);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{x:1,y:0,text:"150\n 80",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0,x:28.5}}]}).to({state:[{t:this.text_1,p:{x:1,y:0,text:"150\n 80",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0,x:28.5}},{t:this.text,p:{x:61,y:17,text:"=",lineWidth:21,font:"25px Verdana"}}]},19).to({state:[{t:this.text_2,p:{x:1,y:0,text:"150\n 80",lineWidth:58,font:"25px Verdana"}},{t:this.shape_1,p:{regX:0,x:28.5}},{t:this.text_1,p:{x:61,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape,p:{regX:0.1,x:114.6}}]},20).to({state:[{t:this.text_2,p:{x:1,y:0,text:"150\n 80",lineWidth:58,font:"25px Verdana"}},{t:this.shape_1,p:{regX:0,x:28.5}},{t:this.text_1,p:{x:61,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape,p:{regX:0.1,x:114.6}},{t:this.instance,p:{x:79}}]},20).to({state:[{t:this.text_2,p:{x:1,y:0,text:"150\n 80",lineWidth:58,font:"25px Verdana"}},{t:this.shape_1,p:{regX:0,x:28.5}},{t:this.text_1,p:{x:61,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0.1,x:114.6}},{t:this.text_3,p:{x:74,text:":5"}},{t:this.instance,p:{x:79}}]},20).to({state:[{t:this.text_4,p:{x:1,y:0,text:"150\n 80",lineWidth:58}},{t:this.shape_1,p:{regX:0,x:28.5}},{t:this.text_2,p:{x:61,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text_1,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape,p:{regX:0.1,x:114.6}},{t:this.text_3,p:{x:74,text:":5"}},{t:this.instance,p:{x:79}},{t:this.text,p:{x:144,y:17,text:"=",lineWidth:21,font:"25px Verdana"}}]},20).to({state:[{t:this.text_5},{t:this.shape_2},{t:this.text_4,p:{x:61,y:17,text:"=",lineWidth:21}},{t:this.text_2,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape_1,p:{regX:0.1,x:114.6}},{t:this.text_3,p:{x:74,text:":5"}},{t:this.instance,p:{x:79}},{t:this.text_1,p:{x:144,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:171,y:0,text:" 15\n  8",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0.1,x:198.6}}]},18).to({state:[{t:this.text_5},{t:this.shape_2},{t:this.text_4,p:{x:61,y:17,text:"=",lineWidth:21}},{t:this.text_2,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape_1,p:{regX:0.1,x:114.6}},{t:this.text_3,p:{x:74,text:":5"}},{t:this.instance_1},{t:this.text_1,p:{x:144,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:171,y:0,text:" 15\n  8",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0.1,x:198.6}},{t:this.instance,p:{x:164}}]},15).to({state:[{t:this.text_5},{t:this.shape_2},{t:this.text_4,p:{x:61,y:17,text:"=",lineWidth:21}},{t:this.text_2,p:{x:87,y:0,text:" 30\n 16",lineWidth:58,font:" 25px Verdana"}},{t:this.shape_1,p:{regX:0.1,x:114.6}},{t:this.text_6},{t:this.instance_1},{t:this.text_1,p:{x:144,y:17,text:"=",lineWidth:21,font:"25px Verdana"}},{t:this.text,p:{x:171,y:0,text:" 15\n  8",lineWidth:58,font:"25px Verdana"}},{t:this.shape,p:{regX:0.1,x:198.6}},{t:this.instance,p:{x:164}},{t:this.text_3,p:{x:159,text:":2"}}]},14).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1,0,62,72.8);
      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, " 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}