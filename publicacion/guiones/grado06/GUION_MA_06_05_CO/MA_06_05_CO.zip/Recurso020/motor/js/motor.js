Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();
	this.preguntas = new Array();
	this.audios = Array();
	this.boxes = Array();
	this.inputDOM ="";
	this.inputs = Array();
	
	this.contenedor = "";
	this.anterior = "";
	this.continuar = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 235 ;
	//final
	this.PREG_FINAL_X_PADDING = 585 ;
	
	this.RESP_HEIGHT = 82;
	this.RESP_WIDTH = 322; 
	this.RESP_INNER_HEIGHT = 78;
	this.RESP_INNER_WIDTH = 320; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.grado = 1;
	
	/*this.input_height = 75;
	this.input_width = 275;
	this.input_x = 5;
	this.input_y = 65;
	this.fontsize = 18;*/
	
	this.ponerContenedor = function(contenedorMotor) {
	  //alert("Estoy caminando!");
	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('test').attr('cantidad');
			Motor.datosXML.anchoespecial = $(xml).find('anchoespecial').text();
			
			$(xml).find('cuestion').each(function(index) {
				//debugger;
				this.preg = new pregunta();
				//this.preg.explicacion = $(this).children('explicacion').text();
				this.preg.id = index;
				this.preg.enunciado = $(this).children('enunciado').text();
				//this.preg.video = $(this).children('video').text();
				//this.preg.salto = $(this).children('salto').text();
				
				this.preg.sonido = $(this).children('sonido').text();
				this.preg.correccionSinMayusculas = $(this).attr('correccionSinMayusculas');
				this.preg.correccionSinPuntuacion = $(this).attr('correccionSinPuntuacion');
				this.preg.correccionSinPuntuacionFinal = $(this).attr('correccionSinPuntuacionFinal');
				
				
				var dato = this;
				//debugger;
				$(this).find('respuesta').each(function(index2) {
					//debugger;
					var rest = new respuesta();
					rest.text = $(this).attr('contestacion');
					//rest.correcte = $(this).attr('correcta');
					rest.id = index2;
					
				  	dato.preg.respuestas.push(rest);
				});
				
			  	Motor.datosXML.preguntas.push(this.preg);

			});
			
			//console.log(Motor.datosXML.preguntas.length);
	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
			
			if( Main.navegador == "MSIE 10" ){
				$(".input").css( "background-color", "#fff!important" );
			}
			
			//Motor.recolocarVideo();
		});
	}
	this.inicializarEstructura = function(estado) {
		
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.deleteAudios();
		Motor.deleteInputs();
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
	  	var total = 0;
	  	for (key in Motor.audios) 
   		{
			var respuestaReal =$( Motor.audios[key].inputDOM.htmlElement).val();
			if(respuestaReal == ""){
				return false;
			}
		}
		return true;
	};
	
	this.getEstado = function(){
		var estado = new Array();
		for( var i = 0 ; i < Motor.audios.length ; i++ ){
			for ( key1 in Motor.audios ) {
				if( i == Motor.audios[key1].id ){
					estado.push( $( Motor.audios[key1].inputDOM.htmlElement ).val() );
				}
			}
		}
		return estado.join("|");
	}
	
	this.revisar = function(){
		if(this.estado != "")
		{
			if( this.estado.indexOf("[") >= 0 )
			{
				var datos = this.estado.substring(1, this.estado.length-1).split("][");
				Contenedor.timeRevision = datos[0];
				var estado = datos[1].split("|");
			}else{
				var estado = this.estado.split("|");
			}
			
			for(var key in estado)
			{
				if(estado[key].trim() != ""){
					//var repuestas = estado[key].split(",");
					for(key1 in Motor.audios)
					{
						if( key == Motor.audios[key1].id )
						{
					   		 $( Motor.audios[key1].inputDOM.htmlElement ).val( estado[key] );
						}
					}
				}
			}
		}
	}
	
	this.validar = function() {
		var total = 0;
	  	for(key1 in Motor.preguntas){
	   		for (key2 in Motor.audios) 
	   		{
	   			if( Motor.preguntas[key1].id == Motor.audios[key2].id)
	   			{
	   				//console.log(Motor.preguntas[key1].respuestas);
	   				var respuestaCorrecta =   Motor.preguntas[key1].respuestas[0].text;
	   				var respuestaReal =$( Motor.audios[key2].inputDOM.htmlElement).val();
	   				//console.log( respuestaCorrecta + " - " + respuestaReal );

	   				if( Motor.compareResults( Motor.preguntas[key1], respuestaCorrecta, respuestaReal ))
	   				{
	   					total++;
	   					Motor.audios[key2].correct();
	   				}
	   				else if(respuestaReal != ""){
	   					Motor.audios[key2].error();
	   				}
	   			}
			}
		}
		return total.toString() +  "/" + Motor.preguntas.length.toString();
	};
	this.compareResults = function(pregunta, textoCorrecto, textoIntroducido ){
		
		var modo ="";
		if (pregunta.correccionSinMayusculas == 1)
				modo |= CorrectorTexto.MODO_CI;
		if (pregunta.correccionSinPuntuacion == 1)
				modo |= CorrectorTexto.MODO_NOPUNCT;
		if (pregunta.correccionSinPuntuacionFinal == 1)
				modo |= CorrectorTexto.MODO_NOENDPUNCT;
		
		return CorrectorTexto.esValido(textoIntroducido, textoCorrecto, modo);

	};
	this.hideDomObjects = function(){
		for (key2 in Motor.audios) 
   		{
   			Motor.audios[key2].inputDOM.visible= false;
		}
	}
	this.showDomObjects = function(){
		for (key2 in Motor.audios) 
   		{
   			Motor.audios[key2].inputDOM.visible= true;
		}
	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
		for (key in Motor.audios) 
   		{
			$( Motor.audios[key].inputDOM.htmlElement).removeAttr('readonly');
		}
	}
	this.desactivar = function() {
		for (key in Motor.audios) 
   		{
   		    if ( !$('#audio'+Motor.audios[key].id)[0].paused ){
   		       $('#audio' + Motor.audios[key].id)[0].pause(); 
               $('#audio'+ Motor.audios[key].id)[0].currentTime = 0;
               Motor.audios[key].bt.bt.gotoAndStop("normal");
            }
			$( Motor.audios[key].inputDOM.htmlElement).attr('readonly','readonly');
		}
			
	};
	this.numPaginas = function(){
		return 1;
	};
	this.ponerPagina = function(pag){
	    
	};

	this.obtenerPaginaActual = function(pag){
		
	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		//this.desactivar();	
		
	};
	this.deseleccionar = function(){
		for (key in Motor.audios) 
   		{
			if( !Motor.audios[key].correcte ) 
			{
				Motor.audios[key].clear();
			}
		}
	}
	this.solucionar = function(){
		var total = 0;
		for(key1 in Motor.preguntas){
	   		for (key2 in Motor.audios) 
	   		{
	   			if( Motor.preguntas[key1].id == Motor.audios[key2].id)
	   			{
	   				//console.log(Motor.preguntas[key1].respuestas);
	   				var respuestaCorrecta =   Motor.preguntas[key1].respuestas[0].text;
	   				var respuestaReal =$( Motor.audios[key2].inputDOM.htmlElement).val();
	   				
					var correcio = this.validateResults( Motor.preguntas[key1], respuestaCorrecta, respuestaReal ) ;
	   				
	   				if( !Motor.audios[key2].correcte ) 
	   				{
	   					Motor.audios[key2].setCorreccio(correcio);
	   				}
	   			}
			}
		}
	  	
	}
	this.validateResults = function(pregunta, textoCorrecto, textoIntroducido){
		var modo ="";
		if (pregunta.correccionSinMayusculas == 1)
				modo |= CorrectorTexto.MODO_CI;
		if (pregunta.correccionSinPuntuacion == 1)
				modo |= CorrectorTexto.MODO_NOPUNCT;
		if (pregunta.correccionSinPuntuacionFinal == 1)
				modo |= CorrectorTexto.MODO_NOENDPUNCT;
		
		return CorrectorTexto.taggedContestacion(textoIntroducido, textoCorrecto, modo, "{{u}}", "{{normal}}");
	}
	this.obtenerTipoEjercicio = function() {

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		this.preguntas = new Array();	
		this.audios = new Array();	
		this.boxes = new Array();
		//console.log( Contenedor.datosXML.plataforma );
		this.grado = parseInt(Contenedor.datosXML.plataforma.grado);
		
		var numH =3;
		var numV = 3;
		var separacioH = 310;
		if( this.grado == 2 ){
			if( Motor.datosXML.anchoespecial == 0) {
				numH = 4;
				numV = 4;
				separacioH = 225;
			}else{
				numH = 2;
				numV = 2;
				separacioH = 460;
			}
		}

		var cantidad = (this.grado == 1)? Math.min(Motor.datosXML.cantidad,6) : Math.min(Motor.datosXML.cantidad,8);
		for( var i = 0; i < cantidad; i++)
    	{
    		if( i>= numV*2) numV *=3;
    		
	    	var index = 0;
			if( Contenedor.datosXML.sinaleatoriedad == 0 && Scorm.modo != Scorm.MODO_REVISAR && Scorm.modo != Scorm.MODO_REVISARALUMNO )
			{
				index = Math.floor( Math.random()*Motor.datosXML.preguntas.length);
			} 
			
			var pregunta = Motor.datosXML.preguntas[index];
			Motor.datosXML.preguntas.splice(index,1);
		
	    	this.createAudio( pregunta, pregunta.id );

			var item = "";
			if( this.grado == 1 )  item = new AudioBoxPrimaria(pregunta.respuestas[0], pregunta.id );
			else if( this.grado == 2 ) item = new AudioBoxSecundaria(pregunta.respuestas[0], pregunta.id );
			
			this.audios.push(item);
			item.contenedor.x =  ( i % numH )* separacioH + this.PREG_X_PADDING ;
			item.contenedor.y = Math.floor( i / numV ) * 220 + this.INITIAL_Y + 5 ;
			
			this.contenedor.addChild(item.contenedor);
			
			if( this.grado == 2 && Motor.datosXML.anchoespecial == 1 && i >= 4 ){
				$(item.inputDOM.htmlElement).css("display", "none");
				item.contenedor.visible= false;
			}

			this.boxes.push(item);
	    	this.preguntas.push(pregunta);
	    	
	    }
	    
	    if( this.grado == 2 && Motor.datosXML.anchoespecial == 1 && Motor.datosXML.cantidad > 4 ){
			
			this.continuar = new Boton( 164, 28, pppPreloader.from("module", 'motor/images/btnContinuarEjercicio.png'), LangRes.lang[ LangRes.SIGUIENTE_EJERCICIO ] , "left");
			this.continuar.contenedor.x = 750;
			this.continuar.contenedor.y = 525;
			this.continuar.label.color ="#fff";
			this.continuar.contenedor.visible= true;
			this.contenedor.addChild(this.continuar.contenedor);
			this.continuar.contenedor.on("mousedown", this.continuacio, this);
			
			this.anterior = new Boton( 164, 28, pppPreloader.from("module", 'motor/images/btnAnteriorEjercicio.png'), LangRes.lang[ LangRes.ANTERIOR_EJERCICIO ] ,"center");
			this.anterior.contenedor.x = 750 ;
			this.anterior.contenedor.y = 525;
			this.anterior.contenedor.visible= false;
			this.anterior.label.color ="#fff";
			this.contenedor.addChild(this.anterior.contenedor);
			this.anterior.contenedor.on("mousedown", this.anteriora, this);
		}
			
	    Main.stage.addChild( this.contenedor );

    }
	this.continuacio = function()
	{
		for(key1 in this.boxes)
		{
			var item = this.boxes[key1];
			if(parseInt(key1) < 4)
			{
				$(item.inputDOM.htmlElement).css("display", "none");
				item.contenedor.visible= false;
			}else{
				$(item.inputDOM.htmlElement).css("display", "block");
				item.contenedor.visible= true;
			} 
		}
		this.continuar.contenedor.visible = false;
		this.anterior.contenedor.visible = true;
		
	}
	this.anteriora = function()
	{
		for(key1 in this.boxes)
		{
			var item = this.boxes[key1];
			if(parseInt(key1) < 4)
			{
				$(item.inputDOM.htmlElement).css("display", "block");
				item.contenedor.visible= true;
			}else{
				$(item.inputDOM.htmlElement).css("display", "none");
				item.contenedor.visible= false;
			} 
		}
		this.continuar.contenedor.visible = true;
		this.anterior.contenedor.visible = false;
	}
	this.createAudio = function(pregunta, index)
	{

        if(Main.navegador == "MSIE 9"){
			$('<audio id="audio'+index+'" src="'+pppPreloader.from("data", "data/sonidos/"+pregunta.sonido)+'" preload="auto" ></audio>')
	        .appendTo($("#mediaHolder"));
		}else{
			$('<audio id="audio'+index+'" preload="auto" ></audio>')
	        .append('<source src="'+pppPreloader.from("data", "data/sonidos/"+pregunta.sonido)+'" type="audio/mpeg" />')
	        .appendTo($("#mediaHolder"));
        }

	}

	
	this.deleteAudios = function()
	{
		$( "audio" ).each(function() {
		  $( this ).remove();
		});
	}
    this.deleteInputs = function()
	{
		$( "textarea" ).each(function() {
		  $( this ).remove();
		});
	}

}
