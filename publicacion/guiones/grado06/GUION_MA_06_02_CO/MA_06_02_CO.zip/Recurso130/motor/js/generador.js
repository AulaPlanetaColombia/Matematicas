Generador = new function()
{
	this.nOp;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones = new Array();

	this.lPreguntas=new Array();
	this.lRespuestas=new Array();
	this.lRespuestasString=new Array();
	this.lFiguras=new Array();

	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.plano = "";
	this.co_pizarra = "";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,"#000000",false];
		Random.init(semilla,100);
		
		this.lVariaciones = new Array();
		this.lPreguntas=new Array();
		this.lRespuestas=new Array();
		this.lRespuestasString=new Array();
		this.lFiguras=new Array();
		this.plano = "";
		this.co_pizarra = "";
		

		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		
	}
	
	this.enunciar = function()
	{
        
		//hace todos los cálculos:
		this.co_pizarra = new createjs.Container();
		
		var operacion = 0;//0-->suma   1-->resta   2-->multi   3-->divi
        //VARIABLES FIJADAS:
        var qElementos = 6;
        //VARIABLES ALEATORIAS:
        var valorExtremo;
        var razon;
        var lSerieNUM = new Array();
        var lSerieSTR = new Array();
		
		this.enun = Motor.datosXML.enunciados[Motor.campoNum];
		//this.enun = Motor.datosXML.enunciados[Motor.campoNum].enunciado;
		//console.log(this.enun);
		//console.log(Motor.datosXML.enunciados[Motor.campoNum].enunciado);
		switch(Motor.campo){
            case 'N':
                if(operacion<2){//suma o resta de naturales
                    razon=Random.integer(1,100);
                    valorExtremo=Random.integer(0,1000);
                }else{//multi o divi de naturales
                    razon=Random.integer(2,9);
                    valorExtremo=Random.integer(0,100);
                }
                break;
            case 'E':
                if(operacion<2){//suma o resta de enteros
                    razon=Random.integer(-100,100,[-1,0,1]);
                    valorExtremo=Random.integer(-1000,1000);
                }else{//multi o divi de enteros
                    razon=Random.integer(-9,9,[-1,0,1]);
                    valorExtremo=Random.integer(-100,100,[0]);
                }
                break;
            case 'D':
                if(operacion<2){//suma o resta de decimales
                    razon=JL.str2num(JL.num2str(Random.float(0.1,0.9),Random.integer(1,3)));
                    valorExtremo=Random.integer(-100,100,[0]);
                }else{//multi o divi de decimales
                    while(true){
                        razon=JL.str2num(JL.num2str(Random.float(0.1,9.9),1));
                        if(razon!=1.0){
                            break;
                        }
                    }
                    valorExtremo=Random.integer(-10,10,[0]);
                }
                break;
        }
        
        var valor = valorExtremo;
        lSerieSTR.push(this.limpiarDEC(valor,8));
        //console.log(lSerieSTR);
        for (var nElem=1;nElem<qElementos;nElem++) {
            //console.log("operacion2 : "   + operacion);
            switch(operacion){
                case 0://suma
                case 1://resta
                    valor+=razon;
                    break;
                case 2://multi
                case 3://divi
                    valor*=razon;
                    break;
            }
            lSerieSTR.push(this.limpiarDEC(valor,8));
        }
        
        if((operacion==1)||(operacion==3)){//resta o divi: invierte el array
            lSerieSTR.reverse();
        }
        lSerieNUM=new Array();
        for (var s in lSerieSTR){
            
            lSerieNUM.push(JL.str2num(lSerieSTR[s]));
        }
        //console.log(lSerieSTR);
        
        Motor.lOperaciones[this.nOp]=new Object();
        Motor.lOperaciones[this.nOp].enunciadoParseado=this.enun;
        Motor.lOperaciones[this.nOp].lSerieNUM=lSerieNUM;
        Motor.lOperaciones[this.nOp].lSerieSTR=lSerieSTR;
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;

        //console.log(Motor.lOperaciones[this.nOp]);

        /*Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
        Motor.lOperaciones[this.nOp].preguntaSprite.y=90;
        Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
        Motor.lOperaciones[this.nOp].entrada=0;
        Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;*/
		
        
		//console.log("El campo es : " + campoNum);
		
		
		
		
		
	
	
	
	}
	this.limpiarDEC = function(vv,dd){
	    dd = dd || 8;
        return JL.num2str(JL.str2num(JL.num2str(vv,dd)));
    }
	

}