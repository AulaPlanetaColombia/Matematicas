function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    //this.video = pregunta.video;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = true;
	//this.figura = operacio.figura;
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.addLine( 0, 50, 300 - 118, "", "", operacio.lSerieSTR[0]);
    this.addLine( 1, 200, 300 - 118, "", "", operacio.lSerieSTR[1]);
    this.addLine( 2, 350, 300 - 118, "", "", operacio.lSerieSTR[2]);
    this.addLine( 3, 500, 300 - 118, "", "", operacio.lSerieSTR[3]);
    this.addLine( 4, 650, 300 - 118, "", "", operacio.lSerieSTR[4]);
    this.addLine( 5, 800, 300 - 118, "", "", operacio.lSerieSTR[5]);
                
  
    
    //this.contenedor.addChild( operacio.figura ); 
    
   	//this.addLine( 0, 350, 400 - 118, "P = ", operacio.tipoUnidad , operacio.respuestaString[0]  );
	//this.addLine( 1, 350, 460 - 118, "A = ", operacio.tipoUnidad+"<sp>2<n>", operacio.respuestaString[1]);

	this.correcto3 = operacio.lSerieSTR[3]; 
	this.correcto4 = operacio.lSerieSTR[4]; 
	this.correcto5 = operacio.lSerieSTR[5]; 

	this.resp3 = "";
	this.resp4 = "";
	this.resp5 = "";
}

Pagina.prototype.addLine = function( index, x, y, _text, unitat, resposta){
	
	/*this["text"+index] = new createjs.RichText();
	this["text"+index].text = _text;
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
	this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
	this["text"+index].color = "#0D3158";
	this["text"+index].x = x - 45;
	this["text"+index].y = y + 8;
	
	this.contenedor.addChild( this["text"+index] );*/
    if(index < 3){
        this["cajaX"+index] = new CajaTexto(resposta);
    }else{
         this["cajaX"+index] = new CajaTexto2();
    }
	
	this["cajaX"+index] .contenedor.x = x;
	this["cajaX"+index] .contenedor.y = y;

	this.contenedor.addChild( this["cajaX"+index].contenedor  );
	
	/*this["unitats"+index] = new createjs.RichText();
	this["unitats"+index].text = unitat.toString();
    this["unitats"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
	this["unitats"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
	this["unitats"+index].color = "#0D3158";
	this["unitats"+index].x = x + 255;
	this["unitats"+index].y = y + 8;
	
	this.contenedor.addChild( this["unitats"+index]  );*/
	
	if(index > 2){
    	this["valor"+index] = new createjs.RichText();
    	this["valor"+index].text = resposta.toString();
        this["valor"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Verdana" : "16px Verdana" ;
    	this["valor"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 18 : 16 ;
    	this["valor"+index].color = "#E1001A";
    	this["valor"+index].x = x + 80;
    	this["valor"+index].y = y + 90;
    	this["valor"+index].textAlign = "right";
    	this["valor"+index].alpha = 0;
    	
    	this.contenedor.addChild( this["valor"+index]  );
	
	}
}

function PuntoP( color )
{
	color =  color || "#000";
	this.contenedor = new createjs.Container();
	this.punto = new createjs.Shape();
	
	this.punto.graphics.beginFill(color).drawCircle(0,0,5);
	
	this.contenedor.addChild( this.punto );
}
function CajaTexto(resposta)
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	/*this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 90, 60, 10);*/
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#000").setStrokeStyle(1).drawRoundRect(0, 0, 130, 40, 10);

    this.texte = new createjs.RichText();
    this.texte.font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Verdana" : "16px Verdana" ;
    this.texte.fontSize = 20;
    this.texte.text = resposta; //+ Math.floor(Math.random()*1000).toString();
    this.texte.textAlign = "center";
    this.texte.x = 65;
    this.texte.y = 10;

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	this.area.addChild( this.texte );
	
	
	this.contenedor.addChild( this.area );
}

function CajaTexto2()
{
    this.contenedor = new createjs.Container();
    this.area = new createjs.Container();
    
    this.fons = new createjs.Shape();
    this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 130, 40, 10);
    
    this.marc = new createjs.Shape();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 130, 40, 10);

    this.area.addChild( this.fons );
    this.area.addChild( this.marc );
    
    this.contenedor.addChild( this.area );
}


CajaTexto2.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 130, 40, 10);
}
CajaTexto2.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 130, 40, 10);
}

CajaTexto2.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 130, 40, 10);
}
