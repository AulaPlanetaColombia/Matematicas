(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
        titulo1(this,txt['titulo']);
	this.instance = new lib.fondo();
	this.instance.setTransform(475,294,1,1,0,0,0,475,304);
   this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
    
        this.addChild(this.instance,this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit1'],"20px");
this.instance = new lib.grafica3();
	this.instance.setTransform(778.3,320,1.252,1.252,0,0,0,44,0);

	this.instance_1 = new lib.grafic2();
	this.instance_1.setTransform(504,333,1,1,0,0,0,44,0);

	this.instance_2 = new lib.grafica1();
	this.instance_2.setTransform(199.3,329,0.374,0.374,0,0,0,44,0);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['tit2']);
	this.text = new cjs.Text(txt['text1'], "20px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 378;
	this.text.setTransform(79,133.9);

	this.instance = new lib.imagen1();
	this.instance.setTransform(705.8,340.3,1.312,1.312,0,0,0,230.5,153.4);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
    this.informacion.on("click", function (evt) {
            putStage(new lib.framei1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion, this.anterior, this.siguiente,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3']);
this.instance = new lib.animacion1();
	this.instance.setTransform(77,137.9);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['tit4']);
this.instance = new lib.animacion2();
	this.instance.setTransform(495.9,329.4,1,1,0,0,0,416.9,200.9);

	this.text = new cjs.Text("Analicemos la tabla", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 616;
	this.text.setTransform(80,127.9);

	this.text_1 = new cjs.Text("2", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(291.7,387);

	this.text_2 = new cjs.Text("5", "16px Verdana", "#FF6600");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(149.4,387);

	this.text_3 = new cjs.Text("5", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(291.7,352.7);

	this.text_4 = new cjs.Text("4", "16px Verdana", "#FF00FF");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(149.4,352.7);

	this.text_5 = new cjs.Text("7", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(291.7,319.9);

	this.text_6 = new cjs.Text("3", "16px Verdana", "#996600");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(149.4,319.9);

	this.text_7 = new cjs.Text("10", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(291.7,254.7);

	this.text_8 = new cjs.Text("1", "16px Verdana", "#0066FF");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(149.4,254.7);

	this.text_9 = new cjs.Text("14", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(291.7,287.2);

	this.text_10 = new cjs.Text("2", "16px Verdana", "#CC0000");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(149.4,287.2);

	this.text_11 = new cjs.Text("2", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(291.7,225.2);

	this.text_12 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(149.4,225.2);

	this.instance_1 = new lib.tabla2();
	this.instance_1.setTransform(222.3,296.6-incremento,1,1,0,0,0,139.8,118.1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.informacion.on("click", function (evt) {
            putStage(new lib.framei2());
        });

        this.addChild(this.logo, this.titulo, this.informacion, this.home, this.anterior, this.siguiente,this.instance_1,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['tit5']);
this.instance = new lib.diagramaAnim();
	this.instance.setTransform(690.1,369.2,1,1,0,0,0,222.2,160.3);

	this.text = new cjs.Text("5 %", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(307.4,467);

	this.text_1 = new cjs.Text("12,5 %", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(307.4,430);

	this.text_2 = new cjs.Text("17,5 %", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(307.4,395);

	this.text_3 = new cjs.Text("35 %", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(307.4,357);

	this.text_4 = new cjs.Text("25 %", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(307.4,322);

	this.text_5 = new cjs.Text("5 %", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(307.4,285);

	this.text_6 = new cjs.Text("100%", "bold 16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(308.4,499);

	this.text_7 = new cjs.Text("Total", "bold 16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(147.4,499);

	this.text_8 = new cjs.Text("5", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(147.4,467);

	this.text_9 = new cjs.Text("4", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(147.4,430);

	this.text_10 = new cjs.Text("3", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(147.4,395);

	this.text_11 = new cjs.Text("2", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(147.4,356);

	this.text_12 = new cjs.Text("1", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(147.4,321);

	this.text_13 = new cjs.Text("0", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(147.4,285);

	this.text_14 = new cjs.Text("Frecuencia relativa fr", "bold 16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.lineWidth = 156;
	this.text_14.setTransform(303.7,225);
 var html = createDiv("<center><b>Porcentaje<sub></sub></b></center>", "Verdana", "16px", '130px', '40px', "20px", "185px", "left");
 
    this.text_14 = new cjs.DOMElement(html);
    this.text_14.setTransform(313-80, 225-615);
	this.text_15 = new cjs.Text("Computadores", "bold 16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(149.7,232);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AYCTEI6UAAIAAE1IYtAAQBzAAAAhkMAAAgspQAAhFg3gWQgZgJgjAAI4tAAIAAJRIaUAAA3W3vQg3AWAABFIAAHtIV4AAIAApRI0FAAQgkAAgYAJgA4NCNIV4AAIAAllI14AAIAAFlIAAFoAiVjYIAAloI14AAIAAFoA4NunIAAFnAiS34IgDAAAiVunIADAAIAAFnIaPAAAhOr3IAGAAAiVjYIADAAIAAloIgDAAIAAlnAX9jYI6PAAIAAFlIaPAAAiVCNIAAFoIADAAIAAlogAiVH1IAAFnIADAAIAAlnIaPAAAiSTEIgDAAIAAE1IADAAAiVNcIAAFoI14AAIAADRQAABkBzAAIUFAAAiSTEIAAloAiVH1I14AAIAAFnIV4AAA4NNcIAAFoAX9NcI6PAA");
	this.shape.setTransform(235.3,373-incremento);

	this.text_16 = new cjs.Text("El diagrama de sectores es una herramienta muy prÃ¡ctica para representar frecuencias. ", "20px Verdana");
	this.text_16.lineHeight = 20;
	this.text_16.lineWidth = 382;
	this.text_16.setTransform(79,128.9);
         var html = createDiv(txt['text5'], "Verdana", "20px", '390px', '40px', "20px", "185px", "left");
    this.text_16 = new cjs.DOMElement(html);
    this.text_16.setTransform(90, 128-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.informacion.on("click", function (evt) {
            putStage(new lib.framei3());
        });

        this.addChild(this.logo, this.titulo, this.informacion, this.home, this.anterior, this.siguiente,this.text_16,this.shape,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit6']);
this.text = new cjs.Text(txt['text7'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 787;
	this.text.setTransform(46,133.9);

	this.instance = new lib.conclusiones1();
	this.instance.setTransform(68.5,156.2,1,1,0,0,0,394.4,26.3);

	this.instance_1 = new lib.diagrama();
	this.instance_1.setTransform(733.8,363.2,0.823,0.823,0,0,0,132.1,106.9);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['tit6']);
this.instance = new lib.imagne2();
	this.instance.setTransform(733,377.7,1,1,0,0,0,135,150.7);

	

	this.text_1 = new cjs.Text("Ahora podemos tomar decisiones sobre el uso del computador como herramienta educativa:\n\nHay que fomentar el uso del computador.\nHay que permitir que algunos deberes se hagan por computador.\nNecesitaremos una sala con computadores para los alumnos sin computador en casa \no con acceso limitado al mismo.", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 454;
	this.text_1.setTransform(82,231.9);
 var html = createDiv(txt['text13'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(90, 231-608);
	this.text_2 = new cjs.Text("Para acabar el estudio, suponemos que la muestra sobre la que se ha trabajado es suficientemente representativa y extrapolamos las conclusiones anteriores a todos los alumnos de sexto a noveno del colegio.", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 784;
	this.text_2.setTransform(82,131.9);
        var html = createDiv(txt['text12'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(90, 131-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.text_2,this.text_1,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.framei1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,1,0);
        titulo2(this,txt['tit7']);
texto(this,txt['text14'],0,-40);
 this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.texto,this.home,this.informacion,this.cerrar,this.audioplay);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.framei2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,1,0);
        titulo2(this,txt['tit8']);
texto(this,txt['text15'],0,-40);
 this.cerrar.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.texto,this.home,this.informacion,this.cerrar,this.audioplay);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.framei3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,1,0);
      var inc=0;
      if (isbq) inc=35;
        titulo2(this,txt['tit9']);
texto(this,txt['text16'],0,-40);
this.text = new cjs.Text("360º\nNúmero de datos", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.setTransform(430.6-inc/2,275.9-inc+incremento);



	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AuIAAIcRAA");
	this.shape.setTransform(432.5-inc/2,302-inc);
 this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.texto,this.home,this.informacion,this.cerrar,this.shape,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._01_OPT = function() {
	this.initialize(img._01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1085,765);


(lib._03_Opt = function() {
	this.initialize(img._03_Opt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,600);


(lib._04_OPT = function() {
	this.initialize(img._04_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,267,400);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.tabla3 = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("= 0,05", "14px Verdana");
	this.text.lineHeight = 12;
	this.text.setTransform(330.9,226.9);

	this.text_1 = new cjs.Text("2\n40", "14px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(316.1,219.9);

	this.text_2 = new cjs.Text("= 0,125", "14px Verdana");
	this.text_2.lineHeight = 12;
	this.text_2.setTransform(330.9,189.9);

	this.text_3 = new cjs.Text("5\n40", "14px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 15;
	this.text_3.setTransform(316.1,182.9);

	this.text_4 = new cjs.Text("= 0,175", "14px Verdana");
	this.text_4.lineHeight = 12;
	this.text_4.setTransform(330.9,153.9);

	this.text_5 = new cjs.Text("7\n40", "14px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 15;
	this.text_5.setTransform(316.1,146.9);

	this.text_6 = new cjs.Text("= 0,35", "14px Verdana");
	this.text_6.lineHeight = 12;
	this.text_6.setTransform(330.9,116.9);

	this.text_7 = new cjs.Text("14\n40", "14px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 15;
	this.text_7.setTransform(316.1,109.9);

	this.text_8 = new cjs.Text("= 0,25", "14px Verdana");
	this.text_8.lineHeight = 12;
	this.text_8.setTransform(330.9,81.9);

	this.text_9 = new cjs.Text("10\n40", "14px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 15;
	this.text_9.setTransform(316.1,74.9);

	this.text_10 = new cjs.Text("= 0,05", "14px Verdana");
	this.text_10.lineHeight = 12;
	this.text_10.setTransform(330.9,45.9);

	this.text_11 = new cjs.Text("2\n40", "14px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 15;
	this.text_11.setTransform(316.1,38.9);

	this.text_12 = new cjs.Text("5 %", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(427.1,226.9);

	this.text_13 = new cjs.Text("12,5 %", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(427.1,189.9);

	this.text_14 = new cjs.Text("17,5 %", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(427.1,154.9);

	this.text_15 = new cjs.Text("35 %", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(427.1,116.9);

	this.text_16 = new cjs.Text("25 %", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(427.1,81.9);

	this.text_17 = new cjs.Text("5 %", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(427.1,44.9);

	this.text_18 = new cjs.Text("100%", "bold 16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(428.1,258.9);

	this.text_19 = new cjs.Text("1", "bold 16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(345.1,258.9);

	this.text_20 = new cjs.Text("40", "bold 16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(217.1,258.9);

	this.text_21 = new cjs.Text("2", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(217.1,226.9);

	this.text_22 = new cjs.Text("5", "16px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(217.1,189.9);

	this.text_23 = new cjs.Text("7", "16px Verdana");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(217.1,154.9);

	this.text_24 = new cjs.Text("14", "16px Verdana");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(217.1,115.9);

	this.text_25 = new cjs.Text("10", "16px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(217.1,80.9);

	this.text_26 = new cjs.Text("2", "16px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(217.1,44.9);

	this.text_27 = new cjs.Text("Total", "bold 16px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(67.1,258.9);

	this.text_28 = new cjs.Text("5", "16px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(67.1,226.9);

	this.text_29 = new cjs.Text("4", "16px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(67.1,189.9);

	this.text_30 = new cjs.Text("3", "16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 16;
	this.text_30.setTransform(67.1,154.9);

	this.text_31 = new cjs.Text("2", "16px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(67.1,115.9);

	this.text_32 = new cjs.Text("1", "16px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(67.1,80.9);

	this.text_33 = new cjs.Text("0", "16px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(67.1,44.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhtOJIDbAAAhtIXIDbAAAhtCvIDbAAAhtjBIDbAAAhtofIDbAAAhtuHIDbAA");
        if (isbq)
	this.shape.setTransform(318.1,145-incremento);
else
    	this.shape.setTransform(318.1,147.5-incremento);

	// Capa 1
	this.text_34 = new cjs.Text("Frecuencia relativa fr", "bold 16px Verdana");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 16;
	this.text_34.lineWidth = 156;
	this.text_34.setTransform(383.4,-15);
 var html = createDiv("<center><b>Frecuencia relativa fr<sub></sub></b></center>", "Verdana", "16px", '130px', '40px', "20px", "185px", "left");
 
    this.text_34 = new cjs.DOMElement(html);
    this.text_34.setTransform(383-80, -15-615);
	this.text_35 = new cjs.Text("Frecuencia absoluta f", "bold 16px Verdana");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 16;
	this.text_35.lineWidth = 156;
	this.text_35.setTransform(218.4,-15);
 var html = createDiv("<center><b>Frecuencia absoluta f<sub></sub></b></center>", "Verdana", "16px", '140px', '40px', "20px", "185px", "left");
 
    this.text_35 = new cjs.DOMElement(html);
    this.text_35.setTransform(218-80, -15-615);
	this.text_36 = new cjs.Text("Computadores", "bold 16px Verdana");
	this.text_36.textAlign = "center";
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(69.4,-8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EgktgWUIAAHtIV4AAIAApRI0FAAQhzAAAABkgAuuunIY6AAIAApRI5BAAEAkiATEIsZAAIAAE1IKyAAQBzAAAAhkMAAAgspQAAhkhzAAI4vAAEAkigOnIsZAAIAAFnIMUAAEAkdgDYIsUAAIAAFlIMUAAAYJCNIAAFoIMUAAAYJpAIAAFoIt9AAIAAFlIN9AAEAkdANcIsUAAIAAFoIt9AAIAAE1IN9AAAYJH1IAAFnIt9AAIAAFoAYJunIt9AAIAAFnIN9AAAKMCNIAAFoIN9AAAKMpAIAAFoEgktgOnIAAFnIV4AAIAAlnEgktACNIV4AAIAAllI14AAIAAFlIAAFoIV4AAIAAloEgktgJAIAAFoAu1jYIAAloAu1TEI14AAIAADRQAABkBzAAIUFAAIAAk1IAAloI14AAIAAFoAKMNcIAAlnI5BAAIAAFngAu1jYIZBAAAKMpAI5BAAAKMCNI5BAAEgktAH1IAAFnAuuTEIY6AAAu1X5IZBAA");
	this.shape_1.setTransform(235,133-incremento);

	this.addChild(this.shape_1,this.text_36,this.text_35,this.text_34,this.shape,this.text_33,this.text_32,this.text_31,this.text_30,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-19.9,470,306);


(lib.tabla2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("A13AAMArvAAA");
	this.shape.setTransform(140,39.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("A13AAMArvAAA");
	this.shape_1.setTransform(140,72.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("A13AAMArvAAA");
	this.shape_2.setTransform(140,104.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AV4AAMgrvAAA");
	this.shape_3.setTransform(140,137.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("A13AAMArvAAA");
	this.shape_4.setTransform(140,203.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A13AAMArvAAA");
	this.shape_5.setTransform(140,170.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("A0EAAMAoJAAA");
	this.shape_6.setTransform(140,236);

	this.text = new cjs.Text("Computadores", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(69.4,7.9+incremento);

	this.text_1 = new cjs.Text("Alumno", "bold 16px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(176,7.9+incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("AUFSbQBzAAAAhkMAAAghtQAAhkhzAAI0FAAMAAAAk1AAAyaI0EAAQhzAAAABkMAAAAhtQAABkBzAA");
	this.shape_7.setTransform(140,118);

	this.addChild(this.shape_7,this.text_1,this.text,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,280,236);


(lib.tabla1 = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("9º", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(54.1,156.9);

	this.text_1 = new cjs.Text("7º", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(54.1,96.9);

	this.text_2 = new cjs.Text("6º", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(54.1,67.9);

	this.text_3 = new cjs.Text("10", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(480.5,20.9);

	this.text_4 = new cjs.Text("9", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(441.1,20.9);

	this.text_5 = new cjs.Text("8", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(401.9,20.9);

	this.text_6 = new cjs.Text("7", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(362.7,20.9);

	this.text_7 = new cjs.Text("6", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(323.5,20.9);

	this.text_8 = new cjs.Text("5", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(284.3,20.9);

	this.text_9 = new cjs.Text("4", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(245.1,20.9);

	this.text_10 = new cjs.Text("3", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(205.9,20.9);

	this.text_11 = new cjs.Text("2", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(166.7,20.9);

	this.text_12 = new cjs.Text("1", "16px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(118,20.9);

	this.text_13 = new cjs.Text("8º", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(54.1,126.9);

	// Capa 1
	this.text_14 = new cjs.Text("Alumno", "bold 16px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(36.1,0.9);

	this.text_15 = new cjs.Text("Curso", "bold 16px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(5,42.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAl1gOWIksAAIAAKUIGJAAIAAowQAAhhhdgDgEAhJgECIAAEWIGJAAIAAkWA1sAUIFvAAIAAkWImJAAIAAEWIAAEsIAAEsIAAErMA76AAAQBcgDAChcIAAjMImJAAIAAEiEAnSAJsIAAksImJAAIAAEsImJAAIAAEiEAnSAFAIAAksAbAkCImJAAIAAEWIGJAAgAbAAUIGJAAIAAEsImJAAIAAEsEAhJgOWImJAAIAAKUIGJAAAOukCImJAAIAAEWIGJAAIAAkWIGJAAIAAqUImJAAgAOuAUIGJAAIAAEsIGJAAIAAksAU3OOIAAkiImJAAIAAEiAU3JsIAAksImJAAIAAEsAbAuWImJAAAU3JsIGJAAAIlAUIAAEsIGJAAIAAksACckCImHAAIAAEWIGHAAIAAkWIGJAAIAAqUImJAAgACcAUIGJAAAv9AUIGJAAIAAkWImJAAIAAqUImJAAIAAKUAp0AUIAAEsIGJAAIAAksgAp0kCIGJAAIAAqUImJAAgAp0OOIAAkiImJAAIAAEiACcOOIAAkiImHAAIAAEiAp0FAIAAEsIGJAAIAAksAIlOOIAAkiImJAAAIlJsIAAksImJAAIAAEsACcuWImHAAACcAUIAAEsImHAAA2GuWIvnAAQg4AAgYAfIQ3J1Egm9gN3QgUAYAAAtIAAIwIRLAAEgnRgECIAAEWIRLAAA2GJsIxLAAIAADMQACBfBiAAIPnAAA2GFAIxLAAIAAEsA1sJsIFvAAIAAksIlvAAEgnRAAUIAAEsAv9FAIAAksAp0uWImJAAAp0FAImJAAAIlJsIGJAAAOuuWImJAA");
	this.shape.setTransform(251.5,92-incremento);

	this.addChild(this.shape,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,503,184);


(lib.objeto1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text6'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 382;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,386,52.6);


(lib.imagne2 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A1F3iMAqLAAAMAAAAvFMgqLAAAg");
	mask.setTransform(135,150.7);

	// Capa 2
	this.instance = new lib._04_OPT();
	this.instance.setTransform(-10.1,-56.6,1.065,1.065);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10.1,-56.6,284.4,426);


(lib.imagen1 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A+2XCMAAAguDMA9tAAAMAAAAuDg");
	mask.setTransform(197.5,147.5);

	// Capa 2
	this.instance = new lib._03_Opt();
	this.instance.setTransform(100.4,-46.5,0.635,0.635);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(100.4,-46.5,254,381);


(lib.grafica3 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah2ByIAAjkIDtDlg");
	this.shape.setTransform(102.8,-79.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B4B4B4").s().p("Ah2ByIAAjkIDtDlg");
	this.shape_1.setTransform(101.9,-78.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#97DA66").s().p("AgTDeIAAnjIAoAAIAAIKg");
	this.shape_2.setTransform(72.7,-46.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#97DA66").s().p("AgUC5IAAmcIApAAIAAHGg");
	this.shape_3.setTransform(80.7,-35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#97DA66").s().p("AgTDEIAAm1IAoAAIAAHjg");
	this.shape_4.setTransform(88.6,-27.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#97DA66").s().p("AgUBwIAAkQIAoAAIAAFBg");
	this.shape_5.setTransform(96.5,-10.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F8F8F8").s().p("AI0F6IAAlDIgqAAIAAESIglgqIAAnjIgqAAIAAG1IglgnIAAnGIgqAAIAAGcIglgkIAAoKIgqAAIAAHjQj+jokKiQQkIiOjigeIAAh8IREAAQBfB7BRCFQBoCpBPCxIAAI9QhLhrhXhng");
	this.shape_6.setTransform(42.1,-32.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#40BA0D").s().p("AgUBzIAAjlIApAAIAADlg");
	this.shape_7.setTransform(-14.4,29.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#40BA0D").s().p("AgTA/IAAh9IAnAAIAAB9g");
	this.shape_8.setTransform(-6.5,34.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#40BA0D").s().p("AgUDdIAAm5IApAAIAAG5g");
	this.shape_9.setTransform(1.4,18.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#40BA0D").s().p("AgUCwIAAlfIAoAAIAAFfg");
	this.shape_10.setTransform(9.3,23.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#40BA0D").s().p("AgUBnIAAjNIApAAIAADNg");
	this.shape_11.setTransform(17.2,30.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#40BA0D").s().p("AgTBcIAAi3IAnAAIAAC3g");
	this.shape_12.setTransform(25.2,31.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#40BA0D").s().p("AgUAqIAAhTIAoAAIAABTg");
	this.shape_13.setTransform(33.1,36.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#40BA0D").s().p("AgTDaIAAmzIAnAAIAAGzg");
	this.shape_14.setTransform(41,19);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#40BA0D").s().p("AgUEGIAAoLIAoAAIAAILg");
	this.shape_15.setTransform(48.9,14.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#40BA0D").s().p("AgTE0IAApnIAnAAIAAJng");
	this.shape_16.setTransform(56.9,10.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#40BA0D").s().p("AgTECIAAoDIAnAAIAAIDg");
	this.shape_17.setTransform(64.8,15.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#40BA0D").s().p("AgTI2IAAxrIAoAAIAARrg");
	this.shape_18.setTransform(72.7,-15.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#40BA0D").s().p("AgUHtIAAvZIApAAIAAPZg");
	this.shape_19.setTransform(80.7,-8.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#40BA0D").s().p("AgTHRIAAuhIAoAAIAAOhg");
	this.shape_20.setTransform(88.6,-5.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#40BA0D").s().p("AgUFTIAAqlIAoAAIAAKlg");
	this.shape_21.setTransform(96.5,7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#40BA0D").s().p("ArVCaIAAkzIWrAAIAAEzg");
	this.shape_22.setTransform(42.1,73.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F3F3F3").s().p("ArVOGIAA8LIS7AAIDwDmIAAYlg");
	this.shape_23.setTransform(42.1,-1.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B4B4B4").s().p("ArVOGIAA8LIS7AAIDwDnIAAYkg");
	this.shape_24.setTransform(46,1.1);

	this.addChild(this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-30.5,-91.4,149.2,182.8);


(lib.grafica1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#B2EB0F","#97DC2B"],[0,0.612,1],88.4,134.5,-17.5,-32.4).s().p("AE9KXQnAhDmLiDQnSiYk/jZQk+jXiHj/QCZDhEnC+QEnDDGcCPQFzCCHFBAQGMA3H7ALQEKAFEFgRIon1OIAwAYIJvWJQkBAVkNAAQnWAAnEhEg");
	this.shape.setTransform(-82.6,-30);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#8EDA14").s().p("ApqneIinBUQhZAug4AoQkTC1iTDOQiTDQgHDXQgIjlCRjeQCRjeEdi/QA3gpBYgwICkhTMAhQAQTIAMAbg");
	this.shape_1.setTransform(-118.1,-151.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#C5F17F","#B2EB0F","#5BBF4A"],[0,0.353,0.969],122.8,-81.6,-167.1,187.9).s().p("AFuSWQnAhDmLiDQoEiplNj2QlOj2hpkhQhtkaCIkeQCHkeFnjxQA2gpBYgwICkhTMAhQAQVIJwWJQkBAVkNAAQnWAAnEhEg");
	this.shape_2.setTransform(-87.5,-81.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#ACE817","#00AF08"],[0,1],-109,136.2,0,-109,136.2,210.6).s().p("AFtYMQnAhEmLiCQoEiplNj2QlOj2hpkhQgohqgGhrQgCgnACgoIAA67MA4qAW9IgBbNQkDAVkLAAQnWAAnEhEg");
	this.shape_3.setTransform(-87.4,56.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FFFFFF","#FF7B8C"],[0.18,1],78,-0.8,0,78,-0.8,307.4).s().p("AsPG3QGkg6F2huQF3huEviYIxxnRITQHXQk/ChmOBxQmNBwm9A4g");
	this.shape_4.setTransform(198.5,120.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FF7B8C","#FF2422"],[0,0.976],3.1,-27.4,0,3.1,-27.4,122.4).s().p("Awlp4MAhLAM3Qk/ChmOBxQmNBxm+A3g");
	this.shape_5.setTransform(170.7,103.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#AA0000").s().p("AkYkUIAArIIIxTxIAALIg");
	this.shape_6.setTransform(92.7,115.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#FF7B8C","#FF2422","#C70806"],[0,0.427,1],32.3,71.5,0,32.3,71.5,98).s().p("Awlp4IHoC9IZjCjIAAHXQk/ChmOBwQmNBym+A3g");
	this.shape_7.setTransform(170.7,150.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FF8900","#FFEC12"],[0,1],-66.6,-13.7,154.6,32).s().p("AxqA/IAAvuMAjVANxIAAPug");
	this.shape_8.setTransform(180,65.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#FFFFFF","#FBFF00"],[0,0.914],84.7,51.1,0,84.7,51.1,241.4).s().p("A2pmIIAegKMAi+AMvQFCjHCejjQCcjjgMj2QAmEFiiD5QijD7lZDUg");
	this.shape_9.setTransform(211.9,10.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#FBFF00","#FFB12A"],[0,1],-13.4,36.1,0,-13.4,36.1,198.9).s().p("A1iguMAkQgLnQCNBrBiB+QBjB9AyCHQBwEgiQEWQiQEYl/Dwg");
	this.shape_10.setTransform(215.5,-23.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFD100","#FF9500"],[0,0.933],-13.6,36.4,53.7,-134.5).s().p("A2qgyMAmDgMLQCaByBqCHQBnCDA0CNQB2EuiaEmQiZEnmQD3g");
	this.shape_11.setTransform(211.9,-23.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0072C0").s().p("AwQI7IAA8CMAghAP+IAAWRg");
	this.shape_12.setTransform(-58.7,-58.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["#FFFFFF","#35D7FD"],[0,1],123.8,-21.2,0,123.8,-21.2,311.3).s().p("AzsJyMAlFgMrQjziVk5h2QkzhylkhNQGRBLFaB7QFgB8EMClMgm2AMgg");
	this.shape_13.setTransform(168,-143.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["#5DF1FF","#00B8FA"],[0,0.482],53.3,27,0,53.3,27,372.1).s().p("EgjsgFEQE/iGGJhaQF+hWGpgmQEPgXEOAAQLbABKXCbQKXCcHEEXMgm2AMgg");
	this.shape_14.setTransform(65.6,-148.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#00B8FA","#0075EC"],[0,1],0,0,0,0,0,118.1).s().p("Azbk3MAm3gMiIAAcCMgm3AGxg");
	this.shape_15.setTransform(169.7,-47.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FF0000").s().p("EgjsgCMQE/iGGJhZQF+hXGpgmQEJgWEUAAQLbAAKXCcQKXCbHEEVMgm2AGxg");
	this.shape_16.setTransform(65.6,12.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["#FFC000","#FF6E00"],[0,1],144,30.5,0,144,30.5,87.3).s().p("AMrOzMgjVgNxMAkDgLgIAVkXII4AAIAAOtQAeD+iiD2QiiD1lSDQIgDAFg");
	this.shape_17.setTransform(211.9,65.2);

	this.addChild(this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-269,-218.2,626.2,436.6);


(lib.grafic2 = function() {
	this.initialize();

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],6.4,-12.6,-20.2,41.4).s().p("AhMAuIgBh7ICaAfIABB8g");
	this.shape.setTransform(138.8,64.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAQICEhDICxAkIiEBDg");
	this.shape_1.setTransform(145.3,54);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#FFC000","#FF6E00"],[0,1],19.5,4.1,0,19.5,4.1,28.1).s().p("AhBgmICChFIABCSIiCBFg");
	this.shape_2.setTransform(154.3,63.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],9.8,-19.8,-15.2,31.1).s().p("AhNAVIAAhJICaAgIABBJg");
	this.shape_3.setTransform(105.1,60.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAPICEhCICxAlIiFBCg");
	this.shape_4.setTransform(111.7,52.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FFC000","#FF6E00"],[0,1],19.5,3.2,0,19.5,3.2,26.7).s().p("AhBgNICChEIABBfIiCBFg");
	this.shape_5.setTransform(120.6,58.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],11.9,-23.9,-16.1,33.1).s().p("AhLBfIgDjdICbAgIACDdg");
	this.shape_6.setTransform(71.3,46.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAQICEhDICxAkIiEBDg");
	this.shape_7.setTransform(77.8,30.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#FFC000","#FF6E00"],[0,1],19.7,5.9,0,19.7,5.9,31.4).s().p("AhChXICChFIADDzIiCBGg");
	this.shape_8.setTransform(86.8,44.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],11.3,-22.9,-18.1,37).s().p("AhKDfIgFncICaAfIAFHcg");
	this.shape_9.setTransform(37.4,26.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAQICEhDICxAlIiEBCg");
	this.shape_10.setTransform(43.8,-1.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["#FFC000","#FF6E00"],[0,1],20.1,10.8,0,20.1,10.8,42.7).s().p("AhDjXICChEIAFHyIiCBFg");
	this.shape_11.setTransform(53,25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],10,-20.1,-20,40.9).s().p("AhJFpIgIryICbAhIAILyg");
	this.shape_12.setTransform(3.6,5.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAQICEhDICxAkIiEBDg");
	this.shape_13.setTransform(9.8,-36.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["#FFC000","#FF6E00"],[0,1],20.5,16,0,20.5,16,57.1).s().p("AhElhICBhFIAIMJIiCBEg");
	this.shape_14.setTransform(19.1,4.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],9,-18,-21.2,43.5).s().p("AhHHpIgLvwICbAfIAKPwg");
	this.shape_15.setTransform(-30.2,-13.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAPICFhCICwAlIiEBCg");
	this.shape_16.setTransform(-24.1,-68.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["#FFC000","#FF6E00"],[0,1],20.8,20.8,0,20.8,20.8,71.3).s().p("AhGngICChFIALQHIiCBEg");
	this.shape_17.setTransform(-14.7,-15.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#FFDA3D","#FFC500","#FFF766","#FFC500"],[0,0.451,0.463,0.976],21,-42.5,-8.6,17.8).s().p("AhKEFIgGopICbAgIAFIpg");
	this.shape_18.setTransform(-63.7,2.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#FFC000","#FF6E00"],[0,1],20.2,12.2,0,20.2,12.2,46.5).s().p("AhEj9ICChEIAHI+IiDBFg");
	this.shape_19.setTransform(-48.2,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#FF8F00","#FFE100"],[0,1],-15.4,0,15.6,0).s().p("AiaAPICEhCICxAlIiEBCg");
	this.shape_20.setTransform(-57.4,-30.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#FFDA3D","#FFFFFF"],[0,1],-10.4,37.2,11.6,0).s().p("AOdKeIgCiUICzAkIABCUgAJLJZIAAhiICyAlIABBhgAD7IUIgDj1ICyAkIADD2gAhVHPIgFnyICwAjIAGH0gAmmGKIgIsIICzAkIAHMJgAr4FGIgKwHICzAkIAKQHgAxJEBIgGo/ICzAkIAFI/g");
	this.shape_21.setTransform(37.4,3.4);

	this.addChild(this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-72.9,-74.1,234,148.2);


(lib.frase3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("El número de computadores son las variables, el subconjunto de alumnos es la muestra y el número de alumnos con la misma respuesta se llama frecuencia. ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 788;
 var html = createDiv(txt['text4'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, -608);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,792,76.9);


(lib.frase2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text3'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 860;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,863.9,28.3);


(lib.frase1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text2'], "20px Verdana");
	this.text.lineHeight = 20;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,394.4,28.3);


(lib.fondo = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
	mask.setTransform(475,304);

	// Capa 2
	this.instance = new lib._01_OPT();
	this.instance.setTransform(23.8,61.7,0.832,0.832);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(23.8,61.7,903,636.7);


(lib.diagrama = function() {
	this.initialize();

	// Capa 5
	this.text = new cjs.Text("4 pc.: 12,5 %", "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(237.1,75.2);

	this.text_1 = new cjs.Text("3 pc: 17,5 %", "16px Verdana");
	this.text_1.lineHeight = 18;
	this.text_1.setTransform(172,-11);

	this.text_2 = new cjs.Text("2 pc: 35 %", "16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(-122,51.8);

	this.text_3 = new cjs.Text("5 pc: 5 %", "16px Verdana");
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(232.9,144.3);

	this.text_4 = new cjs.Text("1 pc: 25 %", "16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(61.5,246.5);

	this.text_5 = new cjs.Text("0 pc: 5 %", "16px Verdana");
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(217.9,186.9);

	this.text_6 = new cjs.Text(" ", "bold 8px ArialMT");
	this.text_6.lineHeight = 10;
	this.text_6.setTransform(286,11.5);

	this.text_7 = new cjs.Text("número de computadores", "bold 16px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(-0.9,-53);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AOZqxQAAAAAAABQDlEpAAGHQAABPgKBMQgXC5hPCiQhTCoiOCPQlRFRncAAQnbAAlRlRIAAgBQlRlQAAncQAAnbFRlRQD2j2FChCQB1gZB/AAQHcAAFRFRQA7A7AxBAgAj0xkID0RkIOZqxAssMsIMsssIR0CbAQOH2IwOn2IMtMt");
	this.shape.setTransform(113,120);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("Ao5j6IRzCdQgXC2hPCig");
	this.shape_1.setTransform(170,145.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF00FF").s().p("Ao+EKIOYqwIAAABQDlEqAAGGQAABQgKBMg");
	this.shape_2.setTransform(170.5,93.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#996600").s().p("ApGolQB2gYCAAAQHbAAFQFQQA7A8AxA/IuYKwg");
	this.shape_3.setTransform(146.8,62.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0000").s().p("Ao9CcQAAnbFQlRQD1j2FBhCID1RkIsrMtQlQlRAAncg");
	this.shape_4.setTransform(55.5,104.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0099FF").s().p("AssDuIAAAAIMsssIMtMsQlRFRncAAQnbAAlRlRg");
	this.shape_5.setTransform(113,177.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#339900").s().p("AoGmVIQNH1QhTCoiOCOg");
	this.shape_6.setTransform(164.9,160.6);

	this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-122,-53,483.4,323);


(lib.conclu4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("•", "20px Verdana");
	this.text.lineHeight = 20;

	this.text_1 = new cjs.Text(txt['text11'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 440;
	this.text_1.setTransform(17.6,1.1);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,462,55.7);


(lib.conclu3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("•", "20px Verdana");
	this.text.lineHeight = 20;

	this.text_1 = new cjs.Text(txt['text10'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 445;
	this.text_1.setTransform(17.6,1.1);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,467,55.7);


(lib.conclu2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("•", "20px Verdana");
	this.text.lineHeight = 20;

	this.text_1 = new cjs.Text(txt['text9'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 441;
	this.text_1.setTransform(17.6,1.1);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,463,55.7);


(lib.conclu1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("•", "20px Verdana");
	this.text.lineHeight = 20;

	this.text_1 = new cjs.Text(txt['text8'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 429;
	this.text_1.setTransform(17.6,1.1);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,451,55.7);


(lib.bt_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 25px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 27;
	this.text.lineWidth = 9;
	this.text.setTransform(-2,-17.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhhCUQgyAAAAgyIAAjDQAAgyAyAAIDDAAQAyAAAAAyIAADDQAAAygyAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]}).to({state:[{t:this.shape,p:{scaleX:1.248,scaleY:1.248,y:0.9}},{t:this.text,p:{scaleX:1.248,scaleY:1.248,x:-3.5,y:-21.1}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.8,-17.5,29.8,34.4);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.tabla4 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.tabla3();
	this.instance.setTransform(235,163,1,1,0,0,0,235,143);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,470,306);


(lib.diagramaAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.objeto1();
	this.instance.setTransform(212.1,-53.4,1,1,0,0,0,193,26.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(35).to({_off:false},0).to({alpha:1},19).wait(1));

	// Capa 1
	this.instance_1 = new lib.diagrama();
	this.instance_1.setTransform(205.1,168.1,1,1,0,0,0,115,115);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(35).to({_off:false},0).to({alpha:1},19).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.conclusiones1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.conclu1();
	this.instance.setTransform(787.1,105.5,1,1,0,0,0,416.6,14.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},15).wait(122));

	// Capa 4
	this.instance_1 = new lib.conclu2();
	this.instance_1.setTransform(787.1,178.8,1,1,0,0,0,416.6,14.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},0).to({alpha:1},19).wait(93));

	// Capa 3
	this.instance_2 = new lib.conclu3();
	this.instance_2.setTransform(787.1,252.1,1,1,0,0,0,416.6,14.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(58).to({_off:false},0).to({alpha:1},18).wait(65));

	// Capa 2
	this.instance_3 = new lib.conclu4();
	this.instance_3.setTransform(787.1,325.5,1,1,0,0,0,416.6,14.7);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(87).to({_off:false},0).to({alpha:1},20).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.tabla4();
	this.instance.setTransform(598.5,153,1,1,0,0,0,235,153);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).to({alpha:1},25).to({_off:false},1).wait(2));

	// Capa 1
	this.instance_1 = new lib.frase3();
	this.instance_1.setTransform(395.9,343.9,1,1,0,0,0,395.9,38.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({alpha:1},22).to({_off:true},51).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 7
	this.text = new cjs.Text("2", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(760.1,113.9);

	this.text_1 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(618.1,113.9);

	this.text_2 = new cjs.Text("2", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(760.1,113.9);

	this.text_3 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(618.1,113.9);

	this.text_4 = new cjs.Text("2", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(760.1,113.9);

	this.text_5 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(618.1,113.9);

	this.text_6 = new cjs.Text("2", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(760.1,113.9);

	this.text_7 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(618.1,113.9);

	this.text_8 = new cjs.Text("2", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(760.1,113.9);

	this.text_9 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(618.1,113.9);

	this.text_10 = new cjs.Text("2", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(760.1,113.9);

	this.text_11 = new cjs.Text("0", "16px Verdana", "#339900");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(618.1,113.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},132).to({state:[{t:this.text_1,p:{y:113.9,text:"0",color:"#339900"}},{t:this.text,p:{y:113.9,text:"2",lineWidth:10}}]},95).to({state:[{t:this.text_3,p:{y:113.9,text:"0",color:"#339900"}},{t:this.text_2,p:{y:113.9,text:"2",lineWidth:10}},{t:this.text_1,p:{y:143.9,text:"1",color:"#0066FF"}},{t:this.text,p:{y:143.9,text:"10",lineWidth:21}}]},13).to({state:[{t:this.text_5,p:{y:113.9,text:"0",color:"#339900"}},{t:this.text_4,p:{y:113.9,text:"2",lineWidth:10}},{t:this.text_3,p:{y:175.9,text:"2",color:"#CC0000"}},{t:this.text_2,p:{y:175.9,text:"14",lineWidth:21}},{t:this.text_1,p:{y:143.9,text:"1",color:"#0066FF"}},{t:this.text,p:{y:143.9,text:"10",lineWidth:21}}]},15).to({state:[{t:this.text_7,p:{y:113.9,text:"0",color:"#339900"}},{t:this.text_6,p:{y:113.9,text:"2",lineWidth:10}},{t:this.text_5,p:{y:175.9,text:"2",color:"#CC0000"}},{t:this.text_4,p:{y:175.9,text:"14",lineWidth:21}},{t:this.text_3,p:{y:143.9,text:"1",color:"#0066FF"}},{t:this.text_2,p:{y:143.9,text:"10",lineWidth:21}},{t:this.text_1,p:{y:208.9,text:"3",color:"#996600"}},{t:this.text,p:{y:208.9,text:"7",lineWidth:10}}]},14).to({state:[{t:this.text_9,p:{y:113.9,text:"0",color:"#339900"}},{t:this.text_8,p:{y:113.9,text:"2",lineWidth:10}},{t:this.text_7,p:{y:175.9,text:"2",color:"#CC0000"}},{t:this.text_6,p:{y:175.9,text:"14",lineWidth:21}},{t:this.text_5,p:{y:143.9,text:"1",color:"#0066FF"}},{t:this.text_4,p:{y:143.9,text:"10",lineWidth:21}},{t:this.text_3,p:{y:208.9,text:"3",color:"#996600"}},{t:this.text_2,p:{y:208.9,text:"7",lineWidth:10}},{t:this.text_1,p:{y:241.9,text:"4",color:"#FF00FF"}},{t:this.text,p:{y:241.9,text:"5",lineWidth:10}}]},15).to({state:[{t:this.text_11},{t:this.text_10},{t:this.text_9,p:{y:175.9,text:"2",color:"#CC0000"}},{t:this.text_8,p:{y:175.9,text:"14",lineWidth:21}},{t:this.text_7,p:{y:143.9,text:"1",color:"#0066FF"}},{t:this.text_6,p:{y:143.9,text:"10",lineWidth:21}},{t:this.text_5,p:{y:208.9,text:"3",color:"#996600"}},{t:this.text_4,p:{y:208.9,text:"7",lineWidth:10}},{t:this.text_3,p:{y:241.9,text:"4",color:"#FF00FF"}},{t:this.text_2,p:{y:241.9,text:"5",lineWidth:10}},{t:this.text_1,p:{y:275.9,text:"5",color:"#FF6600"}},{t:this.text,p:{y:275.9,text:"2",lineWidth:10}}]},16).wait(8));

	// Capa 4
	this.text_12 = new cjs.Text("1", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(130,260.9);

	this.text_13 = new cjs.Text("2", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(130,230.9);

	this.text_14 = new cjs.Text("1", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(130,200.9);

	this.text_15 = new cjs.Text("0", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(130,170.9);

	this.text_16 = new cjs.Text("1", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(130,260.9);

	this.text_17 = new cjs.Text("2", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(130,230.9);

	this.text_18 = new cjs.Text("1", "16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(130,200.9);

	this.text_19 = new cjs.Text("0", "16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(130,170.9);

	this.text_20 = new cjs.Text("1", "16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(130,260.9);

	this.text_21 = new cjs.Text("2", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(130,230.9);

	this.text_22 = new cjs.Text("1", "16px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(130,200.9);

	this.text_23 = new cjs.Text("0", "16px Verdana");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(130,170.9);

	this.text_24 = new cjs.Text("1", "16px Verdana");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(130,260.9);

	this.text_25 = new cjs.Text("2", "16px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(130,230.9);

	this.text_26 = new cjs.Text("1", "16px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(130,200.9);

	this.text_27 = new cjs.Text("0", "16px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(130,170.9);

	this.text_28 = new cjs.Text("1", "16px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(130,260.9);

	this.text_29 = new cjs.Text("2", "16px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(130,230.9);

	this.text_30 = new cjs.Text("1", "16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 16;
	this.text_30.setTransform(130,200.9);

	this.text_31 = new cjs.Text("0", "16px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(130,170.9);

	this.text_32 = new cjs.Text("1", "16px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(130,260.9);

	this.text_33 = new cjs.Text("2", "16px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(130,230.9);

	this.text_34 = new cjs.Text("1", "16px Verdana");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 16;
	this.text_34.setTransform(130,200.9);

	this.text_35 = new cjs.Text("0", "16px Verdana");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 16;
	this.text_35.setTransform(130,170.9);

	this.text_36 = new cjs.Text("1", "16px Verdana");
	this.text_36.textAlign = "center";
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(130,260.9);

	this.text_37 = new cjs.Text("2", "16px Verdana");
	this.text_37.textAlign = "center";
	this.text_37.lineHeight = 16;
	this.text_37.setTransform(130,230.9);

	this.text_38 = new cjs.Text("1", "16px Verdana");
	this.text_38.textAlign = "center";
	this.text_38.lineHeight = 16;
	this.text_38.setTransform(130,200.9);

	this.text_39 = new cjs.Text("0", "16px Verdana");
	this.text_39.textAlign = "center";
	this.text_39.lineHeight = 16;
	this.text_39.setTransform(130,170.9);

	this.text_40 = new cjs.Text("1", "16px Verdana");
	this.text_40.textAlign = "center";
	this.text_40.lineHeight = 16;
	this.text_40.setTransform(130,260.9);

	this.text_41 = new cjs.Text("2", "16px Verdana");
	this.text_41.textAlign = "center";
	this.text_41.lineHeight = 16;
	this.text_41.setTransform(130,230.9);

	this.text_42 = new cjs.Text("1", "16px Verdana");
	this.text_42.textAlign = "center";
	this.text_42.lineHeight = 16;
	this.text_42.setTransform(130,200.9);

	this.text_43 = new cjs.Text("0", "16px Verdana");
	this.text_43.textAlign = "center";
	this.text_43.lineHeight = 16;
	this.text_43.setTransform(130,170.9);

	this.text_44 = new cjs.Text("1", "16px Verdana");
	this.text_44.textAlign = "center";
	this.text_44.lineHeight = 16;
	this.text_44.setTransform(130,260.9);

	this.text_45 = new cjs.Text("2", "16px Verdana");
	this.text_45.textAlign = "center";
	this.text_45.lineHeight = 16;
	this.text_45.setTransform(130,230.9);

	this.text_46 = new cjs.Text("1", "16px Verdana");
	this.text_46.textAlign = "center";
	this.text_46.lineHeight = 16;
	this.text_46.setTransform(130,200.9);

	this.text_47 = new cjs.Text("0", "16px Verdana");
	this.text_47.textAlign = "center";
	this.text_47.lineHeight = 16;
	this.text_47.setTransform(130,170.9);

	this.text_48 = new cjs.Text("1", "16px Verdana");
	this.text_48.textAlign = "center";
	this.text_48.lineHeight = 16;
	this.text_48.setTransform(130,260.9);

	this.text_49 = new cjs.Text("2", "16px Verdana");
	this.text_49.textAlign = "center";
	this.text_49.lineHeight = 16;
	this.text_49.setTransform(130,230.9);

	this.text_50 = new cjs.Text("1", "16px Verdana");
	this.text_50.textAlign = "center";
	this.text_50.lineHeight = 16;
	this.text_50.setTransform(130,200.9);

	this.text_51 = new cjs.Text("0", "16px Verdana");
	this.text_51.textAlign = "center";
	this.text_51.lineHeight = 16;
	this.text_51.setTransform(130,170.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_15,p:{x:130,text:"0",y:170.9,color:"#000000"}},{t:this.text_14,p:{x:130,text:"1",y:200.9,color:"#000000"}},{t:this.text_13,p:{x:130,text:"2",y:230.9,color:"#000000"}},{t:this.text_12,p:{x:130,text:"1",y:260.9,color:"#000000"}}]},34).to({state:[{t:this.text_19,p:{x:130,text:"0",y:170.9,color:"#000000"}},{t:this.text_18,p:{x:130,text:"1",y:200.9,color:"#000000"}},{t:this.text_17,p:{x:130,text:"2",y:230.9,color:"#000000"}},{t:this.text_16,p:{x:130,text:"1",y:260.9,color:"#000000"}},{t:this.text_15,p:{x:170,text:"2",y:170.9,color:"#000000"}},{t:this.text_14,p:{x:170,text:"3",y:200.9,color:"#000000"}},{t:this.text_13,p:{x:170,text:"1",y:230.9,color:"#000000"}},{t:this.text_12,p:{x:170,text:"2",y:260.9,color:"#000000"}}]},10).to({state:[{t:this.text_23,p:{x:130,text:"0",y:170.9,color:"#000000"}},{t:this.text_22,p:{x:130,text:"1",y:200.9,color:"#000000"}},{t:this.text_21,p:{x:130,text:"2",y:230.9,color:"#000000"}},{t:this.text_20,p:{x:130,text:"1",y:260.9,color:"#000000"}},{t:this.text_19,p:{x:170,text:"2",y:170.9,color:"#000000"}},{t:this.text_18,p:{x:170,text:"3",y:200.9,color:"#000000"}},{t:this.text_17,p:{x:170,text:"1",y:230.9,color:"#000000"}},{t:this.text_16,p:{x:170,text:"2",y:260.9,color:"#000000"}},{t:this.text_15,p:{x:209,text:"0",y:170.9,color:"#000000"}},{t:this.text_14,p:{x:209,text:"1",y:200.9,color:"#000000"}},{t:this.text_13,p:{x:209,text:"1",y:230.9,color:"#000000"}},{t:this.text_12,p:{x:209,text:"2",y:260.9,color:"#000000"}}]},10).to({state:[{t:this.text_27,p:{x:130,text:"0",y:170.9,color:"#000000"}},{t:this.text_26,p:{x:130,text:"1",y:200.9,color:"#000000"}},{t:this.text_25,p:{x:130,text:"2",y:230.9,color:"#000000"}},{t:this.text_24,p:{x:130,text:"1",y:260.9,color:"#000000"}},{t:this.text_23,p:{x:170,text:"2",y:170.9,color:"#000000"}},{t:this.text_22,p:{x:170,text:"3",y:200.9,color:"#000000"}},{t:this.text_21,p:{x:170,text:"1",y:230.9,color:"#000000"}},{t:this.text_20,p:{x:170,text:"2",y:260.9,color:"#000000"}},{t:this.text_19,p:{x:209,text:"0",y:170.9,color:"#000000"}},{t:this.text_18,p:{x:209,text:"1",y:200.9,color:"#000000"}},{t:this.text_17,p:{x:209,text:"1",y:230.9,color:"#000000"}},{t:this.text_16,p:{x:209,text:"2",y:260.9,color:"#000000"}},{t:this.text_15,p:{x:248,text:"2",y:170.9,color:"#000000"}},{t:this.text_14,p:{x:248,text:"2",y:200.9,color:"#000000"}},{t:this.text_13,p:{x:248,text:"2",y:230.9,color:"#000000"}},{t:this.text_12,p:{x:248,text:"3",y:260.9,color:"#000000"}}]},11).to({state:[{t:this.text_31,p:{x:130,text:"0",y:170.9,color:"#000000"}},{t:this.text_30,p:{x:130,text:"1",y:200.9,color:"#000000"}},{t:this.text_29,p:{x:130,text:"2",y:230.9,color:"#000000"}},{t:this.text_28,p:{x:130,text:"1",y:260.9,color:"#000000"}},{t:this.text_27,p:{x:170,text:"2",y:170.9,color:"#000000"}},{t:this.text_26,p:{x:170,text:"3",y:200.9,color:"#000000"}},{t:this.text_25,p:{x:170,text:"1",y:230.9,color:"#000000"}},{t:this.text_24,p:{x:170,text:"2",y:260.9,color:"#000000"}},{t:this.text_23,p:{x:209,text:"0",y:170.9,color:"#000000"}},{t:this.text_22,p:{x:209,text:"1",y:200.9,color:"#000000"}},{t:this.text_21,p:{x:209,text:"1",y:230.9,color:"#000000"}},{t:this.text_20,p:{x:209,text:"2",y:260.9,color:"#000000"}},{t:this.text_19,p:{x:248,text:"2",y:170.9,color:"#000000"}},{t:this.text_18,p:{x:248,text:"2",y:200.9,color:"#000000"}},{t:this.text_17,p:{x:248,text:"2",y:230.9,color:"#000000"}},{t:this.text_16,p:{x:248,text:"3",y:260.9,color:"#000000"}},{t:this.text_15,p:{x:288,text:"3",y:170.9,color:"#000000"}},{t:this.text_14,p:{x:288,text:"3",y:200.9,color:"#000000"}},{t:this.text_13,p:{x:288,text:"5",y:230.9,color:"#000000"}},{t:this.text_12,p:{x:288,text:"5",y:260.9,color:"#000000"}}]},10).to({state:[{t:this.text_35,p:{x:130,text:"0",color:"#000000"}},{t:this.text_34,p:{x:130,text:"1",color:"#000000"}},{t:this.text_33,p:{x:130,text:"2",color:"#000000"}},{t:this.text_32,p:{x:130,text:"1",color:"#000000"}},{t:this.text_31,p:{x:170,text:"2",y:170.9,color:"#000000"}},{t:this.text_30,p:{x:170,text:"3",y:200.9,color:"#000000"}},{t:this.text_29,p:{x:170,text:"1",y:230.9,color:"#000000"}},{t:this.text_28,p:{x:170,text:"2",y:260.9,color:"#000000"}},{t:this.text_27,p:{x:209,text:"0",y:170.9,color:"#000000"}},{t:this.text_26,p:{x:209,text:"1",y:200.9,color:"#000000"}},{t:this.text_25,p:{x:209,text:"1",y:230.9,color:"#000000"}},{t:this.text_24,p:{x:209,text:"2",y:260.9,color:"#000000"}},{t:this.text_23,p:{x:248,text:"2",y:170.9,color:"#000000"}},{t:this.text_22,p:{x:248,text:"2",y:200.9,color:"#000000"}},{t:this.text_21,p:{x:248,text:"2",y:230.9,color:"#000000"}},{t:this.text_20,p:{x:248,text:"3",y:260.9,color:"#000000"}},{t:this.text_19,p:{x:288,text:"3",y:170.9,color:"#000000"}},{t:this.text_18,p:{x:288,text:"3",y:200.9,color:"#000000"}},{t:this.text_17,p:{x:288,text:"5",y:230.9,color:"#000000"}},{t:this.text_16,p:{x:288,text:"5",y:260.9,color:"#000000"}},{t:this.text_15,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:328,text:"2",y:261.3,color:"#000000"}}]},10).to({state:[{t:this.text_39,p:{x:130,text:"0",color:"#000000"}},{t:this.text_38,p:{x:130,text:"1",color:"#000000"}},{t:this.text_37,p:{x:130,text:"2",color:"#000000"}},{t:this.text_36,p:{x:130,text:"1",color:"#000000"}},{t:this.text_35,p:{x:170,text:"2",color:"#000000"}},{t:this.text_34,p:{x:170,text:"3",color:"#000000"}},{t:this.text_33,p:{x:170,text:"1",color:"#000000"}},{t:this.text_32,p:{x:170,text:"2",color:"#000000"}},{t:this.text_31,p:{x:209,text:"0",y:170.9,color:"#000000"}},{t:this.text_30,p:{x:209,text:"1",y:200.9,color:"#000000"}},{t:this.text_29,p:{x:209,text:"1",y:230.9,color:"#000000"}},{t:this.text_28,p:{x:209,text:"2",y:260.9,color:"#000000"}},{t:this.text_27,p:{x:248,text:"2",y:170.9,color:"#000000"}},{t:this.text_26,p:{x:248,text:"2",y:200.9,color:"#000000"}},{t:this.text_25,p:{x:248,text:"2",y:230.9,color:"#000000"}},{t:this.text_24,p:{x:248,text:"3",y:260.9,color:"#000000"}},{t:this.text_23,p:{x:288,text:"3",y:170.9,color:"#000000"}},{t:this.text_22,p:{x:288,text:"3",y:200.9,color:"#000000"}},{t:this.text_21,p:{x:288,text:"5",y:230.9,color:"#000000"}},{t:this.text_20,p:{x:288,text:"5",y:260.9,color:"#000000"}},{t:this.text_19,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:367,text:"1",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:367,text:"1",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:367,text:"3",y:261.3,color:"#000000"}}]},11).to({state:[{t:this.text_43,p:{x:130,text:"0",color:"#000000"}},{t:this.text_42,p:{x:130,text:"1",color:"#000000"}},{t:this.text_41,p:{x:130,text:"2",color:"#000000"}},{t:this.text_40,p:{x:130,text:"1",color:"#000000"}},{t:this.text_39,p:{x:170,text:"2",color:"#000000"}},{t:this.text_38,p:{x:170,text:"3",color:"#000000"}},{t:this.text_37,p:{x:170,text:"1",color:"#000000"}},{t:this.text_36,p:{x:170,text:"2",color:"#000000"}},{t:this.text_35,p:{x:209,text:"0",color:"#000000"}},{t:this.text_34,p:{x:209,text:"1",color:"#000000"}},{t:this.text_33,p:{x:209,text:"1",color:"#000000"}},{t:this.text_32,p:{x:209,text:"2",color:"#000000"}},{t:this.text_31,p:{x:248,text:"2",y:170.9,color:"#000000"}},{t:this.text_30,p:{x:248,text:"2",y:200.9,color:"#000000"}},{t:this.text_29,p:{x:248,text:"2",y:230.9,color:"#000000"}},{t:this.text_28,p:{x:248,text:"3",y:260.9,color:"#000000"}},{t:this.text_27,p:{x:288,text:"3",y:170.9,color:"#000000"}},{t:this.text_26,p:{x:288,text:"3",y:200.9,color:"#000000"}},{t:this.text_25,p:{x:288,text:"5",y:230.9,color:"#000000"}},{t:this.text_24,p:{x:288,text:"5",y:260.9,color:"#000000"}},{t:this.text_23,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_22,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_19,p:{x:367,text:"1",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:367,text:"1",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:406,text:"1",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:406,text:"2",y:261.3,color:"#000000"}}]},12).to({state:[{t:this.text_47,p:{x:130,text:"0",color:"#000000"}},{t:this.text_46,p:{x:130,text:"1",color:"#000000"}},{t:this.text_45,p:{x:130,text:"2",color:"#000000"}},{t:this.text_44,p:{x:130,text:"1",color:"#000000"}},{t:this.text_43,p:{x:170,text:"2",color:"#000000"}},{t:this.text_42,p:{x:170,text:"3",color:"#000000"}},{t:this.text_41,p:{x:170,text:"1",color:"#000000"}},{t:this.text_40,p:{x:170,text:"2",color:"#000000"}},{t:this.text_39,p:{x:209,text:"0",color:"#000000"}},{t:this.text_38,p:{x:209,text:"1",color:"#000000"}},{t:this.text_37,p:{x:209,text:"1",color:"#000000"}},{t:this.text_36,p:{x:209,text:"2",color:"#000000"}},{t:this.text_35,p:{x:248,text:"2",color:"#000000"}},{t:this.text_34,p:{x:248,text:"2",color:"#000000"}},{t:this.text_33,p:{x:248,text:"2",color:"#000000"}},{t:this.text_32,p:{x:248,text:"3",color:"#000000"}},{t:this.text_31,p:{x:288,text:"3",y:170.9,color:"#000000"}},{t:this.text_30,p:{x:288,text:"3",y:200.9,color:"#000000"}},{t:this.text_29,p:{x:288,text:"5",y:230.9,color:"#000000"}},{t:this.text_28,p:{x:288,text:"5",y:260.9,color:"#000000"}},{t:this.text_27,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_26,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_25,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_23,p:{x:367,text:"1",y:171.3,color:"#000000"}},{t:this.text_22,p:{x:367,text:"1",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_19,p:{x:406,text:"1",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:406,text:"2",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:445,text:"2",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:445,text:"2",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:445,text:"2",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:445,text:"3",y:261.3,color:"#000000"}}]},12).to({state:[{t:this.text_51,p:{color:"#000000"}},{t:this.text_50,p:{color:"#000000"}},{t:this.text_49,p:{color:"#000000"}},{t:this.text_48,p:{color:"#000000"}},{t:this.text_47,p:{x:170,text:"2",color:"#000000"}},{t:this.text_46,p:{x:170,text:"3",color:"#000000"}},{t:this.text_45,p:{x:170,text:"1",color:"#000000"}},{t:this.text_44,p:{x:170,text:"2",color:"#000000"}},{t:this.text_43,p:{x:209,text:"0",color:"#000000"}},{t:this.text_42,p:{x:209,text:"1",color:"#000000"}},{t:this.text_41,p:{x:209,text:"1",color:"#000000"}},{t:this.text_40,p:{x:209,text:"2",color:"#000000"}},{t:this.text_39,p:{x:248,text:"2",color:"#000000"}},{t:this.text_38,p:{x:248,text:"2",color:"#000000"}},{t:this.text_37,p:{x:248,text:"2",color:"#000000"}},{t:this.text_36,p:{x:248,text:"3",color:"#000000"}},{t:this.text_35,p:{x:288,text:"3",color:"#000000"}},{t:this.text_34,p:{x:288,text:"3",color:"#000000"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#000000"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#000000"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#000000"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#000000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#000000"}}]},12).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#000000"}},{t:this.text_49,p:{color:"#000000"}},{t:this.text_48,p:{color:"#000000"}},{t:this.text_47,p:{x:170,text:"2",color:"#000000"}},{t:this.text_46,p:{x:170,text:"3",color:"#000000"}},{t:this.text_45,p:{x:170,text:"1",color:"#000000"}},{t:this.text_44,p:{x:170,text:"2",color:"#000000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#000000"}},{t:this.text_41,p:{x:209,text:"1",color:"#000000"}},{t:this.text_40,p:{x:209,text:"2",color:"#000000"}},{t:this.text_39,p:{x:248,text:"2",color:"#000000"}},{t:this.text_38,p:{x:248,text:"2",color:"#000000"}},{t:this.text_37,p:{x:248,text:"2",color:"#000000"}},{t:this.text_36,p:{x:248,text:"3",color:"#000000"}},{t:this.text_35,p:{x:288,text:"3",color:"#000000"}},{t:this.text_34,p:{x:288,text:"3",color:"#000000"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#000000"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#000000"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#000000"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#000000"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#000000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#000000"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#000000"}}]},95).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#0066FF"}},{t:this.text_49,p:{color:"#000000"}},{t:this.text_48,p:{color:"#0066FF"}},{t:this.text_47,p:{x:170,text:"2",color:"#000000"}},{t:this.text_46,p:{x:170,text:"3",color:"#000000"}},{t:this.text_45,p:{x:170,text:"1",color:"#0066FF"}},{t:this.text_44,p:{x:170,text:"2",color:"#000000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_41,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_40,p:{x:209,text:"2",color:"#000000"}},{t:this.text_39,p:{x:248,text:"2",color:"#000000"}},{t:this.text_38,p:{x:248,text:"2",color:"#000000"}},{t:this.text_37,p:{x:248,text:"2",color:"#000000"}},{t:this.text_36,p:{x:248,text:"3",color:"#000000"}},{t:this.text_35,p:{x:288,text:"3",color:"#000000"}},{t:this.text_34,p:{x:288,text:"3",color:"#000000"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#000000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#0066FF"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#000000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#000000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#000000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#000000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#000000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#000000"}}]},13).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#0066FF"}},{t:this.text_49,p:{color:"#CC0000"}},{t:this.text_48,p:{color:"#0066FF"}},{t:this.text_47,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_46,p:{x:170,text:"3",color:"#000000"}},{t:this.text_45,p:{x:170,text:"1",color:"#0066FF"}},{t:this.text_44,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_41,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_40,p:{x:209,text:"2",color:"#CC0000"}},{t:this.text_39,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_38,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_37,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_36,p:{x:248,text:"3",color:"#000000"}},{t:this.text_35,p:{x:288,text:"3",color:"#000000"}},{t:this.text_34,p:{x:288,text:"3",color:"#000000"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#000000"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#0066FF"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#000000"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#CC0000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#CC0000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#000000"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#CC0000"}}]},15).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#0066FF"}},{t:this.text_49,p:{color:"#CC0000"}},{t:this.text_48,p:{color:"#0066FF"}},{t:this.text_47,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_46,p:{x:170,text:"3",color:"#996600"}},{t:this.text_45,p:{x:170,text:"1",color:"#0066FF"}},{t:this.text_44,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_41,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_40,p:{x:209,text:"2",color:"#CC0000"}},{t:this.text_39,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_38,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_37,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_36,p:{x:248,text:"3",color:"#996600"}},{t:this.text_35,p:{x:288,text:"3",color:"#996600"}},{t:this.text_34,p:{x:288,text:"3",color:"#996600"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#000000"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#996600"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#0066FF"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#000000"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#996600"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#000000"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#000000"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#CC0000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#CC0000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#996600"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#000000"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#CC0000"}}]},14).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#0066FF"}},{t:this.text_49,p:{color:"#CC0000"}},{t:this.text_48,p:{color:"#0066FF"}},{t:this.text_47,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_46,p:{x:170,text:"3",color:"#996600"}},{t:this.text_45,p:{x:170,text:"1",color:"#0066FF"}},{t:this.text_44,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_41,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_40,p:{x:209,text:"2",color:"#CC0000"}},{t:this.text_39,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_38,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_37,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_36,p:{x:248,text:"3",color:"#996600"}},{t:this.text_35,p:{x:288,text:"3",color:"#996600"}},{t:this.text_34,p:{x:288,text:"3",color:"#996600"}},{t:this.text_33,p:{x:288,text:"5",color:"#000000"}},{t:this.text_32,p:{x:288,text:"5",color:"#000000"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#996600"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#0066FF"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#FF00FF"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#996600"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#FF00FF"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#CC0000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#CC0000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#996600"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#CC0000"}}]},15).to({state:[{t:this.text_51,p:{color:"#339900"}},{t:this.text_50,p:{color:"#0066FF"}},{t:this.text_49,p:{color:"#CC0000"}},{t:this.text_48,p:{color:"#0066FF"}},{t:this.text_47,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_46,p:{x:170,text:"3",color:"#996600"}},{t:this.text_45,p:{x:170,text:"1",color:"#0066FF"}},{t:this.text_44,p:{x:170,text:"2",color:"#CC0000"}},{t:this.text_43,p:{x:209,text:"0",color:"#339900"}},{t:this.text_42,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_41,p:{x:209,text:"1",color:"#0066FF"}},{t:this.text_40,p:{x:209,text:"2",color:"#CC0000"}},{t:this.text_39,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_38,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_37,p:{x:248,text:"2",color:"#CC0000"}},{t:this.text_36,p:{x:248,text:"3",color:"#996600"}},{t:this.text_35,p:{x:288,text:"3",color:"#996600"}},{t:this.text_34,p:{x:288,text:"3",color:"#996600"}},{t:this.text_33,p:{x:288,text:"5",color:"#FF6600"}},{t:this.text_32,p:{x:288,text:"5",color:"#FF6600"}},{t:this.text_31,p:{x:328,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_30,p:{x:328,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_29,p:{x:328,text:"3",y:231.3,color:"#996600"}},{t:this.text_28,p:{x:328,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_27,p:{x:367,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_26,p:{x:367,text:"1",y:201.3,color:"#0066FF"}},{t:this.text_25,p:{x:367,text:"4",y:231.3,color:"#FF00FF"}},{t:this.text_24,p:{x:367,text:"3",y:261.3,color:"#996600"}},{t:this.text_23,p:{x:406,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_22,p:{x:406,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_21,p:{x:406,text:"4",y:231.3,color:"#FF00FF"}},{t:this.text_20,p:{x:406,text:"2",y:261.3,color:"#CC0000"}},{t:this.text_19,p:{x:445,text:"2",y:171.3,color:"#CC0000"}},{t:this.text_18,p:{x:445,text:"2",y:201.3,color:"#CC0000"}},{t:this.text_17,p:{x:445,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_16,p:{x:445,text:"3",y:261.3,color:"#996600"}},{t:this.text_15,p:{x:483,text:"1",y:171.3,color:"#0066FF"}},{t:this.text_14,p:{x:483,text:"4",y:201.3,color:"#FF00FF"}},{t:this.text_13,p:{x:483,text:"2",y:231.3,color:"#CC0000"}},{t:this.text_12,p:{x:483,text:"2",y:261.3,color:"#CC0000"}}]},16).wait(8));

	// Capa 6
	this.instance = new lib.frase1();
	this.instance.setTransform(200.2,14.2,1,1,0,0,0,197.2,14.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},17).wait(287));

	// Capa 5
	this.instance_1 = new lib.tabla1();
	this.instance_1.setTransform(254.5,196.1-incremento,1,1,0,0,0,251.5,92);

	this.text_52 = new cjs.Text("Toma de datos:", "20px Verdana");
	this.text_52.lineHeight = 20;
	this.text_52.lineWidth = 419;
	this.text_52.setTransform(5,60);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_52},{t:this.instance_1}]}).wait(308));

	// Capa 3
	this.instance_2 = new lib.frase2();
	this.instance_2.setTransform(431.9,337.2,1,1,0,0,0,431.9,14.2);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(142).to({alpha:1},17).wait(149));

	// Capa 2
	this.instance_3 = new lib.tabla2();
	this.instance_3.setTransform(691,185.1-incremento,1,1,0,0,0,140,118);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(181).to({alpha:1},23).wait(104));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,60,863.9,291.3);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}