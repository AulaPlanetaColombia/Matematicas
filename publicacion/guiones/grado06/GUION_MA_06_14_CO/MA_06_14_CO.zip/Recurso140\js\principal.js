(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,2,0,0,0);
      if (isbq)
        this.text = new cjs.Text(txt['titulo'], "29px Georgia");
    else
                this.text = new cjs.Text(txt['titulo'], "31px Georgia");

	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.setTransform(473.5,61.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().rr(-395.5,-38,791,76,10);
	this.shape.setTransform(474.9,81);

	this.instance = new lib.fondoMC();
	this.instance.setTransform(475.5,304,1,1,0,0,0,475,304);
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
       
        this.addChild(this.instance,this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.shape,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.instance = new lib.imagen1();
	this.instance.setTransform(710,331.8,1,1,0,0,0,199.4,199.4);

	this.text = new cjs.Text("Las medidas de centralización son parámetros que recogen las principales características de un estudio estadístico. Las principales medidas de centralización son la media aritmética, la mediana y la moda. \n \nUn examen podemos considerarlo como un estudio estadístico con el que queremos evaluar los conocimientos adquiridos en la materia.  ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 363;
	this.text.setTransform(78.4,165.9);
 var html = createDiv(txt['text1'], "Verdana", "20px", '370px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 165-608);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();
var inc=4-incremento;
var incbq=0;
if (isbq) incbq=36;
        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhKAAICVAA");
	this.shape.setTransform(390-incbq,220-inc*2);

	this.instance = new lib.tabla1();
	this.instance.setTransform(79.4,374.4);

	this.text = new cjs.Text("La media aritmética es el cociente entre la suma de todos los datos y el número total de datos.  \n                                \nSe representa mediante una X.\n\nEn el colegio hay 31 alumnos de sexto grado. Para comenzar el estudio estadístico anotamos las notas de la lista en una tabla.", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 790;
	this.text.setTransform(78.4,134.4);
var html = createDiv(txt['text2'], "Verdana", "20px", '800px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 134-608);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text,this.instance,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance = new lib.animacion1();
	this.instance.setTransform(472.4,290.7,1,1,0,0,0,394.4,156.8);

	this.instance_1 = new lib.animacionTablas();
	this.instance_1.setTransform(79,374);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     this.text = new cjs.Text(txt['text6'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 744;
	this.text.setTransform(86,47.9);

//	this.instance = new lib.tabla2("single",9);
//	this.instance.setTransform(79,374);

	this.instance_1 = new lib.grafico1();
	this.instance_1.setTransform(482.4,341,1,1,0,0,0,314.3,191.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
   this.instance = new lib.tabla3Anim();
	this.instance.setTransform(479.9,403.4,1,1,0,0,0,395.9,49.1);

	this.text = new cjs.Text("La mediana es el valor central de una serie de datos ordenados de mayor a menor. Se representa por Me. \n\nPara identificar la mediana en la tabla de notas, buscamos el valor que divide en dos la serie ordenada, el valor que deja tantos datos por arriba como por debajo.", "bold 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 777;
	this.text.setTransform(82,132.9);
 var html = createDiv(txt['text7'], "Verdana", "20px", '780px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 132-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
   this.text = new cjs.Text("Mientras que la media (6) se ve afectada por valores extremos, \nla mediana (5) indica el valor de corte. En consecuencia, han suspendido casi el mismo número de alumnos que han aprobado.", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 777;
	this.text.setTransform(86.4,47.9);
var html = createDiv(txt['text8'], "Verdana", "20px", '780px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 47-608);


	this.instance_1 = new lib.grafico2();
	this.instance_1.setTransform(482.9,341,1,1,0,0,0,314.3,191.2);
 
     this.informacion.on("click", function (evt) {
            putStage(new lib.framei1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion,this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
   this.instance = new lib.tabla4Anim();
	this.instance.setTransform(480.4,403.4,1,1,0,0,0,395.9,49.1);

	this.text = new cjs.Text("La moda  es el valor que se repite más veces en la serie de datos, por lo tanto, es el valor que tiene la mayor frecuencia. Se representa como Mo. En la tabla de notas\n\nModa = Mo = 4", "bold 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 777;
	this.text.setTransform(82.4,132.9);
var html = createDiv(txt['text9'], "Verdana", "20px", '780px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 132-608);


 
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion,this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
  this.text = new cjs.Text("La moda es 4, lo que quiere decir que esa fue la nota que más se repitió \nen el examen.", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 832;
	this.text.setTransform(86.4,47.9);

	this.instance = new lib.grafico3();
	this.instance.setTransform(482.9,341,1,1,0,0,0,314.3,191.2);
var html = createDiv(txt['text10'], "Verdana", "20px", '840px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 47-608);


 
     this.informacion.on("click", function (evt) {
            putStage(new lib.framei2());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion,this.anterior, this.siguiente,this.instance_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame10 = function () {
        this.initialize();
        clearTexts();
var inc=4-incremento;

var incbq=0;
if (isbq) incbq=38;

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
      this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhKAAICVAA");
	this.shape.setTransform(300+incbq,208-incbq/1.6-inc*2,0.758,1);

	

	this.text_1 = new cjs.Text("Las medidas de centralización del examen de matemáticas de sexto grado \nhan resultado:\n\n              X = 6            Mediana = 5           Moda = 4\n\nLas conclusiones que podemos extraer son:\nQue si la media ha sido buena es gracias a ocho alumnos que han hecho muy bien el examen.\nQue han suspendido casi tantos alumnos como han aprobado.\nQue la nota más frecuente ha sido el 4.\n\nPor lo tanto, no podemos decir que ha sido un buen examen. Los conocimientos adquiridos son, en general, insuficientes y tendremos que buscar una manera de reforzar el aprendizaje en matemáticas.", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 793;
	this.text_1.setTransform(81,152.9);
var html = createDiv(txt['text11'], "Verdana", "20px", '800px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(90, 152-638);

	this.text_2 = new cjs.Text("Conclusiones", "bold 23px Verdana", "#FF6600");
	this.text_2.lineHeight = 23;
	this.text_2.lineWidth = 832;
	this.text_2.setTransform(84,69.9);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.text_2,this.text_1,this.text,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.framei1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,1,0);
      this.text = new cjs.Text("Nota", "bold 23px Verdana", "#FF6600");
	this.text.lineHeight = 25;
	this.text.setTransform(82,65.9);
var incbq=0;
if (isbq) incbq=122;

	this.text1 = new cjs.Text("2", "20px Verdana");
	this.text1.setTransform(620-incbq,340);
var html = createDiv(txt['text12'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(90, 153-608);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("AkcAAII5AA");
	this.shape.setTransform(624-incbq,337);
  this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.informacion,this.cerrar,this.shape,this.text_1,this.text,this.text1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.framei2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,1,0);
      this.text = new cjs.Text("Nota", "bold 23px Verdana", "#FF6600");
	this.text.lineHeight = 25;
	this.text.setTransform(82,65.9);

	
var html = createDiv(txt['text13'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(90, 153-608);

	
  this.cerrar.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.informacion,this.cerrar,this.shape,this.text_1,this.text,this.text1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._01_OPT = function() {
	this.initialize(img._01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,633);


(lib._02_OPT = function() {
	this.initialize(img._02_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,400);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.torres3 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C0C0C0").s().p("AjDPzIAA/lIGHAAIAAflg");
	this.shape.setTransform(372.5,176.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C0C0C0").s().p("AjDF6IAAryIGHAAIAALyg");
	this.shape_1.setTransform(220.6,240);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C0C0C0").s().p("AjDH5IAAvxIGHAAIAAPxg");
	this.shape_2.setTransform(19.6,227.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF99FF").s().p("AjCVtMAAAgrZIGFAAMAAAArZg");
	this.shape_3.setTransform(69.9,138.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C0C0C0").s().p("AA2H5IAAvxIGIAAIAAPxgAm9H5IAAkAIGHAAIAAEAg");
	this.shape_4.setTransform(145.2,227.3);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,392.1,277.8);


(lib.torres2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C0C0C0").s().p("AjDPzIAA/lIGHAAIAAflg");
	this.shape.setTransform(372.5,176.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C0C0C0").s().p("AjDF6IAAryIGHAAIAALyg");
	this.shape_1.setTransform(220.6,240);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C0C0C0").s().p("AjCVtMAAAgrZIGFAAMAAAArZg");
	this.shape_2.setTransform(69.9,138.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C0C0C0").s().p("AjDH5IAAvxIGHAAIAAPxg");
	this.shape_3.setTransform(19.6,227.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#66CC00").s().p("AjCCAIAAj/IGFAAIAAD/g");
	this.shape_4.setTransform(120.1,265);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C0C0C0").s().p("AjDH5IAAvxIGGAAIAAPxg");
	this.shape_5.setTransform(170.3,227.3);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,392.1,277.8);


(lib.torres1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C0C0C0").s().p("AjDPzIAA/lIGHAAIAAflg");
	this.shape.setTransform(372.5,176.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C0C0C0").s().p("AjDF6IAAryIGHAAIAALyg");
	this.shape_1.setTransform(220.6,240);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00CCFF").s().p("AjDH5IAAvxIGGAAIAAPxg");
	this.shape_2.setTransform(170.3,227.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C0C0C0").s().p("AjCCAIAAj/IGFAAIAAD/g");
	this.shape_3.setTransform(120.1,265);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C0C0C0").s().p("AjCVtMAAAgrZIGFAAMAAAArZg");
	this.shape_4.setTransform(69.9,138.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C0C0C0").s().p("AjDH5IAAvxIGHAAIAAPxg");
	this.shape_5.setTransform(19.6,227.3);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,392.1,277.8);


(lib.tabla4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("186", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(747,70.9);

	this.text_1 = new cjs.Text("8", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(715.2,38.9);

	this.text_2 = new cjs.Text("0", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(675.2,38.9);

	this.text_3 = new cjs.Text("0", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(636.2,38.9);

	this.text_4 = new cjs.Text("3", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(597.2,38.9);

	this.text_5 = new cjs.Text("4", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(558.2,38.9);

	this.text_6 = new cjs.Text("1", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(518.2,38.9);

	this.text_7 = new cjs.Text("11", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(478.2,38.9);

	this.text_8 = new cjs.Text("4", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(439.2,38.9);

	this.text_9 = new cjs.Text("0", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(400.2,38.9);

	this.text_10 = new cjs.Text("0", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(361.2,38.9);

	this.text_11 = new cjs.Text("0", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(323.2,38.9);

	this.text_12 = new cjs.Text("10", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(715.2,4.9);

	this.text_13 = new cjs.Text("9", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(675.2,4.9);

	this.text_14 = new cjs.Text("8", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(636.2,4.9);

	this.text_15 = new cjs.Text("7", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(597.2,4.9);

	this.text_16 = new cjs.Text("6", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(558.2,4.9);

	this.text_17 = new cjs.Text("5", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(518.2,4.9);

	this.text_18 = new cjs.Text("4", "16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(478.2,4.9);

	this.text_19 = new cjs.Text("3", "16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(439.2,4.9);

	this.text_20 = new cjs.Text("2", "16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(400.2,4.9);

	this.text_21 = new cjs.Text("1", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(361.2,4.9);

	this.text_22 = new cjs.Text("0", "16px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(323.2,4.9);

	this.text_23 = new cjs.Text("31", "16px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(754,39.9);

	this.text_24 = new cjs.Text("TOTAL", "15px Verdana");
	this.text_24.lineHeight = 15;
	this.text_24.setTransform(739,5.9);

	this.text_25 = new cjs.Text("80", "16px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(715.2,70.9);

	this.text_26 = new cjs.Text("0", "16px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(675.2,70.9);

	this.text_27 = new cjs.Text("0", "16px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(636.2,70.9);

	this.text_28 = new cjs.Text("21", "16px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(597.2,70.9);

	this.text_29 = new cjs.Text("24", "16px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(558.2,70.9);

	this.text_30 = new cjs.Text("5", "16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 16;
	this.text_30.setTransform(518.2,70.9);

	this.text_31 = new cjs.Text("44", "16px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(478.2,70.9);

	this.text_32 = new cjs.Text("12", "16px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(439.2,70.9);

	this.text_33 = new cjs.Text("0", "16px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(400.2,70.9);

	this.text_34 = new cjs.Text("0", "16px Verdana");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 16;
	this.text_34.setTransform(361.2,70.9);

	this.text_35 = new cjs.Text("0", "16px Verdana");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 16;
	this.text_35.setTransform(323.2,70.9);

	this.text_36 = new cjs.Text("Nota · frecuencia", "bold 16px Verdana");
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(7,70.9);

	this.text_37 = new cjs.Text("Nota", "bold 16px Verdana");
	this.text_37.lineHeight = 16;
	this.text_37.setTransform(7,4.9);

	this.text_38 = new cjs.Text("Número alumnos (frecuencias)", "bold 16px Verdana");
	this.text_38.lineHeight = 16;
	this.text_38.setTransform(7,38.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("EA93gFaQAAiOhkAAInBAAIAAFXIIlAAgEA93gCRIAAHqQAACNhkAAInBAAIAAAIEA90ADCIoiAAIAAEkEAvCgCMIAAFOIGQAAIAAlOEAvCgHoImJAAIAAFXIGJAAgEAo5AHmIGJAAIAAkkImJAAIAAEkIAAAIEAvCAHuIAAgIIGQAAEAiwgCMIAAFOIGJAAIAAlOEA1SgHoImQAAEAvCgCRIGQAAEAiwgHoImJAAIAAFXIGJAAgAcnHmIGJAAIAAkkImJAAIAAEkIAAAIEAiwAHuIAAgIIGJAAAcniRImJAAIAAFTIGJAAIAAlOAQViRIGJAAIAAlXImJAAgAQVDCIAAEkIGJAAIAAkkImJAAIAAlTImJAAIAAFTgAQVHmIAAAIAWeHuIAAgIIGJAAAcnnoImJAAAKMiRIAAlXImJAAIAAFXgAKMDCImJAAIAAEkIGJAAgAEDHmIAAAIAKMHuIAAgIIGJAAAiEiMIAAFOIGHAAIAAlOAiEnoImJAAIAAFXIGJAAgAoNHmIGJAAIAAkkImJAAIAAEkIAAAIAiEHuIAAgIIGHAAAoNiRImJAAIAAFTIGJAAIAAlOAEDiRImHAAAEDnoImHAAAQVnoImJAAAoNnoImJAAIAAFXAuWHuIAAgIMgt8AAAQhkAAAAiNIAAiXIAAlTIAAjJQAAiOBkAAMAt8AAAAuWHmIAAkkMgvgAAAEg92gCRMAvgAAAAuWHmIGJAAEAo5gHoImJAAEAiwgCRIGJAA");
	this.shape.setTransform(396,49.1-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF99FF").s().p("AjDHnIAAkkIGHAAIAAEkgAjDDDIAAlSIGHAAIAAFSgADEiPImHAAIAAlXIGHAAIAAFXgAjDiPg");
	this.shape_1.setTransform(480.9,49-incremento);

	this.addChild(this.shape_1,this.shape,this.text_38,this.text_37,this.text_36,this.text_35,this.text_34,this.text_33,this.text_32,this.text_31,this.text_30,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,792,98.3);


(lib.tabla3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("186", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(747,71.9);

	this.text_1 = new cjs.Text("8", "bold 16px Verdana", "#0099FF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(715.2,38.9);

	this.text_2 = new cjs.Text("0", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(675.2,38.9);

	this.text_3 = new cjs.Text("0", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(636.2,38.9);

	this.text_4 = new cjs.Text("3", "bold 16px Verdana", "#0099FF");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(597.2,38.9);

	this.text_5 = new cjs.Text("4", "bold 16px Verdana", "#0099FF");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(558.2,38.9);

	this.text_6 = new cjs.Text("1", "bold 16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(518.2,38.9);

	this.text_7 = new cjs.Text("11", "bold 16px Verdana", "#CC0000");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(478.2,38.9);

	this.text_8 = new cjs.Text("4", "bold 16px Verdana", "#CC0000");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(439.2,38.9);

	this.text_9 = new cjs.Text("0", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(400.2,38.9);

	this.text_10 = new cjs.Text("0", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(361.2,38.9);

	this.text_11 = new cjs.Text("0", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(323.2,38.9);

	this.text_12 = new cjs.Text("10", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(715.2,4.9);

	this.text_13 = new cjs.Text("9", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(675.2,4.9);

	this.text_14 = new cjs.Text("8", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(636.2,4.9);

	this.text_15 = new cjs.Text("7", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(597.2,4.9);

	this.text_16 = new cjs.Text("6", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(558.2,4.9);

	this.text_17 = new cjs.Text("5", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(518.2,4.9);

	this.text_18 = new cjs.Text("4", "16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(478.2,4.9);

	this.text_19 = new cjs.Text("3", "16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(439.2,4.9);

	this.text_20 = new cjs.Text("2", "16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(400.2,4.9);

	this.text_21 = new cjs.Text("1", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(361.2,4.9);

	this.text_22 = new cjs.Text("0", "16px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(323.2,4.9);

	this.text_23 = new cjs.Text("31", "16px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(754,39.9);

	this.text_24 = new cjs.Text("TOTAL", "15px Verdana");
	this.text_24.lineHeight = 15;
	this.text_24.setTransform(739,5.9);

	this.text_25 = new cjs.Text("80", "16px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(715.2,70.9);

	this.text_26 = new cjs.Text("0", "16px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(675.2,70.9);

	this.text_27 = new cjs.Text("0", "16px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(636.2,70.9);

	this.text_28 = new cjs.Text("21", "16px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(597.2,70.9);

	this.text_29 = new cjs.Text("24", "16px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(558.2,70.9);

	this.text_30 = new cjs.Text("5", "16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 16;
	this.text_30.setTransform(518.2,70.9);

	this.text_31 = new cjs.Text("44", "16px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(478.2,70.9);

	this.text_32 = new cjs.Text("12", "16px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(439.2,70.9);

	this.text_33 = new cjs.Text("0", "16px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(400.2,70.9);

	this.text_34 = new cjs.Text("0", "16px Verdana");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 16;
	this.text_34.setTransform(361.2,70.9);

	this.text_35 = new cjs.Text("0", "16px Verdana");
	this.text_35.textAlign = "center";
	this.text_35.lineHeight = 16;
	this.text_35.setTransform(323.2,70.9);

	this.text_36 = new cjs.Text("Nota · frecuencia", "bold 16px Verdana");
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(7,70.9);

	this.text_37 = new cjs.Text("Nota", "bold 16px Verdana");
	this.text_37.lineHeight = 16;
	this.text_37.setTransform(7,4.9);

	this.text_38 = new cjs.Text("Número alumnos (frecuencias)", "bold 16px Verdana");
	this.text_38.lineHeight = 16;
	this.text_38.setTransform(7,38.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("EA93gFaQAAiOhkAAInBAAIAAFXIIlAAgEA90ADCIoiAAIAAEkIHBAAQBkAAAAiNIAAnqEA1SAHmIAAAIEAvCgCMIAAFOIGQAAIAAlOEAvCgHoImJAAIAAFXIGJAAgEAvCAHuIAAgIImJAAIAAAIEAvCAHmIAAkkImJAAIAAEkEAiwgCMIAAFOIGJAAIAAlOEAvCgCRIGQAAEA1SgHoImQAAEAvCAHmIGQAAEAiwgHoImJAAIAAFXIGJAAgEAiwAHuIAAgIImJAAIAAAIEAiwAHmIAAkkImJAAIAAEkAWeDCIGJAAIAAlOAWeiRIAAlXImJAAIAAFXIGJAAIAAFTAQVHmIAAAIAQVDCIAAEkIGJAAIAAkkImJAAIAAlTImJAAImJAAImHAAImJAAImJAAIAAFTIGJAAIAAlOAWeHuIAAgIIGJAAAWeiRIGJAAAcnnoImJAAAKMiRIAAlXImJAAIAAFXAKMHuIAAgIImJAAIAAAIAKMHmIAAkkImJAAIAAEkAKMiMIAAFOIGJAAAiEiMIAAFOIGHAAIAAlOAiEiRIAAlXImJAAIAAFXAiEHuIAAgIImJAAIAAAIAiEHmIAAkkImJAAIAAEkAEDnoImHAAAiEHmIGHAAAQVnoImJAAAKMHmIGJAAAoNnoImJAAIAAFXAuWDCMgvgAAAIAACXQAACNBkAAMAt8AAAgAuWHuIAAgIIGJAAEg92ADCIAAlTIAAjJQAAiOBkAAMAt8AAAEg92gCRMAvgAAAEAiwgCRIGJAAEAo5gHoImJAAEAiwAHmIGJAA");
	this.shape.setTransform(396,49.1-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66CC00").s().p("AjDHnIAAkkIGHAAIAAEkgADEDDImHAAIAAlSIGHAAImHAAIAAlXIGHAAIAAFXIAAFSgAjDDDg");
	this.shape_1.setTransform(520.2,49-incremento);

	this.addChild(this.shape_1,this.shape,this.text_38,this.text_37,this.text_36,this.text_35,this.text_34,this.text_33,this.text_32,this.text_31,this.text_30,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.2,792,98.3);


(lib.tabla2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("8", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(715.2,38.9);

	this.text_1 = new cjs.Text("0", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(675.2,38.9);

	this.text_2 = new cjs.Text("0", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(636.2,38.9);

	this.text_3 = new cjs.Text("3", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(597.2,38.9);

	this.text_4 = new cjs.Text("4", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(558.2,38.9);

	this.text_5 = new cjs.Text("1", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(518.2,38.9);

	this.text_6 = new cjs.Text("11", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(478.2,38.9);

	this.text_7 = new cjs.Text("4", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(439.2,38.9);

	this.text_8 = new cjs.Text("0", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(400.2,38.9);

	this.text_9 = new cjs.Text("0", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(361.2,38.9);

	this.text_10 = new cjs.Text("0", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(323.2,38.9);

	this.text_11 = new cjs.Text("10", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(715.2,4.9);

	this.text_12 = new cjs.Text("9", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(675.2,4.9);

	this.text_13 = new cjs.Text("8", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(636.2,4.9);

	this.text_14 = new cjs.Text("7", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(597.2,4.9);

	this.text_15 = new cjs.Text("6", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(558.2,4.9);

	this.text_16 = new cjs.Text("5", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(518.2,4.9);

	this.text_17 = new cjs.Text("4", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(478.2,4.9);

	this.text_18 = new cjs.Text("3", "16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(439.2,4.9);

	this.text_19 = new cjs.Text("2", "16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(400.2,4.9);

	this.text_20 = new cjs.Text("1", "16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(361.2,4.9);

	this.text_21 = new cjs.Text("0", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(323.2,4.9);

	this.text_22 = new cjs.Text("31", "16px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(754,39.9);

	this.text_23 = new cjs.Text("TOTAL", "15px Verdana");
	this.text_23.lineHeight = 15;
	this.text_23.setTransform(738,5.9);

	this.text_24 = new cjs.Text("80", "16px Verdana");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(715.2,70.9);

	this.text_25 = new cjs.Text("0", "16px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(675.2,70.9);

	this.text_26 = new cjs.Text("0", "16px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(636.2,70.9);

	this.text_27 = new cjs.Text("21", "16px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(597.2,70.9);

	this.text_28 = new cjs.Text("24", "16px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(558.2,70.9);

	this.text_29 = new cjs.Text("5", "16px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 16;
	this.text_29.setTransform(518.2,70.9);

	this.text_30 = new cjs.Text("44", "16px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 16;
	this.text_30.setTransform(478.2,70.9);

	this.text_31 = new cjs.Text("12", "16px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 16;
	this.text_31.setTransform(439.2,70.9);

	this.text_32 = new cjs.Text("0", "16px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 16;
	this.text_32.setTransform(400.2,70.9);

	this.text_33 = new cjs.Text("0", "16px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 16;
	this.text_33.setTransform(361.2,70.9);

	this.text_34 = new cjs.Text("0", "16px Verdana");
	this.text_34.textAlign = "center";
	this.text_34.lineHeight = 16;
	this.text_34.setTransform(323.2,70.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_34},{t:this.text_33},{t:this.text_32},{t:this.text_31},{t:this.text_30},{t:this.text_29},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(45));

	// Capa 3
	this.text_35 = new cjs.Text("Nota · frecuencia", "bold 16px Verdana");
	this.text_35.lineHeight = 16;
	this.text_35.setTransform(7,70.9);

	this.text_36 = new cjs.Text("Nota", "bold 16px Verdana");
	this.text_36.lineHeight = 16;
	this.text_36.setTransform(7,4.9);

	this.text_37 = new cjs.Text("Número alumnos (frecuencias)", "bold 16px Verdana");
	this.text_37.lineHeight = 16;
	this.text_37.setTransform(7,38.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_37},{t:this.text_36},{t:this.text_35}]}).wait(45));

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("EA1SgHrIAAFZIIlAAEA90ADAIoiAAIAAEsEAvCgCNIAAFNIGQAAIAAlNEAo5gHrIAAFZIGJAAIAAlZEAvCAHsIAAksImJAAIAAEsEAiwgCNIAAFNIGJAAIAAlNEAvCgCSIGQAAAcnnrIAAFZIGJAAIAAlZEAiwAHsIAAksImJAAIAAEsAWeiNIAAFNIGJAAIAAlNAQVnrIAAFZIGJAAIAAlZAWeHsIAAksImJAAIAAEsAKMiNIAAFNIGJAAIAAlNAWeiSIGJAAAEDnrIAAFZIGJAAIAAlZAKMHsIAAksImJAAIAAEsAiEiNIAAFNIGHAAIAAlNAoNnrIAAFZIGJAAIAAlZAiEHsIAAksImJAAIAAEsAoNiSImJAAIAAFSIGJAAIAAlNAiEiSIGHAAAKMiSIGJAAAuWnrIAAFZMgvgAAAAuWHsIAAksMgvgAAAEAiwgCSIGJAA");
	this.shape.setTransform(396,49.3-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(45));

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,0,1).rr(-396,-34.5,792,69,10);
	this.shape_1.setTransform(396,49-incremento,1,1.414);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).wait(45));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,792,98.5);


(lib.obj1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Nota", "bold 16px Verdana");
	this.text.lineHeight = 16;

	this.text_1 = new cjs.Text("Número alumnos (frecuencias)", "bold 16px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(0,34);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,283.7,57.5);


(lib.imagen1 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A/J/IMA+TAAAMAAAA+RMg+TAAAg");
	mask.setTransform(199.4,199.4);

	// Capa 2
	this.instance = new lib._02_OPT();
	this.instance.setTransform(-97.9,40.4,0.83,0.83);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-97.9,40.4,498,332);


(lib.fondoMC = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhKNgvfMCUbAAAMAAABe/MiUbAAAg");
	mask.setTransform(475,304);

	// Capa 2
	this.instance = new lib._01_OPT();
	this.instance.setTransform(0.3,-3.4);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.3,-3.4,950,633);


(lib.fondoGrafico3 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape.setTransform(8.9,366.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_1.setTransform(628.2,366.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_2.setTransform(628.2,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_3.setTransform(8.9,0.3);

	this.text = new cjs.Text("Nº de alumnos", "bold 9px Verdana");
	this.text.lineHeight = 11;
	this.text.setTransform(0,244.3,1.731,1.731,-89.9);

	this.text_1 = new cjs.Text("Nota", "bold 9px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.setTransform(296.6,356.2,1.731,1.731);

	this.text_2 = new cjs.Text("10", "9px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.setTransform(579.3,328.1,1.731,1.731);

	this.text_3 = new cjs.Text("9", "9px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.setTransform(534.4,328.1,1.731,1.731);

	this.text_4 = new cjs.Text("8", "9px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.setTransform(484,328.1,1.731,1.731);

	this.text_5 = new cjs.Text("7", "9px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.setTransform(433.5,328.1,1.731,1.731);

	this.text_6 = new cjs.Text("6", "9px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.setTransform(383.2,328.1,1.731,1.731);

	this.text_7 = new cjs.Text("5", "9px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.setTransform(333,328.1,1.731,1.731);

	this.text_8 = new cjs.Text("4", "9px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.setTransform(282.1,328.1,1.731,1.731);

	this.text_9 = new cjs.Text("3", "9px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.setTransform(231.9,328.1,1.731,1.731);

	this.text_10 = new cjs.Text("2", "9px Verdana");
	this.text_10.lineHeight = 11;
	this.text_10.setTransform(181.1,328.1,1.731,1.731);

	this.text_11 = new cjs.Text("1", "9px Verdana");
	this.text_11.lineHeight = 11;
	this.text_11.setTransform(131.2,328.1,1.731,1.731);

	this.text_12 = new cjs.Text("0", "9px Verdana");
	this.text_12.lineHeight = 11;
	this.text_12.setTransform(80.8,328.1,1.731,1.731);

	this.text_13 = new cjs.Text("12", "9px Verdana");
	this.text_13.lineHeight = 11;
	this.text_13.setTransform(29.6,1.7,1.731,1.731);

	this.text_14 = new cjs.Text("11", "9px Verdana");
	this.text_14.lineHeight = 11;
	this.text_14.setTransform(29.6,26.7,1.731,1.731);

	this.text_15 = new cjs.Text("10", "9px Verdana");
	this.text_15.lineHeight = 11;
	this.text_15.setTransform(29.6,52.2,1.731,1.731);

	this.text_16 = new cjs.Text("9", "9px Verdana");
	this.text_16.lineHeight = 11;
	this.text_16.setTransform(38.6,76.9,1.731,1.731);

	this.text_17 = new cjs.Text("8", "9px Verdana");
	this.text_17.lineHeight = 11;
	this.text_17.setTransform(38.6,102.3,1.731,1.731);

	this.text_18 = new cjs.Text("7", "9px Verdana");
	this.text_18.lineHeight = 11;
	this.text_18.setTransform(38.6,127.5,1.731,1.731);

	this.text_19 = new cjs.Text("6", "9px Verdana");
	this.text_19.lineHeight = 11;
	this.text_19.setTransform(38.6,153,1.731,1.731);

	this.text_20 = new cjs.Text("5", "9px Verdana");
	this.text_20.lineHeight = 11;
	this.text_20.setTransform(38.6,177.6,1.731,1.731);

	this.text_21 = new cjs.Text("4", "9px Verdana");
	this.text_21.lineHeight = 11;
	this.text_21.setTransform(38.6,203.4,1.731,1.731);

	this.text_22 = new cjs.Text("3", "9px Verdana");
	this.text_22.lineHeight = 11;
	this.text_22.setTransform(38.6,229.1,1.731,1.731);

	this.text_23 = new cjs.Text("2", "9px Verdana");
	this.text_23.lineHeight = 11;
	this.text_23.setTransform(38.6,254.1,1.731,1.731);

	this.text_24 = new cjs.Text("1", "9px Verdana");
	this.text_24.lineHeight = 11;
	this.text_24.setTransform(38.6,279.2,1.731,1.731);

	this.text_25 = new cjs.Text("0", "9px Verdana");
	this.text_25.lineHeight = 11;
	this.text_25.setTransform(38.6,304.4,1.731,1.731);
        if (isbq) inc=6; else inc=0;

	this.text_26 = new cjs.Text("Moda", "9px Verdana");
	this.text_26.lineHeight = 11;
	this.text_26.setTransform(263.5,13.7+incremento+inc,1.731,1.731);

	this.text_27 = new cjs.Text("", "bold 9px Verdana");
	this.text_27.lineHeight = 11;
	this.text_27.setTransform(129.7,87.6+incremento+inc,1.731,1.731);

	this.text_28 = new cjs.Text("", "bold 9px Verdana");
	this.text_28.lineHeight = 11;
	this.text_28.setTransform(119.2,87.6+incremento+inc,1.731,1.731);

	this.text_29 = new cjs.Text("Examen matemáticas ", "bold 9px Verdana");
	this.text_29.lineHeight = 11;
	this.text_29.setTransform(63.1,67.2+incremento,1.731,1.731);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_4.setTransform(617,319.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_5.setTransform(566.7,319.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_6.setTransform(516.5,319.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_7.setTransform(465,319.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_8.setTransform(414.8,319.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_9.setTransform(364.6,319.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_10.setTransform(314.3,319.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_11.setTransform(264.1,319.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_12.setTransform(213.9,319.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_13.setTransform(162.4,319.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_14.setTransform(112.1,319.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_15.setTransform(61.9,319.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_16.setTransform(339.4,317.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_17.setTransform(59.4,14.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_18.setTransform(59.4,39.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_19.setTransform(59.4,65.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_20.setTransform(59.4,89.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_21.setTransform(59.4,115.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_22.setTransform(59.4,140.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_23.setTransform(59.4,166.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_24.setTransform(59.4,190.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_25.setTransform(59.4,216.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_26.setTransform(59.4,241.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_27.setTransform(59.4,267.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_28.setTransform(59.4,291.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_29.setTransform(59.4,317.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAA3sMAAAAvZ");
	this.shape_30.setTransform(61.9,165.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_31.setTransform(571.3,317.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_32.setTransform(591.2,317.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_33.setTransform(611.1,317.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCACIAAgDIACAAIACABIABACg");
	this.shape_34.setTransform(611.1,114.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgCACIACgCIAAgBIADAAIAAADg");
	this.shape_35.setTransform(571.3,114.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAAACIgBgCIgBgCIAFAAIAAAFIgDgBg");
	this.shape_36.setTransform(419.4,317.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_37.setTransform(439.3,317.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgBgCIAEAAIgCACIgBACIgBABg");
	this.shape_38.setTransform(459.2,317.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgBACIAAgDIABABIABAAIACACg");
	this.shape_39.setTransform(459.2,241.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgCACIABgCIABAAIADgBIAAADg");
	this.shape_40.setTransform(419.4,241.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIADAAIAAAFIgCgBg");
	this.shape_41.setTransform(369.1,317.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_42.setTransform(389,317.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_43.setTransform(409,317.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_44.setTransform(409,216);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgBADIAAgDIABAAIACgCIAAAFg");
	this.shape_45.setTransform(369.1,216);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIAEAAIAAAFg");
	this.shape_46.setTransform(318.9,317.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_47.setTransform(338.8,317.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_48.setTransform(358.7,317.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgCACIAAgDIACABQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABACg");
	this.shape_49.setTransform(358.7,291.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgBACIAAgCIABAAIADgBIAAADg");
	this.shape_50.setTransform(318.9,291.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQgBAAAAAAQAAgBAAAAIgBgCIAFAAIAAAFQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAAAAAg");
	this.shape_51.setTransform(268.7,317.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_52.setTransform(288.6,317.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgCgCIAEAAIgBACIgBACIgCABg");
	this.shape_53.setTransform(308.5,317.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIABADg");
	this.shape_54.setTransform(308.5,39.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgCADIABgDIABAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAIAAAFg");
	this.shape_55.setTransform(268.7,39.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIgBgCIAEAAIAAAFIgCgBg");
	this.shape_56.setTransform(218.4,317.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_57.setTransform(238.3,317.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_58.setTransform(258.3,317.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_59.setTransform(258.3,216);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgCADIABgDIABAAIACgCIAAAFg");
	this.shape_60.setTransform(218.4,216);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_61.setTransform(61.9,165.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#808080").s().p("EgrWAAGIAAgKMBWtAAAIAAAKg");
	this.shape_62.setTransform(339.4,317.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_63.setTransform(616.9,165.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#808080").s().p("EgrWAAGIAAgLMBWtAAAIAAALg");
	this.shape_64.setTransform(339.4,14.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_65.setTransform(339.4,14.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_66.setTransform(339.4,39.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_67.setTransform(339.4,65.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_68.setTransform(339.4,89.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_69.setTransform(339.4,115.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_70.setTransform(339.4,140.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_71.setTransform(339.4,166.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_72.setTransform(339.4,190.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_73.setTransform(339.4,216.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_74.setTransform(339.4,241.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_75.setTransform(339.4,267.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_76.setTransform(339.4,291.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_77.setTransform(8.9,366.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_78.setTransform(628.2,366.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_79.setTransform(628.2,0.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_80.setTransform(8.9,0.3);

	this.addChild(this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,628.6,382.4);


(lib.fondoGrafico2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape.setTransform(8.9,366.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_1.setTransform(628.2,366.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_2.setTransform(628.2,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_3.setTransform(8.9,0.3);

	this.text = new cjs.Text("Nº de alumnos", "bold 9px Verdana");
	this.text.lineHeight = 11;
	this.text.setTransform(0,244.3,1.731,1.731,-89.9);

	this.text_1 = new cjs.Text("Nota", "bold 9px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.setTransform(296.6,356.2,1.731,1.731);

	this.text_2 = new cjs.Text("10", "9px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.setTransform(579.3,328.1,1.731,1.731);

	this.text_3 = new cjs.Text("9", "9px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.setTransform(534.4,328.1,1.731,1.731);

	this.text_4 = new cjs.Text("8", "9px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.setTransform(484,328.1,1.731,1.731);

	this.text_5 = new cjs.Text("7", "9px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.setTransform(433.5,328.1,1.731,1.731);

	this.text_6 = new cjs.Text("6", "9px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.setTransform(383.2,328.1,1.731,1.731);

	this.text_7 = new cjs.Text("5", "9px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.setTransform(333,328.1,1.731,1.731);

	this.text_8 = new cjs.Text("4", "9px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.setTransform(282.1,328.1,1.731,1.731);

	this.text_9 = new cjs.Text("3", "9px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.setTransform(231.9,328.1,1.731,1.731);

	this.text_10 = new cjs.Text("2", "9px Verdana");
	this.text_10.lineHeight = 11;
	this.text_10.setTransform(181.1,328.1,1.731,1.731);

	this.text_11 = new cjs.Text("1", "9px Verdana");
	this.text_11.lineHeight = 11;
	this.text_11.setTransform(131.2,328.1,1.731,1.731);

	this.text_12 = new cjs.Text("0", "9px Verdana");
	this.text_12.lineHeight = 11;
	this.text_12.setTransform(80.8,328.1,1.731,1.731);

	this.text_13 = new cjs.Text("12", "9px Verdana");
	this.text_13.lineHeight = 11;
	this.text_13.setTransform(29.6,1.7,1.731,1.731);

	this.text_14 = new cjs.Text("11", "9px Verdana");
	this.text_14.lineHeight = 11;
	this.text_14.setTransform(29.6,26.7,1.731,1.731);

	this.text_15 = new cjs.Text("10", "9px Verdana");
	this.text_15.lineHeight = 11;
	this.text_15.setTransform(29.6,52.2,1.731,1.731);

	this.text_16 = new cjs.Text("9", "9px Verdana");
	this.text_16.lineHeight = 11;
	this.text_16.setTransform(38.6,76.9,1.731,1.731);

	this.text_17 = new cjs.Text("8", "9px Verdana");
	this.text_17.lineHeight = 11;
	this.text_17.setTransform(38.6,102.3,1.731,1.731);

	this.text_18 = new cjs.Text("7", "9px Verdana");
	this.text_18.lineHeight = 11;
	this.text_18.setTransform(38.6,127.5,1.731,1.731);

	this.text_19 = new cjs.Text("6", "9px Verdana");
	this.text_19.lineHeight = 11;
	this.text_19.setTransform(38.6,153,1.731,1.731);

	this.text_20 = new cjs.Text("5", "9px Verdana");
	this.text_20.lineHeight = 11;
	this.text_20.setTransform(38.6,177.6,1.731,1.731);

	this.text_21 = new cjs.Text("4", "9px Verdana");
	this.text_21.lineHeight = 11;
	this.text_21.setTransform(38.6,203.4,1.731,1.731);

	this.text_22 = new cjs.Text("3", "9px Verdana");
	this.text_22.lineHeight = 11;
	this.text_22.setTransform(38.6,229.1,1.731,1.731);

	this.text_23 = new cjs.Text("2", "9px Verdana");
	this.text_23.lineHeight = 11;
	this.text_23.setTransform(38.6,254.1,1.731,1.731);

	this.text_24 = new cjs.Text("1", "9px Verdana");
	this.text_24.lineHeight = 11;
	this.text_24.setTransform(38.6,279.2,1.731,1.731);

	this.text_25 = new cjs.Text("0", "9px Verdana");
	this.text_25.lineHeight = 11;
	this.text_25.setTransform(38.6,304.4,1.731,1.731);
        if (isbq) inc=6; else inc=0;

	this.text_26 = new cjs.Text("Mediana", "9px Verdana");
	this.text_26.lineHeight = 11;
	this.text_26.maxWidth = 30;
	this.text_26.setTransform(310,267.5+incremento+inc,1.731,1.731);

	this.text_27 = new cjs.Text("", "bold 9px Verdana");
	this.text_27.lineHeight = 11;
	this.text_27.setTransform(129.7,87.6+incremento+inc,1.731,1.731);

	this.text_28 = new cjs.Text("", "bold 9px Verdana");
	this.text_28.lineHeight = 11;
	this.text_28.setTransform(119.2,87.6+incremento+inc,1.731,1.731);

	this.text_29 = new cjs.Text("Examen matemáticas ", "bold 9px Verdana");
	this.text_29.lineHeight = 11;
	this.text_29.setTransform(63.1,67.2+incremento,1.731,1.731);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_4.setTransform(617,319.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_5.setTransform(566.7,319.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_6.setTransform(516.5,319.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_7.setTransform(465,319.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_8.setTransform(414.8,319.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_9.setTransform(364.6,319.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_10.setTransform(314.3,319.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_11.setTransform(264.1,319.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_12.setTransform(213.9,319.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_13.setTransform(162.4,319.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_14.setTransform(112.1,319.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_15.setTransform(61.9,319.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_16.setTransform(339.4,317.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_17.setTransform(59.4,14.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_18.setTransform(59.4,39.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_19.setTransform(59.4,65.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_20.setTransform(59.4,89.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_21.setTransform(59.4,115.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_22.setTransform(59.4,140.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_23.setTransform(59.4,166.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_24.setTransform(59.4,190.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_25.setTransform(59.4,216.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_26.setTransform(59.4,241.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_27.setTransform(59.4,267.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_28.setTransform(59.4,291.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_29.setTransform(59.4,317.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAA3sMAAAAvZ");
	this.shape_30.setTransform(61.9,165.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_31.setTransform(571.3,317.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_32.setTransform(591.2,317.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_33.setTransform(611.1,317.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCACIAAgDIACAAIACABIABACg");
	this.shape_34.setTransform(611.1,114.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgCACIACgCIAAgBIADAAIAAADg");
	this.shape_35.setTransform(571.3,114.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAAACIgBgCIgBgCIAFAAIAAAFIgDgBg");
	this.shape_36.setTransform(419.4,317.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_37.setTransform(439.3,317.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgBgCIAEAAIgCACIgBACIgBABg");
	this.shape_38.setTransform(459.2,317.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgBACIAAgDIABABIABAAIACACg");
	this.shape_39.setTransform(459.2,241.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgCACIABgCIABAAIADgBIAAADg");
	this.shape_40.setTransform(419.4,241.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIADAAIAAAFIgCgBg");
	this.shape_41.setTransform(369.1,317.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_42.setTransform(389,317.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_43.setTransform(409,317.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_44.setTransform(409,216);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgBADIAAgDIABAAIACgCIAAAFg");
	this.shape_45.setTransform(369.1,216);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIAEAAIAAAFg");
	this.shape_46.setTransform(318.9,317.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_47.setTransform(338.8,317.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_48.setTransform(358.7,317.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgCACIAAgDIACABQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABACg");
	this.shape_49.setTransform(358.7,291.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgBACIAAgCIABAAIADgBIAAADg");
	this.shape_50.setTransform(318.9,291.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQgBAAAAAAQAAgBAAAAIgBgCIAFAAIAAAFQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAAAAAg");
	this.shape_51.setTransform(268.7,317.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_52.setTransform(288.6,317.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgCgCIAEAAIgBACIgBACIgCABg");
	this.shape_53.setTransform(308.5,317.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIABADg");
	this.shape_54.setTransform(308.5,39.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgCADIABgDIABAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAIAAAFg");
	this.shape_55.setTransform(268.7,39.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIgBgCIAEAAIAAAFIgCgBg");
	this.shape_56.setTransform(218.4,317.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_57.setTransform(238.3,317.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_58.setTransform(258.3,317.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_59.setTransform(258.3,216);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgCADIABgDIABAAIACgCIAAAFg");
	this.shape_60.setTransform(218.4,216);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_61.setTransform(61.9,165.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#808080").s().p("EgrWAAGIAAgKMBWtAAAIAAAKg");
	this.shape_62.setTransform(339.4,317.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_63.setTransform(616.9,165.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#808080").s().p("EgrWAAGIAAgLMBWtAAAIAAALg");
	this.shape_64.setTransform(339.4,14.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_65.setTransform(339.4,14.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_66.setTransform(339.4,39.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_67.setTransform(339.4,65.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_68.setTransform(339.4,89.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_69.setTransform(339.4,115.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_70.setTransform(339.4,140.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_71.setTransform(339.4,166.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_72.setTransform(339.4,190.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_73.setTransform(339.4,216.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_74.setTransform(339.4,241.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_75.setTransform(339.4,267.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_76.setTransform(339.4,291.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_77.setTransform(8.9,366.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_78.setTransform(628.2,366.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_79.setTransform(628.2,0.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_80.setTransform(8.9,0.3);

	this.addChild(this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,628.6,382.4);


(lib.fondoGrafico1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape.setTransform(8.9,366.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_1.setTransform(628.2,366.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_2.setTransform(628.2,0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_3.setTransform(8.9,0.3);

	this.text = new cjs.Text("Nº de alumnos", "bold 9px Verdana");
	this.text.lineHeight = 11;
	this.text.setTransform(0,244.3,1.731,1.731,-89.9);

	this.text_1 = new cjs.Text("Nota", "bold 9px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.setTransform(296.6,356.2,1.731,1.731);

	this.text_2 = new cjs.Text("10", "9px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.setTransform(579.3,328.1,1.731,1.731);

	this.text_3 = new cjs.Text("9", "9px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.setTransform(534.4,328.1,1.731,1.731);

	this.text_4 = new cjs.Text("8", "9px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.setTransform(484,328.1,1.731,1.731);

	this.text_5 = new cjs.Text("7", "9px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.setTransform(433.5,328.1,1.731,1.731);

	this.text_6 = new cjs.Text("6", "9px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.setTransform(383.2,328.1,1.731,1.731);

	this.text_7 = new cjs.Text("5", "9px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.setTransform(333,328.1,1.731,1.731);

	this.text_8 = new cjs.Text("4", "9px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.setTransform(282.1,328.1,1.731,1.731);

	this.text_9 = new cjs.Text("3", "9px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.setTransform(231.9,328.1,1.731,1.731);

	this.text_10 = new cjs.Text("2", "9px Verdana");
	this.text_10.lineHeight = 11;
	this.text_10.setTransform(181.1,328.1,1.731,1.731);

	this.text_11 = new cjs.Text("1", "9px Verdana");
	this.text_11.lineHeight = 11;
	this.text_11.setTransform(131.2,328.1,1.731,1.731);

	this.text_12 = new cjs.Text("0", "9px Verdana");
	this.text_12.lineHeight = 11;
	this.text_12.setTransform(80.8,328.1,1.731,1.731);

	this.text_13 = new cjs.Text("12", "9px Verdana");
	this.text_13.lineHeight = 11;
	this.text_13.setTransform(29.6,1.7,1.731,1.731);

	this.text_14 = new cjs.Text("11", "9px Verdana");
	this.text_14.lineHeight = 11;
	this.text_14.setTransform(29.6,26.7,1.731,1.731);

	this.text_15 = new cjs.Text("10", "9px Verdana");
	this.text_15.lineHeight = 11;
	this.text_15.setTransform(29.6,52.2,1.731,1.731);

	this.text_16 = new cjs.Text("9", "9px Verdana");
	this.text_16.lineHeight = 11;
	this.text_16.setTransform(38.6,76.9,1.731,1.731);

	this.text_17 = new cjs.Text("8", "9px Verdana");
	this.text_17.lineHeight = 11;
	this.text_17.setTransform(38.6,102.3,1.731,1.731);

	this.text_18 = new cjs.Text("7", "9px Verdana");
	this.text_18.lineHeight = 11;
	this.text_18.setTransform(38.6,127.5,1.731,1.731);

	this.text_19 = new cjs.Text("6", "9px Verdana");
	this.text_19.lineHeight = 11;
	this.text_19.setTransform(38.6,153,1.731,1.731);

	this.text_20 = new cjs.Text("5", "9px Verdana");
	this.text_20.lineHeight = 11;
	this.text_20.setTransform(38.6,177.6,1.731,1.731);

	this.text_21 = new cjs.Text("4", "9px Verdana");
	this.text_21.lineHeight = 11;
	this.text_21.setTransform(38.6,203.4,1.731,1.731);

	this.text_22 = new cjs.Text("3", "9px Verdana");
	this.text_22.lineHeight = 11;
	this.text_22.setTransform(38.6,229.1,1.731,1.731);

	this.text_23 = new cjs.Text("2", "9px Verdana");
	this.text_23.lineHeight = 11;
	this.text_23.setTransform(38.6,254.1,1.731,1.731);

	this.text_24 = new cjs.Text("1", "9px Verdana");
	this.text_24.lineHeight = 11;
	this.text_24.setTransform(38.6,279.2,1.731,1.731);

	this.text_25 = new cjs.Text("0", "9px Verdana");
	this.text_25.lineHeight = 11;
	this.text_25.setTransform(38.6,304.4,1.731,1.731);

	this.text_26 = new cjs.Text("Media", "9px Verdana");
	this.text_26.lineHeight = 11;
        if (isbq) inc=8; else inc=0;
	this.text_26.setTransform(360.2,186+incremento+inc,1.731,1.731);

	this.text_27 = new cjs.Text("", "bold 9px Verdana");
	this.text_27.lineHeight = 11;
	this.text_27.setTransform(139.7,37.6+incremento+inc,1.731,1.731);

	this.text_28 = new cjs.Text("", "bold 9px Verdana");
	this.text_28.lineHeight = 11;
	this.text_28.setTransform(129.2,37.6+incremento+inc,1.731,1.731);

	this.text_29 = new cjs.Text("Examen matemáticas ", "bold 9px Verdana");
	this.text_29.lineHeight = 11;
	this.text_29.setTransform(73.1,17.2+incremento,1.731,1.731);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_4.setTransform(617,319.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_5.setTransform(566.7,319.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_6.setTransform(516.5,319.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_7.setTransform(465,319.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_8.setTransform(414.8,319.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_9.setTransform(364.6,319.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_10.setTransform(314.3,319.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_11.setTransform(264.1,319.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_12.setTransform(213.9,319.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_13.setTransform(162.4,319.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_14.setTransform(112.1,319.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAAAYIAAgv");
	this.shape_15.setTransform(61.9,319.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_16.setTransform(339.4,317.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_17.setTransform(59.4,14.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_18.setTransform(59.4,39.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_19.setTransform(59.4,65.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_20.setTransform(59.4,89.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_21.setTransform(59.4,115.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_22.setTransform(59.4,140.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_23.setTransform(59.4,166.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_24.setTransform(59.4,190.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_25.setTransform(59.4,216.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_26.setTransform(59.4,241.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_27.setTransform(59.4,267.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_28.setTransform(59.4,291.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgXAAIAvAA");
	this.shape_29.setTransform(59.4,317.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1,3,true).p("AAA3sMAAAAvZ");
	this.shape_30.setTransform(61.9,165.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_31.setTransform(571.3,317.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_32.setTransform(591.2,317.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_33.setTransform(611.1,317.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCACIAAgDIACAAIACABIABACg");
	this.shape_34.setTransform(611.1,114.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgCACIACgCIAAgBIADAAIAAADg");
	this.shape_35.setTransform(571.3,114.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAAACIgBgCIgBgCIAFAAIAAAFIgDgBg");
	this.shape_36.setTransform(419.4,317.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_37.setTransform(439.3,317.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgBgCIAEAAIgCACIgBACIgBABg");
	this.shape_38.setTransform(459.2,317.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgBACIAAgDIABABIABAAIACACg");
	this.shape_39.setTransform(459.2,241.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgCACIABgCIABAAIADgBIAAADg");
	this.shape_40.setTransform(419.4,241.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIADAAIAAAFIgCgBg");
	this.shape_41.setTransform(369.1,317.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_42.setTransform(389,317.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_43.setTransform(409,317.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_44.setTransform(409,216);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgBADIAAgDIABAAIACgCIAAAFg");
	this.shape_45.setTransform(369.1,216);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIAAgCIAEAAIAAAFg");
	this.shape_46.setTransform(318.9,317.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_47.setTransform(338.8,317.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_48.setTransform(358.7,317.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgCACIAAgDIACABQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAIABACg");
	this.shape_49.setTransform(358.7,291.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgBACIAAgCIABAAIADgBIAAADg");
	this.shape_50.setTransform(318.9,291.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQgBAAAAAAQAAgBAAAAIgBgCIAFAAIAAAFQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAAAAAg");
	this.shape_51.setTransform(268.7,317.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AjCAGIAAgKIGFAAIAAAKg");
	this.shape_52.setTransform(288.6,317.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgCgCIAEAAIgBACIgBACIgCABg");
	this.shape_53.setTransform(308.5,317.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIABADg");
	this.shape_54.setTransform(308.5,39.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgCADIABgDIABAAQAAAAAAgBQABAAAAAAQABgBAAAAQABAAAAAAIAAAFg");
	this.shape_55.setTransform(268.7,39.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAAACQAAAAAAgBQAAAAAAAAQAAAAAAAAQgBgBAAAAIgBgCIAEAAIAAAFIgCgBg");
	this.shape_56.setTransform(218.4,317.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AjDAGIAAgKIGHAAIAAAKg");
	this.shape_57.setTransform(238.3,317.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgCgCIAFAAIgCACIgBACIgCABg");
	this.shape_58.setTransform(258.3,317.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgCADIAAgFIACACIABAAIACADg");
	this.shape_59.setTransform(258.3,216);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgCADIABgDIABAAIACgCIAAAFg");
	this.shape_60.setTransform(218.4,216);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_61.setTransform(61.9,165.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#808080").s().p("EgrWAAGIAAgKMBWtAAAIAAAKg");
	this.shape_62.setTransform(339.4,317.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#808080").s().p("AgFXsMAAAgvYIALAAMAAAAvYg");
	this.shape_63.setTransform(616.9,165.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#808080").s().p("EgrWAAGIAAgLMBWtAAAIAAALg");
	this.shape_64.setTransform(339.4,14.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_65.setTransform(339.4,14.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_66.setTransform(339.4,39.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_67.setTransform(339.4,65.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_68.setTransform(339.4,89.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_69.setTransform(339.4,115.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_70.setTransform(339.4,140.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_71.setTransform(339.4,166.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_72.setTransform(339.4,190.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_73.setTransform(339.4,216.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_74.setTransform(339.4,241.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_75.setTransform(339.4,267.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(1,1,1,3,true).p("EgrWAAAMBWtAAA");
	this.shape_76.setTransform(339.4,291.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AAAACIAAgCIgCgCIAFAAIAAAFIgDgBg");
	this.shape_77.setTransform(8.9,366.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgCgCIAFAAIgBACIgCACIgCABg");
	this.shape_78.setTransform(628.2,366.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgCADIAAgFIACABIACABIABADg");
	this.shape_79.setTransform(628.2,0.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgCADIACgDIAAgBIADgBIAAAFg");
	this.shape_80.setTransform(8.9,0.3);

	this.addChild(this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,628.6,382.4);


(lib.bt_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 25px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 27;
	this.text.lineWidth = 9;
	this.text.setTransform(-2,-17.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhhCUQgyAAAAgyIAAjDQAAgyAyAAIDDAAQAyAAAAAyIAADDQAAAygyAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]}).to({state:[{t:this.shape,p:{scaleX:1.248,scaleY:1.248,y:0.9}},{t:this.text,p:{scaleX:1.248,scaleY:1.248,x:-3.5,y:-21.1}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).to({state:[{t:this.shape,p:{scaleX:1,scaleY:1,y:0}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2,y:-17.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.8,-17.5,29.8,34.4);


(lib.btn_siguienteV2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ACKiJQAMAMAAARIAADZQAAARgMAMQgMAMgRAAIjZAAQgRAAgMgMQgMgMAAgRIAAjZQAAgRAMgMQAMgMARAAIDZAAQARAAAMAMg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgtA5Ig6AAIAAhyIA6AAIAAgsICVBlIiVBmg");
	this.shape_1.setTransform(0.7,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhsCWQgRAAgMgNQgMgLAAgRIAAjZQAAgRAMgMQAMgMARAAIDZAAQARAAALAMQANAMAAARIAADZQAAARgNALQgLANgRAAgAhhA5IA7AAIAAAtICUhmIiUhlIAAArIg7AAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1E120D").ss(1,0,1).p("ACYiXQANAOAAASIAADwQAAASgNANQgNANgSAAIjwAAQgSAAgOgNQgNgNAAgSIAAjwQAAgSANgOQAOgNASAAIDwAAQASAAANANg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgyA/IhAAAIAAh+IBAAAIAAgxIClBwIilBxg");
	this.shape_4.setTransform(0.7,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah3ClQgSgBgNgNQgNgMgBgSIAAjwQABgSANgNQANgNASgBIDwAAQASABAMANQANANABASIAADwQgBASgNAMQgMANgSABgAhqA/IBAAAIAAAyICkhxIikhvIAAAwIhAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.tabla4Anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.tabla4();
	this.instance.setTransform(395.9,49.1,1,1,0,0,0,395.9,49.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({alpha:1},20).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.tabla3Anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.text = new cjs.Text("Mediana = Me = 5", "bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(390.1,128.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},36).wait(4));

	// Capa 1
	this.instance = new lib.tabla3();
	this.instance.setTransform(395.9,49.1,1,1,0,0,0,395.9,49.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({alpha:1},20).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.tabla1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_52 = new cjs.Graphics().p("AjgmYIHBAAIAAMxInBAAg");
	var mask_graphics_53 = new cjs.Graphics().p("AljGZIAAsxILHAAIAAMxg");
	var mask_graphics_54 = new cjs.Graphics().p("AnmGZIAAsxIPNAAIAAMxg");
	var mask_graphics_55 = new cjs.Graphics().p("AppGZIAAsxITTAAIAAMxg");
	var mask_graphics_56 = new cjs.Graphics().p("ArsGZIAAsxIXZAAIAAMxg");
	var mask_graphics_57 = new cjs.Graphics().p("AtvGZIAAsxIbfAAIAAMxg");
	var mask_graphics_58 = new cjs.Graphics().p("AvyGZIAAsxIflAAIAAMxg");
	var mask_graphics_59 = new cjs.Graphics().p("Ax1GZIAAsxMAjrAAAIAAMxg");
	var mask_graphics_60 = new cjs.Graphics().p("Az4GZIAAsxMAnxAAAIAAMxg");
	var mask_graphics_61 = new cjs.Graphics().p("A17GZIAAsxMAr3AAAIAAMxg");
	var mask_graphics_62 = new cjs.Graphics().p("A3+GZIAAsxMAv9AAAIAAMxg");
	var mask_graphics_63 = new cjs.Graphics().p("A6BGZIAAsxMA0DAAAIAAMxg");
	var mask_graphics_64 = new cjs.Graphics().p("A8EGZIAAsxMA4JAAAIAAMxg");
	var mask_graphics_65 = new cjs.Graphics().p("A+HGZIAAsxMA8PAAAIAAMxg");
	var mask_graphics_66 = new cjs.Graphics().p("EggKAGZIAAsxMBAVAAAIAAMxg");
	var mask_graphics_67 = new cjs.Graphics().p("EgiNAGZIAAsxMBEbAAAIAAMxg");
	var mask_graphics_68 = new cjs.Graphics().p("EgkQAGZIAAsxMBIhAAAIAAMxg");
	var mask_graphics_69 = new cjs.Graphics().p("EgmTAGZIAAsxMBMnAAAIAAMxg");
	var mask_graphics_70 = new cjs.Graphics().p("EgoWAGZIAAsxMBQtAAAIAAMxg");
	var mask_graphics_71 = new cjs.Graphics().p("A2RmYMBUyAAAIAAMxMhUyAAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_graphics_52,x:274.5,y:32}).wait(1).to({graphics:mask_graphics_53,x:287.9,y:32}).wait(1).to({graphics:mask_graphics_54,x:301.3,y:32}).wait(1).to({graphics:mask_graphics_55,x:314.7,y:32}).wait(1).to({graphics:mask_graphics_56,x:328.1,y:32}).wait(1).to({graphics:mask_graphics_57,x:341.5,y:32}).wait(1).to({graphics:mask_graphics_58,x:354.9,y:32}).wait(1).to({graphics:mask_graphics_59,x:368.2,y:32}).wait(1).to({graphics:mask_graphics_60,x:381.6,y:32}).wait(1).to({graphics:mask_graphics_61,x:395,y:32}).wait(1).to({graphics:mask_graphics_62,x:408.4,y:32}).wait(1).to({graphics:mask_graphics_63,x:421.8,y:32}).wait(1).to({graphics:mask_graphics_64,x:435.2,y:32}).wait(1).to({graphics:mask_graphics_65,x:448.6,y:32}).wait(1).to({graphics:mask_graphics_66,x:462,y:32}).wait(1).to({graphics:mask_graphics_67,x:475.4,y:32}).wait(1).to({graphics:mask_graphics_68,x:488.8,y:32}).wait(1).to({graphics:mask_graphics_69,x:502.2,y:32}).wait(1).to({graphics:mask_graphics_70,x:515.6,y:32}).wait(1).to({graphics:mask_graphics_71,x:400.2,y:32}).wait(48));

	// Capa 1
	this.text = new cjs.Text("8", "16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.setTransform(715.2,38.9);

	this.text_1 = new cjs.Text("0", "16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(675.2,38.9);

	this.text_2 = new cjs.Text("0", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(636.2,38.9);

	this.text_3 = new cjs.Text("3", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(597.2,38.9);

	this.text_4 = new cjs.Text("4", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(558.2,38.9);

	this.text_5 = new cjs.Text("1", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(518.2,38.9);

	this.text_6 = new cjs.Text("11", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(478.2,38.9);

	this.text_7 = new cjs.Text("4", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(439.2,38.9);

	this.text_8 = new cjs.Text("0", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(400.2,38.9);

	this.text_9 = new cjs.Text("0", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(361.2,38.9);

	this.text_10 = new cjs.Text("0", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(323.2,38.9);

	this.text_11 = new cjs.Text("10", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(715.2,4.9);

	this.text_12 = new cjs.Text("9", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(675.2,4.9);

	this.text_13 = new cjs.Text("8", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(636.2,4.9);

	this.text_14 = new cjs.Text("7", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(597.2,4.9);

	this.text_15 = new cjs.Text("6", "16px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(558.2,4.9);

	this.text_16 = new cjs.Text("5", "16px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(518.2,4.9);

	this.text_17 = new cjs.Text("4", "16px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(478.2,4.9);

	this.text_18 = new cjs.Text("3", "16px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(439.2,4.9);

	this.text_19 = new cjs.Text("2", "16px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(400.2,4.9);

	this.text_20 = new cjs.Text("1", "16px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(361.2,4.9);

	this.text_21 = new cjs.Text("0", "16px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(323.2,4.9);

	this.text_22 = new cjs.Text("31", "16px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(754,39.9);

	this.text_23 = new cjs.Text("TOTAL", "15px Verdana");
	this.text_23.lineHeight = 15;
	this.text_23.setTransform(738,5.9);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.text_18.mask = this.text_19.mask = this.text_20.mask = this.text_21.mask = this.text_22.mask = this.text_23.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},52).wait(67));

	// Capa 3
	this.instance = new lib.obj1();
	this.instance.setTransform(148.8,33.6,1,1,0,0,0,141.8,28.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(35).to({_off:false},0).to({alpha:1},14).wait(70));

	// Capa 5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AhymYIDlAAIAAMxIjlAAg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Aj6GZIAAsxIH1AAIAAMxg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AmCGZIAAsxIMFAAIAAMxg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AoLGZIAAsxIQXAAIAAMxg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AqTGZIAAsxIUnAAIAAMxg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AscGZIAAsxIY5AAIAAMxg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AukGZIAAsxIdJAAIAAMxg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AwtGZIAAsxMAhbAAAIAAMxg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Ay1GZIAAsxMAlrAAAIAAMxg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A0+GZIAAsxMAp9AAAIAAMxg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A3GGZIAAsxMAuNAAAIAAMxg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A5PGZIAAsxMAyfAAAIAAMxg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A7XGZIAAsxMA2vAAAIAAMxg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A9gGZIAAsxMA7BAAAIAAMxg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A/oGZIAAsxMA/RAAAIAAMxg");
	var mask_1_graphics_15 = new cjs.Graphics().p("EghxAGZIAAsxMBDjAAAIAAMxg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Egj5AGZIAAsxMBHzAAAIAAMxg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EgmCAGZIAAsxMBMFAAAIAAMxg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EgoKAGZIAAsxMBQVAAAIAAMxg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgqTAGZIAAsxMBUnAAAIAAMxg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgsbAGZIAAsxMBY3AAAIAAMxg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EgujAGZIAAsxMBdHAAAIAAMxg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EgwsAGZIAAsxMBhZAAAIAAMxg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Egy0AGZIAAsxMBlpAAAIAAMxg");
	var mask_1_graphics_24 = new cjs.Graphics().p("Eg09AGZIAAsxMBp7AAAIAAMxg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Eg3FAGZIAAsxMBuLAAAIAAMxg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Eg5OAGZIAAsxMBydAAAIAAMxg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Eg7WAGZIAAsxMB2tAAAIAAMxg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Eg9fAGZIAAsxMB6/AAAIAAMxg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Eg/ngGYMB/PAAAIAAMxMh/PAAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-19.4,y:32}).wait(1).to({graphics:mask_1_graphics_1,x:-5.2,y:32}).wait(1).to({graphics:mask_1_graphics_2,x:9,y:32}).wait(1).to({graphics:mask_1_graphics_3,x:23.2,y:32}).wait(1).to({graphics:mask_1_graphics_4,x:37.5,y:32}).wait(1).to({graphics:mask_1_graphics_5,x:51.7,y:32}).wait(1).to({graphics:mask_1_graphics_6,x:65.9,y:32}).wait(1).to({graphics:mask_1_graphics_7,x:80.2,y:32}).wait(1).to({graphics:mask_1_graphics_8,x:94.4,y:32}).wait(1).to({graphics:mask_1_graphics_9,x:108.7,y:32}).wait(1).to({graphics:mask_1_graphics_10,x:122.9,y:32}).wait(1).to({graphics:mask_1_graphics_11,x:137.1,y:32}).wait(1).to({graphics:mask_1_graphics_12,x:151.4,y:32}).wait(1).to({graphics:mask_1_graphics_13,x:165.6,y:32}).wait(1).to({graphics:mask_1_graphics_14,x:179.9,y:32}).wait(1).to({graphics:mask_1_graphics_15,x:194.1,y:32}).wait(1).to({graphics:mask_1_graphics_16,x:208.3,y:32}).wait(1).to({graphics:mask_1_graphics_17,x:222.6,y:32}).wait(1).to({graphics:mask_1_graphics_18,x:236.8,y:32}).wait(1).to({graphics:mask_1_graphics_19,x:251.1,y:32}).wait(1).to({graphics:mask_1_graphics_20,x:265.3,y:32}).wait(1).to({graphics:mask_1_graphics_21,x:279.6,y:32}).wait(1).to({graphics:mask_1_graphics_22,x:293.8,y:32}).wait(1).to({graphics:mask_1_graphics_23,x:308,y:32}).wait(1).to({graphics:mask_1_graphics_24,x:322.3,y:32}).wait(1).to({graphics:mask_1_graphics_25,x:336.5,y:32}).wait(1).to({graphics:mask_1_graphics_26,x:350.8,y:32}).wait(1).to({graphics:mask_1_graphics_27,x:365,y:32}).wait(1).to({graphics:mask_1_graphics_28,x:379.2,y:32}).wait(1).to({graphics:mask_1_graphics_29,x:393.5,y:32}).wait(90));

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,1).p("EA1SgFaIAAFZIIlAAEA1SAACIAAFZEAo5gFaIAAFZIGJAAIAAlZEAvCAACIAAFZEAo5AACIAAFZEAvCgABIGQAAAcnlaIAAFZIGJAAIAAlZEAiwAACIAAFZAcnACIAAFZAQVlaIAAFZIGJAAIAAlZAWeACIAAFZAQVACIAAFZAWegBIGJAAAEDlaIAAFZIGJAAIAAlZAKMACIAAFZAEDACIAAFZAoNlaIAAFZIGJAAIAAlZAiEACIAAFZAoNACIAAFZAiEgBIGHAAAKMgBIGJAAAuWlaIAAFZIGJAAAuWFbIAAlcMgvgAAAEAiwgABIGJAA");
	this.shape.setTransform(396,34.8-incremento);

	this.shape.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(119));

	// Capa 4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,0,1).rr(-396,-34.5,792,69,10);
	this.shape_1.setTransform(396,34.5-incremento);

	this.shape_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,792,69.5);


(lib.grafico3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.torres3();
	this.instance.setTransform(414.8,317.5,1,0.014,0,0,0,196.1,277.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).to({regY:277.8,scaleY:1},39).wait(45));

	// Capa 1
	this.instance_1 = new lib.fondoGrafico3();
	this.instance_1.setTransform(314.3,191.2,1,1,0,0,0,314.3,191.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},22).wait(91));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.grafico2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.torres2();
	this.instance.setTransform(414.8,317.5,1,0.014,0,0,0,196.1,277.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).to({regY:277.8,scaleY:1},39).wait(45));

	// Capa 1
	this.instance_1 = new lib.fondoGrafico2();
	this.instance_1.setTransform(314.3,191.2,1,1,0,0,0,314.3,191.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},22).wait(91));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.grafico1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.torres1();
	this.instance.setTransform(414.8,317.5,1,0.014,0,0,0,196.1,277.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).to({regY:277.8,scaleY:1},39).wait(45));

	// Capa 1
	this.instance_1 = new lib.fondoGrafico1();
	this.instance_1.setTransform(314.3,191.2,1,1,0,0,0,314.3,191.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},22).wait(91));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacionTablas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.tabla2();
	this.instance.setTransform(396,76.7,1,1,0,0,0,395.9,76.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({alpha:1},25).wait(1));

	// Capa 1
	this.instance_1 = new lib.tabla1("single",99);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({startPosition:99},0).to({alpha:0},25).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,792,69.5);


(lib.animacion1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	

	this.text_19 = new cjs.Text("Para calcular la media:", "20px Verdana");
	this.text_19.lineHeight = 20;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_19}]}).wait(223));

	// Capa 4
	this.text_20 = new cjs.Text(txt['text3'], "20px Verdana");
	this.text_20.lineHeight = 20;
	this.text_20.setTransform(2.5,48);


	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_20}]},14).wait(209));

	// Capa 3
	this.text_76 = new cjs.Text(txt['text4'], "20px Verdana");
	this.text_76.lineHeight = 20;
	this.text_76.setTransform(2.5,96.6);


	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_76}]},105).wait(118));

	// Capa 2
	this.text_98 = new cjs.Text(txt['text5'], "20px Verdana");
	this.text_98.lineHeight = 20;
	this.text_98.setTransform(2.5,145.2);


	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_98}]},183).wait(40));

var incbq=0;
if (isbq) incbq=25;

	// Capa 7
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.2,1,1).p("AhKAAICVAA");
	this.shape.setTransform(379-incbq,358);

	this.text_134 = new cjs.Text(" Media = X = 186 : 31  = 6", "bold 20px Verdana");
	this.text_134.lineHeight = 20;
	this.text_134.setTransform(266.6,355+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_134},{t:this.shape}]},207).wait(16));

	// Capa 6
	this.text_135 = new cjs.Text("186", "16px Verdana");
	this.text_135.lineHeight = 16;
	this.text_135.setTransform(747,311.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_135}]},129).wait(94));

	// Capa 1
	this.instance = new lib.animacionTablas("single",0);
	this.instance.setTransform(394.4,272.1,1,1,0,0,0,393.4,32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({mode:"synched",loop:false},0).wait(66).to({mode:"single",startPosition:34},0).wait(118));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,793,309.6);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}