Generador = new function()
{
	this.nOp;
	this.enun = "";
	this.lPregsSTR = new Array();
    this.lRespsNUM = new Array();
    this.lRespsSTR = new Array();

	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.plano = "";
	this.co_pizarra = "";
	this.base ="";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase = ["Arial",36,"#0D3158",false];
		Random.init(semilla,100);
		
		this.lVariaciones = new Array();
		this.lPregsSprite = new Array();
		this.lRespsNumber = new Array();
		this.lRespsString = new Array();
		this.lFiguras = new Array();
		this.formula = "";
		this.co_pizarra = "";
		this.lValores;
        this.lQOcurrencias;

		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();

			Motor.lOperaciones[this.nOp] = new Object();
			Motor.lOperaciones[this.nOp].respsNUM = this.lRespsNUM[this.nOp]
			Motor.lOperaciones[this.nOp].respuestaString = this.lRespsSTR[this.nOp];
			Motor.lOperaciones[this.nOp].entradas = ["","","","","",""];
			Motor.lOperaciones[this.nOp].estaListo = false;
			Motor.lOperaciones[this.nOp].correcto = false;
			Motor.lOperaciones[this.nOp].enunciadoJ = this.enun;
			Motor.lOperaciones[this.nOp].enunciado = this.enun;
			Motor.lOperaciones[this.nOp].rotulos = this.lRotulos;

		}
	}
	
	this.enunciar = function()
	{
        //console.log(Motor.lPreguntas);
		this.enun=Motor.datosXML.enunciadosBase1[0].enunciado.toString();
		var qVeces = Random.integer(8,16);
        this.enun = this.enun.replace('ZZZ', String(qVeces));
        this.enun = this.enun + '\n';
        while(true){//prueba hasta que haya una sola moda:
            this.lValores=new Array();
            this.lQOcurrencias=[0,0,0,0,0,0];
            for(var i = 0; i < qVeces; i++){
                var valor = Random.integer(1,6);
                this.lQOcurrencias[valor-1]++;
                this.lValores.push(valor);
            }
            var maximo=JL.getMaximo(this.lQOcurrencias);
            var qMaximos = 0;
            for(i=0;i<6;i++){
                if(this.lQOcurrencias[i]==maximo){
                    qMaximos++;
                }
            }
            if(qMaximos==1){
                var moda = 1 + this.lQOcurrencias.indexOf(maximo);
                break;
            }
        }
        var suma = 0;
        for(i=0;i<qVeces;i++){
            valor=this.lValores[i];
            suma+=valor;
            this.enun+=valor.toString();
            if(i<qVeces-1){
                this.enun+=', ';
            }
        }
        //calcula las demás magnitudes:
        var media = suma/qVeces;
        var lValoresSort = this.lValores.slice();
        lValoresSort.sort();
        var long = qVeces;
        if(long%2==0){
            var mediana = (lValoresSort[long/2-1]+lValoresSort[long/2])/2;
        }else{
            var mediana = lValoresSort[Math.floor(long/2)];
        }
        var valorFrecAbs = Random.integer(1,6);
        var frecAbs = this.lQOcurrencias[valorFrecAbs-1];
        var valorFrecRel = Random.integer(1,6,[valorFrecAbs]);
        var frecRel = this.lQOcurrencias[valorFrecRel-1]/qVeces;
        var suma2 = 0;
        for(i=0;i<qVeces;i++){
            suma2+=Math.pow(this.lValores[i]-media,2);
        }
        var desviacion = Math.sqrt(suma2/qVeces);
        
        //anota arrays según nivel:
        this.lRespsNUM[this.nOp]=new Array();
        this.lRespsSTR[this.nOp]=new Array();
        this.lRespsNUM[this.nOp].push(media,moda);
        this.lRespsSTR[this.nOp].push(JL.num2str(media,2),JL.num2str(moda,0));
        this.lRotulos = [Motor.lPreguntas[0].enunciado.toString(),Motor.lPreguntas[1].enunciado.toString()];
        
        if(Motor.datosXML.curso > 0){
            this.lRespsNUM[this.nOp].push(mediana,frecAbs,frecRel);
            this.lRespsSTR[this.nOp].push(JL.num2str(mediana,1),JL.num2str(frecAbs,0),JL.num2str(frecRel,2));
            this.lRotulos[2]=Motor.lPreguntas[2].enunciado.toString();
            var auxS = Motor.lPreguntas[3].enunciado.toString();
            auxS=auxS.replace('ZZZ',valorFrecAbs.toString());
            this.lRotulos[3]=auxS;
            auxS=Motor.lPreguntas[4].enunciado.toString();
            auxS=auxS.replace('ZZZ',valorFrecRel.toString());
            this.lRotulos[4]=auxS;
        }
        if(Motor.datosXML.curso > 1){
            this.lRespsNUM[this.nOp].push(desviacion);
            this.lRespsSTR[this.nOp].push(JL.num2str(desviacion,2));
            this.lRotulos[5]=Motor.lPreguntas[5].enunciado;
        }
        
        
        
	
	}
	

}