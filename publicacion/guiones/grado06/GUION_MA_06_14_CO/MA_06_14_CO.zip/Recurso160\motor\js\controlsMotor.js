function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    
    this.subEnunciado(operacio);
    
    this.addLine( 0, 480, 100, operacio.rotulos[0], operacio.respuestaString[0] );
    this.addLine( 1, 480, 150, operacio.rotulos[1], operacio.respuestaString[1] );
    
    if(Motor.datosXML.curso > 0){
        this.addLine( 2, 480, 200, operacio.rotulos[2], operacio.respuestaString[2] );
        this.addLine( 3, 480, 250, operacio.rotulos[3], operacio.respuestaString[3] );
        this.addLine( 4, 480, 300, operacio.rotulos[4], operacio.respuestaString[4] );
    }
    if(Motor.datosXML.curso > 1){
        this.addLine( 5, 480, 350, operacio.rotulos[5], operacio.respuestaString[5] );
    }
    
    //this.contenedor.addChild( this.formula ); 
    
   	//this.addLine( operacio  );
   	 

	//this.valorNum = operacio.respuestaNum; 
	//this.valorStr = operacio.respuestaString; 

	this.correcte0= "";
	this.correcte1= "";
	this.correcte2= "";
	this.correcte3= "";
	this.correcte4= "";
	this.correcte5= "";
	
	this.respuesta0 = operacio.respuestaString[0];
	this.respuesta1 = operacio.respuestaString[1];
	this.respuesta2 = operacio.respuestaString[2];
	this.respuesta3 = operacio.respuestaString[3];
	this.respuesta4 = operacio.respuestaString[4];
	this.respuesta5 = operacio.respuestaString[5];
}

Pagina.prototype.subEnunciado = function(operacio){
    
    
    var res = operacio.enunciado.split(":");
    //console.log(operacio.enunciado);
    //console.log(res[0]);
    //console.log(res[1]);
    this.enunciado = new createjs.RichText();
    //this.enunciado.text = res[0] + '\n' + res[1];
    this.enunciado.text = operacio.enunciado;
    this.enunciado.font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Arial" : "18px Arial" ;
    this.enunciado.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this.enunciado.color = "#0D3158";
    this.enunciado.x = 15;
    this.enunciado.y = 5;
    this.enunciado.lineWidth = 850;
    this.enunciado.lineHeight = 22;
    this.enunciado.mouseEnabled = false;
    this.validacio = "";
    this.contenedor.addChild( this.enunciado );
    
};

Pagina.prototype.addLine = function(index, x, y, _text, valors){
	
	this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text;
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["text"+index].color = "#0D3158";
    this["text"+index].x = x - 20;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "right";
    
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja"+index] = new CajaTexto();
    this["caja"+index] .contenedor.x = x;
    this["caja"+index] .contenedor.y = y;

    this.contenedor.addChild( this["caja"+index].contenedor  );
      
    this["valor_1_"+index] = new createjs.RichText();
    this["valor_1_"+index].text = valors.toString();
    this["valor_1_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_1_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_1_"+index].color = "#E1001A";
    this["valor_1_"+index].x = x + 185;
    this["valor_1_"+index].y = y + 8;
    this["valor_1_"+index].alpha = 0;
    
    this.contenedor.addChild( this["valor_1_"+index]  );
    
    /*this["valor_2_"+index] = new createjs.RichText();
    this["valor_2_"+index].text = valors[1].toString();
    this["valor_2_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_2_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_2_"+index].color = "#E1001A";
    this["valor_2_"+index].x = x + 235;
    this["valor_2_"+index].y = y + 8;
    this["valor_2_"+index].alpha = 0;
    
    this.contenedor.addChild( this["valor_2_"+index]  );*/
}

function PuntoP( color )
{
	color =  color || "#000";
	this.contenedor = new createjs.Container();
	this.punto = new createjs.Shape();
	
	this.punto.graphics.beginFill(color).drawCircle(0,0,5);
	
	this.contenedor.addChild( this.punto );
}
function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 110, 40, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 110, 40, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 110, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 110, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 110, 40, 10);
}
