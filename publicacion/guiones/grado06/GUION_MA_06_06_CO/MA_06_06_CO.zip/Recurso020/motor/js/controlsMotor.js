function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = true;
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.contenedor2 = new createjs.Container();
    this.contenedor2.x = 100;
    this.contenedor2.y = 200;
    
    this.contenedor.addChild(this.contenedor2);
    
    this.contenedorRespuesta = new createjs.Container();
    this.contenedor.addChild(this.contenedorRespuesta);
    
    var tiposOP = ["+",String.fromCharCode(8722),"x",":"];

    //creación fraciones
    switch(operacio.variacion) {
        case 0:
            //primer elemento
            var elem1;
            var elem2;
            if(operacio.pregunta[0][0][1]==1){///es entero
                this.addText(0, 0, 0, operacio.pregunta[0][0][0]);
            }else{///es fraccion
                this.addFrac(0, 0, 0, operacio.pregunta[0][0][0], operacio.pregunta[0][0][1]);
            }

             this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 50, 0, tiposOP[operacio.tipoOP]);

            //segundo elemento
            if(operacio.pregunta[0][1][1]==1){///es entero
                this.addText(0, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 20, 0, operacio.pregunta[0][1][0]);
                
            }else{///es fraccion
                this.addFrac(0, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 20, 0, operacio.pregunta[0][1][0], operacio.pregunta[0][1][1]);
            }

            this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 35, 0, " = ");
            
            this.addLine(0, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 10, 0, operacio.respuestaString);

        break;
        case 1:
            for (var j=0;j<operacio.pregunta[0].length;j++){
                var elemCombinado;
                if((operacio.pregunta[0][j].length>1)&&(operacio.pregunta[0][j][1]!=1)){///es fraccion
                    if( j == 0 ){
                        this.addFrac(0, 0, 0, operacio.pregunta[0][j][0], operacio.pregunta[0][j][1]);
                    }else{
                        this.addFrac(0, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 30, 0, operacio.pregunta[0][j][0], operacio.pregunta[0][j][1]);
                    }
                }else{///no es fraccion
                    //elemCombinado=new Entero();
                    ///si el elemento es un array obtener su primer elemento sino el elemento entero
                    if( j == 0 ){
                         if(typeof operacio.pregunta[0][j] == "object") {
                            this.addText(1, 0, 0, operacio.pregunta[0][j][0]);
                        }else{
                            this.addText(1, 0, 0, operacio.pregunta[0][j]);
                        }
                    }else{
                         if(typeof operacio.pregunta[0][j] == "object") {
                            this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 20, 0, operacio.pregunta[0][j][0]);
                        }else{
                            if( (operacio.pregunta[0][j -1].length>1)&&(operacio.pregunta[0][j -1][1]!=1)){
                                this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 65, 0, operacio.pregunta[0][j]);
                            }else{
                                this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 15, 0, operacio.pregunta[0][j]);
                            }
                        }
                    }
                }
            }
            
            this.addText(1, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 45, 0, " = ");
            
            this.addLine(0, this.contenedor2.getBounds().width + this.contenedor2.getBounds().x + 10, 0, operacio.respuestaString);
            
        break;
    }

	this.valor = [operacio.respuestaString[0][0], operacio.respuestaString[0][1]]; 
    this.respuesta = ["",""];
}

Pagina.prototype.getParam = function(){
    //[num, den]
    Motor.currentPag.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val()];
};

Pagina.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(this.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(this.respuesta[1]);
    
    Motor["inputDOM0"].element_x = this.posicionX + 3;
    Motor["inputDOM1"].element_x = this.posicionX + 3;  
};

Pagina.prototype.isValidado = function(){
    
    var correcto = true;
    for( var i in this.respuesta ){
        if( JL.num2str(this.respuesta[i]) != this.valor[i]){
            if( i == 0 ){
                this.cajaX0.error();
            }else{
                this.cajaY0.error();
            }
            correcto = false;
        }else{
            if( i == 0 ){
                this.cajaX0.correct();
            }else{
                this.cajaY0.correct();
            }
        }
     }
     
    return correcto;
};

Pagina.prototype.verSolucion = function(){
    for( var i in this.respuesta ){
        if( JL.num2str(this.respuesta[i]) != this.valor[i]){
           this.contenedorRespuesta.alpha = 1;
        }
     }
};


Pagina.prototype.addLine = function( index, x, y, resposta){
		
    this["cajaX"+index] = new CajaTexto();
	this["cajaX"+index] .contenedor.x = x;
	this["cajaX"+index] .contenedor.y = y - 30;
	

	this.contenedor2.addChild( this["cajaX"+index].contenedor  );
	
	this["shape"+index] = new createjs.Shape();
    this["shape"+index].graphics.moveTo(x - 5, y + 20);
    this["shape"+index].graphics.setStrokeStyle("1").beginStroke("#000000");
    this["shape"+index].graphics.lineTo(x + 100, y + 20);
    
    this.contenedor2.addChild( this["shape"+index] );
	
	this["cajaY"+index] = new CajaTexto();
    this["cajaY"+index] .contenedor.x = x;
    this["cajaY"+index] .contenedor.y = y + 30;

    this.contenedor2.addChild( this["cajaY"+index].contenedor  );


    this.posicionX = this.contenedor2.x + x;
    this.posicionY = this.contenedor2.y;

	this.contenedorRespuesta.x =  this.contenedor2.x;
	this.contenedorRespuesta.y = y + 300;
	this.contenedorRespuesta.alpha = 0;

	this["valor"+index] = new createjs.RichText();
	this["valor"+index].text = resposta[0][0].toString();
    this["valor"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["valor"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
	this["valor"+index].color = "#E1001A";
	this["valor"+index].x = x + 50;
	this["valor"+index].y = y;
	this["valor"+index].textAlign = "center";
	this["valor"+index].alpha = 1;
	
	this.contenedorRespuesta.addChild( this["valor"+index]  );
	
	this["shape1"+index] = new createjs.Shape();
    this["shape1"+index].graphics.moveTo(x, y + 30);
    this["shape1"+index].graphics.setStrokeStyle("1").beginStroke("#E1001A");
    this["shape1"+index].graphics.lineTo(x + 100, y + 30);
	
	this.contenedorRespuesta.addChild( this["shape1"+index]  );
	
	this["valor"+index] = new createjs.RichText();
    this["valor"+index].text = resposta[0][1].toString();
    this["valor"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["valor"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["valor"+index].color = "#E1001A";
    this["valor"+index].x = x + 50;
    this["valor"+index].y = y + 40;
    this["valor"+index].textAlign = "center";
    this["valor"+index].alpha = 1;
    
    this.contenedorRespuesta.addChild( this["valor"+index]  );
}

Pagina.prototype.addText = function( index, x, y, _text){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this["text"+index].color = "#000";
    this["text"+index].x = x;
    this["text"+index].y = y + 8;
    
    this.contenedor2.addChild( this["text"+index] );
    
}

Pagina.prototype.addFrac = function( index, x, y, _text, _text2){
    
    this["textNum"+index] = new createjs.RichText();
    this["textNum"+index].text = _text.toString();
    this["textNum"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
    this["textNum"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this["textNum"+index].color = "#000";
    this["textNum"+index].x = x + 50;
    this["textNum"+index].y = y - 15;
    this["textNum"+index].textAlign = "center";
    
    this.contenedor2.addChild( this["textNum"+index] );
    
    this["shape"+index] = new createjs.Shape();
    this["shape"+index].graphics.moveTo(x, y + 20);
    this["shape"+index].graphics.setStrokeStyle("1").beginStroke("#000000");
    this["shape"+index].graphics.lineTo(x + 100, y + 20);
    
    this.contenedor2.addChild( this["shape"+index] );
    
    this["textDen"+index] = new createjs.RichText();
    this["textDen"+index].text = _text2.toString();
    this["textDen"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
    this["textDen"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this["textDen"+index].color = "#000";
    this["textDen"+index].x = x + 50;
    this["textDen"+index].y = y + 30;
    this["textDen"+index].textAlign = "center";
    
    this.contenedor2.addChild( this["textDen"+index] );
    
    
}


function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 90, 40, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}
