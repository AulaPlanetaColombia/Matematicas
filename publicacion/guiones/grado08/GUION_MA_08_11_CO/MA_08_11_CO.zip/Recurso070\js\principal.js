(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titol']);
this.txt_boto_03 = new cjs.Text(txt['txt_boto_03'], "bold 16px Verdana");
	this.txt_boto_03.textAlign = "center";
	this.txt_boto_03.lineHeight = 18;
	this.txt_boto_03.lineWidth = 260;
	this.txt_boto_03.setTransform(237.5,447.6);

	this.txt_boto_02 = new cjs.Text(txt['txt_boto_02'], "bold 16px Verdana");
	this.txt_boto_02.textAlign = "center";
	this.txt_boto_02.lineHeight = 18;
	this.txt_boto_02.lineWidth = 260;
	this.txt_boto_02.setTransform(237.6,329.6);

	this.txt_boto_01 = new cjs.Text(txt['txt_boto_01'], "bold 16px Verdana");
	this.txt_boto_01.textAlign = "center";
	this.txt_boto_01.lineHeight = 18;
	this.txt_boto_01.lineWidth = 260;
	this.txt_boto_01.setTransform(237.6,212.1);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(195,231.2,1,1,0,0,0,87.5,23.5);
	new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(195,349,1,1,0,0,0,87.5,23.5);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);

	this.mc_boto_03 = new lib.mc_01();
	this.mc_boto_03.setTransform(195,466.9,1,1,0,0,0,87.5,23.5);
new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_01(), 3);

	
   this.mc_boto_01.on("click", function (evt) {
            putStage(new lib.frame2());
        });
     this.mc_boto_02.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.mc_boto_03.on("click", function (evt) {
            putStage(new lib.frame4());
        });
	this.instance = new lib._1_shutterstock_86729548();
	this.instance.setTransform(457,152.5,0.5,0.5);
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance,this.mc_boto_03,this.mc_boto_02,this.mc_boto_01,this.txt_boto_01,this.txt_boto_02,this.txt_boto_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.e1_titol = new cjs.Text(txt['e1_titol'], "24px Verdana");
	this.e1_titol.textAlign = "center";
	this.e1_titol.lineHeight = 24;
	this.e1_titol.lineWidth = 784;
	this.e1_titol.setTransform(474.2,67.6);

	this.instance = new lib._2_shutterstock_50930257();
	this.instance.setTransform(235.7,213.5,0.5,0.5);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.e1_titol);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['p1_01'],"23px");
this.instance = new lib._2_shutterstock_50930257();
	this.instance.setTransform(235.7,213.5,0.5,0.5);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['p2_01'],"23px");
this.instance = new lib.mc_p2();
	this.instance.setTransform(476,345,1,1,0,0,0,369,182.5);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['p3_01'],"23px");
this.instance = new lib.mc_p3();
	this.instance.setTransform(477.7,350.1,1,1,0,0,0,376.7,197.4);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.informacion,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_popup_info'],"20px");
this.instance = new lib.popup_info();
	this.instance.setTransform(475,304,1,1,0,0,0,475,304);

     
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.informacion,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

      (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.e1_titol = new cjs.Text(txt['e2_titol'], "24px Verdana");
	this.e1_titol.textAlign = "center";
	this.e1_titol.lineHeight = 24;
	this.e1_titol.lineWidth = 784;
	this.e1_titol.setTransform(474.2,67.6);

	this.instance = new lib._3_shutterstock_55394590();
	this.instance.setTransform(179.4,152,0.5,0.5);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.e1_titol);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['f1_01'],"23px");
        

	this.text = new cjs.Text("24%", "bold 24px Verdana");
	this.text.lineHeight = 27;
	this.text.lineWidth = 74;
	this.text.setTransform(395.9,458.2,0.5,0.5);

	this.text_1 = new cjs.Text("32%", "bold 24px Verdana");
	this.text_1.lineHeight = 27;
	this.text_1.lineWidth = 68;
	this.text_1.setTransform(464.5,292.3,0.5,0.5);

	this.text_2 = new cjs.Text("1%", "bold 24px Verdana");
	this.text_2.lineHeight = 27;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(365.6,210.4,0.5,0.5);

	this.text_3 = new cjs.Text("4%", "bold 24px Verdana");
	this.text_3.lineHeight = 27;
	this.text_3.lineWidth = 55;
	this.text_3.setTransform(343.2,239.9,0.5,0.5);

	this.text_4 = new cjs.Text("1%", "bold 24px Verdana");
	this.text_4.lineHeight = 27;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(324.3,220.5,0.5,0.5);

	this.text_5 = new cjs.Text("14%", "bold 24px Verdana");
	this.text_5.lineHeight = 27;
	this.text_5.lineWidth = 67;
	this.text_5.setTransform(280,270.5,0.5,0.5);

	this.text_6 = new cjs.Text("1%", "bold 24px Verdana");
	this.text_6.lineHeight = 27;
	this.text_6.lineWidth = 58;
	this.text_6.setTransform(232.5,303,0.5,0.5);

	this.text_7 = new cjs.Text("18%", "bold 24px Verdana");
	this.text_7.lineHeight = 27;
	this.text_7.lineWidth = 68;
	this.text_7.setTransform(256.2,387.8,0.5,0.5);

	this.text_8 = new cjs.Text("2%", "bold 24px Verdana");
	this.text_8.lineHeight = 27;
	this.text_8.lineWidth = 54;
	this.text_8.setTransform(276.6,454,0.5,0.5);

	this.text_9 = new cjs.Text("1%", "bold 24px Verdana");
	this.text_9.lineHeight = 27;
	this.text_9.lineWidth = 62;
	this.text_9.setTransform(302.9,445.3,0.5,0.5);

	this.text_10 = new cjs.Text("2%", "bold 24px Verdana");
	this.text_10.lineHeight = 27;
	this.text_10.lineWidth = 51;
	this.text_10.setTransform(302.8,471.5,0.5,0.5);

	this.text_11 = new cjs.Text("35 655 630 ciudadanos con derecho a voto", "30px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 34;
	this.text_11.lineWidth = 660;
	this.text_11.setTransform(384.5,520.9,0.5,0.5);

	this.text_12 = new cjs.Text("PIN", "36px Verdana");
	this.text_12.lineHeight = 41;
	this.text_12.lineWidth = 120;
	this.text_12.setTransform(642,477,0.5,0.5);

	this.text_13 = new cjs.Text("AV ", "36px Verdana");
	this.text_13.lineHeight = 41;
	this.text_13.lineWidth = 132;
	this.text_13.setTransform(642,444.2,0.5,0.5);

	this.text_14 = new cjs.Text("PD", "36px Verdana");
	this.text_14.lineHeight = 41;
	this.text_14.lineWidth = 164;
	this.text_14.setTransform(642,411.5,0.5,0.5);

	this.text_15 = new cjs.Text("Resto partidos", "36px Verdana");
	this.text_15.lineHeight = 41;
	this.text_15.lineWidth = 328;
	this.text_15.setTransform(642,378.7,0.5,0.5);

	this.text_16 = new cjs.Text("En blanco", "36px Verdana");
	this.text_16.lineHeight = 41;
	this.text_16.lineWidth = 216;
	this.text_16.setTransform(642,346,0.5,0.5);

	this.text_17 = new cjs.Text("CR", "36px Verdana");
	this.text_17.lineHeight = 41;
	this.text_17.lineWidth = 58;
	this.text_17.setTransform(642,313.2,0.5,0.5);

	this.text_18 = new cjs.Text("CD", "36px Verdana");
	this.text_18.lineHeight = 41;
	this.text_18.lineWidth = 66;
	this.text_18.setTransform(642,280.5,0.5,0.5);

	this.text_19 = new cjs.Text("Liberal", "36px Verdana");
	this.text_19.lineHeight = 41;
	this.text_19.lineWidth = 104;
	this.text_19.setTransform(642,247.7,0.5,0.5);

	this.text_20 = new cjs.Text("Conservador", "36px Verdana");
	this.text_20.lineHeight = 41;
	this.text_20.lineWidth = 133;
	this.text_20.setTransform(642,215,0.5,0.5);

	this.text_21 = new cjs.Text("Abstención", "36px Verdana");
	this.text_21.lineHeight = 41;
	this.text_21.lineWidth = 274;
	this.text_21.setTransform(642,182.2,0.5,0.5);

	this.text_22 = new cjs.Text("ELECCIONES 2011", "30px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 35;
	this.text_22.lineWidth = 341;
	this.text_22.setTransform(459.2,168,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7FECC").s().p("Ah/CBIAAkBID/AAIAAEBg");
	this.shape.setTransform(621.2,423.5,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B8FFFE").s().p("Ah/CBIAAkBID/AAIAAEBg");
	this.shape_1.setTransform(621.2,292.5,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#98BE91").s().p("Ah/CAIAAkAID/AAIAAEAg");
	this.shape_2.setTransform(621.2,390.8,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#945257").s().p("Ah/CAIAAj/ID/AAIAAD/g");
	this.shape_3.setTransform(621.2,259.7,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFA848").s().p("Ah/CAIAAj/ID/AAIAAD/g");
	this.shape_4.setTransform(621.2,489,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7B22FF").s().p("Ah/CAIAAj/ID/AAIAAD/g");
	this.shape_5.setTransform(621.2,358,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00E250").s().p("Ah/CBIAAkBID/AAIAAEBg");
	this.shape_6.setTransform(621.2,227,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFF48D").s().p("Ah/CBIAAkAID/AAIAAEAg");
	this.shape_7.setTransform(621.2,456.3,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FC2A36").s().p("Ah/CBIAAkBID/AAIAAEBg");
	this.shape_8.setTransform(621.2,325.2,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#34ADFE").s().p("Ah/CBIAAkAID/AAIAAEAg");
	this.shape_9.setTransform(621.2,194.2,0.5,0.5);

	this.instance = new lib.Grupodeclips0();
	this.instance.setTransform(406.8,462.7,0.5,0.5,0,0,0,27,16.2);

	this.instance_1 = new lib.Grupodeclips0_1();
	this.instance_1.setTransform(475.4,296.9,0.5,0.5,0,0,0,27,16.2);

	this.instance_2 = new lib.Grupodeclips0_2();
	this.instance_2.setTransform(373.3,214.9,0.5,0.5,0,0,0,20.7,16.2);

	this.instance_3 = new lib.Grupodeclips0_3();
	this.instance_3.setTransform(349.8,243.9,0.5,0.5,0,0,0,20.6,16.2);

	this.instance_4 = new lib.Grupodeclips0_4();
	this.instance_4.setTransform(332,225,0.5,0.5,0,0,0,20.6,16.2);

	this.instance_5 = new lib.Grupodeclips0_5();
	this.instance_5.setTransform(290.9,275.1,0.5,0.5,0,0,0,27,16.2);

	this.instance_6 = new lib.Grupodeclips0_6();
	this.instance_6.setTransform(242.7,313.2,0.5,0.5,0,0,0,20.6,16.2);

	this.instance_7 = new lib.Grupodeclips0_7();
	this.instance_7.setTransform(267,392.4,0.5,0.5,0,0,0,27,16.2);

	this.instance_8 = new lib.Grupodeclips0_8();
	this.instance_8.setTransform(288.8,461.5,0.5,0.5,0,0,0,20.7,16.2);

	this.instance_9 = new lib.Grupodeclips0_9();
	this.instance_9.setTransform(316.6,450.4,0.5,0.5,0,0,0,20.7,16.2);

	this.instance_10 = new lib.Grupodeclips0_10();
	this.instance_10.setTransform(312.7,477.3,0.5,0.5,0,0,0,20.6,16.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B7FECC").s().p("Ahu3oIDdgIMgAKAvgg");
	this.shape_10.setTransform(365.9,276.4,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B8FFFE").s().p("AnU1eIDMg7IEDg0IEGgfMADUAvYg");
	this.shape_11.setTransform(347.5,276.6,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00CEFE").s().p("Aog1wICXg1MAOpAtLg");
	this.shape_12.setTransform(343.7,280.1,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#98BE91").s().p("A2cGtIAkhkICBkjICDjlIC3kEICIijIBth0IDujVIB+hhICvh2IFFixIDDhTMARCAsVg");
	this.shape_13.setTransform(299.1,281.5,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#945257").s().p("A27kjIA+jLMAs5APdg");
	this.shape_14.setTransform(297.5,327.7,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFA848").s().p("AqbVOIjQjwIi3kFIiakXIhqjzIhFjJIgriXIg8k5Igck9IAAjUIAFhqIAnk8IA6kDMAt3AMTMgfJAj2g");
	this.shape_15.setTransform(295,390.2,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#7B22FF").s().p("ArpTOIj7jEMAfJgj1MgajAnXg");
	this.shape_16.setTransform(321.1,415.5,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00E250").s().p("AtRS0MAajgnYMgXvApIg");
	this.shape_17.setTransform(328.4,418.3,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFF48D").s().p("Ao7U1Ii8hjMAXvgpIMgSiArtg");
	this.shape_18.setTransform(332.9,422.4,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FC2A36").s().p("AwpXfIk6gxIk0hTIj4hdMASkgrtMAp7AWTIhOCJIiyEIIhjB9IizDDIjECzIhSBDIisB9IkSCkIkgCHIjHBIIkyBTIk6AxIk+ARg");
	this.shape_19.setTransform(408.4,428.5,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#34ADFE").s().p("A3vMmMAAAgvfQIsAAIwEFQIVD6G4G3QG3G4D6IWQEFIvAAIsIAAA1IgXE+IgXCdIhIE2IhUD8Ig9CUIhdC+g");
	this.shape_20.setTransform(447,312.1,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#808080").ss(0.3,2).p("AAAXvMAAAgvd");
	this.shape_21.setTransform(371.9,277.3,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#808080").ss(0.3,2).p("ABoXsMgDPgvX");
	this.shape_22.setTransform(366.6,277.5,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#808080").s().p("Ahp3oICdgHMAA2Avfg");
	this.shape_23.setTransform(366.6,277.4,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#808080").ss(0.3,2).p("ABoXsMgDPgvX");
	this.shape_24.setTransform(366.6,277.5,0.5,0.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#808080").ss(0.3,2).p("AHUWlMgOngtJ");
	this.shape_25.setTransform(348.3,281,0.5,0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#808080").s().p("AjzAjIBegVIi0AvgAB3gmIDTgWIAAADIieAPIjsAng");
	this.shape_26.setTransform(343.2,205.2,0.5,0.5,0,0,0,-3.2,0.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#808080").s().p("AnU1eIBlgfIE2hIIA1gJIEFgdMADUAvYg");
	this.shape_27.setTransform(348.4,277.5,0.5,0.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#808080").ss(0.3,2).p("AHUWlMgOngtJ");
	this.shape_28.setTransform(348.3,281,0.5,0.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#808080").ss(0.3,2).p("AIfWKMgQ9gsT");
	this.shape_29.setTransform(344.6,282.3,0.5,0.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#808080").s().p("AApgOIABACIhTAbg");
	this.shape_30.setTransform(321.2,210.1,0.5,0.5,0,0,0,-3.2,1.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#808080").s().p("Aof1wICWg1MAOqAtLg");
	this.shape_31.setTransform(344.6,281.1,0.5,0.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#808080").ss(0.3,2).p("AIfWKMgQ9gsT");
	this.shape_32.setTransform(344.6,282.3,0.5,0.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#808080").ss(0.3,2).p("AWcHuMgs3gPb");
	this.shape_33.setTransform(300,328.6,0.5,0.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#808080").s().p("AtYM4ICCkiIBni6IAjg0IiIDvIhuDxIg6CUgAkUh3IBthzIDCi0ICniCIB4hOIh2BQIh/BhIjqDUIjRDpgAHNrOIEciQICTg9IABACIhjAoIkdCLIhfA3g");
	this.shape_34.setTransform(272.8,257.6,0.5,0.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#808080").s().p("A2cGtIAkhkICBkiIBni4IA5haIC7kCIBnh5IBuhzIBMhKID0jNIEIiyIDnh+IDzhqMARCAsVg");
	this.shape_35.setTransform(300,282.4,0.5,0.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#808080").ss(0.3,2).p("AWcHuMgs3gPb");
	this.shape_36.setTransform(300,328.6,0.5,0.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#808080").ss(0.3,2).p("AW7GIMgt2gMP");
	this.shape_37.setTransform(298.4,333.7,0.5,0.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#808080").s().p("AAOgxIACAAIgfBjg");
	this.shape_38.setTransform(226.6,309,0.5,0.5,0,0,0,-1.5,5.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#808080").s().p("A27kjIA+jKMAs5APcg");
	this.shape_39.setTransform(298.4,328.6,0.5,0.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#808080").ss(0.3,2).p("AW7GIMgt2gMP");
	this.shape_40.setTransform(298.4,333.7,0.5,0.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#808080").ss(0.3,2).p("APlx5MgfIAjz");
	this.shape_41.setTransform(321.9,410.7,0.5,0.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#808080").s().p("AF1V1IjNj0IhximICUDOICsDKIBCBFgAgIN5IgwhbIBkCtgAiGKQIhqj0IhFjIIhNkzIgTiBIAVCAIA+EAIBVD8IBpDzIAqBSgAmplmIgPjTIACkKIAakIIAkjRIAmibIACABIglCaIglDRIgZEIIgDEJIAXEWg");
	this.shape_42.setTransform(246,391,0.5,0.5,0,0,0,8,7.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#808080").s().p("AopW+IjdjlIjiknIi9lAIiBkjIhFjIIhDj/IgdidIgjlxIAFk/IAekHIBDk4MAt3AMTMgfJAj2g");
	this.shape_43.setTransform(295.9,391.1,0.5,0.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#808080").ss(0.3,2).p("APlx5MgfIAjz");
	this.shape_44.setTransform(321.9,410.7,0.5,0.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#808080").ss(0.3,2).p("ANQzrMgagAnX");
	this.shape_45.setTransform(329.3,416.4,0.5,0.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#808080").s().p("AhKg0IgogjIABgBIDkCxg");
	this.shape_46.setTransform(279.5,473.8,0.5,0.5,0,0,0,3.2,2.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#808080").s().p("ArpTOIj7jEMAfJgj1MgajAnXg");
	this.shape_47.setTransform(322,416.4,0.5,0.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#808080").ss(0.3,2).p("ANQzrMgagAnX");
	this.shape_48.setTransform(329.3,416.4,0.5,0.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#808080").ss(0.3,2).p("AL40jMgXvApH");
	this.shape_49.setTransform(333.8,419.2,0.5,0.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#808080").s().p("AgsgZIABgCIBYA3g");
	this.shape_50.setTransform(291.4,482.2,0.5,0.5,0,0,0,4.5,2.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#808080").s().p("AtRS0MAajgnXMgXvApIg");
	this.shape_51.setTransform(329.4,419.2,0.5,0.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#808080").ss(0.3,2).p("AL40jMgXvApH");
	this.shape_52.setTransform(333.8,419.2,0.5,0.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#808080").ss(0.3,2).p("AJQ11MgSgArr");
	this.shape_53.setTransform(342.1,423.3,0.5,0.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#808080").s().p("AgZgFIiMhLIABgDIFKCmg");
	this.shape_54.setTransform(304.2,489.2,0.5,0.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#808080").s().p("AprUdIiMhLMAXvgpIMgSiArtg");
	this.shape_55.setTransform(333.9,423.4,0.5,0.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#808080").ss(0.3,2).p("AJQ11MgSgArr");
	this.shape_56.setTransform(342.1,423.3,0.5,0.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#808080").ss(0.3,2).p("A08rHMAp5AWQ");
	this.shape_57.setTransform(438.9,389,0.5,0.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#808080").s().p("AsiLRIhqgGIjFgZID6AZIBqAFICfgCIFygkIE1hCIEvhiIEiiBICMhNIBbg2ID+iyIjQCXIiIBUIi7BkIiRBBIhjAoIkuBiIkBA6IjTAdIjTAQgAzIKkIk2hHIiAgtICBAqIFoBQgA9cHgIABgCIBdAmgAWGiDIDZjpIC/j+IA/hmIg9BoIhdCBIhkB7IiyDGIibCQIh2Bcg");
	this.shape_58.setTransform(409.3,465.1,0.5,0.5,0,0,0,5.1,-8.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#808080").s().p("AySXUIk5g9Ij+hMIjGhMMASkgrtMAp7AWUIhqC1IiWDbIjND0IjlDdIh7BlIiABfIkOCpIkeCLIjGBMIlkBjIicAeIk9AhIkJADg");
	this.shape_59.setTransform(409.3,429.4,0.5,0.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#808080").ss(0.3,2).p("A08rHMAp5AWQ");
	this.shape_60.setTransform(438.9,389,0.5,0.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#808080").ss(0.3,2).p("AAAXvMAAAgvd");
	this.shape_61.setTransform(371.9,277.3,0.5,0.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#808080").s().p("EASEAi2IBHiOIBlj1IBdkvIA8k4IAck8IAChqQAAorkFosQj5oVm2m2Qm2m2oTj5QoukEorAAIAAgKQIsAAIxEFQIUD6G4G3QG3G4D6IXQEFIuAAIsIgQE+IgnEHIgjCbIhLD/IhiD2IhdC/g");
	this.shape_62.setTransform(447.9,313,0.5,0.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#808080").s().p("A3vMmMAAAgvfQIsAAIxEFQIUD6G4G3QG3G4D6IXQEFIuAAIsIgQE+IgnEHIgjCbIhLD/IhiD2IhdC/g");
	this.shape_63.setTransform(447.9,313,0.5,0.5);        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.f1_01 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['f2_01'],"23px");
this.instance = new lib.mc_f2();
	this.instance.setTransform(477.6,346.5,1,1,0,0,0,288.8,165.1);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['f3_01'],"23px");

     this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AIdEkIw4pH");
	this.shape.setTransform(385.5,509.9,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("AG4D6Itvnz");
	this.shape_1.setTransform(292.9,198.7,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_2.setTransform(253.1,186.2,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_3.setTransform(430.6,524.2,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_4.setTransform(361.2,172.7,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AAjp1IhFTq");
	this.shape_5.setTransform(341.7,204.2,0.5,0.5);

	this.instance = new lib.mc_f3();
	this.instance.setTransform(365.8,336.8,1,1,0,0,0,112.6,188.7);

	this.text = new cjs.Text("0", "38px Verdana");
	this.text.lineHeight = 38;
	this.text.setTransform(297.5,452.9,0.5,0.5);

	this.text_1 = new cjs.Text("1", "38px Verdana");
	this.text_1.lineHeight = 38;
	this.text_1.setTransform(285.4,452.9,0.5,0.5);

	this.text_2 = new cjs.Text("4", "38px Verdana");
	this.text_2.lineHeight = 38;
	this.text_2.setTransform(248,321.9,0.5,0.5);

	this.text_3 = new cjs.Text("3", "38px Verdana");
	this.text_3.lineHeight = 38;
	this.text_3.setTransform(235.9,321.9,0.5,0.5);

	this.text_4 = new cjs.Text("8", "38px Verdana");
	this.text_4.lineHeight = 38;
	this.text_4.setTransform(437,319.4,0.5,0.5);

	this.text_5 = new cjs.Text("4", "38px Verdana");
	this.text_5.lineHeight = 38;
	this.text_5.setTransform(424.9,319.4,0.5,0.5);

	this.text_6 = new cjs.Text("3", "38px Verdana");
	this.text_6.lineHeight = 38;
	this.text_6.setTransform(411.2,500.5,0.5,0.5);

	this.text_7 = new cjs.Text("4", "38px Verdana");
	this.text_7.lineHeight = 38;
	this.text_7.setTransform(342.7,148.1,0.5,0.5);

	this.text_8 = new cjs.Text("1", "38px Verdana");
	this.text_8.lineHeight = 38;
	this.text_8.setTransform(234.4,161.1,0.5,0.5);

	this.text_9 = new cjs.Text("Especies encontradas", "40px Verdana");
	this.text_9.lineHeight = 45;
	this.text_9.lineWidth = 439;
	this.text_9.setTransform(544.9,181.7,0.5,0.5);

	this.text_10 = new cjs.Text("perca", "40px Verdana");
	this.text_10.lineHeight = 45;
	this.text_10.lineWidth = 140;
	this.text_10.setTransform(581.8,457.6,0.5,0.5);

	this.text_11 = new cjs.Text("platija", "40px Verdana");
	this.text_11.lineHeight = 45;
	this.text_11.lineWidth = 151;
	this.text_11.setTransform(581.8,411.6,0.5,0.5);

	this.text_12 = new cjs.Text("aguja", "40px Verdana");
	this.text_12.lineHeight = 45;
	this.text_12.lineWidth = 120;
	this.text_12.setTransform(581.8,365.6,0.5,0.5);

	this.text_13 = new cjs.Text("lamprea", "40px Verdana");
	this.text_13.lineHeight = 45;
	this.text_13.lineWidth = 171;
	this.text_13.setTransform(581.8,319.6,0.5,0.5);

	this.text_14 = new cjs.Text("lucio", "40px Verdana");
	this.text_14.lineHeight = 45;
	this.text_14.lineWidth = 105;
	this.text_14.setTransform(581.8,273.6,0.5,0.5);

	this.text_15 = new cjs.Text("salmón", "40px Verdana");
	this.text_15.lineHeight = 45;
	this.text_15.lineWidth = 148;
	this.text_15.setTransform(581.8,227.6,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFA848").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_6.setTransform(555.1,473.6,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#7B22FF").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_7.setTransform(555.1,427.5,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00E250").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_8.setTransform(555.1,381.5,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFF48D").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_9.setTransform(555.1,335.5,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FC2A36").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_10.setTransform(555.1,289.4,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#34ADFE").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_11.setTransform(555.1,243.4,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFA848").s().p("AmP4QIA4gOIEbg0ICqgUIEigLMgACAzjg");
	this.shape_12.setTransform(334,263.9,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#7B22FF").s().p("An94BIDehAMAMdAyCg");
	this.shape_13.setTransform(328.4,266.3,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00E250").s().p("EgJYAqgIhThQIh3h9IhMhXIiNi2IhDheIh5jEIg5hlIh7kEIh3lFIhUlPIgqkdIgRkfIAHkgIAgkdIA6kaIBllLICHk+ICKj9ICfjwIDZkNIDKjNIDbi7IDrioID2iSIE5iSIDZhPMAP8AxDMghIAnig");
	this.shape_14.setTransform(271.3,331.2,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFF48D").s().p("AIgZOIiqgfIlNhaIlBh8Ik1idIjziaIjkiwMAhJgngMgDnAzdg");
	this.shape_15.setTransform(300.8,428.8,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FC2A36").s().p("Ak7ZsMADngzdMAGQAzMIhzAMIisALg");
	this.shape_16.setTransform(358.2,428.9,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#34ADFE").s().p("A5yAMMAAAgzkQKDgCJfEBQJND6HQHHQHWHMECJOQEQJrgDKfIgCBzIgQDmIgqEdIhEEYIhHDbIhWDWIiBECIiWD2IjQEUIjDDUIkBDnIgtAkIjqCoIj3CSIk5CSIjYBPIlOBZIkdAwg");
	this.shape_17.setTransform(436.4,345.8,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_18.setTransform(354.8,264.7,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_19.setTransform(334.7,267.1,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#808080").s().p("AkBAXICqgdIiqAdIhwAZgACMgjIA5gEIisATgAE4gtIhzAGgAFygvIAAABIgrABg");
	this.shape_20.setTransform(333.3,184.7,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#808080").s().p("AmO4QIA4gNIEbg1IBwgOIEggSMAA6Azkg");
	this.shape_21.setTransform(334.8,264.8,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_22.setTransform(334.7,267.1,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_23.setTransform(329.2,268.7,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#808080").s().p("AAUgFIAAABIgnAKg");
	this.shape_24.setTransform(309.3,188.7,0.5,0.5,0,0,0,-8.9,2.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#808080").s().p("An94BIDehAMAMdAyDg");
	this.shape_25.setTransform(329.2,267.2,0.5,0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_26.setTransform(329.2,268.7,0.5,0.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_27.setTransform(354.8,264.7,0.5,0.5);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
         this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame3_4());
    });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.informacion,this.instance,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.instance,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.f3_01,this.practica );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['titol_selecciona'],"23px");
        
        
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AIdEkIw4pH");
	this.shape.setTransform(583.9,498.2,0.466,0.466);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("AG4D6Itvnz");
	this.shape_1.setTransform(497.5,208,0.466,0.466);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_2.setTransform(460.4,196.3,0.466,0.466);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_3.setTransform(626,511.6,0.466,0.466);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_4.setTransform(561.2,183.7,0.466,0.466);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AAjp1IhFTq");
	this.shape_5.setTransform(543,213.1,0.466,0.466);

	this.text = new cjs.Text("%", "38px Verdana");
	this.text.lineHeight = 38;
	this.text.setTransform(519.3,445.1,0.466,0.466);

	this.text_1 = new cjs.Text("%", "38px Verdana");
	this.text_1.lineHeight = 38;
	this.text_1.setTransform(473.1,322.9,0.466,0.466);

	this.text_2 = new cjs.Text("%", "38px Verdana");
	this.text_2.lineHeight = 38;
	this.text_2.setTransform(649.4,320.6,0.466,0.466);

	this.text_3 = new cjs.Text("%", "38px Verdana");
	this.text_3.lineHeight = 38;
	this.text_3.setTransform(625.4,489.4,0.466,0.466);

	this.text_4 = new cjs.Text("%", "38px Verdana");
	this.text_4.lineHeight = 38;
	this.text_4.setTransform(561.5,160.7,0.466,0.466);

	this.text_5 = new cjs.Text("%", "38px Verdana");
	this.text_5.lineHeight = 38;
	this.text_5.setTransform(460.5,172.9,0.466,0.466);

	this.text_6 = new cjs.Text("0", "38px Verdana");
	this.text_6.lineHeight = 38;
	this.text_6.setTransform(501.8,445.1,0.466,0.466);

	this.text_7 = new cjs.Text("1", "38px Verdana");
	this.text_7.lineHeight = 38;
	this.text_7.setTransform(490.5,445.1,0.466,0.466);

	this.text_8 = new cjs.Text("4", "38px Verdana");
	this.text_8.lineHeight = 38;
	this.text_8.setTransform(455.6,322.9,0.466,0.466);

	this.text_9 = new cjs.Text("3", "38px Verdana");
	this.text_9.lineHeight = 38;
	this.text_9.setTransform(444.4,322.9,0.466,0.466);

	this.text_10 = new cjs.Text("8", "38px Verdana");
	this.text_10.lineHeight = 38;
	this.text_10.setTransform(631.9,320.6,0.466,0.466);

	this.text_11 = new cjs.Text("4", "38px Verdana");
	this.text_11.lineHeight = 38;
	this.text_11.setTransform(620.6,320.6,0.466,0.466);

	this.text_12 = new cjs.Text("3", "38px Verdana");
	this.text_12.lineHeight = 38;
	this.text_12.setTransform(607.9,489.4,0.466,0.466);

	this.text_13 = new cjs.Text("4", "38px Verdana");
	this.text_13.lineHeight = 38;
	this.text_13.setTransform(544,160.7,0.466,0.466);

	this.text_14 = new cjs.Text("1", "38px Verdana");
	this.text_14.lineHeight = 38;
	this.text_14.setTransform(443,172.9,0.466,0.466);

	this.text_15 = new cjs.Text("Especies\nencontradas", "40px Verdana");
	this.text_15.lineHeight = 45;
	this.text_15.lineWidth = 263;
	this.text_15.setTransform(745.4,170.8,0.5,0.5);

	this.text_16 = new cjs.Text("perca", "40px Verdana");
	this.text_16.lineHeight = 45;
	this.text_16.lineWidth = 140;
	this.text_16.setTransform(782.4,472.9,0.5,0.5);

	this.text_17 = new cjs.Text("platija", "40px Verdana");
	this.text_17.lineHeight = 45;
	this.text_17.lineWidth = 151;
	this.text_17.setTransform(782.4,426.9,0.5,0.5);

	this.text_18 = new cjs.Text("aguja", "40px Verdana");
	this.text_18.lineHeight = 45;
	this.text_18.lineWidth = 120;
	this.text_18.setTransform(782.4,380.9,0.5,0.5);

	this.text_19 = new cjs.Text("lamprea", "40px Verdana");
	this.text_19.lineHeight = 45;
	this.text_19.lineWidth = 171;
	this.text_19.setTransform(782.4,334.9,0.5,0.5);

	this.text_20 = new cjs.Text("lucio", "40px Verdana");
	this.text_20.lineHeight = 45;
	this.text_20.lineWidth = 105;
	this.text_20.setTransform(782.4,288.9,0.5,0.5);

	this.text_21 = new cjs.Text("salmón", "40px Verdana");
	this.text_21.lineHeight = 45;
	this.text_21.lineWidth = 148;
	this.text_21.setTransform(782.4,242.9,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFA848").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_6.setTransform(755.6,488.9,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#7B22FF").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_7.setTransform(755.6,442.8,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00E250").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_8.setTransform(755.6,396.8,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFF48D").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_9.setTransform(755.6,350.8,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FC2A36").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_10.setTransform(755.6,304.7,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#34ADFE").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_11.setTransform(755.6,258.7,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFA848").s().p("AmP4QIA4gOIEbg0ICqgUIEigLMgACAzjg");
	this.shape_12.setTransform(536,268.9,0.466,0.466);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#7B22FF").s().p("An94BIDehAMAMdAyCg");
	this.shape_13.setTransform(530.8,271.1,0.466,0.466);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00E250").s().p("EgJYAqgIhThQIh3h9IhMhXIiNi2IhDheIh5jEIg5hlIh7kEIh3lFIhUlPIgqkdIgRkfIAHkgIAgkdIA6kaIBllLICHk+ICKj9ICfjwIDZkNIDKjNIDbi7IDrioID2iSIE5iSIDZhPMAP8AxDMghIAnig");
	this.shape_14.setTransform(477.6,331.6,0.466,0.466);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFF48D").s().p("AIgZOIiqgfIlNhaIlBh8Ik1idIjziaIjkiwMAhJgngMgDnAzdg");
	this.shape_15.setTransform(505.1,422.7,0.466,0.466);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FC2A36").s().p("Ak7ZsMADngzdMAGQAzMIhzAMIisALg");
	this.shape_16.setTransform(558.6,422.8,0.466,0.466);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#34ADFE").s().p("A5yAMMAAAgzkQKDgCJfEBQJND6HQHHQHWHMECJOQEQJrgDKfIgCBzIgQDmIgqEdIhEEYIhHDbIhWDWIiBECIiWD2IjQEUIjDDUIkBDnIgtAkIjqCoIj3CSIk5CSIjYBPIlOBZIkdAwg");
	this.shape_17.setTransform(631.6,345.3,0.466,0.466);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_18.setTransform(555.4,269.6,0.466,0.466);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_19.setTransform(536.8,271.9,0.466,0.466);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#808080").s().p("AkBAXICqgdIiqAdIhwAZgACMgjIA5gEIisATgAE4gtIhzAGgAFygvIAAABIgrABg");
	this.shape_20.setTransform(535.5,195,0.466,0.466);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#808080").s().p("AmO4QIA4gNIEbg1IBwgOIEggSMAA6Azkg");
	this.shape_21.setTransform(536.8,269.7,0.466,0.466);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_22.setTransform(536.8,271.9,0.466,0.466);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_23.setTransform(531.6,273.4,0.466,0.466);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#808080").s().p("AAUgFIAAABIgnAKg");
	this.shape_24.setTransform(513,198.7,0.466,0.466,0,0,0,-8.9,2.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#808080").s().p("An94BIDehAMAMdAyDg");
	this.shape_25.setTransform(531.6,272,0.466,0.466);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_26.setTransform(531.6,273.4,0.466,0.466);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_27.setTransform(555.4,269.6,0.466,0.466);


this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
   putStage(new lib.frame3_5());
    });
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.practica,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        titulo2(this, txt['txt_solucion_01'],"23px");
this.instance = new lib.mc_solucion();
	this.instance.setTransform(474.5,275.9,1,1,0,0,0,393.5,233.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AIdEkIw4pH");
	this.shape.setTransform(583.9,498.2,0.466,0.466);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,0,0,4).p("AG4D6Itvnz");
	this.shape_1.setTransform(497.5,208,0.466,0.466);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_2.setTransform(460.4,196.3,0.466,0.466);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_3.setTransform(626,511.6,0.466,0.466);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AFtAAIrZAA");
	this.shape_4.setTransform(561.2,183.7,0.466,0.466);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AAjp1IhFTq");
	this.shape_5.setTransform(543,213.1,0.466,0.466);

	this.text = new cjs.Text("%", "38px Verdana");
	this.text.lineHeight = 38;
	this.text.setTransform(519.3,445.1,0.466,0.466);

	this.text_1 = new cjs.Text("%", "38px Verdana");
	this.text_1.lineHeight = 38;
	this.text_1.setTransform(473.1,322.9,0.466,0.466);

	this.text_2 = new cjs.Text("%", "38px Verdana");
	this.text_2.lineHeight = 38;
	this.text_2.setTransform(649.4,320.6,0.466,0.466);

	this.text_3 = new cjs.Text("%", "38px Verdana");
	this.text_3.lineHeight = 38;
	this.text_3.setTransform(625.4,489.4,0.466,0.466);

	this.text_4 = new cjs.Text("%", "38px Verdana");
	this.text_4.lineHeight = 38;
	this.text_4.setTransform(561.5,160.7,0.466,0.466);

	this.text_5 = new cjs.Text("%", "38px Verdana");
	this.text_5.lineHeight = 38;
	this.text_5.setTransform(460.5,172.9,0.466,0.466);

	this.text_6 = new cjs.Text("0", "38px Verdana");
	this.text_6.lineHeight = 38;
	this.text_6.setTransform(501.8,445.1,0.466,0.466);

	this.text_7 = new cjs.Text("1", "38px Verdana");
	this.text_7.lineHeight = 38;
	this.text_7.setTransform(490.5,445.1,0.466,0.466);

	this.text_8 = new cjs.Text("4", "38px Verdana");
	this.text_8.lineHeight = 38;
	this.text_8.setTransform(455.6,322.9,0.466,0.466);

	this.text_9 = new cjs.Text("3", "38px Verdana");
	this.text_9.lineHeight = 38;
	this.text_9.setTransform(444.4,322.9,0.466,0.466);

	this.text_10 = new cjs.Text("8", "38px Verdana");
	this.text_10.lineHeight = 38;
	this.text_10.setTransform(631.9,320.6,0.466,0.466);

	this.text_11 = new cjs.Text("4", "38px Verdana");
	this.text_11.lineHeight = 38;
	this.text_11.setTransform(620.6,320.6,0.466,0.466);

	this.text_12 = new cjs.Text("3", "38px Verdana");
	this.text_12.lineHeight = 38;
	this.text_12.setTransform(607.9,489.4,0.466,0.466);

	this.text_13 = new cjs.Text("4", "38px Verdana");
	this.text_13.lineHeight = 38;
	this.text_13.setTransform(544,160.7,0.466,0.466);

	this.text_14 = new cjs.Text("1", "38px Verdana");
	this.text_14.lineHeight = 38;
	this.text_14.setTransform(443,172.9,0.466,0.466);

	this.text_15 = new cjs.Text("Especies\nencontradas", "40px Verdana");
	this.text_15.lineHeight = 45;
	this.text_15.lineWidth = 263;
	this.text_15.setTransform(745.4,170.8,0.5,0.5);

	this.text_16 = new cjs.Text("perca", "40px Verdana");
	this.text_16.lineHeight = 45;
	this.text_16.lineWidth = 140;
	this.text_16.setTransform(782.4,472.9,0.5,0.5);

	this.text_17 = new cjs.Text("platija", "40px Verdana");
	this.text_17.lineHeight = 45;
	this.text_17.lineWidth = 151;
	this.text_17.setTransform(782.4,426.9,0.5,0.5);

	this.text_18 = new cjs.Text("aguja", "40px Verdana");
	this.text_18.lineHeight = 45;
	this.text_18.lineWidth = 120;
	this.text_18.setTransform(782.4,380.9,0.5,0.5);

	this.text_19 = new cjs.Text("lamprea", "40px Verdana");
	this.text_19.lineHeight = 45;
	this.text_19.lineWidth = 171;
	this.text_19.setTransform(782.4,334.9,0.5,0.5);

	this.text_20 = new cjs.Text("lucio", "40px Verdana");
	this.text_20.lineHeight = 45;
	this.text_20.lineWidth = 105;
	this.text_20.setTransform(782.4,288.9,0.5,0.5);

	this.text_21 = new cjs.Text("salmón", "40px Verdana");
	this.text_21.lineHeight = 45;
	this.text_21.lineWidth = 148;
	this.text_21.setTransform(782.4,242.9,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFA848").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_6.setTransform(755.6,488.9,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#7B22FF").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_7.setTransform(755.6,442.8,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00E250").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_8.setTransform(755.6,396.8,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFF48D").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_9.setTransform(755.6,350.8,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FC2A36").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_10.setTransform(755.6,304.7,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#34ADFE").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_11.setTransform(755.6,258.7,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFA848").s().p("AmP4QIA4gOIEbg0ICqgUIEigLMgACAzjg");
	this.shape_12.setTransform(536,268.9,0.466,0.466);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#7B22FF").s().p("An94BIDehAMAMdAyCg");
	this.shape_13.setTransform(530.8,271.1,0.466,0.466);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00E250").s().p("EgJYAqgIhThQIh3h9IhMhXIiNi2IhDheIh5jEIg5hlIh7kEIh3lFIhUlPIgqkdIgRkfIAHkgIAgkdIA6kaIBllLICHk+ICKj9ICfjwIDZkNIDKjNIDbi7IDrioID2iSIE5iSIDZhPMAP8AxDMghIAnig");
	this.shape_14.setTransform(477.6,331.6,0.466,0.466);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFF48D").s().p("AIgZOIiqgfIlNhaIlBh8Ik1idIjziaIjkiwMAhJgngMgDnAzdg");
	this.shape_15.setTransform(505.1,422.7,0.466,0.466);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FC2A36").s().p("Ak7ZsMADngzdMAGQAzMIhzAMIisALg");
	this.shape_16.setTransform(558.6,422.8,0.466,0.466);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#34ADFE").s().p("A5yAMMAAAgzkQKDgCJfEBQJND6HQHHQHWHMECJOQEQJrgDKfIgCBzIgQDmIgqEdIhEEYIhHDbIhWDWIiBECIiWD2IjQEUIjDDUIkBDnIgtAkIjqCoIj3CSIk5CSIjYBPIlOBZIkdAwg");
	this.shape_17.setTransform(631.6,345.3,0.466,0.466);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_18.setTransform(555.4,269.6,0.466,0.466);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_19.setTransform(536.8,271.9,0.466,0.466);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#808080").s().p("AkBAXICqgdIiqAdIhwAZgACMgjIA5gEIisATgAE4gtIhzAGgAFygvIAAABIgrABg");
	this.shape_20.setTransform(535.5,195,0.466,0.466);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#808080").s().p("AmO4QIA4gNIEbg1IBwgOIEggSMAA6Azkg");
	this.shape_21.setTransform(536.8,269.7,0.466,0.466);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_22.setTransform(536.8,271.9,0.466,0.466);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_23.setTransform(531.6,273.4,0.466,0.466);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#808080").s().p("AAUgFIAAABIgnAKg");
	this.shape_24.setTransform(513,198.7,0.466,0.466,0,0,0,-8.9,2.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#808080").s().p("An94BIDehAMAMdAyDg");
	this.shape_25.setTransform(531.6,272,0.466,0.466);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_26.setTransform(531.6,273.4,0.466,0.466);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_27.setTransform(555.4,269.6,0.466,0.466);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.e1_titol = new cjs.Text(txt['e3_titol'], "24px Verdana");
	this.e1_titol.textAlign = "center";
	this.e1_titol.lineHeight = 24;
	this.e1_titol.lineWidth = 784;
	this.e1_titol.setTransform(474.2,67.6);

	this.instance = new lib.Excel1();
	this.instance.setTransform(188.4,152.6,0.627,0.627);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.e1_titol);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['h1_01'],"23px");
this.instance = new lib.Excel2();
	this.instance.setTransform(240.8,174.6,0.504,0.504);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['h2_01'],"23px");
this.instance = new lib.Excel3();
	this.instance.setTransform(207.5,161.7,0.553,0.553);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['h3_01'],"23px");
this.instance = new lib.Excel4();
	this.instance.setTransform(302.9,152.1,0.5,0.5);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.informacion,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        
this.instance = new lib.popup_info2();
	this.instance.setTransform(475,304,1,1,0,0,0,475,304);

     
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.informacion,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,666,331);

   (lib._1_shutterstock_86729548 = function() {
	this.initialize(img._1_shutterstock_86729548);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,776,750);


(lib._2_shutterstock_50930257 = function() {
	this.initialize(img._2_shutterstock_50930257);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,957,750);


(lib._3_shutterstock_55394590 = function() {
	this.initialize(img._3_shutterstock_55394590);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1181,750);


(lib._7_86508090 = function() {
	this.initialize(img._7_86508090);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1125,750);


(lib._8_92009525 = function() {
	this.initialize(img._8_92009525);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,750);


(lib.Elecciones = function() {
	this.initialize(img.Elecciones);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1085,729);


(lib.Excel1 = function() {
	this.initialize(img.Excel1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,907,599);


(lib.Excel2 = function() {
	this.initialize(img.Excel2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,923,691);


(lib.Excel3 = function() {
	this.initialize(img.Excel3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,963,632);


(lib.Excel4 = function() {
	this.initialize(img.Excel4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,678,750);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.mc_loader_barra = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#FFFFFF"],[0.894,1],21.4,17.1,-2.9,-25.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape.setTransform(9,27.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],21.5,16.9,-3.1,-24.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_1.setTransform(9,27.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],21.5,16.7,-3.3,-24.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_2.setTransform(9,27.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],21.6,16.4,-3.4,-24.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_3.setTransform(9,27.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],21.7,16.2,-3.6,-24.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_4.setTransform(9,27.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],21.8,15.9,-3.7,-24.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_5.setTransform(9,27.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],21.9,15.7,-3.9,-24).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_6.setTransform(9,27.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],21.9,15.4,-4.1,-23.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_7.setTransform(9,27.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],22.1,15.2,-4.2,-23.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_8.setTransform(9,27.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],22.1,14.9,-4.4,-23.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_9.setTransform(9,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],22.2,14.7,-4.5,-23.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_10.setTransform(9,27.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],22.3,14.5,-4.7,-23.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_11.setTransform(9,27.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],22.4,14.2,-4.8,-22.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_12.setTransform(9,27.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],22.5,13.9,-5,-22.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_13.setTransform(9,27.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],22.5,13.7,-5.2,-22.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_14.setTransform(9,27.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],22.6,13.5,-5.4,-22.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_15.setTransform(9,27.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],22.7,13.2,-5.5,-22.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_16.setTransform(9,27.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],22.8,12.9,-5.7,-22.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_17.setTransform(9,27.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],22.9,12.7,-5.8,-21.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_18.setTransform(9,27.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],23,12.5,-6,-21.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_19.setTransform(9,27.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],23.1,12.2,-6.1,-21.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_20.setTransform(9,27.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],23.2,11.9,-6.3,-21.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_21.setTransform(9,27.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],23.2,11.7,-6.5,-21.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_22.setTransform(9,27.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],23.3,11.5,-6.6,-21).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_23.setTransform(9,27.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],23.4,11.2,-6.8,-20.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_24.setTransform(9,27.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],23.5,10.9,-6.9,-20.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_25.setTransform(9,27.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],23.6,10.7,-7.1,-20.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_26.setTransform(9,27.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],23.6,10.5,-7.3,-20.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_27.setTransform(9,27.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],23.8,10.2,-7.4,-20.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_28.setTransform(9,27.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],23.8,10,-7.6,-19.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_29.setTransform(9,27.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],23.9,9.7,-7.7,-19.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_30.setTransform(9,27.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],24,9.5,-7.9,-19.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_31.setTransform(9,27.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],24.1,9.2,-8,-19.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_32.setTransform(9,27.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],24.2,9,-8.2,-19.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_33.setTransform(9,27.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],24.2,8.7,-8.4,-19.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_34.setTransform(9,27.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],24.3,8.5,-8.5,-18.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_35.setTransform(9,27.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],24.4,8.3,-8.7,-18.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_36.setTransform(9,27.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],24.5,8,-8.8,-18.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_37.setTransform(9,27.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],24.6,7.7,-9,-18.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_38.setTransform(9,27.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],24.7,7.5,-9.2,-18.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_39.setTransform(9,27.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],24.8,7.3,-9.3,-18).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_40.setTransform(9,27.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],24.8,7,-9.5,-17.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_41.setTransform(9,27.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],24.9,6.7,-9.7,-17.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_42.setTransform(9,27.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],25,6.5,-9.8,-17.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_43.setTransform(9,27.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],25.1,6.3,-9.9,-17.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_44.setTransform(9,27.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],25.2,6,-10.1,-17.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_45.setTransform(9,27.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],25.3,5.8,-10.3,-17).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_46.setTransform(9,27.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],25.3,5.5,-10.5,-16.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_47.setTransform(9,27.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],25.4,5.3,-10.6,-16.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_48.setTransform(9,27.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],25.5,5,-10.8,-16.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_49.setTransform(9,27.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],25.6,4.8,-10.9,-16.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_50.setTransform(9,27.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],25.7,4.5,-11.1,-16.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_51.setTransform(9,27.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],25.8,4.3,-11.2,-15.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_52.setTransform(9,27.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],25.9,4,-11.4,-15.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_53.setTransform(9,27.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],25.9,3.8,-11.6,-15.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_54.setTransform(9,27.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],26,3.5,-11.7,-15.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_55.setTransform(9,27.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],26.1,3.3,-11.9,-15.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_56.setTransform(9,27.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],26.2,3,-12,-15.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_57.setTransform(9,27.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],26.3,2.8,-12.2,-14.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_58.setTransform(9,27.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],26.3,2.6,-12.4,-14.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_59.setTransform(9,27.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],26.5,2.3,-12.5,-14.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_60.setTransform(9,27.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],26.5,2.1,-12.7,-14.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_61.setTransform(9,27.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],26.6,1.8,-12.8,-14.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_62.setTransform(9,27.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],26.7,1.6,-13,-14).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_63.setTransform(9,27.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],26.8,1.3,-13.1,-13.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_64.setTransform(9,27.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],26.9,1.1,-13.3,-13.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_65.setTransform(9,27.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],26.9,0.8,-13.5,-13.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_66.setTransform(9,27.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],27,0.6,-13.7,-13.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_67.setTransform(9,27.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],27.1,0.3,-13.8,-13.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_68.setTransform(9,27.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],27.2,0.1,-14,-12.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_69.setTransform(9,27.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],27.3,-0.1,-14.1,-12.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_70.setTransform(9,27.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],27.4,-0.3,-14.3,-12.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_71.setTransform(9,27.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],27.5,-0.5,-14.4,-12.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_72.setTransform(9,27.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],27.6,-0.8,-14.6,-12.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_73.setTransform(9,27.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],27.6,-1.1,-14.8,-12.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_74.setTransform(9,27.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],27.7,-1.3,-14.9,-11.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_75.setTransform(9,27.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],27.8,-1.5,-15.1,-11.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_76.setTransform(9,27.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],27.9,-1.8,-15.2,-11.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_77.setTransform(9,27.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],28,-2.1,-15.4,-11.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_78.setTransform(9,27.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],28,-2.3,-15.6,-11.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_79.setTransform(9,27.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],28.2,-2.5,-15.7,-11).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_80.setTransform(9,27.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],28.2,-2.8,-15.9,-10.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_81.setTransform(9,27.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],28.3,-3.1,-16,-10.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_82.setTransform(9,27.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],28.4,-3.3,-16.2,-10.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_83.setTransform(9,27.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],28.5,-3.5,-16.3,-10.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_84.setTransform(9,27.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],28.6,-3.8,-16.5,-10.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_85.setTransform(9,27.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],28.6,-4,-16.7,-9.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_86.setTransform(9,27.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],28.7,-4.3,-16.8,-9.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_87.setTransform(9,27.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],28.8,-4.5,-17,-9.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_88.setTransform(9,27.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],28.9,-4.8,-17.1,-9.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_89.setTransform(9,27.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],29,-5,-17.3,-9.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_90.setTransform(9,27.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],29.1,-5.3,-17.5,-9.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_91.setTransform(9,27.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],29.2,-5.5,-17.6,-8.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_92.setTransform(9,27.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],29.2,-5.7,-17.8,-8.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_93.setTransform(9,27.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],29.3,-6,-18,-8.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_94.setTransform(9,27.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],29.4,-6.3,-18.1,-8.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_95.setTransform(9,27.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],29.5,-6.5,-18.2,-8.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_96.setTransform(9,27.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],29.6,-6.7,-18.4,-8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_97.setTransform(9,27.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],29.7,-7,-18.6,-7.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_98.setTransform(9,27.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],29.7,-7.3,-18.8,-7.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_99.setTransform(9,27.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#000000","#FFFFFF"],[0,0.592],29.8,-7.5,-18.9,-7.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_100.setTransform(9,27.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).wait(101));

	// Capa 2
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["#000000","#FFFFFF"],[0.894,1],-21.2,-17,3.1,25.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_101.setTransform(18.2,18.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],-21.3,-16.8,3.3,25).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_102.setTransform(18.2,18.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],-21.4,-16.5,3.4,24.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_103.setTransform(18.2,18.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],-21.4,-16.2,3.6,24.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_104.setTransform(18.2,18.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],-21.6,-16,3.7,24.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_105.setTransform(18.2,18.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],-21.6,-15.8,3.9,24.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_106.setTransform(18.2,18.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],-21.7,-15.5,4.1,24.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_107.setTransform(18.2,18.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],-21.8,-15.2,4.2,24).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_108.setTransform(18.2,18.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],-21.9,-15,4.4,23.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_109.setTransform(18.2,18.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],-22,-14.8,4.5,23.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_110.setTransform(18.2,18.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],-22,-14.5,4.7,23.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_111.setTransform(18.2,18.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],-22.1,-14.3,4.9,23.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_112.setTransform(18.2,18.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],-22.2,-14,5,23.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_113.setTransform(18.2,18.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],-22.3,-13.8,5.2,22.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_114.setTransform(18.2,18.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],-22.4,-13.5,5.3,22.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_115.setTransform(18.2,18.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],-22.5,-13.3,5.5,22.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_116.setTransform(18.2,18.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],-22.6,-13,5.6,22.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_117.setTransform(18.2,18.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],-22.7,-12.8,5.8,22.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_118.setTransform(18.2,18.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],-22.7,-12.6,6,22).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_119.setTransform(18.2,18.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],-22.8,-12.3,6.2,21.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_120.setTransform(18.2,18.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],-22.9,-12,6.3,21.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_121.setTransform(18.2,18.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],-23,-11.8,6.5,21.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_122.setTransform(18.2,18.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],-23.1,-11.6,6.6,21.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_123.setTransform(18.2,18.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],-23.1,-11.3,6.8,21.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_124.setTransform(18.2,18.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],-23.3,-11,6.9,21).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_125.setTransform(18.2,18.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],-23.3,-10.8,7.1,20.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_126.setTransform(18.2,18.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],-23.4,-10.6,7.3,20.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_127.setTransform(18.2,18.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],-23.5,-10.3,7.4,20.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_128.setTransform(18.2,18.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],-23.6,-10,7.6,20.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_129.setTransform(18.2,18.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],-23.7,-9.8,7.7,20.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_130.setTransform(18.2,18.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],-23.7,-9.6,7.9,19.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_131.setTransform(18.2,18.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],-23.8,-9.3,8.1,19.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_132.setTransform(18.2,18.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],-23.9,-9.1,8.2,19.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_133.setTransform(18.2,18.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],-24,-8.8,8.4,19.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_134.setTransform(18.2,18.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],-24.1,-8.6,8.5,19.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_135.setTransform(18.2,18.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],-24.1,-8.3,8.7,19.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_136.setTransform(18.2,18.2);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],-24.3,-8.1,8.8,18.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_137.setTransform(18.2,18.2);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],-24.3,-7.8,9,18.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_138.setTransform(18.2,18.2);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],-24.4,-7.6,9.2,18.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_139.setTransform(18.2,18.2);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],-24.5,-7.3,9.4,18.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_140.setTransform(18.2,18.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],-24.6,-7.1,9.5,18.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_141.setTransform(18.2,18.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],-24.7,-6.8,9.6,18).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_142.setTransform(18.2,18.2);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],-24.8,-6.6,9.8,17.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_143.setTransform(18.2,18.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],-24.8,-6.4,10,17.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_144.setTransform(18.2,18.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],-24.9,-6.1,10.1,17.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_145.setTransform(18.2,18.2);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],-25,-5.9,10.3,17.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_146.setTransform(18.2,18.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],-25.1,-5.6,10.5,17.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_147.setTransform(18.2,18.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],-25.2,-5.4,10.6,16.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_148.setTransform(18.2,18.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],-25.3,-5.1,10.7,16.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_149.setTransform(18.2,18.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],-25.4,-4.9,10.9,16.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_150.setTransform(18.2,18.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],-25.4,-4.6,11.1,16.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_151.setTransform(18.2,18.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],-25.5,-4.4,11.3,16.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_152.setTransform(18.2,18.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],-25.6,-4.1,11.4,16.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_153.setTransform(18.2,18.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],-25.7,-3.9,11.6,15.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_154.setTransform(18.2,18.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],-25.8,-3.6,11.7,15.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_155.setTransform(18.2,18.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],-25.8,-3.4,11.9,15.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_156.setTransform(18.2,18.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],-26,-3.1,12,15.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_157.setTransform(18.2,18.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],-26,-2.9,12.2,15.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_158.setTransform(18.2,18.2);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],-26.1,-2.7,12.4,15).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_159.setTransform(18.2,18.2);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],-26.2,-2.4,12.5,14.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_160.setTransform(18.2,18.2);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],-26.3,-2.1,12.7,14.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_161.setTransform(18.2,18.2);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],-26.4,-1.9,12.8,14.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_162.setTransform(18.2,18.2);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],-26.4,-1.7,13,14.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_163.setTransform(18.2,18.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],-26.5,-1.4,13.2,14.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_164.setTransform(18.2,18.2);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],-26.6,-1.1,13.3,14).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_165.setTransform(18.2,18.2);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],-26.7,-0.9,13.5,13.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_166.setTransform(18.2,18.2);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],-26.8,-0.7,13.6,13.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_167.setTransform(18.2,18.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],-26.9,-0.4,13.8,13.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_168.setTransform(18.2,18.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],-27,-0.2,13.9,13.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_169.setTransform(18.2,18.2);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],-27.1,0,14.1,13.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_170.setTransform(18.2,18.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],-27.1,0.2,14.3,12.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_171.setTransform(18.2,18.2);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],-27.2,0.5,14.5,12.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_172.setTransform(18.2,18.2);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],-27.3,0.7,14.6,12.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_173.setTransform(18.2,18.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],-27.4,1,14.8,12.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_174.setTransform(18.2,18.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],-27.5,1.2,14.9,12.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_175.setTransform(18.2,18.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],-27.5,1.5,15.1,12.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_176.setTransform(18.2,18.2);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],-27.7,1.7,15.2,11.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_177.setTransform(18.2,18.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],-27.7,2,15.4,11.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_178.setTransform(18.2,18.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],-27.8,2.2,15.6,11.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_179.setTransform(18.2,18.2);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],-27.9,2.4,15.7,11.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_180.setTransform(18.2,18.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],-28,2.7,15.9,11.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_181.setTransform(18.2,18.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],-28.1,3,16,11).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_182.setTransform(18.2,18.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],-28.1,3.2,16.2,10.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_183.setTransform(18.2,18.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],-28.2,3.4,16.4,10.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_184.setTransform(18.2,18.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],-28.3,3.7,16.5,10.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_185.setTransform(18.2,18.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],-28.4,4,16.7,10.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_186.setTransform(18.2,18.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],-28.5,4.2,16.8,10.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_187.setTransform(18.2,18.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],-28.5,4.4,17,9.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_188.setTransform(18.2,18.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],-28.7,4.7,17.1,9.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_189.setTransform(18.2,18.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],-28.7,5,17.3,9.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_190.setTransform(18.2,18.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],-28.8,5.2,17.5,9.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_191.setTransform(18.2,18.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],-28.9,5.4,17.7,9.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_192.setTransform(18.2,18.2);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],-29,5.7,17.8,9.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_193.setTransform(18.2,18.2);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],-29.1,5.9,17.9,8.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_194.setTransform(18.2,18.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],-29.2,6.2,18.1,8.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_195.setTransform(18.2,18.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],-29.2,6.4,18.3,8.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_196.setTransform(18.2,18.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],-29.3,6.7,18.4,8.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_197.setTransform(18.2,18.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],-29.4,6.9,18.6,8.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_198.setTransform(18.2,18.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],-29.5,7.2,18.8,8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_199.setTransform(18.2,18.2);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],-29.6,7.4,18.9,7.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_200.setTransform(18.2,18.2);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.lf(["#000000","#FFFFFF"],[0,0.592],-29.7,7.7,19,7.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_201.setTransform(18.2,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101}]}).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[]},1).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,0,45.7,45.6);


(lib.fnd_loader = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhKNAu4MAAAhdvMCUbAAAMAAABdvg");
	this.shape.setTransform(475,304.1,1,1.014);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608.1);


(lib.Grupodeclips0_10 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNChIAAlCIGbAAIAAFCg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_9 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNChIAAlCIGbAAIAAFCg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_8 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNCiIAAlDIGbAAIAAFDg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_7 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkNChIAAlCIIbAAIAAFCg");
	mask.setTransform(27,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_6 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNChIAAlCIGbAAIAAFCg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_5 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkNChIAAlCIIbAAIAAFCg");
	mask.setTransform(27,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_4 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNChIAAlCIGbAAIAAFCg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_3 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNCiIAAlDIGbAAIAAFDg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_2 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNChIAAlCIGbAAIAAFCg");
	mask.setTransform(20.7,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0_1 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkNChIAAlCIIbAAIAAFCg");
	mask.setTransform(27,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Grupodeclips0 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkNCiIAAlDIIbAAIAAFDg");
	mask.setTransform(27,16.2);

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt_solution_01
	
	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A+4KPIAAkPMA9xAAAIAAEPg");
	var mask_graphics_1 = new cjs.Graphics().p("A+4CQIAAkfMA9xAAAIAAEfg");
	var mask_graphics_2 = new cjs.Graphics().p("A+4CZIAAkxMA9xAAAIAAExg");
	var mask_graphics_3 = new cjs.Graphics().p("A+4CiIAAlDMA9xAAAIAAFDg");
	var mask_graphics_4 = new cjs.Graphics().p("A+4CrIAAlVMA9xAAAIAAFVg");
	var mask_graphics_5 = new cjs.Graphics().p("A+4C0IAAlnMA9xAAAIAAFng");
	var mask_graphics_6 = new cjs.Graphics().p("A+4C9IAAl5MA9xAAAIAAF5g");
	var mask_graphics_7 = new cjs.Graphics().p("A+4DGIAAmLMA9xAAAIAAGLg");
	var mask_graphics_8 = new cjs.Graphics().p("A+4DQIAAmfMA9xAAAIAAGfg");
	var mask_graphics_9 = new cjs.Graphics().p("A+4DZIAAmxMA9xAAAIAAGxg");
	var mask_graphics_10 = new cjs.Graphics().p("A+4DiIAAnDMA9xAAAIAAHDg");
	var mask_graphics_11 = new cjs.Graphics().p("A+4DrIAAnVMA9xAAAIAAHVg");
	var mask_graphics_12 = new cjs.Graphics().p("A+4D0IAAnnMA9xAAAIAAHng");
	var mask_graphics_13 = new cjs.Graphics().p("A+4D9IAAn5MA9xAAAIAAH5g");
	var mask_graphics_14 = new cjs.Graphics().p("A+4EGIAAoLMA9xAAAIAAILg");
	var mask_graphics_15 = new cjs.Graphics().p("A+4EPIAAodMA9xAAAIAAIdg");
	var mask_graphics_16 = new cjs.Graphics().p("A+4EYIAAovMA9xAAAIAAIvg");
	var mask_graphics_17 = new cjs.Graphics().p("A+4EhIAApBMA9xAAAIAAJBg");
	var mask_graphics_18 = new cjs.Graphics().p("A+4ErIAApVMA9xAAAIAAJVg");
	var mask_graphics_19 = new cjs.Graphics().p("A+4E0IAApnMA9xAAAIAAJng");
	var mask_graphics_20 = new cjs.Graphics().p("A+4E9IAAp5MA9xAAAIAAJ5g");
	var mask_graphics_21 = new cjs.Graphics().p("A+4FGIAAqLMA9xAAAIAAKLg");
	var mask_graphics_22 = new cjs.Graphics().p("A+4FPIAAqdMA9xAAAIAAKdg");
	var mask_graphics_23 = new cjs.Graphics().p("A+4FYIAAqvMA9xAAAIAAKvg");
	var mask_graphics_24 = new cjs.Graphics().p("A+4FhIAArBMA9xAAAIAALBg");
	var mask_graphics_25 = new cjs.Graphics().p("A+4FqIAArTMA9xAAAIAALTg");
	var mask_graphics_26 = new cjs.Graphics().p("A+4FzIAArlMA9xAAAIAALlg");
	var mask_graphics_27 = new cjs.Graphics().p("A+4F8IAAr3MA9xAAAIAAL3g");
	var mask_graphics_28 = new cjs.Graphics().p("A+4GGIAAsLMA9xAAAIAAMLg");
	var mask_graphics_29 = new cjs.Graphics().p("A+4GPIAAsdMA9xAAAIAAMdg");
	var mask_graphics_30 = new cjs.Graphics().p("A+4GYIAAsvMA9xAAAIAAMvg");
	var mask_graphics_31 = new cjs.Graphics().p("A+4GhIAAtBMA9xAAAIAANBg");
	var mask_graphics_32 = new cjs.Graphics().p("A+4GqIAAtTMA9xAAAIAANTg");
	var mask_graphics_33 = new cjs.Graphics().p("A+4GzIAAtlMA9xAAAIAANlg");
	var mask_graphics_34 = new cjs.Graphics().p("A+4G8IAAt3MA9xAAAIAAN3g");
	var mask_graphics_35 = new cjs.Graphics().p("A+4HFIAAuJMA9xAAAIAAOJg");
	var mask_graphics_36 = new cjs.Graphics().p("A+4HOIAAubMA9xAAAIAAObg");
	var mask_graphics_37 = new cjs.Graphics().p("A+4HXIAAutMA9xAAAIAAOtg");
	var mask_graphics_38 = new cjs.Graphics().p("A+4HhIAAvBMA9xAAAIAAPBg");
	var mask_graphics_39 = new cjs.Graphics().p("A+4HqIAAvTMA9xAAAIAAPTg");
	var mask_graphics_40 = new cjs.Graphics().p("A+4HzIAAvlMA9xAAAIAAPlg");
	var mask_graphics_41 = new cjs.Graphics().p("A+4H8IAAv3MA9xAAAIAAP3g");
	var mask_graphics_42 = new cjs.Graphics().p("A+4IFIAAwJMA9xAAAIAAQJg");
	var mask_graphics_43 = new cjs.Graphics().p("A+4IOIAAwbMA9xAAAIAAQbg");
	var mask_graphics_44 = new cjs.Graphics().p("A+4IXIAAwtMA9xAAAIAAQtg");
	var mask_graphics_45 = new cjs.Graphics().p("A+4IgIAAw/MA9xAAAIAAQ/g");
	var mask_graphics_46 = new cjs.Graphics().p("A+4IpIAAxRMA9xAAAIAARRg");
	var mask_graphics_47 = new cjs.Graphics().p("A+4IyIAAxjMA9xAAAIAARjg");
	var mask_graphics_48 = new cjs.Graphics().p("A+4I8IAAx3MA9xAAAIAAR3g");
	var mask_graphics_49 = new cjs.Graphics().p("A+4JFIAAyJMA9xAAAIAASJg");
	var mask_graphics_50 = new cjs.Graphics().p("A+4JOIAAybMA9xAAAIAASbg");
	var mask_graphics_51 = new cjs.Graphics().p("A+4JXIAAytMA9xAAAIAAStg");
	var mask_graphics_52 = new cjs.Graphics().p("A+4JgIAAy/MA9xAAAIAAS/g");
	var mask_graphics_53 = new cjs.Graphics().p("A+4JpIAAzRMA9xAAAIAATRg");
	var mask_graphics_54 = new cjs.Graphics().p("A+4JyIAAzjMA9xAAAIAATjg");
	var mask_graphics_55 = new cjs.Graphics().p("A+4J7IAAz1MA9xAAAIAAT1g");
	var mask_graphics_56 = new cjs.Graphics().p("A+4KEIAA0HMA9xAAAIAAUHg");
	var mask_graphics_57 = new cjs.Graphics().p("A+4KNIAA0ZMA9xAAAIAAUZg");
	var mask_graphics_58 = new cjs.Graphics().p("A+4KXIAA0tMA9xAAAIAAUtg");
	var mask_graphics_59 = new cjs.Graphics().p("A+4KgIAA0/MA9xAAAIAAU/g");
	var mask_graphics_60 = new cjs.Graphics().p("A+4KpIAA1RMA9xAAAIAAVRg");
	var mask_graphics_61 = new cjs.Graphics().p("A+4KyIAA1jMA9xAAAIAAVjg");
	var mask_graphics_62 = new cjs.Graphics().p("A+4K7IAA11MA9xAAAIAAV1g");
	var mask_graphics_63 = new cjs.Graphics().p("A+4LEIAA2HMA9xAAAIAAWHg");
	var mask_graphics_64 = new cjs.Graphics().p("A+4LNIAA2ZMA9xAAAIAAWZg");
	var mask_graphics_65 = new cjs.Graphics().p("A+4LWIAA2rMA9xAAAIAAWrg");
	var mask_graphics_66 = new cjs.Graphics().p("A+4LfIAA29MA9xAAAIAAW9g");
	var mask_graphics_67 = new cjs.Graphics().p("A+4LoIAA3PMA9xAAAIAAXPg");
	var mask_graphics_68 = new cjs.Graphics().p("A+4LyIAA3jMA9xAAAIAAXjg");
	var mask_graphics_69 = new cjs.Graphics().p("A+4L7IAA31MA9xAAAIAAX1g");
	var mask_graphics_70 = new cjs.Graphics().p("A+4MEIAA4HMA9xAAAIAAYHg");
	var mask_graphics_71 = new cjs.Graphics().p("A+4MNIAA4ZMA9xAAAIAAYZg");
	var mask_graphics_72 = new cjs.Graphics().p("A+4MWIAA4rMA9xAAAIAAYrg");
	var mask_graphics_73 = new cjs.Graphics().p("A+4MfIAA49MA9xAAAIAAY9g");
	var mask_graphics_74 = new cjs.Graphics().p("A+4MoIAA5PMA9xAAAIAAZPg");
	var mask_graphics_75 = new cjs.Graphics().p("A+4MxIAA5hMA9xAAAIAAZhg");
	var mask_graphics_76 = new cjs.Graphics().p("A+4M6IAA5zMA9xAAAIAAZzg");
	var mask_graphics_77 = new cjs.Graphics().p("A+4NDIAA6FMA9xAAAIAAaFg");
	var mask_graphics_78 = new cjs.Graphics().p("A+4NNIAA6ZMA9xAAAIAAaZg");
	var mask_graphics_79 = new cjs.Graphics().p("A+4NWIAA6rMA9xAAAIAAarg");
	var mask_graphics_80 = new cjs.Graphics().p("A+4NfIAA69MA9xAAAIAAa9g");
	var mask_graphics_81 = new cjs.Graphics().p("A+4NoIAA7PMA9xAAAIAAbPg");
	var mask_graphics_82 = new cjs.Graphics().p("A+4NxIAA7hMA9xAAAIAAbhg");
	var mask_graphics_83 = new cjs.Graphics().p("A+4N6IAA7zMA9xAAAIAAbzg");
	var mask_graphics_84 = new cjs.Graphics().p("A+4ODIAA8FMA9xAAAIAAcFg");
	var mask_graphics_85 = new cjs.Graphics().p("A+4OMIAA8XMA9xAAAIAAcXg");
	var mask_graphics_86 = new cjs.Graphics().p("A+4OVIAA8pMA9xAAAIAAcpg");
	var mask_graphics_87 = new cjs.Graphics().p("A+4OeIAA87MA9xAAAIAAc7g");
	var mask_graphics_88 = new cjs.Graphics().p("A+4OoIAA9PMA9xAAAIAAdPg");
	var mask_graphics_89 = new cjs.Graphics().p("A+4OxIAA9hMA9xAAAIAAdhg");
	var mask_graphics_90 = new cjs.Graphics().p("A+4O6IAA9zMA9xAAAIAAdzg");
	var mask_graphics_91 = new cjs.Graphics().p("A+4PDIAA+FMA9xAAAIAAeFg");
	var mask_graphics_92 = new cjs.Graphics().p("A+4PMIAA+XMA9xAAAIAAeXg");
	var mask_graphics_93 = new cjs.Graphics().p("A+4PVIAA+pMA9xAAAIAAepg");
	var mask_graphics_94 = new cjs.Graphics().p("A+4PeIAA+7MA9xAAAIAAe7g");
	var mask_graphics_95 = new cjs.Graphics().p("A+4PnIAA/NMA9xAAAIAAfNg");
	var mask_graphics_96 = new cjs.Graphics().p("A+4PwIAA/fMA9xAAAIAAffg");
	var mask_graphics_97 = new cjs.Graphics().p("A+4P6IAA/yMA9xAAAIAAfyg");
	var mask_graphics_98 = new cjs.Graphics().p("A+4QDMAAAggFMA9xAAAMAAAAgFg");
	var mask_graphics_99 = new cjs.Graphics().p("A+4QMMAAAggXMA9xAAAMAAAAgXg");
	var mask_graphics_100 = new cjs.Graphics().p("A+4QVMAAAggpMA9xAAAMAAAAgpg");
	var mask_graphics_101 = new cjs.Graphics().p("A+4QeMAAAgg7MA9xAAAMAAAAg7g");
	var mask_graphics_102 = new cjs.Graphics().p("A+4QnMAAAghNMA9xAAAMAAAAhNg");
	var mask_graphics_103 = new cjs.Graphics().p("A+4QwMAAAghfMA9xAAAMAAAAhfg");
	var mask_graphics_104 = new cjs.Graphics().p("A+4Q5MAAAghxMA9xAAAMAAAAhxg");
	var mask_graphics_105 = new cjs.Graphics().p("A+4RCMAAAgiDMA9xAAAMAAAAiDg");
	var mask_graphics_106 = new cjs.Graphics().p("A+4RLMAAAgiVMA9xAAAMAAAAiVg");
	var mask_graphics_107 = new cjs.Graphics().p("A+4RVMAAAgipMA9xAAAMAAAAipg");
	var mask_graphics_108 = new cjs.Graphics().p("A+4ReMAAAgi7MA9xAAAMAAAAi7g");
	var mask_graphics_109 = new cjs.Graphics().p("A+4RnMAAAgjNMA9xAAAMAAAAjNg");
	var mask_graphics_110 = new cjs.Graphics().p("A+4RwMAAAgjfMA9xAAAMAAAAjfg");
	var mask_graphics_111 = new cjs.Graphics().p("A+4R5MAAAgjxMA9xAAAMAAAAjxg");
	var mask_graphics_112 = new cjs.Graphics().p("A+4SCMAAAgkDMA9xAAAMAAAAkDg");
	var mask_graphics_113 = new cjs.Graphics().p("A+4SLMAAAgkVMA9xAAAMAAAAkVg");
	var mask_graphics_114 = new cjs.Graphics().p("A+4SUMAAAgknMA9xAAAMAAAAkng");
	var mask_graphics_115 = new cjs.Graphics().p("A+4SdMAAAgk5MA9xAAAMAAAAk5g");
	var mask_graphics_116 = new cjs.Graphics().p("A+4SmMAAAglLMA9xAAAMAAAAlLg");
	var mask_graphics_117 = new cjs.Graphics().p("A+4SwMAAAglfMA9xAAAMAAAAlfg");
	var mask_graphics_118 = new cjs.Graphics().p("A+4S5MAAAglxMA9xAAAMAAAAlxg");
	var mask_graphics_119 = new cjs.Graphics().p("A+4TCMAAAgmDMA9xAAAMAAAAmDg");
	var mask_graphics_120 = new cjs.Graphics().p("A+4TLMAAAgmVMA9xAAAMAAAAmVg");
	var mask_graphics_121 = new cjs.Graphics().p("A+4TUMAAAgmnMA9xAAAMAAAAmng");
	var mask_graphics_122 = new cjs.Graphics().p("A+4TdMAAAgm5MA9xAAAMAAAAm5g");
	var mask_graphics_123 = new cjs.Graphics().p("A+4TmMAAAgnLMA9xAAAMAAAAnLg");
	var mask_graphics_124 = new cjs.Graphics().p("A+4TvMAAAgndMA9xAAAMAAAAndg");
	var mask_graphics_125 = new cjs.Graphics().p("A+4T4MAAAgnvMA9xAAAMAAAAnvg");
	var mask_graphics_126 = new cjs.Graphics().p("A+4UBMAAAgoBMA9xAAAMAAAAoBg");
	var mask_graphics_127 = new cjs.Graphics().p("A+4ULMAAAgoVMA9xAAAMAAAAoVg");
	var mask_graphics_128 = new cjs.Graphics().p("A+4UUMAAAgonMA9xAAAMAAAAong");
	var mask_graphics_129 = new cjs.Graphics().p("A+4UdMAAAgo5MA9xAAAMAAAAo5g");
	var mask_graphics_130 = new cjs.Graphics().p("A+4UmMAAAgpLMA9xAAAMAAAApLg");
	var mask_graphics_131 = new cjs.Graphics().p("A+4UvMAAAgpdMA9xAAAMAAAApdg");
	var mask_graphics_132 = new cjs.Graphics().p("A+4U4MAAAgpvMA9xAAAMAAAApvg");
	var mask_graphics_133 = new cjs.Graphics().p("A+4VBMAAAgqBMA9xAAAMAAAAqBg");
	var mask_graphics_134 = new cjs.Graphics().p("A+4VKMAAAgqTMA9xAAAMAAAAqTg");
	var mask_graphics_135 = new cjs.Graphics().p("A+4VTMAAAgqlMA9xAAAMAAAAqlg");
	var mask_graphics_136 = new cjs.Graphics().p("A+4VcMAAAgq3MA9xAAAMAAAAq3g");
	var mask_graphics_137 = new cjs.Graphics().p("A+4VmMAAAgrLMA9xAAAMAAAArLg");
	var mask_graphics_138 = new cjs.Graphics().p("A+4VvMAAAgrdMA9xAAAMAAAArdg");
	var mask_graphics_139 = new cjs.Graphics().p("A+4V4MAAAgrvMA9xAAAMAAAArvg");
	var mask_graphics_140 = new cjs.Graphics().p("A+4WBMAAAgsBMA9xAAAMAAAAsBg");
	var mask_graphics_141 = new cjs.Graphics().p("A+4WKMAAAgsTMA9xAAAMAAAAsTg");
	var mask_graphics_142 = new cjs.Graphics().p("A+4WTMAAAgslMA9xAAAMAAAAslg");
	var mask_graphics_143 = new cjs.Graphics().p("A+4WcMAAAgs3MA9xAAAMAAAAs3g");
	var mask_graphics_144 = new cjs.Graphics().p("A+4WlMAAAgtJMA9xAAAMAAAAtJg");
	var mask_graphics_145 = new cjs.Graphics().p("A+4WuMAAAgtbMA9xAAAMAAAAtbg");
	var mask_graphics_146 = new cjs.Graphics().p("A+4W3MAAAgttMA9xAAAMAAAAttg");
	var mask_graphics_147 = new cjs.Graphics().p("A+4XBMAAAguBMA9xAAAMAAAAuBg");
	var mask_graphics_148 = new cjs.Graphics().p("A+4XKMAAAguTMA9xAAAMAAAAuTg");
	var mask_graphics_149 = new cjs.Graphics().p("A+4XTMAAAgulMA9xAAAMAAAAulg");
	var mask_graphics_150 = new cjs.Graphics().p("A+4XcMAAAgu3MA9xAAAMAAAAu3g");
	var mask_graphics_151 = new cjs.Graphics().p("A+4XlMAAAgvJMA9xAAAMAAAAvJg");
	var mask_graphics_152 = new cjs.Graphics().p("A+4XuMAAAgvbMA9xAAAMAAAAvbg");
	var mask_graphics_153 = new cjs.Graphics().p("A+4X3MAAAgvtMA9xAAAMAAAAvtg");
	var mask_graphics_154 = new cjs.Graphics().p("A+4YAMAAAgv/MA9xAAAMAAAAv/g");
	var mask_graphics_155 = new cjs.Graphics().p("A+4YJMAAAgwRMA9xAAAMAAAAwRg");
	var mask_graphics_156 = new cjs.Graphics().p("A+4YSMAAAgwjMA9xAAAMAAAAwjg");
	var mask_graphics_157 = new cjs.Graphics().p("A+4YcMAAAgw3MA9xAAAMAAAAw3g");
	var mask_graphics_158 = new cjs.Graphics().p("A+4YlMAAAgxJMA9xAAAMAAAAxJg");
	var mask_graphics_159 = new cjs.Graphics().p("A+4YuMAAAgxbMA9xAAAMAAAAxbg");
	var mask_graphics_160 = new cjs.Graphics().p("A+4Y3MAAAgxtMA9xAAAMAAAAxtg");
	var mask_graphics_161 = new cjs.Graphics().p("A+4ZAMAAAgx/MA9xAAAMAAAAx/g");
	var mask_graphics_162 = new cjs.Graphics().p("A+4ZJMAAAgyRMA9xAAAMAAAAyRg");
	var mask_graphics_163 = new cjs.Graphics().p("A+4ZSMAAAgyjMA9xAAAMAAAAyjg");
	var mask_graphics_164 = new cjs.Graphics().p("A+4ZbMAAAgy1MA9xAAAMAAAAy1g");
	var mask_graphics_165 = new cjs.Graphics().p("A+4ZkMAAAgzHMA9xAAAMAAAAzHg");
	var mask_graphics_166 = new cjs.Graphics().p("A+4ZtMAAAgzZMA9xAAAMAAAAzZg");
	var mask_graphics_167 = new cjs.Graphics().p("A+4Z3MAAAgztMA9xAAAMAAAAztg");
	var mask_graphics_168 = new cjs.Graphics().p("A+4aAMAAAgz/MA9xAAAMAAAAz/g");
	var mask_graphics_169 = new cjs.Graphics().p("A+4aJMAAAg0RMA9xAAAMAAAA0Rg");
	var mask_graphics_170 = new cjs.Graphics().p("A+4aSMAAAg0jMA9xAAAMAAAA0jg");
	var mask_graphics_171 = new cjs.Graphics().p("A+4abMAAAg01MA9xAAAMAAAA01g");
	var mask_graphics_172 = new cjs.Graphics().p("A+4akMAAAg1HMA9xAAAMAAAA1Hg");
	var mask_graphics_173 = new cjs.Graphics().p("A+4atMAAAg1ZMA9xAAAMAAAA1Zg");
	var mask_graphics_174 = new cjs.Graphics().p("A+4a2MAAAg1rMA9xAAAMAAAA1rg");
	var mask_graphics_175 = new cjs.Graphics().p("A+4a/MAAAg19MA9xAAAMAAAA19g");
	var mask_graphics_176 = new cjs.Graphics().p("A+4bIMAAAg2PMA9xAAAMAAAA2Pg");
	var mask_graphics_177 = new cjs.Graphics().p("A+4bSMAAAg2jMA9xAAAMAAAA2jg");
	var mask_graphics_178 = new cjs.Graphics().p("A+4bbMAAAg21MA9xAAAMAAAA21g");
	var mask_graphics_179 = new cjs.Graphics().p("A+4bkMAAAg3HMA9xAAAMAAAA3Hg");
	var mask_graphics_180 = new cjs.Graphics().p("A+4btMAAAg3ZMA9xAAAMAAAA3Zg");
	var mask_graphics_181 = new cjs.Graphics().p("A+4b2MAAAg3rMA9xAAAMAAAA3rg");
	var mask_graphics_182 = new cjs.Graphics().p("A+4b/MAAAg39MA9xAAAMAAAA39g");
	var mask_graphics_183 = new cjs.Graphics().p("A+4cIMAAAg4PMA9xAAAMAAAA4Pg");
	var mask_graphics_184 = new cjs.Graphics().p("A+4cRMAAAg4hMA9xAAAMAAAA4hg");
	var mask_graphics_185 = new cjs.Graphics().p("A+4caMAAAg4zMA9xAAAMAAAA4zg");
	var mask_graphics_186 = new cjs.Graphics().p("A+4cjMAAAg5FMA9xAAAMAAAA5Fg");
	var mask_graphics_187 = new cjs.Graphics().p("A+4ctMAAAg5ZMA9xAAAMAAAA5Zg");
	var mask_graphics_188 = new cjs.Graphics().p("A+4c2MAAAg5rMA9xAAAMAAAA5rg");
	var mask_graphics_189 = new cjs.Graphics().p("Ege4AlHMAAAg59MA9xAAAMAAAA59g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:176.8,y:65.5}).wait(1).to({graphics:mask_graphics_1,x:176.8,y:118.4}).wait(1).to({graphics:mask_graphics_2,x:176.8,y:119.3}).wait(1).to({graphics:mask_graphics_3,x:176.8,y:120.3}).wait(1).to({graphics:mask_graphics_4,x:176.8,y:121.2}).wait(1).to({graphics:mask_graphics_5,x:176.8,y:122.1}).wait(1).to({graphics:mask_graphics_6,x:176.8,y:123}).wait(1).to({graphics:mask_graphics_7,x:176.8,y:123.9}).wait(1).to({graphics:mask_graphics_8,x:176.8,y:124.8}).wait(1).to({graphics:mask_graphics_9,x:176.8,y:125.7}).wait(1).to({graphics:mask_graphics_10,x:176.8,y:126.6}).wait(1).to({graphics:mask_graphics_11,x:176.8,y:127.5}).wait(1).to({graphics:mask_graphics_12,x:176.8,y:128.4}).wait(1).to({graphics:mask_graphics_13,x:176.8,y:129.4}).wait(1).to({graphics:mask_graphics_14,x:176.8,y:130.3}).wait(1).to({graphics:mask_graphics_15,x:176.8,y:131.2}).wait(1).to({graphics:mask_graphics_16,x:176.8,y:132.1}).wait(1).to({graphics:mask_graphics_17,x:176.8,y:133}).wait(1).to({graphics:mask_graphics_18,x:176.8,y:133.9}).wait(1).to({graphics:mask_graphics_19,x:176.8,y:134.8}).wait(1).to({graphics:mask_graphics_20,x:176.8,y:135.7}).wait(1).to({graphics:mask_graphics_21,x:176.8,y:136.6}).wait(1).to({graphics:mask_graphics_22,x:176.8,y:137.5}).wait(1).to({graphics:mask_graphics_23,x:176.8,y:138.5}).wait(1).to({graphics:mask_graphics_24,x:176.8,y:139.4}).wait(1).to({graphics:mask_graphics_25,x:176.8,y:140.3}).wait(1).to({graphics:mask_graphics_26,x:176.8,y:141.2}).wait(1).to({graphics:mask_graphics_27,x:176.8,y:142.1}).wait(1).to({graphics:mask_graphics_28,x:176.8,y:143}).wait(1).to({graphics:mask_graphics_29,x:176.8,y:143.9}).wait(1).to({graphics:mask_graphics_30,x:176.8,y:144.8}).wait(1).to({graphics:mask_graphics_31,x:176.8,y:145.7}).wait(1).to({graphics:mask_graphics_32,x:176.8,y:146.6}).wait(1).to({graphics:mask_graphics_33,x:176.8,y:147.6}).wait(1).to({graphics:mask_graphics_34,x:176.8,y:148.5}).wait(1).to({graphics:mask_graphics_35,x:176.8,y:149.4}).wait(1).to({graphics:mask_graphics_36,x:176.8,y:150.3}).wait(1).to({graphics:mask_graphics_37,x:176.8,y:151.2}).wait(1).to({graphics:mask_graphics_38,x:176.8,y:152.1}).wait(1).to({graphics:mask_graphics_39,x:176.8,y:153}).wait(1).to({graphics:mask_graphics_40,x:176.8,y:153.9}).wait(1).to({graphics:mask_graphics_41,x:176.8,y:154.8}).wait(1).to({graphics:mask_graphics_42,x:176.8,y:155.7}).wait(1).to({graphics:mask_graphics_43,x:176.8,y:156.7}).wait(1).to({graphics:mask_graphics_44,x:176.8,y:157.6}).wait(1).to({graphics:mask_graphics_45,x:176.8,y:158.5}).wait(1).to({graphics:mask_graphics_46,x:176.8,y:159.4}).wait(1).to({graphics:mask_graphics_47,x:176.8,y:160.3}).wait(1).to({graphics:mask_graphics_48,x:176.8,y:161.2}).wait(1).to({graphics:mask_graphics_49,x:176.8,y:162.1}).wait(1).to({graphics:mask_graphics_50,x:176.8,y:163}).wait(1).to({graphics:mask_graphics_51,x:176.8,y:163.9}).wait(1).to({graphics:mask_graphics_52,x:176.8,y:164.8}).wait(1).to({graphics:mask_graphics_53,x:176.8,y:165.8}).wait(1).to({graphics:mask_graphics_54,x:176.8,y:166.7}).wait(1).to({graphics:mask_graphics_55,x:176.8,y:167.6}).wait(1).to({graphics:mask_graphics_56,x:176.8,y:168.5}).wait(1).to({graphics:mask_graphics_57,x:176.8,y:169.4}).wait(1).to({graphics:mask_graphics_58,x:176.8,y:170.3}).wait(1).to({graphics:mask_graphics_59,x:176.8,y:171.2}).wait(1).to({graphics:mask_graphics_60,x:176.8,y:172.1}).wait(1).to({graphics:mask_graphics_61,x:176.8,y:173}).wait(1).to({graphics:mask_graphics_62,x:176.8,y:173.9}).wait(1).to({graphics:mask_graphics_63,x:176.8,y:174.9}).wait(1).to({graphics:mask_graphics_64,x:176.8,y:175.8}).wait(1).to({graphics:mask_graphics_65,x:176.8,y:176.7}).wait(1).to({graphics:mask_graphics_66,x:176.8,y:177.6}).wait(1).to({graphics:mask_graphics_67,x:176.8,y:178.5}).wait(1).to({graphics:mask_graphics_68,x:176.8,y:179.4}).wait(1).to({graphics:mask_graphics_69,x:176.8,y:180.3}).wait(1).to({graphics:mask_graphics_70,x:176.8,y:181.2}).wait(1).to({graphics:mask_graphics_71,x:176.8,y:182.1}).wait(1).to({graphics:mask_graphics_72,x:176.8,y:183}).wait(1).to({graphics:mask_graphics_73,x:176.8,y:184}).wait(1).to({graphics:mask_graphics_74,x:176.8,y:184.9}).wait(1).to({graphics:mask_graphics_75,x:176.8,y:185.8}).wait(1).to({graphics:mask_graphics_76,x:176.8,y:186.7}).wait(1).to({graphics:mask_graphics_77,x:176.8,y:187.6}).wait(1).to({graphics:mask_graphics_78,x:176.8,y:188.5}).wait(1).to({graphics:mask_graphics_79,x:176.8,y:189.4}).wait(1).to({graphics:mask_graphics_80,x:176.8,y:190.3}).wait(1).to({graphics:mask_graphics_81,x:176.8,y:191.2}).wait(1).to({graphics:mask_graphics_82,x:176.8,y:192.1}).wait(1).to({graphics:mask_graphics_83,x:176.8,y:193.1}).wait(1).to({graphics:mask_graphics_84,x:176.8,y:194}).wait(1).to({graphics:mask_graphics_85,x:176.8,y:194.9}).wait(1).to({graphics:mask_graphics_86,x:176.8,y:195.8}).wait(1).to({graphics:mask_graphics_87,x:176.8,y:196.7}).wait(1).to({graphics:mask_graphics_88,x:176.8,y:197.6}).wait(1).to({graphics:mask_graphics_89,x:176.8,y:198.5}).wait(1).to({graphics:mask_graphics_90,x:176.8,y:199.4}).wait(1).to({graphics:mask_graphics_91,x:176.8,y:200.3}).wait(1).to({graphics:mask_graphics_92,x:176.8,y:201.2}).wait(1).to({graphics:mask_graphics_93,x:176.8,y:202.2}).wait(1).to({graphics:mask_graphics_94,x:176.8,y:203.1}).wait(1).to({graphics:mask_graphics_95,x:176.8,y:204}).wait(1).to({graphics:mask_graphics_96,x:176.8,y:204.9}).wait(1).to({graphics:mask_graphics_97,x:176.8,y:205.8}).wait(1).to({graphics:mask_graphics_98,x:176.8,y:206.7}).wait(1).to({graphics:mask_graphics_99,x:176.8,y:207.6}).wait(1).to({graphics:mask_graphics_100,x:176.8,y:208.5}).wait(1).to({graphics:mask_graphics_101,x:176.8,y:209.4}).wait(1).to({graphics:mask_graphics_102,x:176.8,y:210.4}).wait(1).to({graphics:mask_graphics_103,x:176.8,y:211.3}).wait(1).to({graphics:mask_graphics_104,x:176.8,y:212.2}).wait(1).to({graphics:mask_graphics_105,x:176.8,y:213.1}).wait(1).to({graphics:mask_graphics_106,x:176.8,y:214}).wait(1).to({graphics:mask_graphics_107,x:176.8,y:214.9}).wait(1).to({graphics:mask_graphics_108,x:176.8,y:215.8}).wait(1).to({graphics:mask_graphics_109,x:176.8,y:216.7}).wait(1).to({graphics:mask_graphics_110,x:176.8,y:217.6}).wait(1).to({graphics:mask_graphics_111,x:176.8,y:218.5}).wait(1).to({graphics:mask_graphics_112,x:176.8,y:219.5}).wait(1).to({graphics:mask_graphics_113,x:176.8,y:220.4}).wait(1).to({graphics:mask_graphics_114,x:176.8,y:221.3}).wait(1).to({graphics:mask_graphics_115,x:176.8,y:222.2}).wait(1).to({graphics:mask_graphics_116,x:176.8,y:223.1}).wait(1).to({graphics:mask_graphics_117,x:176.8,y:224}).wait(1).to({graphics:mask_graphics_118,x:176.8,y:224.9}).wait(1).to({graphics:mask_graphics_119,x:176.8,y:225.8}).wait(1).to({graphics:mask_graphics_120,x:176.8,y:226.7}).wait(1).to({graphics:mask_graphics_121,x:176.8,y:227.6}).wait(1).to({graphics:mask_graphics_122,x:176.8,y:228.6}).wait(1).to({graphics:mask_graphics_123,x:176.8,y:229.5}).wait(1).to({graphics:mask_graphics_124,x:176.8,y:230.4}).wait(1).to({graphics:mask_graphics_125,x:176.8,y:231.3}).wait(1).to({graphics:mask_graphics_126,x:176.8,y:232.2}).wait(1).to({graphics:mask_graphics_127,x:176.8,y:233.1}).wait(1).to({graphics:mask_graphics_128,x:176.8,y:234}).wait(1).to({graphics:mask_graphics_129,x:176.8,y:234.9}).wait(1).to({graphics:mask_graphics_130,x:176.8,y:235.8}).wait(1).to({graphics:mask_graphics_131,x:176.8,y:236.7}).wait(1).to({graphics:mask_graphics_132,x:176.8,y:237.7}).wait(1).to({graphics:mask_graphics_133,x:176.8,y:238.6}).wait(1).to({graphics:mask_graphics_134,x:176.8,y:239.5}).wait(1).to({graphics:mask_graphics_135,x:176.8,y:240.4}).wait(1).to({graphics:mask_graphics_136,x:176.8,y:241.3}).wait(1).to({graphics:mask_graphics_137,x:176.8,y:242.2}).wait(1).to({graphics:mask_graphics_138,x:176.8,y:243.1}).wait(1).to({graphics:mask_graphics_139,x:176.8,y:244}).wait(1).to({graphics:mask_graphics_140,x:176.8,y:244.9}).wait(1).to({graphics:mask_graphics_141,x:176.8,y:245.8}).wait(1).to({graphics:mask_graphics_142,x:176.8,y:246.8}).wait(1).to({graphics:mask_graphics_143,x:176.8,y:247.7}).wait(1).to({graphics:mask_graphics_144,x:176.8,y:248.6}).wait(1).to({graphics:mask_graphics_145,x:176.8,y:249.5}).wait(1).to({graphics:mask_graphics_146,x:176.8,y:250.4}).wait(1).to({graphics:mask_graphics_147,x:176.8,y:251.3}).wait(1).to({graphics:mask_graphics_148,x:176.8,y:252.2}).wait(1).to({graphics:mask_graphics_149,x:176.8,y:253.1}).wait(1).to({graphics:mask_graphics_150,x:176.8,y:254}).wait(1).to({graphics:mask_graphics_151,x:176.8,y:254.9}).wait(1).to({graphics:mask_graphics_152,x:176.8,y:255.9}).wait(1).to({graphics:mask_graphics_153,x:176.8,y:256.8}).wait(1).to({graphics:mask_graphics_154,x:176.8,y:257.7}).wait(1).to({graphics:mask_graphics_155,x:176.8,y:258.6}).wait(1).to({graphics:mask_graphics_156,x:176.8,y:259.5}).wait(1).to({graphics:mask_graphics_157,x:176.8,y:260.4}).wait(1).to({graphics:mask_graphics_158,x:176.8,y:261.3}).wait(1).to({graphics:mask_graphics_159,x:176.8,y:262.2}).wait(1).to({graphics:mask_graphics_160,x:176.8,y:263.1}).wait(1).to({graphics:mask_graphics_161,x:176.8,y:264}).wait(1).to({graphics:mask_graphics_162,x:176.8,y:265}).wait(1).to({graphics:mask_graphics_163,x:176.8,y:265.9}).wait(1).to({graphics:mask_graphics_164,x:176.8,y:266.8}).wait(1).to({graphics:mask_graphics_165,x:176.8,y:267.7}).wait(1).to({graphics:mask_graphics_166,x:176.8,y:268.6}).wait(1).to({graphics:mask_graphics_167,x:176.8,y:269.5}).wait(1).to({graphics:mask_graphics_168,x:176.8,y:270.4}).wait(1).to({graphics:mask_graphics_169,x:176.8,y:271.3}).wait(1).to({graphics:mask_graphics_170,x:176.8,y:272.2}).wait(1).to({graphics:mask_graphics_171,x:176.8,y:273.1}).wait(1).to({graphics:mask_graphics_172,x:176.8,y:274.1}).wait(1).to({graphics:mask_graphics_173,x:176.8,y:275}).wait(1).to({graphics:mask_graphics_174,x:176.8,y:275.9}).wait(1).to({graphics:mask_graphics_175,x:176.8,y:276.8}).wait(1).to({graphics:mask_graphics_176,x:176.8,y:277.7}).wait(1).to({graphics:mask_graphics_177,x:176.8,y:278.6}).wait(1).to({graphics:mask_graphics_178,x:176.8,y:279.5}).wait(1).to({graphics:mask_graphics_179,x:176.8,y:280.4}).wait(1).to({graphics:mask_graphics_180,x:176.8,y:281.3}).wait(1).to({graphics:mask_graphics_181,x:176.8,y:282.2}).wait(1).to({graphics:mask_graphics_182,x:176.8,y:283.2}).wait(1).to({graphics:mask_graphics_183,x:176.8,y:284.1}).wait(1).to({graphics:mask_graphics_184,x:176.8,y:285}).wait(1).to({graphics:mask_graphics_185,x:176.8,y:285.9}).wait(1).to({graphics:mask_graphics_186,x:176.8,y:286.8}).wait(1).to({graphics:mask_graphics_187,x:176.8,y:287.7}).wait(1).to({graphics:mask_graphics_188,x:176.8,y:288.6}).wait(1).to({graphics:mask_graphics_189,x:176.8,y:237.5}).wait(1));

	// txt_solution_02
	this.txt_solucion_02 = new cjs.Text("48 % = 0,48 · 100 = 48 salmones\n\n3 % = 0,03 · 100 = 3 lucios\n\n10 % = 0,1 · 100 = 10 lampreas\n\n34 % = 0,34 · 100 = 34 agujas\n\n1 %  = 0,01 · 100 = 1 platija\n\n4 % = 0,04 · 100 = 4 percas\n\n\nAhora ya se conoce la frecuencia absoluta de cada especie.", "18px Verdana");
	this.txt_solucion_02.lineHeight = 18;
	this.txt_solucion_02.lineWidth = 363;
	this.txt_solucion_02.setTransform(0,130.3);
var html = createDiv(txt['txt_solucion_02'], "Verdana", "18px", '370px', '100px', "20px", "185px", "left");
    this.txt_solucion_02 = new lib.fadeText(html, 10,30);
    this.txt_solucion_02.setTransform(00, 130-608);
	this.txt_solucion_02.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_solucion_02}]}).wait(190));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,787.1,470.1);


(lib.mc_f3_Int = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("%", "38px Verdana");
	this.text.lineHeight = 38;
	this.text.setTransform(63.1,304.9,0.5,0.5);

	this.text_1 = new cjs.Text("%", "38px Verdana");
	this.text_1.lineHeight = 38;
	this.text_1.setTransform(13.6,173.9,0.5,0.5);

	this.text_2 = new cjs.Text("%", "38px Verdana");
	this.text_2.lineHeight = 38;
	this.text_2.setTransform(202.6,171.4,0.5,0.5);

	this.text_3 = new cjs.Text("%", "38px Verdana");
	this.text_3.lineHeight = 38;
	this.text_3.setTransform(176.8,352.4,0.5,0.5);

	this.text_4 = new cjs.Text("%", "38px Verdana");
	this.text_4.lineHeight = 38;
	this.text_4.setTransform(108.3,0,0.5,0.5);

	this.text_5 = new cjs.Text("%", "38px Verdana");
	this.text_5.lineHeight = 38;
	this.text_5.setTransform(0,13.1,0.5,0.5);

	this.addChild(this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,225.1,377.5);


(lib.mc_f2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A1WBCIAAiEMAqtAAAIAACEg");
	var mask_graphics_1 = new cjs.Graphics().p("A1WBaIAAizMAqtAAAIAACzg");
	var mask_graphics_2 = new cjs.Graphics().p("A1WBxIAAjhMAqtAAAIAADhg");
	var mask_graphics_3 = new cjs.Graphics().p("A1WCIIAAkPMAqtAAAIAAEPg");
	var mask_graphics_4 = new cjs.Graphics().p("A1WCfIAAk9MAqtAAAIAAE9g");
	var mask_graphics_5 = new cjs.Graphics().p("A1WC3IAAltMAqtAAAIAAFtg");
	var mask_graphics_6 = new cjs.Graphics().p("A1WDOIAAmbMAqtAAAIAAGbg");
	var mask_graphics_7 = new cjs.Graphics().p("A1WDlIAAnJMAqtAAAIAAHJg");
	var mask_graphics_8 = new cjs.Graphics().p("A1WD8IAAn3MAqtAAAIAAH3g");
	var mask_graphics_9 = new cjs.Graphics().p("A1WETIAAolMAqtAAAIAAIlg");
	var mask_graphics_10 = new cjs.Graphics().p("A1WErIAApVMAqtAAAIAAJVg");
	var mask_graphics_11 = new cjs.Graphics().p("A1WFCIAAqDMAqtAAAIAAKDg");
	var mask_graphics_12 = new cjs.Graphics().p("A1WFZIAAqxMAqtAAAIAAKxg");
	var mask_graphics_13 = new cjs.Graphics().p("A1WFwIAArfMAqtAAAIAALfg");
	var mask_graphics_14 = new cjs.Graphics().p("A1WGHIAAsNMAqtAAAIAAMNg");
	var mask_graphics_15 = new cjs.Graphics().p("A1WGfIAAs9MAqtAAAIAAM9g");
	var mask_graphics_16 = new cjs.Graphics().p("A1WG2IAAtrMAqtAAAIAANrg");
	var mask_graphics_17 = new cjs.Graphics().p("A1WHNIAAuZMAqtAAAIAAOZg");
	var mask_graphics_18 = new cjs.Graphics().p("A1WHkIAAvHMAqtAAAIAAPHg");
	var mask_graphics_19 = new cjs.Graphics().p("A1WH7IAAv1MAqtAAAIAAP1g");
	var mask_graphics_20 = new cjs.Graphics().p("A1WITIAAwlMAqtAAAIAAQlg");
	var mask_graphics_21 = new cjs.Graphics().p("A1WIqIAAxTMAqtAAAIAARTg");
	var mask_graphics_22 = new cjs.Graphics().p("A1WJBIAAyBMAqtAAAIAASBg");
	var mask_graphics_23 = new cjs.Graphics().p("A1WJYIAAyvMAqtAAAIAASvg");
	var mask_graphics_24 = new cjs.Graphics().p("A1WJvIAAzdMAqtAAAIAATdg");
	var mask_graphics_25 = new cjs.Graphics().p("A1WKHIAA0NMAqtAAAIAAUNg");
	var mask_graphics_26 = new cjs.Graphics().p("A1WKeIAA07MAqtAAAIAAU7g");
	var mask_graphics_27 = new cjs.Graphics().p("A1WK1IAA1pMAqtAAAIAAVpg");
	var mask_graphics_28 = new cjs.Graphics().p("A1WLMIAA2XMAqtAAAIAAWXg");
	var mask_graphics_29 = new cjs.Graphics().p("A1WLkIAA3HMAqtAAAIAAXHg");
	var mask_graphics_30 = new cjs.Graphics().p("A1WL7IAA31MAqtAAAIAAX1g");
	var mask_graphics_31 = new cjs.Graphics().p("A1WMSIAA4jMAqtAAAIAAYjg");
	var mask_graphics_32 = new cjs.Graphics().p("A1WMpIAA5RMAqtAAAIAAZRg");
	var mask_graphics_33 = new cjs.Graphics().p("A1WNAIAA5/MAqtAAAIAAZ/g");
	var mask_graphics_34 = new cjs.Graphics().p("A1WNYIAA6vMAqtAAAIAAavg");
	var mask_graphics_35 = new cjs.Graphics().p("A1WNvIAA7dMAqtAAAIAAbdg");
	var mask_graphics_36 = new cjs.Graphics().p("A1WOGIAA8LMAqtAAAIAAcLg");
	var mask_graphics_37 = new cjs.Graphics().p("A1WOdIAA85MAqtAAAIAAc5g");
	var mask_graphics_38 = new cjs.Graphics().p("A1WO0IAA9nMAqtAAAIAAdng");
	var mask_graphics_39 = new cjs.Graphics().p("A1WPMIAA+XMAqtAAAIAAeXg");
	var mask_graphics_40 = new cjs.Graphics().p("A1WPjIAA/FMAqtAAAIAAfFg");
	var mask_graphics_41 = new cjs.Graphics().p("A1WP6IAA/zMAqtAAAIAAfzg");
	var mask_graphics_42 = new cjs.Graphics().p("A1WQRMAAAgghMAqtAAAMAAAAghg");
	var mask_graphics_43 = new cjs.Graphics().p("A1WQoMAAAghPMAqtAAAMAAAAhPg");
	var mask_graphics_44 = new cjs.Graphics().p("A1WRAMAAAgh/MAqtAAAMAAAAh/g");
	var mask_graphics_45 = new cjs.Graphics().p("A1WRXMAAAgitMAqtAAAMAAAAitg");
	var mask_graphics_46 = new cjs.Graphics().p("A1WRuMAAAgjbMAqtAAAMAAAAjbg");
	var mask_graphics_47 = new cjs.Graphics().p("A1WSFMAAAgkJMAqtAAAMAAAAkJg");
	var mask_graphics_48 = new cjs.Graphics().p("A1WScMAAAgk3MAqtAAAMAAAAk3g");
	var mask_graphics_49 = new cjs.Graphics().p("A1WS0MAAAglnMAqtAAAMAAAAlng");
	var mask_graphics_50 = new cjs.Graphics().p("A1WTLMAAAgmVMAqtAAAMAAAAmVg");
	var mask_graphics_51 = new cjs.Graphics().p("A1WTiMAAAgnDMAqtAAAMAAAAnDg");
	var mask_graphics_52 = new cjs.Graphics().p("A1WT5MAAAgnxMAqtAAAMAAAAnxg");
	var mask_graphics_53 = new cjs.Graphics().p("A1WUQMAAAgofMAqtAAAMAAAAofg");
	var mask_graphics_54 = new cjs.Graphics().p("A1WUoMAAAgpPMAqtAAAMAAAApPg");
	var mask_graphics_55 = new cjs.Graphics().p("A1WU/MAAAgp9MAqtAAAMAAAAp9g");
	var mask_graphics_56 = new cjs.Graphics().p("A1WVWMAAAgqrMAqtAAAMAAAAqrg");
	var mask_graphics_57 = new cjs.Graphics().p("A1WVtMAAAgrZMAqtAAAMAAAArZg");
	var mask_graphics_58 = new cjs.Graphics().p("A1WWFMAAAgsJMAqtAAAMAAAAsJg");
	var mask_graphics_59 = new cjs.Graphics().p("A1WWcMAAAgs3MAqtAAAMAAAAs3g");
	var mask_graphics_60 = new cjs.Graphics().p("A1WWzMAAAgtlMAqtAAAMAAAAtlg");
	var mask_graphics_61 = new cjs.Graphics().p("A1WXKMAAAguTMAqtAAAMAAAAuTg");
	var mask_graphics_62 = new cjs.Graphics().p("A1WXhMAAAgvBMAqtAAAMAAAAvBg");
	var mask_graphics_63 = new cjs.Graphics().p("A1WX5MAAAgvxMAqtAAAMAAAAvxg");
	var mask_graphics_64 = new cjs.Graphics().p("A1WYQMAAAgwfMAqtAAAMAAAAwfg");
	var mask_graphics_65 = new cjs.Graphics().p("A1WYnMAAAgxNMAqtAAAMAAAAxNg");
	var mask_graphics_66 = new cjs.Graphics().p("A1WY+MAAAgx7MAqtAAAMAAAAx7g");
	var mask_graphics_67 = new cjs.Graphics().p("A1WZVMAAAgypMAqtAAAMAAAAypg");
	var mask_graphics_68 = new cjs.Graphics().p("A1WZtMAAAgzZMAqtAAAMAAAAzZg");
	var mask_graphics_69 = new cjs.Graphics().p("A1WaEMAAAg0HMAqtAAAMAAAA0Hg");
	var mask_graphics_70 = new cjs.Graphics().p("AD/abMAAAg01MAqvAAAMAAAA01g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:461.4,y:-9.1}).wait(1).to({graphics:mask_graphics_1,x:461.4,y:-6.8}).wait(1).to({graphics:mask_graphics_2,x:461.4,y:-4.5}).wait(1).to({graphics:mask_graphics_3,x:461.4,y:-2.1}).wait(1).to({graphics:mask_graphics_4,x:461.4,y:0.1}).wait(1).to({graphics:mask_graphics_5,x:461.4,y:2.4}).wait(1).to({graphics:mask_graphics_6,x:461.4,y:4.7}).wait(1).to({graphics:mask_graphics_7,x:461.4,y:7}).wait(1).to({graphics:mask_graphics_8,x:461.4,y:9.4}).wait(1).to({graphics:mask_graphics_9,x:461.4,y:11.7}).wait(1).to({graphics:mask_graphics_10,x:461.4,y:14}).wait(1).to({graphics:mask_graphics_11,x:461.4,y:16.3}).wait(1).to({graphics:mask_graphics_12,x:461.4,y:18.6}).wait(1).to({graphics:mask_graphics_13,x:461.4,y:21}).wait(1).to({graphics:mask_graphics_14,x:461.4,y:23.3}).wait(1).to({graphics:mask_graphics_15,x:461.4,y:25.6}).wait(1).to({graphics:mask_graphics_16,x:461.4,y:27.9}).wait(1).to({graphics:mask_graphics_17,x:461.4,y:30.3}).wait(1).to({graphics:mask_graphics_18,x:461.4,y:32.6}).wait(1).to({graphics:mask_graphics_19,x:461.4,y:34.9}).wait(1).to({graphics:mask_graphics_20,x:461.4,y:37.2}).wait(1).to({graphics:mask_graphics_21,x:461.4,y:39.5}).wait(1).to({graphics:mask_graphics_22,x:461.4,y:41.9}).wait(1).to({graphics:mask_graphics_23,x:461.4,y:44.2}).wait(1).to({graphics:mask_graphics_24,x:461.4,y:46.5}).wait(1).to({graphics:mask_graphics_25,x:461.4,y:48.8}).wait(1).to({graphics:mask_graphics_26,x:461.4,y:51.1}).wait(1).to({graphics:mask_graphics_27,x:461.4,y:53.5}).wait(1).to({graphics:mask_graphics_28,x:461.4,y:55.8}).wait(1).to({graphics:mask_graphics_29,x:461.4,y:58.1}).wait(1).to({graphics:mask_graphics_30,x:461.4,y:60.4}).wait(1).to({graphics:mask_graphics_31,x:461.4,y:62.7}).wait(1).to({graphics:mask_graphics_32,x:461.4,y:65.1}).wait(1).to({graphics:mask_graphics_33,x:461.4,y:67.4}).wait(1).to({graphics:mask_graphics_34,x:461.4,y:69.7}).wait(1).to({graphics:mask_graphics_35,x:461.4,y:72}).wait(1).to({graphics:mask_graphics_36,x:461.4,y:74.3}).wait(1).to({graphics:mask_graphics_37,x:461.4,y:76.7}).wait(1).to({graphics:mask_graphics_38,x:461.4,y:79}).wait(1).to({graphics:mask_graphics_39,x:461.4,y:81.3}).wait(1).to({graphics:mask_graphics_40,x:461.4,y:83.6}).wait(1).to({graphics:mask_graphics_41,x:461.4,y:85.9}).wait(1).to({graphics:mask_graphics_42,x:461.4,y:88.3}).wait(1).to({graphics:mask_graphics_43,x:461.4,y:90.6}).wait(1).to({graphics:mask_graphics_44,x:461.4,y:92.9}).wait(1).to({graphics:mask_graphics_45,x:461.4,y:95.2}).wait(1).to({graphics:mask_graphics_46,x:461.4,y:97.6}).wait(1).to({graphics:mask_graphics_47,x:461.4,y:99.9}).wait(1).to({graphics:mask_graphics_48,x:461.4,y:102.2}).wait(1).to({graphics:mask_graphics_49,x:461.4,y:104.5}).wait(1).to({graphics:mask_graphics_50,x:461.4,y:106.8}).wait(1).to({graphics:mask_graphics_51,x:461.4,y:109.2}).wait(1).to({graphics:mask_graphics_52,x:461.4,y:111.5}).wait(1).to({graphics:mask_graphics_53,x:461.4,y:113.8}).wait(1).to({graphics:mask_graphics_54,x:461.4,y:116.1}).wait(1).to({graphics:mask_graphics_55,x:461.4,y:118.4}).wait(1).to({graphics:mask_graphics_56,x:461.4,y:120.8}).wait(1).to({graphics:mask_graphics_57,x:461.4,y:123.1}).wait(1).to({graphics:mask_graphics_58,x:461.4,y:125.4}).wait(1).to({graphics:mask_graphics_59,x:461.4,y:127.7}).wait(1).to({graphics:mask_graphics_60,x:461.4,y:130}).wait(1).to({graphics:mask_graphics_61,x:461.4,y:132.4}).wait(1).to({graphics:mask_graphics_62,x:461.4,y:134.7}).wait(1).to({graphics:mask_graphics_63,x:461.4,y:137}).wait(1).to({graphics:mask_graphics_64,x:461.4,y:139.3}).wait(1).to({graphics:mask_graphics_65,x:461.4,y:141.6}).wait(1).to({graphics:mask_graphics_66,x:461.4,y:144}).wait(1).to({graphics:mask_graphics_67,x:461.4,y:146.3}).wait(1).to({graphics:mask_graphics_68,x:461.4,y:148.6}).wait(1).to({graphics:mask_graphics_69,x:461.4,y:150.9}).wait(1).to({graphics:mask_graphics_70,x:299.1,y:153.2}).wait(1));

	// Capa 2
	this.text = new cjs.Text("Especies encontradas", "40px Verdana");
	this.text.lineHeight = 45;
	this.text.lineWidth = 439;
	this.text.setTransform(356.1,0.3,0.5,0.5);

	this.text_1 = new cjs.Text("perca", "40px Verdana");
	this.text_1.lineHeight = 45;
	this.text_1.lineWidth = 140;
	this.text_1.setTransform(393,276.3,0.5,0.5);

	this.text_2 = new cjs.Text("platija", "40px Verdana");
	this.text_2.lineHeight = 45;
	this.text_2.lineWidth = 151;
	this.text_2.setTransform(393,230.3,0.5,0.5);

	this.text_3 = new cjs.Text("aguja", "40px Verdana");
	this.text_3.lineHeight = 45;
	this.text_3.lineWidth = 120;
	this.text_3.setTransform(393,184.3,0.5,0.5);

	this.text_4 = new cjs.Text("lamprea", "40px Verdana");
	this.text_4.lineHeight = 45;
	this.text_4.lineWidth = 171;
	this.text_4.setTransform(393,138.3,0.5,0.5);

	this.text_5 = new cjs.Text("lucio", "40px Verdana");
	this.text_5.lineHeight = 45;
	this.text_5.lineWidth = 105;
	this.text_5.setTransform(393,92.3,0.5,0.5);

	this.text_6 = new cjs.Text("salmón", "40px Verdana");
	this.text_6.lineHeight = 45;
	this.text_6.lineWidth = 148;
	this.text_6.setTransform(393,46.3,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFA848").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape.setTransform(366.3,292.2,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7B22FF").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_1.setTransform(366.3,246.2,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00E250").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_2.setTransform(366.3,200.1,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFF48D").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_3.setTransform(366.3,154.1,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FC2A36").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_4.setTransform(366.3,108.1,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#34ADFE").s().p("AjLDMIAAmXIGXAAIAAGXg");
	this.shape_5.setTransform(366.3,62,0.5,0.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(71));

	// Capa 3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Aa4LpQAABPgHBOI7/idg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Aa4KbQAACegbCbI7rk5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("Aa4JPQAADtg9DkI7JnRg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Aa4IEQAACegbCaQgcCbg2CUI6Zpng");
	var mask_1_graphics_4 = new cjs.Graphics().p("Aa4G7QAACEgTCBQgTCCgmB9QglB+g4B3I5dr5g");
	var mask_1_graphics_5 = new cjs.Graphics().p("Aa4F2QAAB2gQB1QgPB1geByQgfBxgtBtQgtBtg7BmI4VuDg");
	var mask_1_graphics_6 = new cjs.Graphics().p("Aa4EzQAABvgOBuQgNBtgbBqQgaBrgoBmQgnBngzBhQg0BhhABbI3AwJg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Aa4D1QAAB/gSB9QgRB8gjB5QgjB4gyBzQgzByhDBrQhDBrhRBhI1hyFg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Aa4C7QAAB4gQB1QgPB1gfBxQgeBygtBsQgtBtg7BlQg6BmhIBeQhIBdhUBVIz3z5g");
	var mask_1_graphics_9 = new cjs.Graphics().p("Aa4CGQAACFgTCCQgUCCglB9QgmB9g3B2Qg3B2hHBtQhIBthXBiQhXBihmBWIyD1jg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Aa4BWQAACTgYCPQgXCPgtCIQguCIhBB/QhCB+hWB0QhVBzhoBlQhnBkh5BVIwG3Dg");
	var mask_1_graphics_11 = new cjs.Graphics().p("Aa4AsQAAChgcCcQgcCbg2CTQg1CShOCHQhOCHhkB4QhkB4h5BmQh5BliLBRIuC4Xg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Aa4AIQAACvghCoQghCog/CdQg/CdhaCOQhaCOh0B8Qh0B7iKBkQiLBlieBKIr35fg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Aa4gUQAAC7gmC1QgnC0hICnQhJCnhoCUQhoCViDB9QiEB9idBiQicBhiyBBIpm6Zg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Aa4gsQAADKgsDBQgsDBhTCwQhTCwh2CaQh2CaiVB+QiUB9ivBcQivBdjFA1InQ7Jg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Aa4g9QgBDZgyDNQgyDNheC5QheC5iECeQiFCeimB9QilB9jCBVQjBBUjYAnIk27rg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aa4hHQgBDog4DZQg5DahpDBQhqDBiUChQiUChi3B6Qi3B7jUBLQjTBLjpAVIib7/g");
	var mask_1_graphics_17 = new cjs.Graphics().p("Aa4hKQgBD3g/DlQhADlh2DJQh2DJijCjQikCkjJB2QjIB2jmA/QjlBAj3AAIAA8Fg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aa4hKQAAB8gSB8QgRB7giB3QgiB4gyBxQgxBxhBBpQhBBqhQBgQhPBghdBWQhdBVhnBGQhnBHhvA4QhuA3h2AoQh1Aoh5AXQh6AXh9AHQh6AGh+gKICd7/g");
	var mask_1_graphics_19 = new cjs.Graphics().p("Aa4hKQAACDgTCCQgUCCglB9QgmB9g3B2Qg3B1hHBtQhIBthXBjQhXBihmBVQhmBWhwBFQhwBEh4A0Qh4Azh9AiQh+AiiBAPQiCAPiBgDQiDgEiEgXIE57qg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aa4hKQAACKgVCIQgWCIgpCDQgpCDg9B6Qg8B6hOBxQhPBwhfBkQhfBjhvBWQhwBVh5BCQh5BCiAAvQiBAuiGAbQiGAaiJAHQiGAGiJgPQiKgPiHgkIHS7Ig");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aa4hKQAACRgYCOQgXCPgtCIQguCIhBB/QhCB/hWBzQhVBzhoBlQhnBlh5BUQh4BUiCA/QiDA/iJAoQiJApiOATQiOATiNgEQiPgEiOgbQiPgbiKgyIJo6Zg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Aa4hKQAACYgaCVQgZCVgyCNQgxCOhICDQhICDhcB1QhdB2hwBlQhwBmiCBTQiCBSiLA7QiMA6iSAiQiRAjiVAJQiTAKiVgPQiVgPiSgoQiSgniMhBIL55dg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Aa4hKQAACfgcCbQgcCcg2CSQg1CThOCHQhOCHhkB4QhkB3h5BmQh5BmiLBQQjSB5jkA8QjkA8joAAQjqAAjkg8Qjkg8jSh5IOE4Ug");
	var mask_1_graphics_24 = new cjs.Graphics().p("Aa4hKQAACmgfCiQgeChg6CYQg6CYhUCLQhUCKhsB6QhsB6iBBlQiCBmiVBNQjgB0jxAyQjxAxjxgQQjzgQjohQQjohRjQiQIQJ3Ag");
	var mask_1_graphics_25 = new cjs.Graphics().p("Aa4hKQAACtghCoQghCog/CdQg/CdhaCOQhaCOh0B7Qh0B8iKBkQiLBlieBKQjvBvj9AlQj7Amj7ghQj7ghjrhmQjqhmjKipISF1gg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aa4hKQAAC0gkCuQgjCvhECiQhDCihhCRQhiCRh7B9Qh8B8iTBjQiUBkioBFQj+BpkIAYQkGAZkCgzQkCg0jrh8Qjqh8jDjBIT5z2g");
	var mask_1_graphics_27 = new cjs.Graphics().p("Aa4hKQAAC7gmC1QgnC0hICnQhJCnhoCUQhoCViDB9QiEB9idBiQicBhiyBBQkNBhkRAKQkTAKkHhGQkHhHjpiTQjpiSi4jZIVjyDg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Aa4hKQAADCgpC7QgpC7hOCrQhOCshvCXQhuCXiNB+QiMB+ilBfQimBfi8A7QkaBYkcgFQkdgFkLhbQkLhajliqQjliqirjxIXDwGg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Aa4hKQAADKgsDBQgsDAhTCxQhTCwh2CZQh2CaiVB+QiUB+ivBcQivBcjFA1QkpBOkkgVQkmgVkOhwQkNhwjfjBQjfjBibkJIYXuBg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Aa4hKQgBDRguDHQgvDHhZC1QhYC0h9CcQh+CcidB+QidB9i4BZQi4BZjPAuQiaAiiaAHQiYAGiXgTQiWgTiQgrQiQgsiGhCQiHhCh6hYQh5hYhrhrQhrhshYh+QhYh/hDiPIZfr2g");
	var mask_1_graphics_31 = new cjs.Graphics().p("AbRhKQAADYgyDOQgyDNheC5QheC4iFCfQiFCeilB8QimB9jBBVQjCBVjXAmQiiAcidgBQifAAiagdQiagciSg1QiRg2iGhNQiGhOh3hjQh3hjhlh3Qhlh3hRiKQhQiJg4iaIabplg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AbphKQgBDgg1DTQg1DThkC9QhkC9iMCgQiMCgiuB8QivB7jKBRQjLBQjgAeQioAWijgJQikgJidgmQicgmiThAQiShAiEhZQiFhYhzhvQhzhuhfiDQhfiChHiUQhHiUgsikIbLnPg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ab6hKQgBDog4DZQg5DZhqDBQhpDBiUCiQiUChi3B6Qi3B6jUBLQjTBMjpAUQitAQiogSQipgSifgwQifgviThLQiShLiChkQiChkhuh6Qhvh6hXiNQhXiOg8ieQg9iegfisIbtk2g");
	var mask_1_graphics_34 = new cjs.Graphics().p("AcEhKQgBDvg8DfQg8DghvDFQhwDFicCiQibCjjAB4QjAB4jdBGQjcBGjxALQizAHitgaQisgbihg6Qihg6iShXQiRhWh/hvQh+hvhpiFQhoiFhPiYQhOiYgxinQgxiogQi0IcBiag");
	var mask_1_graphics_35 = new cjs.Graphics().p("AcHhKQAAD3hADlQg/Dlh2DJQh2DJikCjQijCkjJB2QjJB2jlA/QjlBAj5AAQi5AAiwgkQiwgliihEQiihFiQhiQiQhhh6h7Qh7h6hhiQQhhiQhFiiQhFihgkiwQgkiwAAi4IcGAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AcHhKQAACjgdCgQgeCgg4CWQg5CWhSCJQhSCKhpB5QhpB5h/BmQh+BliSBPQjcB2jsA1QjtA1jugKQjwgLjnhKQjnhJjRiJQjPiJigi3Qifi3hpjZQhojYgtjuQgtjuAVj2IcACdg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AcIhKQgBCogfCkQgfCkg8CZQg7CahWCMQhXCMhuB6QhuB6iFBlQiEBmiZBMQjlByj1AuQj0Auj0gWQj2gVjphYQjphXjOiZQjNiZiXjGQiXjHhbjlQhbjmgbj3Qgaj2Asj8IbrE5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("AcIhKQgBCtggCoQghCog/CdQg/CdhaCOQhbCOh0B7QhzB8iLBkQiKBlifBKQjvBvj8AlQj9Amj5ghQj8ghjqhmQjqhmjKipQjKipiNjWQiNjVhMjyQhMjxgHj+QgHj/BEj+IbJHSg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AcHhKQAACygiCsQgjCshCCgQhCChhfCQQhfCQh5B8Qh5B8iQBkQiQBkimBHQj4BrkFAdQkCAdkAgtQkAgtjrh1Qjqh0jGi5QjEi6iCjkQiCjkg8j9Qg8j9AOkDQAOkGBcj+IaaJog");
	var mask_1_graphics_40 = new cjs.Graphics().p("AcHhKQAAC2gkCxQgkCwhGCkQhFCjhjCTQhkCSh+B9Qh+B9iXBiQiWBjisBEQkCBmkMAUQkKAUkEg6QkEg5jqiEQjqiDjAjJQi+jLh1jyQh2jxgqkHQgrkFAkkKQAkkKB0j8IZeL5g");
	var mask_1_graphics_41 = new cjs.Graphics().p("AcHhKQAAC7gmC1QgmC0hJCnQhICnhoCUQhoCViEB9QiEB9icBiQidBhiyBBQkMBhkTAKQkRAKkHhGQkIhHjoiTQjpiSi4jZQi3jbhoj/Qhoj/gYkQQgXkOA6kMQA6kNCOj3IYVOEg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AcHhKQAADAgoC5QgoC4hMCqQhMCqhsCWQhtCXiJB9QiJB+ijBgQijBgi4A9QkWBbkaAAQkYABkKhUQkKhUjmiiQjniiivjqQiujrhZkLQhZkMgEkVQgEkXBRkNQBRkOCnjwIXBQJg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AcHhKQAADFgqC9QgqC8hPCtQhQCthxCZQhxCYiPB9QiPB+ipBeQioBei/A6QkgBVkegLQkggKkMhiQkMhhjjiyQjkixilj5QhuinhEi1QhFi1gdi8Qgci8ALi8QALi9Ayi3QAyi4BairQBZisCAiYIVhSFg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AcHhKQAADKgsDBQgsDAhTCxQhTCwh1CZQh2CaiVB+QiVB+ivBcQivBcjFA1QkpBOkkgVQkmgVkNhwQkOhwjfjBQjfjBiakJQhmixg7i9Qg6i9gQjCQgQjAAZjAQAZjABCi3QBCi3BpioQBqinCQiQIT3T5g");
	var mask_1_graphics_45 = new cjs.Graphics().p("AcIhKQgBDPguDFQguDFhWCzQhXCzh7CbQh6CbibB+QiaB9i1BaQi1BajLAxQiZAkiYAJQiWAJiVgQQiVgQiQgoQiPgoiGg/QiHg/h6hUQh7hUhshnQhshohbh7Qhbh6hGiMQhdi7gwjEQgvjFgDjFQgDjHAojCQAojCBRi1QBSi2B5ihQB6iiCgiGISDVjg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AcIhKQgBDUgwDJQgwDJhaC2QhaC2iACcQiACdifB9QigB+i8BXQi7BYjRArQidAgicAFQiaAEiYgWQiXgWiRgvQiQgviHhGQiGhGh5hbQh5hchphvQhphwhWiCQhWiCg/iTQhVjEgjjMQgkjLALjJQALjLA3jDQA3jCBhizQBiiyCJiaQCJibCvh7IQHXDg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AcIhKQgBDYgyDOQgyDNheC5QheC4iFCfQiECeimB8QimB9jBBVQjBBVjYAmQihAciegBQifAAiagdQiagciRg1QiSg2iFhNQiGhOh3hjQh3hjhmh3Qhlh3hQiKQhRiJg4iaQhKjOgXjSQgYjQAZjNQAajOBGjCQBHjCBxiuQBxiuCZiSQCYiRC+huIOCYXg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AcIhKQgBDdg0DSQg0DRhiC8QhiC7iKCfQiJCgisB8QirB8jIBSQjHBRjeAhQimAYiggGQijgGicgjQibgiiTg9QiSg8iFhVQiEhVh1hrQh1hrhhh+Qhhh/hKiQQhKiRgxigQg/jXgLjXQgKjWAojQQAojPBWjBQBXjACAioQCBioCoiHQCniIDLhfIL3Zgg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AcIg1QgBDjg2DVQg3DWhlC+QhmC+iPChQiOCgiyB7QixB7jOBPQjNBPjjAbQirATijgLQimgMiegpQidgpiThEQiShEiEhcQiDhdhyhyQhyhyhciGQhdiGhDiYQhEiXgoinQg0jfAEjaQADjcA3jQQA3jRBmi9QBmi9CQihQCQihC2h8QC2h7DXhPIJmabg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AcIgdQgBDog5DZQg4DZhqDBQhpDBiUCiQiUChi3B6Qi3B6jUBMQjTBLjpAVQitAPipgSQiogSifgvQiggwiShLQiShLiChkQiChkhuh6Qhvh6hXiNQhXiNg9ieQg8iegfitQgojmASjeQASjgBGjQQBHjRB2i4QB1i5CfiYQCfiYDEhvQDDhvDig9IHQbLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AcIgMQgBDtg7DdQg7DdhtDEQhuDEiZCiQiZCii9B5Qi9B5jaBHQjZBIjvAPQixAKirgYQirgYigg2Qihg3iShSQiShTh/hrQiAhshriBQhqiBhSiVQhRiUg1ikQg1ilgVixQgbjsAgjiQAhjjBWjPQBXjPCFizQCFizCuiOQCtiODQhgQDQhhDrgqIE3btg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AcHgCQAADyg9DhQg+DihxDGQhyDGieCjQifCjjDB3QjCB4jgBEQjfBDj0AIQi1AFiugeQiugeihg9Qihg+iRhaQiRhah+hzQh9hzhmiIQhmiJhMibQhLicgtiqQgtiqgKi2QgOjyAwjkQAwjlBmjMQBmjNCVisQCUisC8iCQC7iDDbhQQDbhRD0gWICbcBg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AcHAAQAAD5hADlQg/Dlh2DJQh2DJikCjQijCkjJB2QjJB1jlBAQjlBAj5AAQi5AAiwgkQiwgliihEQiihFiQhiQiQhhh6h7Qh7h6hhiQQhhiQhFiiQhFiigkivQgkiwAAi6QAAj4BAjlQA/jlB2jJQB2jJCkijQCjikDJh2QDJh1DlhAQDlhAD4AAIAAcGg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AcHAAQAAC6gkCxQglCxhGClQhGCkhlCTQhkCTiAB9QiAB9iYBiQiYBiitBEQkFBlkOARQkLASkFg9QkFg9jqiHQjqiHi+jOQi8jOhyj1Qhzj1glkKQgmkHApkLQApkLB7j6QBTinBviPQBviPCIh0QCIh0CbhYQCbhXCpg3QCqg4C0gVQC0gVC3AQIicb/g");
	var mask_1_graphics_55 = new cjs.Graphics().p("AcHAAQAAC9gmC1QgmC0hJCnQhICnhoCUQhoCUiEB+QiEB9icBhQidBiiyBBQkMBgkTALQkRAKkHhGQkIhHjoiTQjpiSi4jaQi3jahoj/Qhoj/gYkQQgXkOA6kNQA6kMCOj3QBfikB7iKQB7iJCShsQCThsCkhMQCkhNCxgqQCxgrC4gGQC2gGC7AgIk4brg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AcHAAQAADBgnC3QgoC4hLCpQhLCphrCWQhsCWiIB9QiIB+ihBgQihBhi3A+QkTBckYADQkXADkJhRQkJhQjoieQjnieiyjmQiwjnhdkIQhckJgKkVQgJkTBMkOQBLkOChjxQBrihCHiDQCHiCCdhjQCchjCshBQCthBC3gcQC3gdC5AJQC8AJC6AyInRbJg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AcHAAQAADEgpC7QgpC7hNCrQhOCshvCXQhvCXiMB+QiMB9imBfQimBgi7A7QkbBYkbgFQkdgFkLhbQkLhbjlipQjliqirjxQhxiihJiwQhKixgii5Qgji5AEi5QAEi8Ari3QAqi3BSitQBRitB3icQB5icCSh7QCSh7CmhZQCmhZC0g0QC0g1C7gOQC6gOC+AZQC9AZC5BDIpnaag");
	var mask_1_graphics_58 = new cjs.Graphics().p("AcHAAQAADIgqC+QgrC9hQCuQhQCuhzCYQhyCZiQB+QiRB9iqBeQiqBejBA4QkiBTkfgNQkigNkNhlQkMhljii1Qjji1ijj+QhriphCi3QhDi3gZi+Qgai9APi8QAOi/A2i3QA3i4BdiqQBdirCEiWQCFiXCdhzQCdhyCvhOQCvhNC6goQC7gnC9ABQDAAAC9AqQC+AqC2BUIr4Zeg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AcHAAQAADLgsDBQgsDBhTCwQhTCwh1CaQh2CaiVB9QiVB+ivBcQivBdjFA1QkpBOkkgVQkmgWkNhwQkOhvjfjBQjfjBiakJQhmixg7i9Qg6i9gQjCQgQjAAZjAQAZjABCi3QBCi4BpinQBqinCQiQQCQiQCohqQCnhpC3hCQC3hCDBgZQDAgZDAAQQDCAQC9A7QC9A6CxBmIuEYVg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AcIAAQgBDPgtDEQguDEhVCyQhWCzh5CbQh6CaiZB+QiZB+izBaQi0BbjKAxQiXAliXALQiVAKiVgOQiUgPiPgnQiPgmiGg9QiHg9h7hSQh7hShshmQhthmhch4Qhch5hIiKQhgi4gyjDQgyjDgHjGQgGjDAkjCQAljCBNi2QBOi2B1ijQB2ijCciJQCciJCxhfQCyhfC+g1QC/g1DEgKQDDgLDDAgQDDAgC7BLQC7BLCqB3IwIXBg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AcIAAQgBDTgvDHQgvDHhYC0QhYC1h+CcQh9CcidB9QidB+i4BZQi4BYjPAuQibAiiaAHQiYAHiWgTQiWgTiQgrQiQgsiHhCQiGhDh6hXQh6hYhqhsQhrhrhYh/QhZh+hDiPQhZjAgpjIQgqjIAEjHQAEjKAvjCQAwjCBZi0QBZi0CCifQCBieCoiBQCoiAC6hUQC7hUDFgnQDFgoDGAEQDIAFDDAwQDDAwC3BcQC2BcCjCIIyFVhg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AcIAAQgBDWgwDLQgxDKhbC2QhbC3iBCdQiBCdihB9QiiB9i8BXQi9BXjTAqQieAgidADQibADiYgYQiYgXiRgxQiRgwiGhIQiGhIh5hdQh4hehohxQhphyhUiEQhUiDg+iVQhSjHghjNQghjOAPjJQAOjMA7jDQA7jCBlixQBmiyCNiYQCNiYCzh4QCzh3DDhIQDDhIDKgaQDLgZDIAUQDKAUDCBAQDCBBCxBtQCxBsCYCYIz4T3g");
	var mask_1_graphics_63 = new cjs.Graphics().p("AcIAAQgBDagyDNQgyDNheC5QheC5iFCeQiECeimB9QimB9jBBVQjBBUjYAnQihAciegBQifgBiagcQiagciRg2QiSg1iFhOQiGhNh3hjQh3hjhmh4Qhlh3hQiJQhRiJg4iaQhKjOgXjSQgYjQAZjOQAajOBGjCQBHjCBxitQBxiuCZiSQCYiSC+htQC9htDLg8QDLg7DPgLQDNgLDLAkQDLAkC/BRQC/BSCqB9QCqB8CNCnI1iSEg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AcIAAQgBDegzDQQg0DQhhC7QhhC7iICfQiJCfiqB8QiqB9jGBSQjGBTjcAiQikAZiggFQiigEibghQicghiSg7QiSg7iFhTQiFhTh1hpQh2hphih8Qhih9hMiPQhMiPgyieQhDjVgNjWQgNjUAkjQQAkjPBSjBQBTjAB8iqQB9iqCkiKQCkiKDHhjQDIhiDSguQDRgtDRAEQDTAEDKA1QDLA0C7BhQC7BiChCNQCiCMCAC2I3CQHg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AcIAAQgBDig1DTQg1DThkC9QhkC9iMCgQiMCgivB8QiuB7jLBQQjKBRjgAeQipAWiigJQikgJidgmQidgmiShAQiShAiEhZQiFhYhzhvQhzhuhfiDQhfiChHiUQhHiUgsikQg6jbgDjZQgEjYAwjRQAvjQBei/QBei/CJikQCIilCviBQCviCDRhXQDRhWDYggQDXggDTAUQDVAUDJBFQDKBEC0ByQC1ByCYCcQCYCcBxDEI4WOCg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AcIAAQgBDmg3DWQg3DWhmC/QhnC/iQChQiQChizB6QizB7jPBOQjPBOjkAaQisASikgNQingNiegrQiegriShFQiShGiEheQiDhehxh1Qhxh0hbiIQhbiIhCiZQhCiZgmioQgxjhAHjbQAHjdA7jRQA7jRBqi8QBqi8CUieQCUifC5h5QC5h4DahLQDahJDdgRQDagRDWAkQDWAkDHBVQDGBVCuCCQCuCBCMCrQCMCrBiDQI5fL3g");
	var mask_1_graphics_67 = new cjs.Graphics().p("AcIAAQgBDpg5DaQg4DZhqDBQhpDBiUCiQiUChi3B6Qi3B6jUBLQjTBMjpAUQitAPipgRQiogSifgwQiggviShLQiShLiChkQiChkhuh6Qhvh6hXiNQhXiOg9ieQg8iegfisQgojmASjeQASjgBGjRQBHjQB2i5QB1i4CfiYQCfiYDEhvQDDhvDig9QDig8DggBQDfgCDWA0QDWA1DCBlQDCBlClCRQCmCSB/C4QCAC5BQDbI6bJmg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AcIAAQgBDtg6DdQg7DchsDDQhtDDiYCiQiXCii8B5Qi7B5jYBJQjYBIjuARQivALirgWQirgWigg1Qigg1iShRQiShQiAhqQiBhphriAQhsh/hTiTQhTiTg3iiQg2ijgYiwQgejrAdjhQAdjiBSjQQBSjPCBi1QCCi0CqiRQCqiQDNhlQDMhkDpgvQDqgtDhAOQDkAODUBFQDVBFC8B1QC9B1CbChQCbCgByDFQBxDGA+DlI7KHQg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AcHAAQAAD1g+DiQg+DihzDHQhyDHigCjQigCjjEB3QjEB3jhBDQjhBDj1AGQi2AEiuggQivgfihhAQiig/iQhcQiRhch9h1Qh9h1hliKQhliLhJidQhKicgrisQgrisgIi3QgKjzA0jlQA0jlBqjLQBqjMCYiqQCZiqC+h/QC/iADehMQDehND1gQQDzgQDlAvQDmAvDOBmQDOBmCtCUQCuCVCDC8QCEC8BRDcQBSDcAWD0I8BCbg");
	var mask_1_graphics_70 = new cjs.Graphics().p("AAA8GQD5AADlBAQDlBADJB1QDJB2CjCkQCkCjB2DJQB2DJA/DlQBADlAAD4IAAAAQAAD5hADlQg/Dlh2DJQh2DJikCjQijCkjJB2QjJB1jlBAQjlBAj5AAIAAAAQi5AAiwgkQiwgliihEQiihFiQhhQiQhhh6h7Qh7h6hhiQQhhiQhFiiQhFiigkiwQgkiwAAi6IAAAAQAAj4BAjlQA/jlB2jJQB2jJCkijQCjikDJh2QDJh1DlhAQDlhAD4AAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:172,y:90.2}).wait(1).to({graphics:mask_1_graphics_1,x:172,y:98}).wait(1).to({graphics:mask_1_graphics_2,x:172,y:105.7}).wait(1).to({graphics:mask_1_graphics_3,x:172,y:113.2}).wait(1).to({graphics:mask_1_graphics_4,x:172,y:120.4}).wait(1).to({graphics:mask_1_graphics_5,x:172,y:127.4}).wait(1).to({graphics:mask_1_graphics_6,x:172,y:134}).wait(1).to({graphics:mask_1_graphics_7,x:172,y:140.2}).wait(1).to({graphics:mask_1_graphics_8,x:172,y:146}).wait(1).to({graphics:mask_1_graphics_9,x:172,y:151.3}).wait(1).to({graphics:mask_1_graphics_10,x:172,y:156.1}).wait(1).to({graphics:mask_1_graphics_11,x:172,y:160.3}).wait(1).to({graphics:mask_1_graphics_12,x:172,y:164}).wait(1).to({graphics:mask_1_graphics_13,x:172,y:167}).wait(1).to({graphics:mask_1_graphics_14,x:172,y:169.3}).wait(1).to({graphics:mask_1_graphics_15,x:172,y:171}).wait(1).to({graphics:mask_1_graphics_16,x:172,y:172}).wait(1).to({graphics:mask_1_graphics_17,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_18,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_19,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_20,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_21,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_22,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_23,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_24,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_25,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_26,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_27,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_28,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_29,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_30,x:172,y:172.4}).wait(1).to({graphics:mask_1_graphics_31,x:169.5,y:172.4}).wait(1).to({graphics:mask_1_graphics_32,x:167.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_33,x:165.4,y:172.4}).wait(1).to({graphics:mask_1_graphics_34,x:164.4,y:172.4}).wait(1).to({graphics:mask_1_graphics_35,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_36,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_37,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_38,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_39,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_40,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_41,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_42,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_43,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_44,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_45,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_46,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_47,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_48,x:164.1,y:172.4}).wait(1).to({graphics:mask_1_graphics_49,x:164.1,y:170.2}).wait(1).to({graphics:mask_1_graphics_50,x:164.1,y:167.9}).wait(1).to({graphics:mask_1_graphics_51,x:164.1,y:166.2}).wait(1).to({graphics:mask_1_graphics_52,x:164.1,y:165.1}).wait(1).to({graphics:mask_1_graphics_53,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_54,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_55,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_56,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_57,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_58,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_59,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_60,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_61,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_62,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_63,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_64,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_65,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_66,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_67,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_68,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_69,x:164.1,y:164.8}).wait(1).to({graphics:mask_1_graphics_70,x:164.1,y:164.8}).wait(1));

	// Capa 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFA848").s().p("AmP4QIA4gOIEbg0ICqgUIEigLMgACAzjg");
	this.shape_6.setTransform(145.2,82.6,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#7B22FF").s().p("An94BIDehAMAMdAyCg");
	this.shape_7.setTransform(139.6,85,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00E250").s().p("EgJYAqgIhThQIh3h9IhMhXIiNi2IhDheIh5jEIg5hlIh7kEIh3lFIhUlPIgqkdIgRkfIAHkgIAgkdIA6kaIBllLICHk+ICKj9ICfjwIDZkNIDKjNIDbi7IDrioID2iSIE5iSIDZhPMAP8AxDMghIAnig");
	this.shape_8.setTransform(82.5,149.8,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFF48D").s().p("AIgZOIiqgfIlNhaIlBh8Ik1idIjziaIjkiwMAhJgngMgDnAzdg");
	this.shape_9.setTransform(112,247.4,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FC2A36").s().p("Ak7ZsMADngzdMAGQAzMIhzAMIisALg");
	this.shape_10.setTransform(169.4,247.6,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#34ADFE").s().p("A5yAMMAAAgzkQKDgCJfEBQJND6HQHHQHWHMECJOQEQJrgDKfIgCBzIgQDmIgqEdIhEEYIhHDbIhWDWIiBECIiWD2IjQEUIjDDUIkBDnIgtAkIjqCoIj3CSIk5CSIjYBPIlOBZIkdAwg");
	this.shape_11.setTransform(247.6,164.5,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_12.setTransform(166,83.4,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_13.setTransform(145.9,85.8,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#808080").s().p("AkBAXICqgdIiqAdIhwAZgACMgjIA5gEIBzgGIhzAGIisATgAFygvIAAABIgrABg");
	this.shape_14.setTransform(144.5,3.3,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#808080").s().p("AmO4QIA4gNIEbg1IBwgOIEggSMAA6Azkg");
	this.shape_15.setTransform(146,83.4,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#808080").ss(0.1,2).p("AGNZBMgMZgyB");
	this.shape_16.setTransform(145.9,85.8,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_17.setTransform(140.4,87.4,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#808080").s().p("AAUgFIAAABIgnAKg");
	this.shape_18.setTransform(120.5,7.4,0.5,0.5,0,0,0,-8.9,2.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#808080").s().p("An94BIDehAMAMdAyDg");
	this.shape_19.setTransform(140.4,85.9,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#808080").ss(0.1,2).p("AH9YhMgP5gxB");
	this.shape_20.setTransform(140.4,87.4,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#808080").ss(0.1,2).p("AAAZyMAAAgzi");
	this.shape_21.setTransform(166,83.4,0.5,0.5);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(71));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,577.6,330.1);


(lib.mc_p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Txts
	this.text = new cjs.Text("10", "38px Verdana");
	this.text.lineHeight = 43;
	this.text.lineWidth = 50;
	this.text.setTransform(724.1,315.9,0.5,0.5);

	this.text_1 = new cjs.Text("9", "38px Verdana");
	this.text_1.lineHeight = 43;
	this.text_1.lineWidth = 24;
	this.text_1.setTransform(697,315.9,0.5,0.5);

	this.text_2 = new cjs.Text("8", "38px Verdana");
	this.text_2.lineHeight = 43;
	this.text_2.lineWidth = 24;
	this.text_2.setTransform(663.6,315.9,0.5,0.5);

	this.text_3 = new cjs.Text("7", "38px Verdana");
	this.text_3.lineHeight = 43;
	this.text_3.lineWidth = 24;
	this.text_3.setTransform(630.1,315.9,0.5,0.5);

	this.text_4 = new cjs.Text("6", "38px Verdana");
	this.text_4.lineHeight = 43;
	this.text_4.lineWidth = 24;
	this.text_4.setTransform(596.6,315.9,0.5,0.5);

	this.text_5 = new cjs.Text("5", "38px Verdana");
	this.text_5.lineHeight = 43;
	this.text_5.lineWidth = 24;
	this.text_5.setTransform(563.2,315.9,0.5,0.5);

	this.text_6 = new cjs.Text("4", "38px Verdana");
	this.text_6.lineHeight = 43;
	this.text_6.lineWidth = 24;
	this.text_6.setTransform(529.7,315.9,0.5,0.5);

	this.text_7 = new cjs.Text("3", "38px Verdana");
	this.text_7.lineHeight = 43;
	this.text_7.lineWidth = 24;
	this.text_7.setTransform(496.2,315.9,0.5,0.5);

	this.text_8 = new cjs.Text("2", "38px Verdana");
	this.text_8.lineHeight = 43;
	this.text_8.lineWidth = 24;
	this.text_8.setTransform(462.7,315.9,0.5,0.5);

	this.text_9 = new cjs.Text("1", "38px Verdana");
	this.text_9.lineHeight = 43;
	this.text_9.lineWidth = 24;
	this.text_9.setTransform(429.3,315.9,0.5,0.5);

	this.text_10 = new cjs.Text("0", "38px Verdana");
	this.text_10.lineHeight = 43;
	this.text_10.lineWidth = 24;
	this.text_10.setTransform(395.8,315.9,0.5,0.5);

	this.text_11 = new cjs.Text("5", "38px Verdana");
	this.text_11.lineHeight = 43;
	this.text_11.lineWidth = 24;
	this.text_11.setTransform(361.4,37.2,0.5,0.5);

	this.text_12 = new cjs.Text("4,5", "38px Verdana");
	this.text_12.lineHeight = 43;
	this.text_12.lineWidth = 65;
	this.text_12.setTransform(340.8,62.9,0.5,0.5);

	this.text_13 = new cjs.Text("4", "38px Verdana");
	this.text_13.lineHeight = 43;
	this.text_13.lineWidth = 24;
	this.text_13.setTransform(361.4,88.5,0.5,0.5);

	this.text_14 = new cjs.Text("3,5", "38px Verdana");
	this.text_14.lineHeight = 43;
	this.text_14.lineWidth = 68;
	this.text_14.setTransform(339.6,114.2,0.5,0.5);

	this.text_15 = new cjs.Text("3", "38px Verdana");
	this.text_15.lineHeight = 43;
	this.text_15.lineWidth = 24;
	this.text_15.setTransform(361.4,139.8,0.5,0.5);

	this.text_16 = new cjs.Text("2,5", "38px Verdana");
	this.text_16.lineHeight = 43;
	this.text_16.lineWidth = 66;
	this.text_16.setTransform(340.4,165.5,0.5,0.5);

	this.text_17 = new cjs.Text("2", "38px Verdana");
	this.text_17.lineHeight = 43;
	this.text_17.lineWidth = 24;
	this.text_17.setTransform(361.4,191.1,0.5,0.5);

	this.text_18 = new cjs.Text("1,5", "38px Verdana");
	this.text_18.lineHeight = 43;
	this.text_18.lineWidth = 64;
	this.text_18.setTransform(341.6,216.8,0.5,0.5);

	this.text_19 = new cjs.Text("1", "38px Verdana");
	this.text_19.lineHeight = 43;
	this.text_19.lineWidth = 24;
	this.text_19.setTransform(361.4,242.4,0.5,0.5);

	this.text_20 = new cjs.Text("0,5", "38px Verdana");
	this.text_20.lineHeight = 43;
	this.text_20.lineWidth = 66;
	this.text_20.setTransform(340.4,268.1,0.5,0.5);

	this.text_21 = new cjs.Text("0", "38px Verdana");
	this.text_21.lineHeight = 43;
	this.text_21.lineWidth = 24;
	this.text_21.setTransform(361.4,293.7,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape.setTransform(751.7,308.1,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_1.setTransform(718.2,308.1,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_2.setTransform(684.8,308.1,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_3.setTransform(651.3,308.1,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_4.setTransform(617.9,308.1,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_5.setTransform(584.4,308.1,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_6.setTransform(550.8,308.1,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_7.setTransform(517.4,308.1,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_8.setTransform(483.9,308.1,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_9.setTransform(450.4,308.1,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1.3,2).p("AAAAaIAAgz");
	this.shape_10.setTransform(417,308.1,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2.5,2).p("AAAAaIAAgz");
	this.shape_11.setTransform(383.5,308.1,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2.5,2).p("Eg5gAAAMBzBAAA");
	this.shape_12.setTransform(567.6,306.8,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_13.setTransform(382.2,49,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_14.setTransform(382.2,74.8,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_15.setTransform(382.2,100.6,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_16.setTransform(382.2,126.4,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_17.setTransform(382.2,152.1,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_18.setTransform(382.2,177.9,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_19.setTransform(382.2,203.7,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_20.setTransform(382.2,229.5,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_21.setTransform(382.2,255.2,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1.3,2).p("AgYAAIAyAA");
	this.shape_22.setTransform(382.2,281,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2.5,2).p("AgYAAIAyAA");
	this.shape_23.setTransform(382.2,306.8,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2.5,2).p("EAAAgoQMAAABQh");
	this.shape_24.setTransform(383.5,177.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(800));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AAvX4MAAAgpzMA7AAAAMAAAApzg");
	mask.setTransform(382.3,152.8);

	// barra_10
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUH/IAAv9IEpAAIAAP9g");
	this.shape_25.setTransform(735.7,307.8,0.5,0.039,0,0,0,0,0.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,177.4,59.2,177.4).s().p("AhJAeIAAg7ICTAAIAAA7g");
	this.shape_26.setTransform(735.7,306.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,178.7,59.2,178.7).s().p("AhJAqIAAhTICTAAIAABTg");
	this.shape_27.setTransform(735.7,305.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,180,59.2,180).s().p("AhJA1IAAhpICTAAIAABpg");
	this.shape_28.setTransform(735.7,303.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,181.3,59.2,181.3).s().p("AhJBAIAAh/ICTAAIAAB/g");
	this.shape_29.setTransform(735.7,302.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,182.6,59.2,182.6).s().p("AhJBLIAAiVICTAAIAACVg");
	this.shape_30.setTransform(735.7,301.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,183.9,59.2,183.9).s().p("AhJBXIAAitICTAAIAACtg");
	this.shape_31.setTransform(735.7,300);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,185.1,59.2,185.1).s().p("AhJBiIAAjDICTAAIAADDg");
	this.shape_32.setTransform(735.7,298.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,186.4,59.2,186.4).s().p("AhJBtIAAjZICTAAIAADZg");
	this.shape_33.setTransform(735.7,297.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,187.7,59.2,187.7).s().p("AhJB4IAAjvICTAAIAADvg");
	this.shape_34.setTransform(735.7,296.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,189,59.2,189).s().p("AhJCEIAAkHICTAAIAAEHg");
	this.shape_35.setTransform(735.7,294.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,190.3,59.2,190.3).s().p("AhJCPIAAkdICTAAIAAEdg");
	this.shape_36.setTransform(735.7,293.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,191.6,59.2,191.6).s().p("AhJCaIAAkzICTAAIAAEzg");
	this.shape_37.setTransform(735.7,292.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,192.9,59.2,192.9).s().p("AhJClIAAlJICTAAIAAFJg");
	this.shape_38.setTransform(735.7,291);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,194.2,59.2,194.2).s().p("AhJCxIAAlhICTAAIAAFhg");
	this.shape_39.setTransform(735.7,289.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,195.4,59.2,195.4).s().p("AhJC8IAAl3ICTAAIAAF3g");
	this.shape_40.setTransform(735.7,288.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,196.7,59.2,196.7).s().p("AhJDHIAAmNICTAAIAAGNg");
	this.shape_41.setTransform(735.7,287.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,198,59.2,198).s().p("AhJDSIAAmjICTAAIAAGjg");
	this.shape_42.setTransform(735.7,285.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,199.3,59.2,199.3).s().p("AhJDeIAAm7ICTAAIAAG7g");
	this.shape_43.setTransform(735.7,284.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,200.6,59.2,200.6).s().p("AhJDpIAAnRICTAAIAAHRg");
	this.shape_44.setTransform(735.7,283.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#FF7F18","#A5010C"],[0,1],29.2,201.9,59.2,201.9).s().p("AhJD0IAAnnICTAAIAAHng");
	this.shape_45.setTransform(735.7,282);

	this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25,p:{regY:0.3,scaleY:0.039,y:307.8}}]}).to({state:[{t:this.shape_25,p:{regY:0.3,scaleY:0.039,y:307.8}}]},461).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_25,p:{regY:0,scaleY:0.5,y:280.7}}]},1).wait(318));

	// barra_09
	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUQDMAAAggFIEpAAMAAAAgFg");
	this.shape_46.setTransform(702.6,308.3,0.5,0.021,0,0,0,0.1,-0.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,127,26.1,127).s().p("AhKAxIAAhhICUAAIAABhg");
	this.shape_47.setTransform(702.6,305.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,129.9,26.1,129.9).s().p("AhKBNIAAiZICUAAIAACZg");
	this.shape_48.setTransform(702.6,302.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,132.8,26.1,132.8).s().p("AhKBpIAAjRICUAAIAADRg");
	this.shape_49.setTransform(702.6,299.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,135.7,26.1,135.7).s().p("AhKCFIAAkJICUAAIAAEJg");
	this.shape_50.setTransform(702.6,296.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,138.6,26.1,138.6).s().p("AhKChIAAlBICUAAIAAFBg");
	this.shape_51.setTransform(702.6,293.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,141.5,26.1,141.5).s().p("AhKC9IAAl4ICUAAIAAF4g");
	this.shape_52.setTransform(702.6,290.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,144.4,26.1,144.4).s().p("AhKDYIAAmvICUAAIAAGvg");
	this.shape_53.setTransform(702.6,287.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,147.3,26.1,147.3).s().p("AhKD0IAAnnICUAAIAAHng");
	this.shape_54.setTransform(702.6,285);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,150.3,26.1,150.3).s().p("AhKEQIAAofICUAAIAAIfg");
	this.shape_55.setTransform(702.6,282.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,153.2,26.1,153.2).s().p("AhKEsIAApXICUAAIAAJXg");
	this.shape_56.setTransform(702.6,279.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,156.1,26.1,156.1).s().p("AhKFIIAAqPICUAAIAAKPg");
	this.shape_57.setTransform(702.6,276.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,159,26.1,159).s().p("AhKFkIAArGICUAAIAALGg");
	this.shape_58.setTransform(702.6,273.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,161.9,26.1,161.9).s().p("AhKF/IAAr9ICUAAIAAL9g");
	this.shape_59.setTransform(702.6,270.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,164.8,26.1,164.8).s().p("AhKGbIAAs1ICUAAIAAM1g");
	this.shape_60.setTransform(702.6,267.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,167.7,26.1,167.7).s().p("AhKG3IAAttICUAAIAANtg");
	this.shape_61.setTransform(702.6,264.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,170.6,26.1,170.6).s().p("AhKHTIAAulICUAAIAAOlg");
	this.shape_62.setTransform(702.6,261.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#FF7F18","#A5010C"],[0,1],-3.8,173.5,26.1,173.5).s().p("AhKHvIAAvdICUAAIAAPdg");
	this.shape_63.setTransform(702.6,258.8);

	this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_46,p:{regX:0.1,regY:-0.1,scaleY:0.021,y:308.3}}]}).to({state:[{t:this.shape_46,p:{regX:0.1,regY:-0.1,scaleY:0.021,y:308.3}}]},419).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_46,p:{regX:0,regY:0,scaleY:0.509,y:255.8}}]},1).wait(363));

	// barra_08
	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUQDMAAAggFIEpAAMAAAAgFg");
	this.shape_64.setTransform(669.1,307.4,0.5,0.018,0,0,0,0,-1.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,127.5,-7.3,127.5).s().p("AhJApIAAhRICTAAIAABRg");
	this.shape_65.setTransform(669.1,304.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,130,-7.3,130).s().p("AhJBBIAAiBICTAAIAACBg");
	this.shape_66.setTransform(669.1,302.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,132.5,-7.3,132.5).s().p("AhJBYIAAivICTAAIAACvg");
	this.shape_67.setTransform(669.1,299.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,135,-7.3,135).s().p("AhJBwIAAjfICTAAIAADfg");
	this.shape_68.setTransform(669.1,297.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,137.5,-7.3,137.5).s().p("AhJCIIAAkPICTAAIAAEPg");
	this.shape_69.setTransform(669.1,294.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,140,-7.3,140).s().p("AhJCfIAAk9ICTAAIAAE9g");
	this.shape_70.setTransform(669.1,292.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,142.5,-7.3,142.5).s().p("AhJC3IAAltICTAAIAAFtg");
	this.shape_71.setTransform(669.1,289.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,145,-7.3,145).s().p("AhJDOIAAmbICTAAIAAGbg");
	this.shape_72.setTransform(669.1,287.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,147.5,-7.3,147.5).s().p("AhJDmIAAnLICTAAIAAHLg");
	this.shape_73.setTransform(669.1,284.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,150,-7.3,150).s().p("AhJD+IAAn7ICTAAIAAH7g");
	this.shape_74.setTransform(669.1,282.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,152.5,-7.3,152.5).s().p("AhJEVIAAopICTAAIAAIpg");
	this.shape_75.setTransform(669.1,279.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,155,-7.3,155).s().p("AhJEtIAApZICTAAIAAJZg");
	this.shape_76.setTransform(669.1,277.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,157.5,-7.3,157.5).s().p("AhJFEIAAqHICTAAIAAKHg");
	this.shape_77.setTransform(669.1,274.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,160,-7.3,160).s().p("AhJFcIAAq3ICTAAIAAK3g");
	this.shape_78.setTransform(669.1,272.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,162.4,-7.3,162.4).s().p("AhJF0IAArnICTAAIAALng");
	this.shape_79.setTransform(669.1,270);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,164.9,-7.3,164.9).s().p("AhJGLIAAsVICTAAIAAMVg");
	this.shape_80.setTransform(669.1,267.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,167.4,-7.3,167.4).s().p("AhJGjIAAtFICTAAIAANFg");
	this.shape_81.setTransform(669.1,265);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,169.9,-7.3,169.9).s().p("AhJG6IAAtzICTAAIAANzg");
	this.shape_82.setTransform(669.1,262.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,172.4,-7.3,172.4).s().p("AhJHSIAAujICTAAIAAOjg");
	this.shape_83.setTransform(669.1,260);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#FF7F18","#A5010C"],[0,1],-37.3,174.9,-7.3,174.9).s().p("AhJHqIAAvTICTAAIAAPTg");
	this.shape_84.setTransform(669.1,257.5);

	this.shape_64.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = this.shape_69.mask = this.shape_70.mask = this.shape_71.mask = this.shape_72.mask = this.shape_73.mask = this.shape_74.mask = this.shape_75.mask = this.shape_76.mask = this.shape_77.mask = this.shape_78.mask = this.shape_79.mask = this.shape_80.mask = this.shape_81.mask = this.shape_82.mask = this.shape_83.mask = this.shape_84.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_64,p:{regY:-1.3,scaleY:0.018,y:307.4}}]}).to({state:[{t:this.shape_64,p:{regY:-1.3,scaleY:0.018,y:307.4}}]},373).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_64,p:{regY:0,scaleY:0.5,y:255}}]},1).wait(406));

	// barra_07
	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("EgCVAgLMAAAhAVIErAAMAAABAVg");
	this.shape_85.setTransform(635.1,308.1,0.5,0.008,0,0,0,0,-0.8);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,25.7,-41.3,25.7).s().p("AhKA8IAAh3ICUAAIAAB3g");
	this.shape_86.setTransform(635.1,303.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,30.3,-41.3,30.3).s().p("AhKBoIAAjPICUAAIAADPg");
	this.shape_87.setTransform(635.1,298.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,34.8,-41.3,34.8).s().p("AhKCUIAAknICUAAIAAEng");
	this.shape_88.setTransform(635.1,294.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,39.4,-41.3,39.4).s().p("AhKDAIAAl/ICUAAIAAF/g");
	this.shape_89.setTransform(635.1,289.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,43.9,-41.3,43.9).s().p("AhKDsIAAnXICUAAIAAHXg");
	this.shape_90.setTransform(635.1,285.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,48.5,-41.3,48.5).s().p("AhKEYIAAovICUAAIAAIvg");
	this.shape_91.setTransform(635.1,280.7);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,53,-41.3,53).s().p("AhKFEIAAqHICUAAIAAKHg");
	this.shape_92.setTransform(635.1,276.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,57.6,-41.3,57.6).s().p("AhKFwIAArfICUAAIAALfg");
	this.shape_93.setTransform(635.1,271.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,62.1,-41.3,62.1).s().p("AhKGcIAAs3ICUAAIAAM3g");
	this.shape_94.setTransform(635.1,267.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,66.7,-41.3,66.7).s().p("AhKHIIAAuPICUAAIAAOPg");
	this.shape_95.setTransform(635.1,262.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,71.2,-41.3,71.2).s().p("AhKH0IAAvnICUAAIAAPng");
	this.shape_96.setTransform(635.1,258);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,75.8,-41.3,75.8).s().p("AhKIgIAAw/ICUAAIAAQ/g");
	this.shape_97.setTransform(635.1,253.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,80.3,-41.3,80.3).s().p("AhKJMIAAyXICUAAIAASXg");
	this.shape_98.setTransform(635.1,248.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,84.9,-41.3,84.9).s().p("AhKJ5IAAzxICUAAIAATxg");
	this.shape_99.setTransform(635.1,244.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,89.4,-41.3,89.4).s().p("AhKKlIAA1JICUAAIAAVJg");
	this.shape_100.setTransform(635.1,239.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,94,-41.3,94).s().p("AhKLRIAA2hICUAAIAAWhg");
	this.shape_101.setTransform(635.1,235.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,98.5,-41.3,98.5).s().p("AhKL9IAA35ICUAAIAAX5g");
	this.shape_102.setTransform(635.1,230.7);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,103.1,-41.3,103.1).s().p("AhKMpIAA5RICUAAIAAZRg");
	this.shape_103.setTransform(635.1,226.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,107.6,-41.3,107.6).s().p("AhKNVIAA6pICUAAIAAapg");
	this.shape_104.setTransform(635.1,221.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,112.2,-41.3,112.2).s().p("AhKOBIAA8BICUAAIAAcBg");
	this.shape_105.setTransform(635.1,217);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,116.7,-41.3,116.7).s().p("AhKOtIAA9ZICUAAIAAdZg");
	this.shape_106.setTransform(635.1,212.5);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["#FF7F18","#A5010C"],[0,1],-71.3,121.3,-41.3,121.3).s().p("AhKPZIAA+xICUAAIAAexg");
	this.shape_107.setTransform(635.1,207.9);

	this.shape_85.mask = this.shape_86.mask = this.shape_87.mask = this.shape_88.mask = this.shape_89.mask = this.shape_90.mask = this.shape_91.mask = this.shape_92.mask = this.shape_93.mask = this.shape_94.mask = this.shape_95.mask = this.shape_96.mask = this.shape_97.mask = this.shape_98.mask = this.shape_99.mask = this.shape_100.mask = this.shape_101.mask = this.shape_102.mask = this.shape_103.mask = this.shape_104.mask = this.shape_105.mask = this.shape_106.mask = this.shape_107.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_85,p:{regY:-0.8,scaleY:0.008,y:308.1}}]}).to({state:[{t:this.shape_85,p:{regY:-0.8,scaleY:0.008,y:308.1}}]},323).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_85,p:{regY:0,scaleY:0.5,y:203.4}}]},1).wait(454));

	// barra_06
	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("EgCUAoLMAAAhQVIEpAAMAAABQVg");
	this.shape_108.setTransform(601.6,308.8,0.5,0.005,0,0,0,0,-2.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,-24.1,-74.8,-24.1).s().p("AhKBNIAAiZICVAAIAACZg");
	this.shape_109.setTransform(601.6,302.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,-17.6,-74.8,-17.6).s().p("AhKCNIAAkZICVAAIAAEZg");
	this.shape_110.setTransform(601.6,295.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,-11,-74.8,-11).s().p("AhKDMIAAmXICVAAIAAGXg");
	this.shape_111.setTransform(601.6,289.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,-4.5,-74.8,-4.5).s().p("AhKEMIAAoXICVAAIAAIXg");
	this.shape_112.setTransform(601.6,282.6);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,2,-74.8,2).s().p("AhKFLIAAqVICVAAIAAKVg");
	this.shape_113.setTransform(601.6,276);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,8.5,-74.8,8.5).s().p("AhKGLIAAsVICVAAIAAMVg");
	this.shape_114.setTransform(601.6,269.5);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,15.1,-74.8,15.1).s().p("AhKHLIAAuVICVAAIAAOVg");
	this.shape_115.setTransform(601.6,262.9);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,21.6,-74.8,21.6).s().p("AhKIKIAAwTICVAAIAAQTg");
	this.shape_116.setTransform(601.6,256.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,28.2,-74.8,28.2).s().p("AhKJKIAAyTICVAAIAASTg");
	this.shape_117.setTransform(601.6,249.8);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,34.7,-74.8,34.7).s().p("AhKKJIAA0RICVAAIAAURg");
	this.shape_118.setTransform(601.6,243.3);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,41.3,-74.8,41.3).s().p("AhKLJIAA2RICVAAIAAWRg");
	this.shape_119.setTransform(601.6,236.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,47.8,-74.8,47.8).s().p("AhKMIIAA4PICVAAIAAYPg");
	this.shape_120.setTransform(601.6,230.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,54.4,-74.8,54.4).s().p("AhKNIIAA6PICVAAIAAaPg");
	this.shape_121.setTransform(601.6,223.6);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,60.9,-74.8,60.9).s().p("AhKOIIAA8PICVAAIAAcPg");
	this.shape_122.setTransform(601.6,217.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,67.5,-74.8,67.5).s().p("AhKPHIAA+NICVAAIAAeNg");
	this.shape_123.setTransform(601.6,210.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,74,-74.8,74).s().p("AhKQHMAAAggNICVAAMAAAAgNg");
	this.shape_124.setTransform(601.6,204);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,80.6,-74.8,80.6).s().p("AhKRGMAAAgiLICVAAMAAAAiLg");
	this.shape_125.setTransform(601.6,197.4);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,87.1,-74.8,87.1).s().p("AhKSGMAAAgkLICVAAMAAAAkLg");
	this.shape_126.setTransform(601.6,190.9);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["#FF7F18","#A5010C"],[0,1],-104.8,93.7,-74.8,93.7).s().p("AhKTFMAAAgmJICVAAMAAAAmJg");
	this.shape_127.setTransform(601.6,184.3);

	this.shape_108.mask = this.shape_109.mask = this.shape_110.mask = this.shape_111.mask = this.shape_112.mask = this.shape_113.mask = this.shape_114.mask = this.shape_115.mask = this.shape_116.mask = this.shape_117.mask = this.shape_118.mask = this.shape_119.mask = this.shape_120.mask = this.shape_121.mask = this.shape_122.mask = this.shape_123.mask = this.shape_124.mask = this.shape_125.mask = this.shape_126.mask = this.shape_127.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_108,p:{regY:-2.5,scaleY:0.005,y:308.8}}]}).to({state:[{t:this.shape_108,p:{regY:-2.5,scaleY:0.005,y:308.8}}]},277).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_108,p:{regY:0,scaleY:0.5,y:177.7}}]},1).wait(503));

	// barra_05
	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("EgCUAgHMAAAhANIEpAAMAAABANg");
	this.shape_128.setTransform(568.1,308.5,0.5,0.006,0,0,0,0.1,0.5);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,25.8,-108.3,25.8).s().p("AhJA6IAAhzICUAAIAABzg");
	this.shape_129.setTransform(568.1,303.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,30.6,-108.3,30.6).s().p("AhJBoIAAjPICUAAIAADPg");
	this.shape_130.setTransform(568.1,298.9);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,35.4,-108.3,35.4).s().p("AhJCXIAAktICUAAIAAEtg");
	this.shape_131.setTransform(568.1,294.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,40.2,-108.3,40.2).s().p("AhJDFIAAmJICUAAIAAGJg");
	this.shape_132.setTransform(568.1,289.4);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,44.9,-108.3,44.9).s().p("AhJDzIAAnlICUAAIAAHlg");
	this.shape_133.setTransform(568.1,284.6);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,49.7,-108.3,49.7).s().p("AhJEhIAApBICUAAIAAJBg");
	this.shape_134.setTransform(568.1,279.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,54.5,-108.3,54.5).s().p("AhJFPIAAqdICUAAIAAKdg");
	this.shape_135.setTransform(568.1,275.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,59.2,-108.3,59.2).s().p("AhJF9IAAr5ICUAAIAAL5g");
	this.shape_136.setTransform(568.1,270.3);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,64,-108.3,64).s().p("AhJGrIAAtVICUAAIAANVg");
	this.shape_137.setTransform(568.1,265.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,68.8,-108.3,68.8).s().p("AhJHZIAAuxICUAAIAAOxg");
	this.shape_138.setTransform(568.1,260.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,73.5,-108.3,73.5).s().p("AhJIIIAAwPICUAAIAAQPg");
	this.shape_139.setTransform(568.1,256);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,78.3,-108.3,78.3).s().p("AhJI2IAAxrICUAAIAARrg");
	this.shape_140.setTransform(568.1,251.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,83.1,-108.3,83.1).s().p("AhJJkIAAzHICUAAIAATHg");
	this.shape_141.setTransform(568.1,246.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,87.8,-108.3,87.8).s().p("AhJKSIAA0jICUAAIAAUjg");
	this.shape_142.setTransform(568.1,241.7);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,92.6,-108.3,92.6).s().p("AhJLAIAA1/ICUAAIAAV/g");
	this.shape_143.setTransform(568.1,236.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,97.4,-108.3,97.4).s().p("AhJLuIAA3bICUAAIAAXbg");
	this.shape_144.setTransform(568.1,232.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,102.2,-108.3,102.2).s().p("AhJMcIAA43ICUAAIAAY3g");
	this.shape_145.setTransform(568.1,227.4);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,106.9,-108.3,106.9).s().p("AhJNKIAA6TICUAAIAAaTg");
	this.shape_146.setTransform(568.1,222.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,111.7,-108.3,111.7).s().p("AhJN5IAA7xICUAAIAAbxg");
	this.shape_147.setTransform(568.1,217.9);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,116.5,-108.3,116.5).s().p("AhJOnIAA9NICUAAIAAdNg");
	this.shape_148.setTransform(568.1,213.1);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["#FF7F18","#A5010C"],[0,1],-138.3,121.2,-108.3,121.2).s().p("AhJPVIAA+pICUAAIAAepg");
	this.shape_149.setTransform(568.1,208.3);

	this.shape_128.mask = this.shape_129.mask = this.shape_130.mask = this.shape_131.mask = this.shape_132.mask = this.shape_133.mask = this.shape_134.mask = this.shape_135.mask = this.shape_136.mask = this.shape_137.mask = this.shape_138.mask = this.shape_139.mask = this.shape_140.mask = this.shape_141.mask = this.shape_142.mask = this.shape_143.mask = this.shape_144.mask = this.shape_145.mask = this.shape_146.mask = this.shape_147.mask = this.shape_148.mask = this.shape_149.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_128,p:{regX:0.1,regY:0.5,scaleY:0.006,y:308.5}}]}).to({state:[{t:this.shape_128,p:{regX:0.1,regY:0.5,scaleY:0.006,y:308.5}}]},221).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_128,p:{regX:0,regY:0,scaleY:0.5,y:203.5}}]},1).wait(557));

	// barra_04
	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUQDMAAAggFIEpAAMAAAAgFg");
	this.shape_150.setTransform(534.7,308.6,0.5,0.013,0,0,0,0,-1.4);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,126.7,-141.9,126.7).s().p("AhKAoIAAhPICUAAIAABPg");
	this.shape_151.setTransform(534.7,305.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,129.7,-141.9,129.7).s().p("AhKBEIAAiHICVAAIAACHg");
	this.shape_152.setTransform(534.7,302.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,132.7,-141.9,132.7).s().p("AhKBgIAAi/ICVAAIAAC/g");
	this.shape_153.setTransform(534.7,299.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,135.7,-141.9,135.7).s().p("AhJB8IAAj3ICTAAIAAD3g");
	this.shape_154.setTransform(534.7,296.6);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,138.6,-141.9,138.6).s().p("AhKCYIAAkvICUAAIAAEvg");
	this.shape_155.setTransform(534.7,293.7);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,141.6,-141.9,141.6).s().p("AhKCzIAAllICVAAIAAFlg");
	this.shape_156.setTransform(534.7,290.7);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,144.6,-141.9,144.6).s().p("AhKDPIAAmdICVAAIAAGdg");
	this.shape_157.setTransform(534.6,287.7);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,147.6,-141.9,147.6).s().p("AhJDrIAAnVICTAAIAAHVg");
	this.shape_158.setTransform(534.6,284.7);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,150.6,-141.9,150.6).s().p("AhKEHIAAoNICUAAIAAINg");
	this.shape_159.setTransform(534.6,281.7);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,153.5,-141.9,153.5).s().p("AhKEjIAApFICVAAIAAJFg");
	this.shape_160.setTransform(534.6,278.8);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,156.5,-141.9,156.5).s().p("AhJE/IAAp9ICUAAIAAJ9g");
	this.shape_161.setTransform(534.6,275.8);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.9,159.5,-141.9,159.5).s().p("AhJFaIAAqzICTAAIAAKzg");
	this.shape_162.setTransform(534.6,272.8);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.8,162.5,-141.8,162.5).s().p("AhKF2IAArrICUAAIAALrg");
	this.shape_163.setTransform(534.6,269.8);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.8,165.5,-141.8,165.5).s().p("AhKGSIAAsjICVAAIAAMjg");
	this.shape_164.setTransform(534.6,266.8);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.8,168.4,-141.8,168.4).s().p("AhJGuIAAtbICUAAIAANbg");
	this.shape_165.setTransform(534.6,263.9);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.8,171.4,-141.8,171.4).s().p("AhJHKIAAuTICTAAIAAOTg");
	this.shape_166.setTransform(534.6,260.9);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["#FF7F18","#A5010C"],[0,1],-171.8,174.4,-141.8,174.4).s().p("AhKHlIAAvJICUAAIAAPJg");
	this.shape_167.setTransform(534.6,257.9);

	this.shape_150.mask = this.shape_151.mask = this.shape_152.mask = this.shape_153.mask = this.shape_154.mask = this.shape_155.mask = this.shape_156.mask = this.shape_157.mask = this.shape_158.mask = this.shape_159.mask = this.shape_160.mask = this.shape_161.mask = this.shape_162.mask = this.shape_163.mask = this.shape_164.mask = this.shape_165.mask = this.shape_166.mask = this.shape_167.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_150,p:{regY:-1.4,scaleY:0.013,x:534.7,y:308.6}}]}).to({state:[{t:this.shape_150,p:{regY:-1.4,scaleY:0.013,x:534.7,y:308.6}}]},172).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_150,p:{regY:0,scaleY:0.5,x:534.6,y:254.9}}]},1).wait(610));

	// barra_03
	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUQDMAAAggFIEpAAMAAAAgFg");
	this.shape_168.setTransform(502,308.7,0.5,0.014,0,0,0,0.1,-0.5);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,127.3,-174.5,127.3).s().p("AhJAwIAAhfICUAAIAABfg");
	this.shape_169.setTransform(502,305.1);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,130.9,-174.5,130.9).s().p("AhJBRIAAihICUAAIAAChg");
	this.shape_170.setTransform(502,301.5);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,134.5,-174.5,134.5).s().p("AhJByIAAjjICUAAIAADjg");
	this.shape_171.setTransform(502,297.9);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,138,-174.5,138).s().p("AhJCTIAAklICUAAIAAElg");
	this.shape_172.setTransform(502,294.4);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,141.6,-174.5,141.6).s().p("AhJC1IAAlpICUAAIAAFpg");
	this.shape_173.setTransform(502,290.8);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,145.2,-174.5,145.2).s().p("AhJDWIAAmrICUAAIAAGrg");
	this.shape_174.setTransform(502,287.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,148.8,-174.5,148.8).s().p("AhJD3IAAntICUAAIAAHtg");
	this.shape_175.setTransform(502,283.6);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,152.4,-174.5,152.4).s().p("AhJEYIAAovICUAAIAAIvg");
	this.shape_176.setTransform(502,280);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,155.9,-174.5,155.9).s().p("AhJE6IAApzICUAAIAAJzg");
	this.shape_177.setTransform(502,276.5);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,159.5,-174.5,159.5).s().p("AhJFbIAAq1ICUAAIAAK1g");
	this.shape_178.setTransform(502,272.9);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,163.1,-174.5,163.1).s().p("AhJF8IAAr3ICUAAIAAL3g");
	this.shape_179.setTransform(502,269.3);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,166.7,-174.5,166.7).s().p("AhJGdIAAs5ICUAAIAAM5g");
	this.shape_180.setTransform(502,265.7);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,170.3,-174.5,170.3).s().p("AhJG/IAAt9ICUAAIAAN9g");
	this.shape_181.setTransform(502,262.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#FF7F18","#A5010C"],[0,1],-204.5,173.8,-174.5,173.8).s().p("AhJHgIAAu/ICUAAIAAO/g");
	this.shape_182.setTransform(502,258.6);

	this.shape_168.mask = this.shape_169.mask = this.shape_170.mask = this.shape_171.mask = this.shape_172.mask = this.shape_173.mask = this.shape_174.mask = this.shape_175.mask = this.shape_176.mask = this.shape_177.mask = this.shape_178.mask = this.shape_179.mask = this.shape_180.mask = this.shape_181.mask = this.shape_182.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_168,p:{regX:0.1,regY:-0.5,scaleY:0.014,x:502,y:308.7}}]}).to({state:[{t:this.shape_168,p:{regX:0.1,regY:-0.5,scaleY:0.014,x:502,y:308.7}}]},129).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_168,p:{regX:0,regY:0,scaleY:0.5,x:501.9,y:255}}]},1).wait(656));

	// barra_02
	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUQDMAAAggFIEpAAMAAAAgFg");
	this.shape_183.setTransform(467.7,308.4,0.5,0.019,0,0,0,0,-0.5);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,128.1,-208.7,128.1).s().p("AhKA0IAAhnICUAAIAABng");
	this.shape_184.setTransform(467.7,304.8);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,131.6,-208.7,131.6).s().p("AhKBVIAAipICUAAIAACpg");
	this.shape_185.setTransform(467.7,301.3);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,135.2,-208.7,135.2).s().p("AhKB2IAAjrICUAAIAADrg");
	this.shape_186.setTransform(467.7,297.7);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,138.7,-208.7,138.7).s().p("AhKCXIAAktICUAAIAAEtg");
	this.shape_187.setTransform(467.7,294.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,142.2,-208.7,142.2).s().p("AhKC4IAAlvICUAAIAAFvg");
	this.shape_188.setTransform(467.7,290.7);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,145.8,-208.7,145.8).s().p("AhKDZIAAmxICUAAIAAGxg");
	this.shape_189.setTransform(467.7,287.1);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,149.3,-208.7,149.3).s().p("AhKD6IAAnzICUAAIAAHzg");
	this.shape_190.setTransform(467.7,283.6);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,152.9,-208.7,152.9).s().p("AhKEaIAAozICUAAIAAIzg");
	this.shape_191.setTransform(467.7,280);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,156.4,-208.7,156.4).s().p("AhKE7IAAp1ICUAAIAAJ1g");
	this.shape_192.setTransform(467.7,276.5);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,160,-208.7,160).s().p("AhKFcIAAq3ICUAAIAAK3g");
	this.shape_193.setTransform(467.7,272.9);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,163.5,-208.7,163.5).s().p("AhKF9IAAr5ICUAAIAAL5g");
	this.shape_194.setTransform(467.7,269.4);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,167,-208.7,167).s().p("AhKGeIAAs7ICUAAIAAM7g");
	this.shape_195.setTransform(467.7,265.9);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,170.6,-208.7,170.6).s().p("AhKG/IAAt9ICUAAIAAN9g");
	this.shape_196.setTransform(467.7,262.3);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.lf(["#FF7F18","#A5010C"],[0,1],-238.7,174.1,-208.7,174.1).s().p("AhKHgIAAu/ICUAAIAAO/g");
	this.shape_197.setTransform(467.7,258.8);

	this.shape_183.mask = this.shape_184.mask = this.shape_185.mask = this.shape_186.mask = this.shape_187.mask = this.shape_188.mask = this.shape_189.mask = this.shape_190.mask = this.shape_191.mask = this.shape_192.mask = this.shape_193.mask = this.shape_194.mask = this.shape_195.mask = this.shape_196.mask = this.shape_197.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_183,p:{regY:-0.5,scaleY:0.019,y:308.4}}]}).to({state:[{t:this.shape_183,p:{regY:-0.5,scaleY:0.019,y:308.4}}]},80).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_183,p:{regY:0,scaleY:0.5,y:255.2}}]},1).wait(705));

	// barra_01
	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.lf(["#FF7F18","#A5010C"],[0,1],-14.9,0,15,0).s().p("AiUIDIAAwGIEpAAIAAQGg");
	this.shape_198.setTransform(434.2,307.2,0.5,0.03);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,177.9,-242.2,177.9).s().p("AhJAeIAAg7ICTAAIAAA7g");
	this.shape_199.setTransform(434.2,305.6);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,179.6,-242.2,179.6).s().p("AhJAuIAAhbICTAAIAABbg");
	this.shape_200.setTransform(434.2,303.9);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,181.2,-242.2,181.2).s().p("AhJA9IAAh5ICTAAIAAB5g");
	this.shape_201.setTransform(434.2,302.2);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,182.9,-242.2,182.9).s().p("AhJBMIAAiXICTAAIAACXg");
	this.shape_202.setTransform(434.2,300.5);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,184.6,-242.2,184.6).s().p("AhJBbIAAi1ICTAAIAAC1g");
	this.shape_203.setTransform(434.2,298.9);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,186.2,-242.2,186.2).s().p("AhJBqIAAjTICTAAIAADTg");
	this.shape_204.setTransform(434.2,297.2);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,187.9,-242.2,187.9).s().p("AhJB5IAAjxICTAAIAADxg");
	this.shape_205.setTransform(434.2,295.5);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,189.6,-242.2,189.6).s().p("AhJCIIAAkPICTAAIAAEPg");
	this.shape_206.setTransform(434.2,293.9);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,191.3,-242.2,191.3).s().p("AhJCYIAAkvICTAAIAAEvg");
	this.shape_207.setTransform(434.2,292.2);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,192.9,-242.2,192.9).s().p("AhJCnIAAlNICTAAIAAFNg");
	this.shape_208.setTransform(434.2,290.5);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,194.6,-242.2,194.6).s().p("AhJC2IAAlrICTAAIAAFrg");
	this.shape_209.setTransform(434.2,288.9);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,196.3,-242.2,196.3).s().p("AhJDFIAAmJICTAAIAAGJg");
	this.shape_210.setTransform(434.2,287.2);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,197.9,-242.2,197.9).s().p("AhJDUIAAmnICTAAIAAGng");
	this.shape_211.setTransform(434.2,285.5);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,199.6,-242.2,199.6).s().p("AhJDjIAAnFICTAAIAAHFg");
	this.shape_212.setTransform(434.2,283.8);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.lf(["#FF7F18","#A5010C"],[0,1],-272.2,201.3,-242.2,201.3).s().p("AhJDyIAAnjICTAAIAAHjg");
	this.shape_213.setTransform(434.2,282.2);

	this.shape_198.mask = this.shape_199.mask = this.shape_200.mask = this.shape_201.mask = this.shape_202.mask = this.shape_203.mask = this.shape_204.mask = this.shape_205.mask = this.shape_206.mask = this.shape_207.mask = this.shape_208.mask = this.shape_209.mask = this.shape_210.mask = this.shape_211.mask = this.shape_212.mask = this.shape_213.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_198,p:{scaleY:0.03,y:307.2}}]}).to({state:[{t:this.shape_198,p:{scaleY:0.03,y:307.2}}]},29).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_198,p:{scaleY:0.5,y:280.5}}]},1).wait(755));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A6lA6IAAhzMA1LAAAIAABzg");
	var mask_1_graphics_1 = new cjs.Graphics().p("A6lBEIAAiHMA1LAAAIAACHg");
	var mask_1_graphics_2 = new cjs.Graphics().p("A6lBOIAAibMA1LAAAIAACbg");
	var mask_1_graphics_3 = new cjs.Graphics().p("A6lBXIAAitMA1LAAAIAACtg");
	var mask_1_graphics_4 = new cjs.Graphics().p("A6lBhIAAjBMA1LAAAIAADBg");
	var mask_1_graphics_5 = new cjs.Graphics().p("A6lBrIAAjVMA1LAAAIAADVg");
	var mask_1_graphics_6 = new cjs.Graphics().p("A6lB1IAAjpMA1LAAAIAADpg");
	var mask_1_graphics_7 = new cjs.Graphics().p("A6lB/IAAj9MA1LAAAIAAD9g");
	var mask_1_graphics_8 = new cjs.Graphics().p("A6lCJIAAkRMA1LAAAIAAERg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A6lCSIAAkjMA1LAAAIAAEjg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A6lCcIAAk3MA1LAAAIAAE3g");
	var mask_1_graphics_11 = new cjs.Graphics().p("A6lCmIAAlLMA1LAAAIAAFLg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A6lCwIAAlfMA1LAAAIAAFfg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A6lC6IAAlzMA1LAAAIAAFzg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A6lDDIAAmFMA1LAAAIAAGFg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A6lDNIAAmZMA1LAAAIAAGZg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A6lDXIAAmtMA1LAAAIAAGtg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A6lDhIAAnBMA1LAAAIAAHBg");
	var mask_1_graphics_18 = new cjs.Graphics().p("A6lDrIAAnVMA1LAAAIAAHVg");
	var mask_1_graphics_19 = new cjs.Graphics().p("A6lD0IAAnnMA1LAAAIAAHng");
	var mask_1_graphics_20 = new cjs.Graphics().p("A6lD+IAAn7MA1LAAAIAAH7g");
	var mask_1_graphics_21 = new cjs.Graphics().p("A6lEIIAAoPMA1LAAAIAAIPg");
	var mask_1_graphics_22 = new cjs.Graphics().p("A6lESIAAojMA1LAAAIAAIjg");
	var mask_1_graphics_23 = new cjs.Graphics().p("A6lEcIAAo3MA1LAAAIAAI3g");
	var mask_1_graphics_50 = new cjs.Graphics().p("A6lEcIAAo3MA1LAAAIAAI3g");
	var mask_1_graphics_51 = new cjs.Graphics().p("A6lEjIAApFMA1LAAAIAAJFg");
	var mask_1_graphics_52 = new cjs.Graphics().p("A6lErIAApVMA1LAAAIAAJVg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A6lEyIAApjMA1LAAAIAAJjg");
	var mask_1_graphics_54 = new cjs.Graphics().p("A6lE6IAApzMA1LAAAIAAJzg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A6lFBIAAqBMA1LAAAIAAKBg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A6lFJIAAqRMA1LAAAIAAKRg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A6lFQIAAqfMA1LAAAIAAKfg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A6lFYIAAqvMA1LAAAIAAKvg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A6lFgIAAq/MA1LAAAIAAK/g");
	var mask_1_graphics_60 = new cjs.Graphics().p("A6lFnIAArNMA1LAAAIAALNg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A6lFvIAArdMA1LAAAIAALdg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A6lF2IAArrMA1LAAAIAALrg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A6lF+IAAr7MA1LAAAIAAL7g");
	var mask_1_graphics_64 = new cjs.Graphics().p("A6lGFIAAsJMA1LAAAIAAMJg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A6lGNIAAsZMA1LAAAIAAMZg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A6lGUIAAsnMA1LAAAIAAMng");
	var mask_1_graphics_67 = new cjs.Graphics().p("A6lGcIAAs3MA1LAAAIAAM3g");
	var mask_1_graphics_68 = new cjs.Graphics().p("A6lGjIAAtFMA1LAAAIAANFg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A6lGrIAAtVMA1LAAAIAANVg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A6lGyIAAtjMA1LAAAIAANjg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A6lG6IAAtzMA1LAAAIAANzg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A6lHBIAAuBMA1LAAAIAAOBg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A6lHJIAAuRMA1LAAAIAAORg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A6lHQIAAufMA1LAAAIAAOfg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A6lHYIAAuvMA1LAAAIAAOvg");
	var mask_1_graphics_101 = new cjs.Graphics().p("A6lHYIAAuvMA1LAAAIAAOvg");
	var mask_1_graphics_102 = new cjs.Graphics().p("A6lHgIAAu/MA1LAAAIAAO/g");
	var mask_1_graphics_103 = new cjs.Graphics().p("A6lHoIAAvPMA1LAAAIAAPPg");
	var mask_1_graphics_104 = new cjs.Graphics().p("A6lHwIAAvfMA1LAAAIAAPfg");
	var mask_1_graphics_105 = new cjs.Graphics().p("A6lH4IAAvvMA1LAAAIAAPvg");
	var mask_1_graphics_106 = new cjs.Graphics().p("A6lIAIAAv/MA1LAAAIAAP/g");
	var mask_1_graphics_107 = new cjs.Graphics().p("A6lIIIAAwPMA1LAAAIAAQPg");
	var mask_1_graphics_108 = new cjs.Graphics().p("A6lIRIAAwhMA1LAAAIAAQhg");
	var mask_1_graphics_109 = new cjs.Graphics().p("A6lIZIAAwxMA1LAAAIAAQxg");
	var mask_1_graphics_110 = new cjs.Graphics().p("A6lIhIAAxBMA1LAAAIAARBg");
	var mask_1_graphics_111 = new cjs.Graphics().p("A6lIpIAAxRMA1LAAAIAARRg");
	var mask_1_graphics_112 = new cjs.Graphics().p("A6lIxIAAxhMA1LAAAIAARhg");
	var mask_1_graphics_113 = new cjs.Graphics().p("A6lI5IAAxxMA1LAAAIAARxg");
	var mask_1_graphics_114 = new cjs.Graphics().p("A6lJBIAAyBMA1LAAAIAASBg");
	var mask_1_graphics_115 = new cjs.Graphics().p("A6lJJIAAyRMA1LAAAIAASRg");
	var mask_1_graphics_116 = new cjs.Graphics().p("A6lJRIAAyhMA1LAAAIAAShg");
	var mask_1_graphics_117 = new cjs.Graphics().p("A6lJZIAAyxMA1LAAAIAASxg");
	var mask_1_graphics_118 = new cjs.Graphics().p("A6lJhIAAzBMA1LAAAIAATBg");
	var mask_1_graphics_119 = new cjs.Graphics().p("A6lJpIAAzRMA1LAAAIAATRg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A6lJxIAAzhMA1LAAAIAAThg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A6lJ6IAAzzMA1LAAAIAATzg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A6lKCIAA0DMA1LAAAIAAUDg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A6lKKIAA0TMA1LAAAIAAUTg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A6lKSIAA0jMA1LAAAIAAUjg");
	var mask_1_graphics_125 = new cjs.Graphics().p("A6lKaIAA0zMA1LAAAIAAUzg");
	var mask_1_graphics_126 = new cjs.Graphics().p("A6lKiIAA1DMA1LAAAIAAVDg");
	var mask_1_graphics_127 = new cjs.Graphics().p("A6lKqIAA1TMA1LAAAIAAVTg");
	var mask_1_graphics_147 = new cjs.Graphics().p("A6lKqIAA1TMA1LAAAIAAVTg");
	var mask_1_graphics_148 = new cjs.Graphics().p("A6lKxIAA1hMA1LAAAIAAVhg");
	var mask_1_graphics_149 = new cjs.Graphics().p("A6lK5IAA1xMA1LAAAIAAVxg");
	var mask_1_graphics_150 = new cjs.Graphics().p("A6lLAIAA1/MA1LAAAIAAV/g");
	var mask_1_graphics_151 = new cjs.Graphics().p("A6lLIIAA2PMA1LAAAIAAWPg");
	var mask_1_graphics_152 = new cjs.Graphics().p("A6lLPIAA2dMA1LAAAIAAWdg");
	var mask_1_graphics_153 = new cjs.Graphics().p("A6lLWIAA2rMA1LAAAIAAWrg");
	var mask_1_graphics_154 = new cjs.Graphics().p("A6lLeIAA27MA1LAAAIAAW7g");
	var mask_1_graphics_155 = new cjs.Graphics().p("A6lLlIAA3JMA1LAAAIAAXJg");
	var mask_1_graphics_156 = new cjs.Graphics().p("A6lLtIAA3ZMA1LAAAIAAXZg");
	var mask_1_graphics_157 = new cjs.Graphics().p("A6lL0IAA3nMA1LAAAIAAXng");
	var mask_1_graphics_158 = new cjs.Graphics().p("A6lL8IAA33MA1LAAAIAAX3g");
	var mask_1_graphics_159 = new cjs.Graphics().p("A6lMDIAA4FMA1LAAAIAAYFg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A6lMKIAA4TMA1LAAAIAAYTg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A6lMSIAA4jMA1LAAAIAAYjg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A6lMZIAA4xMA1LAAAIAAYxg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A6lMhIAA5BMA1LAAAIAAZBg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A6lMoIAA5PMA1LAAAIAAZPg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A6lMvIAA5eMA1LAAAIAAZeg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A6lM3IAA5tMA1LAAAIAAZtg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A6lM+IAA57MA1LAAAIAAZ7g");
	var mask_1_graphics_168 = new cjs.Graphics().p("A6lNGIAA6LMA1LAAAIAAaLg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A6lNNIAA6ZMA1LAAAIAAaZg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A6lNVIAA6pMA1LAAAIAAapg");
	var mask_1_graphics_171 = new cjs.Graphics().p("A6lNcIAA63MA1LAAAIAAa3g");
	var mask_1_graphics_194 = new cjs.Graphics().p("A6lNcIAA63MA1LAAAIAAa3g");
	var mask_1_graphics_195 = new cjs.Graphics().p("A6lNjIAA7FMA1LAAAIAAbFg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A6lNrIAA7VMA1LAAAIAAbVg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A6lNzIAA7lMA1LAAAIAAblg");
	var mask_1_graphics_198 = new cjs.Graphics().p("A6lN6IAA7zMA1LAAAIAAbzg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A6lOCIAA8DMA1LAAAIAAcDg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A6lOJIAA8RMA1LAAAIAAcRg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A6lORIAA8gMA1LAAAIAAcgg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A6lOYIAA8vMA1LAAAIAAcvg");
	var mask_1_graphics_203 = new cjs.Graphics().p("A6lOfIAA89MA1LAAAIAAc9g");
	var mask_1_graphics_204 = new cjs.Graphics().p("A6lOnIAA9NMA1LAAAIAAdNg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A6lOuIAA9bMA1LAAAIAAdbg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A6lO2IAA9rMA1LAAAIAAdrg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A6lO9IAA96MA1LAAAIAAd6g");
	var mask_1_graphics_208 = new cjs.Graphics().p("A6lPFIAA+JMA1LAAAIAAeJg");
	var mask_1_graphics_209 = new cjs.Graphics().p("A6lPMIAA+YMA1LAAAIAAeYg");
	var mask_1_graphics_210 = new cjs.Graphics().p("A6lPUIAA+nMA1LAAAIAAeng");
	var mask_1_graphics_211 = new cjs.Graphics().p("A6lPcIAA+3MA1LAAAIAAe3g");
	var mask_1_graphics_212 = new cjs.Graphics().p("A6lPjIAA/FMA1LAAAIAAfFg");
	var mask_1_graphics_213 = new cjs.Graphics().p("A6lPrIAA/UMA1LAAAIAAfUg");
	var mask_1_graphics_214 = new cjs.Graphics().p("A6lPyIAA/jMA1LAAAIAAfjg");
	var mask_1_graphics_215 = new cjs.Graphics().p("A6lP6IAA/yMA1LAAAIAAfyg");
	var mask_1_graphics_216 = new cjs.Graphics().p("A6lQBMAAAggBMA1LAAAMAAAAgBg");
	var mask_1_graphics_217 = new cjs.Graphics().p("A6lQIMAAAggPMA1LAAAMAAAAgPg");
	var mask_1_graphics_218 = new cjs.Graphics().p("A6lQQMAAAggfMA1LAAAMAAAAgfg");
	var mask_1_graphics_219 = new cjs.Graphics().p("A6lQXMAAAgguMA1LAAAMAAAAgug");
	var mask_1_graphics_220 = new cjs.Graphics().p("A6lQfMAAAgg9MA1LAAAMAAAAg9g");
	var mask_1_graphics_246 = new cjs.Graphics().p("A6lQfMAAAgg9MA1LAAAMAAAAg9g");
	var mask_1_graphics_247 = new cjs.Graphics().p("A6lQmMAAAghLMA1LAAAMAAAAhLg");
	var mask_1_graphics_248 = new cjs.Graphics().p("A6lQuMAAAghbMA1LAAAMAAAAhbg");
	var mask_1_graphics_249 = new cjs.Graphics().p("A6lQ1MAAAghpMA1LAAAMAAAAhpg");
	var mask_1_graphics_250 = new cjs.Graphics().p("A6lQ8MAAAgh3MA1LAAAMAAAAh3g");
	var mask_1_graphics_251 = new cjs.Graphics().p("A6lREMAAAgiHMA1LAAAMAAAAiHg");
	var mask_1_graphics_252 = new cjs.Graphics().p("A6lRLMAAAgiVMA1LAAAMAAAAiVg");
	var mask_1_graphics_253 = new cjs.Graphics().p("A6lRSMAAAgijMA1LAAAMAAAAijg");
	var mask_1_graphics_254 = new cjs.Graphics().p("A6lRZMAAAgixMA1LAAAMAAAAixg");
	var mask_1_graphics_255 = new cjs.Graphics().p("A6lRhMAAAgjBMA1LAAAMAAAAjBg");
	var mask_1_graphics_256 = new cjs.Graphics().p("A6lRoMAAAgjPMA1LAAAMAAAAjPg");
	var mask_1_graphics_257 = new cjs.Graphics().p("A6lRvMAAAgjdMA1LAAAMAAAAjdg");
	var mask_1_graphics_258 = new cjs.Graphics().p("A6lR3MAAAgjtMA1LAAAMAAAAjtg");
	var mask_1_graphics_259 = new cjs.Graphics().p("A6lR+MAAAgj7MA1LAAAMAAAAj7g");
	var mask_1_graphics_260 = new cjs.Graphics().p("A6lSFMAAAgkJMA1LAAAMAAAAkJg");
	var mask_1_graphics_261 = new cjs.Graphics().p("A6lSNMAAAgkZMA1LAAAMAAAAkZg");
	var mask_1_graphics_262 = new cjs.Graphics().p("A6lSUMAAAgknMA1LAAAMAAAAkng");
	var mask_1_graphics_263 = new cjs.Graphics().p("A6lSbMAAAgk1MA1LAAAMAAAAk1g");
	var mask_1_graphics_264 = new cjs.Graphics().p("A6lSjMAAAglFMA1LAAAMAAAAlFg");
	var mask_1_graphics_265 = new cjs.Graphics().p("A6lSqMAAAglTMA1LAAAMAAAAlTg");
	var mask_1_graphics_266 = new cjs.Graphics().p("A6lSxMAAAglhMA1LAAAMAAAAlhg");
	var mask_1_graphics_267 = new cjs.Graphics().p("A6lS5MAAAglxMA1LAAAMAAAAlxg");
	var mask_1_graphics_268 = new cjs.Graphics().p("A6lTAMAAAgl/MA1LAAAMAAAAl/g");
	var mask_1_graphics_269 = new cjs.Graphics().p("A6lTHMAAAgmNMA1LAAAMAAAAmNg");
	var mask_1_graphics_270 = new cjs.Graphics().p("A6lTOMAAAgmbMA1LAAAMAAAAmbg");
	var mask_1_graphics_271 = new cjs.Graphics().p("A6lTWMAAAgmrMA1LAAAMAAAAmrg");
	var mask_1_graphics_272 = new cjs.Graphics().p("A6lTdMAAAgm5MA1LAAAMAAAAm5g");
	var mask_1_graphics_273 = new cjs.Graphics().p("A6lTkMAAAgnHMA1LAAAMAAAAnHg");
	var mask_1_graphics_274 = new cjs.Graphics().p("A6lTsMAAAgnXMA1LAAAMAAAAnXg");
	var mask_1_graphics_275 = new cjs.Graphics().p("A6lTzMAAAgnlMA1LAAAMAAAAnlg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A6lTzMAAAgnlMA1LAAAMAAAAnlg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A6lT8MAAAgn3MA1LAAAMAAAAn3g");
	var mask_1_graphics_302 = new cjs.Graphics().p("A6lUFMAAAgoJMA1LAAAMAAAAoJg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A6lUOMAAAgobMA1LAAAMAAAAobg");
	var mask_1_graphics_304 = new cjs.Graphics().p("A6lUXMAAAgotMA1LAAAMAAAAotg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A6lUhMAAAgpBMA1LAAAMAAAApBg");
	var mask_1_graphics_306 = new cjs.Graphics().p("A6lUqMAAAgpTMA1LAAAMAAAApTg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A6lUzMAAAgplMA1LAAAMAAAAplg");
	var mask_1_graphics_308 = new cjs.Graphics().p("A6lU8MAAAgp3MA1LAAAMAAAAp3g");
	var mask_1_graphics_309 = new cjs.Graphics().p("A6lVFMAAAgqJMA1LAAAMAAAAqJg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A6lVOMAAAgqbMA1LAAAMAAAAqbg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A6lVXMAAAgqtMA1LAAAMAAAAqtg");
	var mask_1_graphics_312 = new cjs.Graphics().p("A6lVgMAAAgq/MA1LAAAMAAAAq/g");
	var mask_1_graphics_313 = new cjs.Graphics().p("A6lVpMAAAgrRMA1LAAAMAAAArRg");
	var mask_1_graphics_314 = new cjs.Graphics().p("A6lVyMAAAgrjMA1LAAAMAAAArjg");
	var mask_1_graphics_315 = new cjs.Graphics().p("A6lV8MAAAgr3MA1LAAAMAAAAr3g");
	var mask_1_graphics_316 = new cjs.Graphics().p("A6lWFMAAAgsJMA1LAAAMAAAAsJg");
	var mask_1_graphics_317 = new cjs.Graphics().p("A6lWOMAAAgsbMA1LAAAMAAAAsbg");
	var mask_1_graphics_318 = new cjs.Graphics().p("A6lWXMAAAgstMA1LAAAMAAAAstg");
	var mask_1_graphics_319 = new cjs.Graphics().p("A6lWgMAAAgs/MA1LAAAMAAAAs/g");
	var mask_1_graphics_320 = new cjs.Graphics().p("A6lWpMAAAgtRMA1LAAAMAAAAtRg");
	var mask_1_graphics_321 = new cjs.Graphics().p("A6lWyMAAAgtjMA1LAAAMAAAAtjg");
	var mask_1_graphics_322 = new cjs.Graphics().p("A6lW7MAAAgt1MA1LAAAMAAAAt1g");
	var mask_1_graphics_348 = new cjs.Graphics().p("A6lW7MAAAgt1MA1LAAAMAAAAt1g");
	var mask_1_graphics_349 = new cjs.Graphics().p("A6lXCMAAAguDMA1LAAAMAAAAuDg");
	var mask_1_graphics_350 = new cjs.Graphics().p("A6lXIMAAAguPMA1LAAAMAAAAuPg");
	var mask_1_graphics_351 = new cjs.Graphics().p("A6lXPMAAAgudMA1LAAAMAAAAudg");
	var mask_1_graphics_352 = new cjs.Graphics().p("A6lXVMAAAgupMA1LAAAMAAAAupg");
	var mask_1_graphics_353 = new cjs.Graphics().p("A6lXcMAAAgu3MA1LAAAMAAAAu3g");
	var mask_1_graphics_354 = new cjs.Graphics().p("A6lXiMAAAgvDMA1LAAAMAAAAvDg");
	var mask_1_graphics_355 = new cjs.Graphics().p("A6lXpMAAAgvRMA1LAAAMAAAAvRg");
	var mask_1_graphics_356 = new cjs.Graphics().p("A6lXvMAAAgvdMA1LAAAMAAAAvdg");
	var mask_1_graphics_357 = new cjs.Graphics().p("A6lX2MAAAgvrMA1LAAAMAAAAvrg");
	var mask_1_graphics_358 = new cjs.Graphics().p("A6lX9MAAAgv5MA1LAAAMAAAAv5g");
	var mask_1_graphics_359 = new cjs.Graphics().p("A6lYDMAAAgwFMA1LAAAMAAAAwFg");
	var mask_1_graphics_360 = new cjs.Graphics().p("A6lYKMAAAgwTMA1LAAAMAAAAwTg");
	var mask_1_graphics_361 = new cjs.Graphics().p("A6lYQMAAAgwfMA1LAAAMAAAAwfg");
	var mask_1_graphics_362 = new cjs.Graphics().p("A6lYXMAAAgwtMA1LAAAMAAAAwtg");
	var mask_1_graphics_363 = new cjs.Graphics().p("A6lYdMAAAgw5MA1LAAAMAAAAw5g");
	var mask_1_graphics_364 = new cjs.Graphics().p("A6lYkMAAAgxHMA1LAAAMAAAAxHg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A6lYqMAAAgxTMA1LAAAMAAAAxTg");
	var mask_1_graphics_366 = new cjs.Graphics().p("A6lYxMAAAgxhMA1LAAAMAAAAxhg");
	var mask_1_graphics_367 = new cjs.Graphics().p("A6lY3MAAAgxtMA1LAAAMAAAAxtg");
	var mask_1_graphics_368 = new cjs.Graphics().p("A6lY+MAAAgx7MA1LAAAMAAAAx7g");
	var mask_1_graphics_369 = new cjs.Graphics().p("A6lZEMAAAgyHMA1LAAAMAAAAyHg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A6lZLMAAAgyVMA1LAAAMAAAAyVg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A6lZRMAAAgyhMA1LAAAMAAAAyhg");
	var mask_1_graphics_372 = new cjs.Graphics().p("A6lZYMAAAgyvMA1LAAAMAAAAyvg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A6lZeMAAAgy7MA1LAAAMAAAAy7g");
	var mask_1_graphics_396 = new cjs.Graphics().p("A6lZeMAAAgy7MA1LAAAMAAAAy7g");
	var mask_1_graphics_397 = new cjs.Graphics().p("A6lZoMAAAgzPMA1LAAAMAAAAzPg");
	var mask_1_graphics_398 = new cjs.Graphics().p("A6lZxMAAAgzhMA1LAAAMAAAAzhg");
	var mask_1_graphics_399 = new cjs.Graphics().p("A6lZ6MAAAgzzMA1LAAAMAAAAzzg");
	var mask_1_graphics_400 = new cjs.Graphics().p("A6laDMAAAg0FMA1LAAAMAAAA0Fg");
	var mask_1_graphics_401 = new cjs.Graphics().p("A6laMMAAAg0XMA1LAAAMAAAA0Xg");
	var mask_1_graphics_402 = new cjs.Graphics().p("A6laWMAAAg0rMA1LAAAMAAAA0rg");
	var mask_1_graphics_403 = new cjs.Graphics().p("A6lafMAAAg09MA1LAAAMAAAA09g");
	var mask_1_graphics_404 = new cjs.Graphics().p("A6laoMAAAg1PMA1LAAAMAAAA1Pg");
	var mask_1_graphics_405 = new cjs.Graphics().p("A6laxMAAAg1hMA1LAAAMAAAA1hg");
	var mask_1_graphics_406 = new cjs.Graphics().p("A6la6MAAAg1zMA1LAAAMAAAA1zg");
	var mask_1_graphics_407 = new cjs.Graphics().p("A6lbEMAAAg2HMA1LAAAMAAAA2Hg");
	var mask_1_graphics_408 = new cjs.Graphics().p("A6lbNMAAAg2ZMA1LAAAMAAAA2Zg");
	var mask_1_graphics_409 = new cjs.Graphics().p("A6lbWMAAAg2rMA1LAAAMAAAA2rg");
	var mask_1_graphics_410 = new cjs.Graphics().p("A6lbfMAAAg29MA1LAAAMAAAA29g");
	var mask_1_graphics_411 = new cjs.Graphics().p("A6lboMAAAg3PMA1LAAAMAAAA3Pg");
	var mask_1_graphics_412 = new cjs.Graphics().p("A6lbxMAAAg3hMA1LAAAMAAAA3hg");
	var mask_1_graphics_413 = new cjs.Graphics().p("A6lb7MAAAg31MA1LAAAMAAAA31g");
	var mask_1_graphics_414 = new cjs.Graphics().p("A6lcEMAAAg4HMA1LAAAMAAAA4Hg");
	var mask_1_graphics_415 = new cjs.Graphics().p("A6lcNMAAAg4ZMA1LAAAMAAAA4Zg");
	var mask_1_graphics_416 = new cjs.Graphics().p("A6lcWMAAAg4rMA1LAAAMAAAA4rg");
	var mask_1_graphics_417 = new cjs.Graphics().p("A6lcfMAAAg49MA1LAAAMAAAA49g");
	var mask_1_graphics_418 = new cjs.Graphics().p("A6lcoMAAAg5PMA1LAAAMAAAA5Pg");
	var mask_1_graphics_438 = new cjs.Graphics().p("A6lcoMAAAg5PMA1LAAAMAAAA5Pg");
	var mask_1_graphics_439 = new cjs.Graphics().p("A6lcyMAAAg5jMA1LAAAMAAAA5jg");
	var mask_1_graphics_440 = new cjs.Graphics().p("A6lc8MAAAg53MA1LAAAMAAAA53g");
	var mask_1_graphics_441 = new cjs.Graphics().p("A6ldGMAAAg6LMA1LAAAMAAAA6Lg");
	var mask_1_graphics_442 = new cjs.Graphics().p("A6ldPMAAAg6dMA1LAAAMAAAA6dg");
	var mask_1_graphics_443 = new cjs.Graphics().p("A6ldZMAAAg6xMA1LAAAMAAAA6xg");
	var mask_1_graphics_444 = new cjs.Graphics().p("A6ldjMAAAg7FMA1LAAAMAAAA7Fg");
	var mask_1_graphics_445 = new cjs.Graphics().p("A6ldsMAAAg7XMA1LAAAMAAAA7Xg");
	var mask_1_graphics_446 = new cjs.Graphics().p("A6ld2MAAAg7rMA1LAAAMAAAA7rg");
	var mask_1_graphics_447 = new cjs.Graphics().p("A6leAMAAAg7/MA1LAAAMAAAA7/g");
	var mask_1_graphics_448 = new cjs.Graphics().p("A6leKMAAAg8TMA1LAAAMAAAA8Tg");
	var mask_1_graphics_449 = new cjs.Graphics().p("A6leTMAAAg8lMA1LAAAMAAAA8lg");
	var mask_1_graphics_450 = new cjs.Graphics().p("A6ledMAAAg85MA1LAAAMAAAA85g");
	var mask_1_graphics_451 = new cjs.Graphics().p("A6lenMAAAg9NMA1LAAAMAAAA9Ng");
	var mask_1_graphics_452 = new cjs.Graphics().p("A6lewMAAAg9fMA1LAAAMAAAA9fg");
	var mask_1_graphics_453 = new cjs.Graphics().p("A6le6MAAAg9zMA1LAAAMAAAA9zg");
	var mask_1_graphics_454 = new cjs.Graphics().p("A6lfEMAAAg+HMA1LAAAMAAAA+Hg");
	var mask_1_graphics_455 = new cjs.Graphics().p("A6lfNMAAAg+ZMA1LAAAMAAAA+Zg");
	var mask_1_graphics_456 = new cjs.Graphics().p("A6lfXMAAAg+tMA1LAAAMAAAA+tg");
	var mask_1_graphics_457 = new cjs.Graphics().p("A6lfhMAAAg/BMA1LAAAMAAAA/Bg");
	var mask_1_graphics_458 = new cjs.Graphics().p("A6lfrMAAAg/VMA1LAAAMAAAA/Vg");
	var mask_1_graphics_459 = new cjs.Graphics().p("A6lf0MAAAg/nMA1LAAAMAAAA/ng");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:144.5,y:-12.1}).wait(1).to({graphics:mask_1_graphics_1,x:144.5,y:-11.1}).wait(1).to({graphics:mask_1_graphics_2,x:144.5,y:-10.1}).wait(1).to({graphics:mask_1_graphics_3,x:144.5,y:-9.2}).wait(1).to({graphics:mask_1_graphics_4,x:144.5,y:-8.2}).wait(1).to({graphics:mask_1_graphics_5,x:144.5,y:-7.2}).wait(1).to({graphics:mask_1_graphics_6,x:144.5,y:-6.2}).wait(1).to({graphics:mask_1_graphics_7,x:144.5,y:-5.2}).wait(1).to({graphics:mask_1_graphics_8,x:144.5,y:-4.2}).wait(1).to({graphics:mask_1_graphics_9,x:144.5,y:-3.3}).wait(1).to({graphics:mask_1_graphics_10,x:144.5,y:-2.3}).wait(1).to({graphics:mask_1_graphics_11,x:144.5,y:-1.3}).wait(1).to({graphics:mask_1_graphics_12,x:144.5,y:-0.3}).wait(1).to({graphics:mask_1_graphics_13,x:144.5,y:0.6}).wait(1).to({graphics:mask_1_graphics_14,x:144.5,y:1.5}).wait(1).to({graphics:mask_1_graphics_15,x:144.5,y:2.5}).wait(1).to({graphics:mask_1_graphics_16,x:144.5,y:3.5}).wait(1).to({graphics:mask_1_graphics_17,x:144.5,y:4.5}).wait(1).to({graphics:mask_1_graphics_18,x:144.5,y:5.5}).wait(1).to({graphics:mask_1_graphics_19,x:144.5,y:6.4}).wait(1).to({graphics:mask_1_graphics_20,x:144.5,y:7.4}).wait(1).to({graphics:mask_1_graphics_21,x:144.5,y:8.4}).wait(1).to({graphics:mask_1_graphics_22,x:144.5,y:9.4}).wait(1).to({graphics:mask_1_graphics_23,x:144.5,y:10.4}).wait(27).to({graphics:mask_1_graphics_50,x:144.5,y:10.4}).wait(1).to({graphics:mask_1_graphics_51,x:144.5,y:11.1}).wait(1).to({graphics:mask_1_graphics_52,x:144.5,y:11.9}).wait(1).to({graphics:mask_1_graphics_53,x:144.5,y:12.6}).wait(1).to({graphics:mask_1_graphics_54,x:144.5,y:13.4}).wait(1).to({graphics:mask_1_graphics_55,x:144.5,y:14.1}).wait(1).to({graphics:mask_1_graphics_56,x:144.5,y:14.9}).wait(1).to({graphics:mask_1_graphics_57,x:144.5,y:15.6}).wait(1).to({graphics:mask_1_graphics_58,x:144.5,y:16.4}).wait(1).to({graphics:mask_1_graphics_59,x:144.5,y:17.1}).wait(1).to({graphics:mask_1_graphics_60,x:144.5,y:17.9}).wait(1).to({graphics:mask_1_graphics_61,x:144.5,y:18.6}).wait(1).to({graphics:mask_1_graphics_62,x:144.5,y:19.4}).wait(1).to({graphics:mask_1_graphics_63,x:144.5,y:20.1}).wait(1).to({graphics:mask_1_graphics_64,x:144.5,y:20.9}).wait(1).to({graphics:mask_1_graphics_65,x:144.5,y:21.6}).wait(1).to({graphics:mask_1_graphics_66,x:144.5,y:22.4}).wait(1).to({graphics:mask_1_graphics_67,x:144.5,y:23.1}).wait(1).to({graphics:mask_1_graphics_68,x:144.5,y:23.9}).wait(1).to({graphics:mask_1_graphics_69,x:144.5,y:24.6}).wait(1).to({graphics:mask_1_graphics_70,x:144.5,y:25.4}).wait(1).to({graphics:mask_1_graphics_71,x:144.5,y:26.1}).wait(1).to({graphics:mask_1_graphics_72,x:144.5,y:26.9}).wait(1).to({graphics:mask_1_graphics_73,x:144.5,y:27.6}).wait(1).to({graphics:mask_1_graphics_74,x:144.5,y:28.4}).wait(1).to({graphics:mask_1_graphics_75,x:144.5,y:29.2}).wait(26).to({graphics:mask_1_graphics_101,x:144.5,y:29.2}).wait(1).to({graphics:mask_1_graphics_102,x:144.5,y:30}).wait(1).to({graphics:mask_1_graphics_103,x:144.5,y:30.8}).wait(1).to({graphics:mask_1_graphics_104,x:144.5,y:31.6}).wait(1).to({graphics:mask_1_graphics_105,x:144.5,y:32.4}).wait(1).to({graphics:mask_1_graphics_106,x:144.5,y:33.2}).wait(1).to({graphics:mask_1_graphics_107,x:144.5,y:34}).wait(1).to({graphics:mask_1_graphics_108,x:144.5,y:34.8}).wait(1).to({graphics:mask_1_graphics_109,x:144.5,y:35.6}).wait(1).to({graphics:mask_1_graphics_110,x:144.5,y:36.4}).wait(1).to({graphics:mask_1_graphics_111,x:144.5,y:37.2}).wait(1).to({graphics:mask_1_graphics_112,x:144.5,y:38}).wait(1).to({graphics:mask_1_graphics_113,x:144.5,y:38.8}).wait(1).to({graphics:mask_1_graphics_114,x:144.5,y:39.6}).wait(1).to({graphics:mask_1_graphics_115,x:144.5,y:40.4}).wait(1).to({graphics:mask_1_graphics_116,x:144.5,y:41.2}).wait(1).to({graphics:mask_1_graphics_117,x:144.5,y:42}).wait(1).to({graphics:mask_1_graphics_118,x:144.5,y:42.8}).wait(1).to({graphics:mask_1_graphics_119,x:144.5,y:43.6}).wait(1).to({graphics:mask_1_graphics_120,x:144.5,y:44.4}).wait(1).to({graphics:mask_1_graphics_121,x:144.5,y:45.2}).wait(1).to({graphics:mask_1_graphics_122,x:144.5,y:46}).wait(1).to({graphics:mask_1_graphics_123,x:144.5,y:46.8}).wait(1).to({graphics:mask_1_graphics_124,x:144.5,y:47.6}).wait(1).to({graphics:mask_1_graphics_125,x:144.5,y:48.4}).wait(1).to({graphics:mask_1_graphics_126,x:144.5,y:49.2}).wait(1).to({graphics:mask_1_graphics_127,x:144.5,y:50}).wait(20).to({graphics:mask_1_graphics_147,x:144.5,y:50}).wait(1).to({graphics:mask_1_graphics_148,x:144.5,y:50.7}).wait(1).to({graphics:mask_1_graphics_149,x:144.5,y:51.4}).wait(1).to({graphics:mask_1_graphics_150,x:144.5,y:52.2}).wait(1).to({graphics:mask_1_graphics_151,x:144.5,y:52.9}).wait(1).to({graphics:mask_1_graphics_152,x:144.5,y:53.6}).wait(1).to({graphics:mask_1_graphics_153,x:144.5,y:54.4}).wait(1).to({graphics:mask_1_graphics_154,x:144.5,y:55.1}).wait(1).to({graphics:mask_1_graphics_155,x:144.5,y:55.9}).wait(1).to({graphics:mask_1_graphics_156,x:144.5,y:56.6}).wait(1).to({graphics:mask_1_graphics_157,x:144.5,y:57.3}).wait(1).to({graphics:mask_1_graphics_158,x:144.5,y:58.1}).wait(1).to({graphics:mask_1_graphics_159,x:144.5,y:58.8}).wait(1).to({graphics:mask_1_graphics_160,x:144.5,y:59.6}).wait(1).to({graphics:mask_1_graphics_161,x:144.5,y:60.3}).wait(1).to({graphics:mask_1_graphics_162,x:144.5,y:61}).wait(1).to({graphics:mask_1_graphics_163,x:144.5,y:61.8}).wait(1).to({graphics:mask_1_graphics_164,x:144.5,y:62.5}).wait(1).to({graphics:mask_1_graphics_165,x:144.5,y:63.3}).wait(1).to({graphics:mask_1_graphics_166,x:144.5,y:64}).wait(1).to({graphics:mask_1_graphics_167,x:144.5,y:64.7}).wait(1).to({graphics:mask_1_graphics_168,x:144.5,y:65.5}).wait(1).to({graphics:mask_1_graphics_169,x:144.5,y:66.2}).wait(1).to({graphics:mask_1_graphics_170,x:144.5,y:67}).wait(1).to({graphics:mask_1_graphics_171,x:144.5,y:67.7}).wait(23).to({graphics:mask_1_graphics_194,x:144.5,y:67.7}).wait(1).to({graphics:mask_1_graphics_195,x:144.5,y:68.5}).wait(1).to({graphics:mask_1_graphics_196,x:144.5,y:69.2}).wait(1).to({graphics:mask_1_graphics_197,x:144.5,y:70}).wait(1).to({graphics:mask_1_graphics_198,x:144.5,y:70.7}).wait(1).to({graphics:mask_1_graphics_199,x:144.5,y:71.5}).wait(1).to({graphics:mask_1_graphics_200,x:144.5,y:72.2}).wait(1).to({graphics:mask_1_graphics_201,x:144.5,y:73}).wait(1).to({graphics:mask_1_graphics_202,x:144.5,y:73.7}).wait(1).to({graphics:mask_1_graphics_203,x:144.5,y:74.5}).wait(1).to({graphics:mask_1_graphics_204,x:144.5,y:75.3}).wait(1).to({graphics:mask_1_graphics_205,x:144.5,y:76}).wait(1).to({graphics:mask_1_graphics_206,x:144.5,y:76.8}).wait(1).to({graphics:mask_1_graphics_207,x:144.5,y:77.5}).wait(1).to({graphics:mask_1_graphics_208,x:144.5,y:78.3}).wait(1).to({graphics:mask_1_graphics_209,x:144.5,y:79}).wait(1).to({graphics:mask_1_graphics_210,x:144.5,y:79.8}).wait(1).to({graphics:mask_1_graphics_211,x:144.5,y:80.5}).wait(1).to({graphics:mask_1_graphics_212,x:144.5,y:81.3}).wait(1).to({graphics:mask_1_graphics_213,x:144.5,y:82.1}).wait(1).to({graphics:mask_1_graphics_214,x:144.5,y:82.8}).wait(1).to({graphics:mask_1_graphics_215,x:144.5,y:83.6}).wait(1).to({graphics:mask_1_graphics_216,x:144.5,y:84.3}).wait(1).to({graphics:mask_1_graphics_217,x:144.5,y:85.1}).wait(1).to({graphics:mask_1_graphics_218,x:144.5,y:85.8}).wait(1).to({graphics:mask_1_graphics_219,x:144.5,y:86.6}).wait(1).to({graphics:mask_1_graphics_220,x:144.5,y:87.4}).wait(26).to({graphics:mask_1_graphics_246,x:144.5,y:87.4}).wait(1).to({graphics:mask_1_graphics_247,x:144.5,y:88.1}).wait(1).to({graphics:mask_1_graphics_248,x:144.5,y:88.8}).wait(1).to({graphics:mask_1_graphics_249,x:144.5,y:89.6}).wait(1).to({graphics:mask_1_graphics_250,x:144.5,y:90.3}).wait(1).to({graphics:mask_1_graphics_251,x:144.5,y:91.1}).wait(1).to({graphics:mask_1_graphics_252,x:144.5,y:91.8}).wait(1).to({graphics:mask_1_graphics_253,x:144.5,y:92.6}).wait(1).to({graphics:mask_1_graphics_254,x:144.5,y:93.3}).wait(1).to({graphics:mask_1_graphics_255,x:144.5,y:94.1}).wait(1).to({graphics:mask_1_graphics_256,x:144.5,y:94.8}).wait(1).to({graphics:mask_1_graphics_257,x:144.5,y:95.6}).wait(1).to({graphics:mask_1_graphics_258,x:144.5,y:96.3}).wait(1).to({graphics:mask_1_graphics_259,x:144.5,y:97.1}).wait(1).to({graphics:mask_1_graphics_260,x:144.5,y:97.8}).wait(1).to({graphics:mask_1_graphics_261,x:144.5,y:98.5}).wait(1).to({graphics:mask_1_graphics_262,x:144.5,y:99.3}).wait(1).to({graphics:mask_1_graphics_263,x:144.5,y:100}).wait(1).to({graphics:mask_1_graphics_264,x:144.5,y:100.8}).wait(1).to({graphics:mask_1_graphics_265,x:144.5,y:101.5}).wait(1).to({graphics:mask_1_graphics_266,x:144.5,y:102.3}).wait(1).to({graphics:mask_1_graphics_267,x:144.5,y:103}).wait(1).to({graphics:mask_1_graphics_268,x:144.5,y:103.8}).wait(1).to({graphics:mask_1_graphics_269,x:144.5,y:104.5}).wait(1).to({graphics:mask_1_graphics_270,x:144.5,y:105.3}).wait(1).to({graphics:mask_1_graphics_271,x:144.5,y:106}).wait(1).to({graphics:mask_1_graphics_272,x:144.5,y:106.8}).wait(1).to({graphics:mask_1_graphics_273,x:144.5,y:107.5}).wait(1).to({graphics:mask_1_graphics_274,x:144.5,y:108.3}).wait(1).to({graphics:mask_1_graphics_275,x:144.5,y:109}).wait(25).to({graphics:mask_1_graphics_300,x:144.5,y:109}).wait(1).to({graphics:mask_1_graphics_301,x:144.5,y:109.9}).wait(1).to({graphics:mask_1_graphics_302,x:144.5,y:110.8}).wait(1).to({graphics:mask_1_graphics_303,x:144.5,y:111.7}).wait(1).to({graphics:mask_1_graphics_304,x:144.5,y:112.6}).wait(1).to({graphics:mask_1_graphics_305,x:144.5,y:113.5}).wait(1).to({graphics:mask_1_graphics_306,x:144.5,y:114.4}).wait(1).to({graphics:mask_1_graphics_307,x:144.5,y:115.4}).wait(1).to({graphics:mask_1_graphics_308,x:144.5,y:116.3}).wait(1).to({graphics:mask_1_graphics_309,x:144.5,y:117.2}).wait(1).to({graphics:mask_1_graphics_310,x:144.5,y:118.1}).wait(1).to({graphics:mask_1_graphics_311,x:144.5,y:119}).wait(1).to({graphics:mask_1_graphics_312,x:144.5,y:119.9}).wait(1).to({graphics:mask_1_graphics_313,x:144.5,y:120.8}).wait(1).to({graphics:mask_1_graphics_314,x:144.5,y:121.7}).wait(1).to({graphics:mask_1_graphics_315,x:144.5,y:122.6}).wait(1).to({graphics:mask_1_graphics_316,x:144.5,y:123.5}).wait(1).to({graphics:mask_1_graphics_317,x:144.5,y:124.4}).wait(1).to({graphics:mask_1_graphics_318,x:144.5,y:125.3}).wait(1).to({graphics:mask_1_graphics_319,x:144.5,y:126.3}).wait(1).to({graphics:mask_1_graphics_320,x:144.5,y:127.2}).wait(1).to({graphics:mask_1_graphics_321,x:144.5,y:128.1}).wait(1).to({graphics:mask_1_graphics_322,x:144.5,y:129}).wait(26).to({graphics:mask_1_graphics_348,x:144.5,y:129}).wait(1).to({graphics:mask_1_graphics_349,x:144.5,y:129.6}).wait(1).to({graphics:mask_1_graphics_350,x:144.5,y:130.3}).wait(1).to({graphics:mask_1_graphics_351,x:144.5,y:130.9}).wait(1).to({graphics:mask_1_graphics_352,x:144.5,y:131.6}).wait(1).to({graphics:mask_1_graphics_353,x:144.5,y:132.2}).wait(1).to({graphics:mask_1_graphics_354,x:144.5,y:132.9}).wait(1).to({graphics:mask_1_graphics_355,x:144.5,y:133.5}).wait(1).to({graphics:mask_1_graphics_356,x:144.5,y:134.2}).wait(1).to({graphics:mask_1_graphics_357,x:144.5,y:134.8}).wait(1).to({graphics:mask_1_graphics_358,x:144.5,y:135.4}).wait(1).to({graphics:mask_1_graphics_359,x:144.5,y:136.1}).wait(1).to({graphics:mask_1_graphics_360,x:144.5,y:136.7}).wait(1).to({graphics:mask_1_graphics_361,x:144.5,y:137.4}).wait(1).to({graphics:mask_1_graphics_362,x:144.5,y:138}).wait(1).to({graphics:mask_1_graphics_363,x:144.5,y:138.7}).wait(1).to({graphics:mask_1_graphics_364,x:144.5,y:139.3}).wait(1).to({graphics:mask_1_graphics_365,x:144.5,y:140}).wait(1).to({graphics:mask_1_graphics_366,x:144.5,y:140.6}).wait(1).to({graphics:mask_1_graphics_367,x:144.5,y:141.3}).wait(1).to({graphics:mask_1_graphics_368,x:144.5,y:141.9}).wait(1).to({graphics:mask_1_graphics_369,x:144.5,y:142.6}).wait(1).to({graphics:mask_1_graphics_370,x:144.5,y:143.2}).wait(1).to({graphics:mask_1_graphics_371,x:144.5,y:143.9}).wait(1).to({graphics:mask_1_graphics_372,x:144.5,y:144.5}).wait(1).to({graphics:mask_1_graphics_373,x:144.5,y:145.1}).wait(23).to({graphics:mask_1_graphics_396,x:144.5,y:145.1}).wait(1).to({graphics:mask_1_graphics_397,x:144.5,y:146.1}).wait(1).to({graphics:mask_1_graphics_398,x:144.5,y:147}).wait(1).to({graphics:mask_1_graphics_399,x:144.5,y:148}).wait(1).to({graphics:mask_1_graphics_400,x:144.5,y:148.9}).wait(1).to({graphics:mask_1_graphics_401,x:144.5,y:149.8}).wait(1).to({graphics:mask_1_graphics_402,x:144.5,y:150.8}).wait(1).to({graphics:mask_1_graphics_403,x:144.5,y:151.7}).wait(1).to({graphics:mask_1_graphics_404,x:144.5,y:152.6}).wait(1).to({graphics:mask_1_graphics_405,x:144.5,y:153.6}).wait(1).to({graphics:mask_1_graphics_406,x:144.5,y:154.5}).wait(1).to({graphics:mask_1_graphics_407,x:144.5,y:155.4}).wait(1).to({graphics:mask_1_graphics_408,x:144.5,y:156.4}).wait(1).to({graphics:mask_1_graphics_409,x:144.5,y:157.3}).wait(1).to({graphics:mask_1_graphics_410,x:144.5,y:158.2}).wait(1).to({graphics:mask_1_graphics_411,x:144.5,y:159.2}).wait(1).to({graphics:mask_1_graphics_412,x:144.5,y:160.1}).wait(1).to({graphics:mask_1_graphics_413,x:144.5,y:161}).wait(1).to({graphics:mask_1_graphics_414,x:144.5,y:162}).wait(1).to({graphics:mask_1_graphics_415,x:144.5,y:162.9}).wait(1).to({graphics:mask_1_graphics_416,x:144.5,y:163.8}).wait(1).to({graphics:mask_1_graphics_417,x:144.5,y:164.8}).wait(1).to({graphics:mask_1_graphics_418,x:144.5,y:165.7}).wait(20).to({graphics:mask_1_graphics_438,x:144.5,y:165.7}).wait(1).to({graphics:mask_1_graphics_439,x:144.5,y:166.7}).wait(1).to({graphics:mask_1_graphics_440,x:144.5,y:167.6}).wait(1).to({graphics:mask_1_graphics_441,x:144.5,y:168.6}).wait(1).to({graphics:mask_1_graphics_442,x:144.5,y:169.5}).wait(1).to({graphics:mask_1_graphics_443,x:144.5,y:170.5}).wait(1).to({graphics:mask_1_graphics_444,x:144.5,y:171.5}).wait(1).to({graphics:mask_1_graphics_445,x:144.5,y:172.4}).wait(1).to({graphics:mask_1_graphics_446,x:144.5,y:173.4}).wait(1).to({graphics:mask_1_graphics_447,x:144.5,y:174.3}).wait(1).to({graphics:mask_1_graphics_448,x:144.5,y:175.3}).wait(1).to({graphics:mask_1_graphics_449,x:144.5,y:176.3}).wait(1).to({graphics:mask_1_graphics_450,x:144.5,y:177.2}).wait(1).to({graphics:mask_1_graphics_451,x:144.5,y:178.2}).wait(1).to({graphics:mask_1_graphics_452,x:144.5,y:179.2}).wait(1).to({graphics:mask_1_graphics_453,x:144.5,y:180.1}).wait(1).to({graphics:mask_1_graphics_454,x:144.5,y:181.1}).wait(1).to({graphics:mask_1_graphics_455,x:144.5,y:182}).wait(1).to({graphics:mask_1_graphics_456,x:144.5,y:183}).wait(1).to({graphics:mask_1_graphics_457,x:144.5,y:184}).wait(1).to({graphics:mask_1_graphics_458,x:144.5,y:184.9}).wait(1).to({graphics:mask_1_graphics_459,x:144.5,y:185.9}).wait(341));

	// mc_p3_01
	this.mc_p3_01 = new cjs.Text(txt['mc_p3_01'], "20px Verdana");
	this.mc_p3_01.lineHeight = 20;
	this.mc_p3_01.lineWidth = 317;

	this.mc_p3_01.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mc_p3_01}]}).wait(800));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,751.7,394.9);


(lib.mc_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg4JABVIAAioMBwTAAAIAACog");
	var mask_graphics_1 = new cjs.Graphics().p("Eg4JABmIAAjLMBwTAAAIAADLg");
	var mask_graphics_2 = new cjs.Graphics().p("Eg4JAB3IAAjtMBwTAAAIAADtg");
	var mask_graphics_3 = new cjs.Graphics().p("Eg4JACIIAAkPMBwTAAAIAAEPg");
	var mask_graphics_4 = new cjs.Graphics().p("Eg4JACZIAAkxMBwTAAAIAAExg");
	var mask_graphics_5 = new cjs.Graphics().p("Eg4JACqIAAlTMBwTAAAIAAFTg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg4JAC7IAAl1MBwTAAAIAAF1g");
	var mask_graphics_7 = new cjs.Graphics().p("Eg4JADMIAAmXMBwTAAAIAAGXg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg4JADdIAAm5MBwTAAAIAAG5g");
	var mask_graphics_9 = new cjs.Graphics().p("Eg4JADuIAAnbMBwTAAAIAAHbg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg4JAD/IAAn9MBwTAAAIAAH9g");
	var mask_graphics_11 = new cjs.Graphics().p("Eg4JAEQIAAofMBwTAAAIAAIfg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg4JAEhIAApBMBwTAAAIAAJBg");
	var mask_graphics_13 = new cjs.Graphics().p("Eg4JAEyIAApjMBwTAAAIAAJjg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg4JAFDIAAqFMBwTAAAIAAKFg");
	var mask_graphics_15 = new cjs.Graphics().p("Eg4JAFUIAAqnMBwTAAAIAAKng");
	var mask_graphics_16 = new cjs.Graphics().p("Eg4JAFlIAArJMBwTAAAIAALJg");
	var mask_graphics_17 = new cjs.Graphics().p("Eg4JAF2IAArrMBwTAAAIAALrg");
	var mask_graphics_18 = new cjs.Graphics().p("Eg4JAGHIAAsNMBwTAAAIAAMNg");
	var mask_graphics_19 = new cjs.Graphics().p("Eg4JAGYIAAsvMBwTAAAIAAMvg");
	var mask_graphics_20 = new cjs.Graphics().p("Eg4JAGpIAAtRMBwTAAAIAANRg");
	var mask_graphics_21 = new cjs.Graphics().p("Eg4JAG6IAAtzMBwTAAAIAANzg");
	var mask_graphics_22 = new cjs.Graphics().p("Eg4JAHLIAAuVMBwTAAAIAAOVg");
	var mask_graphics_23 = new cjs.Graphics().p("Eg4JAHcIAAu3MBwTAAAIAAO3g");
	var mask_graphics_24 = new cjs.Graphics().p("Eg4JAHtIAAvZMBwTAAAIAAPZg");
	var mask_graphics_25 = new cjs.Graphics().p("Eg4JAH+IAAv7MBwTAAAIAAP7g");
	var mask_graphics_26 = new cjs.Graphics().p("Eg4JAIPIAAwdMBwTAAAIAAQdg");
	var mask_graphics_27 = new cjs.Graphics().p("Eg4JAIgIAAw/MBwTAAAIAAQ/g");
	var mask_graphics_28 = new cjs.Graphics().p("Eg4JAIyIAAxjMBwTAAAIAARjg");
	var mask_graphics_29 = new cjs.Graphics().p("Eg4JAJDIAAyFMBwTAAAIAASFg");
	var mask_graphics_30 = new cjs.Graphics().p("Eg4JAJUIAAynMBwTAAAIAASng");
	var mask_graphics_31 = new cjs.Graphics().p("Eg4JAJlIAAzJMBwTAAAIAATJg");
	var mask_graphics_32 = new cjs.Graphics().p("Eg4JAJ2IAAzrMBwTAAAIAATrg");
	var mask_graphics_33 = new cjs.Graphics().p("Eg4JAKHIAA0NMBwTAAAIAAUNg");
	var mask_graphics_34 = new cjs.Graphics().p("Eg4JAKYIAA0vMBwTAAAIAAUvg");
	var mask_graphics_35 = new cjs.Graphics().p("Eg4JAKpIAA1RMBwTAAAIAAVRg");
	var mask_graphics_36 = new cjs.Graphics().p("Eg4JAK6IAA1zMBwTAAAIAAVzg");
	var mask_graphics_37 = new cjs.Graphics().p("Eg4JALLIAA2VMBwTAAAIAAWVg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg4JALcIAA23MBwTAAAIAAW3g");
	var mask_graphics_39 = new cjs.Graphics().p("Eg4JALtIAA3ZMBwTAAAIAAXZg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg4JAL+IAA37MBwTAAAIAAX7g");
	var mask_graphics_41 = new cjs.Graphics().p("Eg4JAMPIAA4dMBwTAAAIAAYdg");
	var mask_graphics_42 = new cjs.Graphics().p("Eg4JAMgIAA4/MBwTAAAIAAY/g");
	var mask_graphics_43 = new cjs.Graphics().p("Eg4JAMxIAA5hMBwTAAAIAAZhg");
	var mask_graphics_44 = new cjs.Graphics().p("Eg4JANCIAA6DMBwTAAAIAAaDg");
	var mask_graphics_45 = new cjs.Graphics().p("Eg4JANTIAA6lMBwTAAAIAAalg");
	var mask_graphics_46 = new cjs.Graphics().p("Eg4JANkIAA7HMBwTAAAIAAbHg");
	var mask_graphics_47 = new cjs.Graphics().p("Eg4JAN1IAA7pMBwTAAAIAAbpg");
	var mask_graphics_48 = new cjs.Graphics().p("Eg4JAOGIAA8LMBwTAAAIAAcLg");
	var mask_graphics_49 = new cjs.Graphics().p("Eg4JAOXIAA8tMBwTAAAIAActg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg4JAOoIAA9PMBwTAAAIAAdPg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg4JAO5IAA9xMBwTAAAIAAdxg");
	var mask_graphics_52 = new cjs.Graphics().p("Eg4JAPKIAA+TMBwTAAAIAAeTg");
	var mask_graphics_53 = new cjs.Graphics().p("Eg4JAPbIAA+1MBwTAAAIAAe1g");
	var mask_graphics_54 = new cjs.Graphics().p("Eg4JAPsIAA/XMBwTAAAIAAfXg");
	var mask_graphics_55 = new cjs.Graphics().p("Eg4JAP+IAA/7MBwTAAAIAAf7g");
	var mask_graphics_56 = new cjs.Graphics().p("Eg4JAQPMAAAggdMBwTAAAMAAAAgdg");
	var mask_graphics_57 = new cjs.Graphics().p("Eg4JAQgMAAAgg/MBwTAAAMAAAAg/g");
	var mask_graphics_58 = new cjs.Graphics().p("Eg4JAQxMAAAghhMBwTAAAMAAAAhhg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg4JARCMAAAgiDMBwTAAAMAAAAiDg");
	var mask_graphics_60 = new cjs.Graphics().p("Eg4JARTMAAAgilMBwTAAAMAAAAilg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg4JARkMAAAgjHMBwTAAAMAAAAjHg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg4JAR1MAAAgjpMBwTAAAMAAAAjpg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg4JASGMAAAgkLMBwTAAAMAAAAkLg");
	var mask_graphics_64 = new cjs.Graphics().p("Eg4JASXMAAAgktMBwTAAAMAAAAktg");
	var mask_graphics_65 = new cjs.Graphics().p("Eg4JASoMAAAglPMBwTAAAMAAAAlPg");
	var mask_graphics_66 = new cjs.Graphics().p("Eg4JAS5MAAAglxMBwTAAAMAAAAlxg");
	var mask_graphics_67 = new cjs.Graphics().p("Eg4JATKMAAAgmTMBwTAAAMAAAAmTg");
	var mask_graphics_68 = new cjs.Graphics().p("Eg4JATbMAAAgm1MBwTAAAMAAAAm1g");
	var mask_graphics_69 = new cjs.Graphics().p("Eg4JATsMAAAgnXMBwTAAAMAAAAnXg");
	var mask_graphics_70 = new cjs.Graphics().p("Eg4JAT9MAAAgn5MBwTAAAMAAAAn5g");
	var mask_graphics_71 = new cjs.Graphics().p("Eg4JAUOMAAAgobMBwTAAAMAAAAobg");
	var mask_graphics_72 = new cjs.Graphics().p("Eg4JAUfMAAAgo9MBwTAAAMAAAAo9g");
	var mask_graphics_73 = new cjs.Graphics().p("Eg4JAUwMAAAgpfMBwTAAAMAAAApfg");
	var mask_graphics_74 = new cjs.Graphics().p("Eg4JAVBMAAAgqBMBwTAAAMAAAAqBg");
	var mask_graphics_75 = new cjs.Graphics().p("Eg4JAVSMAAAgqjMBwTAAAMAAAAqjg");
	var mask_graphics_76 = new cjs.Graphics().p("Eg4JAVjMAAAgrFMBwTAAAMAAAArFg");
	var mask_graphics_77 = new cjs.Graphics().p("Eg4JAV0MAAAgrnMBwTAAAMAAAArng");
	var mask_graphics_78 = new cjs.Graphics().p("Eg4JAWFMAAAgsJMBwTAAAMAAAAsJg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg4JAWWMAAAgsrMBwTAAAMAAAAsrg");
	var mask_graphics_80 = new cjs.Graphics().p("Eg4JAWnMAAAgtNMBwTAAAMAAAAtNg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg4JAW4MAAAgtvMBwTAAAMAAAAtvg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg4JAXJMAAAguRMBwTAAAMAAAAuRg");
	var mask_graphics_83 = new cjs.Graphics().p("Eg4JAXbMAAAgu1MBwTAAAMAAAAu1g");
	var mask_graphics_84 = new cjs.Graphics().p("Eg4JAXsMAAAgvXMBwTAAAMAAAAvXg");
	var mask_graphics_85 = new cjs.Graphics().p("Eg4JAX9MAAAgv5MBwTAAAMAAAAv5g");
	var mask_graphics_86 = new cjs.Graphics().p("Eg4JAYOMAAAgwbMBwTAAAMAAAAwbg");
	var mask_graphics_87 = new cjs.Graphics().p("Eg4JAYfMAAAgw9MBwTAAAMAAAAw9g");
	var mask_graphics_88 = new cjs.Graphics().p("Eg4JAYwMAAAgxfMBwTAAAMAAAAxfg");
	var mask_graphics_89 = new cjs.Graphics().p("Eg4JAZBMAAAgyBMBwTAAAMAAAAyBg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg4JAZSMAAAgyjMBwTAAAMAAAAyjg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg4JAZjMAAAgzFMBwTAAAMAAAAzFg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg4JAZ0MAAAgznMBwTAAAMAAAAzng");
	var mask_graphics_93 = new cjs.Graphics().p("Eg4JAaFMAAAg0JMBwTAAAMAAAA0Jg");
	var mask_graphics_94 = new cjs.Graphics().p("Eg4JAaWMAAAg0rMBwTAAAMAAAA0rg");
	var mask_graphics_95 = new cjs.Graphics().p("Eg4JAanMAAAg1NMBwTAAAMAAAA1Ng");
	var mask_graphics_96 = new cjs.Graphics().p("Eg4JAa4MAAAg1vMBwTAAAMAAAA1vg");
	var mask_graphics_97 = new cjs.Graphics().p("Eg4JAbJMAAAg2RMBwTAAAMAAAA2Rg");
	var mask_graphics_98 = new cjs.Graphics().p("Eg4JAbaMAAAg2zMBwTAAAMAAAA2zg");
	var mask_graphics_99 = new cjs.Graphics().p("Eg4JAbrMAAAg3VMBwTAAAMAAAA3Vg");
	var mask_graphics_100 = new cjs.Graphics().p("Eg4JAb8MAAAg33MBwTAAAMAAAA33g");
	var mask_graphics_101 = new cjs.Graphics().p("Eg4JAcNMAAAg4ZMBwTAAAMAAAA4Zg");
	var mask_graphics_102 = new cjs.Graphics().p("Eg4JAceMAAAg47MBwTAAAMAAAA47g");
	var mask_graphics_103 = new cjs.Graphics().p("Eg1uAcvMAAAg5dMBwTAAAMAAAA5dg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:390.4,y:357}).wait(1).to({graphics:mask_graphics_1,x:390.4,y:355.2}).wait(1).to({graphics:mask_graphics_2,x:390.4,y:353.5}).wait(1).to({graphics:mask_graphics_3,x:390.4,y:351.8}).wait(1).to({graphics:mask_graphics_4,x:390.4,y:350.1}).wait(1).to({graphics:mask_graphics_5,x:390.4,y:348.4}).wait(1).to({graphics:mask_graphics_6,x:390.4,y:346.7}).wait(1).to({graphics:mask_graphics_7,x:390.4,y:345}).wait(1).to({graphics:mask_graphics_8,x:390.4,y:343.3}).wait(1).to({graphics:mask_graphics_9,x:390.4,y:341.6}).wait(1).to({graphics:mask_graphics_10,x:390.4,y:339.9}).wait(1).to({graphics:mask_graphics_11,x:390.4,y:338.2}).wait(1).to({graphics:mask_graphics_12,x:390.4,y:336.5}).wait(1).to({graphics:mask_graphics_13,x:390.4,y:334.8}).wait(1).to({graphics:mask_graphics_14,x:390.4,y:333.1}).wait(1).to({graphics:mask_graphics_15,x:390.4,y:331.4}).wait(1).to({graphics:mask_graphics_16,x:390.4,y:329.7}).wait(1).to({graphics:mask_graphics_17,x:390.4,y:328}).wait(1).to({graphics:mask_graphics_18,x:390.4,y:326.3}).wait(1).to({graphics:mask_graphics_19,x:390.4,y:324.6}).wait(1).to({graphics:mask_graphics_20,x:390.4,y:322.9}).wait(1).to({graphics:mask_graphics_21,x:390.4,y:321.2}).wait(1).to({graphics:mask_graphics_22,x:390.4,y:319.5}).wait(1).to({graphics:mask_graphics_23,x:390.4,y:317.8}).wait(1).to({graphics:mask_graphics_24,x:390.4,y:316.1}).wait(1).to({graphics:mask_graphics_25,x:390.4,y:314.4}).wait(1).to({graphics:mask_graphics_26,x:390.4,y:312.7}).wait(1).to({graphics:mask_graphics_27,x:390.4,y:311}).wait(1).to({graphics:mask_graphics_28,x:390.4,y:309.2}).wait(1).to({graphics:mask_graphics_29,x:390.4,y:307.5}).wait(1).to({graphics:mask_graphics_30,x:390.4,y:305.8}).wait(1).to({graphics:mask_graphics_31,x:390.4,y:304.1}).wait(1).to({graphics:mask_graphics_32,x:390.4,y:302.4}).wait(1).to({graphics:mask_graphics_33,x:390.4,y:300.7}).wait(1).to({graphics:mask_graphics_34,x:390.4,y:299}).wait(1).to({graphics:mask_graphics_35,x:390.4,y:297.3}).wait(1).to({graphics:mask_graphics_36,x:390.4,y:295.6}).wait(1).to({graphics:mask_graphics_37,x:390.4,y:293.9}).wait(1).to({graphics:mask_graphics_38,x:390.4,y:292.2}).wait(1).to({graphics:mask_graphics_39,x:390.4,y:290.5}).wait(1).to({graphics:mask_graphics_40,x:390.4,y:288.8}).wait(1).to({graphics:mask_graphics_41,x:390.4,y:287.1}).wait(1).to({graphics:mask_graphics_42,x:390.4,y:285.4}).wait(1).to({graphics:mask_graphics_43,x:390.4,y:283.7}).wait(1).to({graphics:mask_graphics_44,x:390.4,y:282}).wait(1).to({graphics:mask_graphics_45,x:390.4,y:280.3}).wait(1).to({graphics:mask_graphics_46,x:390.4,y:278.6}).wait(1).to({graphics:mask_graphics_47,x:390.4,y:276.9}).wait(1).to({graphics:mask_graphics_48,x:390.4,y:275.2}).wait(1).to({graphics:mask_graphics_49,x:390.4,y:273.5}).wait(1).to({graphics:mask_graphics_50,x:390.4,y:271.8}).wait(1).to({graphics:mask_graphics_51,x:390.4,y:270.1}).wait(1).to({graphics:mask_graphics_52,x:390.4,y:268.4}).wait(1).to({graphics:mask_graphics_53,x:390.4,y:266.7}).wait(1).to({graphics:mask_graphics_54,x:390.4,y:265}).wait(1).to({graphics:mask_graphics_55,x:390.4,y:263.2}).wait(1).to({graphics:mask_graphics_56,x:390.4,y:261.5}).wait(1).to({graphics:mask_graphics_57,x:390.4,y:259.8}).wait(1).to({graphics:mask_graphics_58,x:390.4,y:258.1}).wait(1).to({graphics:mask_graphics_59,x:390.4,y:256.4}).wait(1).to({graphics:mask_graphics_60,x:390.4,y:254.7}).wait(1).to({graphics:mask_graphics_61,x:390.4,y:253}).wait(1).to({graphics:mask_graphics_62,x:390.4,y:251.3}).wait(1).to({graphics:mask_graphics_63,x:390.4,y:249.6}).wait(1).to({graphics:mask_graphics_64,x:390.4,y:247.9}).wait(1).to({graphics:mask_graphics_65,x:390.4,y:246.2}).wait(1).to({graphics:mask_graphics_66,x:390.4,y:244.5}).wait(1).to({graphics:mask_graphics_67,x:390.4,y:242.8}).wait(1).to({graphics:mask_graphics_68,x:390.4,y:241.1}).wait(1).to({graphics:mask_graphics_69,x:390.4,y:239.4}).wait(1).to({graphics:mask_graphics_70,x:390.4,y:237.7}).wait(1).to({graphics:mask_graphics_71,x:390.4,y:236}).wait(1).to({graphics:mask_graphics_72,x:390.4,y:234.3}).wait(1).to({graphics:mask_graphics_73,x:390.4,y:232.6}).wait(1).to({graphics:mask_graphics_74,x:390.4,y:230.9}).wait(1).to({graphics:mask_graphics_75,x:390.4,y:229.2}).wait(1).to({graphics:mask_graphics_76,x:390.4,y:227.5}).wait(1).to({graphics:mask_graphics_77,x:390.4,y:225.8}).wait(1).to({graphics:mask_graphics_78,x:390.4,y:224.1}).wait(1).to({graphics:mask_graphics_79,x:390.4,y:222.4}).wait(1).to({graphics:mask_graphics_80,x:390.4,y:220.7}).wait(1).to({graphics:mask_graphics_81,x:390.4,y:219}).wait(1).to({graphics:mask_graphics_82,x:390.4,y:217.3}).wait(1).to({graphics:mask_graphics_83,x:390.4,y:215.5}).wait(1).to({graphics:mask_graphics_84,x:390.4,y:213.8}).wait(1).to({graphics:mask_graphics_85,x:390.4,y:212.1}).wait(1).to({graphics:mask_graphics_86,x:390.4,y:210.4}).wait(1).to({graphics:mask_graphics_87,x:390.4,y:208.7}).wait(1).to({graphics:mask_graphics_88,x:390.4,y:207}).wait(1).to({graphics:mask_graphics_89,x:390.4,y:205.3}).wait(1).to({graphics:mask_graphics_90,x:390.4,y:203.6}).wait(1).to({graphics:mask_graphics_91,x:390.4,y:201.9}).wait(1).to({graphics:mask_graphics_92,x:390.4,y:200.2}).wait(1).to({graphics:mask_graphics_93,x:390.4,y:198.5}).wait(1).to({graphics:mask_graphics_94,x:390.4,y:196.8}).wait(1).to({graphics:mask_graphics_95,x:390.4,y:195.1}).wait(1).to({graphics:mask_graphics_96,x:390.4,y:193.4}).wait(1).to({graphics:mask_graphics_97,x:390.4,y:191.7}).wait(1).to({graphics:mask_graphics_98,x:390.4,y:190}).wait(1).to({graphics:mask_graphics_99,x:390.4,y:188.3}).wait(1).to({graphics:mask_graphics_100,x:390.4,y:186.6}).wait(1).to({graphics:mask_graphics_101,x:390.4,y:184.9}).wait(1).to({graphics:mask_graphics_102,x:390.4,y:183.2}).wait(1).to({graphics:mask_graphics_103,x:375,y:181.5}).wait(1));

	// Capa 2
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(56.7,11);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#808080").s().p("EgDjAxhMAAAhjBIHHAAMAAABjBg");
	this.shape.setTransform(712.3,183.9,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#808080").s().p("EgDjAzlMAAAhnJIHHAAMAAABnJg");
	this.shape_1.setTransform(632.1,177.3,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#808080").s().p("EgDlArUMAAAhWnIHLAAMAAABWng");
	this.shape_2.setTransform(549.3,203.8,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#808080").s().p("EgDjAvcMAAAhe4IHHAAMAAABe4g");
	this.shape_3.setTransform(470.1,190.6,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#808080").s().p("EgDjAsVMAAAhYpIHHAAMAAABYpg");
	this.shape_4.setTransform(389.4,200.5,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#808080").s().p("AjjbxMAAAg3hIHHAAMAAAA3hg");
	this.shape_5.setTransform(306.7,253.5,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#808080").s().p("EgDlAmIMAAAhMPIHLAAMAAABMPg");
	this.shape_6.setTransform(228.4,220.4,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#808080").s().p("EgDjAh+MAAAhD7IHHAAMAAABD7g");
	this.shape_7.setTransform(147.6,233.7,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#808080").s().p("AjjbxMAAAg3hIHHAAMAAAA3hg");
	this.shape_8.setTransform(69.5,253.5,0.5,0.5);

	this.instance.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(104));

	// Capa 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_9.setTransform(737.8,344.3,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_10.setTransform(666.7,344.3,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_11.setTransform(586.6,344.3,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_12.setTransform(506.4,344.3,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_13.setTransform(426.3,344.3,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_14.setTransform(346.3,344.3,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_15.setTransform(266.2,344.3,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_16.setTransform(185.9,344.3,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_17.setTransform(105.9,344.3,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(0.3,2).p("AAAAoIAAhP");
	this.shape_18.setTransform(39.7,344.3,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(0.3,2).p("EhtEAAAMDaJAAA");
	this.shape_19.setTransform(388.8,342.3,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_20.setTransform(37.7,10.9,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_21.setTransform(37.7,44.1,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_22.setTransform(37.7,77.3,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_23.setTransform(37.7,110.3,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_24.setTransform(37.7,143.4,0.5,0.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_25.setTransform(37.7,176.6,0.5,0.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_26.setTransform(37.7,209.8,0.5,0.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_27.setTransform(37.7,242.9,0.5,0.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_28.setTransform(37.7,275.9,0.5,0.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_29.setTransform(37.7,309.1,0.5,0.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(0.3,2).p("AgnAAIBQAA");
	this.shape_30.setTransform(37.7,342.3,0.5,0.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(0.3,2).p("EAAAgzwMAAABnh");
	this.shape_31.setTransform(39.7,176.6,0.5,0.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(0.3,2).p("EA2bgSGIADAAEA2bgXRIADAAEA2bgM6IADAAEAwTgSGIA+AAEAx1gSGIA+AAEAzXgSGIA/AAEAwTgXRIA+AAEAx1gXRIA+AAEAzXgXRIA/AAEAoogSGIA+AAEAqKgSGIA/AAEArsgSGIA/AAEAtOgSGIA+AAEAoogXRIA+AAEAqKgXRIA/AAEArsgXRIA/AAEAtOgXRIA+AAEAoogM6IA+AAEAqKgM6IA/AAEArsgM6IA/AAEAtOgM6IA+AAEAwTgM6IA+AAEAx1gM6IA+AAEAzXgM6IA/AAEAuwgSGIA/AAEAuwgXRIA/AAEAuwgM6IA/AAEAwTgHwIA+AAEAx1gHwIA+AAEAzXgHwIA/AAEAwTgCkIA+AAEAx1gCkIA+AAEAzXgCkIA/AAEAoogHwIA+AAEAqKgHwIA/AAEArsgHwIA/AAEAtOgHwIA+AAEAoogCkIA+AAEAqKgCkIA/AAEArsgCkIA/AAEAtOgCkIA+AAEAooAClIA+AAEAqKAClIA/AAEArsAClIA/AAEAtOAClIA+AAEAwTAClIA+AAEAx1AClIA+AAEAzXAClIA/AAEAuwgHwIA/AAEAuwAClIA/AAEAuwgCkIA/AAEA2bgHwIADAAEA2bgCkIADAAEA2bAClIADAAEA05gSGIA+AAEA05gXRIA+AAEA05gHwIA+AAEA05gM6IA+AAEA05AClIA+AAEA05gCkIA+AAEA2bAM8IADAAEA2bAHxIADAAEA2bASGIADAAEAwTAM8IA+AAEAx1AM8IA+AAEAzXAM8IA/AAEAwTAHxIA+AAEAx1AHxIA+AAEAzXAHxIA/AAEAooAM8IA+AAEAqKAM8IA/AAEArsAM8IA/AAEAtOAM8IA+AAEAooAHxIA+AAEAqKAHxIA/AAEArsAHxIA/AAEAtOAHxIA+AAEAtOASGIA+AAEArsASGIA/AAEAqKASGIA/AAEAooASGIA+AAEAzXASGIA/AAEAx1ASGIA+AAEAwTASGIA+AAEAuwAM8IA/AAEAuwAHxIA/AAEAuwASGIA/AAEAzXAXSIA/AAEAx1AXSIA+AAEAwTAXSIA+AAEAtOAXSIA+AAEArsAXSIA/AAEAqKAXSIA/AAEAooAXSIA+AAEAuwAXSIA/AAEA2bAXSIADAAEA05AM8IA+AAEA05AHxIA+AAEA05ASGIA+AAEA05AXSIA+AAEAifgSGIA/AAEAkBgSGIA+AAEAlkgSGIA+AAEAnFgSGIA/AAEAifgXRIA/AAEAkBgXRIA+AAEAlkgXRIA+AAEAnFgXRIA/AAAcXyGIA+AAAd4yGIA/AAAfbyGIA+AAEAg9gSGIA+AAAcX3RIA+AAAd43RIA/AAAfb3RIA+AAEAg9gXRIA+AAAcXs6IA+AAAd4s6IA/AAAfbs6IA+AAEAg9gM6IA+AAEAifgM6IA/AAEAkBgM6IA+AAEAlkgM6IA+AAEAnFgM6IA/AAAWNyGIA/AAAXwyGIA+AAAZSyGIA/AAAa0yGIA+AAAWN3RIA/AAAXw3RIA+AAAZS3RIA/AAAa03RIA+AAAQFyGIA/AAARnyGIA/AAATJyGIA/AAAQF3RIA/AAARn3RIA/AAATJ3RIA/AAAQFs6IA/AAARns6IA/AAATJs6IA/AAAWNs6IA/AAAXws6IA+AAAZSs6IA/AAAa0s6IA+AAAUryGIA/AAAUr3RIA/AAAUrs6IA/AAAWNnwIA/AAAXwnwIA+AAAZSnwIA/AAAa0nwIA+AAAWNikIA/AAAXwikIA+AAAZSikIA/AAAa0ikIA+AAAQFnwIA/AAARnnwIA/AAATJnwIA/AAAQFikIA/AAARnikIA/AAATJikIA/AAAQFClIA/AAARnClIA/AAATJClIA/AAAWNClIA/AAAXwClIA+AAAZSClIA/AAAa0ClIA+AAAUrnwIA/AAAUrClIA/AAAUrikIA/AAEAifgHwIA/AAEAkBgHwIA+AAEAlkgHwIA+AAEAnFgHwIA/AAEAifgCkIA/AAEAkBgCkIA+AAEAlkgCkIA+AAEAnFgCkIA/AAAcXnwIA+AAAd4nwIA/AAAfbnwIA+AAEAg9gHwIA+AAAcXikIA+AAAd4ikIA/AAAfbikIA+AAEAg9gCkIA+AAAcXClIA+AAAd4ClIA/AAAfbClIA+AAEAg9AClIA+AAEAifAClIA/AAEAkBAClIA+AAEAlkAClIA+AAEAnFAClIA/AAAJ8yGIA+AAALfyGIA+AAANAyGIA/AAAJ83RIA+AAALf3RIA+AAANA3RIA/AAADzyGIA/AAAFWyGIA+AAAG4yGIA+AAADz3RIA/AAAFW3RIA+AAAG43RIA+AAADzs6IA/AAAFWs6IA+AAAG4s6IA+AAAJ8s6IA+AAALfs6IA+AAANAs6IA/AAAIayGIA+AAAIa3RIA+AAAIas6IA+AAAiTyGIA+AAAgxyGIA8AAAAvyGIA/AAAiT3RIA+AAAgx3RIA8AAAAv3RIA/AAAp+yGIA+AAAocyGIA+AAAm6yGIA/AAAlYyGIA/AAAp+3RIA+AAAoc3RIA+AAAm63RIA/AAAlY3RIA/AAAp+s6IA+AAAocs6IA+AAAm6s6IA/AAAlYs6IA/AAAiTs6IA+AAAgxs6IA8AAAAvs6IA/AAAj2yGIA/AAAj23RIA/AAAj2s6IA/AAAiTnwIA+AAAgxnwIA8AAAAvnwIA/AAAiTikIA+AAAgxikIA8AAAAvikIA/AAAp+nwIA+AAAocnwIA+AAAm6nwIA/AAAlYnwIA/AAAp+ikIA+AAAocikIA+AAAm6ikIA/AAAlYikIA/AAAp+ClIA+AAAocClIA+AAAm6ClIA/AAAlYClIA/AAAiTClIA+AAAgxClIA8AAAAvClIA/AAAj2nwIA/AAAj2ClIA/AAAj2ikIA/AAAJ8nwIA+AAALfnwIA+AAANAnwIA/AAAJ8ikIA+AAALfikIA+AAANAikIA/AAADznwIA/AAAFWnwIA+AAAG4nwIA+AAADzikIA/AAAFWikIA+AAAG4ikIA+AAADzClIA/AAAFWClIA+AAAG4ClIA+AAAJ8ClIA+AAALfClIA+AAANAClIA/AAAIanwIA+AAAIaClIA+AAAIaikIA+AAACRyGIA/AAACR3RIA/AAACRnwIA/AAACRs6IA/AAACRClIA/AAACRikIA/AAAJ8M8IA+AAALfM8IA+AAANAM8IA/AAAJ8HxIA+AAALfHxIA+AAANAHxIA/AAADzM8IA/AAAFWM8IA+AAAG4M8IA+AAADzHxIA/AAAFWHxIA+AAAG4HxIA+AAAG4SGIA+AAAFWSGIA+AAADzSGIA/AAANASGIA/AAALfSGIA+AAAJ8SGIA+AAAIaM8IA+AAAIaHxIA+AAAIaSGIA+AAAiTM8IA+AAAgxM8IA8AAAAvM8IA/AAAiTHxIA+AAAgxHxIA8AAAAvHxIA/AAAp+M8IA+AAAocM8IA+AAAm6M8IA/AAAlYM8IA/AAAp+HxIA+AAAocHxIA+AAAm6HxIA/AAAlYHxIA/AAAlYSGIA/AAAm6SGIA/AAAocSGIA+AAAp+SGIA+AAAAvSGIA/AAAgxSGIA8AAAiTSGIA+AAAj2M8IA/AAAj2HxIA/AAAj2SGIA/AAAAvXSIA/AAAgxXSIA8AAAiTXSIA+AAAlYXSIA/AAAm6XSIA/AAAocXSIA+AAAp+XSIA+AAAj2XSIA/AAANAXSIA/AAALfXSIA+AAAJ8XSIA+AAAG4XSIA+AAAFWXSIA+AAADzXSIA/AAAIaXSIA+AAACRM8IA/AAACRHxIA/AAACRSGIA/AAACRXSIA/AAEAifAM8IA/AAEAkBAM8IA+AAEAlkAM8IA+AAEAnFAM8IA/AAEAifAHxIA/AAEAkBAHxIA+AAEAlkAHxIA+AAEAnFAHxIA/AAAcXM8IA+AAAd4M8IA/AAAfbM8IA+AAEAg9AM8IA+AAAcXHxIA+AAAd4HxIA/AAAfbHxIA+AAEAg9AHxIA+AAEAg9ASGIA+AAAfbSGIA+AAAd4SGIA/AAAcXSGIA+AAEAnFASGIA/AAEAlkASGIA+AAEAkBASGIA+AAEAifASGIA/AAAWNM8IA/AAAXwM8IA+AAAZSM8IA/AAAa0M8IA+AAAWNHxIA/AAAXwHxIA+AAAZSHxIA/AAAa0HxIA+AAAQFM8IA/AAARnM8IA/AAATJM8IA/AAAQFHxIA/AAARnHxIA/AAATJHxIA/AAATJSGIA/AAARnSGIA/AAAQFSGIA/AAAa0SGIA+AAAZSSGIA/AAAXwSGIA+AAAWNSGIA/AAAUrM8IA/AAAUrHxIA/AAAUrSGIA/AAAa0XSIA+AAAZSXSIA/AAAXwXSIA+AAAWNXSIA/AAATJXSIA/AAARnXSIA/AAAQFXSIA/AAAUrXSIA/AAEAnFAXSIA/AAEAlkAXSIA+AAEAkBAXSIA+AAEAifAXSIA/AAEAg9AXSIA+AAAfbXSIA+AAAd4XSIA/AAAcXXSIA+AAAOjyGIA+AAAOj3RIA+AAAOjnwIA+AAAOjs6IA+AAAOjClIA+AAAOjikIA+AAAOjM8IA+AAAOjHxIA+AAAOjSGIA+AAAOjXSIA+AAArgyGIA+AAAwH3RIA/AAAul3RIA/AAAtD3RIA/AAArg3RIA+AAAwHyGIA/AAAulyGIA/AAAtDyGIA/AAA2Q3RIA/AAA0t3RIA+AAAzL3RIA+AAAxp3RIA+AAA2QyGIA/AAA0tyGIA+AAAzLyGIA+AAAxpyGIA+AAA2Qs6IA/AAA0ts6IA+AAAzLs6IA+AAAxps6IA+AAAwHs6IA/AAAuls6IA/AAAtDs6IA/AAArgs6IA+AAA8Y3RIA+AAA623RIA+AAA5U3RIA/AAA3y3RIA/AAA8YyGIA+AAA62yGIA+AAA5UyGIA/AAA3yyGIA/AAEgihgXRIA/AAEgg/gXRIA/AAA/d3RIA/AAEgihgSGIA/AAEgg/gSGIA/AAA/dyGIA/AAEgihgM6IA/AAEgg/gM6IA/AAA/ds6IA/AAA8Ys6IA+AAA62s6IA+AAA5Us6IA/AAA3ys6IA/AAA963RIA+AAA96s6IA+AAA96yGIA+AAA8YikIA+AAA62ikIA+AAA5UikIA/AAA3yikIA/AAA8YnwIA+AAA62nwIA+AAA5UnwIA/AAA3ynwIA/AAEgihgCkIA/AAEgg/gCkIA/AAA/dikIA/AAEgihgHwIA/AAEgg/gHwIA/AAA/dnwIA/AAEgg/AClIA/AAA/dClIA/AAEgihAClIA/AAA8YClIA+AAA62ClIA+AAA5UClIA/AAA3yClIA/AAA96ClIA+AAA96ikIA+AAA96nwIA+AAAwHnwIA/AAAulnwIA/AAAtDnwIA/AAArgnwIA+AAAwHikIA/AAAulikIA/AAAtDikIA/AAArgikIA+AAA2QnwIA/AAA0tnwIA+AAAzLnwIA+AAAxpnwIA+AAA2QikIA/AAA0tikIA+AAAzLikIA+AAAxpikIA+AAA2QClIA/AAA0tClIA+AAAzLClIA+AAAxpClIA+AAAwHClIA/AAAulClIA/AAAtDClIA/AAArgClIA+AAEgoqgXRIA/AAEgnHgXRIA+AAEgllgXRIA+AAEgoqgSGIA/AAEgnHgSGIA+AAEgllgSGIA+AAEguygXRIA+AAEgtQgXRIA/AAEgrugXRIA/AAEguygSGIA+AAEgtQgSGIA/AAEgrugSGIA/AAEguygM6IA+AAEgtQgM6IA/AAEgrugM6IA/AAEgoqgM6IA/AAEgnHgM6IA+AAEgllgM6IA+AAEgqMgXRIA/AAEgqMgM6IA/AAEgqMgSGIA/AAEg07gXRIA/AAEgzZgXRIA/AAEgx2gXRIA+AAEg07gSGIA/AAEgzZgSGIA/AAEgx2gSGIA+AAEg07gM6IA/AAEgzZgM6IA/AAEgx2gM6IA+AAEg2dgXRIA/AAEg2dgM6IA/AAEg2dgSGIA/AAEg07gCkIA/AAEgzZgCkIA/AAEgx2gCkIA+AAEg07gHwIA/AAEgzZgHwIA/AAEgx2gHwIA+AAEg07AClIA/AAEgzZAClIA/AAEgx2AClIA+AAEg2dgCkIA/AAEg2dgHwIA/AAEg2dAClIA/AAEgoqgCkIA/AAEgnHgCkIA+AAEgllgCkIA+AAEgoqgHwIA/AAEgnHgHwIA+AAEgllgHwIA+AAEguygCkIA+AAEgtQgCkIA/AAEgrugCkIA/AAEguygHwIA+AAEgtQgHwIA/AAEgrugHwIA/AAEguyAClIA+AAEgtQAClIA/AAEgruAClIA/AAEgoqAClIA/AAEgnHAClIA+AAEgllAClIA+AAEgqMgCkIA/AAEgqMgHwIA/AAEgqMAClIA/AAEgwUgXRIA+AAEgwUgM6IA+AAEgwUgSGIA+AAEgwUgCkIA+AAEgwUgHwIA+AAEgwUAClIA+AAEgoqAM8IA/AAEgnHAM8IA+AAEgllAM8IA+AAEgoqAHxIA/AAEgnHAHxIA+AAEgllAHxIA+AAEgruAM8IA/AAEguyAHxIA+AAEgtQAHxIA/AAEgruAHxIA/AAEgtQAM8IA/AAEguyAM8IA+AAEgruASGIA/AAEgtQASGIA/AAEguyASGIA+AAEgllASGIA+AAEgnHASGIA+AAEgoqASGIA/AAEgqMAM8IA/AAEgqMAHxIA/AAEgqMASGIA/AAEg07AHxIA/AAEgzZAHxIA/AAEgx2AHxIA+AAEgx2AM8IA+AAEgzZAM8IA/AAEg07AM8IA/AAEgx2ASGIA+AAEgzZASGIA/AAEg07ASGIA/AAEg2dAHxIA/AAEg2dAM8IA/AAEg2dASGIA/AAEgx2AXSIA+AAEgzZAXSIA/AAEg07AXSIA/AAEg2dAXSIA/AAEgllAXSIA+AAEgnHAXSIA+AAEgoqAXSIA/AAEgruAXSIA/AAEgtQAXSIA/AAEguyAXSIA+AAEgqMAXSIA/AAEgwUAHxIA+AAEgwUAM8IA+AAEgwUASGIA+AAEgwUAXSIA+AAAwHM8IA/AAAulM8IA/AAAtDM8IA/AAArgM8IA+AAAwHHxIA/AAAulHxIA/AAAtDHxIA/AAArgHxIA+AAA2QM8IA/AAA0tM8IA+AAAzLM8IA+AAAxpM8IA+AAA2QHxIA/AAA0tHxIA+AAAzLHxIA+AAAxpHxIA+AAAxpSGIA+AAAzLSGIA+AAA0tSGIA+AAA2QSGIA/AAArgSGIA+AAAtDSGIA/AAAulSGIA/AAAwHSGIA/AAA8YM8IA+AAA62M8IA+AAA5UM8IA/AAA3yM8IA/AAA8YHxIA+AAA62HxIA+AAA5UHxIA/AAA3yHxIA/AAEgihAM8IA/AAEgg/AM8IA/AAA/dM8IA/AAEgihAHxIA/AAEgg/AHxIA/AAA/dHxIA/AAA/dSGIA/AAEgg/ASGIA/AAEgihASGIA/AAA3ySGIA/AAA5USGIA/AAA62SGIA+AAA8YSGIA+AAA96M8IA+AAA96HxIA+AAA96SGIA+AAA3yXSIA/AAA5UXSIA/AAA62XSIA+AAA8YXSIA+AAA/dXSIA/AAEgg/AXSIA/AAEgihAXSIA/AAA96XSIA+AAArgXSIA+AAAtDXSIA/AAAulXSIA/AAAwHXSIA/AAAxpXSIA+AAAzLXSIA+AAA0tXSIA+AAA2QXSIA/AAEgkDgXRIA+AAEgkDgM6IA+AAEgkDgSGIA+AAEgkDgCkIA+AAEgkDgHwIA+AAEgkDAM8IA+AAEgkDAHxIA+AAEgkDAClIA+AAEgkDASGIA+AAEgkDAXSIA+AA");
	this.shape_32.setTransform(388.4,160);

	this.text = new cjs.Text("2011", "40px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 45;
	this.text.lineWidth = 142;
	this.text.setTransform(741.1,346.7,0.5,0.5);

	this.text_1 = new cjs.Text("2010", "40px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 45;
	this.text_1.lineWidth = 137;
	this.text_1.setTransform(659.8,346.7,0.5,0.5);

	this.text_2 = new cjs.Text("2009", "40px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 45;
	this.text_2.lineWidth = 104;
	this.text_2.setTransform(574.1,346.7,0.5,0.5);

	this.text_3 = new cjs.Text("2008", "40px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 45;
	this.text_3.lineWidth = 103;
	this.text_3.setTransform(493.7,346.7,0.5,0.5);

	this.text_4 = new cjs.Text("2007", "40px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 45;
	this.text_4.lineWidth = 104;
	this.text_4.setTransform(413.3,346.7,0.5,0.5);

	this.text_5 = new cjs.Text("2006", "40px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 45;
	this.text_5.lineWidth = 110;
	this.text_5.setTransform(333,346.7,0.5,0.5);

	this.text_6 = new cjs.Text("2005", "40px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 45;
	this.text_6.lineWidth = 102;
	this.text_6.setTransform(251.7,346.7,0.5,0.5);

	this.text_7 = new cjs.Text("2004", "40px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 45;
	this.text_7.lineWidth = 111;
	this.text_7.setTransform(173.2,346.7,0.5,0.5);

	this.text_8 = new cjs.Text("2003", "40px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 45;
	this.text_8.lineWidth = 104;
	this.text_8.setTransform(92.8,346.7,0.5,0.5);

	this.text_9 = new cjs.Text("5,0", "40px Verdana");
	this.text_9.lineHeight = 45;
	this.text_9.lineWidth = 71;
	this.text_9.setTransform(-2.1,-1.6,0.5,0.5);

	this.text_10 = new cjs.Text("4,5", "40px Verdana");
	this.text_10.lineHeight = 45;
	this.text_10.lineWidth = 76;
	this.text_10.setTransform(-2.1,31.5,0.5,0.5);

	this.text_11 = new cjs.Text("4,0", "40px Verdana");
	this.text_11.lineHeight = 45;
	this.text_11.lineWidth = 70;
	this.text_11.setTransform(-2.1,64.6,0.5,0.5);

	this.text_12 = new cjs.Text("3,5", "40px Verdana");
	this.text_12.lineHeight = 45;
	this.text_12.lineWidth = 67;
	this.text_12.setTransform(-2.1,97.7,0.5,0.5);

	this.text_13 = new cjs.Text("3,0", "40px Verdana");
	this.text_13.lineHeight = 45;
	this.text_13.lineWidth = 69;
	this.text_13.setTransform(-2.1,130.9,0.5,0.5);

	this.text_14 = new cjs.Text("2,5", "40px Verdana");
	this.text_14.lineHeight = 45;
	this.text_14.lineWidth = 69;
	this.text_14.setTransform(-2.1,164,0.5,0.5);

	this.text_15 = new cjs.Text("2,0", "40px Verdana");
	this.text_15.lineHeight = 45;
	this.text_15.lineWidth = 66;
	this.text_15.setTransform(-2.1,197.1,0.5,0.5);

	this.text_16 = new cjs.Text("1,5", "40px Verdana");
	this.text_16.lineHeight = 45;
	this.text_16.lineWidth = 67;
	this.text_16.setTransform(-2.1,230.3,0.5,0.5);

	this.text_17 = new cjs.Text("1,0", "40px Verdana");
	this.text_17.lineHeight = 45;
	this.text_17.lineWidth = 68;
	this.text_17.setTransform(-2.1,263.4,0.5,0.5);

	this.text_18 = new cjs.Text("0,5", "40px Verdana");
	this.text_18.lineHeight = 45;
	this.text_18.lineWidth = 66;
	this.text_18.setTransform(-2.1,296.5,0.5,0.5);

	this.text_19 = new cjs.Text("0,0", "40px Verdana");
	this.text_19.lineHeight = 45;
	this.text_19.lineWidth = 71;
	this.text_19.setTransform(-2.1,329.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(104));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.1,-1.6,745.3,374.7);


(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);


(lib.btn_practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 8;
	this.text.setTransform(13.1,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape.setTransform(15,15.9,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(15,15.9,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,30,30.7);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-132.55,-12.9,265.1,25.8,6);
	this.shape.setTransform(132.3,12.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-132.55,-12.9,265.1,25.8,6);
	this.shape_1.setTransform(132.3,12.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-132.55,-12.9,265.1,25.8,6);
	this.shape_2.setTransform(132.3,12.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,265.1,25.8);


(lib.btn_Fals = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-132.55,-12.9,265.1,25.8,6);
	this.shape.setTransform(132.5,12.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("Au/MpIAA5RId/AAIAAZRg");
	this.shape.setTransform(26.7,-139.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("AyLPzIAA/lMAkXAAAIAAflg");
	this.shape.setTransform(103.4,112.2,1,1.222);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("AwtPVIAA+pMAhbAAAIAAepg");
	this.shape.setTransform(93.9,78.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_loader = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.mc_barras = new lib.mc_loader_barra();
	this.mc_barras.setTransform(22.9,30.1,1,1,0,0,0,13.6,22.8);

	this.timeline.addTween(cjs.Tween.get(this.mc_barras).wait(1).to({rotation:4.6},0).wait(1).to({rotation:9.1,y:30},0).wait(1).to({rotation:13.7},0).wait(1).to({rotation:18.2},0).wait(1).to({rotation:22.8},0).wait(1).to({rotation:27.3,y:30.1},0).wait(1).to({rotation:31.9},0).wait(1).to({rotation:36.5},0).wait(1).to({rotation:41,y:30},0).wait(1).to({rotation:45.6},0).wait(1).to({rotation:50.1},0).wait(1).to({rotation:54.7,y:30.1},0).wait(1).to({rotation:59.2},0).wait(1).to({rotation:63.8,y:30},0).wait(1).to({rotation:68.4},0).wait(1).to({rotation:72.9,y:30.1},0).wait(1).to({rotation:77.5},0).wait(1).to({rotation:82,y:30},0).wait(1).to({rotation:86.6,y:30.1},0).wait(1).to({rotation:91.1},0).wait(1).to({rotation:95.7},0).wait(1).to({rotation:100.3},0).wait(1).to({rotation:104.8,y:30},0).wait(1).to({rotation:109.4,y:30.1},0).wait(1).to({rotation:113.9},0).wait(1).to({rotation:118.5},0).wait(1).to({rotation:123,y:30},0).wait(1).to({rotation:127.6,y:30.1},0).wait(1).to({rotation:132.2},0).wait(1).to({rotation:136.7},0).wait(1).to({rotation:141.3,y:30},0).wait(1).to({rotation:145.8,y:30.1},0).wait(1).to({rotation:150.4,y:30},0).wait(1).to({rotation:154.9},0).wait(1).to({rotation:159.5},0).wait(1).to({rotation:164.1,y:30.1},0).wait(1).to({rotation:168.6},0).wait(1).to({rotation:173.2,y:30},0).wait(1).to({rotation:177.7},0).wait(1).to({rotation:182.4},0).wait(1).to({rotation:186.9,y:30.1},0).wait(1).to({rotation:191.5,y:30},0).wait(1).to({rotation:196,y:30.1},0).wait(1).to({rotation:200.6},0).wait(1).to({rotation:205.2},0).wait(1).to({rotation:209.7},0).wait(1).to({rotation:214.3},0).wait(1).to({rotation:218.8,y:30},0).wait(1).to({rotation:223.4},0).wait(1).to({rotation:227.9},0).wait(1).to({rotation:232.5},0).wait(1).to({rotation:237.1},0).wait(1).to({rotation:241.6,y:30.1},0).wait(1).to({rotation:246.2,y:30},0).wait(1).to({rotation:250.7},0).wait(1).to({rotation:255.3},0).wait(1).to({rotation:259.8},0).wait(1).to({rotation:264.4},0).wait(1).to({rotation:269,y:30.1},0).wait(1).to({rotation:273.5,y:30},0).wait(1).to({rotation:278.1,x:23,y:30.1},0).wait(1).to({rotation:282.6,x:22.9,y:30},0).wait(1).to({rotation:287.2,x:23},0).wait(1).to({rotation:291.7,x:22.9},0).wait(1).to({rotation:296.3},0).wait(1).to({rotation:300.9,x:23},0).wait(1).to({rotation:305.4,x:22.9,y:30.1},0).wait(1).to({rotation:310,y:30},0).wait(1).to({rotation:314.5,y:30.1},0).wait(1).to({rotation:319.1},0).wait(1).to({rotation:323.6,x:23,y:30},0).wait(1).to({rotation:328.2},0).wait(1).to({rotation:332.8,x:22.9},0).wait(1).to({rotation:337.3},0).wait(1).to({rotation:341.9},0).wait(1).to({rotation:346.4,y:30.1},0).wait(1).to({rotation:351,y:30},0).wait(1).to({rotation:355.5,y:30.1},0).wait(1).to({rotation:360},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,7.3,45.7,45.6);


(lib.popup_info2 = function() {
	this.initialize();

	// Capa 6
	this.txt_popup_info2 = new cjs.Text("", "20px Verdana");
	this.txt_popup_info2.lineHeight = 22;
	this.txt_popup_info2.lineWidth = 374;
	this.txt_popup_info2.setTransform(81.7,116.4);
var html = createDiv(txt['txt_popup_info2'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
    this.txt_popup_info2 = new cjs.DOMElement(html);;
    this.txt_popup_info2.setTransform(90, 116-608);
	
	this.instance_1 = new lib.Excel1();
	this.instance_1.setTransform(416.2,122.3,0.5,0.5);

	

	this.addChild(this.instance_1,this.txt_popup_info2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.mc_f3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.mc_f3_Int();
	this.instance.setTransform(112.6,188.7,1,1,0,0,0,112.6,188.7);
	this.instance.shadow = new cjs.Shadow("rgba(255,0,0,1)",1,2,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:112.5,regY:189.6,x:112.5,y:189.6},0).wait(15).to({alpha:0.5},15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,225.1,377.5);


(lib.popup_info = function() {
	this.initialize();

	
	// FlashAICB
	this.text = new cjs.Text("s", "38px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 43;
	this.text.lineWidth = 20;
	this.text.setTransform(789.6,506.3,0.5,0.5);

	this.text_1 = new cjs.Text("12", "38px Verdana");
	this.text_1.textAlign = "left";
	this.text_1.lineHeight = 43;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(737.6-23,513.6,0.5,0.5);

	this.text_2 = new cjs.Text("11", "38px Verdana");
	this.text_2.textAlign = "left";
	this.text_2.lineHeight = 43;
	this.text_2.lineWidth = 56;
	this.text_2.setTransform(709.7-33,513.6,0.5,0.5);

	this.text_3 = new cjs.Text("10", "38px Verdana");
	this.text_3.textAlign = "left";
	this.text_3.lineHeight = 43;
	this.text_3.lineWidth = 51;
	this.text_3.setTransform(665.4-33,513.6,0.5,0.5);

	this.text_4 = new cjs.Text("9", "38px Verdana");
	this.text_4.textAlign = "left";
	this.text_4.lineHeight = 43;
	this.text_4.lineWidth = 24;
	this.text_4.setTransform(626.1-23,513.6,0.5,0.5);

	this.text_5 = new cjs.Text("8", "38px Verdana");
	this.text_5.textAlign = "left";
	this.text_5.lineHeight = 43;
	this.text_5.lineWidth = 24;
	this.text_5.setTransform(585.8-23,513.6,0.5,0.5);

	this.text_6 = new cjs.Text("7", "38px Verdana");
	this.text_6.textAlign = "left";
	this.text_6.lineHeight = 43;
	this.text_6.lineWidth = 24;
	this.text_6.setTransform(545.4-23,513.6,0.5,0.5);

	this.text_7 = new cjs.Text("6", "38px Verdana");
	this.text_7.textAlign = "left";
	this.text_7.lineHeight = 43;
	this.text_7.lineWidth = 24;
	this.text_7.setTransform(505.2-23,513.6,0.5,0.5);

	this.text_8 = new cjs.Text("5", "38px Verdana");
	this.text_8.textAlign = "left";
	this.text_8.lineHeight = 43;
	this.text_8.lineWidth = 24;
	this.text_8.setTransform(464.9-23,513.6,0.5,0.5);

	this.text_9 = new cjs.Text("4", "38px Verdana");
	this.text_9.textAlign = "left";
	this.text_9.lineHeight = 43;
	this.text_9.lineWidth = 24;
	this.text_9.setTransform(424.6-23,513.6,0.5,0.5);

	this.text_10 = new cjs.Text("3", "38px Verdana");
	this.text_10.textAlign = "left";
	this.text_10.lineHeight = 43;
	this.text_10.lineWidth = 24;
	this.text_10.setTransform(384.3-23,513.6,0.5,0.5);

	this.text_11 = new cjs.Text("2", "38px Verdana");
	this.text_11.textAlign = "left";
	this.text_11.lineHeight = 43;
	this.text_11.lineWidth = 24;
	this.text_11.setTransform(344-23,513.6,0.5,0.5);

	this.text_12 = new cjs.Text("1", "38px Verdana");
	this.text_12.textAlign = "left";
	this.text_12.lineHeight = 43;
	this.text_12.lineWidth = 24;
	this.text_12.setTransform(303.7-23,513.6,0.5,0.5);

	this.text_13 = new cjs.Text("0", "38px Verdana");
	this.text_13.textAlign = "left";
	this.text_13.lineHeight = 43;
	this.text_13.lineWidth = 24;
	this.text_13.setTransform(263.3-23,513.6,0.5,0.5);

	this.text_14 = new cjs.Text("0", "38px Verdana");
	this.text_14.textAlign = "right";
	this.text_14.lineHeight = 43;
	this.text_14.lineWidth = 24;
	this.text_14.setTransform(201,498.8,0.5,0.5);

	this.text_15 = new cjs.Text("4", "38px Verdana");
	this.text_15.textAlign = "right";
	this.text_15.lineHeight = 43;
	this.text_15.lineWidth = 24;
	this.text_15.setTransform(201,434.8,0.5,0.5);

	this.text_16 = new cjs.Text("8", "38px Verdana");
	this.text_16.textAlign = "right";
	this.text_16.lineHeight = 43;
	this.text_16.lineWidth = 24;
	this.text_16.setTransform(201,378.9,0.5,0.5);

	this.text_17 = new cjs.Text("12", "38px Verdana");
	this.text_17.textAlign = "right";
	this.text_17.lineHeight = 43;
	this.text_17.lineWidth = 55;
	this.text_17.setTransform(201,320.7,0.5,0.5);

	this.text_18 = new cjs.Text("16", "38px Verdana");
	this.text_18.textAlign = "right";
	this.text_18.lineHeight = 43;
	this.text_18.lineWidth = 52;
	this.text_18.setTransform(201,265.1,0.5,0.5);

	this.text_19 = new cjs.Text("F", "38px Verdana");
	this.text_19.textAlign = "right";
	this.text_19.lineHeight = 43;
	this.text_19.lineWidth = 22;
	this.text_19.setTransform(201,208.1,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape.setTransform(207.4,477.2,0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_1.setTransform(207.4,447.8,0.5,0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,0,0,4).p("AhMAAICZAA");
	this.shape_2.setTransform(206.7,419.8,0.5,0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_3.setTransform(207.8,391.7,0.5,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_4.setTransform(207.8,362.3,0.5,0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_5.setTransform(207.8,334.3,0.5,0.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,0,0,4).p("AhMAAICZAA");
	this.shape_6.setTransform(208.5,305.3,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_7.setTransform(207.8,277.3,0.5,0.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICaAA");
	this.shape_8.setTransform(206.9,248.5,0.5,0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,0,0,4).p("AhNAAICbAA");
	this.shape_9.setTransform(207.3,219.6,0.5,0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("EhXZAAAMCu0AAA");
	this.shape_10.setTransform(483.2,505.8,0.5,0.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAgtrMAAABbX");
	this.shape_11.setTransform(211.3,364.5,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AGOgvIsbAAIAABfIMbAAg");
	this.shape_12.setTransform(729.3,503.2,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmNhaIAAC1IMbAAIAAi1g");
	this.shape_13.setTransform(688.8,501,0.5,0.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmNDyIMbAAIAAnjIsbAAg");
	this.shape_14.setTransform(648.7,493.5,0.5,0.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmNnwIAAPhIMbAAIAAvhg");
	this.shape_15.setTransform(608,480.7,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AGOuUIsbAAIAAcpIMbAAg");
	this.shape_16.setTransform(567.4,459.6,0.5,0.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmN21MAAAAtrIMbAAMAAAgtrg");
	this.shape_17.setTransform(527.7,432.6,0.5,0.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#00A2C7").ss(3,0,0,4).p("EAGOggrIsbAAMAAABBXIMbAAg");
	this.shape_18.setTransform(487.5,400.8,0.5,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#00A2C7").ss(3,0,0,4).p("EgGNgnDMAAABOHIMbAAMAAAhOHg");
	this.shape_19.setTransform(447.5,380.5,0.5,0.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#00A2C7").ss(3,0,0,4).p("EgGNgnDMAAABOHIMbAAMAAAhOHg");
	this.shape_20.setTransform(407.4,380.4,0.5,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmN/TMAAAA+nIMbAAMAAAg+ng");
	this.shape_21.setTransform(367.5,405.2,0.5,0.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AGOylIsbAAMAAAAlLIMbAAg");
	this.shape_22.setTransform(327.4,446.3,0.5,0.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AmNnTIAAOmIMbAAIAAumg");
	this.shape_23.setTransform(287.3,482.1,0.5,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#00A2C7").ss(3,0,0,4).p("AGbhlIs1AAIAADLIM1AAg");
	this.shape_24.setTransform(246.6,500.3,0.5,0.5);

	

	this.addChild(this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.btn_salir,this.instance,this.txt_popup_info);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}