Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar(this.nOp, Random.integer(0,Motor.lEnunciados[this.nOp].length-1));
			
			
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			
			
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function(contexto, enfoque)
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		//var nAux,rr;
		//var sAux;
		//var lAux;
		//var hor,min,seg,signo;
		//var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		//var a1,an;
		var lCardinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lOrdinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		var pi = Math.PI;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		
		
		this.enun = Motor.lEnunciados[contexto][enfoque];
		
		//console.log(this.enun);
		
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(contexto){
				case 0://DOS DEPÓSITOS DE AGUA
				var R1=Random.integer(100,200)/100;
				var R2=Random.integer(250,400)/100;
				this.enun=this.enun.replace('AAA',JL.num2str(R1,2));
				this.enun=this.enun.replace('AAA',JL.num2str(R2,2));
				var H1=Random.integer(60,95);
				this.enun=this.enun.replace('AAA',JL.num2str(H1,0));
				switch(enfoque){
					case 0:
						H2=R1*R1*H1/(R2*R2);
						this.lAlternativas=this.getAlternativas(H2,1,3);
						for(na=0;na<4;na++){
							lSP_alts[na] = this.lAlternativas[0][na] + ' cm';
							//EA.adc(lAlts[0][na]+' cm',lA[na]);
						}
					break;
					case 1:
						var V=pi*R1*R1*H1*10;
						this.lAlternativas=this.getAlternativas(V,0,3);
						for(na=0;na<4;na++){
							lSP_alts[na] = this.lAlternativas[0][na] + ' litros';
							//EA.adc(lAlts[0][na]+' litros',lA[na]);
						}
					break;
					case 2:
						var V=pi*R1*R1*H1*10;
						Q=Random.integer(30,80)/10;
						this.enun=this.enun.replace('AAA',JL.num2str(Q,1));
						var seg=Math.round(V/Q);
						
						this.lAlternativas=this.getAlternativas(seg,0,3);
						for(na=0;na<4;na++){
							var hms=JL.seg2sex(JL.str2num(this.lAlternativas[0][na]));
							if(hms[0]>0){
								lSP_alts[na] = JL.num2str(hms[0],0) + 'h';
								//EA.adc(JL.num2str(hms[0],0)+'h',lA[na]);
							}
							lSP_alts[na] = ' ' + JL.num2str(hms[1],0) + 'min' + ' ' + JL.num2str(hms[2],0) + 's';
							//EA.adc(' '+JL.num2str(hms[1],0)+"min ",lA[na]);
							//EA.adc(' '+JL.num2str(hms[2],0)+'s',lA[na]);
						}
					break;
				}
			    break;
				case 1://MONEDAS
					var VN=[2,5,10,20][Random.integer(0,3)];
					this.enun=this.enun.replace('AAA',JL.num2str(VN,0));
					q=Random.integer(6,18);
					var VT=q*VN;
					var D=Random.integer(16,25)/10;
					var e=Random.integer(18,24)/10;//mm
					var densidad=Random.integer(57,75)/10;//g/cm3
					//var V=pi*D*e*q/40;//cm3 antiguo
					var V=pi*D*D*e*q/40;//cm3
					var peso=V*densidad;
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(D,1));
							this.enun=this.enun.replace('AAA',JL.num2str(e,1));
							this.enun=this.enun.replace('AAA',JL.num2str(densidad,1));
							this.enun=this.enun.replace('AAA',JL.num2str(peso,1));
							this.lAlternativas=this.getAlternativas(q*VN,0,3);
							
							var lAE = new Array();
							var arrayNum = [6,7,8,9,10,11,12,13,14,15,16,17,18];
                            for (var vv in arrayNum) {
                                if (arrayNum[vv] != q) { 
                                    lAE.push(arrayNum[vv]); 
                                }
                            }
                            lAE = JL.barajar(lAE);
							
							for(na=0;na<4;na++){
								
								if (na != this.lAlternativas[1]) {
                                    var vAlt = VN * lAE.pop();
                                    //EA.adc(String(vAlt)+' �',lA[na]);
                                    lSP_alts[na] = String(vAlt) + ' €';
                                } else {
                                    //EA.adc(lAlts[0][na]+' �',lA[na]);
                                    lSP_alts[na] = this.lAlternativas[0][na] + ' €';
                                }
								
								//lSP_alts[na] = this.lAlternativas[0][na] + ' euros';
								//EA.adc(lAlts[0][na]+' euros',lA[na]);
							}
						break;
					}
				break;
				case 2://PINTAR UN DEPÓSITO
					var R1=Random.integer(200,400)/100;
					var H1=Random.integer(450,650)/100;
					var V=pi*R1*R1*H1*1000;
					var precio=Random.integer(500,1000)/100;
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(R1,2));
							this.enun=this.enun.replace('AAA',JL.num2str(V,0));
							this.enun=this.enun.replace('AAA',JL.num2str(precio,2));
							this.lAlternativas=this.getAlternativas(2*pi*R1*H1*precio,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' €';
								//EA.adc(lAlts[0][na]+' €',lA[na]);
							}
						break;
					}
				break;
				case 3://TUNEL DEL METRO
					var H1=Random.integer(1200,2500)/1000;//km
					var D=Random.integer(600,950)/100;//m
					var V=pi*D*D*H1*1000/4/2;//m3
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H1,3));
							this.enun=this.enun.replace('AAA',JL.num2str(D,2));
							this.lAlternativas=this.getAlternativas(V,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m' + '{{sup}}3{{normal}}';
								//EA.adc(lAlts[0][na],lA[na]);
								//EA.adc(EA.pot(' m',3),lA[na]);
							}
						break;
					}
				break;
				case 4://TRONCOS DE MADERA
					var densidad=Random.integer(41,92)/100;//g/cm3
					var q=Random.integer(120,470);
					var D=Random.integer(45,75);//cm
					var H1=Random.integer(550,780)/100;
					this.enun=this.enun.replace('AAA',JL.num2str(densidad,2));
					this.enun=this.enun.replace('AAA',JL.num2str(q,0));
					this.enun=this.enun.replace('AAA',JL.num2str(H1,2));
					this.enun=this.enun.replace('AAA',JL.num2str(D,0));
					var V=pi*D*D/4*H1*100;//cm3
					var pesoPorArbol = V*densidad/1000000;//Tm por árbol
					var pesoPorCamion = Random.integer(18,24);//Tm
					this.enun=this.enun.replace('AAA',JL.num2str(pesoPorCamion,0));
					var qArbolesPorCamion = Math.floor(pesoPorCamion/pesoPorArbol);
					this.lAlternativas=this.getAlternativas(Math.floor(1+q/qArbolesPorCamion),0,3);
					for(na=0;na<4;na++){
						lSP_alts[na] = this.lAlternativas[0][na] + ' viajes';
						//EA.adc(lAlts[0][na]+' viajes',lA[na]);
					}
				break;
				case 5://INYECCIÓN
					var D=Random.integer(16,23);//mm
					var H1=Random.integer(35,60);//mm
					this.enun=this.enun.replace('AAA',JL.num2str(D,0));
					this.enun=this.enun.replace('AAA',JL.num2str(H1,0));
					var D1=Random.integer(2,8)/10;//mm
					this.enun=this.enun.replace('AAA',JL.num2str(D1,1));
					var H2=H1*Math.pow(D/D1,2)/1000;//m
					this.lAlternativas=this.getAlternativas(H2,0,3);
					for(na=0;na<4;na++){
						lSP_alts[na] = this.lAlternativas[0][na] + ' m';
						//EA.adc(lAlts[0][na]+' m',lA[na]);
					}
				break;
				case 6://TANQUES DE COMBUSTIBLE SHUTTLE
					var D=Random.integer(710,950)/100;//m
					var H1=Random.integer(410,490)/10;//m
					this.enun=this.enun.replace('AAA',JL.num2str(H1,1));
					this.enun=this.enun.replace('AAA',JL.num2str(D,2));
					var V=pi*D*D/4*H1;//m3
					var T=Random.integer(350,650);
					this.enun=this.enun.replace('AAA',String(Math.floor(T/60))+"min "+String(T%60)+'s');
					this.lAlternativas=this.getAlternativas(1000*V/T,0,3);
					for(na=0;na<4;na++){
						lSP_alts[na] = this.lAlternativas[0][na] + ' l/s';
						//EA.adc(lAlts[0][na]+' l/s',lA[na]);
					}
				break;
				case 7://COLUMNAS DE UN TEMPLO
					var q=Random.integer(26,54);
					var H1=Random.integer(61,99)/10;//m
					var D=Random.integer(410,990)/10;//cm
					this.enun=this.enun.replace('AAA',JL.num2str(q,0));
					this.enun=this.enun.replace('AAA',JL.num2str(H1,1));
					this.enun=this.enun.replace('AAA',JL.num2str(D,0));
					var D1=D*Math.sqrt(q)/100;
					this.lAlternativas=this.getAlternativas(D1,2,3);
					for(na=0;na<4;na++){
					    lSP_alts[na] = this.lAlternativas[0][na] + ' m';
						//EA.adc(lAlts[0][na]+' m',lA[na]);
					}
				break;
				case 8://PLACA DE DVD
                    var D=Random.integer(5,16);//mm
                    var D1=Random.integer(51,88)/10;//cm
                    var e=Random.integer(8,18)/10;//mm
                    var densidad=Random.integer(290,390)/100;//g/cm3
                    var q=Random.integer(45,85);//mm
                    this.enun=this.enun.replace('AAA',JL.num2str(D1,1));
                    this.enun=this.enun.replace('AAA',JL.num2str(D,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(e,1));
                    this.enun=this.enun.replace('AAA',JL.num2str(densidad,2));
                    this.enun=this.enun.replace('AAA',JL.num2str(q,0));
                    var V=q*pi*(D1*D1-D*D/100)/4*e/10;
                    this.lAlternativas=this.getAlternativas(V*densidad,0,3);
                    for(na=0;na<4;na++){
                        lSP_alts[na] = this.lAlternativas[0][na] + ' g';
                        //EA.adc(lAlts[0][na]+' g',lA[na]);
                    }
                break;
				case 9:
    				var q=Random.integer(15,24);
                    var q2=Random.integer(25,39);
                    var L=Random.integer(71,98);//cm
                    var L1=Random.integer(121,168);//cm
                    var D=Random.integer(21,48)/10;//cm
                    var D1=Random.integer(61,88)/10;//cm
                    this.enun=this.enun.replace('AAA',JL.num2str(q+q2,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(q,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(L,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(D,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(L1,0));
                    this.enun=this.enun.replace('AAA',JL.num2str(D1,0));
                    
                    var V=pi*(q*D*D*L+q2*D1*D1*L1)/4000;//litros
                    this.lAlternativas=this.getAlternativas(V,0,3);
                    for(na=0;na<4;na++){
                        lSP_alts[na] = this.lAlternativas[0][na] + ' l';
                        //EA.adc(lAlts[0][na]+' l',lA[na]);
                    }
                break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=this.lAlternativas[1];
			//lRespuestasOK[nOp]=lAlts[1];
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=r.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}