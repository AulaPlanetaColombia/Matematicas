Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();

	
	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 235 ;
	//final
	this.PREG_FINAL_X_PADDING = 585 ;
	
	this.RESP_HEIGHT = 82;
	this.RESP_WIDTH = 322; 
	this.RESP_INNER_HEIGHT = 78;
	this.RESP_INNER_WIDTH = 320; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.IMG = "data/imagenes/";
	
	//GUINARDO
	this.lEnunciados=new Array();
	this.qEnunciados = 0;
	this.listAux= new Array();
	this.qOperaciones;
	this.lOperaciones = new Array();
	this.co_pizarra;
	
	this.ponerContenedor = function(contenedorMotor) {

	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('qOperaciones').text();
				        
	        var seed = $(xml).find('seed');
	        Motor.datosXML.seed = seed.text();
			
			Motor.datosXML.preguntas= new Array();
			$(xml).find('enunciado').each(function(index) {
				//debugger;
				this.preg = new pregunta();
				this.preg.id = index;
				var padre = this.preg;
				$(this).children('enfoque').each(function(index2) {
					this.enfoque = new enfoque();
					this.enfoque.id = index2
					this.enfoque.enunciado = $(this).text();
					padre.enunciado.push(this.enfoque);
				});
				//var enfoque = $(this).children('enfoque');
			  	Motor.datosXML.preguntas.push(this.preg);
			  	
			});
			//console.log(Motor.datosXML.preguntas.length);
			//console.log(Motor.datosXML.preguntas);

	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
		});
	}
	this.inicializarEstructura = function(estado) {
		
		this.initGenerador();
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
	  	var total = 0;
	  	for(key1 in Motor.pagines){
	  		var contestada = false
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			if(Motor.pagines[key1].respostes[key2].checked )
	   			{
	   				contestada = true;
	   			}
			}
			if( !contestada ) return false;
		}
		return true;
	};
	
	this.getEstado = function(){
        var estado = new Array();
        
        var respuesta = "";
        
        for(key1 in Motor.pagines)
        {
            respuesta = respuesta + "AAA";
            var pagina = new Array();
            var encontrado = false;
            for(var key3 in Motor.pagines[key1].respostes)
            {
                if( Motor.pagines[key1].respostes[key3].checked ){
                    //console.log("opcion marcada : " + key3);
                    //pagina.push(key3);
                    respuesta = respuesta + key3.toString();
                    encontrado = true;
                }
            }
        }
        return respuesta;
    };
    
    this.revisar = function(){
        if(this.estado != "")
        {
            var lRespuestas = this.estado.split("AAA");
            lRespuestas.splice(0,1);
            for(var i=0; i < this.qOperaciones; i++){

                for (key2 in Motor.pagines[i].respostes){
                    if( lRespuestas[i] !="" && (Motor.pagines[i].respostes[key2].id ==  lRespuestas[i]) ) {
                        Motor.pagines[i].respostes[key2].pressHandler();
                    } 
                }

            }
        }
    };
	
	this.validar = function() {
		var total = 0;
	  	for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			Motor.pagines[key1].respostes[key2].desactivar();
	   			
	   			if(Motor.pagines[key1].respostes[key2].checked && Motor.pagines[key1].respostes[key2].correcte != "0")
	   			{
	   				Motor.pagines[key1].respostes[key2].correct();
	   				
	   			}
	   			else if(Motor.pagines[key1].respostes[key2].checked && Motor.pagines[key1].respostes[key2].correcte == "0")
	   			{
	   				Motor.pagines[key1].respostes[key2].error();
	   				Motor.pagines[key1].validacio = false;
	   			}
	   			else if(Motor.pagines[key1].respostes[key2].correcte != "0" && !Motor.pagines[key1].respostes[key2].checked )
	   			{
	   				Motor.pagines[key1].validacio = false;
	   			}
			}
			if(Motor.pagines[key1].validacio) total++;
		}
		return total.toString() +  "/" + Motor.pagines.length.toString();
	};
	this.hideDomObjects = function(){

	}
	this.showDomObjects = function(){

	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
        for(key1 in Motor.pagines){
            for (key2 in Motor.pagines[key1].respostes) 
            {
                Motor.pagines[key1].respostes[key2].activar();
            }   
        }
    }
    this.desactivar = function() {
        for(key1 in Motor.pagines){
            for (key2 in Motor.pagines[key1].respostes) 
            {
                Motor.pagines[key1].respostes[key2].desactivar();
            }   
        }
    };
	this.numPaginas = function(){
		return Motor.datosXML.cantidad;
	};
	this.ponerPagina = function(pag) {
		this.contenedor.removeChild( this.currentPag.contenedor );
		this.currentNumPag = pag - 1;
	    this.currentPag = this.pagines[this.currentNumPag];
	    this.contenedor.addChild( this.currentPag.contenedor );
	    
	};
	
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		
	};
	this.deseleccionar = function(){
		/*for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			Motor.pagines[key1].respostes[key2].desactivar();
	   			Motor.pagines[key1].respostes[key2].clear();
			}
		}*/
	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
	  	for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			if( Motor.pagines[key1].respostes[key2].correcte != "0")
	   			{
	   				Motor.pagines[key1].respostes[key2].bona();

	   			}
			}
		}
	}
	this.obtenerTipoEjercicio = function() {

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		this.pagines= new Array();

	    for(var i=0; i < Motor.datosXML.cantidad; i++)
    	{
	    	var index = 0;			
			var pregunta = Motor.datosXML.preguntas[index];
			Motor.datosXML.preguntas.splice(index,1);

	    	this.addPagina( pregunta, i , index);
	    }
	    this.contenedor.addChild( this.pagines[0].contenedor );
	    this.currentPag = this.pagines[0] ;
	    this.currentNumPag = 0;
	    
	    Main.stage.addChild( this.contenedor );
	    
    }
    
    this.addPagina = function( pregunta, numpagina , idPregunta)
    {
    	//console.log(pregunta);
    	var pagina = new Pagina( pregunta, numpagina, Motor.lOperaciones[numpagina]);
    	pagina.contenedor.y = this.INITIAL_Y;
    	this.pagines.push( pagina );
    	
    }
    
    this.initGenerador = function()
    {
    	var seed = Motor.datosXML.seed;
		//var tira = new XML(m.xmlExterno);
		//var tiraList = new XMLList(tira.enunciados.enunciado);
		//trace(tiraList);
		this.lEnunciados = new Array();
		this.lQEnfoques=new Array();
		this.qEnunciados = 0;
		this.listAux= new Array();
		this.lOperaciones = new Array();
		//console.log(Motor.datosXML.preguntas);
		for(var key in Motor.datosXML.preguntas){
			this.lEnunciados[key]=new Array();
			//console.log(Motor.datosXML.preguntas[key].enunciado);
			//console.log("se termina enunaciadoo!!!")
			for( var enf in Motor.datosXML.preguntas[key].enunciado ){
				var ss = Motor.datosXML.preguntas[key].enunciado[enf].enunciado.toString();
				ss=JL.reemplazar(ss,'NNN','\n');
				this.lEnunciados[key].push(ss);
			}
			this.lQEnfoques[key]=this.lEnunciados[key].length;
		}
		//console.log(this.lQEnfoques);
		this.qEnunciados = this.lEnunciados.length;
		this.listAux= Motor.datosXML.enunciadosAux;
		this.co_pizarra= new createjs.Container();
	
		/////extrar qOperaciones
		this.qOperaciones = Motor.datosXML.cantidad;

		if(Scorm.modo == Scorm.MODO_EXPONER){
			Generador.generarSerie(JL.iRandom(10000,100000));
		}else{
			Generador.generarSerie(seed);
		}
		//console.log(Motor.lOperaciones);
    }

}
