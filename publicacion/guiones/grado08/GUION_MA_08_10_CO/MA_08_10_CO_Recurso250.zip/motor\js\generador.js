Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar(this.nOp, Random.integer(0,Motor.lEnunciados[this.nOp].length-1));
			
			
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			
			
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function(contexto, enfoque){
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		//var nAux,rr;
		//var sAux;
		//var lAux;
		//var hor,min,seg,signo;
		//var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		//var a1,an;
		var lCardinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lOrdinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		var pi = Math.PI;
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		var modelo = this.nOp % Motor.qEnunciados;
		//console.log("modelo "+modelo);
		//modelo=1;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		
		
		this.enun = Motor.lEnunciados[contexto][enfoque];
				
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================
			switch(contexto){
				case 0://DOS CANICAS
                    var R1=Random.integer(15,35);//mm
                    var R2=Random.integer(21,44);//mm
                    var V=4*pi*Math.pow(R1,3)/3;//mm3
                    var V2=4*pi*Math.pow(R2,3)/3;//mm3
                    this.enun=this.enun.replace('AAA',JL.num2str(V/1000,2));
                    this.enun=this.enun.replace('AAA',JL.num2str(V2/1000,2));
                    switch(enfoque){
                        case 0:
                            this.lAlternativas=this.getAlternativas(R1+R2,0,3);
                            for(na=0;na<4;na++){
                                if(na==this.lAlternativas[1]){
                                    lSP_alts[na] = this.lAlternativas[0][na] + ' mm';
                                    //EA.adc(lAlts[0][na]+' mm',lA[na]);
                                }else{
                                    if(Random.boolean(0.5)){
                                        lSP_alts[na] = this.lAlternativas[0][na] + ' mm';
                                        //EA.adc(lAlts[0][na]+' mm',lA[na]);
                                    }else{
                                        lSP_alts[na] = this.lAlternativas[0][na] + ' mm';
                                        //EA.adc(lAlts[0][na]+' mm',lA[na]);
                                    }
                                }
                            }
                        break;
                    }
                break;
				case 1://RACIMO UVAS
                    var Q=Random.integer(31,99);//q de uvas
                    var D=Random.integer(8,19);//mm diám.uva
                    var densidad=Random.integer(91,109)/100;//g/cm2
                    var V=Q*4*pi*Math.pow(D/2,3)/3000;//cm3 totales
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(D,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(densidad,2));
                            this.lAlternativas=this.getAlternativas(V*densidad,1,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' g';
                                //EA.adc(lAlts[0][na]+' g',lA[na]);
                            }
                        break;
                        case 1:
                            this.enun=this.enun.replace('AAA',JL.num2str(D,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(densidad,2));
                            this.enun=this.enun.replace('AAA',JL.num2str(V*densidad,1));
                            this.lAlternativas=this.getAlternativas(Q,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' granos';
                                //EA.adc(lAlts[0][na]+' granos',lA[na]);
                            }
                        break;
                        case 2:
                            this.enun=this.enun.replace('AAA',JL.num2str(D,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(V*densidad,1));
                            this.lAlternativas=this.getAlternativas(densidad,3,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' g/cm' + '{{sup}}3{{normal}}';
                                //EA.adc(lAlts[0][na],lA[na]);
                                //EA.adc(EA.pot(' g/cm','3'),lA[na]);
                            }
                        break;
                    }
                break;
				case 2://OBSERVATORIO Y TELESCOPIO
                    var D=Random.integer(251,399)/10;//m
                    this.enun=this.enun.replace('AAA',JL.num2str(D,1));
                    var V=2*pi*Math.pow(D/2,3)/3;//m3
                    var L2=Random.integer(71,199)/10;//m
                    var D2=Random.integer(61,119);//cm
                    this.enun=this.enun.replace('AAA',JL.num2str(L2,1));
                    this.enun=this.enun.replace('AAA',JL.num2str(D2,0));
                    var V2=pi*D2*D2*L2/40000;//m3
                    switch(enfoque){
                        case 0:
                            this.lAlternativas=this.getAlternativas(1000*V2/V,3,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na];
                                //EA.adc(lAlts[0][na],lA[na]);
                            }
                        break;
                    }
                break;
				case 3://SUPERFICIE DE UN PLANETA
                    var R=Random.integer(1500,8000);//km
                    var f=Random.integer(41,85);//%
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(R,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(f,0));
                            var S=4*pi*R*R*(100-f)/100;//km2
                            this.lAlternativas=this.getAlternativas(S,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' km' + '{{sup}}2{{normal}}';
                                //EA.adc(lAlts[0][na],lA[na]);
                                //EA.adc(EA.pot(' km','2'),lA[na]);
                            }
                        break;
                        case 1:
                            this.enun=this.enun.replace('AAA',JL.num2str(R,0));
                            var S=4*pi*R*R*f/100;//km2
                            this.enun=this.enun.replace('AAA',JL.num2str(S,0));
                            this.lAlternativas=this.getAlternativas(100-f,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + '%';
                                //EA.adc(lAlts[0][na]+'%',lA[na]);
                            }
                        break;
                    }
                break;
				case 4://GRIFO QUE GOTEA
                    var Q=Random.integer(3,15);//gotas por segundo
                    var D=Random.integer(31,75)/10;//mm diámetro gota
                    var V2=[2,4,5,6,10,12,15,20,25,50][Random.integer(0,9)];//litros del cubo
                    var V=4*pi*Math.pow(D/2,3)/3000;//cm3 por gota
                    var T=Math.round(1000*V2/(Q*V));//segundos total
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(D,1));
                            this.enun=this.enun.replace('AAA',JL.num2str(V2,0));
                            this.lAlternativas=this.getAlternativas(T,0,3);
                            for(na=0;na<4;na++){
                                var lAux=JL.seg2sex(JL.str2num(this.lAlternativas[0][na]));
                                if(lAux[0]>0){
                                    lSP_alts[na] = lAux[0].toString() + ' h';
                                    //EA.adc(String(lAux[0])+" h",lA[na]);
                                }
                                lSP_alts[na] = lSP_alts[na] + ' ' + lAux[1].toString() + ' min';
                                lSP_alts[na] = lSP_alts[na] + ' ' + lAux[2].toString() + ' s';
                                //EA.adc(' '+String(lAux[1])+" min ",lA[na]);
                                //EA.adc(' '+String(lAux[2])+' s',lA[na]);
                            }
                        break;
                    }
                break;
				case 5://PINTANDO DEPÓSITOS
                    var Q=Random.integer(3,12);//depósitos
                    var R=Random.integer(31,65)/10;//m diámetro cada depósito
                    var V=Q*4*pi*Math.pow(R,3)/3;//m3 totales
                    var S=Q*4*pi*R*R;//m2 totales a pintar
                    var precio=Random.integer(760,980)/100;//euros por m2
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(V,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(precio,2));
                            this.lAlternativas=this.getAlternativas(precio*S,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' €';
                                //EA.adc(lAlts[0][na]+' €',lA[na]);
                            }
                        break;
                    }
                break;
				case 6://RECORRIENDO UN PLANETA
                    var R=Random.integer(1471,3299);//km radio planeta
                    var V=4*pi*Math.pow(R,3)/3;//km3 totales
                    var L=2*pi*R;//km del ecuador
                    var Q=Random.integer(3,12);//vueltas completas
                    var L2=L*Q;//km totales recorridos
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(R,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.lAlternativas=this.getAlternativas(L2,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' km';
                                //EA.adc(lAlts[0][na]+' km',lA[na]);
                            }
                        break;
                        case 1:
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(L2,0));
                            this.lAlternativas=this.getAlternativas(R,0,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' km';
                                //EA.adc(lAlts[0][na]+' km',lA[na]);
                            }
                        break;
                    }
                break;
				case 7://BURBUJAS
                    var R=Random.integer(41,154)/10;//mm diámetro burbuja grande
                    var V=4*pi*Math.pow(R,3)/3;//mm3 de la burbuja
                    var Q=Random.integer(15,29);//cantidad de burbujitas
                    var R1=R/JL.getRaizCubica(Q);
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(2*R,1));
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.lAlternativas=this.getAlternativas(2*R1,2,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' mm';
                                //EA.adc(lAlts[0][na]+' mm',lA[na]);
                            }
                        break;
                    }
                break;
				case 8://VASO CON BOLITAS
                    var R=Random.integer(81,129)/10;//mm diámetro bolita
                    var Q=Random.integer(8,19);//cantidad de bolitas
                    var V=Q*4*pi*Math.pow(R,3)/3000;//cm3 totales
                    var D1=Random.integer(31,45)/10;//cm diámetro vaso
                    var S=pi*D1*D1/4;//cm2 superficie base vaso
                    switch(enfoque){
                        case 0:
                            this.enun=this.enun.replace('AAA',JL.num2str(Q,0));
                            this.enun=this.enun.replace('AAA',JL.num2str(R,1));
                            this.enun=this.enun.replace('AAA',JL.num2str(D1,1));
                            //this.lAlternativas=this.getAlternativas(V*10/S,1,3);
                            this.lAlternativas=this.getAlternativas(V/S,1,3);
                            for(na=0;na<4;na++){
                                lSP_alts[na] = this.lAlternativas[0][na] + ' cm';
                                //EA.adc(lAlts[0][na]+' mm',lA[na]);
                            }
                        break;
                    }
                break;
				case 9://IGLÚ
    			var R1=Random.integer(215,255)/100;//m radio i del igloo
                var e=Random.integer(21,39);//cm espesor pared hielo
                var R2=R1+e/100;//m radio e del igloo
                var V=2*pi*(Math.pow(R2,3)-Math.pow(R1,3))/3;//m3 de pared de hielo
                switch(enfoque){
                    case 0:
                        this.enun=this.enun.replace('AAA',JL.num2str(2*R1,2));
                        this.enun=this.enun.replace('AAA',JL.num2str(e,0));
                        this.lAlternativas=this.getAlternativas(V,1,3);
                        for(na=0;na<4;na++){
                            lSP_alts[na] = this.lAlternativas[0][na] + ' m' + '{{sup}}3{{normal}}';
                            //EA.adc(lAlts[0][na],lA[na]);
                            //EA.adc(EA.pot(' m','3'),lA[na]);
                        }
                    break;
                }
                break;
			}
		}
		
		//console.log("lAlternativas: "+this.lAlternativas);
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){
			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');
			//this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			//this.enun=this.enun.replace('ZZ3',JL.superI('3',20));
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=this.lAlternativas[1];
			//lRespuestasOK[nOp]=lAlts[1];
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=r.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v,-1));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok,-1);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}