Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones=new Array();
	
	this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",20,0x000000,false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
	
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {
			//enunciar(this.nOp,0);
			this.enunciar()
			
			//enunciar(this.nOp,this.Random.integer(0,lQEnfoques[this.nOp]-1));
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].enunciadoParseado=this.lEnunciados_STRING[this.nOp];
			Motor.lOperaciones[this.nOp].RespuestaSprite=this.llRespuestas_SPRITE[this.nOp];
			//console.log("op "+ this.nOp);
			Motor.lOperaciones[this.nOp].preguntaSprite=this.lEnunciados_SPRITE[this.nOp];
			////co_pizarra addchilar
			Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
			Motor.lOperaciones[this.nOp].preguntaSprite.y=200;
			Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
			Motor.lOperaciones[this.nOp].entrada=0;
			Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		for(var i=0;i<Motor.qOperaciones;i++){
			for(var j=0;j<4;j++){
				var ea=this.llRespuestas_SPRITE[i][j];
				ea.x=120;ea.y=240+70*j+40;
				Motor.co_pizarra.addChild(ea);
			}
		}
	}
	
	this.enunciar = function()
	{
		//prepara containers:
		//JL.vaciarContainer(co_pregunta);
		var co_pregunta=new createjs.Container();
		//JL.vaciarContainer(this.co_respuestas);
		var sp_alt=new createjs.Container();
		//console.log("qAlternativas: "+this.qAlternativas);
		var lSP_alts=new Array();
		for(var na=0;na<this.qAlternativas;na++){
			sp_alt="";//EA.ini(' ');
			lSP_alts.push(sp_alt);
			/*if(!this.bModoPLAY){
				sp_alt.x=80;sp_alt.y=250+60*na;
				this.co_respuestas.addChild(sp_alt);
			}*/
		}
		//declara variables internas:
		var nAux,rr;
		var sAux;
		var lAux;
		var hor,min,seg,signo;
		var a,b,c,d,e,f,g,h,i,j,k,l,m,n,p,q,s,t,u,v,w;
		var a1,an;
		var lCardinales=['cero','uno','dos','tres','cuatro','cinco','seis','siete','ocho','nueve','diez','once','doce','trece','catorce','quince'];
		var lOrdinales=['','primer','segundo','tercer','cuarto','quinto','sexto','séptimo','octavo','noveno','décimo','onceavo','doceavo'];
		//
		//console.log("qEnunciados: "+Motor.qEnunciados);
		//var modelo = this.nOp % Motor.qEnunciados;

		var enfoque = Random.integer(0, Motor.datosXML.preguntas[this.nOp].length-1);
		this.enun=Motor.datosXML.preguntas[this.nOp].enunciado[enfoque].enunciado;


		var densidad,litros,qB,V,H,LH,WH,lAux,nAux;
		//this.enun = Motor.lEnunciados[this.nOp];
		var nOK;
		var resp;
		this.lAlternativas;
		//AQUÍ VA CÓDIGO ESPECÍFICO =================================================================
		var bAlternativasClasico=true;//a variar según el caso (en tiempo de desarrollo)
		if(bAlternativasClasico){
			//getAlternativas numérico "clásico" ====================================================

			switch(this.nOp){
				case 9://CAJA DE CERILLAS
					//decide y calcula datos:
					WH=Random.integer(10,26)/10;//cm
					LH=WH+Random.integer(10,25)/10;//cm
					H=Random.integer(8,20);//mm
					V=WH*LH*H/10;//cm3
					qB=[20,40,50,80,100,150,200][Random.integer(0,6)];
					litros=[0.2,0.33,0.5,0.75][Random.integer(0,3)];
					densidad=qB/V;//cerillas/cm3
					qCerillas=Math.round(litros*1000*densidad);
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H,0));
							this.enun=this.enun.replace('AAA',JL.num2str(litros,2));
							this.lAlternativas=this.getAlternativas(qCerillas,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' cerillas';
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H,0));
							nAux=Random.integer(5,20);//cerillas/cm3
							this.enun=this.enun.replace('AAA',JL.num2str(nAux*1000,0));
							this.lAlternativas=this.getAlternativas(Math.floor(nAux*V),0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' cerillas';
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H,0));
							this.lAlternativas=this.getAlternativas(densidad*1000,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' cerillas dm{{sup}}3{{normal}}';
							}
						break;
					}
				break;
				case 8://BALDOSAS HEXAGONALES
					//decide y calcula datos:
					qB=Random.integer(1200,1800);
					LB=Random.integer(150,300)/10;//cm
					eH=Random.integer(10,20);//mm
					AB=6*LB*LB*Math.cos(Math.PI/6)/2;//cm2
					V=qB*AB*eH/10;//cm3
					V/=1000000;//m3
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(eH,0));
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.lAlternativas=this.getAlternativas(V,2,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' m{{sup}}3{{normal}}';
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(eH,0));
							this.enun=this.enun.replace('AAA',JL.num2str(V,2));
							this.lAlternativas=this.getAlternativas(qB,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' baldosas';
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(V,2));
							this.lAlternativas=this.getAlternativas(eH,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' mm';
							}
						break;
					}
				break;
				case 7://EL PENTÁGONO
					//decide y calcula datos:
					R2=Random.integer(75,99);
					R1=R2+Random.integer(15,30);
					H=Random.integer(10,22);
					nAux=JL.deg2rad(36);

					PB1=5*2*R1*Math.sin(nAux);
					PB2=5*2*R2*Math.sin(nAux);
					V=Math.round(5*H*Math.sin(nAux)*Math.cos(nAux)*(R1*R1-R2*R2));
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(PB1,1));
							this.enun=this.enun.replace('AAA',JL.num2str(R2,0));
							this.lAlternativas=this.getAlternativas(V,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' m{{sup}}3{{normal}}';
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(PB1,1));
							this.enun=this.enun.replace('AAA',JL.num2str(R2,0));
							this.lAlternativas=this.getAlternativas((PB1+PB2)*H,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' m{{sup}}3{{normal}}';
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(PB1,1));
							this.enun=this.enun.replace('AAA',JL.num2str(R2,0));
							this.lAlternativas=this.getAlternativas(R1-R2,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' m';
							}
						break;
					}
				break;
				case 6://LOUVRE
					//decide y calcula datos:
					LB=Random.integer(250,400)/10;
					H=Random.integer(150,250)/10;
					V=H*LB*LB/3;
					PB=4*LB;
					apL=Math.sqrt(H*H+LB*LB/4);
					AL=2*LB*apL;
					tpu=Random.integer(30,55);
					qPersonas=Random.integer(2,8);
					T=AL*tpu/qPersonas;
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qPersonas,0));
							this.enun=this.enun.replace('AAA',JL.num2str(tpu,0));
							this.lAlternativas=this.getAlternativas(Math.round(T),0,3);
							for(na=0;na<4;na++){
								lAux=JL.seg2sex(JL.str2num(this.lAlternativas[0][na]));
								lSP_alts[na] = String(lAux[0]) + ' h' + ' ' + String(lAux[1]) + ' min' + ' ' + String(lAux[2]) + ' s';

								/*EA.adc(String(lAux[0])+" h",lA[na]);
								EA.adc(' '+String(lAux[1])+" min ",lA[na]);
								EA.adc(' '+String(lAux[2])+' s',lA[na]);*/
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(PB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qPersonas,0));
							this.enun=this.enun.replace('AAA',JL.num2str(tpu,0));
							this.lAlternativas=this.getAlternativas(Math.round(T),0,3);
							for(na=0;na<4;na++){
								lAux=JL.seg2sex(JL.str2num(this.lAlternativas[0][na]));
								lSP_alts[na] = String(lAux[0]) + ' h' + ' ' + String(lAux[1]) + ' min' + ' ' + String(lAux[2]) + ' s';
								/*EA.adc(String(lAux[0])+" h",lA[na]);
								EA.adc(' '+String(lAux[1])+" min",lA[na]);
								EA.adc(' '+String(lAux[2])+' s',lA[na]);*/
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.enun=this.enun.replace('AAA',JL.num2str(PB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qPersonas,0));
							this.enun=this.enun.replace('AAA',JL.num2str(tpu,0));
							this.lAlternativas=this.getAlternativas(Math.round(T),0,3);
							for(na=0;na<4;na++){
								lAux=JL.seg2sex(JL.str2num(this.lAlternativas[0][na]));
								lSP_alts[na] = String(lAux[0]) + ' h' + ' ' + String(lAux[1]) + ' min' + ' ' + String(lAux[2]) + ' s';
								/*EA.adc(String(lAux[0])+" h",lA[na]);
								EA.adc(' '+String(lAux[1])+" min",lA[na]);
								EA.adc(' '+String(lAux[2])+' s',lA[na]);*/
							}
						break;
					}
				break;
				case 5://TOLVA
					//decide y calcula datos:
					LB=Random.integer(20,50)/10;
					H=Random.integer(15,35)/10;
					if(enfoque<2){
						V=1000*H*LB*LB*Math.sqrt(3)/12;
					}else{
						V=1000*H*LB*LB/3;
					}
					Q=Random.integer(80,150)/10;
					T=Math.round(V/Q);
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(Q,1));
							this.lAlternativas=this.getAlternativas(Math.round(T),0,3);
							for(na=0;na<4;na++){
								nAux=JL.str2num((this.lAlternativas[0][na]));
								min=Math.floor(nAux/60);
								seg=nAux%60;
								lSP_alts[na] = String(min)+' min ' + ' ' + String(seg)+' s';
								/*EA.adc(String(min)+" min ",lA[na]);
								EA.adc(' '+String(seg)+' s',lA[na]);*/
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							T=Math.round(T);
							sAux=String(Math.floor(T/60))+" min "+String(T%60)+' s';
							enun=enun.replace('AAA',sAux);
							this.lAlternativas=this.getAlternativas(Q,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na]+' l/s';
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(Q,1));
							this.lAlternativas=this.getAlternativas(Math.round(T),0,3);
							for(na=0;na<4;na++){
								nAux=JL.str2num((lAlts[0][na]));
								min=Math.floor(nAux/60);
								seg=nAux%60;
								lSP_alts[na] = String(min)+' min ' + ' ' + String(seg)+' s';
							}
						break;
					}
				break;
				case 4://CAMPANARIO
					//decide y calcula datos:
					H1=Random.integer(250,500)/10;
					H2=Random.integer(40,70)/10;
					LB=Random.integer(30,50)/10;
					V=LB*LB*(H1+H2/3);
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H1,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H2,1));
							this.enun=this.enun.replace('AAA',JL.num2str(4*LB,1));
							this.lAlternativas=this.getAlternativas(V,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m{{sup}}3{{normal}}';
								/*EA.adc(lAlts[0][na]+' ',lA[na]);
								EA.adc(EA.pot(' m','3'),lA[na]);*/
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(4*LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H1+H2,1));
							this.lAlternativas=this.getAlternativas(H2,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m';
								//EA.adc(lAlts[0][na]+' m',lA[na]);
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(H2,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H1,1));
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.lAlternativas=this.getAlternativas(LB,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m';
								//EA.adc(lAlts[0][na]+' m',lA[na]);
							}
						break;
					}
				break;
				case 3://OBELISCO
					//decide y calcula datos:
					H=Random.integer(20,60);
					LB=Random.integer(50,180)/10;
					AB=LB*LB;
					V=AB*H/3;
					apL=Math.sqrt(H*H+LB*LB/4);
					AL=2*LB*apL;
					precio=Random.integer(7,18);
					costeC=AL*precio;
					costeB=4*LB*precio;
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H,0));
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.enun=this.enun.replace('AAA',JL.num2str(precio,0));
							this.lAlternativas=this.getAlternativas(costeC,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' €';
								//EA.adc(lAlts[0][na]+' €',lA[na]);
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(precio,0));
							this.lAlternativas=this.getAlternativas(costeC,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' €';
								//EA.adc(lAlts[0][na]+' €',lA[na]);
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(H,0));
							this.enun=this.enun.replace('AAA',JL.num2str(V,1));
							this.enun=this.enun.replace('AAA',JL.num2str(precio,0));
							this.lAlternativas=this.getAlternativas(costeB,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' €';
								//EA.adc(lAlts[0][na]+' €',lA[na]);
							}
						break;
					}
				break;
				case 2://PISCINA
					//decide y calcula datos:
					qB=Random.integer(3,15);
					WP=Random.integer(60,200)/10;
					LP=Random.integer(220,350)/10;
					VB=Random.integer(550,950)/10;
					H=qB*VB/WP/LP;
					
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(LP,1));
							this.enun=this.enun.replace('AAA',JL.num2str(WP,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(VB,1));
							this.lAlternativas=this.getAlternativas(H,2,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' mm';
								//EA.adc(lAlts[0][na]+' mm',lA[na]);
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(LP,1));
							this.enun=this.enun.replace('AAA',JL.num2str(WP,1));
							this.enun=this.enun.replace('AAA',JL.num2str(VB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H,2));
							this.lAlternativas=this.getAlternativas(qB,0,3,[2,19]);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' bañistas';
								//EA.adc(lAlts[0][na]+' bañistas',lA[na]);
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(LP,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qB,0));
							this.enun=this.enun.replace('AAA',JL.num2str(VB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(H,2));
							this.lAlternativas=this.getAlternativas(WP,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m';
								//EA.adc(lAlts[0][na]+' m',lA[na]);
							}
						break;
					}
				break;
				case 1://RESMA DE HOJAS DE PAPEL
					//decide y calcula datos:
					qH=Random.integer(300,500);
					WH=Random.integer(150,200)/10;
					LH=Random.integer(210,250)/10;
					eH=Random.integer(30,80)/10000;
					H=qH*eH;
					V=H*LH*WH;
					switch(enfoque){
						case 0:
							//console.log(JL.num2str(V,0));
							this.enun=this.enun.replace('AAA',JL.num2str(qH,0));
							this.enun=this.enun.replace('AAA',JL.num2str(V,0));
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));

							this.lAlternativas=this.getAlternativas(Math.round(10000*eH),0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' micras';
								//EA.adc(lAlts[0][na]+' micras',lA[na]);
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(qH,0));
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(eH,4));

							this.lAlternativas=this.getAlternativas(V,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' cm{{sup}}3{{normal}}';
								/*EA.adc(lAlts[0][na],lA[na]);
								EA.adc(EA.pot(' cm','3'),lA[na]);*/
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(V,0));
							this.enun=this.enun.replace('AAA',JL.num2str(eH,4));
							this.enun=this.enun.replace('AAA',JL.num2str(WH,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LH,1));
							this.lAlternativas=this.getAlternativas(qH,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' hojas';
								//EA.adc(lAlts[0][na]+' hojas',lA[na]);
							}
						break;
					}
				break;
				case 0://PIRÁMIDES DE EGIPTO
					//decide y calcula datos:
					H=Random.integer(400,1500)/10;
					LB=Random.integer(450,2350)/10;
					LC=Random.integer(180,240)/100;
					V=LB*LB*H/3;
					VC=LC*LC*LC;
					qC=V/VC;
					switch(enfoque){
						case 0:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(LC,2));
							this.lAlternativas=this.getAlternativas(qC,0,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' bloques';
								//EA.adc(lAlts[0][na]+' bloques',lA[na]);
							}
						break;
						case 1:
							this.enun=this.enun.replace('AAA',JL.num2str(H,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qC,0));
							this.enun=this.enun.replace('AAA',JL.num2str(LC,2));
							this.lAlternativas=this.getAlternativas(LB,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m';
								//EA.adc(lAlts[0][na]+' m',lA[na]);
							}
						break;
						case 2:
							this.enun=this.enun.replace('AAA',JL.num2str(LB,1));
							this.enun=this.enun.replace('AAA',JL.num2str(qC,0));
							this.enun=this.enun.replace('AAA',JL.num2str(LC,2));
							this.lAlternativas=this.getAlternativas(H,1,3);
							for(na=0;na<4;na++){
								lSP_alts[na] = this.lAlternativas[0][na] + ' m';
								//EA.adc(lAlts[0][na]+' m',lA[na]);
							}
						break;
					}
				break;
			}
		}
		
		//parsea los posibles exponentes del enunciado:
		for(n=0;n<5;n++){

			this.enun=this.enun.replace('ZZ2','{{sup}}2{{normal}}');
            this.enun=this.enun.replace('ZZ3','{{sup}}3{{normal}}');

			/*this.enun=this.enun.replace('ZZ2',JL.superI('2',20));
			this.enun=this.enun.replace('ZZ3',JL.superI('3',20));*/
		}
		//carga arrays para JOAN ó sitúa flechas para PATER:
		if(this.bModoPLAY){
			this.lEnunciados_STRING[this.nOp]=this.enun;
			this.lEnunciados_SPRITE[this.nOp]=co_pregunta;
			this.llRespuestas_SPRITE[this.nOp]=new Array();
			for(n=0;n<this.qAlternativas;n++){
				this.llRespuestas_SPRITE[this.nOp][n]=lSP_alts[n];
				}
			this.lIndicesOK_INT[this.nOp]=this.lAlternativas[1];
		}
	
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=r.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}