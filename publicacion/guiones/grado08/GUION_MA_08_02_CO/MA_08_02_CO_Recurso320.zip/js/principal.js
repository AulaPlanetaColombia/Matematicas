(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titol']);

        this.btn_imatge = new lib.btn_imatge();
        this.btn_imatge.setTransform(476.1, 316, 1, 1, 0, 0, 0, 145.8, 182.5);
        new cjs.ButtonHelper(this.btn_imatge, 0, 1, 2, false, new lib.btn_imatge(), 3);

        this.btn_imatge.on("click", function (evt) {
            putStage(new lib.frame2(),1);
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.btn_imatge);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame2 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['titol_01']);
        
         this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.addEventListener("click", function (evt) {
           
            putStage(new lib.frame1());
        });
        
        hideButtons("inherit")
        stagesf = new swiffy.Stage(document.getElementById('container'),
                swiffyobject, {});
                stagesf.start();
    


        var html = createDiv(txt['titol_01_2'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 70, 1);
        this.texto1.setTransform(90, -588);

        html = createDiv(txt['titol_01_3'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 100, 1);
        this.texto2.setTransform(90, -588);

        html = createDiv(txt['titol_01_4'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto3 = new lib.fadeText(html, 140, 1);
        this.texto3.setTransform(90, -588);

   html = createDiv(txt['titol_01_5'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto4 = new lib.fadeText(html, 180, 1);
        this.texto4.setTransform(90, -588);
        
         html = createDiv(txt['titol_01_6'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto5 = new lib.fadeText(html, 220, 1);
        this.texto5.setTransform(90, -588);
        
         html = createDiv(txt['titol_01_7'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto6 = new lib.fadeText(html, 260, 1);
        this.texto6.setTransform(90, -588);
       
        html = createDiv(txt['titol_01'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto6b = new lib.fadeText(html, 300, 1);
        this.texto6b.setTransform(90, -588);
        

 html = createDiv(txt['resto'], "Verdana", "25px", '350px', '100px', "20px", "185px", "left");
        this.texto7 = new lib.fadeText(html, 1389, 1);
        this.texto7.setTransform(540, -308);
       

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.texto1, this.texto2, this.texto3, this.texto4, this.texto5, this.texto6, this.texto7,this.texto6b);
       
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_02']);

 var html = document.createElement('img');
    html.src = "images/numerico.gif";
    html.id="numerico";
    document.body.appendChild(html);
    
    
        this.instance_2= new cjs.DOMElement(html);
        
           var html = createDiv(txt['resultado'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 460);
        this.texto1.setTransform(220, -188);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_2, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['txt_p3']);

 var html = createDiv(txt['titol_03'], "Verdana", "25px", '270px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 20,1);
        this.texto1.setTransform(90, -188);
        
         var flecha = new lib.Shutterstock_49857889();
    this.instance = new lib.fadeElement(flecha, 45);
    this.instance.setTransform(300.1, 193.2, 0.4, 0.4, 0, 0, 0, 5.7, 36.8);
       
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['txt_p4']);

 var html = createDiv(txt['titol_04'], "Verdana", "25px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 20,1);
        this.texto1.setTransform(90, -168);
        
         var flecha = new lib.Shutterstock_73532953();
    this.instance = new lib.fadeElement(flecha, 45);
    this.instance.setTransform(300.1, 150, 0.4, 0.4, 0, 0, 0, 5.7, 36.8);
       
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_05']);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titol_06']);

var html = createDiv(txt['txt_p6_01'], "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(90, -488);
        
this.mc_p6 = new lib.mc_p6();
	this.mc_p6.setTransform(448.8,346.4,1,1,0,0,0,366.8,194.1);

var html = createDiv(txt['txt_p6_02'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 200);
        this.texto2.setTransform(390, -388);
        
          this.practica = new lib.btn_practica(txt['txt_boto_practica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
       this.practica.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1,this.mc_p6,this.texto2,this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['titol_practica']);
 this.practica = new lib.btn_practica(txt['txt_boto_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);


        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.practica.on("click", function (evt) {
            putStage(new lib.frame9());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.practica,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    // symbols:
(lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        titulo2(this, txt['titol_solucion']);

var html = createDiv(txt['txt_solucion'], "Verdana", "20px", '770px', '10px', "20px", "185px", "center");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(90, -478);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.practica,this.texto1,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


(lib.mc_p6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

// Lineas
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAAglIAABL");
	this.shape.setTransform(68.3,68.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,2,1).p("AAAAtIAAhZ");
	this.shape_1.setTransform(68.4,69);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,2,1).p("AAAA1IAAhp");
	this.shape_2.setTransform(68.5,69.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AAAA8IAAh3");
	this.shape_3.setTransform(68.5,70.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,2,1).p("AAABDIAAiF");
	this.shape_4.setTransform(68.6,71.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,2,1).p("AAABLIAAiV");
	this.shape_5.setTransform(68.7,71.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AAABSIAAij");
	this.shape_6.setTransform(68.8,72.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,2,1).p("AAABaIAAiz");
	this.shape_7.setTransform(68.9,73.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,2,1).p("AAABhIAAjB");
	this.shape_8.setTransform(68.9,73.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,2,1).p("AAABoIAAjP");
	this.shape_9.setTransform(69,74.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,2,1).p("AAABwIAAjf");
	this.shape_10.setTransform(69.1,75.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,2,1).p("AAAB3IAAjt");
	this.shape_11.setTransform(69.2,75.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,2,1).p("AAAB+IAAj7");
	this.shape_12.setTransform(69.2,76.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,2,1).p("AAACGIAAkL");
	this.shape_13.setTransform(69.3,77.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,2,1).p("AgRCMIAAkZAgQCMIAhkL");
	this.shape_14.setTransform(71.2,78.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,2,1).p("AgjCMIAAkZAghCMIBDj9");
	this.shape_15.setTransform(73.1,78.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,2,1).p("Ag1CMIAAkZAgyCLIBlju");
	this.shape_16.setTransform(74.9,78.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,2,1).p("AhHCLIAAkZAhDCLICIjh");
	this.shape_17.setTransform(76.7,78.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,2,1).p("AhZCLIAAkZAhUCLICqjT");
	this.shape_18.setTransform(78.5,78.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,2,1).p("AhrCLIAAkZAhlCLIDNjF");
	this.shape_19.setTransform(80.3,78.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,2,1).p("Ah9CLIAAkZAh1CLIDvi2");
	this.shape_20.setTransform(82,78.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,2,1).p("AiOCMIAAkZAiGCLIESio");
	this.shape_21.setTransform(83.8,78.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,2,1).p("AigCMIAAkZAiWCLIE0ia");
	this.shape_22.setTransform(85.6,78.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,2,1).p("AiyCMIAAkZAinCLIFXiM");
	this.shape_23.setTransform(87.3,78.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,2,1).p("AjDCMIAAkZAi3CLIF5h/");
	this.shape_24.setTransform(89.1,78.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,2,1).p("AjVCNIAAkZAjICLIGchx");
	this.shape_25.setTransform(90.8,78.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(2,2,1).p("AjmCNIAAkZAjYCLIG9hj");
	this.shape_26.setTransform(92.6,78.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(2,2,1).p("Aj4CNIAAkZAjpCLIHghV");
	this.shape_27.setTransform(94.3,78.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,2,1).p("AkKCNIAAkZAj5CLIIChH");
	this.shape_28.setTransform(96.1,78.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(2,2,1).p("AkbCNIAAkZAkKCLIIlg5");
	this.shape_29.setTransform(97.9,78.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(2,2,1).p("AktCNIAAkZAkbCLIJIgr");
	this.shape_30.setTransform(99.6,78.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(2,2,1).p("Ak+CNIAAkZAkrCLIJqgd");
	this.shape_31.setTransform(101.4,78.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(2,2,1).p("AlQCNIAAkZAk8CLIKNgP");
	this.shape_32.setTransform(103.2,78.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(2,2,1).p("AhsAAIDZAA");
	this.shape_33.setTransform(106,92.6,3.14,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{scaleY:1,x:68.3,y:68.4}}]},59).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape,p:{scaleY:3.675,x:69.4,y:78}}]},1).to({state:[{t:this.shape,p:{scaleY:3.675,x:69.4,y:78}}]},10).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape,p:{scaleY:3,x:69.4,y:78.6}},{t:this.shape_33}]},1).wait(387));

	// Cx
	this.text = new cjs.Text("C(x)", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 95;
	this.text.setTransform(75.7,93.9+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},145).wait(345));

	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_27 = new cjs.Graphics().p("AgSHOIAAltIAlAAIAAFtg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AgiC2IAAlrIBFAAIAAFrg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AgxC2IAAlrIBjAAIAAFrg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AhBC2IAAlrICDAAIAAFrg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AhQC2IAAlrIChAAIAAFrg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AhgC2IAAlrIDBAAIAAFrg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AhwC2IAAlrIDgAAIAAFrg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Ah/C2IAAlrID/AAIAAFrg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AiPC2IAAlrIEfAAIAAFrg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AieC2IAAlrIE9AAIAAFrg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AiuC2IAAlrIFdAAIAAFrg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ai9C2IAAlrIF7AAIAAFrg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AjNC2IAAlrIGbAAIAAFrg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AjcC2IAAlrIG5AAIAAFrg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AjsC2IAAlrIHZAAIAAFrg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Aj7C2IAAlrIH3AAIAAFrg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkLC2IAAlrIIXAAIAAFrg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AkaC2IAAlrII1AAIAAFrg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AkqHOIAAltIJVAAIAAFtg");
	var mask_1_graphics_115 = new cjs.Graphics().p("AkqHOIAAltIJVAAIAAFtg");
	var mask_1_graphics_116 = new cjs.Graphics().p("AlLC3IAAltIKXAAIAAFtg");
	var mask_1_graphics_117 = new cjs.Graphics().p("AlsC3IAAltILZAAIAAFtg");
	var mask_1_graphics_118 = new cjs.Graphics().p("AmNC4IAAlvIMbAAIAAFvg");
	var mask_1_graphics_119 = new cjs.Graphics().p("AmuC4IAAlvINdAAIAAFvg");
	var mask_1_graphics_120 = new cjs.Graphics().p("AnPC5IAAlxIOfAAIAAFxg");
	var mask_1_graphics_121 = new cjs.Graphics().p("AnwC5IAAlxIPhAAIAAFxg");
	var mask_1_graphics_122 = new cjs.Graphics().p("AoRC6IAAlzIQjAAIAAFzg");
	var mask_1_graphics_123 = new cjs.Graphics().p("AoxC6IAAlzIRkAAIAAFzg");
	var mask_1_graphics_124 = new cjs.Graphics().p("ApSC7IAAl1ISlAAIAAF1g");
	var mask_1_graphics_125 = new cjs.Graphics().p("ApzC7IAAl1ITnAAIAAF1g");
	var mask_1_graphics_126 = new cjs.Graphics().p("AqUC8IAAl3IUpAAIAAF3g");
	var mask_1_graphics_127 = new cjs.Graphics().p("Aq1C9IAAl5IVrAAIAAF5g");
	var mask_1_graphics_128 = new cjs.Graphics().p("ArWC9IAAl5IWtAAIAAF5g");
	var mask_1_graphics_129 = new cjs.Graphics().p("Ar3C+IAAl7IXvAAIAAF7g");
	var mask_1_graphics_130 = new cjs.Graphics().p("AsYC+IAAl7IYxAAIAAF7g");
	var mask_1_graphics_131 = new cjs.Graphics().p("As5HXIAAl+IZzAAIAAF+g");
	var mask_1_graphics_159 = new cjs.Graphics().p("As5HXIAAl+IZzAAIAAF+g");
	var mask_1_graphics_160 = new cjs.Graphics().p("As5DSIAAmjIZzAAIAAGjg");
	var mask_1_graphics_161 = new cjs.Graphics().p("As5DlIAAnJIZzAAIAAHJg");
	var mask_1_graphics_162 = new cjs.Graphics().p("As5D4IAAnvIZzAAIAAHvg");
	var mask_1_graphics_163 = new cjs.Graphics().p("As5ELIAAoVIZzAAIAAIVg");
	var mask_1_graphics_164 = new cjs.Graphics().p("As5EfIAAo9IZzAAIAAI9g");
	var mask_1_graphics_165 = new cjs.Graphics().p("As5EyIAApjIZzAAIAAJjg");
	var mask_1_graphics_166 = new cjs.Graphics().p("As5FFIAAqJIZzAAIAAKJg");
	var mask_1_graphics_167 = new cjs.Graphics().p("As5FYIAAqvIZzAAIAAKvg");
	var mask_1_graphics_168 = new cjs.Graphics().p("As5FrIAArVIZzAAIAALVg");
	var mask_1_graphics_169 = new cjs.Graphics().p("As5F+IAAr7IZzAAIAAL7g");
	var mask_1_graphics_170 = new cjs.Graphics().p("As5GSIAAsjIZzAAIAAMjg");
	var mask_1_graphics_171 = new cjs.Graphics().p("As5GlIAAtJIZzAAIAANJg");
	var mask_1_graphics_172 = new cjs.Graphics().p("As5G4IAAtvIZzAAIAANvg");
	var mask_1_graphics_173 = new cjs.Graphics().p("As5HLIAAuVIZzAAIAAOVg");
	var mask_1_graphics_174 = new cjs.Graphics().p("As5HeIAAu7IZzAAIAAO7g");
	var mask_1_graphics_175 = new cjs.Graphics().p("As5HxIAAvhIZzAAIAAPhg");
	var mask_1_graphics_176 = new cjs.Graphics().p("As5IFIAAwJIZzAAIAAQJg");
	var mask_1_graphics_177 = new cjs.Graphics().p("As5IYIAAwvIZzAAIAAQvg");
	var mask_1_graphics_178 = new cjs.Graphics().p("As5IrIAAxVIZzAAIAARVg");
	var mask_1_graphics_179 = new cjs.Graphics().p("As5NXIAAx7IZzAAIAAR7g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(27).to({graphics:mask_1_graphics_27,x:-1.7,y:46.3}).wait(1).to({graphics:mask_1_graphics_28,x:-0.1,y:74.3}).wait(1).to({graphics:mask_1_graphics_29,x:1.4,y:74.3}).wait(1).to({graphics:mask_1_graphics_30,x:3,y:74.3}).wait(1).to({graphics:mask_1_graphics_31,x:4.6,y:74.3}).wait(1).to({graphics:mask_1_graphics_32,x:6.2,y:74.3}).wait(1).to({graphics:mask_1_graphics_33,x:7.8,y:74.3}).wait(1).to({graphics:mask_1_graphics_34,x:9.4,y:74.3}).wait(1).to({graphics:mask_1_graphics_35,x:11.1,y:74.3}).wait(1).to({graphics:mask_1_graphics_36,x:12.7,y:74.3}).wait(1).to({graphics:mask_1_graphics_37,x:14.3,y:74.3}).wait(1).to({graphics:mask_1_graphics_38,x:15.9,y:74.3}).wait(1).to({graphics:mask_1_graphics_39,x:17.5,y:74.3}).wait(1).to({graphics:mask_1_graphics_40,x:19.1,y:74.3}).wait(1).to({graphics:mask_1_graphics_41,x:20.7,y:74.3}).wait(1).to({graphics:mask_1_graphics_42,x:22.3,y:74.3}).wait(1).to({graphics:mask_1_graphics_43,x:23.9,y:74.3}).wait(1).to({graphics:mask_1_graphics_44,x:25.5,y:74.3}).wait(1).to({graphics:mask_1_graphics_45,x:27.1,y:46.3}).wait(70).to({graphics:mask_1_graphics_115,x:27.1,y:46.3}).wait(1).to({graphics:mask_1_graphics_116,x:30.4,y:74.4}).wait(1).to({graphics:mask_1_graphics_117,x:33.7,y:74.4}).wait(1).to({graphics:mask_1_graphics_118,x:37,y:74.5}).wait(1).to({graphics:mask_1_graphics_119,x:40.3,y:74.5}).wait(1).to({graphics:mask_1_graphics_120,x:43.6,y:74.6}).wait(1).to({graphics:mask_1_graphics_121,x:46.8,y:74.6}).wait(1).to({graphics:mask_1_graphics_122,x:50.1,y:74.7}).wait(1).to({graphics:mask_1_graphics_123,x:53.4,y:74.7}).wait(1).to({graphics:mask_1_graphics_124,x:56.7,y:74.8}).wait(1).to({graphics:mask_1_graphics_125,x:60,y:74.8}).wait(1).to({graphics:mask_1_graphics_126,x:63.2,y:74.9}).wait(1).to({graphics:mask_1_graphics_127,x:66.5,y:75}).wait(1).to({graphics:mask_1_graphics_128,x:69.8,y:75}).wait(1).to({graphics:mask_1_graphics_129,x:73.1,y:75.1}).wait(1).to({graphics:mask_1_graphics_130,x:76.4,y:75.1}).wait(1).to({graphics:mask_1_graphics_131,x:79.7,y:47.1}).wait(28).to({graphics:mask_1_graphics_159,x:79.7,y:47.1}).wait(1).to({graphics:mask_1_graphics_160,x:79.7,y:77.1}).wait(1).to({graphics:mask_1_graphics_161,x:79.7,y:79}).wait(1).to({graphics:mask_1_graphics_162,x:79.7,y:80.9}).wait(1).to({graphics:mask_1_graphics_163,x:79.7,y:82.9}).wait(1).to({graphics:mask_1_graphics_164,x:79.7,y:84.8}).wait(1).to({graphics:mask_1_graphics_165,x:79.7,y:86.7}).wait(1).to({graphics:mask_1_graphics_166,x:79.7,y:88.6}).wait(1).to({graphics:mask_1_graphics_167,x:79.7,y:90.5}).wait(1).to({graphics:mask_1_graphics_168,x:79.7,y:92.5}).wait(1).to({graphics:mask_1_graphics_169,x:79.7,y:94.4}).wait(1).to({graphics:mask_1_graphics_170,x:79.7,y:96.3}).wait(1).to({graphics:mask_1_graphics_171,x:79.7,y:98.2}).wait(1).to({graphics:mask_1_graphics_172,x:79.7,y:100.2}).wait(1).to({graphics:mask_1_graphics_173,x:79.7,y:102.1}).wait(1).to({graphics:mask_1_graphics_174,x:79.7,y:104}).wait(1).to({graphics:mask_1_graphics_175,x:79.7,y:105.9}).wait(1).to({graphics:mask_1_graphics_176,x:79.7,y:107.8}).wait(1).to({graphics:mask_1_graphics_177,x:79.7,y:109.8}).wait(1).to({graphics:mask_1_graphics_178,x:79.7,y:111.7}).wait(1).to({graphics:mask_1_graphics_179,x:79.7,y:85.5}).wait(311));
	// Formula
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(2,2,1).p("AgMhfIAMAQQALAVAGAXQAUBFg2A+");
	this.shape_34.setTransform(32.8,155.5,1,1,70.2);

	this.text_1 = new cjs.Text("R", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 16;
	this.text_1.setTransform(20.5,129.6+incremento);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(2,2,1).p("AATAUQgIAJgLAAQgJAAgIgJQgIgJAAgLQAAgKAIgKQAIgIAJAAQALAAAIAIQAHAKAAAKQAAALgHAJg");
	this.shape_35.setTransform(35.4,129.4,0.926,0.847);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgRAUQgJgJABgLQgBgLAJgIQAHgJAKAAQAKAAAJAJQAIAIAAALQAAALgIAJQgJAJgKAAQgKAAgHgJg");
	this.shape_36.setTransform(35.4,129.4,0.926,0.847);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(2,2,1).p("AATAUQgIAJgLAAQgJAAgIgJQgIgJAAgLQAAgKAIgKQAIgIAJAAQALAAAIAIQAHAKAAAKQAAALgHAJg");
	this.shape_37.setTransform(28,114.7,0.926,0.847);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgRAUQgJgJABgLQgBgLAJgIQAHgJAKAAQAKAAAJAJQAIAIAAALQAAALgIAJQgJAJgKAAQgKAAgHgJg");
	this.shape_38.setTransform(28,114.7,0.926,0.847);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(2,2,1).p("AATAUQgIAJgLAAQgJAAgIgJQgIgJAAgLQAAgKAIgKQAIgIAJAAQALAAAIAIQAHAKAAAKQAAALgHAJg");
	this.shape_39.setTransform(20.1,99.4,0.926,0.847);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgRAUQgJgJABgLQgBgLAJgIQAHgJAKAAQAKAAAJAJQAIAIAAALQAAALgIAJQgJAJgKAAQgKAAgHgJg");
	this.shape_40.setTransform(20.1,99.4,0.926,0.847);

	this.text_2 = new cjs.Text("x – a", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 95;
	this.text_2.setTransform(75.6,61.1+incremento);

	this.text_3 = new cjs.Text("P(x)", "italic 20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 47;
	this.text_3.setTransform(1.9,61.6+incremento);

	this.shape_34.mask = this.text_1.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.text_1},{t:this.shape_34}]},27).wait(463));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,768,367.6);

    (lib.Shutterstock_49857889 = function () {
        this.initialize(img.Shutterstock_49857889);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 690, 750);


    (lib.Shutterstock_73532953 = function () {
        this.initialize(img.Shutterstock_73532953);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 721, 696);


    (lib.shutterstock_84274162 = function () {
        this.initialize(img.shutterstock_84274162);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 748);

 (lib.numerico = function () {
        this.initialize(img.numerico);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1000, 748);


 
    (lib.mc_p4 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.Shutterstock_73532953();
        this.instance.setTransform(0, 0, 0.4, 0.4);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 288.4, 278.4);


    (lib.mc_p3 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.Shutterstock_49857889();
        this.instance.setTransform(0, -78.9, 0.4, 0.4);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, -78.9, 276, 300);


  

    (lib.mc_5 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text("5", "20px Verdana");
        this.text.lineHeight = 22;

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 16.9, 28.3);

    (lib.mc_p1 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});


        // Lineas
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 1, 1).p("AAAgUIAAAq");
        this.shape.setTransform(439.8, 408.9);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(2, 1, 1).p("AAAAeIAAg7");
        this.shape_1.setTransform(439.7, 409.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(2, 1, 1).p("AAAAnIAAhN");
        this.shape_2.setTransform(439.7, 410.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#000000").ss(2, 1, 1).p("AAAAwIAAhf");
        this.shape_3.setTransform(439.7, 411.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#000000").ss(2, 1, 1).p("AAAA5IAAhx");
        this.shape_4.setTransform(439.7, 412.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(2, 1, 1).p("AAABCIAAiD");
        this.shape_5.setTransform(439.7, 413.4);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(2, 1, 1).p("AAABKIAAiT");
        this.shape_6.setTransform(439.7, 414.3);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(2, 1, 1).p("AAABTIAAil");
        this.shape_7.setTransform(439.7, 415.2);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#000000").ss(2, 1, 1).p("AAABcIAAi3");
        this.shape_8.setTransform(439.7, 416.1);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#000000").ss(2, 1, 1).p("AAABlIAAjJ");
        this.shape_9.setTransform(439.7, 417);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(2, 1, 1).p("AAABuIAAjb");
        this.shape_10.setTransform(439.7, 417.9);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(2, 1, 1).p("AAAB3IAAjt");
        this.shape_11.setTransform(439.7, 418.8);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#000000").ss(2, 1, 1).p("AAAB/IAAj9");
        this.shape_12.setTransform(439.7, 419.7);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#000000").ss(2, 1, 1).p("AAACIIAAkP");
        this.shape_13.setTransform(439.7, 420.6);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#000000").ss(2, 1, 1).p("AAACRIAAkh");
        this.shape_14.setTransform(439.7, 421.5);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#000000").ss(2, 1, 1).p("AAACaIAAkz");
        this.shape_15.setTransform(439.7, 422.3);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#000000").ss(2, 1, 1).p("AAACjIAAlF");
        this.shape_16.setTransform(439.7, 423.2);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#000000").ss(2, 1, 1).p("AAACrIAAlV");
        this.shape_17.setTransform(439.7, 424.1);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#000000").ss(2, 1, 1).p("AAAC0IAAln");
        this.shape_18.setTransform(439.7, 425);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#000000").ss(2, 1, 1).p("AAAC9IAAl5");
        this.shape_19.setTransform(439.7, 425.9);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#000000").ss(2, 1, 1).p("AAADGIAAmL");
        this.shape_20.setTransform(439.7, 426.8);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(2, 1, 1).p("AAAjOIAAGd");
        this.shape_21.setTransform(439.7, 427.7);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#000000").ss(2, 1, 1).p("AgVAAIAqAA");
        this.shape_22.setTransform(441.9, 448.4);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#000000").ss(2, 1, 1).p("AgkjNIgBGbIBLAA");
        this.shape_23.setTransform(443.5, 427.7);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#000000").ss(2, 1, 1).p("Ag0jNIgBGbIBrAA");
        this.shape_24.setTransform(445.1, 427.7);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(2, 1, 1).p("AhFjNIAAGbICLAA");
        this.shape_25.setTransform(446.8, 427.7);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#000000").ss(2, 1, 1).p("AhVjNIgBGbICtAA");
        this.shape_26.setTransform(448.4, 427.7);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(2, 1, 1).p("AhljNIgBGbIDNAA");
        this.shape_27.setTransform(450, 427.7);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#000000").ss(2, 1, 1).p("Ah2jNIAAGbIDtAA");
        this.shape_28.setTransform(451.7, 427.7);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#000000").ss(2, 1, 1).p("AiGjNIAAGbIENAA");
        this.shape_29.setTransform(453.3, 427.7);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f().s("#000000").ss(2, 1, 1).p("AiWjNIgBGbIEvAA");
        this.shape_30.setTransform(454.9, 427.7);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f().s("#000000").ss(2, 1, 1).p("AinjNIAAGbIFPAA");
        this.shape_31.setTransform(456.6, 427.7);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f().s("#000000").ss(2, 1, 1).p("Ai3jNIAAGbIFvAA");
        this.shape_32.setTransform(458.2, 427.7);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f().s("#000000").ss(2, 1, 1).p("AjHjNIgBGbIGRAA");
        this.shape_33.setTransform(459.8, 427.7);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f().s("#000000").ss(2, 1, 1).p("AjYjNIAAGbIGxAA");
        this.shape_34.setTransform(461.5, 427.7);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f().s("#000000").ss(2, 1, 1).p("AjojNIAAGbIHRAA");
        this.shape_35.setTransform(463.1, 427.7);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f().s("#000000").ss(2, 1, 1).p("Aj4jNIgBGbIHzAA");
        this.shape_36.setTransform(464.7, 427.7);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f().s("#000000").ss(2, 1, 1).p("AkIjNIgBGbIITAA");
        this.shape_37.setTransform(466.3, 427.7);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f().s("#000000").ss(2, 1, 1).p("AkZjNIAAGbIIzAA");
        this.shape_38.setTransform(468, 427.7);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f().s("#000000").ss(2, 1, 1).p("AkpjNIgBGbIJVAA");
        this.shape_39.setTransform(469.6, 427.7);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f().s("#000000").ss(2, 1, 1).p("Ak5jNIgBGbIJ1AA");
        this.shape_40.setTransform(471.2, 427.7);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f().s("#000000").ss(2, 1, 1).p("AlLAAIKWAA");
        this.shape_41.setTransform(472.9, 448.3);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1300).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).to({state: [{t: this.shape_3}]}, 1).to({state: [{t: this.shape_4}]}, 1).to({state: [{t: this.shape_5}]}, 1).to({state: [{t: this.shape_6}]}, 1).to({state: [{t: this.shape_7}]}, 1).to({state: [{t: this.shape_8}]}, 1).to({state: [{t: this.shape_9}]}, 1).to({state: [{t: this.shape_10}]}, 1).to({state: [{t: this.shape_11}]}, 1).to({state: [{t: this.shape_12}]}, 1).to({state: [{t: this.shape_13}]}, 1).to({state: [{t: this.shape_14}]}, 1).to({state: [{t: this.shape_15}]}, 1).to({state: [{t: this.shape_16}]}, 1).to({state: [{t: this.shape_17}]}, 1).to({state: [{t: this.shape_18}]}, 1).to({state: [{t: this.shape_19}]}, 1).to({state: [{t: this.shape_20}]}, 1).to({state: [{t: this.shape_21}]}, 1).to({state: [{t: this.shape_21}, {t: this.shape_22}]}, 8).to({state: [{t: this.shape_23}]}, 1).to({state: [{t: this.shape_24}]}, 1).to({state: [{t: this.shape_25}]}, 1).to({state: [{t: this.shape_26}]}, 1).to({state: [{t: this.shape_27}]}, 1).to({state: [{t: this.shape_28}]}, 1).to({state: [{t: this.shape_29}]}, 1).to({state: [{t: this.shape_30}]}, 1).to({state: [{t: this.shape_31}]}, 1).to({state: [{t: this.shape_32}]}, 1).to({state: [{t: this.shape_33}]}, 1).to({state: [{t: this.shape_34}]}, 1).to({state: [{t: this.shape_35}]}, 1).to({state: [{t: this.shape_36}]}, 1).to({state: [{t: this.shape_37}]}, 1).to({state: [{t: this.shape_38}]}, 1).to({state: [{t: this.shape_39}]}, 1).to({state: [{t: this.shape_40}]}, 1).to({state: [{t: this.shape_21}, {t: this.shape_41}]}, 1).wait(41));

        // Capa 13
        this.instance = new lib.mc_5();
        this.instance.setTransform(157.2, 163.1, 1, 1, 0, 0, 0, 8.4, 14);
        this.instance._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(336).to({_off: false}, 0).wait(1).to({regY: 15.1, y: 174.8}, 0).wait(1).to({y: 185.5}, 0).wait(1).to({y: 196.2}, 0).wait(1).to({y: 206.9}, 0).wait(1).to({y: 217.5}, 0).wait(1).to({y: 228.2}, 0).wait(1).to({y: 238.9}, 0).wait(1).to({y: 249.6}, 0).wait(1).to({y: 260.3}, 0).wait(1).to({y: 270.9}, 0).wait(1).to({y: 281.6}, 0).wait(1).to({y: 292.3}, 0).wait(1).to({y: 303}, 0).wait(1).to({y: 313.6}, 0).wait(1).to({y: 324.3}, 0).wait(1).to({y: 335}, 0).wait(1).to({y: 345.7}, 0).wait(1).to({y: 356.4}, 0).wait(1).to({y: 367}, 0).wait(1).to({y: 377.7}, 0).wait(1).to({y: 388.4}, 0).wait(1).to({y: 399.1}, 0).wait(1).to({y: 409.7}, 0).wait(1).to({y: 420.4}, 0).wait(1).to({y: 431.1}, 0).to({_off: true}, 1).wait(1027));

        // Multiplicacions
        this.text = new cjs.Text("5 · 2 = 10", "20px Verdana");
        this.text.lineHeight = 22;
        this.text.setTransform(599.1, 270.2);


        this.resto = new cjs.Text("El resto de la divisón es 7", "20px Verdana");
        this.resto.lineHeight = 22;
        this.resto.lineWidth = 263;
        this.resto.setTransform(473.3, 266.1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.text, p: {text: "5 · 2 = 10", lineWidth: 103}}]}, 401).to({state: []}, 44).to({state: [{t: this.text, p: {text: "–3 + 10 = 7", lineWidth: 125}}]}, 67).to({state: []}, 48).to({state: [{t: this.text, p: {text: "7 · 2 = 14", lineWidth: 103}}]}, 69).to({state: []}, 44).to({state: [{t: this.text, p: {text: "–8 + 14 = 6", lineWidth: 125}}]}, 72).to({state: []}, 43).to({state: [{t: this.text, p: {text: "6 · 2 = 12", lineWidth: 103}}]}, 73).to({state: []}, 48).to({state: [{t: this.text, p: {text: "–1 + 12 = 11", lineWidth: 137}}]}, 75).to({state: []}, 46).to({state: [{t: this.text, p: {text: "11 · 2 = 22", lineWidth: 116}}]}, 67).to({state: []}, 43).to({state: [{t: this.text, p: {text: "–15 + 22 = 7", lineWidth: 137}}]}, 70).to({state: []}, 47).to({state: [{t: this.resto}]}, 110).wait(22));

        // 5        7         6        11         7
        this.text_1 = new cjs.Text("5        7         6        11         7", "20px Verdana", "#FFFFFF");
        this.text_1.lineHeight = 22;
        this.text_1.setTransform(148.9, 416);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_1, p: {color: "#FFFFFF", lineWidth: 315}}]}).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 361).to({state: [{t: this.text_1, p: {color: "#B30218", lineWidth: 315}}]}, 21).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 79).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 76).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 66).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 90).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 72).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 74).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 94).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 75).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 64).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 87).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 315}}]}, 74).to({state: [{t: this.text_1, p: {color: "#000000", lineWidth: 316}}]}, 115).wait(41));

        // 2
        this.text_2 = new cjs.Text("2", "20px Verdana", "#FFFFFF");
        this.text_2.lineHeight = 22;
        this.text_2.setTransform(92.9, 362);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_2, p: {color: "#FFFFFF"}}]}).to({state: [{t: this.text_2, p: {color: "#000000"}}]}, 290).to({state: [{t: this.text_2, p: {color: "#B30218"}}]}, 92).to({state: [{t: this.text_2, p: {color: "#000000"}}]}, 79).to({state: [{t: this.text_2, p: {color: "#B30218"}}]}, 142).to({state: [{t: this.text_2, p: {color: "#000000"}}]}, 90).to({state: [{t: this.text_2, p: {color: "#B30218"}}]}, 146).to({state: [{t: this.text_2, p: {color: "#000000"}}]}, 94).to({state: [{t: this.text_2, p: {color: "#B30218"}}]}, 139).to({state: [{t: this.text_2, p: {color: "#000000"}}]}, 87).wait(230));

        //          10       14       12        22
        this.text_3 = new cjs.Text("         10       14       12        22", "20px Verdana", "#FFFFFF");
        this.text_3.lineHeight = 22;
        this.text_3.setTransform(148.9, 362);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_3}]}).to({state: [{t: this.text_3}]}, 425).to({state: [{t: this.text_3}]}, 62).to({state: [{t: this.text_3}]}, 91).to({state: [{t: this.text_3}]}, 75).to({state: [{t: this.text_3}]}, 72).to({state: [{t: this.text_3}]}, 81).to({state: [{t: this.text_3}]}, 78).to({state: [{t: this.text_3}]}, 79).to({state: [{t: this.text_3}]}, 87).to({state: [{t: this.text_3}]}, 68).to({state: [{t: this.text_3}]}, 68).to({state: [{t: this.text_3}]}, 92).wait(111));

        // 5       –3       –8       –1       –15
        this.text_4 = new cjs.Text("5       –3       –8       –1       –15", "20px Verdana", "#FFFFFF");
        this.text_4.lineHeight = 22;
        this.text_4.setTransform(148.9, 149);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_4, p: {color: "#FFFFFF"}}]}).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 85).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 40).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 38).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 42).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 38).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 244).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 91).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 147).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 81).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 157).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 87).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 136).to({state: [{t: this.text_4, p: {color: "#000000"}}]}, 92).wait(111));

        // Capa 12 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_0 = new cjs.Graphics().p("AjGCgIAAk/IGNAAIAAE/g");
        var mask_graphics_25 = new cjs.Graphics().p("AjGCgIAAk/IGNAAIAAE/g");
        var mask_graphics_26 = new cjs.Graphics().p("AkWDYIAAmvIItAAIAAGvg");
        var mask_graphics_27 = new cjs.Graphics().p("AlmERIAAohILOAAIAAIhg");
        var mask_graphics_28 = new cjs.Graphics().p("Am2FKIAAqTINuAAIAAKTg");
        var mask_graphics_29 = new cjs.Graphics().p("AoGGDIAAsFIQNAAIAAMFg");
        var mask_graphics_30 = new cjs.Graphics().p("ApWG8IAAt3IStAAIAAN3g");
        var mask_graphics_31 = new cjs.Graphics().p("AqmH1IAAvpIVOAAIAAPpg");
        var mask_graphics_32 = new cjs.Graphics().p("Ar2ItIAAxZIXuAAIAARZg");
        var mask_graphics_33 = new cjs.Graphics().p("AtGJmIAAzLIaNAAIAATLg");
        var mask_graphics_34 = new cjs.Graphics().p("AuWKfIAA09IctAAIAAU9g");
        var mask_graphics_35 = new cjs.Graphics().p("AvmLYIAA2vIfNAAIAAWvg");
        var mask_graphics_36 = new cjs.Graphics().p("Aw2MRIAA4hMAhuAAAIAAYhg");
        var mask_graphics_37 = new cjs.Graphics().p("AyGNKIAA6TMAkOAAAIAAaTg");
        var mask_graphics_38 = new cjs.Graphics().p("AzWOCIAA8DMAmtAAAIAAcDg");
        var mask_graphics_39 = new cjs.Graphics().p("A0mO7IAA91MApNAAAIAAd1g");
        var mask_graphics_40 = new cjs.Graphics().p("A12P0IAA/nMAruAAAIAAfng");
        var mask_graphics_41 = new cjs.Graphics().p("A3GQtMAAAghZMAuOAAAMAAAAhZg");
        var mask_graphics_42 = new cjs.Graphics().p("A4WRmMAAAgjLMAwtAAAMAAAAjLg");
        var mask_graphics_43 = new cjs.Graphics().p("A5mSfMAAAgk9MAzNAAAMAAAAk9g");
        var mask_graphics_44 = new cjs.Graphics().p("A62TYMAAAgmvMA1tAAAMAAAAmvg");
        var mask_graphics_45 = new cjs.Graphics().p("A8GUQMAAAgofMA4OAAAMAAAAofg");
        var mask_graphics_46 = new cjs.Graphics().p("A9WVJMAAAgqRMA6uAAAMAAAAqRg");
        var mask_graphics_47 = new cjs.Graphics().p("A+mWCMAAAgsDMA9NAAAMAAAAsDg");
        var mask_graphics_48 = new cjs.Graphics().p("A/2W7MAAAgt1MA/tAAAMAAAAt1g");
        var mask_graphics_49 = new cjs.Graphics().p("EghGAX0MAAAgvnMBCOAAAMAAAAvng");
        var mask_graphics_50 = new cjs.Graphics().p("EgiWAYtMAAAgxZMBEuAAAMAAAAxZg");
        var mask_graphics_51 = new cjs.Graphics().p("EgjmAZlMAAAgzJMBHNAAAMAAAAzJg");
        var mask_graphics_52 = new cjs.Graphics().p("EgfWAjYMAAAg07MBJuAAAMAAAA07g");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: mask_graphics_0, x: 90.5, y: 437}).wait(25).to({graphics: mask_graphics_25, x: 90.5, y: 437}).wait(1).to({graphics: mask_graphics_26, x: 98.5, y: 431.3}).wait(1).to({graphics: mask_graphics_27, x: 106.5, y: 425.6}).wait(1).to({graphics: mask_graphics_28, x: 114.5, y: 419.9}).wait(1).to({graphics: mask_graphics_29, x: 122.5, y: 414.2}).wait(1).to({graphics: mask_graphics_30, x: 130.5, y: 408.5}).wait(1).to({graphics: mask_graphics_31, x: 138.5, y: 402.8}).wait(1).to({graphics: mask_graphics_32, x: 146.5, y: 397.2}).wait(1).to({graphics: mask_graphics_33, x: 154.5, y: 391.5}).wait(1).to({graphics: mask_graphics_34, x: 162.5, y: 385.8}).wait(1).to({graphics: mask_graphics_35, x: 170.5, y: 380.1}).wait(1).to({graphics: mask_graphics_36, x: 178.5, y: 374.4}).wait(1).to({graphics: mask_graphics_37, x: 186.5, y: 368.7}).wait(1).to({graphics: mask_graphics_38, x: 194.5, y: 363.1}).wait(1).to({graphics: mask_graphics_39, x: 202.5, y: 357.4}).wait(1).to({graphics: mask_graphics_40, x: 210.5, y: 351.7}).wait(1).to({graphics: mask_graphics_41, x: 218.5, y: 346}).wait(1).to({graphics: mask_graphics_42, x: 226.5, y: 340.3}).wait(1).to({graphics: mask_graphics_43, x: 234.5, y: 334.6}).wait(1).to({graphics: mask_graphics_44, x: 242.5, y: 328.9}).wait(1).to({graphics: mask_graphics_45, x: 250.5, y: 323.3}).wait(1).to({graphics: mask_graphics_46, x: 258.5, y: 317.6}).wait(1).to({graphics: mask_graphics_47, x: 266.5, y: 311.9}).wait(1).to({graphics: mask_graphics_48, x: 274.5, y: 306.2}).wait(1).to({graphics: mask_graphics_49, x: 282.5, y: 300.5}).wait(1).to({graphics: mask_graphics_50, x: 290.5, y: 294.8}).wait(1).to({graphics: mask_graphics_51, x: 298.5, y: 289.2}).wait(1).to({graphics: mask_graphics_52, x: 271.2, y: 226.5}).wait(1337));

        // Capa 9
        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f().s("#000000").ss(2, 1, 1).p("Egi/AAAMBF/AAA");
        this.shape_42.setTransform(306.5, 407);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f().s("#000000").ss(2, 1, 1).p("AAA4vMAAAAxf");
        this.shape_43.setTransform(122.5, 285.5);

        this.shape_42.mask = this.shape_43.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_43}, {t: this.shape_42}]}).wait(1389));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 785, 444.3);


    (lib.btn_imatge = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.shutterstock_84274162();
        this.instance.setTransform(-104.9, 18.6, 0.499, 0.499);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("Egn/Ad6MAAAg7zMBP+AAAMAAAA7zg");
        this.shape.setTransform(145.7, 205);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).to({state: [{t: this.instance}, {t: this.shape}]}, 1).to({state: [{t: this.instance}]}, 1).to({state: [{t: this.instance}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-104.9, 18.6, 499.2, 373.4);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV' && childNodes[i].id != 'container' || childNodes[i].id == 'numerico') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "#FFFFFF";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}