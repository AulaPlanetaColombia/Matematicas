Scorm = new function()
{

	this.modo = "";
	this.initialMode = "";
	this.suspend_data = "";
	this.completed = "";
	this.connected = false;
	
	this.MODO_EXPONER = "browse";
	this.MODO_REVISAR = "review";
	this.MODO_REVISARALUMNO = "areview";
	this.MODO_EXAMEN = "exam";
	
	this.init = function( data )
	{
		this.modo = data.mode;
		this.suspend_data = data.suspend_data;
		this.completed = data.completed;
		this.connected = data.connected;
		
		/****  HARDCODED DATA  ****
		this.modo = this.MODO_REVISARALUMNO;
		this.suspend_data = "AAA-AAA11AAA4AAA+AAA71AAA9AAA+AAA16AAA5AAA+AAA32AAA5AAA-AAA36AAA8AAA-AAA16AAA5AAA-AAA16AAA7AAA+AAA12AAA7AAA+AAA13AAA3AAA+AAA4AAA8";
		this.completed = "completed";
		this.connected = true;
		**/
		
		this.initialMode = this.modo;
	}
	
}