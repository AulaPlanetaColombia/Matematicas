Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
		
	this.lVariaciones=new Array();
	
	/*this.lEnunciados_STRING=new Array();
	this.lEnunciados_SPRITE=new Array();
	this.llRespuestas_SPRITE=new Array();
	this.lIndicesOK_INT=new Array();*/
	
	/*this.lPregsSPRITE=new Array();
	this.lPregSTRING=new Array();
	this.lRespNUM=new Array();
	this.lRespSTRING=new Array();
	this.lRespsSPRITE=new Array();*/
	
	this.lPregSPR = new Array();
	this.lRespNUM = new Array();
	this.lRespSTR = new Array();
	
	this.ea ="";
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=[1];
	
	this.bModoPLAY=true;
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",26,"#000000",false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			//console.log(this.lTiposVariaciones);
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
		//console.log(this.lVariaciones);
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {

			this.enunciar();			
			
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].pregSPR=this.lPregSPR[this.nOp]
			Motor.lOperaciones[this.nOp].respNum=this.lRespNUM[this.nOp];
			Motor.lOperaciones[this.nOp].respuestaString=this.lRespSTR[this.nOp]
			Motor.lOperaciones[this.nOp].entrada="";
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			Motor.lOperaciones[this.nOp].formula=this.ea;
			
			//console.log( Motor.lOperaciones[this.nOp].respuestaString );
		}

	}
	this.signo = function (vv){
        var valor = Number(vv);
        if(valor>0){
            return '+';
        }else if(valor<0){
            return String.fromCharCode(8722);
        }else{
            return '';
        }
    };
    
	this.enunciar = function()
	{
			
		while(true){
            var xA = Random.integer(-7,7);
            var yA = Random.integer(-7,7);
            var xB = Random.integer(-7,7);
            var yB = Random.integer(-7,7);
            if((xA!=xB)&&(yA!=yB)&&(Math.abs(xA-xB)<10)&&(Math.abs(yA-yB)<10)){
                break;
            }
        }
			
		var m = (yB-yA)/(xB-xA);
        var n = (yA*xB-xA*yB)/(xB-xA);
        var mFraccion = JL.simplificar([yB-yA,xB-xA]);
        
        var nFraccion = JL.simplificar([yA*xB-xA*yB,xB-xA]);
        
        var lCoefs = JL.getEqG_2P([xA,yA],[xB,yB]);
        
        var A = lCoefs[0];
        var B = lCoefs[1];
        var C = lCoefs[2];
        var vx = xB-xA;
        var vy = yB-yA;
        //monta el plano y la recta:
        PlanoXY.PlanoXY([400,400],30,[200,200]);
		PlanoXY.plot('pol',[n,m],"#0000ff");	
		var variacion = 4;
		
		switch(variacion){
		   case 4://punto-pendiente:
		      this.ea=EA.ini(JL.cursiva('y')+' = ');
		      var azar = Random.integer(0,1);
		      switch(azar){
		          case 0://k es yA
		              //k es la m (entera ó fracción)
                        if(m==Math.floor(m)){
                            EA.adcStatic(JL.cursiva('k')+JL.cursiva('x')+' ',this.ea);
                            this.lRespNUM[this.nOp]=m;
                        }else{
                            if(Random.integer(0,1)==0){
                                //k es el numerador de m:
                                EA.adfStatic(EA.fra(JL.cursiva('k'),JL.num2str(mFraccion[1])),this.ea);
                                EA.adcStatic(' ',this.ea, null, 10);
                                EA.adcStatic(JL.cursiva('x')+' ',this.ea);
                                this.lRespNUM[this.nOp]=mFraccion[0];
                            }else{
                                //k es el denominador:
                                EA.adfStatic(EA.fra(JL.num2str(mFraccion[0]),JL.cursiva('k')),this.ea);
                                EA.adcStatic(' ',this.ea, null, 10);
                                EA.adcStatic(JL.cursiva('x')+' ',this.ea);
                                this.lRespNUM[this.nOp]=mFraccion[1];
                            }
                        }
                        if(n==Math.floor(n)){
                            if(n>0){
                                EA.adcStatic('+ '+JL.num2str(Math.abs(n)),this.ea);
                            }else if(n<0){
                                EA.adcStatic(String.fromCharCode(8722)+' '+JL.num2str(Math.abs(n)),this.ea);
                            }
                        }else{
                            EA.adcStatic(this.signo(n)+' ',this.ea);
                            EA.adfStatic(EA.fra(JL.num2str(Math.abs(nFraccion[0])),JL.num2str(Math.abs(nFraccion[1]))),this.ea);
                            EA.adcStatic(' ',this.ea, null, 10);
//                          EA.adc(')',ea);
                        }
		          break;
		          case 1://k es n (entero o fracción)
                        if(m==Math.floor(m)){
                            if(m==1){
                                EA.adcStatic(JL.cursiva('x')+' ',this.ea);
                            }else if(m==-1){
                                EA.adcStatic(String.fromCharCode(8722)+JL.cursiva('x')+' ',this.ea);
                            }else{
                                EA.adcStatic(JL.num2str(m)+JL.cursiva('x')+' ',this.ea);
                            }
                        }else{
                            EA.adfStatic(EA.fra(JL.num2str(mFraccion[0]),JL.num2str(mFraccion[1])),this.ea);
                            EA.adcStatic(' ',this.ea, null, 10);
                            EA.adcStatic(JL.cursiva('x')+' ',this.ea);
                        }
                        if(n==0){
                            EA.adcStatic('+ '+JL.cursiva('k'),this.ea);
                            this.lRespNUM[this.nOp]=0;
                        }else{
                            EA.adcStatic(this.signo(n)+' ',this.ea);
                            if(n==Math.floor(n)){
                                EA.adcStatic(JL.cursiva('k'),this.ea);
                                this.lRespNUM[this.nOp]=Math.abs(n);
                            }else{
                                if(Random.integer(0,1)==0){
                                    //la k es el numerador:
                                    EA.adfStatic(EA.fra(JL.cursiva('k'),String(Math.abs(nFraccion[1]))),this.ea);
                                    EA.adcStatic(' ',this.ea, null, 10);
                                    this.lRespNUM[this.nOp]=Math.abs(nFraccion[0]);
                                }else{
                                    //la k es el denominador:
                                    EA.adfStatic(EA.fra(JL.num2str(Math.abs(nFraccion[0])),JL.cursiva('k')),this.ea);
                                    EA.adcStatic(' ',this.ea, null, 10);
                                    this.lRespNUM[this.nOp]=Math.abs(nFraccion[1]);
                                }
                            }
                        }
                        break;   
		      }
		   break;
		}	
		//this.ea.x=500;this.ea.y=170;
		this.ea.x=500;this.ea.y=60;
        //co_formules.addChild(ea);
        //monta los arrays:
        this.lPregSPR[this.nOp]=PlanoXY.contenedor;
        this.lRespSTR[this.nOp]=this.lRespNUM[this.nOp].toString();
			
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}