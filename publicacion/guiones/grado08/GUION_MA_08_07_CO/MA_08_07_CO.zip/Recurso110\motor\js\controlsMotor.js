function Pagina( pregunta, _numpagina, operacio) {


    //console.log(operacio);
    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;

    this.contenedor = new createjs.Container();

	var co_pregunta=new createjs.Container();
	co_pregunta.x=20;
	co_pregunta.y = 20;
	co_pregunta.addChild(operacio.pregSPR);
	
    this.contenedor.addChild(co_pregunta);
    
    this.contenedor.addChild(operacio.formula);
	 
	this.K = "";
	 
	this.cajaK = new CajaTexto();
	//this.cajaK.contenedor.x = 598;
	this.cajaK.contenedor.x = 550;
	this.cajaK.contenedor.y = 298-118;

	this.contenedor.addChild( this.cajaK.contenedor  );
	
	this.textK = new createjs.RichText();
    this.textK.text = "{{cur}}k{{normal}} =";
    this.textK.font =  "22px Arial" ;
	this.textK.fontSize =  22;
	this.textK.color = "#0D3158";
	//this.textK.x = 555;
	this.textK.x = 507;
	this.textK.y = 298-110;
	this.textK.mouseEnabled = false;
	
	this.contenedor.addChild( this.textK  );
	
	this.solucio = new createjs.RichText();
    this.solucio.text = operacio.respuestaString;
    this.solucio.font =  "22px Arial" ;
	this.solucio.fontSize =  22;
	this.solucio.color = "#E1001A";
	this.solucio.x = 645;
	this.solucio.y = 250;
	this.solucio.alpha =0;
	
	this.contenedor.addChild( this.solucio  );
	
	this.validacio = false;
}

function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 204, 40, 5);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 204, 40, 5);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 204, 40, 5);
	
}
CajaTexto.prototype.error = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 204, 40, 5);
}

CajaTexto.prototype.correct = function(){

	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 204, 40, 5);
}
