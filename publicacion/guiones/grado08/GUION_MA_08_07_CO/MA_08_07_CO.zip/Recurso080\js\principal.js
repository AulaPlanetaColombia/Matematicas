(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

        this.entrar = new lib.BtnFalse();
        this.entrar.setTransform(475.4, 340.1, 0.929, 1.217, 0, 0, 0, 309.9, 163.5);
        new cjs.ButtonHelper(this.entrar, 0, 1, 2, false, new lib.BtnFalse(), 3);

        this.instance_1 = new lib.Symbol_intro();
        this.instance_1.setTransform(509.5, 340.9, 0.462, 0.462, 0, 0, 0, 491.6, 401.3);




        this.entrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.instance_1, this.entrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);


        texto(this, txt['pantalla1'], 0, 300);

        this.text = new cjs.Text("o", "16px Verdana");
        this.text.lineHeight = 16;
        this.text.setTransform(709.8, 322.2);

        this.text_1 = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(668, 198.9);

        this.text_2 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
        this.text_2.lineHeight = 16;
        this.text_2.setTransform(861.7, 330.9);

        this.text_3 = new cjs.Text("y = mx", "italic 16px Verdana", "#350088");
        this.text_3.lineHeight = 16;
        this.text_3.setTransform(792.1, 239.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#350088").ss(2, 0, 0, 4).p("A0uGeMApdgM7");
        this.shape.setTransform(702.4, 324.3);

        this.instance = new lib.ClipGroup0();
        this.instance.setTransform(706, 336.2, 0.45, 0.45, 0, 0, 0, 499.9, 500.1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAxZMAAAAiz");
        this.shape_1.setTransform(704.7, 321.8);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.addChild(this.logo, this.home, this.texto, this.siguiente, this.shape_1, this.instance, this.shape, this.text_3, this.text_2, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);


        texto(this, txt['pantalla2'], 0, 300);


        this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
        this.text.lineHeight = 16;
        this.text.setTransform(672.1, 177.9);

        this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(820.6, 381.7);

        this.text_2 = new cjs.Text(" ", "12px Arial");
        this.text_2.lineHeight = 14;
        this.text_2.setTransform(533.5, 285.9, 0.366, 0.366);

        this.instance_1 = new lib.ClipGroup0b();
        this.instance_1.setTransform(743.1, 378.3, 0.366, 0.366, 0, 0, 0, 500.1, 500.1);

        this.instance_2 = new lib.ClipGroup0_1();
        this.instance_2.setTransform(713.4, 347.9, 0.366, 0.366, 0, 0, 0, 500.1, 500.1);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#350088").ss(4, 0, 0, 4).p("EAAAhJfMAAACS/");
        this.shape.setTransform(702, 349.9, 0.366, 0.366);

        this.instance_3 = new lib.ClipGroup0_2();
        this.instance_3.setTransform(702, 348.2, 0.366, 0.366, 0, 0, 0, 411.9, 499.1);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.addChild(this.logo, this.home, this.texto, this.siguiente, this.anterior, this.shape_1, this.instance_3, this.shape, this.instance_2, this.instance_1, this.text_2, this.text_1, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);

        texto(this, txt['pantalla3'], 0, 350);

        this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
        this.text.lineHeight = 16;
        this.text.setTransform(545, 152.1);

        this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(863.3, 394.7);

        this.instance_1 = new lib.Symbol6();
        this.instance_1.setTransform(650.5, 340.9, 0.462, 0.462, 0, 0, 0, 491.6, 401.3);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.addChild(this.logo, this.home, this.siguiente, this.anterior, this.instance_1, this.text_1, this.text, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);

        texto(this, txt['pantalla4'], 0, 400);

        this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
        this.text.lineHeight = 16;
        this.text.setTransform(545, 152.1);

        this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(863.3, 394.7);

        this.instance_1 = new lib.Symbol3();
        this.instance_1.setTransform(650.5, 340.9, 0.462, 0.462, 0, 0, 0, 491.6, 401.3);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.addChild(this.logo, this.home, this.siguiente, this.anterior, this.instance_1, this.text_1, this.text, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);

        texto(this, txt['pantalla5'], 0, 400);

        this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
        this.text.lineHeight = 16;
        this.text.setTransform(545, 152.1);

        this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(863.3, 394.7);

        this.instance_1 = new lib.Symbol4();
        this.instance_1.setTransform(650.5, 340.9, 0.462, 0.462, 0, 0, 0, 491.6, 401.3);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.home, this.siguiente, this.anterior, this.instance_1, this.text_1, this.text, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);

        texto(this, txt['pantalla6'], 0, 400);

     	this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
	this.text.lineHeight = 16;
	this.text.setTransform(628.4,152.1);

	this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(861.3,394.7);

        this.instance_1 = new lib.Symbol5();
        this.instance_1.setTransform(650.5, 340.9, 0.462, 0.462, 0, 0, 0, 491.6, 401.3);

  this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
       
        this.addChild(this.logo, this.home, this.practica, this.anterior, this.instance_1, this.text_1, this.text, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
  titulo2(this, txt['pantalla_practica']);
       

     	this.instance_1 = new lib.Bitmap42();
	this.instance_1.setTransform(183.4,153.6,0.622,0.621);

  this.practica = new lib.btn_practica(txt['textbtnsolucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
       
        this.addChild(this.logo, this.practica, this.anterior, this.instance_1,  this.titulo,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);

      texto(this, txt['pantalla_solucion'], 0, 400);
this.text = new cjs.Text("Y", "16px Verdana", "#BB2DE2");
	this.text.lineHeight = 16;
	this.text.setTransform(610,183.6);

	this.text_1 = new cjs.Text("X", "16px Verdana", "#BB2DE2");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(857.1,394.7);

	this.text_2 = new cjs.Text("1 ", "40px Verdana");
	this.text_2.lineHeight = 48;
	this.text_2.setTransform(669.7,394.6,0.369,0.369);

	this.text_3 = new cjs.Text("(1, m)", "40px Verdana");
	this.text_3.lineHeight = 45;
	this.text_3.lineWidth = 157;
	this.text_3.setTransform(687.2,272.1,0.369,0.369);

	this.text_4 = new cjs.Text("m", "italic 40px Verdana");
	this.text_4.lineHeight = 45;
	this.text_4.lineWidth = 39;
	this.text_4.setTransform(612.5,271.9,0.369,0.369);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("Ag8g7QAagZAiAAQAjAAAaAZQAZAZAAAiQAAAjgZAZQgaAZgjAAQgiAAgagZQgZgZAAgjQAAgiAZgZg");
	this.shape.setTransform(668.6,284.3,0.369,0.369);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3900AC").s().p("Ag8A8QgZgZAAgjQAAgiAZgZQAagZAiAAQAjAAAaAZQAZAZgBAiQABAjgZAZQgaAZgjAAQgiAAgagZg");
	this.shape_1.setTransform(668.6,284.3,0.369,0.369);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3900AC").ss(2,0,0,4).p("AneWbMAO9gs0");
	this.shape_2.setTransform(652.4,332.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AgdAAIA7AA");
	this.shape_3.setTransform(667.8,284,0.369,0.369);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AgdAAIA7AA");
	this.shape_4.setTransform(634.6,284,0.369,0.369);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AAA2cMAAAAs5");
	this.shape_5.setTransform(633.5,332.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("A8zAAMA5nAAA");
	this.shape_6.setTransform(686.6,389);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        
       this.instance_1 = new lib.Mapadebits2();
	this.instance_1.setTransform(639.8,283.2);

	this.instance_2 = new lib.Mapadebits1();
	this.instance_2.setTransform(667.7,284.4);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
       
        this.addChild(this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_4,this.text_3,this.text_2,this.text_1,this.instance_2,this.instance_1,this.text,this.logo, this.anterior, this.anterior, this.instance_1,  this.texto,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,105);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,24,1);
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   /* function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

 (lib.Bitmap42 = function () {
        this.initialize(img.Bitmap42);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 500, 332);

 (lib.btn_practica = function (texto,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape.setTransform(333.5,488.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
	this.shape_1.setTransform(333.5,488.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(113));

	// Layer 11
	this.instance = new lib.Tween39("synched",0);
	this.instance.setTransform(-622.8,719.4,1.274,1.274);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(26));

	// Layer 8
	this.instance_1 = new lib.Tween40("synched",0);
	this.instance_1.setTransform(-622.8,776.6,1.274,1.274);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(87).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(8));

	// Layer 4
	this.instance_2 = new lib.Tween41("synched",0);
	this.instance_2.setTransform(492.5,406);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(87).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(8));

	// Layer 10
	this.instance_3 = new lib.Tween42("synched",0);
	this.instance_3.setTransform(-622.8,559.7,1.274,1.274);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(66));

	// Layer 7
	this.instance_4 = new lib.Tween43("synched",0);
	this.instance_4.setTransform(-622.8,616.7,1.274,1.274);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(47).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(48));

	// Layer 3
	this.instance_5 = new lib.Tween44("synched",0);
	this.instance_5.setTransform(363.5,358.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(47).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(48));

	// Layer 9
	this.instance_6 = new lib.Tween45("synched",0);
	this.instance_6.setTransform(-622.8,398.4,1.274,1.274);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(104));

	// Layer 6
	this.instance_7 = new lib.Tween46("synched",0);
	this.instance_7.setTransform(-622.8,455.5,1.274,1.274);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(9).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(86));

	// Layer 2
	this.instance_8 = new lib.Tween47("synched",0);
	this.instance_8.setTransform(456,362.9);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(9).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(86));

	// Layer 1
	this.text = new cjs.Text("-4", "14px Verdana");
	this.text.lineHeight = 17;
	this.text.setTransform(308.5,791.1);

	this.text_1 = new cjs.Text("-3", "14px Verdana");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(308.5,715);

	this.text_2 = new cjs.Text("-2", "14px Verdana");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(308.5,637.4);

	this.text_3 = new cjs.Text("-1", "14px Verdana");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(308.5,560.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape_2.setTransform(333.5,488.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
	this.shape_3.setTransform(333.5,488.2);

	this.text_4 = new cjs.Text("6", "14px Verdana");
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(313.7,18.4);

	this.text_5 = new cjs.Text("5", "14px Verdana");
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(313.7,96);

	this.text_6 = new cjs.Text("4", "14px Verdana");
	this.text_6.lineHeight = 17;
	this.text_6.setTransform(312.7,174.7);

	this.text_7 = new cjs.Text("3", "14px Verdana");
	this.text_7.lineHeight = 17;
	this.text_7.setTransform(313.7,249.8);

	this.text_8 = new cjs.Text("2", "14px Verdana");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(314.7,326.7);

	this.text_9 = new cjs.Text("1", "14px Verdana");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(313.7,406.1);

	this.text_10 = new cjs.Text("0", "14px Verdana");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(313.7,472.9);

	this.text_11 = new cjs.Text("8", "14px Verdana");
	this.text_11.lineHeight = 17;
	this.text_11.setTransform(949.6,498.3);

	this.text_12 = new cjs.Text("7", "14px Verdana");
	this.text_12.lineHeight = 17;
	this.text_12.setTransform(871.2,498.3);

	this.text_13 = new cjs.Text("6", "14px Verdana");
	this.text_13.lineHeight = 17;
	this.text_13.setTransform(794.2,498.3);

	this.text_14 = new cjs.Text("5", "14px Verdana");
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(717.4,498.3);

	this.text_15 = new cjs.Text("4", "14px Verdana");
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(639.6,498.3);

	this.text_16 = new cjs.Text("3", "14px Verdana");
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(561.7,498.3);

	this.text_17 = new cjs.Text("1", "14px Verdana");
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(406.8,498.3);

	this.text_18 = new cjs.Text("2", "14px Verdana");
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(483.9,498.3);

	this.text_19 = new cjs.Text("-4", "14px Verdana");
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(17.1,498.3);

	this.text_20 = new cjs.Text("-3", "14px Verdana");
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(93.9,498.3);

	this.text_21 = new cjs.Text("-1", "14px Verdana");
	this.text_21.lineHeight = 17;
	this.text_21.setTransform(248.4,498.3);

	this.text_22 = new cjs.Text("-2", "14px Verdana");
	this.text_22.lineHeight = 17;
	this.text_22.setTransform(170.8,498.3);

	this.text_23 = new cjs.Text("0", "14px Verdana");
	this.text_23.lineHeight = 17;
	this.text_23.setTransform(342.3,498.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_4.setTransform(330.6,797.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_5.setTransform(330.6,720);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_6.setTransform(330.6,642.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_7.setTransform(330.6,566);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_8.setTransform(330.6,23.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_9.setTransform(330.6,100.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_10.setTransform(330.6,178.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_11.setTransform(330.6,255.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_12.setTransform(330.6,333.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_13.setTransform(330.6,410.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_14.setTransform(23.8,491.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_15.setTransform(101.5,491.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_16.setTransform(179,491.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_17.setTransform(255.6,491.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_18.setTransform(410.8,491.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_19.setTransform(488.3,490.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_20.setTransform(565.9,490.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_21.setTransform(643.5,491.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_22.setTransform(721.1,491);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_23.setTransform(797.7,490.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_24.setTransform(953.1,490.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_25.setTransform(875.3,490.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAAgPIg1A3IgLgLIBAhEIBBBEIgMALg");
	this.shape_26.setTransform(333,4.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA+RMAAAh8h");
	this.shape_27.setTransform(333,400.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgnA1IA4g1Ig4g0IALgMIBEBAIhEBBg");
	this.shape_28.setTransform(981,488.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(4,0,0,4).p("EhMzAAAMCZnAAA");
	this.shape_29.setTransform(491.7,488.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.shape_2},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1130000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(17.1,0,968,804.7);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape.setTransform(333.5,488.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
	this.shape_1.setTransform(333.5,488.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(121));

	// Layer 10
	this.instance = new lib.Tween31("synched",0);
	this.instance.setTransform(-620.5,776.8,1.305,1.305);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(14));

	// Layer 4
	this.instance_1 = new lib.Tween32("synched",0);
	this.instance_1.setTransform(492.5,406);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(14));

	// Layer 9
	this.instance_2 = new lib.Tween33("synched",0);
	this.instance_2.setTransform(-620.5,663.9,1.305,1.305);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(44));

	// Layer 2
	this.instance_3 = new lib.Tween34("synched",0);
	this.instance_3.setTransform(456,362.9);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(59).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(44));

	// Layer 8
	this.instance_4 = new lib.Tween35("synched",0);
	this.instance_4.setTransform(-620.5,545.4,1.305,1.305);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(74));

	// Layer 3
	this.instance_5 = new lib.Tween36("synched",0);
	this.instance_5.setTransform(396.3,363.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(29).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(74));

	// Layer 7
	this.instance_6 = new lib.Tween37("synched",0);
	this.instance_6.setTransform(-620.5,426.7,1.305,1.305);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(102));

	// Layer 6
	this.instance_7 = new lib.Tween38("synched",0);
	this.instance_7.setTransform(363.5,358.8);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(102));

	// Layer 1
	this.text = new cjs.Text("-4", "14px Verdana");
	this.text.lineHeight = 17;
	this.text.setTransform(308.5,791.1);

	this.text_1 = new cjs.Text("-3", "14px Verdana");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(308.5,715);

	this.text_2 = new cjs.Text("-2", "14px Verdana");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(308.5,637.4);

	this.text_3 = new cjs.Text("-1", "14px Verdana");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(308.5,560.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape_2.setTransform(333.5,488.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
	this.shape_3.setTransform(333.5,488.2);

	this.text_4 = new cjs.Text("6", "14px Verdana");
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(313.7,18.4);

	this.text_5 = new cjs.Text("5", "14px Verdana");
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(313.7,96);

	this.text_6 = new cjs.Text("4", "14px Verdana");
	this.text_6.lineHeight = 17;
	this.text_6.setTransform(312.7,174.7);

	this.text_7 = new cjs.Text("3", "14px Verdana");
	this.text_7.lineHeight = 17;
	this.text_7.setTransform(313.7,249.8);

	this.text_8 = new cjs.Text("2", "14px Verdana");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(314.7,326.7);

	this.text_9 = new cjs.Text("1", "14px Verdana");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(313.7,406.1);

	this.text_10 = new cjs.Text("0", "14px Verdana");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(313.7,472.9);

	this.text_11 = new cjs.Text("8", "14px Verdana");
	this.text_11.lineHeight = 17;
	this.text_11.setTransform(949.6,498.3);

	this.text_12 = new cjs.Text("7", "14px Verdana");
	this.text_12.lineHeight = 17;
	this.text_12.setTransform(871.2,498.3);

	this.text_13 = new cjs.Text("6", "14px Verdana");
	this.text_13.lineHeight = 17;
	this.text_13.setTransform(794.2,498.3);

	this.text_14 = new cjs.Text("5", "14px Verdana");
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(717.4,498.3);

	this.text_15 = new cjs.Text("4", "14px Verdana");
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(639.6,498.3);

	this.text_16 = new cjs.Text("3", "14px Verdana");
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(561.7,498.3);

	this.text_17 = new cjs.Text("1", "14px Verdana");
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(406.8,498.3);

	this.text_18 = new cjs.Text("2", "14px Verdana");
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(483.9,498.3);

	this.text_19 = new cjs.Text("-4", "14px Verdana");
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(17.1,498.3);

	this.text_20 = new cjs.Text("-3", "14px Verdana");
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(93.9,498.3);

	this.text_21 = new cjs.Text("-1", "14px Verdana");
	this.text_21.lineHeight = 17;
	this.text_21.setTransform(248.4,498.3);

	this.text_22 = new cjs.Text("-2", "14px Verdana");
	this.text_22.lineHeight = 17;
	this.text_22.setTransform(170.8,498.3);

	this.text_23 = new cjs.Text("0", "14px Verdana");
	this.text_23.lineHeight = 17;
	this.text_23.setTransform(342.3,498.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_4.setTransform(330.6,797.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_5.setTransform(330.6,720);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_6.setTransform(330.6,642.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_7.setTransform(330.6,566);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_8.setTransform(330.6,23.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_9.setTransform(330.6,100.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_10.setTransform(330.6,178.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_11.setTransform(330.6,255.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_12.setTransform(330.6,333.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_13.setTransform(330.6,410.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_14.setTransform(23.8,491.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_15.setTransform(101.5,491.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_16.setTransform(179,491.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_17.setTransform(255.6,491.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_18.setTransform(410.8,491.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_19.setTransform(488.3,490.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_20.setTransform(565.9,490.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_21.setTransform(643.5,491.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_22.setTransform(721.1,491);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_23.setTransform(797.7,490.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_24.setTransform(953.1,490.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_25.setTransform(875.3,490.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAAgPIg1A3IgLgLIBAhEIBBBEIgMALg");
	this.shape_26.setTransform(333,4.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA+RMAAAh8h");
	this.shape_27.setTransform(333,400.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgnA1IA4g1Ig4g0IALgMIBEBAIhEBBg");
	this.shape_28.setTransform(981,488.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(4,0,0,4).p("EhMzAAAMCZnAAA");
	this.shape_29.setTransform(491.7,488.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_3},{t:this.shape_2},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(1210000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(17.1,0,968,804.7);

(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{fin:109});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape.setTransform(511.8,511.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3900AC").s().p("AggAhQgOgOAAgTQAAgSAOgOQAOgOASABQATgBAOAOQAOAOAAASQAAATgOAOQgOANgTAAQgSAAgOgNg");
	this.shape_1.setTransform(511.8,511.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(110));

	// Layer 12
	this.instance = new lib.Tween48("synched",0);
	this.instance.setTransform(-627.8,743.5,1.327,1.327);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(23));

	// Layer 13
	this.instance_1 = new lib.Tween49("synched",0);
	this.instance_1.setTransform(-627.8,802.9,1.327,1.327);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(87).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(5));

	// Layer 4
	this.instance_2 = new lib.Tween50("synched",0);
	this.instance_2.setTransform(500.7,505.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(87).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(5));

	// Layer 8
	this.instance_3 = new lib.Tween51("synched",0);
	this.instance_3.setTransform(-627.8,587.9,1.327,1.327);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(40).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(62));

	// Layer 11
	this.instance_4 = new lib.Tween52("synched",0);
	this.instance_4.setTransform(-627.8,647.3,1.327,1.327);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(48).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(44));

	// Layer 3
	this.instance_5 = new lib.Tween53("synched",0);
	this.instance_5.setTransform(478.2,412);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(48).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(44));

	// Layer 6
	this.instance_6 = new lib.Tween54("synched",0);
	this.instance_6.setTransform(-627.8,430.9,1.327,1.327);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(101));

	// Layer 7
	this.instance_7 = new lib.Tween55("synched",0);
	this.instance_7.setTransform(-627.8,490.3,1.327,1.327);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(9).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(83));

	// Layer 2
	this.instance_8 = new lib.Tween56("synched",0);
	this.instance_8.setTransform(411.5,410.7);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(9).to({startPosition:0,_off:false},0).to({alpha:1},18).wait(83));

	// Layer 1
	this.text = new cjs.Text("a", "14px Verdana", "#3900AC");
	this.text.lineHeight = 17;
	this.text.setTransform(26.7,0);

	this.text_1 = new cjs.Text("1", "14px Verdana");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(592.4,520.4);

	this.text_2 = new cjs.Text("2", "14px Verdana");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(678.1,520.4);

	this.text_3 = new cjs.Text("4", "14px Verdana");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(847.6,521.3);

	this.text_4 = new cjs.Text("-3", "14px Verdana");
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(485.1,761.3);

	this.text_5 = new cjs.Text("-2", "14px Verdana");
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(485.1,675.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
	this.shape_2.setTransform(511.8,511.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3900AC").s().p("AggAhQgOgOAAgTQAAgSAOgOQAOgOASABQATgBAOAOQAOAOAAASQAAATgOAOQgOANgTAAQgSAAgOgNg");
	this.shape_3.setTransform(511.8,511.3);

	this.text_6 = new cjs.Text("-1", "14px Verdana");
	this.text_6.lineHeight = 17;
	this.text_6.setTransform(485.1,590.4);

	this.text_7 = new cjs.Text("5", "14px Verdana");
	this.text_7.lineHeight = 17;
	this.text_7.setTransform(492.2,77.6);

	this.text_8 = new cjs.Text("4", "14px Verdana");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(492.2,164.1);

	this.text_9 = new cjs.Text("3", "14px Verdana");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(492.2,248.4);

	this.text_10 = new cjs.Text("2", "14px Verdana");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(492.2,333.4);

	this.text_11 = new cjs.Text("1", "14px Verdana");
	this.text_11.lineHeight = 17;
	this.text_11.setTransform(492.2,419.3);

	this.text_12 = new cjs.Text("0", "14px Verdana");
	this.text_12.lineHeight = 17;
	this.text_12.setTransform(520,521.4);

	this.text_13 = new cjs.Text("5", "14px Verdana");
	this.text_13.lineHeight = 17;
	this.text_13.setTransform(934.2,520.4);

	this.text_14 = new cjs.Text("3", "14px Verdana");
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(762,521.4);

	this.text_15 = new cjs.Text("-5", "14px Verdana");
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(74,521.4);

	this.text_16 = new cjs.Text("-4", "14px Verdana");
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(160,521.4);

	this.text_17 = new cjs.Text("-3", "14px Verdana");
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(245.6,521.4);

	this.text_18 = new cjs.Text("-1", "14px Verdana");
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(414.7,521.4);

	this.text_19 = new cjs.Text("-2", "14px Verdana");
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(329.7,521.4);

	this.text_20 = new cjs.Text("0", "14px Verdana");
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(492.2,484);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_4.setTransform(508.3,766.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_5.setTransform(508.3,681.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_6.setTransform(508.3,595.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_7.setTransform(508.3,82.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_8.setTransform(508.3,168.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_9.setTransform(508.3,253.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_10.setTransform(508.3,338.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,0,0,4).p("AggAAIBBAA");
	this.shape_11.setTransform(508.3,425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_12.setTransform(83.4,514.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_13.setTransform(168.7,514.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_14.setTransform(253.6,514.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_15.setTransform(339.2,514.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_16.setTransform(425,514.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_17.setTransform(596.5,513.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_18.setTransform(682,514.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_19.setTransform(767.2,514);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_20.setTransform(852.7,513.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAAgQIg0A4IgMgLIBAhEIBBBEIgMALg");
	this.shape_21.setTransform(511.3,14.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA+jMAAAh9F");
	this.shape_22.setTransform(511.4,412.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(2,0,0,4).p("AAAggIAABB");
	this.shape_23.setTransform(938.2,514);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgnA1IA4g1Ig4g0IALgMIBEBAIhEBBg");
	this.shape_24.setTransform(989.3,511.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(4,0,0,4).p("EhNJAAAMCaTAAA");
	this.shape_25.setTransform(497.8,511.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.shape_3},{t:this.shape_2},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(110000));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(26.7,0,966.6,774.8);

    (lib.Symbol6 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Layer 6
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
        this.shape.setTransform(333.4, 488.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
        this.shape_1.setTransform(333.4, 488.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}]}).wait(99));

        // Layer 5
        this.instance = new lib.Tween30("synched", 0);
        this.instance.setTransform(333.5, 488.2);
        this.instance.alpha = 0;
        this.instance._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 2).to({alpha: 0}, 2).to({alpha: 1}, 2).to({alpha: 0}, 2).to({startPosition: 0}, 20).to({alpha: 1}, 2).to({alpha: 0}, 2).to({alpha: 1}, 2).to({alpha: 0}, 2).to({startPosition: 0}, 22).to({alpha: 1}, 2).to({alpha: 0}, 2).to({alpha: 1}, 2).to({alpha: 0}, 2).to({_off: true}, 1).wait(13));

        // Layer 10
        this.instance_1 = new lib.Tween24("synched", 0);
        this.instance_1.setTransform(-622.1, 776.5, 2.105, 2.105);
        this.instance_1.alpha = 0;
        this.instance_1._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(22));

        // Layer 4
        this.instance_2 = new lib.Tween25("synched", 0);
        this.instance_2.setTransform(304.6, 399.4);
        this.instance_2.alpha = 0;
        this.instance_2._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(22));

        // Layer 9
        this.instance_3 = new lib.Tween26("synched", 0);
        this.instance_3.setTransform(-622.1, 645.4, 2.105, 2.105);
        this.instance_3.alpha = 0;
        this.instance_3._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(52));

        // Layer 3
        this.instance_4 = new lib.Tween27("synched", 0);
        this.instance_4.setTransform(377.7, 399.4);
        this.instance_4.alpha = 0;
        this.instance_4._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(29).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(52));

        // Layer 8
        this.instance_5 = new lib.Tween28("synched", 0);
        this.instance_5.setTransform(-622.1, 503.3, 2.105, 2.105);
        this.instance_5.alpha = 0;
        this.instance_5._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(80));

        // Layer 2
        this.instance_6 = new lib.Tween29("synched", 0);
        this.instance_6.setTransform(420.9, 399.4);
        this.instance_6.alpha = 0;
        this.instance_6._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1).to({startPosition: 0, _off: false}, 0).to({alpha: 1}, 18).wait(80));

        // Layer 1
        this.text = new cjs.Text("-4", "14px Verdana");
        this.text.lineHeight = 17;
        this.text.setTransform(308.5, 791.1);

        this.text_1 = new cjs.Text("-3", "14px Verdana");
        this.text_1.lineHeight = 17;
        this.text_1.setTransform(308.5, 715);

        this.text_2 = new cjs.Text("-2", "14px Verdana");
        this.text_2.lineHeight = 17;
        this.text_2.setTransform(308.5, 637.4);

        this.text_3 = new cjs.Text("-1", "14px Verdana");
        this.text_3.lineHeight = 17;
        this.text_3.setTransform(308.5, 560.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
        this.shape_2.setTransform(333.4, 488.2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
        this.shape_3.setTransform(333.4, 488.2);

        this.text_4 = new cjs.Text("6", "14px Verdana");
        this.text_4.lineHeight = 17;
        this.text_4.setTransform(313.7, 18.4);

        this.text_5 = new cjs.Text("5", "14px Verdana");
        this.text_5.lineHeight = 17;
        this.text_5.setTransform(313.6, 96);

        this.text_6 = new cjs.Text("4", "14px Verdana");
        this.text_6.lineHeight = 17;
        this.text_6.setTransform(312.7, 174.7);

        this.text_7 = new cjs.Text("3", "14px Verdana");
        this.text_7.lineHeight = 17;
        this.text_7.setTransform(313.6, 249.8);

        this.text_8 = new cjs.Text("2", "14px Verdana");
        this.text_8.lineHeight = 17;
        this.text_8.setTransform(314.7, 326.7);

        this.text_9 = new cjs.Text("1", "14px Verdana");
        this.text_9.lineHeight = 17;
        this.text_9.setTransform(313.6, 406.1);

        this.text_10 = new cjs.Text("0", "14px Verdana");
        this.text_10.lineHeight = 17;
        this.text_10.setTransform(313.7, 472.9);

        this.text_11 = new cjs.Text("8", "14px Verdana");
        this.text_11.lineHeight = 17;
        this.text_11.setTransform(949.6, 498.3);

        this.text_12 = new cjs.Text("7", "14px Verdana");
        this.text_12.lineHeight = 17;
        this.text_12.setTransform(871.2, 498.3);

        this.text_13 = new cjs.Text("6", "14px Verdana");
        this.text_13.lineHeight = 17;
        this.text_13.setTransform(794.1, 498.3);

        this.text_14 = new cjs.Text("5", "14px Verdana");
        this.text_14.lineHeight = 17;
        this.text_14.setTransform(717.4, 498.3);

        this.text_15 = new cjs.Text("4", "14px Verdana");
        this.text_15.lineHeight = 17;
        this.text_15.setTransform(639.5, 498.3);

        this.text_16 = new cjs.Text("3", "14px Verdana");
        this.text_16.lineHeight = 17;
        this.text_16.setTransform(561.7, 498.3);

        this.text_17 = new cjs.Text("1", "14px Verdana");
        this.text_17.lineHeight = 17;
        this.text_17.setTransform(406.8, 498.3);

        this.text_18 = new cjs.Text("2", "14px Verdana");
        this.text_18.lineHeight = 17;
        this.text_18.setTransform(483.8, 498.3);

        this.text_19 = new cjs.Text("-4", "14px Verdana");
        this.text_19.lineHeight = 17;
        this.text_19.setTransform(17, 498.3);

        this.text_20 = new cjs.Text("-3", "14px Verdana");
        this.text_20.lineHeight = 17;
        this.text_20.setTransform(93.9, 498.3);

        this.text_21 = new cjs.Text("-1", "14px Verdana");
        this.text_21.lineHeight = 17;
        this.text_21.setTransform(248.4, 498.3);

        this.text_22 = new cjs.Text("-2", "14px Verdana");
        this.text_22.lineHeight = 17;
        this.text_22.setTransform(170.7, 498.3);

        this.text_23 = new cjs.Text("0", "14px Verdana");
        this.text_23.lineHeight = 17;
        this.text_23.setTransform(342.2, 498.3);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_4.setTransform(330.6, 797.8);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_5.setTransform(330.6, 720);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_6.setTransform(330.6, 642.5);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_7.setTransform(330.6, 566);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_8.setTransform(330.6, 23.6);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_9.setTransform(330.6, 100.8);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_10.setTransform(330.6, 178.6);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_11.setTransform(330.6, 255.3);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_12.setTransform(330.6, 333.3);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_13.setTransform(330.6, 410.8);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_14.setTransform(23.8, 491.1);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_15.setTransform(101.5, 491.1);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_16.setTransform(178.9, 491.1);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_17.setTransform(255.6, 491.1);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_18.setTransform(410.8, 491.1);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_19.setTransform(488.3, 490.7);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_20.setTransform(565.9, 490.6);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_21.setTransform(643.5, 491.8);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_22.setTransform(721.1, 491);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_23.setTransform(797.7, 490.8);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_24.setTransform(953, 490.9);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_25.setTransform(875.2, 490.9);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#000000").s().p("AAAgPIg1A3IgLgLIBAhEIBBBEIgMALg");
        this.shape_26.setTransform(333, 4.1);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EAAAA+RMAAAh8h");
        this.shape_27.setTransform(333, 400.3);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#000000").s().p("AgnA1IA4g1Ig4g0IALgMIBEBAIhEBBg");
        this.shape_28.setTransform(980.9, 488.4);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EhMzAAAMCZnAAA");
        this.shape_29.setTransform(491.6, 488.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_29}, {t: this.shape_28}, {t: this.shape_27}, {t: this.shape_26}, {t: this.shape_25}, {t: this.shape_24}, {t: this.shape_23}, {t: this.shape_22}, {t: this.shape_21}, {t: this.shape_20}, {t: this.shape_19}, {t: this.shape_18}, {t: this.shape_17}, {t: this.shape_16}, {t: this.shape_15}, {t: this.shape_14}, {t: this.shape_13}, {t: this.shape_12}, {t: this.shape_11}, {t: this.shape_10}, {t: this.shape_9}, {t: this.shape_8}, {t: this.shape_7}, {t: this.shape_6}, {t: this.shape_5}, {t: this.shape_4}, {t: this.text_23}, {t: this.text_22}, {t: this.text_21}, {t: this.text_20}, {t: this.text_19}, {t: this.text_18}, {t: this.text_17}, {t: this.text_16}, {t: this.text_15}, {t: this.text_14}, {t: this.text_13}, {t: this.text_12}, {t: this.text_11}, {t: this.text_10}, {t: this.text_9}, {t: this.text_8}, {t: this.text_7}, {t: this.text_6}, {t: this.text_5}, {t: this.text_4}, {t: this.shape_3}, {t: this.shape_2}, {t: this.text_3}, {t: this.text_2}, {t: this.text_1}, {t: this.text}]}).wait(990000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(17, 0, 968, 804.7);

    (lib.ClipGroup0 = function () {
        this.initialize();

        // Layer 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EhOHBOHMAAAicOMCcOAAAMAAACcOg");
        mask.setTransform(500, 500);

        // Layer 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("AhlAAIhFi9QA/A2BiA2QBYAwBbAhQhcAihXAwQhjA2g+A2g");
        this.shape.setTransform(814.9, 472.1);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("AAJBSQhWgwhcgiQBbghBXgwQBjg2A+g2IhEC9IBEC+Qg9g2hkg2g");
        this.shape_1.setTransform(157.1, 472.1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EgyRAAAMBkjAAA");
        this.shape_2.setTransform(486, 472.1);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#000000").s().p("AhRgIQg2hkg2g+IC9BFIC+hFQg2A+g2BkQgwBXgiBbQghhbgwhXg");
        this.shape_3.setTransform(497, 723);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#000000").s().p("AAABmIi9BFQA2g+A2hjQAwhXAhhcQAiBbAwBYQA2BiA2A/g");
        this.shape_4.setTransform(497, 213.1);

        this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = mask;

        this.addChild(this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(140, 196, 692, 544.1);

    (lib.BtnFalse = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
        this.shape.setTransform(310, 163.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
        this.shape_1.setTransform(310, 163.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);

    (lib.ClipGroup0_2 = function () {
        this.initialize();

        // Layer 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EhAXBN+MAAAib7MCAvAAAMAAACb7g");
        mask.setTransform(412, 499);

    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.ClipGroup0_1 = function () {
        this.initialize();

        // Layer 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EhOHBOHMAAAicOMCcOAAAMAAACcOg");
        mask.setTransform(500, 500);

        // Layer 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#350088").s().p("AhlAAIhFi9QA/A2BiA2QBYAwBbAhQhbAihYAwQhiA2g/A2g");
        this.shape.setTransform(864, 573.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#350088").ss(4, 0, 0, 4).p("Eg+eAAAMB89AAA");
        this.shape_1.setTransform(457, 573.5);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#350088").s().p("AAABmIi9BEQA2g9A2hkQAxhWAghdQAiBdAwBWQA2BkA1A9g");
        this.shape_2.setTransform(469, 28.1);

        this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask;

        this.addChild(this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(450, 11, 431.1, 581.6);


    (lib.ClipGroup0b = function () {
        this.initialize();

        // Layer 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EhOHBOHMAAAicOMCcOAAAMAAACcOg");
        mask.setTransform(500, 500);

        // Layer 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FE001C").ss(4, 0, 0, 4).p("EhAXBAJMCAviAR");
        this.shape.setTransform(469, 412.5);

        this.shape.mask = mask;

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(57, 2, 824.1, 821);

    (lib.Tween56 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#3900AC").ss(4, 0, 0, 4).p("EA+VA+5Mh8ph9x");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-398.9, -402.4, 797.9, 805.1);


    (lib.Tween55 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = -x", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween54 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = -1", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween53 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FE001C").ss(4, 0, 0, 4).p("EAU+A+sMgp7h9X");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-134.2, -401.1, 268.5, 802.5);


    (lib.Tween52 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = -3x", "italic 20px Verdana", "#FE001C");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween51 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = -3", "italic 20px Verdana", "#FE001C");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween50 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#009900").ss(4, 0, 0, 4).p("EBOOAm/MicbhN9");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-500.6, -249.4, 1001.4, 499.1);


    (lib.Tween49 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = -0,5x", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween48 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = -0,5", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween47 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#3900AC").ss(4, 0, 0, 4).p("Eg4kA4sMBxIhxX");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-362, -362.8, 724.2, 725.7);


    (lib.Tween46 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = x", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween45 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = 1", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween44 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#009900").ss(4, 0, 0, 4).p("EgNXA4EMAavhwH");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-85.5, -358.7, 171.3, 717.7);


    (lib.Tween43 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 4x", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween42 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = 4", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween41 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#EB00B3").ss(4, 0, 0, 4).p("EhM8AmNMCZ5hMZ");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-492.4, -244.5, 985.1, 489.2);


    (lib.Tween40 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 0,5x", "italic 20px Verdana", "#EB00B3");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween39 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("m = 0,5", "italic 20px Verdana", "#EB00B3");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween38 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#009900").ss(4, 0, 0, 4).p("EgNXA4EMAavhwH");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-85.5, -358.7, 171.3, 717.7);


    (lib.Tween37 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 4x", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween36 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FE001C").ss(4, 0, 0, 4).p("EgcZA41MA4zhxq");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-181.7, -363.7, 363.7, 727.6);


    (lib.Tween35 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 2x", "italic 20px Verdana", "#FE001C");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween34 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#3900AC").ss(4, 0, 0, 4).p("Eg4kA4sMBxIhxX");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-362, -362.8, 724.2, 725.7);


    (lib.Tween33 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = x", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween32 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#EB00B3").ss(4, 0, 0, 4).p("EhM8AmNMCZ5hMZ");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-492.4, -244.5, 985.1, 489.2);


    (lib.Tween31 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 0,5x", "italic 20px Verdana", "#EB00B3");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-89.2, -23.3, 1.652, 1.652);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-89.2, -23.3, 178.6, 46.8);


    (lib.Tween30 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.rf(["#FFFFFF", "rgba(255,255,255,0)"], [0, 1], 0, 0, 0, 0, 0, 19.8).s().p("AiCCFQg2g4AAhNQAAhMA2g1QA3g4BLAAQBMAAA4A4QA2A1gBBMQABBNg2A4Qg4A2hMgBQhLABg3g2g");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-18.5, -18.6, 37.2, 37.4);


    (lib.Tween29 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#3900AC").ss(4, 0, 0, 4).p("Eg+CA+aMB8Fh8z");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-397.1, -399.3, 794.3, 798.9);


    (lib.Tween28 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = x", "italic 20px Verdana", "#3900AC");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-54, -14.1);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-54, -14.1, 108.1, 28.3);


    (lib.Tween27 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FE001C").ss(4, 0, 0, 4).p("EgfDA+aMA+Hh8z");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-198.7, -399.3, 397.7, 798.9);


    (lib.Tween26 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = 2x", "italic 20px Verdana", "#FE001C");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-54, -14.1);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-54, -14.1, 108.1, 28.3);


    (lib.Tween25 = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#009900").ss(4, 0, 0, 4).p("EAU7A+aMgp1h8z");

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-133.8, -399.3, 267.9, 798.9);


    (lib.Tween24 = function () {
        this.initialize();

        // Layer 1
        this.text = new cjs.Text("y = -3x", "italic 20px Verdana", "#009900");
        this.text.lineHeight = 22;
        this.text.lineWidth = 104;
        this.text.setTransform(-54, -14.1);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-54, -14.1, 108.1, 28.3);

    (lib.Symbol_intro = function () {
        this.initialize();

        // Layer 6
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
        this.shape.setTransform(333.4, 488.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
        this.shape_1.setTransform(333.4, 488.2);

        // Layer 5
        this.instance = new lib.Tween30("synched", 0);
        this.instance.setTransform(333.5, 488.2);
        this.instance.alpha = 0;

        // Layer 4
        this.instance_1 = new lib.Tween25("synched", 0);
        this.instance_1.setTransform(304.6, 399.4);

        // Layer 3
        this.instance_2 = new lib.Tween27("synched", 0);
        this.instance_2.setTransform(377.7, 399.4);

        // Layer 2
        this.instance_3 = new lib.Tween29("synched", 0);
        this.instance_3.setTransform(420.9, 399.4);

        // Layer 1
        this.text = new cjs.Text("-4", "14px Verdana");
        this.text.lineHeight = 17;
        this.text.setTransform(308.5, 791.1);

        this.text_1 = new cjs.Text("-3", "14px Verdana");
        this.text_1.lineHeight = 17;
        this.text_1.setTransform(308.5, 715);

        this.text_2 = new cjs.Text("-2", "14px Verdana");
        this.text_2.lineHeight = 17;
        this.text_2.setTransform(308.5, 637.4);

        this.text_3 = new cjs.Text("-1", "14px Verdana");
        this.text_3.lineHeight = 17;
        this.text_3.setTransform(308.5, 560.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAuAAQAAATgNAOQgOANgTAAQgSAAgOgNQgNgOAAgTQAAgSANgOQAOgOASAAQATAAAOAOQANAOAAASg");
        this.shape_2.setTransform(333.4, 488.2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#3900AC").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgOASABQATgBAOAOQANAOAAASQAAATgNAOQgOANgTAAQgSAAgOgNg");
        this.shape_3.setTransform(333.4, 488.2);

        this.text_4 = new cjs.Text("6", "14px Verdana");
        this.text_4.lineHeight = 17;
        this.text_4.setTransform(313.7, 18.4);

        this.text_5 = new cjs.Text("5", "14px Verdana");
        this.text_5.lineHeight = 17;
        this.text_5.setTransform(313.6, 96);

        this.text_6 = new cjs.Text("4", "14px Verdana");
        this.text_6.lineHeight = 17;
        this.text_6.setTransform(312.7, 174.7);

        this.text_7 = new cjs.Text("3", "14px Verdana");
        this.text_7.lineHeight = 17;
        this.text_7.setTransform(313.6, 249.8);

        this.text_8 = new cjs.Text("2", "14px Verdana");
        this.text_8.lineHeight = 17;
        this.text_8.setTransform(314.7, 326.7);

        this.text_9 = new cjs.Text("1", "14px Verdana");
        this.text_9.lineHeight = 17;
        this.text_9.setTransform(313.6, 406.1);

        this.text_10 = new cjs.Text("0", "14px Verdana");
        this.text_10.lineHeight = 17;
        this.text_10.setTransform(313.7, 472.9);

        this.text_11 = new cjs.Text("8", "14px Verdana");
        this.text_11.lineHeight = 17;
        this.text_11.setTransform(949.6, 498.3);

        this.text_12 = new cjs.Text("7", "14px Verdana");
        this.text_12.lineHeight = 17;
        this.text_12.setTransform(871.2, 498.3);

        this.text_13 = new cjs.Text("6", "14px Verdana");
        this.text_13.lineHeight = 17;
        this.text_13.setTransform(794.1, 498.3);

        this.text_14 = new cjs.Text("5", "14px Verdana");
        this.text_14.lineHeight = 17;
        this.text_14.setTransform(717.4, 498.3);

        this.text_15 = new cjs.Text("4", "14px Verdana");
        this.text_15.lineHeight = 17;
        this.text_15.setTransform(639.5, 498.3);

        this.text_16 = new cjs.Text("3", "14px Verdana");
        this.text_16.lineHeight = 17;
        this.text_16.setTransform(561.7, 498.3);

        this.text_17 = new cjs.Text("1", "14px Verdana");
        this.text_17.lineHeight = 17;
        this.text_17.setTransform(406.8, 498.3);

        this.text_18 = new cjs.Text("2", "14px Verdana");
        this.text_18.lineHeight = 17;
        this.text_18.setTransform(483.8, 498.3);

        this.text_19 = new cjs.Text("-4", "14px Verdana");
        this.text_19.lineHeight = 17;
        this.text_19.setTransform(17, 498.3);

        this.text_20 = new cjs.Text("-3", "14px Verdana");
        this.text_20.lineHeight = 17;
        this.text_20.setTransform(93.9, 498.3);

        this.text_21 = new cjs.Text("-1", "14px Verdana");
        this.text_21.lineHeight = 17;
        this.text_21.setTransform(248.4, 498.3);

        this.text_22 = new cjs.Text("-2", "14px Verdana");
        this.text_22.lineHeight = 17;
        this.text_22.setTransform(170.7, 498.3);

        this.text_23 = new cjs.Text("0", "14px Verdana");
        this.text_23.lineHeight = 17;
        this.text_23.setTransform(342.2, 498.3);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_4.setTransform(330.6, 797.8);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_5.setTransform(330.6, 720);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_6.setTransform(330.6, 642.5);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_7.setTransform(330.6, 566);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_8.setTransform(330.6, 23.6);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_9.setTransform(330.6, 100.8);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_10.setTransform(330.6, 178.6);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_11.setTransform(330.6, 255.3);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_12.setTransform(330.6, 333.3);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AggAAIBBAA");
        this.shape_13.setTransform(330.6, 410.8);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_14.setTransform(23.8, 491.1);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_15.setTransform(101.5, 491.1);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_16.setTransform(178.9, 491.1);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_17.setTransform(255.6, 491.1);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_18.setTransform(410.8, 491.1);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_19.setTransform(488.3, 490.7);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_20.setTransform(565.9, 490.6);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_21.setTransform(643.5, 491.8);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_22.setTransform(721.1, 491);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_23.setTransform(797.7, 490.8);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_24.setTransform(953, 490.9);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(2, 0, 0, 4).p("AAAggIAABB");
        this.shape_25.setTransform(875.2, 490.9);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#000000").s().p("AAAgPIg1A3IgLgLIBAhEIBBBEIgMALg");
        this.shape_26.setTransform(333, 4.1);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EAAAA+RMAAAh8h");
        this.shape_27.setTransform(333, 400.3);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#000000").s().p("AgnA1IA4g1Ig4g0IALgMIBEBAIhEBBg");
        this.shape_28.setTransform(980.9, 488.4);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#000000").ss(4, 0, 0, 4).p("EhMzAAAMCZnAAA");
        this.shape_29.setTransform(491.6, 488.4);

        this.addChild(this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.text_23, this.text_22, this.text_21, this.text_20, this.text_19, this.text_18, this.text_17, this.text_16, this.text_15, this.text_14, this.text_13, this.text_12, this.text_11, this.text_10, this.text_9, this.text_8, this.text_7, this.text_6, this.text_5, this.text_4, this.shape_3, this.shape_2, this.text_3, this.text_2, this.text_1, this.text, this.instance_3, this.instance_2, this.instance_1, this.instance, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(17, 0, 968, 804.7);

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}