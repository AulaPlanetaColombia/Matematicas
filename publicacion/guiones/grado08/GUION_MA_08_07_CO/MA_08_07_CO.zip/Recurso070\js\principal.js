(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

this.entrar = new lib.BtnFalse();
	this.entrar.setTransform(476.9,349.1,0.8,1.286,0,0,0,309.9,163.5);
	new cjs.ButtonHelper(this.entrar, 0, 1, 2, false, new lib.BtnFalse(), 3);

	this.instance_1 = new lib.MTB_10_07_01_01();
	this.instance_1.setTransform(242.5,152.1,0.588,0.588);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.entrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.siguiente,this.entrar, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        

 var html = createDiv(txt['pantalla1_02'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -500);
    
      html = createDiv(txt['pantalla1_03'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 20);
    this.texto2.setTransform(100, -350);
    
    html = createDiv(txt['pantalla1_04'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.texto3 = new lib.fadeText(html, 40);
    this.texto3.setTransform(100, -290);
    html = createDiv(txt['pantalla1_05'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.texto4 = new lib.fadeText(html, 60);
    this.texto4.setTransform(100, -230);
    html = createDiv(txt['pantalla1_06'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.texto5 = new lib.fadeText(html, 80);
    this.texto5.setTransform(100, -170);
    
        this.instance_2 = new lib.MTB_10_07_01_02();
	this.instance_2.setTransform(475,151.8,0.496,0.496);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.siguiente, this.texto1, this.texto2, this.texto3 , this.texto4, this.texto5,this.instance_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['pantalla2_01']);
var html = createDiv(txt['pantalla2_01'], "Verdana", "20px", '400px', '10px', "20px", "185px", "left");
    this.titulo = new lib.fadeText(html, 0);
    this.titulo.setTransform(90, -480);
 
	this.instance_1 = new lib.pant_02();
	this.instance_1.setTransform(279.1,328.4,1,1,0,0,0,197.2,177.9);
        
         var html = createDiv(txt['pantalla2_02'], "Verdana", "20px", '300px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 180);
    this.texto1.setTransform(90, -220);
    
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance_1,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
        	this.instance = new lib.pant_03();
	this.instance.setTransform(293.5,323.9,1,1,0,0,0,197.2,177.9);
var html = createDiv(txt['pantalla3_01'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
      html = createDiv(txt['pantalla3_02'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 60);
    this.texto2.setTransform(90, -300);
    


	this.instance_1 = new lib.shutterstock_44676511();
	this.instance_1.setTransform(460.4,116,0.563,0.563);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
        	this.instance = new lib.pant_04();
	this.instance.setTransform(293,330.1,1,1,0,0,0,197.2,177.9);
var html = createDiv(txt['pantalla4_01'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
      html = createDiv(txt['pantalla4_02'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 60);
    this.texto2.setTransform(90, -330);
    


	this.instance_1 = new lib.MTB_10_07_01_03();
	this.instance_1.setTransform(460.4,116,0.498,0.498);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
        	var html = createDiv(txt['pantalla5_01'], "Verdana", "20px", '345px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
      html = createDiv(txt['pantalla5_02'], "Verdana", "20px", '345px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 60,0);
    this.texto2.setTransform(90, -470);
    
this.text = new cjs.Text("X", "20px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.setTransform(878.2,325.3);

	this.text_1 = new cjs.Text("Y", "20px Arial");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(658.2,84.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("Ag0gzQAXgXAdAAQAfAAAWAXQAWAVAAAeQAAAfgWAVQgWAXgfAAQgdAAgXgXQgWgVAAgfQAAgeAWgVg");
	this.shape.setTransform(646.3,351.5,0.459,0.459);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("AgzA1QgXgXAAgeQAAgdAXgXQAVgWAeABQAfgBAVAWQAXAXAAAdQAAAegXAXQgVAVgfAAQgeAAgVgVg");
	this.shape_1.setTransform(646.3,351.5,0.459,0.459);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,0,0,4).p("APt/SMgfZA+l");
	this.shape_2.setTransform(666.4,311.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,0,0,4).p("AAA/PMAAAA+f");
	this.shape_3.setTransform(646.3,311);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("A/IAAMA+RAAA");
	this.shape_4.setTransform(665.3,351.4);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_1,this.text,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
        	this.instance = new lib.pant_06();
	this.instance.setTransform(293.5,323.9,1,1,0,0,0,197.2,177.9);
var html = createDiv(txt['pantalla6_01'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
    
 html = createDiv(txt['pantalla6_02'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 30);
    this.texto2.setTransform(90, -470);
    
     html = createDiv(txt['pantalla6_03'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto3 = new lib.fadeText(html, 60);
    this.texto3.setTransform(90, -470);

	

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1,this.texto1,this.texto2,this.texto3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
        	this.instance = new lib.pant_07();
	this.instance.setTransform(293.5,323.9,1,1,0,0,0,197.2,177.9);
var html = createDiv(txt['pantalla7_01'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
    
 html = createDiv(txt['pantalla7_02'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 50);
    this.texto2.setTransform(90, -470);
    
    

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.instance_1,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
this.instance = new lib.pant_08();
	this.instance.setTransform(293.5,323.9,1,1,0,0,0,197.2,177.9);
var html = createDiv(txt['pantalla8_01'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, -470);
    
    
 html = createDiv(txt['pantalla8_02'], "Verdana", "20px", '330px', '10px', "20px", "185px", "left");
    this.texto2 = new lib.fadeText(html, 50);
    this.texto2.setTransform(90, -470);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance,this.instance_1,this.texto1,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -502);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

   
   //Simbolillos
   
   (lib.flash0 = function() {
	this.initialize(img.flash0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,76,18);


(lib.flash0pngcopy = function() {
	this.initialize(img.flash0pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,76,18);


(lib.MTB_10_07_01_01 = function() {
	this.initialize(img.MTB_10_07_01_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,676);


(lib.MTB_10_07_01_02 = function() {
	this.initialize(img.MTB_10_07_01_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,589);


(lib.MTB_10_07_01_03 = function() {
	this.initialize(img.MTB_10_07_01_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,488);



(lib.shutterstock_44676511 = function() {
	this.initialize(img.shutterstock_44676511);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,700,467);


(lib.Symbol7 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00A52F").ss(1,0,0,4).p("Afsv+Mg/XAf9");
	this.shape.setTransform(202.9,102.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,405.8,204.7);


(lib.Symbol6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgXAWQgVAWgfAAQgeAAgVgWQgXgWAAgfQAAgdAXgWQAVgXAeAAQAfAAAVAXQAXAWAAAdg");
	this.shape.setTransform(3.3,3.3,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("AgzA1QgXgXAAgeQAAgdAXgXQAVgWAeABQAfgBAVAWQAXAXAAAdQAAAegXAXQgVAVgfAAQgeAAgVgVg");
	this.shape_1.setTransform(3.3,3.3,0.444,0.444);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,6.7);


(lib.Symbol5 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgWAWQgWAWgfAAQgeAAgVgWQgXgWAAgfQAAgdAXgWQAVgXAeAAQAfAAAWAXQAWAWAAAdg");
	this.shape.setTransform(3.3,3.3,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("AgzA1QgXgXAAgeQAAgeAXgVQAVgXAeAAQAfAAAVAXQAXAVAAAeQAAAegXAXQgVAVgfAAQgeAAgVgVg");
	this.shape_1.setTransform(3.3,3.3,0.444,0.444);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,6.7);


(lib.Symbol4 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AA1gzQAWAVAAAeQAAAfgWAVQgWAXgfAAQgdAAgWgXQgXgVAAgfQAAgeAXgVQAWgXAdAAQAfAAAWAXg");
	this.shape.setTransform(3.3,3.3,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("Ag0A0QgVgVAAgfQAAgdAVgXQAXgVAdgBQAeABAWAVQAXAXgBAdQABAfgXAVQgWAXgeAAQgdAAgXgXg");
	this.shape_1.setTransform(3.3,3.3,0.444,0.444);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,6.7);


(lib.Symbol3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgWAWQgWAWgfAAQgdAAgWgWQgXgWAAgfQAAgdAXgWQAWgXAdAAQAfAAAWAXQAWAWAAAdg");
	this.shape.setTransform(3.3,3.3,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("Ag0A0QgVgVgBgfQABgeAVgVQAXgXAdAAQAfAAAVAXQAXAVAAAeQAAAfgXAVQgVAXgfAAQgdAAgXgXg");
	this.shape_1.setTransform(3.3,3.3,0.444,0.444);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,6.7);


(lib.Symbol2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AA1gzQAWAWAAAdQAAAfgWAWQgWAWgfAAQgdAAgWgWQgWgWAAgfQAAgdAWgWQAWgXAdAAQAfAAAWAXg");
	this.shape.setTransform(3.3,3.3,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("Ag0A0QgWgWABgeQgBgdAWgXQAXgVAdAAQAeAAAXAVQAWAXgBAdQABAegWAWQgXAXgegBQgdABgXgXg");
	this.shape_1.setTransform(3.3,3.3,0.444,0.444);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,6.7);


(lib.Symbol1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AArAAIhUAA");
	this.shape.setTransform(33.9,63.3,0.444,0.444);

	this.text = new cjs.Text("X", "30px Verdana");
	this.text.lineHeight = 36;
	this.text.setTransform(412.3,250,0.444,0.444);

	this.text_1 = new cjs.Text("Y", "30px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(31.6,0,0.444,0.444);

	this.text_2 = new cjs.Text("0", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(23.4,242.2,0.444,0.444);

	this.text_3 = new cjs.Text(" 3", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(16.3,58.5,0.444,0.444);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAqAAIhTAA");
	this.shape_1.setTransform(33.7,127.5,0.444,0.444);

	this.text_4 = new cjs.Text(" 2", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(16.3,122.8,0.444,0.444);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AA2AAIhrAA");
	this.shape_2.setTransform(34.6,192.2,0.444,0.444);

	this.text_5 = new cjs.Text(" 1", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(17.2,187.5,0.444,0.444);

	this.text_6 = new cjs.Text("3", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(226.3,264.5,0.444,0.444);

	this.text_7 = new cjs.Text("2", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(160.6,264.3,0.444,0.444);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_3.setTransform(229.8,260.4,0.444,0.444);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABa");
	this.shape_4.setTransform(164.9,259.8,0.444,0.444);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_5.setTransform(100.5,260.9,0.444,0.444);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_6.setTransform(359.7,260.4,0.444,0.444);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_7.setTransform(294.6,260.5,0.444,0.444);

	this.text_8 = new cjs.Text("5", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(356.3,264.3,0.444,0.444);

	this.text_9 = new cjs.Text("4", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(289.8,264.5,0.444,0.444);

	this.text_10 = new cjs.Text("1", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(96.1,265.1,0.444,0.444);

	this.text_11 = new cjs.Text("0", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(40.7,265.1,0.444,0.444);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("AAA1mMAAAArN");
	this.shape_8.setTransform(36.4,159.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,0,0,4).p("A/uAAMA/dAAA");
	this.shape_9.setTransform(203.1,257.8);

	this.addChild(this.shape_9,this.shape_8,this.text_11,this.text_10,this.text_9,this.text_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.text_7,this.text_6,this.text_5,this.shape_2,this.text_4,this.shape_1,this.text_3,this.text_2,this.text_1,this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,421.4,297.5);


(lib.pant_08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 1
	this.text = new cjs.Text("X", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(772,202.4);

	this.text_1 = new cjs.Text("Y", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(573,-35.2);

	this.text_2 = new cjs.Text("y = –2x", "italic bold 20px Verdana", "#009900");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(416.7,88);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape.setTransform(406.5,219.9,0.4,0.4);

	this.text_3 = new cjs.Text("-3", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(397.5,223.6,0.4,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_1.setTransform(464.7,219,0.4,0.4);

	this.text_4 = new cjs.Text("-2", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(455.8,222.9,0.4,0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_2.setTransform(579,277.7,0.4,0.4);

	this.text_5 = new cjs.Text("-1", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(564.2,273.2,0.4,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_3.setTransform(523.1,219.8,0.4,0.4);

	this.text_6 = new cjs.Text("-1", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(514.3,223.6,0.4,0.4);

	this.text_7 = new cjs.Text("2", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(569.6,99.3,0.4,0.4);

	this.text_8 = new cjs.Text("3", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(569.2,40.2,0.4,0.4);

	this.text_9 = new cjs.Text("1", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(569.9,155.8,0.4,0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_4.setTransform(579.3,104.6,0.4,0.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_5.setTransform(579.4,160.7,0.4,0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_6.setTransform(579.3,45.1,0.4,0.4);

	this.text_10 = new cjs.Text("0", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(569.8,202.4,0.4,0.4);

	this.text_11 = new cjs.Text("0", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(584.2,224.1,0.4,0.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_7.setTransform(698.8,219.3,0.4,0.4);

	this.text_12 = new cjs.Text("2", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(694.8,223.8,0.4,0.4);

	this.text_13 = new cjs.Text("3", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(753.3,223.8,0.4,0.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABa");
	this.shape_8.setTransform(756.6,219.7,0.4,0.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_9.setTransform(641.2,220.1,0.4,0.4);

	this.text_14 = new cjs.Text("1", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(637.2,223.8,0.4,0.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAAABIhHApIAAgqIBHgpIBIApIAAAqg");
	this.shape_10.setTransform(581.4,-3.8,0.4,0.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,0,0,4).p("AAAaVMAAAg0q");
	this.shape_11.setTransform(581.4,164.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgqBIIAqhIIgqhGIAqAAIAqBGIgqBIg");
	this.shape_12.setTransform(767.1,217.2,0.4,0.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("A9GAAMA6NAAA");
	this.shape_13.setTransform(581.3,217.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#00A52F").ss(1,0,0,4).p("AtR6fMAajA0/");
	this.shape_14.setTransform(553.8,163.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.text_14},{t:this.shape_9},{t:this.shape_8},{t:this.text_13},{t:this.text_12},{t:this.shape_7},{t:this.text_11},{t:this.text_10},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.shape_3},{t:this.text_5},{t:this.shape_2},{t:this.text_4},{t:this.shape_1},{t:this.text_3},{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},77).wait(1));

	
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,423,353);


(lib.pant_07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 1
	this.text = new cjs.Text("y = 2x", "italic bold 20px Verdana", "#FF0000");
	this.text.lineHeight = 22;
	this.text.setTransform(538.4,15.3);

	this.text_1 = new cjs.Text("X", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(827.8,237.3);

	this.text_2 = new cjs.Text("Y", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(512.3,-35.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape.setTransform(518.3,318.3,0.453,0.453);

	this.text_3 = new cjs.Text("-1", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(501.4,313.4,0.453,0.453);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_1.setTransform(457.3,256.8,0.453,0.453);

	this.text_4 = new cjs.Text("-1", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(447.2,261.2,0.453,0.453);

	this.text_5 = new cjs.Text("2", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(507.4,120,0.453,0.453);

	this.text_6 = new cjs.Text("3", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(506.9,56.8,0.453,0.453);

	this.text_7 = new cjs.Text("1", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(508,183.6,0.453,0.453);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_2.setTransform(518.6,126.3,0.453,0.453);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_3.setTransform(518.7,189.9,0.453,0.453);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_4.setTransform(518.6,62.2,0.453,0.453);

	this.text_8 = new cjs.Text("0", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(507.7,237.3,0.453,0.453);

	this.text_9 = new cjs.Text("0", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(524,261.6,0.453,0.453);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_5.setTransform(648.4,256.2,0.453,0.453);

	this.text_10 = new cjs.Text("2", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(643.8,261.4,0.453,0.453);

	this.text_11 = new cjs.Text("3", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(708.8,261.4,0.453,0.453);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_6.setTransform(713,256.7,0.453,0.453);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_7.setTransform(585.9,257.1,0.453,0.453);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_8.setTransform(777.1,256.6,0.453,0.453);

	this.text_12 = new cjs.Text("4", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(772.2,261.2,0.453,0.453);

	this.text_13 = new cjs.Text("1", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(581.1,261.4,0.453,0.453);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAAABIhHApIAAgqIBHgpIBIApIAAAqg");
	this.shape_9.setTransform(520.9,4.7,0.453,0.453);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("AAAb3MAAAg3u");
	this.shape_10.setTransform(520.9,182.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AgqBHIAqhHIgqhHIAqAAIAqBHIgqBHg");
	this.shape_11.setTransform(813.8,253.8,0.453,0.453);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgpBHIAphHIgphHIApAAIAqBHIgqBHg");
	this.shape_12.setTransform(813.8,253.8,0.453,0.453);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("EhF/AAAMCL/AAA");
	this.shape_13.setTransform(611.3,253.8,0.453,0.453);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF0000").ss(1,0,0,4).p("ANU71MganA3r");
	this.shape_14.setTransform(555.9,182.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.text_13},{t:this.text_12},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.text_11},{t:this.text_10},{t:this.shape_5},{t:this.text_9},{t:this.text_8},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_1},{t:this.text_3},{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},77).wait(1));

	// Layer 3
	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,373,361);


(lib.pant_06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 6
	this.text = new cjs.Text("y = 0,5x", "italic bold 20px Verdana", "#009900");
	this.text.lineHeight = 22;
	this.text.setTransform(676,85);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00A52F").ss(1,0,0,4).p("AfOv1Mg+bAfr");
	this.shape.setTransform(598.2,198.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text}]},205).wait(1));

	// Layer 5
	this.text_1 = new cjs.Text("y = x", "italic bold 20px Verdana", "#9933FF");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(628.4,6.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#9907D7").ss(1,0,0,4).p("AZR7sMgyhA3Z");
	this.shape_1.setTransform(572.1,173.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_1}]},165).wait(41));

	// Layer 4
	this.text_2 = new cjs.Text("y = 2x", "italic bold 20px Verdana", "#FF0000");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(529.9,-2.6);

	this.text_3 = new cjs.Text("X", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 17;
	this.text_3.setTransform(808.4,228.4);

	this.text_4 = new cjs.Text("Y", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 17;
	this.text_4.setTransform(498.7,-36.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,0,0,4).p("ANM7mMgaXA3N");
	this.shape_2.setTransform(541.9,174);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.text_4},{t:this.text_3},{t:this.text_2}]},123).wait(83));

	// Layer 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_3.setTransform(504.6,308.7,0.449,0.449);

	this.text_5 = new cjs.Text("-1", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(488.1,303.6,0.449,0.449);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_4.setTransform(444.1,247.8,0.449,0.449);

	this.text_6 = new cjs.Text("-1", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(434,252.2,0.449,0.449);

	this.text_7 = new cjs.Text("2", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(494.2,112,0.449,0.449);

	this.text_8 = new cjs.Text("3", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(493.6,49.3,0.449,0.449);

	this.text_9 = new cjs.Text("1", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(494.2,175.2,0.449,0.449);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_5.setTransform(504.9,118.4,0.449,0.449);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_6.setTransform(505,181.5,0.449,0.449);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_7.setTransform(504.9,54.8,0.449,0.449);

	this.text_10 = new cjs.Text("0", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(494.2,228.4,0.449,0.449);

	this.text_11 = new cjs.Text("0", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(510.4,252.8,0.449,0.449);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_8.setTransform(633.6,247.1,0.449,0.449);

	this.text_12 = new cjs.Text("2", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(629.1,252.5,0.449,0.449);

	this.text_13 = new cjs.Text("3", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(693.7,252.5,0.449,0.449);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_9.setTransform(697.6,247.6,0.449,0.449);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_10.setTransform(571.6,248.1,0.449,0.449);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_11.setTransform(761.2,247.6,0.449,0.449);

	this.text_14 = new cjs.Text("4", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(756.2,252.2,0.449,0.449);

	this.text_15 = new cjs.Text("1", "30px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(567.1,252.5,0.449,0.449);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAAABIhHApIAAgqIBHgpIBIApIAAAqg");
	this.shape_12.setTransform(507.2,-2,0.449,0.449);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,0,0,4).p("AAAboMAAAg3P");
	this.shape_13.setTransform(507.2,174.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgpBHIAphHIgphHIApAAIAqBHIgqBHg");
	this.shape_14.setTransform(797.5,244.8,0.449,0.449);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,0,0,4).p("A/bAAMA+3AAA");
	this.shape_15.setTransform(596.8,244.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.text_15},{t:this.text_14},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.text_13},{t:this.text_12},{t:this.shape_8},{t:this.text_11},{t:this.text_10},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.shape_3}]},123).wait(83));

	// Layer 3
	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,405,369);


(lib.pant_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 3
	this.b1 = new cjs.Text("miab\n", "20px Verdana");
	this.b1.lineHeight = 22;
	this.b1.lineWidth = 353;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.b1}]}).wait(26));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,357,355);


(lib.pant_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 1
	this.text = new cjs.Text("f(x) = mx", "italic 25px Verdana");
	this.text.lineHeight = 27;
	this.text.setTransform(0,64.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},27).wait(51));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,373,361);


(lib.pant_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 1
	this.text = new cjs.Text("y = 0,5 x", "italic 25px Verdana");
	this.text.lineHeight = 27;
	this.text.setTransform(0,117.9);
  var html = createDiv("<i>y</i> = 0,5 <i>x</i>", "Verdana", "25px", '770px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, 117-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},27).wait(51));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,373,361);


(lib.BtnFalse = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
	this.shape.setTransform(310,163.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EgwaAZiMAAAgzDMBg1AAAMAAAAzDg");
	this.shape_1.setTransform(310,163.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);



(lib.pant_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,0,4).p("AAAGqIAAtS");
	this.shape.setTransform(249.6,133.5-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,0,0,4).p("AAAGqIAAtS");
	this.shape_1.setTransform(205.8,133.5-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,0,0,4).p("AAAGqIAAtS");
	this.shape_2.setTransform(149.6,133.5-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,0,0,4).p("AAAGqIAAtS");
	this.shape_3.setTransform(104.6,133.5-incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,0,0,4).p("AAAGqIAAtS");
	this.shape_4.setTransform(49.6,133.5-incremento);

	this.text = new cjs.Text("y", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(17.6,140.6);

	this.text_1 = new cjs.Text("x", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(17.6,97.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,0,0,4).p("AYlGqMgxJAAAIAAmqIAAmoMAxJAAAIAAGogA4kAAMAxJAAA");
	this.shape_5.setTransform(158.2,133.5-incremento);

	this.instance = new lib.Symbol2();
	this.instance.setTransform(486.4,227.9,1,1,0,0,0,3.3,3.3);

	this.text_2 = new cjs.Text("x", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(17.6,97.6);

	this.text_3 = new cjs.Text("1", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(67.5,97.6);

	this.instance_1 = new lib.Symbol3();
	this.instance_1.setTransform(551.7,195.2,1,1,0,0,0,3.3,3.3);

	this.text_4 = new cjs.Text("x", "italic 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(17.6,97.6);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(67.5,97.6);

	this.instance_2 = new lib.Symbol4();
	this.instance_2.setTransform(616.1,163,1,1,0,0,0,3.3,3.3);

	this.text_6 = new cjs.Text("x", "italic 20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(17.6,97.6);

	this.text_7 = new cjs.Text("1", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(67.5,97.6);

	this.instance_3 = new lib.Symbol5();
	this.instance_3.setTransform(681.1,130.8,1,1,0,0,0,3.4,3.3);

	this.text_8 = new cjs.Text("x", "italic 20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(17.6,97.6);

	this.text_9 = new cjs.Text("1", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(67.5,97.6);

	this.instance_4 = new lib.Symbol6();
	this.instance_4.setTransform(746,98.2,1,1,0,0,0,3.3,3.3);

	this.text_10 = new cjs.Text("x", "italic 20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(17.6,97.6);

	this.text_11 = new cjs.Text("1", "20px Verdana");
	this.text_11.lineHeight = 22;
	this.text_11.setTransform(67.5,97.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.text_1,p:{y:97.6,text:"x",x:17.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text,p:{x:17.6,text:"y",font:"italic 20px Verdana",lineWidth:12}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},27).to({state:[{t:this.shape_5},{t:this.text_3,p:{x:67.5,text:"1",y:97.6,font:"20px Verdana",lineWidth:13}},{t:this.text_2,p:{y:97.6,text:"x",x:17.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text_1,p:{y:140.6,text:"y",x:17.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text,p:{x:57.5,text:"0,5",font:"20px Verdana",lineWidth:33}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]},23).to({state:[{t:this.shape_5},{t:this.text_5,p:{x:67.5,text:"1",y:97.6,font:"20px Verdana",lineWidth:13}},{t:this.text_4,p:{x:17.6,text:"x",font:"italic 20px Verdana",lineWidth:12,y:97.6}},{t:this.text_3,p:{x:117.8,text:"2",y:97.6,font:"20px Verdana",lineWidth:13}},{t:this.text_2,p:{y:140.6,text:"y",x:17.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text_1,p:{y:140.6,text:"0,5",x:57.5,font:"20px Verdana",lineWidth:33}},{t:this.text,p:{x:117.8,text:"1",font:"20px Verdana",lineWidth:13}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.instance_1}]},30).to({state:[{t:this.shape_5},{t:this.text_7,p:{x:67.5,text:"1"}},{t:this.text_6,p:{x:17.6,text:"x",font:"italic 20px Verdana",lineWidth:12}},{t:this.text_5,p:{x:117.8,text:"2",y:97.6,font:"20px Verdana",lineWidth:13}},{t:this.text_4,p:{x:168.1,text:"3",font:"20px Verdana",lineWidth:13,y:97.6}},{t:this.text_3,p:{x:17.6,text:"y",y:140.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text_2,p:{y:140.6,text:"1,5",x:158.1,font:"20px Verdana",lineWidth:33}},{t:this.text_1,p:{y:140.6,text:"0,5",x:57.5,font:"20px Verdana",lineWidth:33}},{t:this.text,p:{x:117.8,text:"1",font:"20px Verdana",lineWidth:13}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.instance_1},{t:this.instance_2}]},31).to({state:[{t:this.shape_5},{t:this.text_9,p:{x:67.5,text:"1"}},{t:this.text_8,p:{x:17.6,text:"x",font:"italic 20px Verdana",lineWidth:12}},{t:this.text_7,p:{x:117.8,text:"2"}},{t:this.text_6,p:{x:168.1,text:"3",font:"20px Verdana",lineWidth:13}},{t:this.text_5,p:{x:218.4,text:"4",y:97.6,font:"20px Verdana",lineWidth:13}},{t:this.text_4,p:{x:17.6,text:"y",font:"italic 20px Verdana",lineWidth:12,y:140.6}},{t:this.text_3,p:{x:158.1,text:"1,5",y:140.6,font:"20px Verdana",lineWidth:33}},{t:this.text_2,p:{y:140.6,text:"0,5",x:57.5,font:"20px Verdana",lineWidth:33}},{t:this.text_1,p:{y:140.6,text:"1",x:117.8,font:"20px Verdana",lineWidth:13}},{t:this.text,p:{x:218.4,text:"2",font:"20px Verdana",lineWidth:13}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3}]},33).to({state:[{t:this.shape_5},{t:this.text_11},{t:this.text_10},{t:this.text_9,p:{x:117.8,text:"2"}},{t:this.text_8,p:{x:268.7,text:"5",font:"20px Verdana",lineWidth:13}},{t:this.text_7,p:{x:168.1,text:"3"}},{t:this.text_6,p:{x:218.4,text:"4",font:"20px Verdana",lineWidth:13}},{t:this.text_5,p:{x:17.6,text:"y",y:140.6,font:"italic 20px Verdana",lineWidth:12}},{t:this.text_4,p:{x:158.1,text:"1,5",font:"20px Verdana",lineWidth:33,y:140.6}},{t:this.text_3,p:{x:57.5,text:"0,5",y:140.6,font:"20px Verdana",lineWidth:33}},{t:this.text_2,p:{y:140.6,text:"1",x:117.8,font:"20px Verdana",lineWidth:13}},{t:this.text_1,p:{y:140.6,text:"2",x:218.4,font:"20px Verdana",lineWidth:13}},{t:this.text,p:{x:258.7,text:"2,5",font:"20px Verdana",lineWidth:33}},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.instance_1},{t:this.instance_2},{t:this.instance_3},{t:this.instance_4}]},33).wait(50));

	// Layer 6
	this.instance_5 = new lib.Symbol7();
	this.instance_5.setTransform(588.6,177,1,1,0,0,0,202.8,102.3);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(206).to({_off:false},0).wait(21));

	
	// Layer 3
	this.instance_6 = new lib.Symbol1();
	this.instance_6.setTransform(595.6,152.2,1,1,0,0,0,209.6,149.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).wait(227));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,807.4,377.9);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}