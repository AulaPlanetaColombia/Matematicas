Generador = new function()
{
	this.nOp;
	this.lEnunciadosParseados;
	this.lRespuestasSPRITE;
	this.lPreguntasSPRITE;
	this.lRespuestasOK;
	this.qAlternativas=4;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
		
	this.lVariaciones=new Array();
	
	this.lPregSPR = new Array();
	this.lRespNUM = new Array();
	this.lRespSTR = new Array();
	
	this.ea ="";
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=[1];
	
	this.bModoPLAY=true;

	this.generarSerie = function(semilla)
	{
		EA._formatoBase=["Arial",26,"#000000",false];
		Random.init(semilla,100);
		
		for (var numOp=0;numOp<Motor.qOperaciones;numOp++) {
			var indice=numOp % this.lTiposVariaciones.length;
			this.lVariaciones[numOp]=this.lTiposVariaciones[indice];
		}
		for (this.nOp=0;this.nOp<Motor.qOperaciones;this.nOp++) {

			this.enunciar();			
			
			Motor.lOperaciones[this.nOp]=new Object();
			Motor.lOperaciones[this.nOp].pregSPR=this.lPregSPR[this.nOp]
			Motor.lOperaciones[this.nOp].respNum=this.lRespNUM[this.nOp];
			Motor.lOperaciones[this.nOp].respuestaString=this.lRespSTR[this.nOp]
			Motor.lOperaciones[this.nOp].entrada="";
			Motor.lOperaciones[this.nOp].estaListo=false;
			Motor.lOperaciones[this.nOp].correcto=false;
			Motor.lOperaciones[this.nOp].formula=this.ea;
			
		}

	}
	
	this.enunciar = function()
	{
			
		while(true){
            var xA = Random.integer(-7,7);
            var yA = Random.integer(-7,7);
            var xB = Random.integer(-7,7);
            var yB = Random.integer(-7,7);
            if((xA!=xB)&&(yA!=yB)&&(Math.abs(xA-xB)<10)&&(Math.abs(yA-yB)<10)){
                break;
            }
        }
			
		var m = (yB-yA)/(xB-xA);
        var n = (yA*xB-xA*yB)/(xB-xA);
        var mFraccion = JL.simplificar([yB-yA,xB-xA]);
        
        var nFraccion = JL.simplificar([yA*xB-xA*yB,xB-xA]);
        
        var lCoefs = JL.getEqG_2P([xA,yA],[xB,yB]);
        
        var A = lCoefs[0];
        var B = lCoefs[1];
        var C = lCoefs[2];
        var vx = xB-xA;
        var vy = yB-yA;
        //monta el plano y la recta:
        PlanoXY.PlanoXY([400,400],30,[200,200]);
		PlanoXY.plot('pol',[n,m],"#0000ff");	
		var variacion = 1;

		switch(variacion){
		   case 1://punto-pendiente:
		      var azar = Random.integer(0,2);
		      switch(azar){
		          case 0://k es yA
		              this.ea=EA.ini(JL.cursiva('y')+' '+String.fromCharCode(8722)+' '+JL.cursiva('k')+' = ');
		          
		              if(m==Math.floor(m)){
                            //this.ea=EA.ini(JL.cursiva('y')+' '+String.fromCharCode(8722)+'k'+' = '+JL.num2str(m)+'('+JL.cursiva('x')+' '+JL.num2str(-xA,0,true)+')');
                            EA.adcStatic(JL.num2str(m),this.ea);
                            if(xA>0){
                                EA.adcStatic('('+JL.cursiva('x')+' '+String.fromCharCode(8722)+' '+JL.num2str(Math.abs(xA))+')',this.ea);
                            }else if(xA<0){
                                EA.adcStatic('('+JL.cursiva('x')+' + '+JL.num2str(Math.abs(xA))+')',this.ea);
                            }else{
                                EA.adcStatic(JL.cursiva('x'),this.ea);
                            }
                        }else{
//                          ea=EA.ini('y-k=');
                            //this.ea=EA.ini(JL.cursiva('y')+' '+String.fromCharCode(8722)+' '+JL.cursiva('k')+' = ');
                            EA.adfStatic(EA.fra(JL.num2str(mFraccion[0]),JL.num2str(mFraccion[1])),this.ea);
                            EA.adcStatic(' ',this.ea, null, 10);
                            if(xA>0){
                                EA.adcStatic('('+JL.cursiva('x')+' '+String.fromCharCode(8722)+' '+JL.num2str(Math.abs(xA))+')',this.ea, null, 10);
                            }else if(xA<0){
                                EA.adcStatic('('+JL.cursiva('x')+' + '+JL.num2str(Math.abs(xA))+')',this.ea, null, 10);
                            }else{
                                //EA.adcStatic('('+JL.cursiva('x')+' '+String.fromCharCode(8722)+' 0)',this.ea, null, 10);
                                EA.adcStatic(JL.cursiva('x'),this.ea, null, 10);
                            }
                        }
                        this.lRespNUM[this.nOp]=yA;
		          break;
		          case 1://k es la m (entera ó fracción)
		              this.ea=EA.ini(JL.cursiva('y')+' ');
		              if(yA>0){
                            EA.adcStatic(String.fromCharCode(8722)+' '+JL.num2str(Math.abs(yA)), this.ea, null, 10);
                        }else if(yA<0){
                            EA.adcStatic('+ '+JL.num2str(Math.abs(yA)), this.ea, null, 10);
                        }else{
                            EA.adcStatic(String.fromCharCode(8722)+' 0', this.ea, null, 10);
                        }
                        EA.adcStatic(' = ',this.ea);
                        if(m==Math.floor(m)){
//                          EA.adc('k(x',ea);
                            EA.adcStatic(JL.cursiva('k')+'('+JL.cursiva('x')+' ',this.ea, null, 10);
                            this.lRespNUM[this.nOp]=m;
                        }else{
                            if(Random.integer(0,1)==0){
                                //k es el numerador:
                                EA.adfStatic(EA.fra(JL.cursiva('k'),JL.num2str(mFraccion[1])),this.ea);
                                EA.adcStatic(' ',this.ea, null, 10);
                                EA.adcStatic('('+JL.cursiva('x')+' ',this.ea, null, 10);
                                this.lRespNUM[this.nOp]=mFraccion[0];
                            }else{
                                //k es el denominador:
                                EA.adfStatic(EA.fra(JL.num2str(mFraccion[0]),JL.cursiva('k')),this.ea);
                                EA.adcStatic(' ',this.ea, null, 10);
                                EA.adcStatic('('+JL.cursiva('x')+' ',this.ea, null, 10);
                                this.lRespNUM[this.nOp]=mFraccion[1];
                            }
                        }
                        if(xA>0){
                            EA.adcStatic(String.fromCharCode(8722)+' '+JL.num2str(Math.abs(xA))+')',this.ea, null, 10);
                        }else if(xA<0){
                            EA.adcStatic('+ '+JL.num2str(Math.abs(xA))+')',this.ea, null, 10);
                        }else{
                            EA.adcStatic(String.fromCharCode(8722)+' 0)',this.ea, null, 10);
                        }
		          break;
		          case 2://k es xA
                        this.ea=EA.ini(JL.cursiva('y')+' ');
                        if(yA>0){
                            EA.adcStatic(String.fromCharCode(8722)+' '+JL.num2str(Math.abs(yA)),this.ea, null, 10);
                        }else if(yA<0){
                            EA.adcStatic('+ '+JL.num2str(Math.abs(yA)),this.ea);
                        }else{
                            //EA.adcStatic(String.fromCharCode(8722)+' 0',this.ea);
                        }
                        EA.adcStatic(' = ',this.ea);
                        if(m==Math.floor(m)){
                            EA.adcStatic(JL.num2str(m),this.ea, null, 10);
                        }else{
                            EA.adfStatic(EA.fra(JL.num2str(mFraccion[0]),JL.num2str(mFraccion[1])),this.ea);
                            EA.adcStatic(' ',this.ea, null, 10);
                        }
                        EA.adcStatic('('+JL.cursiva('x')+' '+String.fromCharCode(8722)+' '+JL.cursiva('k')+')',this.ea, null, 10);
                        this.lRespNUM[this.nOp]=xA;
                        break;    
		      }
		   break;
		}	
		//this.ea.x=500;this.ea.y=170;
		this.ea.x=500;this.ea.y=60;
        //co_formules.addChild(ea);
        //monta los arrays:
        this.lPregSPR[this.nOp]=PlanoXY.contenedor;
        this.lRespSTR[this.nOp]=this.lRespNUM[this.nOp].toString();
			
			
			

		/*	
			PlanoXY.PlanoXY([400,400],40,[200,200]);

			//decide los coefs (de y = a/(x+-b) ):
			var numer = Random.integer(-6,6,[0]);
			var denom = Random.integer(-6,6);
			var C = Random.integer(-6,6);
			//trace(numer,denom,C);
			//dibuja la curva:
			PlanoXY.plot('rac',[[numer+C*denom,C],[denom,1]],"#0000ff");
			//escribe la expresión, decidiendo cuál es la letra 'k':
			this.ea=EA.ini(JL.cursiva('f ')+'('+JL.cursiva('x')+')= ');
	//		var ea=EA.ini('f(x)=');
			switch(Random.integer(0,2)){
				case 0://numer como 'k':
					console.log(EA.pol2([denom,1],'x',true,true));
					EA.adfStatic(EA.fra(JL.cursiva('k'),EA.pol2([denom,1],'x',true,true)),this.ea);
					if(C>0){
						EA.adcStatic(' + '+Math.abs(C).toString(),this.ea);
					}else if(C<0){
						EA.adcStatic(' '+String.fromCharCode(8722)+' '+Math.abs(C).toString(),this.ea);
					}
					var sol=numer;
					break;
				case 1://denom como 'k':
	//				EA.adf(EA.fra(String(numer),'x+k'),ea);
					EA.adfStatic(EA.fra(JL.num2str(numer),JL.cursiva('x')+' + '+JL.cursiva('k')),this.ea);
					if(C>0){
						EA.adcStatic(' + '+Math.abs(C).toString(),this.ea);
					}else if(C<0){
						EA.adcStatic(' '+String.fromCharCode(8722)+' '+Math.abs(C).toString(),this.ea);
					}
					sol=denom;
					break;
				case 2://C como 'k':
					sol=C;
					EA.adfStatic(EA.fra(JL.num2str(numer),EA.pol2([denom,1],'x',true,true)),this.ea);
					EA.adcStatic(' + '+JL.cursiva('k'),this.ea);
					break;
			}
			
			this.ea.x=500; this.ea.y=50;
			//monta los arrays:
			this.lPregSPR[this.nOp] = PlanoXY.contenedor;
			this.lRespNUM[this.nOp] = sol;
			this.lRespSTR[this.nOp] = sol.toString();
	*/
	}
	this.getAlternativas = function(nok,qDec,qAlt,lMinMax,lConcretos){
		//SI lConcretos NO ES null, APLICA EL CRITERIO DE VALORES CONCRETOS (HA DE HABER SUFICIENTES!!!)
		//SI lConcretos ES null PERO lMinMax NO ES NULL, APLICA EL CRITERIO DE RANGO ENTRE MÍN Y MÁX
		//SI AMBOS ARRAYS SON null APLICA EL CRITERIO ABIERTO DE RANGO EQUILIBRADO
		lMinMax =  lMinMax || null;
		lConcretos =  lConcretos || null;
		
		var margenREL=nok*0.05;
		var potencia=Math.pow(10,qDec);
		while(true){
			var lWork=[nok];
			if(lConcretos!=null){
				lWork.shift();
				var lResp=new Array();
				while(lResp.length<3){
					var ind=Random.integer(0,lConcretos.length-1);
					var v=lConcretos[ind];
					if(v!=nok){
						lResp.push(JL.num2str(v));
						lConcretos.splice(ind,1);
					}
				}
				var sOK=JL.num2str(nok);
				var indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}else if(lMinMax!=null){
				for(var i=0;i<3;i++){
					np=Random.float(lMinMax[0],lMinMax[1]);
					np=Math.round(np*potencia)/potencia;
					lWork.push(np);
				}
			}else{
				for(i=0;i<3;i++){
					var desv=nok*Random.float(0.05,0.6);
					//console.log("desv: "+desv);
					var np=nok+desv*Random.sign();
					np=Math.round(np*potencia)/potencia;
					
					lWork.push(np);
				}
				
				//console.log(lWork);
			}
			var bCercanos=false;
			for(var j=0;j<qAlt;j++){
				for(var k=j+1;k<qAlt+1;k++){
					//console.log(lWork[j]+" - "+lWork[k]);
					if(Math.abs(lWork[j]-lWork[k])<margenREL){
						bCercanos=true;
						break;
					}
				}
			}
			
			//console.log(lWork);
			
			if(!bCercanos){
				lWork.shift();
				lResp=new Array();
				for(var n in lWork){
					//console.log("11>"+n);
					//console.log("aa>"+JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
					lResp.push(JL.quitarCerosDec(JL.num2str( lWork[n],qDec)));
				}
				sOK=JL.quitarCerosDec(JL.num2str(Math.round(nok*potencia)/potencia,qDec));
				indOK=Random.integer(0,qAlt);
				lResp.splice(indOK,0,sOK);
				//console.log('indOK:'+indOK);
				return [lResp,indOK];
			}
		}
		return [];
	}

}