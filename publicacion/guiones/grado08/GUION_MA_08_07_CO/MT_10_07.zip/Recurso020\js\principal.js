(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);
this.txt_00_03 = new cjs.Text("Eje de simetria", "bold 16px Verdana", "#993399");
	this.txt_00_03.textAlign = "right";
	this.txt_00_03.lineHeight = 20;
	this.txt_00_03.lineWidth = 192;
	this.txt_00_03.setTransform(623.5,442.7);

	this.txt_00_01 = new cjs.Text("Ramas de la parábola", "bold 16px Verdana", "#003399");
	this.txt_00_01.textAlign = "center";
	this.txt_00_01.lineHeight = 20;
	this.txt_00_01.lineWidth = 240;
	this.txt_00_01.setTransform(685.2,169.7);

	this.txt_00_02 = new cjs.Text("Vértice", "bold 16px Verdana", "#009900");
	this.txt_00_02.lineHeight = 20;
	this.txt_00_02.lineWidth = 102;
	this.txt_00_02.setTransform(771.9,327.5);

	

	this.instance_1 = new lib.Imagen_00();
	this.instance_1.setTransform(818.4,417.1,0.456,0.456,0,0,0,476.9,386.4);

	
	this.btn_04 = new lib.boton_04();
	this.btn_04.setTransform(228.4,461.5,1,1,0,0,0,98.5,18);
	new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.boton_04(), 3);

	this.btn_03 = new lib.boton_03();
	this.btn_03.setTransform(227.6,381.5,1,1,0,0,0,98.5,18);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.boton_03(), 3);

	this.btn_02 = new lib.boton_02();
	this.btn_02.setTransform(228.4,301.5,1,1,0,0,0,98.5,18);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.boton_02(), 3);

	this.txt_boto_01 = new cjs.Text("¿Sabes...?", "bold 16px Arial");
	this.txt_boto_01.textAlign = "center";
	this.txt_boto_01.lineHeight = 18;
	this.txt_boto_01.lineWidth = 187;
	this.txt_boto_01.setTransform(225.5,211.2+incremento);

	this.mc_01 = new lib.CdP_Practica();
	this.mc_01.setTransform(227.6,221.5,1.516,1.2,0,0,0,65,15);
new cjs.ButtonHelper(this.mc_01, 0, 1, 2, false, new lib.CdP_Practica(), 3);


        this.mc_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });

  this.btn_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
          this.btn_03.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
          this.btn_04.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        
        this.addChild(this.logo, this.titulo,this.mc_01,this.txt_boto_01,this.btn_02,this.btn_03,this.btn_04,this.btn_01,this.instance_1,this.txt_00_02,this.txt_00_01,this.txt_00_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['txt_01_01']);

this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AiQAAQAAg7AqgrQArgqA7AAQA8AAArAqQArArAAA7QAAA8grArQgrAqg8AAQg7AAgrgqQgqgrAAg8g");
	this.shape.setTransform(542.6,169.6);

	this.text = new cjs.Text("B", "20px Verdana");
	this.text.lineHeight = 24;
	this.text.setTransform(535,155.9+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AiQAAQAAg7AqgrQArgqA7AAQA8AAArAqQArArAAA7QAAA8grArQgrAqg8AAQg7AAgrgqQgqgrAAg8g");
	this.shape_1.setTransform(82.6,169.6);

	this.text_1 = new cjs.Text("A", "20px Verdana");
	this.text_1.lineHeight = 24;
	this.text_1.setTransform(75,155.9+incremento);

	this.instance_1 = new lib.Imagen_01_02();
	this.instance_1.setTransform(703.3,355.4,0.821,0.821,0,0,0,164.5,177);

	this.instance_2 = new lib.Imagen_01_01();
	this.instance_2.setTransform(257.5,360,1,1,0,0,0,164.5,177);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_2,this.instance_1,this.text_1,this.shape_1,this.text,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
this.instance_1 = new lib.textoAnimado_01();
	this.instance_1.setTransform(474.4,323.6,1,1,0,0,0,393.4,194.7);
        texto(this,txt['txt_01_02'],0,0);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
          var html = createDiv(txt['txt_01_03'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -222);

this.instance_1 = new lib.Imagen_01_02();
	this.instance_1.setTransform(663.4,254.9,0.447,0.447,0,0,0,164.6,177.1);

	this.instance_2 = new lib.Imagen_01_01();
	this.instance_2.setTransform(273.9,258,0.534,0.534,0,0,0,164.5,176.9);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   
 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['txt_02_01']);
        
	this.instance_1 = new lib.Imagen_01_01();
	this.instance_1.setTransform(475.1,338,1,1,0,0,0,164.6,168.5);

        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
this.instance_1 = new lib.Imagen_01_01();
	this.instance_1.setTransform(695.1,338,1,1,0,0,0,164.6,168.5);

        texto(this,txt['txt_02_02'],0,350);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_02_03'],0,350);
	this.instance_1 = new lib.tabla_01_MC();
	this.instance_1.setTransform(278,357.5,1,1,0,0,0,198,53.5);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_02_04'],0,350);
	this.instance_1 = new lib.GraficoAnimado_01();
	this.instance_1.setTransform(463.9,310.8,1,1,0,0,0,383.9,162.6);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
                texto(this,txt['txt_02_05'],0,350);
	this.instance_1 = new lib.GraficoAnimado_01("synched",212);
	this.instance_1.setTransform(463.9,310.8,1,1,0,0,0,383.9,162.6);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['txt_03_01']);
        
	this.instance_1 = new lib.Imagen_01_02();
	this.instance_1.setTransform(475.1,338,1,1,0,0,0,164.6,168.5);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        

	this.instance_1 = new lib.Imagen_01_02();
	this.instance_1.setTransform(695.1,338,1,1,0,0,0,164.6,168.5);
        texto(this,txt['txt_03_02'],0,350);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_03_03'],0,350);
	this.instance_1 = new lib.tabla_02_MC();
	this.instance_1.setTransform(278,357.5,1,1,0,0,0,198,53.5);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_03_04'],0,350);
	this.instance_1 = new lib.GraficoAnimado_02();
	this.instance_1.setTransform(463.9,310.8,1,1,0,0,0,383.9,162.6);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
                texto(this,txt['txt_03_05'],0,350);
	this.instance_1 = new lib.GraficoAnimado_02("synched",196);
	this.instance_1.setTransform(463.9,310.8,1,1,0,0,0,383.9,162.6);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['txt_04_01']);
        
	this.instance_1 = new lib.fondo();
	this.instance_1.setTransform(160.1,137.3,0.489,0.489);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this,txt['txt_04_02'],0,0,-510);

	this.instance_1 = new lib.Imagen_04_06();
	this.instance_1.setTransform(740.4,429,0.2,0.2,0,0,0,0.8,0);

	this.instance_2 = new lib.Imagen_04_03();
	this.instance_2.setTransform(740.4,249,0.2,0.2,0,0,0,0.8,0);

	this.instance_3 = new lib.Imagen_04_05();
	this.instance_3.setTransform(476.4,429,0.2,0.2,0,0,0,0.8,0);

	this.instance_4 = new lib.Imagen_04_02();
	this.instance_4.setTransform(476.4,249,0.2,0.2,0,0,0,0.8,0);

	this.instance_5 = new lib.Imagen_04_04();
	this.instance_5.setTransform(210.4,429,0.2,0.2,0,0,0,0.8,0);

	this.instance_6 = new lib.Imagen_04_01();
	this.instance_6.setTransform(210.4,249,0.2,0.2,0,0,0,0.8,0);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.texto, this.home, this.anterior, this.siguiente,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_04_03'],0,350);
	this.instance_1 = new lib.GraficoAnimado_03();
	this.instance_1.setTransform(660.4,330.8,1,1,0,0,0,245.5,200.4);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
                texto(this,txt['txt_04_04'],0,350);
	this.instance_1 = new lib.GraficoAnimado_04();
	this.instance_1.setTransform(692.4,336.8,0.527,0.527,0,0,0,-0.5,0.7);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
       this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.siguiente,this.instance_2,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame4_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
                texto(this,txt['txt_04_05'],0,350);
	this.grafico = new lib.graficoAnimado_05();
	this.grafico.setTransform(689.3,341.1,0.523,0.523,0,0,0,-0.4,1.1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
      this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_6());
        });
     
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.anterior, this.informacion,this.grafico);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
                texto(this,txt['txt_info_01'],0,350);
	this.instance_1 = new lib.IMG_info_01();
	this.instance_1.setTransform(685.6,315.1,1,1,0,0,0,0.1,0);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
     
      

        this.addChild(this.logo, this.titulo, this.home,this.texto, this.cerrar, this.informacion,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib.fondo = function() {
	this.initialize(img.fondo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1289,800);


(lib.MTB_10_07_052 = function() {
	this.initialize(img.MTB_10_07_052);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);



(lib.tabla_02_MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("AmEBKIAAiUIMKAAIAACUg");
	var mask_graphics_22 = new cjs.Graphics().p("AmECLIAAkVIMKAAIAAEVg");
	var mask_graphics_23 = new cjs.Graphics().p("AmEDMIAAmXIMKAAIAAGXg");
	var mask_graphics_24 = new cjs.Graphics().p("AmEEMIAAoXIMKAAIAAIXg");
	var mask_graphics_25 = new cjs.Graphics().p("AmEFMIAAqYIMKAAIAAKYg");
	var mask_graphics_26 = new cjs.Graphics().p("AmEGNIAAsZIMKAAIAAMZg");
	var mask_graphics_27 = new cjs.Graphics().p("AmEHNIAAuaIMKAAIAAOag");
	var mask_graphics_28 = new cjs.Graphics().p("AmEIOIAAwbIMKAAIAAQbg");
	var mask_graphics_29 = new cjs.Graphics().p("AmEJPIAAydIMKAAIAASdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmEKPIAA0dIMKAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmELPIAA2eIMKAAIAAWeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:29,y:-15.4}).wait(1).to({graphics:mask_graphics_22,x:29,y:-9}).wait(1).to({graphics:mask_graphics_23,x:29,y:-2.5}).wait(1).to({graphics:mask_graphics_24,x:29,y:3.9}).wait(1).to({graphics:mask_graphics_25,x:29,y:10.3}).wait(1).to({graphics:mask_graphics_26,x:29,y:16.8}).wait(1).to({graphics:mask_graphics_27,x:29,y:23.2}).wait(1).to({graphics:mask_graphics_28,x:29,y:29.7}).wait(1).to({graphics:mask_graphics_29,x:29,y:36.1}).wait(1).to({graphics:mask_graphics_30,x:29,y:42.6}).wait(1).to({graphics:mask_graphics_31,x:29,y:49}).wait(1).to({graphics:null,x:0,y:0}).wait(79));

	// Capa 6
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(31,62.9);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(31,12.9);

	this.text.mask = this.text_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},21).wait(90));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_32 = new cjs.Graphics().p("Ak5AsIAAhYIJzAAIAABYg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ak5B2IAAjrIJzAAIAADrg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Ak5C/IAAl9IJzAAIAAF9g");
	var mask_1_graphics_35 = new cjs.Graphics().p("Ak5EIIAAoPIJzAAIAAIPg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Ak5FRIAAqhIJzAAIAAKhg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ak5GaIAAszIJzAAIAAMzg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ak5HjIAAvFIJzAAIAAPFg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Ak5IsIAAxXIJzAAIAARXg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AAZJ1IAAzqIJ1AAIAATqg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(32).to({graphics:mask_1_graphics_32,x:99.5,y:-10.4}).wait(1).to({graphics:mask_1_graphics_33,x:99.5,y:-3.1}).wait(1).to({graphics:mask_1_graphics_34,x:99.5,y:4.1}).wait(1).to({graphics:mask_1_graphics_35,x:99.5,y:11.4}).wait(1).to({graphics:mask_1_graphics_36,x:99.5,y:18.8}).wait(1).to({graphics:mask_1_graphics_37,x:99.5,y:26.1}).wait(1).to({graphics:mask_1_graphics_38,x:99.5,y:33.4}).wait(1).to({graphics:mask_1_graphics_39,x:99.5,y:40.7}).wait(1).to({graphics:mask_1_graphics_40,x:65.5,y:48}).wait(1).to({graphics:null,x:0,y:0}).wait(70));

	// Capa 5
	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(97,66.9);

	this.text_3 = new cjs.Text("0", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,12.9);

	this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.text_2}]},32).wait(79));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_43 = new cjs.Graphics().p("AkrAnIAAhNIJWAAIAABNg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AkrBpIAAjRIJWAAIAADRg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AkrCrIAAlVIJWAAIAAFVg");
	var mask_2_graphics_46 = new cjs.Graphics().p("AkrDsIAAnXIJWAAIAAHXg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AkrEuIAApbIJWAAIAAJbg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AkrFwIAArfIJWAAIAALfg");
	var mask_2_graphics_49 = new cjs.Graphics().p("AkrGxIAAthIJWAAIAANhg");
	var mask_2_graphics_50 = new cjs.Graphics().p("AkrHzIAAvlIJWAAIAAPlg");
	var mask_2_graphics_51 = new cjs.Graphics().p("AF2I1IAAxpIJYAAIAARpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(43).to({graphics:mask_2_graphics_43,x:165,y:-8.9}).wait(1).to({graphics:mask_2_graphics_44,x:165,y:-2.3}).wait(1).to({graphics:mask_2_graphics_45,x:165,y:4.1}).wait(1).to({graphics:mask_2_graphics_46,x:165,y:10.7}).wait(1).to({graphics:mask_2_graphics_47,x:165,y:17.3}).wait(1).to({graphics:mask_2_graphics_48,x:165,y:23.8}).wait(1).to({graphics:mask_2_graphics_49,x:165,y:30.4}).wait(1).to({graphics:mask_2_graphics_50,x:165,y:37}).wait(1).to({graphics:mask_2_graphics_51,x:97.5,y:43.5}).wait(60));

	// Capa 4
	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,66.9);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(163,12.9);

	this.text_4.mask = this.text_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_5},{t:this.text_4}]},43).wait(68));

	// Capa 12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_54 = new cjs.Graphics().p("AlHA3IAAhsIKPAAIAABsg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AlHCDIAAkFIKPAAIAAEFg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AlHDPIAAmdIKPAAIAAGdg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AlHEcIAAo3IKPAAIAAI3g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AlHFoIAArPIKPAAIAALPg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AlHG1IAAtpIKPAAIAANpg");
	var mask_3_graphics_60 = new cjs.Graphics().p("AlHIBIAAwBIKPAAIAAQBg");
	var mask_3_graphics_61 = new cjs.Graphics().p("AKaJOIAAyaIKRAAIAASag");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_3_graphics_54,x:231.8,y:-5.4}).wait(1).to({graphics:mask_3_graphics_55,x:231.8,y:2.1}).wait(1).to({graphics:mask_3_graphics_56,x:231.8,y:9.8}).wait(1).to({graphics:mask_3_graphics_57,x:231.8,y:17.4}).wait(1).to({graphics:mask_3_graphics_58,x:231.8,y:25.1}).wait(1).to({graphics:mask_3_graphics_59,x:231.8,y:32.7}).wait(1).to({graphics:mask_3_graphics_60,x:231.8,y:40.4}).wait(1).to({graphics:mask_3_graphics_61,x:132.3,y:48}).wait(50));

	// Capa 3
	this.text_6 = new cjs.Text("–2", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(229,66.9);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(229,12.9);

	this.text_6.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.text_6}]},54).wait(57));

	// Capa 13 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_64 = new cjs.Graphics().p("Ak+A8IAAh3IJ+AAIAAB3g");
	var mask_4_graphics_65 = new cjs.Graphics().p("Ak+CQIAAkfIJ+AAIAAEfg");
	var mask_4_graphics_66 = new cjs.Graphics().p("Ak+DkIAAnHIJ+AAIAAHHg");
	var mask_4_graphics_67 = new cjs.Graphics().p("Ak+E4IAApvIJ+AAIAAJvg");
	var mask_4_graphics_68 = new cjs.Graphics().p("Ak+GNIAAsZIJ+AAIAAMZg");
	var mask_4_graphics_69 = new cjs.Graphics().p("Ak+HhIAAvBIJ+AAIAAPBg");
	var mask_4_graphics_70 = new cjs.Graphics().p("Ak+I1IAAxpIJ+AAIAARpg");
	var mask_4_graphics_71 = new cjs.Graphics().p("APdKJIAA0RIKAAAIAAURg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(64).to({graphics:mask_4_graphics_64,x:294,y:-9.9}).wait(1).to({graphics:mask_4_graphics_65,x:294,y:-1.5}).wait(1).to({graphics:mask_4_graphics_66,x:294,y:6.9}).wait(1).to({graphics:mask_4_graphics_67,x:294,y:15.3}).wait(1).to({graphics:mask_4_graphics_68,x:294,y:23.7}).wait(1).to({graphics:mask_4_graphics_69,x:294,y:32.1}).wait(1).to({graphics:mask_4_graphics_70,x:294,y:40.6}).wait(1).to({graphics:mask_4_graphics_71,x:163,y:49}).wait(40));

	// Capa 2
	this.text_8 = new cjs.Text("–8", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(296,66.9);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(296,12.9);

	this.text_8.mask = this.text_9.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_9},{t:this.text_8}]},64).wait(47));

	// Capa 14 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_75 = new cjs.Graphics().p("AkYA1IAAhpIIxAAIAABpg");
	var mask_5_graphics_76 = new cjs.Graphics().p("AkYCNIAAkZIIxAAIAAEZg");
	var mask_5_graphics_77 = new cjs.Graphics().p("AkYDmIAAnLIIxAAIAAHLg");
	var mask_5_graphics_78 = new cjs.Graphics().p("AkYE/IAAp9IIxAAIAAJ9g");
	var mask_5_graphics_79 = new cjs.Graphics().p("AkYGXIAAstIIxAAIAAMtg");
	var mask_5_graphics_80 = new cjs.Graphics().p("AkYHwIAAvfIIxAAIAAPfg");
	var mask_5_graphics_81 = new cjs.Graphics().p("AVrJJIAAyQII0AAIAASQg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(75).to({graphics:mask_5_graphics_75,x:362.2,y:-4.6}).wait(1).to({graphics:mask_5_graphics_76,x:362.2,y:4.2}).wait(1).to({graphics:mask_5_graphics_77,x:362.2,y:13.1}).wait(1).to({graphics:mask_5_graphics_78,x:362.2,y:21.9}).wait(1).to({graphics:mask_5_graphics_79,x:362.2,y:30.8}).wait(1).to({graphics:mask_5_graphics_80,x:362.2,y:39.6}).wait(1).to({graphics:mask_5_graphics_81,x:195.2,y:48.5}).wait(30));

	// Capa 7
	this.text_10 = new cjs.Text("–8", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(361,66.9);

	this.text_11 = new cjs.Text("–2", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(361,12.9);

	this.text_10.mask = this.text_11.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_11},{t:this.text_10}]},75).wait(36));

	// Capa 8 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_0 = new cjs.Graphics().p("Aj0K8IAA13IHpAAIAAV3g");
	var mask_6_graphics_1 = new cjs.Graphics().p("AlZK8IAA13IKzAAIAAV3g");
	var mask_6_graphics_2 = new cjs.Graphics().p("Am/K8IAA13IN/AAIAAV3g");
	var mask_6_graphics_3 = new cjs.Graphics().p("AokK8IAA13IRJAAIAAV3g");
	var mask_6_graphics_4 = new cjs.Graphics().p("AqKK8IAA13IUVAAIAAV3g");
	var mask_6_graphics_5 = new cjs.Graphics().p("ArwK8IAA13IXhAAIAAV3g");
	var mask_6_graphics_6 = new cjs.Graphics().p("AtVK8IAA13IarAAIAAV3g");
	var mask_6_graphics_7 = new cjs.Graphics().p("Au7K8IAA13Id3AAIAAV3g");
	var mask_6_graphics_8 = new cjs.Graphics().p("AwhK8IAA13MAhDAAAIAAV3g");
	var mask_6_graphics_9 = new cjs.Graphics().p("AyGK8IAA13MAkNAAAIAAV3g");
	var mask_6_graphics_10 = new cjs.Graphics().p("AzsK8IAA13MAnZAAAIAAV3g");
	var mask_6_graphics_11 = new cjs.Graphics().p("A1SK8IAA13MAqlAAAIAAV3g");
	var mask_6_graphics_12 = new cjs.Graphics().p("A23K8IAA13MAtvAAAIAAV3g");
	var mask_6_graphics_13 = new cjs.Graphics().p("A4dK8IAA13MAw7AAAIAAV3g");
	var mask_6_graphics_14 = new cjs.Graphics().p("A6DK8IAA13MA0HAAAIAAV3g");
	var mask_6_graphics_15 = new cjs.Graphics().p("A7oK8IAA13MA3RAAAIAAV3g");
	var mask_6_graphics_16 = new cjs.Graphics().p("A9OK8IAA13MA6dAAAIAAV3g");
	var mask_6_graphics_17 = new cjs.Graphics().p("A+0K8IAA13MA9pAAAIAAV3g");
	var mask_6_graphics_18 = new cjs.Graphics().p("EggZAK8IAA13MBAzAAAIAAV3g");
	var mask_6_graphics_19 = new cjs.Graphics().p("Egh/AK8IAA13MBD/AAAIAAV3g");
	var mask_6_graphics_20 = new cjs.Graphics().p("EgjlAK8IAA13MBHLAAAIAAV3g");
	var mask_6_graphics_21 = new cjs.Graphics().p("EglKAK8IAA13MBKVAAAIAAV3g");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:mask_6_graphics_0,x:-37.4,y:47}).wait(1).to({graphics:mask_6_graphics_1,x:-27.2,y:47}).wait(1).to({graphics:mask_6_graphics_2,x:-17.1,y:47}).wait(1).to({graphics:mask_6_graphics_3,x:-6.9,y:47}).wait(1).to({graphics:mask_6_graphics_4,x:3.2,y:47}).wait(1).to({graphics:mask_6_graphics_5,x:13.3,y:47}).wait(1).to({graphics:mask_6_graphics_6,x:23.5,y:47}).wait(1).to({graphics:mask_6_graphics_7,x:33.7,y:47}).wait(1).to({graphics:mask_6_graphics_8,x:43.8,y:47}).wait(1).to({graphics:mask_6_graphics_9,x:54,y:47}).wait(1).to({graphics:mask_6_graphics_10,x:64.2,y:47}).wait(1).to({graphics:mask_6_graphics_11,x:74.3,y:47}).wait(1).to({graphics:mask_6_graphics_12,x:84.5,y:47}).wait(1).to({graphics:mask_6_graphics_13,x:94.7,y:47}).wait(1).to({graphics:mask_6_graphics_14,x:104.8,y:47}).wait(1).to({graphics:mask_6_graphics_15,x:115,y:47}).wait(1).to({graphics:mask_6_graphics_16,x:125.1,y:47}).wait(1).to({graphics:mask_6_graphics_17,x:135.3,y:47}).wait(1).to({graphics:mask_6_graphics_18,x:145.5,y:47}).wait(1).to({graphics:mask_6_graphics_19,x:155.6,y:47}).wait(1).to({graphics:mask_6_graphics_20,x:165.8,y:47}).wait(1).to({graphics:mask_6_graphics_21,x:176,y:47}).wait(90));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape.setTransform(330.8,53.5-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(264.6,53.5-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(198.5,53.5-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(132.3,53.5-incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(66.2,53.5-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_5.setTransform(198,53.5-incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_6.setTransform(198,53.5-incremento);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask_6;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,396,107);


(lib.tabla_01_MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("AmEBKIAAiUIMKAAIAACUg");
	var mask_graphics_22 = new cjs.Graphics().p("AmECLIAAkVIMKAAIAAEVg");
	var mask_graphics_23 = new cjs.Graphics().p("AmEDMIAAmXIMKAAIAAGXg");
	var mask_graphics_24 = new cjs.Graphics().p("AmEEMIAAoXIMKAAIAAIXg");
	var mask_graphics_25 = new cjs.Graphics().p("AmEFMIAAqYIMKAAIAAKYg");
	var mask_graphics_26 = new cjs.Graphics().p("AmEGNIAAsZIMKAAIAAMZg");
	var mask_graphics_27 = new cjs.Graphics().p("AmEHNIAAuaIMKAAIAAOag");
	var mask_graphics_28 = new cjs.Graphics().p("AmEIOIAAwbIMKAAIAAQbg");
	var mask_graphics_29 = new cjs.Graphics().p("AmEJPIAAydIMKAAIAASdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmEKPIAA0dIMKAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmELQIAA2eIMKAAIAAWeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:29,y:-15.4}).wait(1).to({graphics:mask_graphics_22,x:29,y:-9}).wait(1).to({graphics:mask_graphics_23,x:29,y:-2.5}).wait(1).to({graphics:mask_graphics_24,x:29,y:3.9}).wait(1).to({graphics:mask_graphics_25,x:29,y:10.3}).wait(1).to({graphics:mask_graphics_26,x:29,y:16.8}).wait(1).to({graphics:mask_graphics_27,x:29,y:23.2}).wait(1).to({graphics:mask_graphics_28,x:29,y:29.7}).wait(1).to({graphics:mask_graphics_29,x:29,y:36.1}).wait(1).to({graphics:mask_graphics_30,x:29,y:42.6}).wait(1).to({graphics:mask_graphics_31,x:29,y:49}).wait(1).to({graphics:null,x:0,y:0}).wait(79));

	// Capa 6
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(31,62.9);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(31,12.9);

	this.text.mask = this.text_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},21).wait(90));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_32 = new cjs.Graphics().p("Ak5AsIAAhYIJzAAIAABYg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ak5B2IAAjrIJzAAIAADrg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Ak5C/IAAl9IJzAAIAAF9g");
	var mask_1_graphics_35 = new cjs.Graphics().p("Ak5EIIAAoPIJzAAIAAIPg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Ak5FRIAAqhIJzAAIAAKhg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ak5GaIAAszIJzAAIAAMzg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ak5HjIAAvFIJzAAIAAPFg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Ak5IsIAAxXIJzAAIAARXg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AAZJ1IAAzqIJ1AAIAATqg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(32).to({graphics:mask_1_graphics_32,x:99.5,y:-10.4}).wait(1).to({graphics:mask_1_graphics_33,x:99.5,y:-3.1}).wait(1).to({graphics:mask_1_graphics_34,x:99.5,y:4.1}).wait(1).to({graphics:mask_1_graphics_35,x:99.5,y:11.4}).wait(1).to({graphics:mask_1_graphics_36,x:99.5,y:18.8}).wait(1).to({graphics:mask_1_graphics_37,x:99.5,y:26.1}).wait(1).to({graphics:mask_1_graphics_38,x:99.5,y:33.4}).wait(1).to({graphics:mask_1_graphics_39,x:99.5,y:40.7}).wait(1).to({graphics:mask_1_graphics_40,x:65.5,y:48}).wait(1).to({graphics:null,x:0,y:0}).wait(70));

	// Capa 5
	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(97,66.9);

	this.text_3 = new cjs.Text("0", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,12.9);

	this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.text_2}]},32).wait(79));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_43 = new cjs.Graphics().p("AkrAnIAAhNIJWAAIAABNg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AkrBpIAAjRIJWAAIAADRg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AkrCrIAAlVIJWAAIAAFVg");
	var mask_2_graphics_46 = new cjs.Graphics().p("AkrDsIAAnXIJWAAIAAHXg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AkrEuIAApbIJWAAIAAJbg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AkrFwIAArfIJWAAIAALfg");
	var mask_2_graphics_49 = new cjs.Graphics().p("AkrGxIAAthIJWAAIAANhg");
	var mask_2_graphics_50 = new cjs.Graphics().p("AkrHzIAAvlIJWAAIAAPlg");
	var mask_2_graphics_51 = new cjs.Graphics().p("AF2I1IAAxpIJYAAIAARpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(43).to({graphics:mask_2_graphics_43,x:165,y:-8.9}).wait(1).to({graphics:mask_2_graphics_44,x:165,y:-2.3}).wait(1).to({graphics:mask_2_graphics_45,x:165,y:4.1}).wait(1).to({graphics:mask_2_graphics_46,x:165,y:10.7}).wait(1).to({graphics:mask_2_graphics_47,x:165,y:17.3}).wait(1).to({graphics:mask_2_graphics_48,x:165,y:23.8}).wait(1).to({graphics:mask_2_graphics_49,x:165,y:30.4}).wait(1).to({graphics:mask_2_graphics_50,x:165,y:37}).wait(1).to({graphics:mask_2_graphics_51,x:97.5,y:43.5}).wait(60));

	// Capa 4
	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,66.9);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(163,12.9);

	this.text_4.mask = this.text_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_5},{t:this.text_4}]},43).wait(68));

	// Capa 12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_54 = new cjs.Graphics().p("AlHA3IAAhsIKPAAIAABsg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AlHCDIAAkFIKPAAIAAEFg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AlHDPIAAmdIKPAAIAAGdg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AlHEcIAAo3IKPAAIAAI3g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AlHFoIAArPIKPAAIAALPg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AlHG1IAAtpIKPAAIAANpg");
	var mask_3_graphics_60 = new cjs.Graphics().p("AlHIBIAAwBIKPAAIAAQBg");
	var mask_3_graphics_61 = new cjs.Graphics().p("AKaJOIAAyaIKRAAIAASag");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_3_graphics_54,x:231.8,y:-5.4}).wait(1).to({graphics:mask_3_graphics_55,x:231.8,y:2.1}).wait(1).to({graphics:mask_3_graphics_56,x:231.8,y:9.8}).wait(1).to({graphics:mask_3_graphics_57,x:231.8,y:17.4}).wait(1).to({graphics:mask_3_graphics_58,x:231.8,y:25.1}).wait(1).to({graphics:mask_3_graphics_59,x:231.8,y:32.7}).wait(1).to({graphics:mask_3_graphics_60,x:231.8,y:40.4}).wait(1).to({graphics:mask_3_graphics_61,x:132.3,y:48}).wait(50));

	// Capa 3
	this.text_6 = new cjs.Text("1", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(229,66.9);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(229,12.9);

	this.text_6.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.text_6}]},54).wait(57));

	// Capa 13 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_64 = new cjs.Graphics().p("Ak+A8IAAh3IJ+AAIAAB3g");
	var mask_4_graphics_65 = new cjs.Graphics().p("Ak+CQIAAkfIJ+AAIAAEfg");
	var mask_4_graphics_66 = new cjs.Graphics().p("Ak+DkIAAnHIJ+AAIAAHHg");
	var mask_4_graphics_67 = new cjs.Graphics().p("Ak+E4IAApvIJ+AAIAAJvg");
	var mask_4_graphics_68 = new cjs.Graphics().p("Ak+GNIAAsZIJ+AAIAAMZg");
	var mask_4_graphics_69 = new cjs.Graphics().p("Ak+HhIAAvBIJ+AAIAAPBg");
	var mask_4_graphics_70 = new cjs.Graphics().p("Ak+I1IAAxpIJ+AAIAARpg");
	var mask_4_graphics_71 = new cjs.Graphics().p("APdKJIAA0SIKAAAIAAUSg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(64).to({graphics:mask_4_graphics_64,x:294,y:-9.9}).wait(1).to({graphics:mask_4_graphics_65,x:294,y:-1.5}).wait(1).to({graphics:mask_4_graphics_66,x:294,y:6.9}).wait(1).to({graphics:mask_4_graphics_67,x:294,y:15.3}).wait(1).to({graphics:mask_4_graphics_68,x:294,y:23.7}).wait(1).to({graphics:mask_4_graphics_69,x:294,y:32.1}).wait(1).to({graphics:mask_4_graphics_70,x:294,y:40.6}).wait(1).to({graphics:mask_4_graphics_71,x:163,y:49}).wait(40));

	// Capa 2
	this.text_8 = new cjs.Text("4", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(296,66.9);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(296,12.9);

	this.text_8.mask = this.text_9.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_9},{t:this.text_8}]},64).wait(47));

	// Capa 14 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_75 = new cjs.Graphics().p("AkYA1IAAhpIIxAAIAABpg");
	var mask_5_graphics_76 = new cjs.Graphics().p("AkYCNIAAkZIIxAAIAAEZg");
	var mask_5_graphics_77 = new cjs.Graphics().p("AkYDmIAAnLIIxAAIAAHLg");
	var mask_5_graphics_78 = new cjs.Graphics().p("AkYE/IAAp9IIxAAIAAJ9g");
	var mask_5_graphics_79 = new cjs.Graphics().p("AkYGXIAAstIIxAAIAAMtg");
	var mask_5_graphics_80 = new cjs.Graphics().p("AkYHwIAAvfIIxAAIAAPfg");
	var mask_5_graphics_81 = new cjs.Graphics().p("AVrJJIAAyQII0AAIAASQg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(75).to({graphics:mask_5_graphics_75,x:362.2,y:-4.6}).wait(1).to({graphics:mask_5_graphics_76,x:362.2,y:4.2}).wait(1).to({graphics:mask_5_graphics_77,x:362.2,y:13.1}).wait(1).to({graphics:mask_5_graphics_78,x:362.2,y:21.9}).wait(1).to({graphics:mask_5_graphics_79,x:362.2,y:30.8}).wait(1).to({graphics:mask_5_graphics_80,x:362.2,y:39.6}).wait(1).to({graphics:mask_5_graphics_81,x:195.2,y:48.5}).wait(30));

	// Capa 7
	this.text_10 = new cjs.Text("4", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(361,66.9);

	this.text_11 = new cjs.Text("–2", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(361,12.9);

	this.text_10.mask = this.text_11.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_11},{t:this.text_10}]},75).wait(36));

	// Capa 8 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_0 = new cjs.Graphics().p("Aj0K8IAA13IHpAAIAAV3g");
	var mask_6_graphics_1 = new cjs.Graphics().p("AlZK8IAA13IKzAAIAAV3g");
	var mask_6_graphics_2 = new cjs.Graphics().p("Am/K8IAA13IN/AAIAAV3g");
	var mask_6_graphics_3 = new cjs.Graphics().p("AokK8IAA13IRJAAIAAV3g");
	var mask_6_graphics_4 = new cjs.Graphics().p("AqKK8IAA13IUVAAIAAV3g");
	var mask_6_graphics_5 = new cjs.Graphics().p("ArwK8IAA13IXhAAIAAV3g");
	var mask_6_graphics_6 = new cjs.Graphics().p("AtVK8IAA13IarAAIAAV3g");
	var mask_6_graphics_7 = new cjs.Graphics().p("Au7K8IAA13Id3AAIAAV3g");
	var mask_6_graphics_8 = new cjs.Graphics().p("AwhK8IAA13MAhDAAAIAAV3g");
	var mask_6_graphics_9 = new cjs.Graphics().p("AyGK8IAA13MAkNAAAIAAV3g");
	var mask_6_graphics_10 = new cjs.Graphics().p("AzsK8IAA13MAnZAAAIAAV3g");
	var mask_6_graphics_11 = new cjs.Graphics().p("A1SK8IAA13MAqlAAAIAAV3g");
	var mask_6_graphics_12 = new cjs.Graphics().p("A23K8IAA13MAtvAAAIAAV3g");
	var mask_6_graphics_13 = new cjs.Graphics().p("A4dK8IAA13MAw7AAAIAAV3g");
	var mask_6_graphics_14 = new cjs.Graphics().p("A6DK8IAA13MA0HAAAIAAV3g");
	var mask_6_graphics_15 = new cjs.Graphics().p("A7oK8IAA13MA3RAAAIAAV3g");
	var mask_6_graphics_16 = new cjs.Graphics().p("A9OK8IAA13MA6dAAAIAAV3g");
	var mask_6_graphics_17 = new cjs.Graphics().p("A+0K8IAA13MA9pAAAIAAV3g");
	var mask_6_graphics_18 = new cjs.Graphics().p("EggZAK8IAA13MBAzAAAIAAV3g");
	var mask_6_graphics_19 = new cjs.Graphics().p("Egh/AK8IAA13MBD/AAAIAAV3g");
	var mask_6_graphics_20 = new cjs.Graphics().p("EgjlAK8IAA13MBHLAAAIAAV3g");
	var mask_6_graphics_21 = new cjs.Graphics().p("EglKAK8IAA13MBKVAAAIAAV3g");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:mask_6_graphics_0,x:-37.4,y:47}).wait(1).to({graphics:mask_6_graphics_1,x:-27.2,y:47}).wait(1).to({graphics:mask_6_graphics_2,x:-17.1,y:47}).wait(1).to({graphics:mask_6_graphics_3,x:-6.9,y:47}).wait(1).to({graphics:mask_6_graphics_4,x:3.2,y:47}).wait(1).to({graphics:mask_6_graphics_5,x:13.3,y:47}).wait(1).to({graphics:mask_6_graphics_6,x:23.5,y:47}).wait(1).to({graphics:mask_6_graphics_7,x:33.7,y:47}).wait(1).to({graphics:mask_6_graphics_8,x:43.8,y:47}).wait(1).to({graphics:mask_6_graphics_9,x:54,y:47}).wait(1).to({graphics:mask_6_graphics_10,x:64.2,y:47}).wait(1).to({graphics:mask_6_graphics_11,x:74.3,y:47}).wait(1).to({graphics:mask_6_graphics_12,x:84.5,y:47}).wait(1).to({graphics:mask_6_graphics_13,x:94.7,y:47}).wait(1).to({graphics:mask_6_graphics_14,x:104.8,y:47}).wait(1).to({graphics:mask_6_graphics_15,x:115,y:47}).wait(1).to({graphics:mask_6_graphics_16,x:125.1,y:47}).wait(1).to({graphics:mask_6_graphics_17,x:135.3,y:47}).wait(1).to({graphics:mask_6_graphics_18,x:145.5,y:47}).wait(1).to({graphics:mask_6_graphics_19,x:155.6,y:47}).wait(1).to({graphics:mask_6_graphics_20,x:165.8,y:47}).wait(1).to({graphics:mask_6_graphics_21,x:176,y:47}).wait(90));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape.setTransform(330.8,53.5-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(264.6,53.5-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(198.5,53.5-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(132.3,53.5-incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(66.2,53.5-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_5.setTransform(198,53.5-incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_6.setTransform(198,53.5-incremento);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask_6;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,396,107);
(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,318,377);


(lib.IMG_info_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgFdAimMAAAhFLIK6AAMAAABFLg");
	var mask_graphics_1 = new cjs.Graphics().p("EgG3AimMAAAhFLINvAAMAAABFLg");
	var mask_graphics_2 = new cjs.Graphics().p("EgISAimMAAAhFLIQlAAMAAABFLg");
	var mask_graphics_3 = new cjs.Graphics().p("EgJtAimMAAAhFLITbAAMAAABFLg");
	var mask_graphics_4 = new cjs.Graphics().p("EgLIAimMAAAhFLIWRAAMAAABFLg");
	var mask_graphics_5 = new cjs.Graphics().p("EgMiAimMAAAhFLIZFAAMAAABFLg");
	var mask_graphics_6 = new cjs.Graphics().p("EgN9AimMAAAhFLIb7AAMAAABFLg");
	var mask_graphics_7 = new cjs.Graphics().p("EgPYAimMAAAhFLIexAAMAAABFLg");
	var mask_graphics_8 = new cjs.Graphics().p("EgQzAimMAAAhFLMAhnAAAMAAABFLg");
	var mask_graphics_9 = new cjs.Graphics().p("EgSOAimMAAAhFLMAkdAAAMAAABFLg");
	var mask_graphics_10 = new cjs.Graphics().p("EgToAimMAAAhFLMAnRAAAMAAABFLg");
	var mask_graphics_11 = new cjs.Graphics().p("EgVDAimMAAAhFLMAqHAAAMAAABFLg");
	var mask_graphics_12 = new cjs.Graphics().p("EgWeAimMAAAhFLMAs9AAAMAAABFLg");
	var mask_graphics_13 = new cjs.Graphics().p("EgX5AimMAAAhFLMAvzAAAMAAABFLg");
	var mask_graphics_14 = new cjs.Graphics().p("EgZUAimMAAAhFLMAypAAAMAAABFLg");
	var mask_graphics_15 = new cjs.Graphics().p("EgauAimMAAAhFLMA1dAAAMAAABFLg");
	var mask_graphics_16 = new cjs.Graphics().p("EgcJAimMAAAhFLMA4TAAAMAAABFLg");
	var mask_graphics_17 = new cjs.Graphics().p("EgdkAimMAAAhFLMA7JAAAMAAABFLg");
	var mask_graphics_18 = new cjs.Graphics().p("Ege/AimMAAAhFLMA9/AAAMAAABFLg");
	var mask_graphics_19 = new cjs.Graphics().p("EggaAimMAAAhFLMBA1AAAMAAABFLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-228.4,y:15.4}).wait(1).to({graphics:mask_graphics_1,x:-219.3,y:15.4}).wait(1).to({graphics:mask_graphics_2,x:-210.2,y:15.4}).wait(1).to({graphics:mask_graphics_3,x:-201.2,y:15.4}).wait(1).to({graphics:mask_graphics_4,x:-192.1,y:15.4}).wait(1).to({graphics:mask_graphics_5,x:-183,y:15.4}).wait(1).to({graphics:mask_graphics_6,x:-173.9,y:15.4}).wait(1).to({graphics:mask_graphics_7,x:-164.8,y:15.4}).wait(1).to({graphics:mask_graphics_8,x:-155.8,y:15.4}).wait(1).to({graphics:mask_graphics_9,x:-146.7,y:15.4}).wait(1).to({graphics:mask_graphics_10,x:-137.6,y:15.4}).wait(1).to({graphics:mask_graphics_11,x:-128.5,y:15.4}).wait(1).to({graphics:mask_graphics_12,x:-119.5,y:15.4}).wait(1).to({graphics:mask_graphics_13,x:-110.4,y:15.4}).wait(1).to({graphics:mask_graphics_14,x:-101.3,y:15.4}).wait(1).to({graphics:mask_graphics_15,x:-92.2,y:15.4}).wait(1).to({graphics:mask_graphics_16,x:-83.1,y:15.4}).wait(1).to({graphics:mask_graphics_17,x:-74.1,y:15.4}).wait(1).to({graphics:mask_graphics_18,x:-65,y:15.4}).wait(1).to({graphics:mask_graphics_19,x:-55.9,y:15.4}).wait(82));

	// Capa 3
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(-177.3,-176.1);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(101));

	// Capa 5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_29 = new cjs.Graphics().p("EgDlAlQMAAAhKfIHKAAMAAABKfg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EgFBAlQMAAAhKfIKDAAMAAABKfg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EgGdAlQMAAAhKfIM8AAMAAABKfg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EgH6AlQMAAAhKfIP1AAMAAABKfg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgJXAlQMAAAhKfISuAAMAAABKfg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgKzAlQMAAAhKfIVnAAMAAABKfg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgMPAlQMAAAhKfIYfAAMAAABKfg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgNsAlQMAAAhKfIbZAAMAAABKfg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EgPJAlQMAAAhKfIeTAAMAAABKfg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgQlAlQMAAAhKfMAhLAAAMAAABKfg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgSBAlQMAAAhKfMAkDAAAMAAABKfg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgTeAlQMAAAhKfMAm9AAAMAAABKfg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgU7AlQMAAAhKfMAp2AAAMAAABKfg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgWXAlQMAAAhKfMAsvAAAMAAABKfg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgXzAlQMAAAhKfMAvoAAAMAAABKfg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgZQAlQMAAAhKfMAyhAAAMAAABKfg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgatAlQMAAAhKfMA1aAAAMAAABKfg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgcJAlQMAAAhKfMA4TAAAMAAABKfg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgdmAlQMAAAhKfMA7MAAAMAAABKfg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgfCAlQMAAAhKfMA+FAAAMAAABKfg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EggeAlQMAAAhKfMBA9AAAMAAABKfg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_1_graphics_29,x:-206.4,y:-1.5}).wait(1).to({graphics:mask_1_graphics_30,x:-197.1,y:-1.5}).wait(1).to({graphics:mask_1_graphics_31,x:-187.9,y:-1.5}).wait(1).to({graphics:mask_1_graphics_32,x:-178.6,y:-1.5}).wait(1).to({graphics:mask_1_graphics_33,x:-169.4,y:-1.5}).wait(1).to({graphics:mask_1_graphics_34,x:-160.1,y:-1.5}).wait(1).to({graphics:mask_1_graphics_35,x:-150.9,y:-1.5}).wait(1).to({graphics:mask_1_graphics_36,x:-141.6,y:-1.5}).wait(1).to({graphics:mask_1_graphics_37,x:-132.4,y:-1.5}).wait(1).to({graphics:mask_1_graphics_38,x:-123.1,y:-1.5}).wait(1).to({graphics:mask_1_graphics_39,x:-113.9,y:-1.5}).wait(1).to({graphics:mask_1_graphics_40,x:-104.6,y:-1.5}).wait(1).to({graphics:mask_1_graphics_41,x:-95.4,y:-1.5}).wait(1).to({graphics:mask_1_graphics_42,x:-86.1,y:-1.5}).wait(1).to({graphics:mask_1_graphics_43,x:-76.9,y:-1.5}).wait(1).to({graphics:mask_1_graphics_44,x:-67.6,y:-1.5}).wait(1).to({graphics:mask_1_graphics_45,x:-58.4,y:-1.5}).wait(1).to({graphics:mask_1_graphics_46,x:-49.1,y:-1.5}).wait(1).to({graphics:mask_1_graphics_47,x:-39.9,y:-1.5}).wait(1).to({graphics:mask_1_graphics_48,x:-30.6,y:-1.5}).wait(1).to({graphics:mask_1_graphics_49,x:-21.4,y:-1.5}).wait(52));

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00662F").ss(4).p("AKAHsIz/vX");
	this.shape.setTransform(-82.1,146.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00662F").ss(4).p("A26PRIkKjMMAZqguZIcfV0MgZMAu1Ikyjs");
	this.shape_1.setTransform(0.5,0);

	this.shape.mask = this.shape_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},29).wait(72));

	// Capa 6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_60 = new cjs.Graphics().p("AkNaKMAAAg0TIIaAAMAAAA0Tg");
	var mask_2_graphics_61 = new cjs.Graphics().p("AlMaKMAAAg0TIKZAAMAAAA0Tg");
	var mask_2_graphics_62 = new cjs.Graphics().p("AmMaKMAAAg0TIMZAAMAAAA0Tg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AnMaKMAAAg0TIOZAAMAAAA0Tg");
	var mask_2_graphics_64 = new cjs.Graphics().p("AoMaKMAAAg0TIQZAAMAAAA0Tg");
	var mask_2_graphics_65 = new cjs.Graphics().p("ApMaKMAAAg0TISZAAMAAAA0Tg");
	var mask_2_graphics_66 = new cjs.Graphics().p("AqMaKMAAAg0TIUZAAMAAAA0Tg");
	var mask_2_graphics_67 = new cjs.Graphics().p("ArMaKMAAAg0TIWZAAMAAAA0Tg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AsMaKMAAAg0TIYZAAMAAAA0Tg");
	var mask_2_graphics_69 = new cjs.Graphics().p("AtMaKMAAAg0TIaZAAMAAAA0Tg");
	var mask_2_graphics_70 = new cjs.Graphics().p("AuMaKMAAAg0TIcZAAMAAAA0Tg");
	var mask_2_graphics_71 = new cjs.Graphics().p("AvMaKMAAAg0TIeZAAMAAAA0Tg");
	var mask_2_graphics_72 = new cjs.Graphics().p("AwMaKMAAAg0TMAgZAAAMAAAA0Tg");
	var mask_2_graphics_73 = new cjs.Graphics().p("AxMaKMAAAg0TMAiZAAAMAAAA0Tg");
	var mask_2_graphics_74 = new cjs.Graphics().p("AyMaKMAAAg0TMAkZAAAMAAAA0Tg");
	var mask_2_graphics_75 = new cjs.Graphics().p("AzMaKMAAAg0TMAmZAAAMAAAA0Tg");
	var mask_2_graphics_76 = new cjs.Graphics().p("A0MaKMAAAg0TMAoZAAAMAAAA0Tg");
	var mask_2_graphics_77 = new cjs.Graphics().p("A1MaKMAAAg0TMAqZAAAMAAAA0Tg");
	var mask_2_graphics_78 = new cjs.Graphics().p("A2MaKMAAAg0TMAsZAAAMAAAA0Tg");
	var mask_2_graphics_79 = new cjs.Graphics().p("A3MaKMAAAg0TMAuYAAAMAAAA0Tg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(60).to({graphics:mask_2_graphics_60,x:-191.4,y:51.4}).wait(1).to({graphics:mask_2_graphics_61,x:-185,y:51.4}).wait(1).to({graphics:mask_2_graphics_62,x:-178.6,y:51.4}).wait(1).to({graphics:mask_2_graphics_63,x:-172.2,y:51.4}).wait(1).to({graphics:mask_2_graphics_64,x:-165.8,y:51.4}).wait(1).to({graphics:mask_2_graphics_65,x:-159.4,y:51.4}).wait(1).to({graphics:mask_2_graphics_66,x:-153,y:51.4}).wait(1).to({graphics:mask_2_graphics_67,x:-146.6,y:51.4}).wait(1).to({graphics:mask_2_graphics_68,x:-140.2,y:51.4}).wait(1).to({graphics:mask_2_graphics_69,x:-133.8,y:51.4}).wait(1).to({graphics:mask_2_graphics_70,x:-127.5,y:51.4}).wait(1).to({graphics:mask_2_graphics_71,x:-121.1,y:51.4}).wait(1).to({graphics:mask_2_graphics_72,x:-114.7,y:51.4}).wait(1).to({graphics:mask_2_graphics_73,x:-108.3,y:51.4}).wait(1).to({graphics:mask_2_graphics_74,x:-101.9,y:51.4}).wait(1).to({graphics:mask_2_graphics_75,x:-95.5,y:51.4}).wait(1).to({graphics:mask_2_graphics_76,x:-89.1,y:51.4}).wait(1).to({graphics:mask_2_graphics_77,x:-82.7,y:51.4}).wait(1).to({graphics:mask_2_graphics_78,x:-76.3,y:51.4}).wait(1).to({graphics:mask_2_graphics_79,x:-69.9,y:51.4}).wait(22));

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#2D73B5").ss(4).p("AJUwlMgSmAhL");
	this.shape_2.setTransform(-15.9,45.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#E76114").ss(4).p("AiMADIEZgF");
	this.shape_3.setTransform(-22.7,181.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#E76114").ss(4).p("AjgABIHBgB");
	this.shape_4.setTransform(-27,171.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#E76114").ss(4).p("AkrAAIJXAB");
	this.shape_5.setTransform(-30.8,163.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#E76114").ss(4).p("AlvABILfgB");
	this.shape_6.setTransform(-34.7,154.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#E76114").ss(4).p("AnRgLIOjAW");
	this.shape_7.setTransform(-39.8,144.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#E76114").ss(4).p("AopgEIRTAJ");
	this.shape_8.setTransform(-44,134.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#E76114").ss(4).p("AqOgHIUdAP");
	this.shape_9.setTransform(-49.5,122.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#E76114").ss(4).p("AregJIW9AT");
	this.shape_10.setTransform(-55.2,112.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#E76114").ss(4).p("ArhgPIXDAf");
	this.shape_11.setTransform(-51.9,102.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#E76114").ss(4).p("ArXgJIWwAT");
	this.shape_12.setTransform(-46.3,94);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#E76114").ss(4).p("Aq/gJIV/AT");
	this.shape_13.setTransform(-40.2,83.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#E76114").ss(4).p("AqtgEIVbAJ");
	this.shape_14.setTransform(-35.4,75.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#E76114").ss(4).p("AqSgFIUlAL");
	this.shape_15.setTransform(-29.4,64.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#E76114").ss(4).p("Ap3gBITuAD");
	this.shape_16.setTransform(-23.2,53.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#E76114").ss(4).p("ApcgCIS5AF");
	this.shape_17.setTransform(-18,44.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#E76114").ss(4).p("Ao/AAIR/AB");
	this.shape_18.setTransform(-14,36.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#E76114").ss(4).p("AomAAIRNAB");
	this.shape_19.setTransform(-8,26.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#E76114").ss(4).p("An/gBIP/AD");
	this.shape_20.setTransform(-2.9,15.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#E76114").ss(4).p("AHmAEIvLgH");
	this.shape_21.setTransform(2.1,7.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#E76114").ss(4).p("AG/AAIt9AA");
	this.shape_22.setTransform(7.1,-3.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#E76114").ss(4).p("AGDAGIsFgL");
	this.shape_23.setTransform(13.1,-13.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#E76114").ss(4).p("AFwAGIrfgL");
	this.shape_24.setTransform(16.6,-21.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#E76114").ss(4).p("AE8AEIp4gH");
	this.shape_25.setTransform(20.2,-30.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#E76114").ss(4).p("AELAAIoVAA");
	this.shape_26.setTransform(25.1,-40.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#E76114").ss(4).p("AC0AAIlnAA");
	this.shape_27.setTransform(30.2,-52.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#E76114").ss(4).p("AlfUJQA/iBBZjJQCymUB9lrQGWyJkClH");
	this.shape_28.setTransform(18.4,69.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#E76114").ss(4).p("ANss/QgbgLgpgFQhRgIhEAmQjABul3GfQkYE3qzNG");
	this.shape_29.setTransform(-43.9,22.8);

	this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},60).wait(41));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-177.3,-176.1,318,377);


(lib.Imagen_04_06 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#F307B6").ss(4,0,0,4).p("EArJA2pQhrpOkwxBQlazZmExDQnU0mmbrxQnot+lkAAQoBAAnTNhQl8LClrUjQjxNlkwWgQhMFqiGJ5QhrHuhDD5");
	this.shape.setTransform(8,112);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAABDVMAAAiGp");
	this.shape_1.setTransform(-6,18.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EBH7AAAMiP1AAA");
	this.shape_2.setTransform(-7.1,-299.2);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-268,-236,552.2,697.8);


(lib.Imagen_04_05 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFC000").ss(4,0,0,4).p("EgrIg2oQBrJOEwRCQFaTYGERDQHUUmGbLyQHoN+FkAAQIBAAHTtiQF8rCFr0jQDxtlEw2gQBMlpCGp5QBqnuBEj5");
	this.shape.setTransform(-14.2,-133.8);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAhDUMAAACGp");
	this.shape_1.setTransform(-0.1,-40.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhH6AAAMCP1AAA");
	this.shape_2.setTransform(1,277.5);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-290.3,-483.5,552.2,697.9);


(lib.Imagen_04_04 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#9907D7").ss(4,0,0,4).p("EArJA2pQhrpOkwxCQlazYmExDQnU0mmbryQnot+lkAAQoBAAnTNiQl8LClrUjQjxNlkwWgQhMFpiGJ5QhqHuhED5");
	this.shape.setTransform(11.8,-5.4);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA8WMAAAh4r");
	this.shape_1.setTransform(-2.3,-40.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EBH7AAAMiP1AAA");
	this.shape_2.setTransform(-3.4,-313.7);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-264.2,-353.5,552.2,697.9);


(lib.Imagen_04_03 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00A52F").ss(4,0,0,4).p("EgrIg2oQBrJOEwRCQFaTYGERDQHUUmGbLyQHoN+FkAAQIBAAHTtiQF8rCFr0jQDxtlEw2gQBMlpCGp5QBqnuBEj5");
	this.shape.setTransform(-18.1,-40);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAg8VMAAAB4r");
	this.shape_1.setTransform(-4,-4.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhH6AAAMCP1AAA");
	this.shape_2.setTransform(-2.9,268.3);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-294.3,-389.7,552.2,697.9);


(lib.Imagen_04_02 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#007493").ss(4,0,0,4).p("EAphAzeQhnorkkwDQlOyQl1wDQnDzamLrGQnWtKlWAAQnuAAnBMwQlvKYldTXQjoMzklVMQhJFUiAJVQhnHRhBDq");
	this.shape.setTransform(-30,-57.7);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA8WMAAAh4r");
	this.shape_1.setTransform(-38.5,-113.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EBH7AAAMiP1AAA");
	this.shape_2.setTransform(-39.6,-386.7);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-295.8,-385.6,531.6,657.3);


(lib.Imagen_04_01 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4,0,0,4).p("EgrIgzdQBrIrEwQDQFaSQGEQDQHUTaGbLGQHoNKFkAAQIBAAHTswQF8qZFrzWQDxszEw1MQBMlVCGpUQBqnRBEjr");
	this.shape.setTransform(-10.6,-55.9);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAg8VMAAAB4r");
	this.shape_1.setTransform(-0.5,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhH6AAAMCP1AAA");
	this.shape_2.setTransform(0.5,273);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-286.8,-385.4,552.2,657.3);


(lib.Imagen_01_02 = function() {
	this.initialize();

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4,0,0,4).p("EAapAntQhToBiYrWQjDukjPr2QkEu9jwoZQkgqDjxAAUgIIAAAgIrAgtQiuKQjaQFQg4EJhhHUQhPF1gsC2");
	this.shape.setTransform(165.8,234.6,0.481,0.481);

	// ejes
	this.text = new cjs.Text("X", "25px Verdana");
	this.text.lineHeight = 25;
	this.text.setTransform(353,109.9+incremento);

	this.text_1 = new cjs.Text("Y", "25px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(183,-21.1);

	this.text_2 = new cjs.Text("", "25px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.lineWidth = 100;
	this.text_2.setTransform(183,-34.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAg8VMAAAB4r");
	this.shape_1.setTransform(167,170.7,0.481,0.481);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhCZAAAMCEzAAA");
	this.shape_2.setTransform(166.6,110.9,0.481,0.481);

	this.addChild(this.shape_2,this.shape_1,this.text_2,this.text_1,this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(83.8,-34.1,290.6,391);


(lib.Imagen_01_01 = function() {
	this.initialize();

	// Capa 4
	this.text = new cjs.Text("X", "25px Verdana");
	this.text.lineHeight = 25;
	this.text.setTransform(329,275.8);

	this.text_1 = new cjs.Text("Y", "25px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(172,4.9);

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#9907D7").ss(4,0,0,4).p("Eg3RgzdQCJIsGGQCQG7SQHyQEQJYTZIOLGQJxNKHJAAQKSAAJWsvQHoqZHRzWQE1szGG1NQC7qSBSkWQCInRBXjr");
	this.shape.setTransform(155.7,146.5,0.396,0.396);

	// ejes
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAg8VMAAAB4r");
	this.shape_1.setTransform(164.1,168.5,0.396,0.396);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,0,0,4).p("EhH6AAAMCP1AAA");
	this.shape_2.setTransform(164.6,276.7,0.396,0.396);

	this.addChild(this.shape_2,this.shape_1,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(15.5,4.9,334.9,305.3);


(lib.Imagen_00 = function() {
	this.initialize();

	// circulo
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAegXAXQgWAWgeAAQgeAAgWgWQgWgXAAgeQAAgeAWgWQAWgWAeAAQAeAAAWAWQAXAWAAAeg");
	this.shape.setTransform(195.4,307.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0060BA").s().p("Ag0A0QgVgVAAgfQAAgeAVgVQAXgXAdAAQAfAAAVAXQAXAVAAAeQAAAfgXAVQgVAXgfAAQgdAAgXgXg");
	this.shape_1.setTransform(195.4,307.2);

	// Texto
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(4,0,0,4).p("A0H3MQAyD5COHOQChINC1HNQDbIuDAFAQDjF6ClAAQFUAAGXzGQCCmDCgpOQDArEAJgc");
	this.shape_2.setTransform(190.3,160.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#003399").ss(2,0,0,4).p("AHNN5IuZ7x");
	this.shape_3.setTransform(248.2,10.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#003399").ss(2,0,0,4).p("Al6TDMAL1gmF");
	this.shape_4.setTransform(149.8,43.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#009900").ss(2,0,0,4).p("AsJHTIYTul");
	this.shape_5.setTransform(281.4,262.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#993399").ss(2,0,0,4).p("AxiStMAjFglZ");
	this.shape_6.setTransform(83,312);

	// ejes
	this.text = new cjs.Text("X", "31px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 24;
	this.text.setTransform(612.1,326.8);

	this.text_1 = new cjs.Text("Y", "31px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 31;
	this.text_1.lineWidth = 24;
	this.text_1.setTransform(98.4,-80.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2.8,0,0,4).p("EAAAgknMAAABJQ");
	this.shape_7.setTransform(195.4,215.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(4,0,0,4).p("EhKeAAAMCU9AAA");
	this.shape_8.setTransform(115.2,353.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAgtaMAAABa1");
	this.shape_9.setTransform(100.6,257.9);

	this.addChild(this.shape_9,this.shape_8,this.shape_7,this.text_1,this.text,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-361.5,-80.9,989.8,629.6);


(lib.graficoAnimado_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_114 = new cjs.Graphics().p("EgC6ArqMAAAhXUIF1AAMAAABXUg");
	var mask_graphics_115 = new cjs.Graphics().p("EgHpArqMAAAhXUIPTAAMAAABXUg");
	var mask_graphics_116 = new cjs.Graphics().p("EgMZArqMAAAhXUIYzAAMAAABXUg");
	var mask_graphics_117 = new cjs.Graphics().p("EgRJArqMAAAhXUMAiTAAAMAAABXUg");
	var mask_graphics_118 = new cjs.Graphics().p("EgV5ArqMAAAhXUMArzAAAMAAABXUg");
	var mask_graphics_119 = new cjs.Graphics().p("EgaoArqMAAAhXUMA1RAAAMAAABXUg");
	var mask_graphics_120 = new cjs.Graphics().p("EgfYArqMAAAhXUMA+xAAAMAAABXUg");
	var mask_graphics_121 = new cjs.Graphics().p("EgkIArqMAAAhXUMBIRAAAMAAABXUg");
	var mask_graphics_122 = new cjs.Graphics().p("Ego4ArqMAAAhXUMBRxAAAMAAABXUg");
	var mask_graphics_123 = new cjs.Graphics().p("EgtoArqMAAAhXUMBbRAAAMAAABXUg");
	var mask_graphics_124 = new cjs.Graphics().p("EgyXArqMAAAhXUMBkvAAAMAAABXUg");
	var mask_graphics_125 = new cjs.Graphics().p("Eg3HArqMAAAhXUMBuPAAAMAAABXUg");
	var mask_graphics_126 = new cjs.Graphics().p("Eg73ArqMAAAhXUMB3vAAAMAAABXUg");
	var mask_graphics_127 = new cjs.Graphics().p("EhAnArqMAAAhXUMCBPAAAMAAABXUg");
	var mask_graphics_128 = new cjs.Graphics().p("EhFWArqMAAAhXUMCKtAAAMAAABXUg");
	var mask_graphics_129 = new cjs.Graphics().p("EhKGArqMAAAhXUMCUNAAAMAAABXUg");
	var mask_graphics_130 = new cjs.Graphics().p("EhO2ArqMAAAhXUMCdtAAAMAAABXUg");
	var mask_graphics_131 = new cjs.Graphics().p("EhTmArqMAAAhXUMCnNAAAMAAABXUg");
	var mask_graphics_132 = new cjs.Graphics().p("EhYWArqMAAAhXUMCwsAAAMAAABXUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(114).to({graphics:mask_graphics_114,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_115,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_116,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_117,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_118,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_119,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_120,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_121,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_122,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_123,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_124,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_125,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_126,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_127,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_128,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_129,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_130,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_131,x:-90.4,y:75}).wait(1).to({graphics:mask_graphics_132,x:-90.4,y:75}).wait(3));

	// grafica roja
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4,0,0,4).p("Egu+ApAQAykrEasdQFLumGItAQHqwUHLpYQIrrUHIAAQGUAAIaLMQHAJVH0QJQGZNMFYOXQEwMwAzEx");
	this.shape.setTransform(-90.5,77.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AtgCbIAqhAIgbifIA2AAIAOBpIA/hpIA4AAIiQDfgADaCUIAdhvIA5AAIg1BvgAF3BfQgSgEgLgFIAAgxIAGAAQANAIAQAGQAPAFAPAAQAJAAALgCQALgCAGgGQAFgEADgFQACgFAAgKQAAgHgDgGQgDgFgGgEQgIgCgLgCQgLgCgJAAQgNAAgMADIgWADIgGAAIAAh6ICbAAIAAAqIhmAAIAAAjIALAAIANAAQASAAAOADQAOAEAKAGQANAIAIANQAHALAAAUQAAARgGAPQgGAPgMAKQgOALgRAGQgSAFgWAAQgbAAgSgEgABBBbQgSgHgKgOQgLgPgFgVQgFgVAAgaQAAgcAFgVQAFgVALgPQALgOARgHQARgHAYAAQAZAAARAHQARAHALAPQALAOAFAVQAFAVAAAcQAAAagFAVQgFAWgLAOQgLAOgRAHQgRAIgZAAQgYAAgRgIgABRhFQgIAQAAAoQAAAlAIARQAIASARAAQASAAAIgSQAIgRAAglQAAgogIgQQgIgRgSAAQgSAAgHARgAKQBeIgagyIgxAyIg9AAIBVhTIguhPIA5AAIAaAyIAvgyIA9AAIhUBQIAvBSgAoaA3IAAgnIC7AAIAAAngAi9ARIAAglICoAAIAAAlgALxgJIAAgYQANgJANgKIAUgSQAMgLAFgJQAFgIAAgIQAAgKgHgFQgGgFgMAAQgIAAgKADQgKAEgIAGIgDAAIAAggQAHgDANgDQANgDANAAQAbAAAOALQAOAMAAAUQAAANgHANQgGAMgOANIgSAOIgMAKIBAAAIAAAbgAoagUIAAgnIC7AAIAAAng");
	this.shape_1.setTransform(293,146.7);

	this.shape.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},114).wait(21));

	// Capa 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_77 = new cjs.Graphics().p("EgBkAsaMAAAhYzIDJAAMAAABYzg");
	var mask_1_graphics_78 = new cjs.Graphics().p("EgFWAsaMAAAhYzIKtAAMAAABYzg");
	var mask_1_graphics_79 = new cjs.Graphics().p("EgJHAsaMAAAhYzISPAAMAAABYzg");
	var mask_1_graphics_80 = new cjs.Graphics().p("EgM5AsaMAAAhYzIZzAAMAAABYzg");
	var mask_1_graphics_81 = new cjs.Graphics().p("EgQrAsaMAAAhYzMAhXAAAMAAABYzg");
	var mask_1_graphics_82 = new cjs.Graphics().p("EgUdAsaMAAAhYzMAo7AAAMAAABYzg");
	var mask_1_graphics_83 = new cjs.Graphics().p("EgYPAsaMAAAhYzMAwfAAAMAAABYzg");
	var mask_1_graphics_84 = new cjs.Graphics().p("EgcBAsaMAAAhYzMA4DAAAMAAABYzg");
	var mask_1_graphics_85 = new cjs.Graphics().p("EgfzAsaMAAAhYzMA/nAAAMAAABYzg");
	var mask_1_graphics_86 = new cjs.Graphics().p("EgjlAsaMAAAhYzMBHLAAAMAAABYzg");
	var mask_1_graphics_87 = new cjs.Graphics().p("EgnWAsaMAAAhYzMBOtAAAMAAABYzg");
	var mask_1_graphics_88 = new cjs.Graphics().p("EgrIAsaMAAAhYzMBWRAAAMAAABYzg");
	var mask_1_graphics_89 = new cjs.Graphics().p("Egu6AsaMAAAhYzMBd1AAAMAAABYzg");
	var mask_1_graphics_90 = new cjs.Graphics().p("EgysAsaMAAAhYzMBlZAAAMAAABYzg");
	var mask_1_graphics_91 = new cjs.Graphics().p("Eg2eAsaMAAAhYzMBs9AAAMAAABYzg");
	var mask_1_graphics_92 = new cjs.Graphics().p("Eg6QAsaMAAAhYzMB0hAAAMAAABYzg");
	var mask_1_graphics_93 = new cjs.Graphics().p("Eg+CAsaMAAAhYzMB8FAAAMAAABYzg");
	var mask_1_graphics_94 = new cjs.Graphics().p("EhBzAsaMAAAhYzMCDnAAAMAAABYzg");
	var mask_1_graphics_95 = new cjs.Graphics().p("EhFlAsaMAAAhYzMCLLAAAMAAABYzg");
	var mask_1_graphics_96 = new cjs.Graphics().p("EhJXAsaMAAAhYzMCSvAAAMAAABYzg");
	var mask_1_graphics_97 = new cjs.Graphics().p("EhNJAsaMAAAhYzMCaTAAAMAAABYzg");
	var mask_1_graphics_98 = new cjs.Graphics().p("EhQ7AsaMAAAhYzMCh3AAAMAAABYzg");
	var mask_1_graphics_99 = new cjs.Graphics().p("EhUtAsaMAAAhYzMCpbAAAMAAABYzg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(77).to({graphics:mask_1_graphics_77,x:-89.4,y:79.7}).wait(1).to({graphics:mask_1_graphics_78,x:-89.4,y:79.7}).wait(1).to({graphics:mask_1_graphics_79,x:-89.3,y:79.7}).wait(1).to({graphics:mask_1_graphics_80,x:-89.2,y:79.7}).wait(1).to({graphics:mask_1_graphics_81,x:-89.2,y:79.7}).wait(1).to({graphics:mask_1_graphics_82,x:-89.1,y:79.7}).wait(1).to({graphics:mask_1_graphics_83,x:-89.1,y:79.7}).wait(1).to({graphics:mask_1_graphics_84,x:-89,y:79.7}).wait(1).to({graphics:mask_1_graphics_85,x:-89,y:79.7}).wait(1).to({graphics:mask_1_graphics_86,x:-88.9,y:79.7}).wait(1).to({graphics:mask_1_graphics_87,x:-88.8,y:79.7}).wait(1).to({graphics:mask_1_graphics_88,x:-88.8,y:79.7}).wait(1).to({graphics:mask_1_graphics_89,x:-88.7,y:79.7}).wait(1).to({graphics:mask_1_graphics_90,x:-88.7,y:79.7}).wait(1).to({graphics:mask_1_graphics_91,x:-88.6,y:79.7}).wait(1).to({graphics:mask_1_graphics_92,x:-88.5,y:79.7}).wait(1).to({graphics:mask_1_graphics_93,x:-88.5,y:79.7}).wait(1).to({graphics:mask_1_graphics_94,x:-88.4,y:79.7}).wait(1).to({graphics:mask_1_graphics_95,x:-88.4,y:79.7}).wait(1).to({graphics:mask_1_graphics_96,x:-88.3,y:79.7}).wait(1).to({graphics:mask_1_graphics_97,x:-88.2,y:79.7}).wait(1).to({graphics:mask_1_graphics_98,x:-88.2,y:79.7}).wait(1).to({graphics:mask_1_graphics_99,x:-88.1,y:79.7}).wait(36));

	// grafica verde
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00A52F").ss(4,0,0,4).p("EgYKApAQARhkAbk6QAimlAYkFQBdwQB7rWUAGQglAAM6AAAUALVAAAAG3AkqQCJLYB3QLQAMBsBAJGQAjFFASBq");
	this.shape_2.setTransform(-89.1,77.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A52F").s().p("Aq/CbIAqhAIgbifIA2AAIAOBpIA/hpIA4AAIiQDfgAHvBeIgagyIgxAyIg9AAIBVhTIguhPIA5AAIAaAyIAvgyIA9AAIhUBQIAvBSgAFnBeIirAAIAAgkIAngeQAUgQAMgLQARgQAIgMQAHgNAAgNQAAgPgJgIQgKgIgSAAQgNAAgPAGQgPAFgNAJIgEAAIAAgwQAKgFAUgFQAVgEAUAAQApAAAVARQAWARAAAgQAAAUgKATQgLATgVARQgNANgOAKIgTAPIBiAAIAAApgAl5A3IAAgnIC7AAIAAAngAgcARIAAglICmAAIAAAlgAJQgJIAAgYIAagTIAUgSQAMgLAFgJQAFgIAAgIQAAgKgHgFQgGgFgMAAQgIAAgKADQgKAEgIAGIgDAAIAAggQAHgDANgDQANgDANAAQAbAAAOALQAOAMAAAUQAAANgHANQgGAMgOANIgSAOIgMAKIBAAAIAAAbgAl5gUIAAgnIC7AAIAAAng");
	this.shape_3.setTransform(276.4,75.2);

	this.shape_2.mask = this.shape_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},77).wait(58));

	// Capa 3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_39 = new cjs.Graphics().p("EgC6AqiMAAAhVDIF1AAMAAABVDg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgGcAqiMAAAhVDIM5AAMAAABVDg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgJ+AqiMAAAhVDIT9AAMAAABVDg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgNgAqiMAAAhVDIbBAAMAAABVDg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgRCAqiMAAAhVDMAiFAAAMAAABVDg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgUkAqiMAAAhVDMApJAAAMAAABVDg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgYGAqiMAAAhVDMAwNAAAMAAABVDg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgboAqiMAAAhVDMA3RAAAMAAABVDg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgfKAqiMAAAhVDMA+VAAAMAAABVDg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EgisAqiMAAAhVDMBFZAAAMAAABVDg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgmPAqiMAAAhVDMBMfAAAMAAABVDg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgpxAqiMAAAhVDMBTjAAAMAAABVDg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EgtTAqiMAAAhVDMBanAAAMAAABVDg");
	var mask_2_graphics_52 = new cjs.Graphics().p("Egw1AqiMAAAhVDMBhrAAAMAAABVDg");
	var mask_2_graphics_53 = new cjs.Graphics().p("Eg0XAqiMAAAhVDMBovAAAMAAABVDg");
	var mask_2_graphics_54 = new cjs.Graphics().p("Eg35AqiMAAAhVDMBvzAAAMAAABVDg");
	var mask_2_graphics_55 = new cjs.Graphics().p("Eg7bAqiMAAAhVDMB23AAAMAAABVDg");
	var mask_2_graphics_56 = new cjs.Graphics().p("Eg+9AqiMAAAhVDMB97AAAMAAABVDg");
	var mask_2_graphics_57 = new cjs.Graphics().p("EhCfAqiMAAAhVDMCE/AAAMAAABVDg");
	var mask_2_graphics_58 = new cjs.Graphics().p("EhGCAqiMAAAhVDMCMFAAAMAAABVDg");
	var mask_2_graphics_59 = new cjs.Graphics().p("EhJkAqiMAAAhVDMCTJAAAMAAABVDg");
	var mask_2_graphics_60 = new cjs.Graphics().p("EhNGAqiMAAAhVDMCaNAAAMAAABVDg");
	var mask_2_graphics_61 = new cjs.Graphics().p("EhQoAqiMAAAhVDMChRAAAMAAABVDg");
	var mask_2_graphics_62 = new cjs.Graphics().p("EhUKAqiMAAAhVDMCoVAAAMAAABVDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(39).to({graphics:mask_2_graphics_39,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_40,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_41,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_42,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_43,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_44,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_45,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_46,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_47,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_48,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_49,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_50,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_51,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_52,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_53,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_54,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_55,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_56,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_57,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_58,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_59,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_60,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_61,x:-90.4,y:82.2}).wait(1).to({graphics:mask_2_graphics_62,x:-90.3,y:82.2}).wait(73));

	// grafica lila
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#9907D7").ss(4,0,0,4).p("EgiTApAQEI4+GBzwQFAwcFfpQQGurUHGAAQGSAAGdLMQFTJMFKQSQD8MXDePMQCcKsBIG1");
	this.shape_4.setTransform(-90.5,77.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9907D7").s().p("ApUCbIAqhAIgbifIA2AAIAOBpIA+hpIA4AAIiPDfgAGFBeIgbgyIgxAyIg9AAIBWhTIguhPIA4AAIAbAyIAugyIA9AAIhTBQIAvBSgAkOA3IAAgnIC7AAIAAAngABNARIAAglICoAAIAAAlgAHlgJIAAgYQANgJANgKIAUgSQAMgLAFgJQAFgIAAgIQAAgKgHgFQgFgFgNAAQgIAAgKADQgKAEgIAGIgCAAIAAggQAGgDAOgDQANgDANAAQAaAAAOALQAOAMAAAUQABANgIANQgGAMgOANIgSAOIgMAKIBAAAIAAAbgAkOgUIAAgnIC7AAIAAAng");
	this.shape_5.setTransform(265.4,6);

	this.shape_4.mask = this.shape_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4}]},39).wait(96));

	// Capa 2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("EgK4A3PMAAAhudIVxAAMAAABudg");
	var mask_3_graphics_1 = new cjs.Graphics().p("EgNoA3PMAAAhudIbRAAMAAABudg");
	var mask_3_graphics_2 = new cjs.Graphics().p("EgQYA3PMAAAhudMAgxAAAMAAABudg");
	var mask_3_graphics_3 = new cjs.Graphics().p("EgTIA3PMAAAhudMAmRAAAMAAABudg");
	var mask_3_graphics_4 = new cjs.Graphics().p("EgV4A3PMAAAhudMArxAAAMAAABudg");
	var mask_3_graphics_5 = new cjs.Graphics().p("EgYoA3PMAAAhudMAxRAAAMAAABudg");
	var mask_3_graphics_6 = new cjs.Graphics().p("EgbYA3PMAAAhudMA2xAAAMAAABudg");
	var mask_3_graphics_7 = new cjs.Graphics().p("EgeIA3PMAAAhudMA8RAAAMAAABudg");
	var mask_3_graphics_8 = new cjs.Graphics().p("Egg4A3PMAAAhudMBBxAAAMAAABudg");
	var mask_3_graphics_9 = new cjs.Graphics().p("EgjoA3PMAAAhudMBHRAAAMAAABudg");
	var mask_3_graphics_10 = new cjs.Graphics().p("EgmYA3PMAAAhudMBMxAAAMAAABudg");
	var mask_3_graphics_11 = new cjs.Graphics().p("EgpIA3PMAAAhudMBSRAAAMAAABudg");
	var mask_3_graphics_12 = new cjs.Graphics().p("Egr5A3PMAAAhudMBXzAAAMAAABudg");
	var mask_3_graphics_13 = new cjs.Graphics().p("EgupA3PMAAAhudMBdTAAAMAAABudg");
	var mask_3_graphics_14 = new cjs.Graphics().p("EgxZA3PMAAAhudMBizAAAMAAABudg");
	var mask_3_graphics_15 = new cjs.Graphics().p("Eg0JA3PMAAAhudMBoTAAAMAAABudg");
	var mask_3_graphics_16 = new cjs.Graphics().p("Eg25A3PMAAAhudMBtzAAAMAAABudg");
	var mask_3_graphics_17 = new cjs.Graphics().p("Eg5pA3PMAAAhudMBzTAAAMAAABudg");
	var mask_3_graphics_18 = new cjs.Graphics().p("Eg8ZA3PMAAAhudMB4zAAAMAAABudg");
	var mask_3_graphics_19 = new cjs.Graphics().p("Eg/JA3PMAAAhudMB+TAAAMAAABudg");
	var mask_3_graphics_20 = new cjs.Graphics().p("EhB5A3PMAAAhudMCDzAAAMAAABudg");
	var mask_3_graphics_21 = new cjs.Graphics().p("EhEpA3PMAAAhudMCJTAAAMAAABudg");
	var mask_3_graphics_22 = new cjs.Graphics().p("EhHZA3PMAAAhudMCOzAAAMAAABudg");
	var mask_3_graphics_23 = new cjs.Graphics().p("EhKJA3PMAAAhudMCUTAAAMAAABudg");
	var mask_3_graphics_24 = new cjs.Graphics().p("EhM5A3PMAAAhudMCZzAAAMAAABudg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-537.1,y:0.9}).wait(1).to({graphics:mask_3_graphics_1,x:-519.5,y:0.9}).wait(1).to({graphics:mask_3_graphics_2,x:-501.9,y:0.9}).wait(1).to({graphics:mask_3_graphics_3,x:-484.3,y:0.9}).wait(1).to({graphics:mask_3_graphics_4,x:-466.7,y:0.9}).wait(1).to({graphics:mask_3_graphics_5,x:-449.1,y:0.9}).wait(1).to({graphics:mask_3_graphics_6,x:-431.5,y:0.9}).wait(1).to({graphics:mask_3_graphics_7,x:-413.9,y:0.9}).wait(1).to({graphics:mask_3_graphics_8,x:-396.3,y:0.9}).wait(1).to({graphics:mask_3_graphics_9,x:-378.7,y:0.9}).wait(1).to({graphics:mask_3_graphics_10,x:-361.1,y:0.9}).wait(1).to({graphics:mask_3_graphics_11,x:-343.5,y:0.9}).wait(1).to({graphics:mask_3_graphics_12,x:-325.9,y:0.9}).wait(1).to({graphics:mask_3_graphics_13,x:-308.2,y:0.9}).wait(1).to({graphics:mask_3_graphics_14,x:-290.6,y:0.9}).wait(1).to({graphics:mask_3_graphics_15,x:-273,y:0.9}).wait(1).to({graphics:mask_3_graphics_16,x:-255.4,y:0.9}).wait(1).to({graphics:mask_3_graphics_17,x:-237.8,y:0.9}).wait(1).to({graphics:mask_3_graphics_18,x:-220.2,y:0.9}).wait(1).to({graphics:mask_3_graphics_19,x:-202.6,y:0.9}).wait(1).to({graphics:mask_3_graphics_20,x:-185,y:0.9}).wait(1).to({graphics:mask_3_graphics_21,x:-167.4,y:0.9}).wait(1).to({graphics:mask_3_graphics_22,x:-149.8,y:0.9}).wait(1).to({graphics:mask_3_graphics_23,x:-132.2,y:0.9}).wait(1).to({graphics:mask_3_graphics_24,x:-114.6,y:0.9}).wait(111));

	// ejes
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_6.setTransform(-95,267.6);

	this.text = new cjs.Text("0", "30px Verdana");
	this.text.lineHeight = 36;
	this.text.setTransform(-118.5,-219);

	this.text_1 = new cjs.Text("X", "30px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(336.2,-201.8);

	this.text_2 = new cjs.Text("Y", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-99.4,-347.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxB0IlhAAIAAjnIFhAAg");
	this.shape_7.setTransform(-90.8,-314.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiwB0IAAjnIFhAAIAADng");
	this.shape_8.setTransform(-90.8,-314.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("AGcDpIs3AAIAAnRIM3AAg");
	this.shape_9.setTransform(356.5,-186.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AmbDpIAAnRIM3AAIAAHRg");
	this.shape_10.setTransform(356.5,-186.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_11.setTransform(100.6,-181.1);

	this.text_3 = new cjs.Text("2", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(91.4,-171.5);

	this.text_4 = new cjs.Text("3", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(184.9,-171.5);

	this.text_5 = new cjs.Text("–5", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-132.5,255.4);

	this.text_6 = new cjs.Text("–3", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-134.6,71);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_12.setTransform(-94.1,82.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABa");
	this.shape_13.setTransform(193.7,-181);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_14.setTransform(6.6,-181.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_15.setTransform(-183.8,-181.4);

	this.text_7 = new cjs.Text("–1", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-204.1,-172.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_16.setTransform(-278.8,-181.8);

	this.text_8 = new cjs.Text("–2", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(-297.2,-172);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_17.setTransform(-366.3,-181.7);

	this.text_9 = new cjs.Text("–3", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-391,-171.3);

	this.text_10 = new cjs.Text("1", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-117.4,-295.4);

	this.text_11 = new cjs.Text("–1", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-131.3,-115);

	this.text_12 = new cjs.Text("–2", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-135.5,-20.4);

	this.text_13 = new cjs.Text("–4", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-133.5,163.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_18.setTransform(-94.9,-101.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_19.setTransform(-95.1,-281.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_20.setTransform(-95,175.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_21.setTransform(-94.2,-10.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_22.setTransform(284,-181);

	this.text_14 = new cjs.Text("4", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(273.1,-171.1);

	this.text_15 = new cjs.Text("1", "30px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(-2.6,-172.5);

	this.text_16 = new cjs.Text("0", "30px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(-81.5,-176.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAAAAIhGArIAAgrIBGgqIBIAqIAAArg");
	this.shape_23.setTransform(-90.8,-310.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAAzfMAAAhm9");
	this.shape_24.setTransform(-90.8,17.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgqBIIAqhIIgqhHIArAAIAqBHIgqBIg");
	this.shape_25.setTransform(322.2,-185.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(4,0,0,4).p("Eg8VAAAMB4rAAA");
	this.shape_26.setTransform(-62.7,-185.5);

	this.shape_6.mask = this.text.mask = this.text_1.mask = this.text_2.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.text_7.mask = this.shape_16.mask = this.text_8.mask = this.shape_17.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.shape_17},{t:this.text_8},{t:this.shape_16},{t:this.text_7},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape_6}]}).wait(135));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-448.9,-347.2,846.8,694.4);

(lib.GraficoAnimado_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_104 = new cjs.Graphics().p("EgEHAs3MAAAhZtIIPAAMAAABZtg");
	var mask_graphics_105 = new cjs.Graphics().p("EgIrAs3MAAAhZtIRXAAMAAABZtg");
	var mask_graphics_106 = new cjs.Graphics().p("EgNPAs3MAAAhZtIafAAMAAABZtg");
	var mask_graphics_107 = new cjs.Graphics().p("EgRyAs3MAAAhZtMAjlAAAMAAABZtg");
	var mask_graphics_108 = new cjs.Graphics().p("EgWWAs3MAAAhZtMAstAAAMAAABZtg");
	var mask_graphics_109 = new cjs.Graphics().p("Ega6As3MAAAhZtMA11AAAMAAABZtg");
	var mask_graphics_110 = new cjs.Graphics().p("EgfeAs3MAAAhZtMA+9AAAMAAABZtg");
	var mask_graphics_111 = new cjs.Graphics().p("EgkCAs3MAAAhZtMBIFAAAMAAABZtg");
	var mask_graphics_112 = new cjs.Graphics().p("EgomAs3MAAAhZtMBRNAAAMAAABZtg");
	var mask_graphics_113 = new cjs.Graphics().p("EgtKAs3MAAAhZtMBaVAAAMAAABZtg");
	var mask_graphics_114 = new cjs.Graphics().p("EgxuAs3MAAAhZtMBjdAAAMAAABZtg");
	var mask_graphics_115 = new cjs.Graphics().p("Eg2SAs3MAAAhZtMBslAAAMAAABZtg");
	var mask_graphics_116 = new cjs.Graphics().p("Eg61As3MAAAhZtMB1rAAAMAAABZtg");
	var mask_graphics_117 = new cjs.Graphics().p("Eg/ZAs3MAAAhZtMB+zAAAMAAABZtg");
	var mask_graphics_118 = new cjs.Graphics().p("EhD9As3MAAAhZtMCH7AAAMAAABZtg");
	var mask_graphics_119 = new cjs.Graphics().p("EhIhAs3MAAAhZtMCRDAAAMAAABZtg");
	var mask_graphics_120 = new cjs.Graphics().p("EhNFAs3MAAAhZtMCaLAAAMAAABZtg");
	var mask_graphics_121 = new cjs.Graphics().p("EhRpAs3MAAAhZtMCjTAAAMAAABZtg");
	var mask_graphics_122 = new cjs.Graphics().p("EhWNAs3MAAAhZtMCsbAAAMAAABZtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(104).to({graphics:mask_graphics_104,x:-73.4,y:-57.2}).wait(1).to({graphics:mask_graphics_105,x:-73.4,y:-57.2}).wait(1).to({graphics:mask_graphics_106,x:-73.4,y:-57.2}).wait(1).to({graphics:mask_graphics_107,x:-73.3,y:-57.2}).wait(1).to({graphics:mask_graphics_108,x:-73.3,y:-57.2}).wait(1).to({graphics:mask_graphics_109,x:-73.3,y:-57.2}).wait(1).to({graphics:mask_graphics_110,x:-73.3,y:-57.2}).wait(1).to({graphics:mask_graphics_111,x:-73.2,y:-57.2}).wait(1).to({graphics:mask_graphics_112,x:-73.2,y:-57.2}).wait(1).to({graphics:mask_graphics_113,x:-73.2,y:-57.2}).wait(1).to({graphics:mask_graphics_114,x:-73.1,y:-57.2}).wait(1).to({graphics:mask_graphics_115,x:-73.1,y:-57.2}).wait(1).to({graphics:mask_graphics_116,x:-73.1,y:-57.2}).wait(1).to({graphics:mask_graphics_117,x:-73.1,y:-57.2}).wait(1).to({graphics:mask_graphics_118,x:-73,y:-57.2}).wait(1).to({graphics:mask_graphics_119,x:-73,y:-57.2}).wait(1).to({graphics:mask_graphics_120,x:-73,y:-57.2}).wait(1).to({graphics:mask_graphics_121,x:-73,y:-57.2}).wait(1).to({graphics:mask_graphics_122,x:-72.9,y:-57.2}).wait(11));

	// grafica azul
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00A1C9").ss(4,0,0,4).p("EAu/go/QgyEskaMcQlLOmmINAQnqQUnLJYQorLUnIAAQmUAAoarMQnApVn0wJQmZtMlYuXQkwswgzkx");
	this.shape.setTransform(-75.9,-42.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A1C9").s().p("Ar1CbIAqhAIgbifIA2AAIAOBpIA/hpIA4AAIiQDfgABvCUIAdhvIA5AAIg0BvgAENBfQgTgEgLgFIAAgxIAGAAQAOAIAPAGQAPAFAQAAQAIAAAMgCQAKgCAHgGQAFgEACgFQACgFABgKQAAgHgEgGQgDgFgGgEQgHgCgMgCQgLgCgJAAQgNAAgMADIgVADIgHAAIAAh6ICbAAIAAAqIhmAAIAAAjIALAAIANAAQASAAAOADQAOAEAKAGQANAIAIANQAHALAAAUQABARgHAPQgGAPgMAKQgNALgSAGQgRAFgXAAQgbAAgRgEgAgoBbQgSgHgKgOQgLgPgFgVQgFgVABgaQAAgcAEgVQAGgVAKgPQALgOARgHQARgHAXAAQAZAAAQAHQASAHAKAPQALAOAFAVQAFAVAAAcQAAAagFAVQgFAWgLAOQgKAOgSAHQgQAIgZAAQgXAAgRgIgAgYhFQgIAQAAAoQAAAlAIARQAIASAQAAQARAAAJgSQAHgRAAglQAAgogHgQQgJgRgRAAQgRAAgHARgAImBeIgbgyIgxAyIg8AAIBUhTIgthPIA4AAIAaAyIAvgyIA9AAIhTBQIAuBSgAmvA3IAAgnIC7AAIAAAngAKHgJIAAgYIAZgTIAVgSQALgLAFgJQAFgIAAgIQAAgKgHgFQgFgFgNAAQgIAAgKADQgJAEgJAGIgDAAIAAggQAHgDANgDQANgDANAAQAcAAAOALQAOAMgBAUQABANgIANQgGAMgOANIgSAOIgMAKIBAAAIAAAbgAmvgUIAAgnIC7AAIAAAng");
	this.shape_1.setTransform(317,-84.4);

	this.shape.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},104).wait(29));

	// Capa 4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_72 = new cjs.Graphics().p("EgCrAuAMAAAhb/IFXAAMAAABb/g");
	var mask_1_graphics_73 = new cjs.Graphics().p("EgG/AuAMAAAhb/IN/AAMAAABb/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("EgLTAuAMAAAhb/IWnAAMAAABb/g");
	var mask_1_graphics_75 = new cjs.Graphics().p("EgPnAuAMAAAhb/IfPAAMAAABb/g");
	var mask_1_graphics_76 = new cjs.Graphics().p("EgT6AuAMAAAhb/MAn1AAAMAAABb/g");
	var mask_1_graphics_77 = new cjs.Graphics().p("EgYOAuAMAAAhb/MAwdAAAMAAABb/g");
	var mask_1_graphics_78 = new cjs.Graphics().p("EgciAuAMAAAhb/MA5FAAAMAAABb/g");
	var mask_1_graphics_79 = new cjs.Graphics().p("Egg2AuAMAAAhb/MBBtAAAMAAABb/g");
	var mask_1_graphics_80 = new cjs.Graphics().p("EglKAuAMAAAhb/MBKVAAAMAAABb/g");
	var mask_1_graphics_81 = new cjs.Graphics().p("EgpeAuAMAAAhb/MBS9AAAMAAABb/g");
	var mask_1_graphics_82 = new cjs.Graphics().p("EgtyAuAMAAAhb/MBblAAAMAAABb/g");
	var mask_1_graphics_83 = new cjs.Graphics().p("EgyGAuAMAAAhb/MBkNAAAMAAABb/g");
	var mask_1_graphics_84 = new cjs.Graphics().p("Eg2aAuAMAAAhb/MBs1AAAMAAABb/g");
	var mask_1_graphics_85 = new cjs.Graphics().p("Eg6uAuAMAAAhb/MB1dAAAMAAABb/g");
	var mask_1_graphics_86 = new cjs.Graphics().p("Eg/CAuAMAAAhb/MB+FAAAMAAABb/g");
	var mask_1_graphics_87 = new cjs.Graphics().p("EhDWAuAMAAAhb/MCGtAAAMAAABb/g");
	var mask_1_graphics_88 = new cjs.Graphics().p("EhHqAuAMAAAhb/MCPVAAAMAAABb/g");
	var mask_1_graphics_89 = new cjs.Graphics().p("EhL+AuAMAAAhb/MCX9AAAMAAABb/g");
	var mask_1_graphics_90 = new cjs.Graphics().p("EhQSAuAMAAAhb/MCglAAAMAAABb/g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(72).to({graphics:mask_1_graphics_72,x:-73.7,y:-49.9}).wait(1).to({graphics:mask_1_graphics_73,x:-73.7,y:-49.9}).wait(1).to({graphics:mask_1_graphics_74,x:-73.6,y:-49.9}).wait(1).to({graphics:mask_1_graphics_75,x:-73.6,y:-49.9}).wait(1).to({graphics:mask_1_graphics_76,x:-73.6,y:-49.9}).wait(1).to({graphics:mask_1_graphics_77,x:-73.5,y:-49.9}).wait(1).to({graphics:mask_1_graphics_78,x:-73.5,y:-49.9}).wait(1).to({graphics:mask_1_graphics_79,x:-73.4,y:-49.9}).wait(1).to({graphics:mask_1_graphics_80,x:-73.4,y:-49.9}).wait(1).to({graphics:mask_1_graphics_81,x:-73.4,y:-49.9}).wait(1).to({graphics:mask_1_graphics_82,x:-73.3,y:-49.9}).wait(1).to({graphics:mask_1_graphics_83,x:-73.3,y:-49.9}).wait(1).to({graphics:mask_1_graphics_84,x:-73.2,y:-49.9}).wait(1).to({graphics:mask_1_graphics_85,x:-73.2,y:-49.9}).wait(1).to({graphics:mask_1_graphics_86,x:-73.2,y:-49.9}).wait(1).to({graphics:mask_1_graphics_87,x:-73.1,y:-49.9}).wait(1).to({graphics:mask_1_graphics_88,x:-73.1,y:-49.9}).wait(1).to({graphics:mask_1_graphics_89,x:-73,y:-49.9}).wait(1).to({graphics:mask_1_graphics_90,x:-73,y:-49.9}).wait(43));

	// grafica naranja
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF8000").ss(4,0,0,4).p("EAYLgo/QgQBkgbE6QgQC8gqHuQheQRh7LVUgGQAlAgM5AAAUgLWAAAgG3gkqQiIrYh3wLQgMhjhBpPQgjlFgShq");
	this.shape_2.setTransform(-77.3,-42.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF8000").s().p("ApUCbIAqhAIgbifIA2AAIAOBpIA+hpIA4AAIiPDfgAGFBeIgbgyIgxAyIg8AAIisAAIAAgkIAogeQATgQAMgLQARgQAIgMQAHgNABgNQAAgPgKgIQgJgIgSAAQgOAAgPAGQgPAFgMAJIgFAAIAAgwQAKgFAVgFQAUgEAUAAQApAAAVARQAWARAAAgQAAAUgKATQgLATgUARQgOANgNAKIgTAPIBiAAIAAApIBUhTIgthPIA4AAIAaAyIAvgyIA9AAIhTBQIAuBSgAkOA3IAAgnIC7AAIAAAngAHlgJIAAgYQANgJANgKIAVgSQALgLAFgJQAFgIAAgIQAAgKgHgFQgFgFgNAAQgIAAgKADQgKAEgIAGIgCAAIAAggQAGgDANgDQANgDANAAQAcAAAOALQAOAMgBAUQABANgIANQgGAMgOANIgSAOIgMAKIBAAAIAAAbgAkOgUIAAgnIC7AAIAAAng");
	this.shape_3.setTransform(302.4,-155.9);

	this.shape_2.mask = this.shape_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},72).wait(61));

	// Capa 3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_39 = new cjs.Graphics().p("EgCrAs1MAAAhZpIFXAAMAAABZpg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgGiAs1MAAAhZpINFAAMAAABZpg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgKZAs1MAAAhZpIUzAAMAAABZpg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgOQAs1MAAAhZpIchAAMAAABZpg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgSHAs1MAAAhZpMAkPAAAMAAABZpg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgV9As1MAAAhZpMAr7AAAMAAABZpg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgZ0As1MAAAhZpMAzpAAAMAAABZpg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgdrAs1MAAAhZpMA7XAAAMAAABZpg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EghiAs1MAAAhZpMBDFAAAMAAABZpg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EglZAs1MAAAhZpMBKzAAAMAAABZpg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgpQAs1MAAAhZpMBShAAAMAAABZpg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgtHAs1MAAAhZpMBaPAAAMAAABZpg");
	var mask_2_graphics_51 = new cjs.Graphics().p("Egw+As1MAAAhZpMBh9AAAMAAABZpg");
	var mask_2_graphics_52 = new cjs.Graphics().p("Eg01As1MAAAhZpMBprAAAMAAABZpg");
	var mask_2_graphics_53 = new cjs.Graphics().p("Eg4sAs1MAAAhZpMBxZAAAMAAABZpg");
	var mask_2_graphics_54 = new cjs.Graphics().p("Eg8jAs1MAAAhZpMB5HAAAMAAABZpg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EhAaAs1MAAAhZpMCA1AAAMAAABZpg");
	var mask_2_graphics_56 = new cjs.Graphics().p("EhERAs1MAAAhZpMCIjAAAMAAABZpg");
	var mask_2_graphics_57 = new cjs.Graphics().p("EhIIAs1MAAAhZpMCQRAAAMAAABZpg");
	var mask_2_graphics_58 = new cjs.Graphics().p("EhL/As1MAAAhZpMCX/AAAMAAABZpg");
	var mask_2_graphics_59 = new cjs.Graphics().p("EhP2As1MAAAhZpMCftAAAMAAABZpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(39).to({graphics:mask_2_graphics_39,x:-73.7,y:-42.3}).wait(1).to({graphics:mask_2_graphics_40,x:-73.7,y:-42.3}).wait(1).to({graphics:mask_2_graphics_41,x:-73.6,y:-42.3}).wait(1).to({graphics:mask_2_graphics_42,x:-73.5,y:-42.3}).wait(1).to({graphics:mask_2_graphics_43,x:-73.4,y:-42.3}).wait(1).to({graphics:mask_2_graphics_44,x:-73.4,y:-42.3}).wait(1).to({graphics:mask_2_graphics_45,x:-73.3,y:-42.3}).wait(1).to({graphics:mask_2_graphics_46,x:-73.2,y:-42.3}).wait(1).to({graphics:mask_2_graphics_47,x:-73.1,y:-42.3}).wait(1).to({graphics:mask_2_graphics_48,x:-73.1,y:-42.3}).wait(1).to({graphics:mask_2_graphics_49,x:-73,y:-42.3}).wait(1).to({graphics:mask_2_graphics_50,x:-72.9,y:-42.3}).wait(1).to({graphics:mask_2_graphics_51,x:-72.8,y:-42.3}).wait(1).to({graphics:mask_2_graphics_52,x:-72.8,y:-42.3}).wait(1).to({graphics:mask_2_graphics_53,x:-72.7,y:-42.3}).wait(1).to({graphics:mask_2_graphics_54,x:-72.6,y:-42.3}).wait(1).to({graphics:mask_2_graphics_55,x:-72.5,y:-42.3}).wait(1).to({graphics:mask_2_graphics_56,x:-72.5,y:-42.3}).wait(1).to({graphics:mask_2_graphics_57,x:-72.4,y:-42.3}).wait(1).to({graphics:mask_2_graphics_58,x:-72.3,y:-42.3}).wait(1).to({graphics:mask_2_graphics_59,x:-72.2,y:-42.3}).wait(74));

	// grafica lila
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#C807D7").ss(4,0,0,4).p("EAiUgo/QkIY+mBTwQlAQclfJQQmtLUnHAAQmSAAmdrMQlSpMlLwSQj8sXjevMQicqthIm0");
	this.shape_4.setTransform(-75.9,-42.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C807D7").s().p("AnpCbIAqhAIgbifIA2AAIAOBpIA+hpIA4AAIiPDfgAEaBeIgbgyIgxAyIg8AAIBVhTIguhPIA4AAIAbAyIAvgyIA9AAIhUBQIAvBSgAijA3IAAgnIC5AAIAAAngAF7gJIAAgYQANgJAMgKIAVgSQALgLAFgJQAFgIAAgIQAAgKgGgFQgGgFgMAAQgJAAgJADQgKAEgIAGIgDAAIAAggQAGgDAOgDQANgDANAAQAbAAAOALQAOAMAAAUQAAANgHANQgHAMgOANIgRAOIgNAKIBAAAIAAAbgAijgUIAAgnIC5AAIAAAng");
	this.shape_5.setTransform(292.7,-221.2);

	this.shape_4.mask = this.shape_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4}]},39).wait(94));

	// Capa 2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("EgFxA7xMAAAh3iILjAAMAAAB3ig");
	var mask_3_graphics_1 = new cjs.Graphics().p("EgJCA7xMAAAh3iISFAAMAAAB3ig");
	var mask_3_graphics_2 = new cjs.Graphics().p("EgMSA7xMAAAh3iIYlAAMAAAB3ig");
	var mask_3_graphics_3 = new cjs.Graphics().p("EgPjA7xMAAAh3iIfHAAMAAAB3ig");
	var mask_3_graphics_4 = new cjs.Graphics().p("EgS0A7xMAAAh3iMAlpAAAMAAAB3ig");
	var mask_3_graphics_5 = new cjs.Graphics().p("EgWFA7xMAAAh3iMAsLAAAMAAAB3ig");
	var mask_3_graphics_6 = new cjs.Graphics().p("EgZWA7xMAAAh3iMAytAAAMAAAB3ig");
	var mask_3_graphics_7 = new cjs.Graphics().p("EgcnA7xMAAAh3iMA5PAAAMAAAB3ig");
	var mask_3_graphics_8 = new cjs.Graphics().p("Egf3A7xMAAAh3iMA/vAAAMAAAB3ig");
	var mask_3_graphics_9 = new cjs.Graphics().p("EgjIA7xMAAAh3iMBGRAAAMAAAB3ig");
	var mask_3_graphics_10 = new cjs.Graphics().p("EgmZA7xMAAAh3iMBMzAAAMAAAB3ig");
	var mask_3_graphics_11 = new cjs.Graphics().p("EgpqA7xMAAAh3iMBTVAAAMAAAB3ig");
	var mask_3_graphics_12 = new cjs.Graphics().p("Egs7A7xMAAAh3iMBZ3AAAMAAAB3ig");
	var mask_3_graphics_13 = new cjs.Graphics().p("EgwMA7xMAAAh3iMBgZAAAMAAAB3ig");
	var mask_3_graphics_14 = new cjs.Graphics().p("EgzdA7xMAAAh3iMBm7AAAMAAAB3ig");
	var mask_3_graphics_15 = new cjs.Graphics().p("Eg2tA7xMAAAh3iMBtbAAAMAAAB3ig");
	var mask_3_graphics_16 = new cjs.Graphics().p("Eg5+A7xMAAAh3iMBz9AAAMAAAB3ig");
	var mask_3_graphics_17 = new cjs.Graphics().p("Eg9PA7xMAAAh3iMB6fAAAMAAAB3ig");
	var mask_3_graphics_18 = new cjs.Graphics().p("EhAgA7xMAAAh3iMCBBAAAMAAAB3ig");
	var mask_3_graphics_19 = new cjs.Graphics().p("EhDxA7xMAAAh3iMCHjAAAMAAAB3ig");
	var mask_3_graphics_20 = new cjs.Graphics().p("EhHCA7xMAAAh3iMCOFAAAMAAAB3ig");
	var mask_3_graphics_21 = new cjs.Graphics().p("EhKSA7xMAAAh3iMCUlAAAMAAAB3ig");
	var mask_3_graphics_22 = new cjs.Graphics().p("EhNjA7xMAAAh3iMCbHAAAMAAAB3ig");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-524.3,y:-9.3}).wait(1).to({graphics:mask_3_graphics_1,x:-503.4,y:-9.3}).wait(1).to({graphics:mask_3_graphics_2,x:-482.5,y:-9.3}).wait(1).to({graphics:mask_3_graphics_3,x:-461.6,y:-9.3}).wait(1).to({graphics:mask_3_graphics_4,x:-440.7,y:-9.3}).wait(1).to({graphics:mask_3_graphics_5,x:-419.9,y:-9.3}).wait(1).to({graphics:mask_3_graphics_6,x:-399,y:-9.3}).wait(1).to({graphics:mask_3_graphics_7,x:-378.1,y:-9.3}).wait(1).to({graphics:mask_3_graphics_8,x:-357.2,y:-9.3}).wait(1).to({graphics:mask_3_graphics_9,x:-336.3,y:-9.3}).wait(1).to({graphics:mask_3_graphics_10,x:-315.4,y:-9.3}).wait(1).to({graphics:mask_3_graphics_11,x:-294.6,y:-9.3}).wait(1).to({graphics:mask_3_graphics_12,x:-273.7,y:-9.3}).wait(1).to({graphics:mask_3_graphics_13,x:-252.8,y:-9.3}).wait(1).to({graphics:mask_3_graphics_14,x:-231.9,y:-9.3}).wait(1).to({graphics:mask_3_graphics_15,x:-211,y:-9.3}).wait(1).to({graphics:mask_3_graphics_16,x:-190.1,y:-9.3}).wait(1).to({graphics:mask_3_graphics_17,x:-169.2,y:-9.3}).wait(1).to({graphics:mask_3_graphics_18,x:-148.4,y:-9.3}).wait(1).to({graphics:mask_3_graphics_19,x:-127.5,y:-9.3}).wait(1).to({graphics:mask_3_graphics_20,x:-106.6,y:-9.3}).wait(1).to({graphics:mask_3_graphics_21,x:-85.7,y:-9.3}).wait(1).to({graphics:mask_3_graphics_22,x:-64.8,y:-9.3}).wait(111));

	// ejes
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_6.setTransform(-77.8,311.7);

	this.text = new cjs.Text("–1", "30px Verdana");
	this.text.lineHeight = 36;
	this.text.setTransform(-117.3,298.6);

	this.text_1 = new cjs.Text("X", "30px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(386.7,204.9);

	this.text_2 = new cjs.Text("Y", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-80.8,-348.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxDpIlhAAIAAnRIFhAAg");
	this.shape_7.setTransform(-73.2,-329.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_8.setTransform(-73.2,-329.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxjoIAAHRIlhAAIAAnRg");
	this.shape_9.setTransform(395.5,219.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_10.setTransform(395.5,219.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_11.setTransform(108.1,225.6);

	this.text_3 = new cjs.Text("2", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(97.9,235.2);

	this.text_4 = new cjs.Text("3", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(189.4,235.1);

	this.text_5 = new cjs.Text("0", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-97.9,190.8);

	this.text_6 = new cjs.Text("2", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-100,30.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_12.setTransform(-76.5,42.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_13.setTransform(198.2,225.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_14.setTransform(18.1,224.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_15.setTransform(-163.2,227.2);

	this.text_7 = new cjs.Text("–1", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-183.6,233.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_16.setTransform(-251.3,226.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_17.setTransform(-339.8,226.9);

	this.text_8 = new cjs.Text("–3", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(-364.5,233.4);

	this.text_9 = new cjs.Text("–2", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-269.7,232.7);

	this.text_10 = new cjs.Text("5", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-99.8,-246);

	this.text_11 = new cjs.Text("4", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-100.7,-153.6);

	this.text_12 = new cjs.Text("3", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-100.9,-61);

	this.text_13 = new cjs.Text("1", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-98.9,118.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_18.setTransform(-75.3,-139.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_19.setTransform(-75.5,-231.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_20.setTransform(-75.4,130.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_21.setTransform(-76.6,-51.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_22.setTransform(288.5,225.7);

	this.text_14 = new cjs.Text("4", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(277.6,235.5);

	this.text_15 = new cjs.Text("1", "30px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(7.9,234.2);

	this.text_16 = new cjs.Text("0", "30px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(-66,230);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAAAAIhHAqIAAgqIBHgpIBHApIAAAqg");
	this.shape_23.setTransform(-73.2,-328.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA1SMAAAhqi");
	this.shape_24.setTransform(-73.2,11.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgpBIIAphIIgphGIAqAAIAqBGIgqBIg");
	this.shape_25.setTransform(394.3,221.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(4,0,0,4).p("EhAwAAAMCBhAAA");
	this.shape_26.setTransform(-18.9,221.2);

	this.shape_6.mask = this.text.mask = this.text_1.mask = this.text_2.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.text_7.mask = this.shape_16.mask = this.shape_17.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.shape_17},{t:this.shape_16},{t:this.text_7},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.shape_6}]}).wait(133));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-433.4,-352.6,846.8,705.3);


(lib.GraficoAnimado_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_42 = new cjs.Graphics().p("AM0fnMAAAg+eIEOAAMAAAA+eg");
	var mask_graphics_43 = new cjs.Graphics().p("AjbfPMAAAg+dIG3AAMAAAA+dg");
	var mask_graphics_44 = new cjs.Graphics().p("AkwfPMAAAg+dIJhAAMAAAA+dg");
	var mask_graphics_45 = new cjs.Graphics().p("AmFfPMAAAg+dIMLAAMAAAA+dg");
	var mask_graphics_46 = new cjs.Graphics().p("AnafPMAAAg+dIO1AAMAAAA+dg");
	var mask_graphics_47 = new cjs.Graphics().p("AowfPMAAAg+dIRhAAMAAAA+dg");
	var mask_graphics_48 = new cjs.Graphics().p("AqFfPMAAAg+dIULAAMAAAA+dg");
	var mask_graphics_49 = new cjs.Graphics().p("ArafPMAAAg+dIW1AAMAAAA+dg");
	var mask_graphics_50 = new cjs.Graphics().p("AsvfPMAAAg+dIZfAAMAAAA+dg");
	var mask_graphics_51 = new cjs.Graphics().p("AuEfPMAAAg+dIcJAAMAAAA+dg");
	var mask_graphics_52 = new cjs.Graphics().p("AvafPMAAAg+dIe1AAMAAAA+dg");
	var mask_graphics_53 = new cjs.Graphics().p("AwvfPMAAAg+dMAhfAAAMAAAA+dg");
	var mask_graphics_54 = new cjs.Graphics().p("AyEfPMAAAg+dMAkJAAAMAAAA+dg");
	var mask_graphics_55 = new cjs.Graphics().p("AzZfPMAAAg+dMAmzAAAMAAAA+dg");
	var mask_graphics_56 = new cjs.Graphics().p("A0vfPMAAAg+dMApfAAAMAAAA+dg");
	var mask_graphics_57 = new cjs.Graphics().p("A2EfPMAAAg+dMAsJAAAMAAAA+dg");
	var mask_graphics_58 = new cjs.Graphics().p("A3ZfPMAAAg+dMAuzAAAMAAAA+dg");
	var mask_graphics_59 = new cjs.Graphics().p("A4ufPMAAAg+dMAxdAAAMAAAA+dg");
	var mask_graphics_60 = new cjs.Graphics().p("A6DfPMAAAg+dMA0HAAAMAAAA+dg");
	var mask_graphics_61 = new cjs.Graphics().p("A7ZfPMAAAg+dMA2zAAAMAAAA+dg");
	var mask_graphics_62 = new cjs.Graphics().p("A8ufPMAAAg+dMA5dAAAMAAAA+dg");
	var mask_graphics_63 = new cjs.Graphics().p("A+DfPMAAAg+dMA8HAAAMAAAA+dg");
	var mask_graphics_64 = new cjs.Graphics().p("A/YfPMAAAg+dMA+xAAAMAAAA+dg");
	var mask_graphics_65 = new cjs.Graphics().p("EgguAfnMAAAg+eMBBdAAAMAAAA+eg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(42).to({graphics:mask_graphics_42,x:109.1,y:202.3}).wait(1).to({graphics:mask_graphics_43,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_44,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_45,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_46,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_47,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_48,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_49,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_50,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_51,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_52,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_53,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_54,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_55,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_56,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_57,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_58,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_59,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_60,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_61,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_62,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_63,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_64,x:204.6,y:204.6}).wait(1).to({graphics:mask_graphics_65,x:204.6,y:202.3}).wait(41));

	// Capa 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#C807D7").ss(2,0,0,4).p("EAiTgo7QkHY+mCTwQlAQcleJQQmuLVnGAAQmTAAmcrNQlTpLlLwSQj7sYjevLQidqthIm1");
	this.shape.setTransform(202.7,175.5,0.567,0.567);

	this.shape.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},42).wait(64));

	// Capa 8
	this.text = new cjs.Text("(0, 0)", "bold 18px Verdana", "#3366CC");
	this.text.lineHeight = 20;
	this.text.lineWidth = 100;
	this.text.setTransform(244.3,293.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3366CC").s().p("AgbAbQgMgLAAgQQAAgPAMgMQAMgMAPABQAQgBAMAMQALAMABAPQgBAQgLALQgMAMgQAAQgPAAgMgMg");
	this.shape_1.setTransform(204.1,324.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text}]},24).wait(82));

	// Capa 7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgD4AhRMAAAhChIHxAAMAAABChg");
	var mask_1_graphics_1 = new cjs.Graphics().p("EgF8AhRMAAAhChIL5AAMAAABChg");
	var mask_1_graphics_2 = new cjs.Graphics().p("EgH/AhRMAAAhChIP/AAMAAABChg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EgKCAhRMAAAhChIUFAAMAAABChg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EgMFAhRMAAAhChIYLAAMAAABChg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EgOIAhRMAAAhChIcRAAMAAABChg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EgQLAhRMAAAhChMAgXAAAMAAABChg");
	var mask_1_graphics_7 = new cjs.Graphics().p("EgSOAhRMAAAhChMAkdAAAMAAABChg");
	var mask_1_graphics_8 = new cjs.Graphics().p("EgURAhRMAAAhChMAojAAAMAAABChg");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgWUAhRMAAAhChMAspAAAMAAABChg");
	var mask_1_graphics_10 = new cjs.Graphics().p("EgYXAhRMAAAhChMAwvAAAMAAABChg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgaaAhRMAAAhChMA01AAAMAAABChg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgcdAhRMAAAhChMA47AAAMAAABChg");
	var mask_1_graphics_13 = new cjs.Graphics().p("EgegAhRMAAAhChMA9BAAAMAAABChg");
	var mask_1_graphics_14 = new cjs.Graphics().p("EggjAhRMAAAhChMBBHAAAMAAABChg");
	var mask_1_graphics_15 = new cjs.Graphics().p("EgimAhRMAAAhChMBFNAAAMAAABChg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EgkpAhRMAAAhChMBJTAAAMAAABChg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EgmsAhRMAAAhChMBNZAAAMAAABChg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EgovAhRMAAAhChMBRfAAAMAAABChg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgqyAhRMAAAhChMBVmAAAMAAABChg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-41.8,y:198.6}).wait(1).to({graphics:mask_1_graphics_1,x:-28.7,y:198.6}).wait(1).to({graphics:mask_1_graphics_2,x:-15.6,y:198.6}).wait(1).to({graphics:mask_1_graphics_3,x:-2.5,y:198.6}).wait(1).to({graphics:mask_1_graphics_4,x:10.5,y:198.6}).wait(1).to({graphics:mask_1_graphics_5,x:23.6,y:198.6}).wait(1).to({graphics:mask_1_graphics_6,x:36.7,y:198.6}).wait(1).to({graphics:mask_1_graphics_7,x:49.8,y:198.6}).wait(1).to({graphics:mask_1_graphics_8,x:62.9,y:198.6}).wait(1).to({graphics:mask_1_graphics_9,x:76,y:198.6}).wait(1).to({graphics:mask_1_graphics_10,x:89.2,y:198.6}).wait(1).to({graphics:mask_1_graphics_11,x:102.3,y:198.6}).wait(1).to({graphics:mask_1_graphics_12,x:115.4,y:198.6}).wait(1).to({graphics:mask_1_graphics_13,x:128.5,y:198.6}).wait(1).to({graphics:mask_1_graphics_14,x:141.6,y:198.6}).wait(1).to({graphics:mask_1_graphics_15,x:154.7,y:198.6}).wait(1).to({graphics:mask_1_graphics_16,x:167.8,y:198.6}).wait(1).to({graphics:mask_1_graphics_17,x:180.9,y:198.6}).wait(1).to({graphics:mask_1_graphics_18,x:194,y:198.6}).wait(1).to({graphics:mask_1_graphics_19,x:207.1,y:198.6}).wait(87));

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_2.setTransform(201.7,376.7,0.567,0.567);

	this.text_1 = new cjs.Text("–1", "30px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(179.3,369.3,0.567,0.567);

	this.text_2 = new cjs.Text("X", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(465.1,316.2,0.567,0.567);

	this.text_3 = new cjs.Text("Y", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(200,2.2,0.567,0.567);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxDpIlhAAIAAnRIFhAAg");
	this.shape_3.setTransform(204.3,13.2,0.567,0.567);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_4.setTransform(204.3,13.2,0.567,0.567);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxjoIAAHRIlhAAIAAnRg");
	this.shape_5.setTransform(470.1,324.6,0.567,0.567);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_6.setTransform(470.1,324.6,0.567,0.567);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_7.setTransform(307.1,327.9,0.567,0.567);

	this.text_4 = new cjs.Text("2", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(301.3,333.4,0.567,0.567);

	this.text_5 = new cjs.Text("3", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(353.2,333.3,0.567,0.567);

	this.text_6 = new cjs.Text("0", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(190.3,308.2,0.567,0.567);

	this.text_7 = new cjs.Text("2", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(189.1,217.3,0.567,0.567);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_8.setTransform(202.4,223.9,0.567,0.567);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_9.setTransform(358.2,327.9,0.567,0.567);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_10.setTransform(256.1,327.3,0.567,0.567);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_11.setTransform(153.2,328.8,0.567,0.567);

	this.text_8 = new cjs.Text("–1", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(141.7,332.7,0.567,0.567);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_12.setTransform(103.3,328.6,0.567,0.567);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_13.setTransform(53.1,328.7,0.567,0.567);

	this.text_9 = new cjs.Text("–3", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(39.1,332.3,0.567,0.567);

	this.text_10 = new cjs.Text("–2", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(92.8,332,0.567,0.567);

	this.text_11 = new cjs.Text("5", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(189.2,60.5,0.567,0.567);

	this.text_12 = new cjs.Text("4", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(188.7,112.9,0.567,0.567);

	this.text_13 = new cjs.Text("3", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(188.6,165.4,0.567,0.567);

	this.text_14 = new cjs.Text("1", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(189.7,267.3,0.567,0.567);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_14.setTransform(203.1,120.7,0.567,0.567);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_15.setTransform(203,68.4,0.567,0.567);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_16.setTransform(203,274,0.567,0.567);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_17.setTransform(202.3,170.9,0.567,0.567);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_18.setTransform(409.4,327.9,0.567,0.567);

	this.text_15 = new cjs.Text("4", "30px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(403.2,333.6,0.567,0.567);

	this.text_16 = new cjs.Text("1", "30px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(250.3,332.8,0.567,0.567);

	this.text_17 = new cjs.Text("0", "30px Verdana");
	this.text_17.lineHeight = 36;
	this.text_17.setTransform(208.4,330.4,0.567,0.567);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#C807D7").ss(2,0,0,4).p("ABHAoIhHgoIhGAoIAAgrIBGgpIBHApg");
	this.shape_19.setTransform(204.3,14.1,0.567,0.567);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAAAAIhHAqIAAgqIBHgpIBHApIAAAqg");
	this.shape_20.setTransform(204.3,13.9,0.567,0.567);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAA1SMAAAhqi");
	this.shape_21.setTransform(204.3,206.6,0.567,0.567);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#C807D7").ss(2,0,0,4).p("AgnBIIAohIIgohGIAqAAIAqBGIgqBIg");
	this.shape_22.setTransform(469.3,325.4,0.567,0.567);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgpBIIAphIIgphGIAqAAIAqBGIgqBIg");
	this.shape_23.setTransform(469.4,325.4,0.567,0.567);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2,0,0,4).p("EhAwAAAMCBhAAA");
	this.shape_24.setTransform(235,325.4,0.567,0.567);

	this.shape_2.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.text_8.mask = this.shape_12.mask = this.shape_13.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.shape_13},{t:this.shape_12},{t:this.text_8},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_2}]}).wait(106));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(39.1,0,441.1,385.8);


(lib.GraficoAnimado_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_161 = new cjs.Graphics().p("AnycCMAAAg4DIPmAAMAAAA4Dg");
	var mask_graphics_162 = new cjs.Graphics().p("AoicCMAAAg4DIRFAAMAAAA4Dg");
	var mask_graphics_163 = new cjs.Graphics().p("ApScCMAAAg4DISlAAMAAAA4Dg");
	var mask_graphics_164 = new cjs.Graphics().p("AqBcCMAAAg4DIUDAAMAAAA4Dg");
	var mask_graphics_165 = new cjs.Graphics().p("AqxcCMAAAg4DIVjAAMAAAA4Dg");
	var mask_graphics_166 = new cjs.Graphics().p("ArhcCMAAAg4DIXDAAMAAAA4Dg");
	var mask_graphics_167 = new cjs.Graphics().p("AsQcCMAAAg4DIYhAAMAAAA4Dg");
	var mask_graphics_168 = new cjs.Graphics().p("AtAcCMAAAg4DIaBAAMAAAA4Dg");
	var mask_graphics_169 = new cjs.Graphics().p("AtvcCMAAAg4DIbfAAMAAAA4Dg");
	var mask_graphics_170 = new cjs.Graphics().p("AufcCMAAAg4DIc/AAMAAAA4Dg");
	var mask_graphics_171 = new cjs.Graphics().p("AvPcCMAAAg4DIefAAMAAAA4Dg");
	var mask_graphics_172 = new cjs.Graphics().p("Av+cCMAAAg4DIf9AAMAAAA4Dg");
	var mask_graphics_173 = new cjs.Graphics().p("AwucCMAAAg4DMAhdAAAMAAAA4Dg");
	var mask_graphics_174 = new cjs.Graphics().p("AxdcCMAAAg4DMAi7AAAMAAAA4Dg");
	var mask_graphics_175 = new cjs.Graphics().p("AyNcCMAAAg4DMAkbAAAMAAAA4Dg");
	var mask_graphics_176 = new cjs.Graphics().p("Ay9cCMAAAg4DMAl7AAAMAAAA4Dg");
	var mask_graphics_177 = new cjs.Graphics().p("AzscCMAAAg4DMAnZAAAMAAAA4Dg");
	var mask_graphics_178 = new cjs.Graphics().p("A0ccCMAAAg4DMAo5AAAMAAAA4Dg");
	var mask_graphics_179 = new cjs.Graphics().p("A1LcCMAAAg4DMAqXAAAMAAAA4Dg");
	var mask_graphics_180 = new cjs.Graphics().p("A17cCMAAAg4DMAr3AAAMAAAA4Dg");
	var mask_graphics_181 = new cjs.Graphics().p("A2rcCMAAAg4DMAtXAAAMAAAA4Dg");
	var mask_graphics_182 = new cjs.Graphics().p("A3acCMAAAg4DMAu1AAAMAAAA4Dg");
	var mask_graphics_183 = new cjs.Graphics().p("A4KcCMAAAg4DMAwVAAAMAAAA4Dg");
	var mask_graphics_184 = new cjs.Graphics().p("AE1fAMAAAg4EMAx2AAAMAAAA4Eg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(161).to({graphics:mask_graphics_161,x:431,y:217.4}).wait(1).to({graphics:mask_graphics_162,x:435.7,y:217.4}).wait(1).to({graphics:mask_graphics_163,x:440.5,y:217.4}).wait(1).to({graphics:mask_graphics_164,x:445.2,y:217.4}).wait(1).to({graphics:mask_graphics_165,x:450,y:217.4}).wait(1).to({graphics:mask_graphics_166,x:454.8,y:217.4}).wait(1).to({graphics:mask_graphics_167,x:459.5,y:217.4}).wait(1).to({graphics:mask_graphics_168,x:464.3,y:217.4}).wait(1).to({graphics:mask_graphics_169,x:469,y:217.4}).wait(1).to({graphics:mask_graphics_170,x:473.8,y:217.4}).wait(1).to({graphics:mask_graphics_171,x:478.6,y:217.4}).wait(1).to({graphics:mask_graphics_172,x:483.3,y:217.4}).wait(1).to({graphics:mask_graphics_173,x:488.1,y:217.4}).wait(1).to({graphics:mask_graphics_174,x:492.8,y:217.4}).wait(1).to({graphics:mask_graphics_175,x:497.6,y:217.4}).wait(1).to({graphics:mask_graphics_176,x:502.4,y:217.4}).wait(1).to({graphics:mask_graphics_177,x:507.1,y:217.4}).wait(1).to({graphics:mask_graphics_178,x:511.9,y:217.4}).wait(1).to({graphics:mask_graphics_179,x:516.6,y:217.4}).wait(1).to({graphics:mask_graphics_180,x:521.4,y:217.4}).wait(1).to({graphics:mask_graphics_181,x:526.2,y:217.4}).wait(1).to({graphics:mask_graphics_182,x:530.9,y:217.4}).wait(1).to({graphics:mask_graphics_183,x:535.7,y:217.4}).wait(1).to({graphics:mask_graphics_184,x:350,y:198.4}).wait(13));

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4,0,0,4).p("EAVoAnuQg4mqigstQiut0jCsnQjjuzi7ojQjbqDiHAAUgGZAAAgHHAgtQiQKUi0QBQjQSpgTBg");
	this.shape.setTransform(596.1,232.8,0.553,0.553);

	this.shape.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},161).wait(36));

	// tabla
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(31,218.8);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(31,168.8);

	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(97,222.8);

	this.text_3 = new cjs.Text("0", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,168.8);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,222.8);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(163,168.8);

	this.text_6 = new cjs.Text("–2", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(229,222.8);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(229,168.8);

	this.text_8 = new cjs.Text("–8", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(296,222.8);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(296,168.8);

	this.text_10 = new cjs.Text("–8", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(361,222.8);

	this.text_11 = new cjs.Text("–2", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(361,168.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(330.8,209.4-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(264.6,209.4-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(198.5,209.4-incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(132.3,209.4-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_5.setTransform(66.2,209.4-incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_6.setTransform(198,209.4-incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_7.setTransform(198,209.4-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"bold 20px Verdana"}},{t:this.text_2,p:{font:"bold 20px Verdana"}},{t:this.text_1},{t:this.text}]},51).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"bold 20px Verdana"}},{t:this.text_4,p:{font:"bold 20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},22).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"bold 20px Verdana"}},{t:this.text_6,p:{font:"bold 20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},19).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"bold 20px Verdana"}},{t:this.text_8,p:{font:"bold 20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},20).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"bold 20px Verdana"}},{t:this.text_10,p:{font:"bold 20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},22).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},23).wait(40));

	// circulos
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgWAWQgWAWgfAAQgdAAgWgWQgXgWAAgfQAAgdAXgWQAWgXAdAAQAfAAAWAXQAWAWAAAdg");
	this.shape_8.setTransform(595.7,91.6,0.553,0.553);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0060BA").s().p("Ag0A1QgVgXAAgeQAAgeAVgVQAXgXAdAAQAeAAAWAXQAXAVgBAeQABAegXAXQgWAVgeAAQgdAAgXgVg");
	this.shape_9.setTransform(595.7,91.6,0.553,0.553);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgWAWQgWAWgfAAQgdAAgWgWQgXgWAAgfQAAgdAXgWQAWgXAdAAQAfAAAWAXQAWAWAAAdg");
	this.shape_10.setTransform(625.7,153.6,0.553,0.553);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0060BA").s().p("Ag0A1QgVgXAAgeQAAgeAVgVQAXgXAdAAQAeAAAWAXQAXAVgBAeQABAegXAXQgWAVgeAAQgdAAgXgVg");
	this.shape_11.setTransform(625.7,153.6,0.553,0.553);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("ABLAAQAAAfgXAWQgWAWgeAAQgdAAgXgWQgWgWAAgfQAAgdAWgWQAXgXAdAAQAeAAAWAXQAXAWAAAdg");
	this.shape_12.setTransform(563.7,153.6,0.553,0.553);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0060BA").s().p("AgzA1QgXgXAAgeQAAgeAXgVQAVgXAeAAQAeAAAXAXQAVAVAAAeQAAAegVAXQgXAVgeAAQgeAAgVgVg");
	this.shape_13.setTransform(563.7,153.6,0.553,0.553);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA1gzQAWAWAAAdQAAAfgWAWQgXAWgeAAQgeAAgWgWQgWgWAAgfQAAgeAWgVQAWgXAeAAQAeAAAXAXg");
	this.shape_14.setTransform(662.8,313.5,0.553,0.553);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0060BA").s().p("Ag0A1QgVgXAAgeQAAgeAVgVQAXgXAdAAQAfAAAVAXQAXAWAAAdQAAAegXAXQgVAVgfAAQgdAAgXgVg");
	this.shape_15.setTransform(662.8,313.5,0.553,0.553);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA0gzQAXAWAAAdQAAAfgXAWQgWAWgeAAQgeAAgWgWQgWgWAAgfQAAgeAWgVQAWgXAeAAQAeAAAWAXg");
	this.shape_16.setTransform(529.5,313.5,0.553,0.553);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0060BA").s().p("AgzA1QgXgXAAgeQAAgeAXgVQAVgXAeAAQAfAAAVAXQAXAWAAAdQAAAegXAXQgVAVgfAAQgeAAgVgVg");
	this.shape_17.setTransform(529.5,313.5,0.553,0.553);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},28).to({state:[{t:this.shape_9},{t:this.shape_8}]},23).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},22).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_13},{t:this.shape_12},{t:this.shape_9},{t:this.shape_8}]},19).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_11},{t:this.shape_10},{t:this.shape_13},{t:this.shape_12},{t:this.shape_9},{t:this.shape_8}]},20).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_17},{t:this.shape_16},{t:this.shape_11},{t:this.shape_10},{t:this.shape_13},{t:this.shape_12},{t:this.shape_9},{t:this.shape_8}]},22).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_17},{t:this.shape_16},{t:this.shape_11},{t:this.shape_10},{t:this.shape_13},{t:this.shape_12},{t:this.shape_9},{t:this.shape_8}]},23).wait(40));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_28 = new cjs.Graphics().p("Ah3fZMAAAg+xIDvAAMAAAA+xg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AjrfZMAAAg+xIHXAAMAAAA+xg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AlgfZMAAAg+xILBAAMAAAA+xg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AnVfZMAAAg+xIOrAAMAAAA+xg");
	var mask_1_graphics_32 = new cjs.Graphics().p("ApJfZMAAAg+xISTAAMAAAA+xg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Aq+fZMAAAg+xIV9AAMAAAA+xg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AsyfZMAAAg+xIZmAAMAAAA+xg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AunfZMAAAg+xIdPAAMAAAA+xg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AwcfZMAAAg+xMAg5AAAMAAAA+xg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AyQfZMAAAg+xMAkhAAAMAAAA+xg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A0FfZMAAAg+xMAoLAAAMAAAA+xg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A16fZMAAAg+xMAr1AAAMAAAA+xg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A3vfZMAAAg+xMAveAAAMAAAA+xg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A5jfZMAAAg+xMAzHAAAMAAAA+xg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A7YfZMAAAg+xMA2xAAAMAAAA+xg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A9MfZMAAAg+xMA6ZAAAMAAAA+xg");
	var mask_1_graphics_44 = new cjs.Graphics().p("A/BfZMAAAg+xMA+DAAAMAAAA+xg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Egg2AfZMAAAg+xMBBtAAAMAAAA+xg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AjMfZMAAAg+xMBFWAAAMAAAA+xg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(28).to({graphics:mask_1_graphics_28,x:415,y:178.8}).wait(1).to({graphics:mask_1_graphics_29,x:426.6,y:178.8}).wait(1).to({graphics:mask_1_graphics_30,x:438.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_31,x:450,y:178.8}).wait(1).to({graphics:mask_1_graphics_32,x:461.6,y:178.8}).wait(1).to({graphics:mask_1_graphics_33,x:473.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_34,x:485,y:178.8}).wait(1).to({graphics:mask_1_graphics_35,x:496.6,y:178.8}).wait(1).to({graphics:mask_1_graphics_36,x:508.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_37,x:520,y:178.8}).wait(1).to({graphics:mask_1_graphics_38,x:531.6,y:178.8}).wait(1).to({graphics:mask_1_graphics_39,x:543.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_40,x:555,y:178.8}).wait(1).to({graphics:mask_1_graphics_41,x:566.7,y:178.8}).wait(1).to({graphics:mask_1_graphics_42,x:578.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_43,x:590,y:178.8}).wait(1).to({graphics:mask_1_graphics_44,x:601.7,y:178.8}).wait(1).to({graphics:mask_1_graphics_45,x:613.3,y:178.8}).wait(1).to({graphics:mask_1_graphics_46,x:423.5,y:178.8}).wait(151));

	// ejes
	this.text_12 = new cjs.Text("Y", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(826.9,81.6,0.553,0.553);

	this.text_13 = new cjs.Text("X", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(590.3,-17.7,0.553,0.553);

	this.text_14 = new cjs.Text("–2", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(571.2,146.8,0.553,0.553);

	this.text_15 = new cjs.Text("", "12px ArialMT");
	this.text_15.lineHeight = 14;
	this.text_15.setTransform(589.8,154.2,0.553,0.553);

	this.text_16 = new cjs.Text("", "12px ArialMT");
	this.text_16.lineHeight = 14;
	this.text_16.setTransform(589.4,154.2,0.553,0.553);

	this.text_17 = new cjs.Text("", "12px ArialMT");
	this.text_17.lineHeight = 14;
	this.text_17.setTransform(583.3,154.2,0.553,0.553);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_18.setTransform(592.8,154.3,0.553,0.553);

	this.text_18 = new cjs.Text("–6", "30px Verdana");
	this.text_18.lineHeight = 36;
	this.text_18.setTransform(570.3,254.5,0.553,0.553);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_19.setTransform(592.2,261,0.553,0.553);

	this.text_19 = new cjs.Text("–4", "30px Verdana");
	this.text_19.lineHeight = 36;
	this.text_19.setTransform(570.4,202.2,0.553,0.553);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_20.setTransform(592.1,207.6,0.553,0.553);

	this.text_20 = new cjs.Text("–8", "30px Verdana");
	this.text_20.lineHeight = 36;
	this.text_20.setTransform(571.5,307.2,0.553,0.553);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_21.setTransform(592.8,313.7,0.553,0.553);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_22.setTransform(530.9,93.7,0.553,0.553);

	this.text_21 = new cjs.Text("–2", "30px Verdana");
	this.text_21.lineHeight = 36;
	this.text_21.setTransform(519.2,98.9,0.553,0.553);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABa");
	this.shape_23.setTransform(472.8,93.3,0.553,0.553);

	this.text_22 = new cjs.Text("–4", "30px Verdana");
	this.text_22.lineHeight = 36;
	this.text_22.setTransform(461.3,98.7,0.553,0.553);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_24.setTransform(782.4,94.3,0.553,0.553);

	this.text_23 = new cjs.Text("6", "30px Verdana");
	this.text_23.lineHeight = 36;
	this.text_23.setTransform(776.8,99.6,0.553,0.553);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABa");
	this.shape_25.setTransform(723.4,94.2,0.553,0.553);

	this.text_24 = new cjs.Text("4", "30px Verdana");
	this.text_24.lineHeight = 36;
	this.text_24.setTransform(717.9,99.5,0.553,0.553);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_26.setTransform(665.2,93.8,0.553,0.553);

	this.text_25 = new cjs.Text("2", "30px Verdana");
	this.text_25.lineHeight = 36;
	this.text_25.setTransform(659.6,98.9,0.553,0.553);

	this.text_26 = new cjs.Text("0", "30px Verdana");
	this.text_26.lineHeight = 36;
	this.text_26.setTransform(581.2,71.1,0.553,0.553);

	this.text_27 = new cjs.Text("0", "30px Verdana");
	this.text_27.lineHeight = 36;
	this.text_27.setTransform(598.9,98.5,0.553,0.553);

	this.text_28 = new cjs.Text("2", "30px Verdana");
	this.text_28.lineHeight = 36;
	this.text_28.setTransform(580.2,24.5,0.553,0.553);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_27.setTransform(593.1,31,0.553,0.553);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(2,0,0,4).p("EAAAg0VMAAABor");
	this.shape_28.setTransform(595.4,188.1,0.553,0.553);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(2,0,0,4).p("Egz2AAAMBntAAA");
	this.shape_29.setTransform(634.4,91.1,0.553,0.553);

	this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.shape_18.mask = this.text_18.mask = this.shape_19.mask = this.text_19.mask = this.shape_20.mask = this.text_20.mask = this.shape_21.mask = this.shape_22.mask = this.text_21.mask = this.shape_23.mask = this.text_22.mask = this.shape_24.mask = this.text_23.mask = this.shape_25.mask = this.text_24.mask = this.shape_26.mask = this.text_25.mask = this.text_26.mask = this.text_27.mask = this.text_28.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.text_25},{t:this.shape_26},{t:this.text_24},{t:this.shape_25},{t:this.text_23},{t:this.shape_24},{t:this.text_22},{t:this.shape_23},{t:this.text_21},{t:this.shape_22},{t:this.shape_21},{t:this.text_20},{t:this.shape_20},{t:this.text_19},{t:this.shape_19},{t:this.text_18},{t:this.shape_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12}]},28).wait(169));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,155.9,396,107);


(lib.GraficoAnimado_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// tabla
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(31,218.8);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(31,168.8);

	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(97,222.8);

	this.text_3 = new cjs.Text("0", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,168.8);

	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,222.8);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(163,168.8);

	this.text_6 = new cjs.Text("1", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(229,222.8);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(229,168.8);

	this.text_8 = new cjs.Text("4", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(296,222.8);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(296,168.8);

	this.text_10 = new cjs.Text("4", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(361,222.8);

	this.text_11 = new cjs.Text("–2", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(361,168.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape.setTransform(330.8,209.4-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(264.6,209.4-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(198.5,209.4-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(132.3,209.4-incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(66.2,209.4-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_5.setTransform(198,209.4-incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_6.setTransform(198,209.4-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"bold 20px Verdana"}},{t:this.text_2,p:{font:"bold 20px Verdana"}},{t:this.text_1},{t:this.text}]},67).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"bold 20px Verdana"}},{t:this.text_4,p:{font:"bold 20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},22).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"bold 20px Verdana"}},{t:this.text_6,p:{font:"bold 20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},19).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"bold 20px Verdana"}},{t:this.text_8,p:{font:"bold 20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},20).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"bold 20px Verdana"}},{t:this.text_10,p:{font:"bold 20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},22).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_11,p:{font:"20px Verdana"}},{t:this.text_10,p:{font:"20px Verdana"}},{t:this.text_9,p:{font:"20px Verdana"}},{t:this.text_8,p:{font:"20px Verdana"}},{t:this.text_7,p:{font:"20px Verdana"}},{t:this.text_6,p:{font:"20px Verdana"}},{t:this.text_5,p:{font:"20px Verdana"}},{t:this.text_4,p:{font:"20px Verdana"}},{t:this.text_3,p:{font:"20px Verdana"}},{t:this.text_2,p:{font:"20px Verdana"}},{t:this.text_1},{t:this.text}]},23).wait(40));

	// Capa 7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_179 = new cjs.Graphics().p("AkGXAMAAAgt/IINAAMAAAAt/g");
	var mask_graphics_180 = new cjs.Graphics().p("Ak0XAMAAAgt/IJpAAMAAAAt/g");
	var mask_graphics_181 = new cjs.Graphics().p("AlhXAMAAAgt/ILDAAMAAAAt/g");
	var mask_graphics_182 = new cjs.Graphics().p("AmPXAMAAAgt/IMfAAMAAAAt/g");
	var mask_graphics_183 = new cjs.Graphics().p("Am8XAMAAAgt/IN5AAMAAAAt/g");
	var mask_graphics_184 = new cjs.Graphics().p("AnqXAMAAAgt/IPVAAMAAAAt/g");
	var mask_graphics_185 = new cjs.Graphics().p("AoXXAMAAAgt/IQvAAMAAAAt/g");
	var mask_graphics_186 = new cjs.Graphics().p("ApEXAMAAAgt/ISJAAMAAAAt/g");
	var mask_graphics_187 = new cjs.Graphics().p("ApyXAMAAAgt/ITlAAMAAAAt/g");
	var mask_graphics_188 = new cjs.Graphics().p("AqfXAMAAAgt/IU/AAMAAAAt/g");
	var mask_graphics_189 = new cjs.Graphics().p("ArNXAMAAAgt/IWbAAMAAAAt/g");
	var mask_graphics_190 = new cjs.Graphics().p("Ar6XAMAAAgt/IX1AAMAAAAt/g");
	var mask_graphics_191 = new cjs.Graphics().p("AsoXAMAAAgt/IZRAAMAAAAt/g");
	var mask_graphics_192 = new cjs.Graphics().p("AtVXAMAAAgt/IarAAMAAAAt/g");
	var mask_graphics_193 = new cjs.Graphics().p("AuDXAMAAAgt/IcHAAMAAAAt/g");
	var mask_graphics_194 = new cjs.Graphics().p("AuwXAMAAAgt/IdhAAMAAAAt/g");
	var mask_graphics_195 = new cjs.Graphics().p("AveXAMAAAgt/Ie9AAMAAAAt/g");
	var mask_graphics_196 = new cjs.Graphics().p("AwLXAMAAAgt/MAgXAAAMAAAAt/g");
	var mask_graphics_197 = new cjs.Graphics().p("Aw4XAMAAAgt/MAhxAAAMAAAAt/g");
	var mask_graphics_198 = new cjs.Graphics().p("AxmXAMAAAgt/MAjNAAAMAAAAt/g");
	var mask_graphics_199 = new cjs.Graphics().p("AyTXAMAAAgt/MAknAAAMAAAAt/g");
	var mask_graphics_200 = new cjs.Graphics().p("AzBXAMAAAgt/MAmDAAAMAAAAt/g");
	var mask_graphics_201 = new cjs.Graphics().p("AzuXAMAAAgt/MAndAAAMAAAAt/g");
	var mask_graphics_202 = new cjs.Graphics().p("A0cXAMAAAgt/MAo5AAAMAAAAt/g");
	var mask_graphics_203 = new cjs.Graphics().p("A1JXAMAAAgt/MAqTAAAMAAAAt/g");
	var mask_graphics_204 = new cjs.Graphics().p("A13XAMAAAgt/MArvAAAMAAAAt/g");
	var mask_graphics_205 = new cjs.Graphics().p("A2kXAMAAAgt/MAtJAAAMAAAAt/g");
	var mask_graphics_206 = new cjs.Graphics().p("AKdXAMAAAgt/MAumAAAMAAAAt/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(179).to({graphics:mask_graphics_179,x:458.5,y:139.1}).wait(1).to({graphics:mask_graphics_180,x:463.1,y:139.1}).wait(1).to({graphics:mask_graphics_181,x:467.6,y:139.1}).wait(1).to({graphics:mask_graphics_182,x:472.2,y:139.1}).wait(1).to({graphics:mask_graphics_183,x:476.7,y:139.1}).wait(1).to({graphics:mask_graphics_184,x:481.3,y:139.1}).wait(1).to({graphics:mask_graphics_185,x:485.8,y:139.1}).wait(1).to({graphics:mask_graphics_186,x:490.3,y:139.1}).wait(1).to({graphics:mask_graphics_187,x:494.9,y:139.1}).wait(1).to({graphics:mask_graphics_188,x:499.4,y:139.1}).wait(1).to({graphics:mask_graphics_189,x:504,y:139.1}).wait(1).to({graphics:mask_graphics_190,x:508.5,y:139.1}).wait(1).to({graphics:mask_graphics_191,x:513.1,y:139.1}).wait(1).to({graphics:mask_graphics_192,x:517.6,y:139.1}).wait(1).to({graphics:mask_graphics_193,x:522.2,y:139.1}).wait(1).to({graphics:mask_graphics_194,x:526.7,y:139.1}).wait(1).to({graphics:mask_graphics_195,x:531.3,y:139.1}).wait(1).to({graphics:mask_graphics_196,x:535.8,y:139.1}).wait(1).to({graphics:mask_graphics_197,x:540.3,y:139.1}).wait(1).to({graphics:mask_graphics_198,x:544.9,y:139.1}).wait(1).to({graphics:mask_graphics_199,x:549.4,y:139.1}).wait(1).to({graphics:mask_graphics_200,x:554,y:139.1}).wait(1).to({graphics:mask_graphics_201,x:558.5,y:139.1}).wait(1).to({graphics:mask_graphics_202,x:563.1,y:139.1}).wait(1).to({graphics:mask_graphics_203,x:567.6,y:139.1}).wait(1).to({graphics:mask_graphics_204,x:572.2,y:139.1}).wait(1).to({graphics:mask_graphics_205,x:576.7,y:139.1}).wait(1).to({graphics:mask_graphics_206,x:365.2,y:139.1}).wait(7));

	// curva
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00A1C9").ss(2,0,0,4).p("AQnzCQggDEhJE4QhpHEh7FvQiiHpiqEUQjQFRjRAAQi5AAjElKQigkQigngQh8lvhrm9QhRlLgei5");
	this.shape_7.setTransform(606.2,141.5);

	this.shape_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_7}]},179).wait(34));

	// bolas
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AgXAYQgKgKAAgOQAAgNAKgKQALgKAMAAQAOAAAKAKQAKAKAAANQAAAOgKAKQgKAKgOAAQgMAAgLgKg");
	this.shape_8.setTransform(605.8,263.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0060BA").s().p("AgXAYQgKgKAAgOQAAgMAKgLQALgKAMAAQAOAAAKAKQAKALAAAMQAAAOgKAKQgKAKgOAAQgMAAgLgKg");
	this.shape_9.setTransform(605.8,263.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AD5i4QgKAKgOAAQgOAAgLgKQgKgKAAgPQAAgOAKgKQALgKAOAAQAOAAAKAKQAKAKAAAOQAAAPgKAKgAj4DqQgKgKAAgOQAAgPAKgKQALgKANAAQAPAAAKAKQAKAKAAAPQAAAOgKAKQgKAKgPAAQgNAAgLgKg");
	this.shape_10.setTransform(628.3,242.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0060BA").s().p("Aj4DqQgKgKAAgOQAAgOAKgLQALgKANAAQAPAAAKAKQAKALAAAOQAAAOgKAKQgKAKgPAAQgNAAgLgKgADIi4QgKgKAAgPQAAgOAKgKQALgKANAAQAPAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgPAAQgNAAgLgKg");
	this.shape_11.setTransform(628.3,242.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AHXi4QgKAKgPAAQgOAAgKgKQgKgKAAgPQAAgOAKgKQAKgKAOAAQAPAAAKAKQAKAKAAAOQAAAPgKAKgAgaDqQgKgKAAgOQAAgPAKgKQAKgKAOAAQANAAAKAKQAKAKAAAPQAAAOgKAKQgKAKgNAAQgOAAgKgKgAmli4QgLAKgOAAQgOAAgKgKQgKgKAAgPQAAgOAKgKQAKgKAOAAQAOAAALAKQAKAKAAAOQAAAPgKAKg");
	this.shape_12.setTransform(606.1,242.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0060BA").s().p("AgaDqQgKgKAAgOQAAgOAKgLQALgKANAAQANAAAKAKQAKALAAAOQAAAOgKAKQgKAKgNAAQgNAAgLgKgAGmi4QgKgKAAgPQAAgOAKgKQALgKANAAQAPAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgPAAQgNAAgLgKgAnWi4QgKgKAAgPQAAgOAKgKQAKgKAPAAQANAAALAKQAKAKAAAOQAAAPgKAKQgLAKgNAAQgPAAgKgKg");
	this.shape_13.setTransform(606.1,242.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AK4soQgKAKgOAAQgPAAgKgKQgKgKAAgOQAAgOAKgLQAKgKAPAAQAOAAAKAKQAKALAAAOQAAAOgKAKgAD2G2QgKAKgPAAQgOAAgKgKQgKgKAAgPQAAgOAKgKQAKgKAOAAQAPAAAKAKQAKAKAAAOQAAAPgKAKgAj7NaQgKgKAAgPQAAgOAKgKQAKgKAOAAQAPAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgPAAQgOAAgKgKgAqGG2QgLAKgOAAQgOAAgKgKQgKgKAAgPQAAgOAKgKQAKgKAOAAQAOAAALAKQAKAKAAAOQAAAPgKAKg");
	this.shape_14.setTransform(628.6,179.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0060BA").s().p("Aj7NaQgKgKAAgPQAAgOAKgKQAKgKAOAAQAPAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgPAAQgOAAgKgKgADFG2QgKgKAAgPQAAgOAKgKQAKgKAOAAQAPAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgPAAQgOAAgKgKgAq3G2QgKgKAAgPQAAgOAKgKQAKgKAOAAQAOAAALAKQAKAKAAAOQAAAPgKAKQgLAKgOAAQgOAAgKgKgAKHsoQgKgKAAgOQAAgOAKgLQAKgKAPAAQAOAAAKAKQAKALAAAOQAAAOgKAKQgKAKgOAAQgPAAgKgKg");
	this.shape_15.setTransform(628.6,179.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AOYsoQgLAKgOAAQgOAAgKgKQgKgKAAgOQAAgOAKgLQAKgKAOAAQAOAAALAKQAKALAAAOQAAAOgKAKgAHVG2QgKAKgOAAQgOAAgLgKQgKgKAAgPQAAgOAKgKQALgKAOAAQAOAAAKAKQAKAKAAAOQAAAPgKAKgAt+tjQAOAAAKAKQAKALAAAOQAAAOgKAKQgKAKgOAAQgPAAgKgKQgKgKAAgOQAAgOAKgLQAKgKAPAAgAgcNaQgKgKAAgPQAAgOAKgKQALgKAOAAQAMAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgMAAQgOAAgLgKgAmnG2QgKAKgOAAQgPAAgKgKQgKgKAAgPQAAgOAKgKQAKgKAPAAQAOAAAKAKQAKAKAAAOQAAAPgKAKg");
	this.shape_16.setTransform(606.3,179.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0060BA").s().p("AgcNaQgKgKAAgPQAAgOAKgKQALgKAOAAQAMAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgMAAQgOAAgLgKgAGkG2QgKgKAAgPQAAgOAKgKQALgKAOAAQAOAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgOAAQgOAAgLgKgAnYG2QgKgKAAgPQAAgOAKgKQAKgKAPAAQAOAAAKAKQAKAKAAAOQAAAPgKAKQgKAKgOAAQgPAAgKgKgANnsoQgKgKAAgOQAAgOAKgLQAKgKAOAAQAOAAALAKQAKALAAAOQAAAOgKAKQgLAKgOAAQgOAAgKgKgAuXsoQgKgKAAgOQAAgOAKgLQAKgKAPAAQAOAAAKAKQAKALAAAOQAAAOgKAKQgKAKgOAAQgPAAgKgKg");
	this.shape_17.setTransform(606.3,179.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9},{t:this.shape_8}]},67).to({state:[{t:this.shape_11},{t:this.shape_10}]},22).to({state:[{t:this.shape_13},{t:this.shape_12}]},19).to({state:[{t:this.shape_15},{t:this.shape_14}]},20).to({state:[{t:this.shape_17},{t:this.shape_16}]},22).to({state:[{t:this.shape_17},{t:this.shape_16}]},23).wait(40));

	// Capa 6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("Ai2cZMAAAg4xIFtAAMAAAA4xg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AkQcZMAAAg4xIIhAAMAAAA4xg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AlqcZMAAAg4xILVAAMAAAA4xg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AnEcZMAAAg4xIOJAAMAAAA4xg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AoecZMAAAg4xIQ9AAMAAAA4xg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Ap4cZMAAAg4xITxAAMAAAA4xg");
	var mask_1_graphics_50 = new cjs.Graphics().p("ArScZMAAAg4xIWlAAMAAAA4xg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AsscZMAAAg4xIZZAAMAAAA4xg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AuGcZMAAAg4xIcNAAMAAAA4xg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AvgcZMAAAg4xIfBAAMAAAA4xg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Aw6cZMAAAg4xMAh1AAAMAAAA4xg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AyUcZMAAAg4xMAkpAAAMAAAA4xg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AzucZMAAAg4xMAndAAAMAAAA4xg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A1IcZMAAAg4xMAqRAAAMAAAA4xg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A2icZMAAAg4xMAtFAAAMAAAA4xg");
	var mask_1_graphics_59 = new cjs.Graphics().p("A38cZMAAAg4xMAv5AAAMAAAA4xg");
	var mask_1_graphics_60 = new cjs.Graphics().p("A5WcZMAAAg4xMAytAAAMAAAA4xg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A6wcZMAAAg4xMA1hAAAMAAAA4xg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A8KcZMAAAg4xMA4VAAAMAAAA4xg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A9kcZMAAAg4xMA7JAAAMAAAA4xg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A++cZMAAAg4xMA99AAAMAAAA4xg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EggYAcZMAAAg4xMBAxAAAMAAAA4xg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EghyAcZMAAAg4xMBDlAAAMAAAA4xg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AkZcZMAAAg4xMBGYAAAMAAAA4xg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:412.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_45,x:421.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_46,x:430.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_47,x:439.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_48,x:448.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_49,x:457.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_50,x:466.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_51,x:475.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_52,x:484.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_53,x:493.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_54,x:502.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_55,x:511.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_56,x:520.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_57,x:529.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_58,x:538.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_59,x:547.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_60,x:556.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_61,x:565.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_62,x:574.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_63,x:583.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_64,x:592.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_65,x:601.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_66,x:610.4,y:158.9}).wait(1).to({graphics:mask_1_graphics_67,x:422.4,y:158.9}).wait(146));

	// Capa 2
	this.text_12 = new cjs.Text("X", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(827.3,251.2,0.46,0.46);

	this.text_13 = new cjs.Text("Y", "30px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(602.4,-7.2,0.46,0.46);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#00A1C9").ss(2,0,0,4).p("ABHAoIhHgoIhGAoIAAgrIBGgpIBHApg");
	this.shape_18.setTransform(605.8,11.4,0.46,0.46);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAAAAIhHAqIAAgqIBHgpIBHApIAAAqg");
	this.shape_19.setTransform(605.8,11.3,0.46,0.46);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#00A1C9").ss(2,0,0,4).p("AgnBIIAohIIgohGIAqAAIAqBGIgqBIg");
	this.shape_20.setTransform(820.9,264.1,0.46,0.46);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgpBIIAphIIgphGIAqAAIAqBGIgqBIg");
	this.shape_21.setTransform(821,264.1,0.46,0.46);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2,0,0,4).p("Aj5YhIAApdI55AAAj5PEMAAAgnkAj5PEMAhsAAA");
	this.shape_22.setTransform(630.8,167.6);

	this.text_12.mask = this.text_13.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.text_13},{t:this.text_12}]},44).wait(169));

	// Capa 1
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(3,0,0,4).p("AAiAAIhDAA");
	this.shape_23.setTransform(603.7,305.7,0.46,0.46);

	this.text_14 = new cjs.Text("–1", "30px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(585.6,299.7,0.46,0.46);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxDpIlhAAIAAnRIFhAAg");
	this.shape_24.setTransform(605.8,10.7,0.46,0.46);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_25.setTransform(605.8,10.7,0.46,0.46);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(1,0,0,4).p("ACxjoIAAHRIlhAAIAAnRg");
	this.shape_26.setTransform(821.6,263.4,0.46,0.46);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AiwDpIAAnRIFhAAIAAHRg");
	this.shape_27.setTransform(821.6,263.4,0.46,0.46);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_28.setTransform(689.3,266.1,0.46,0.46);

	this.text_15 = new cjs.Text("2", "30px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(684.6,270.5,0.46,0.46);

	this.text_16 = new cjs.Text("3", "30px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(726.7,270.5,0.46,0.46);

	this.text_17 = new cjs.Text("0", "30px Verdana");
	this.text_17.lineHeight = 36;
	this.text_17.setTransform(594.5,250.1,0.46,0.46);

	this.text_18 = new cjs.Text("2", "30px Verdana");
	this.text_18.lineHeight = 36;
	this.text_18.setTransform(593.5,176.3,0.46,0.46);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgsIAABZ");
	this.shape_29.setTransform(730.7,266.1,0.46,0.46);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_30.setTransform(647.9,265.6,0.46,0.46);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_31.setTransform(564.4,266.9,0.46,0.46);

	this.text_19 = new cjs.Text("–1", "30px Verdana");
	this.text_19.lineHeight = 36;
	this.text_19.setTransform(555.1,270,0.46,0.46);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_32.setTransform(523.9,266.7,0.46,0.46);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgxIAABj");
	this.shape_33.setTransform(483.1,266.7,0.46,0.46);

	this.text_20 = new cjs.Text("–3", "30px Verdana");
	this.text_20.lineHeight = 36;
	this.text_20.setTransform(471.8,269.7,0.46,0.46);

	this.text_21 = new cjs.Text("–2", "30px Verdana");
	this.text_21.lineHeight = 36;
	this.text_21.setTransform(515.4,269.4,0.46,0.46);

	this.text_22 = new cjs.Text("5", "30px Verdana");
	this.text_22.lineHeight = 36;
	this.text_22.setTransform(593.6,49.1,0.46,0.46);

	this.text_23 = new cjs.Text("4", "30px Verdana");
	this.text_23.lineHeight = 36;
	this.text_23.setTransform(593.2,91.6,0.46,0.46);

	this.text_24 = new cjs.Text("3", "30px Verdana");
	this.text_24.lineHeight = 36;
	this.text_24.setTransform(593.1,134.2,0.46,0.46);

	this.text_25 = new cjs.Text("1", "30px Verdana");
	this.text_25.lineHeight = 36;
	this.text_25.setTransform(594,217,0.46,0.46);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(3,0,0,4).p("AAAgtIAABb");
	this.shape_34.setTransform(772.3,266.1,0.46,0.46);

	this.text_26 = new cjs.Text("4", "30px Verdana");
	this.text_26.lineHeight = 36;
	this.text_26.setTransform(767.3,270.7,0.46,0.46);

	this.text_27 = new cjs.Text("1", "30px Verdana");
	this.text_27.lineHeight = 36;
	this.text_27.setTransform(643.2,270.1,0.46,0.46);

	this.text_28 = new cjs.Text("0", "30px Verdana");
	this.text_28.lineHeight = 36;
	this.text_28.setTransform(609.2,268.2,0.46,0.46);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(3,0,0,4).p("AATmYIgeAAAAStAIgeAAAAMgBIgdAAAANGsIgeAAAASNCIgdAA");
	this.shape_35.setTransform(604.6,139);

	this.shape_23.mask = this.text_14.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.text_18.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.text_19.mask = this.shape_32.mask = this.shape_33.mask = this.text_20.mask = this.text_21.mask = this.text_22.mask = this.text_23.mask = this.text_24.mask = this.text_25.mask = this.shape_34.mask = this.text_26.mask = this.text_27.mask = this.text_28.mask = this.shape_35.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_35},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.shape_34},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.shape_33},{t:this.shape_32},{t:this.text_19},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.text_14},{t:this.shape_23}]},44).wait(169));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,155.9,396,107);



(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.3,1,1).p("AJOiVIybAAQg8AAAAA8IAACzQAAA8A8AAISbAAQA8AAAAg8IAAizQAAg8g8AAg");
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ApMCVQg9AAAAg7IAAiyQAAg9A9AAISaAAQA7AAAAA9IAACyQAAA7g7AAg");
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s("#000000").ss(0.5,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#666666").s("#666666").ss(0.5,1,1).rr(-65,-15,130,30,6);
	this.shape_3.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);



(lib.boton_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("y = ax", "italic bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 192;
	this.text.setTransform(97.1,5.7+incremento);
	this.text2 = new cjs.Text("             ²", " bold 16px Verdana");
	this.text2.textAlign = "center";
	this.text2.lineHeight = 18;
	this.text2.lineWidth = 192;
	this.text2.setTransform(97.1,5.7+incremento);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{font:"italic bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));
this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text2,p:{font:" bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text2,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));
	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(98.6,18,1.516,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(98.6,18,1.516,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(98.6,18,1.516,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,197.1,36);


(lib.boton_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("y =     x", "italic bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 189;
	this.text.setTransform(96.4,5.7+incremento);
this.text2 = new cjs.Text("        –2   ²", " bold 16px Verdana");
	this.text2.textAlign = "center";
	this.text2.lineHeight = 18;
	this.text2.lineWidth = 189;
	this.text2.setTransform(96.4,5.7+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{font:"italic bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));
this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text2,p:{font:" bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text2,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(98.6,18,1.516,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(98.6,18,1.516,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(98.6,18,1.516,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,197.1,36);


(lib.boton_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("y = x", "italic bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 188;
	this.text.setTransform(96.1,5.7+incremento);
this.text2 = new cjs.Text("²", "bold 16px Verdana");
	this.text2.textAlign = "center";
	this.text2.lineHeight = 18;
	this.text2.lineWidth = 188;
	this.text2.setTransform(126.1,5.7+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{font:"italic bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));
this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text2,p:{font:" bold 16px Verdana",color:"#000000"}}]}).to({state:[{t:this.text2,p:{font:"16px Arial",color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));
	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(98.6,18,1.516,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(98.6,18,1.516,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1.3,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(98.6,18,1.516,1.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,197.1,36);


(lib.textoAnimado_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhHJAEsIAApXMCOTAAAIAAJXg");
	var mask_graphics_20 = new cjs.Graphics().p("EhHJAEsIAApXMCOTAAAIAAJXg");
	var mask_graphics_21 = new cjs.Graphics().p("EhHJAE4IAApvMCOTAAAIAAJvg");
	var mask_graphics_22 = new cjs.Graphics().p("EhHJAFFIAAqJMCOTAAAIAAKJg");
	var mask_graphics_23 = new cjs.Graphics().p("EhHJAFRIAAqhMCOTAAAIAAKhg");
	var mask_graphics_24 = new cjs.Graphics().p("EhHJAFeIAAq7MCOTAAAIAAK7g");
	var mask_graphics_25 = new cjs.Graphics().p("EhHJAFqIAArTMCOTAAAIAALTg");
	var mask_graphics_26 = new cjs.Graphics().p("EhHJAF3IAArtMCOTAAAIAALtg");
	var mask_graphics_27 = new cjs.Graphics().p("EhHJAGDIAAsFMCOTAAAIAAMFg");
	var mask_graphics_28 = new cjs.Graphics().p("EhHJAGQIAAsfMCOTAAAIAAMfg");
	var mask_graphics_29 = new cjs.Graphics().p("EhHJAGcIAAs3MCOTAAAIAAM3g");
	var mask_graphics_30 = new cjs.Graphics().p("EhHJAGpIAAtRMCOTAAAIAANRg");
	var mask_graphics_31 = new cjs.Graphics().p("EhHJAG1IAAtpMCOTAAAIAANpg");
	var mask_graphics_32 = new cjs.Graphics().p("EhHJAHCIAAuDMCOTAAAIAAODg");
	var mask_graphics_33 = new cjs.Graphics().p("EhHJAHOIAAubMCOTAAAIAAObg");
	var mask_graphics_34 = new cjs.Graphics().p("EhHJAHbIAAu1MCOTAAAIAAO1g");
	var mask_graphics_35 = new cjs.Graphics().p("EhHJAHnIAAvNMCOTAAAIAAPNg");
	var mask_graphics_36 = new cjs.Graphics().p("EhHJAH0IAAvnMCOTAAAIAAPng");
	var mask_graphics_37 = new cjs.Graphics().p("EhHJAIAIAAv/MCOTAAAIAAP/g");
	var mask_graphics_38 = new cjs.Graphics().p("EhHJAINIAAwZMCOTAAAIAAQZg");
	var mask_graphics_39 = new cjs.Graphics().p("EhHJAIZIAAwxMCOTAAAIAAQxg");
	var mask_graphics_40 = new cjs.Graphics().p("EhHJAImIAAxLMCOTAAAIAARLg");
	var mask_graphics_80 = new cjs.Graphics().p("EhHJAImIAAxLMCOTAAAIAARLg");
	var mask_graphics_81 = new cjs.Graphics().p("EhHJAI2IAAxrMCOTAAAIAARrg");
	var mask_graphics_82 = new cjs.Graphics().p("EhHJAJGIAAyLMCOTAAAIAASLg");
	var mask_graphics_83 = new cjs.Graphics().p("EhHJAJXIAAytMCOTAAAIAAStg");
	var mask_graphics_84 = new cjs.Graphics().p("EhHJAJnIAAzNMCOTAAAIAATNg");
	var mask_graphics_85 = new cjs.Graphics().p("EhHJAJ3IAAztMCOTAAAIAATtg");
	var mask_graphics_86 = new cjs.Graphics().p("EhHJAKHIAA0NMCOTAAAIAAUNg");
	var mask_graphics_87 = new cjs.Graphics().p("EhHJAKXIAA0tMCOTAAAIAAUtg");
	var mask_graphics_88 = new cjs.Graphics().p("EhHJAKoIAA1PMCOTAAAIAAVPg");
	var mask_graphics_89 = new cjs.Graphics().p("EhHJAK4IAA1vMCOTAAAIAAVvg");
	var mask_graphics_90 = new cjs.Graphics().p("EhHJALIIAA2PMCOTAAAIAAWPg");
	var mask_graphics_91 = new cjs.Graphics().p("EhHJALYIAA2vMCOTAAAIAAWvg");
	var mask_graphics_92 = new cjs.Graphics().p("EhHJALoIAA3PMCOTAAAIAAXPg");
	var mask_graphics_93 = new cjs.Graphics().p("EhHJAL5IAA3xMCOTAAAIAAXxg");
	var mask_graphics_94 = new cjs.Graphics().p("EhHJAMJIAA4RMCOTAAAIAAYRg");
	var mask_graphics_95 = new cjs.Graphics().p("EhHJAMZIAA4xMCOTAAAIAAYxg");
	var mask_graphics_96 = new cjs.Graphics().p("EhHJAMpIAA5RMCOTAAAIAAZRg");
	var mask_graphics_97 = new cjs.Graphics().p("EhHJAM5IAA5xMCOTAAAIAAZxg");
	var mask_graphics_98 = new cjs.Graphics().p("EhHJANKIAA6TMCOTAAAIAAaTg");
	var mask_graphics_99 = new cjs.Graphics().p("EhHJANaIAA6zMCOTAAAIAAazg");
	var mask_graphics_100 = new cjs.Graphics().p("EhHJANqIAA7TMCOTAAAIAAbTg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:443.5,y:7.2}).wait(20).to({graphics:mask_graphics_20,x:443.5,y:7.2}).wait(1).to({graphics:mask_graphics_21,x:443.5,y:8.4}).wait(1).to({graphics:mask_graphics_22,x:443.5,y:9.7}).wait(1).to({graphics:mask_graphics_23,x:443.5,y:10.9}).wait(1).to({graphics:mask_graphics_24,x:443.5,y:12.2}).wait(1).to({graphics:mask_graphics_25,x:443.5,y:13.4}).wait(1).to({graphics:mask_graphics_26,x:443.5,y:14.7}).wait(1).to({graphics:mask_graphics_27,x:443.5,y:15.9}).wait(1).to({graphics:mask_graphics_28,x:443.5,y:17.2}).wait(1).to({graphics:mask_graphics_29,x:443.5,y:18.4}).wait(1).to({graphics:mask_graphics_30,x:443.5,y:19.7}).wait(1).to({graphics:mask_graphics_31,x:443.5,y:20.9}).wait(1).to({graphics:mask_graphics_32,x:443.5,y:22.2}).wait(1).to({graphics:mask_graphics_33,x:443.5,y:23.4}).wait(1).to({graphics:mask_graphics_34,x:443.5,y:24.7}).wait(1).to({graphics:mask_graphics_35,x:443.5,y:25.9}).wait(1).to({graphics:mask_graphics_36,x:443.5,y:27.2}).wait(1).to({graphics:mask_graphics_37,x:443.5,y:28.4}).wait(1).to({graphics:mask_graphics_38,x:443.5,y:29.7}).wait(1).to({graphics:mask_graphics_39,x:443.5,y:30.9}).wait(1).to({graphics:mask_graphics_40,x:443.5,y:32.1}).wait(40).to({graphics:mask_graphics_80,x:443.5,y:32.1}).wait(1).to({graphics:mask_graphics_81,x:443.5,y:33.8}).wait(1).to({graphics:mask_graphics_82,x:443.5,y:35.4}).wait(1).to({graphics:mask_graphics_83,x:443.5,y:37}).wait(1).to({graphics:mask_graphics_84,x:443.5,y:38.6}).wait(1).to({graphics:mask_graphics_85,x:443.5,y:40.2}).wait(1).to({graphics:mask_graphics_86,x:443.5,y:41.9}).wait(1).to({graphics:mask_graphics_87,x:443.5,y:43.5}).wait(1).to({graphics:mask_graphics_88,x:443.5,y:45.1}).wait(1).to({graphics:mask_graphics_89,x:443.5,y:46.7}).wait(1).to({graphics:mask_graphics_90,x:443.5,y:48.3}).wait(1).to({graphics:mask_graphics_91,x:443.5,y:49.9}).wait(1).to({graphics:mask_graphics_92,x:443.5,y:51.6}).wait(1).to({graphics:mask_graphics_93,x:443.5,y:53.2}).wait(1).to({graphics:mask_graphics_94,x:443.5,y:54.8}).wait(1).to({graphics:mask_graphics_95,x:443.5,y:56.4}).wait(1).to({graphics:mask_graphics_96,x:443.5,y:58}).wait(1).to({graphics:mask_graphics_97,x:443.5,y:59.6}).wait(1).to({graphics:mask_graphics_98,x:443.5,y:61.3}).wait(1).to({graphics:mask_graphics_99,x:443.5,y:62.9}).wait(1).to({graphics:mask_graphics_100,x:443.5,y:64.5}).wait(58));

	// Capa 3
	

	// Capa 1
	this.instance = new lib.Imagen_01_02();
	this.instance.setTransform(593.4,234.9,0.447,0.447,0,0,0,164.6,177.1);

	this.instance_1 = new lib.Imagen_01_01();
	this.instance_1.setTransform(203.9,238,0.534,0.534,0,0,0,164.5,176.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(158));

	// Capa 7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Ao4BeIAAi7IRxAAIAAC7g");
	var mask_1_graphics_56 = new cjs.Graphics().p("Ao4BeIAAi7IRxAAIAAC7g");
	var mask_1_graphics_57 = new cjs.Graphics().p("Ao4B1IAAjpIRxAAIAADpg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Ao4CLIAAkVIRxAAIAAEVg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Ao4CiIAAlDIRxAAIAAFDg");
	var mask_1_graphics_60 = new cjs.Graphics().p("Ao4C4IAAlvIRxAAIAAFvg");
	var mask_1_graphics_61 = new cjs.Graphics().p("Ao4DPIAAmdIRxAAIAAGdg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Ao4DlIAAnJIRxAAIAAHJg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Ao4D8IAAn3IRxAAIAAH3g");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ao4ESIAAojIRxAAIAAIjg");
	var mask_1_graphics_65 = new cjs.Graphics().p("Ao4EpIAApRIRxAAIAAJRg");
	var mask_1_graphics_66 = new cjs.Graphics().p("ACqfGIAAqAIRzAAIAAKAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:205,y:343.6}).wait(56).to({graphics:mask_1_graphics_56,x:205,y:343.6}).wait(1).to({graphics:mask_1_graphics_57,x:205,y:345.9}).wait(1).to({graphics:mask_1_graphics_58,x:205,y:348.1}).wait(1).to({graphics:mask_1_graphics_59,x:205,y:350.4}).wait(1).to({graphics:mask_1_graphics_60,x:205,y:352.6}).wait(1).to({graphics:mask_1_graphics_61,x:205,y:354.9}).wait(1).to({graphics:mask_1_graphics_62,x:205,y:357.1}).wait(1).to({graphics:mask_1_graphics_63,x:205,y:359.4}).wait(1).to({graphics:mask_1_graphics_64,x:205,y:361.6}).wait(1).to({graphics:mask_1_graphics_65,x:205,y:363.9}).wait(1).to({graphics:mask_1_graphics_66,x:131,y:199}).wait(92));

	// Capa 2
	this.text = new cjs.Text("y = x²", "italic 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.lineWidth = 100;
	this.text.setTransform(203,361);

	this.text.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(158));

	// Capa 8 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("Ar2A2IAAhrIXuAAIAABrg");
	var mask_2_graphics_114 = new cjs.Graphics().p("Ar2A2IAAhrIXuAAIAABrg");
	var mask_2_graphics_115 = new cjs.Graphics().p("Ar2BHIAAiNIXuAAIAACNg");
	var mask_2_graphics_116 = new cjs.Graphics().p("Ar2BXIAAitIXuAAIAACtg");
	var mask_2_graphics_117 = new cjs.Graphics().p("Ar2BnIAAjNIXuAAIAADNg");
	var mask_2_graphics_118 = new cjs.Graphics().p("Ar2B4IAAjvIXuAAIAADvg");
	var mask_2_graphics_119 = new cjs.Graphics().p("Ar2CIIAAkPIXuAAIAAEPg");
	var mask_2_graphics_120 = new cjs.Graphics().p("Ar2CYIAAkvIXuAAIAAEvg");
	var mask_2_graphics_121 = new cjs.Graphics().p("Ar2CpIAAlRIXuAAIAAFRg");
	var mask_2_graphics_122 = new cjs.Graphics().p("Ar2C5IAAlxIXuAAIAAFxg");
	var mask_2_graphics_123 = new cjs.Graphics().p("Ar2DKIAAmTIXuAAIAAGTg");
	var mask_2_graphics_124 = new cjs.Graphics().p("Ar2DaIAAmzIXuAAIAAGzg");
	var mask_2_graphics_125 = new cjs.Graphics().p("AcletIAAnWIXwAAIAAHWg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:594,y:351.6}).wait(114).to({graphics:mask_2_graphics_114,x:594,y:351.6}).wait(1).to({graphics:mask_2_graphics_115,x:594,y:353.3}).wait(1).to({graphics:mask_2_graphics_116,x:594,y:354.9}).wait(1).to({graphics:mask_2_graphics_117,x:594,y:356.5}).wait(1).to({graphics:mask_2_graphics_118,x:594,y:358.2}).wait(1).to({graphics:mask_2_graphics_119,x:594,y:359.8}).wait(1).to({graphics:mask_2_graphics_120,x:594,y:361.4}).wait(1).to({graphics:mask_2_graphics_121,x:594,y:363}).wait(1).to({graphics:mask_2_graphics_122,x:594,y:364.7}).wait(1).to({graphics:mask_2_graphics_123,x:594,y:366.3}).wait(1).to({graphics:mask_2_graphics_124,x:594,y:367.9}).wait(1).to({graphics:mask_2_graphics_125,x:335,y:196.5}).wait(33));

	// Capa 5
	this.text_1 = new cjs.Text("y = –2x²", "italic 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 100;
	this.text_1.setTransform(593,361);

	this.text_1.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1}]}).wait(158));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,787,389.3);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}