(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.btn_03 = new lib.boton_04();
        this.btn_03.setTransform(94.7, 360);
        new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.boton_04(), 3);

        this.btn_02 = new lib.boton_03();
        this.btn_02.setTransform(94.7, 280);
        new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.boton_03(), 3);

        this.btn_01 = new lib.boton_02();
        this.btn_01.setTransform(94.7, 200);
        new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.boton_02(), 3);

        this.instance_1 = new lib.IMG_00();
        this.instance_1.setTransform(657.9, 326.9, 0.45, 0.45, 0, 0, 0, -0.5, -0.5);

        this.btn_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.btn_03.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });


        this.addChild(this.logo,  this.titulo, this.instance_1,this.btn_01,this.btn_02,this.btn_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, "<i>y = ax² + q</i>");
       

      this.instance_1 = new lib.IMG_01b();
	this.instance_1.setTransform(483.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.titulo,this.home,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_01_01'],0,300);
       

      this.instance_1 = new lib.IMG_01b();
	this.instance_1.setTransform(683.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_01_02'],0,300);
       

      this.instance_1 = new lib.IMG_01b();
	this.instance_1.setTransform(683.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

	this.instance = new lib.tabla_01_MC();
	this.instance.setTransform(320,347,0.853,0.853,0,0,0,176,47.1);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_01_03'],0,300);
       

      this.instance_1 = new lib.IMG_01b();
	this.instance_1.setTransform(683.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

		this.instance = new lib.tabla_01_MC("single",99);
	this.instance.setTransform(320,347,0.853,0.853,0,0,0,176,47.1);

this.instance_3 = new lib.flechas();
	this.instance_3.setTransform(405,347,1,1,0,0,0,139.8,22.1);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance,this.instance_3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
      
     (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_01_04'],0,300);
       

      this.instance_1 = new lib.IMG_02();
	this.instance_1.setTransform(683.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

		this.instance = new lib.tabla_01_MC("single",99);
	this.instance.setTransform(320,347,0.853,0.853,0,0,0,176,47.1);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame1_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        texto(this, txt['txt_01_05'],0,300);
       

      this.instance_1 = new lib.IMG_03();
	this.instance_1.setTransform(683.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.informacion, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame1_7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_info_01'],0,300);
       

      this.instance_1 = new lib.IMG_info_01();
	this.instance_1.setTransform(734.2,341.7,0.432,0.432,0,0,0,-0.2,-2.1);

		
        
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });


        this.addChild(this.logo,  this.texto,this.cerrar, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


  (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, "<i>y = a(x + p)²</i>");
       

      this.instance_1 = new lib.IMG_04();
	this.instance_1.setTransform(483.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.titulo,this.home,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_02_01'],0,300);
       

      this.instance_1 = new lib.IMG_04();
	this.instance_1.setTransform(697.4,302.8,0.367,0.367,0,0,0,-0.5,532.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_02_02'],0,300);
       

   
	this.instance = new lib.tabla_02_MC();
	this.instance.setTransform(272.1,337,1,1,0,0,0,176,47);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_02_03'],0,300);
       

    this.instance_1 = new lib.IMG_05();
	this.instance_1.setTransform(727,357.5,0.386,0.386,0,0,0,-0.2,89.5);
	this.instance = new lib.tabla_02_MC("synched",100);
	this.instance.setTransform(272.1,337,1,1,0,0,0,176,47);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance,this.instance_3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
      
     (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_02_04'],0,300);
       

     	this.instance_1 = new lib.IMG_06();
	this.instance_1.setTransform(730.1,272.9,0.454,0.454);

		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        texto(this, txt['txt_02_05'],0,300);
       

      this.instance_1 = new lib.IMG_07();
	this.instance_1.setTransform(715,313.6,0.424,0.424,0,0,0,-0.2,-0.4);

		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.informacion, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame2_7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_info_02'],0,330);
       

      this.instance_1 = new lib.IMG_info_02();
	this.instance_1.setTransform(734.2,341.7,0.432,0.432,0,0,0,-0.2,-2.1);

		
        
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });


        this.addChild(this.logo,  this.texto,this.cerrar, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


 (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, "<i>y = a(x + p)² + q</i>");
       

      this.instance_1 = new lib.IMG_08();
	this.instance_1.setTransform(483.4,321.8,0.441,0.441,0,0,0,-0.5,532.3);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.titulo,this.home,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_03_01'],0,300);
       

    this.instance_1 = new lib.IMG_08();
	this.instance_1.setTransform(704.7,303.1,0.367,0.367,0,0,0,-0.5,532.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_03_02'],0,300);
       

   
	this.instance_1 = new lib.IMG_10();
	this.instance_1.setTransform(725.4,321.1,0.428,0.428,0,0,0,-0.2,-0.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_03_03'],0,300);
       

      this.instance_1 = new lib.IMG_08();
	this.instance_1.setTransform(704.7,303.1,0.367,0.367,0,0,0,-0.5,532.2);
   
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
      
     (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_03_04'],0,300);
       

     	this.instance_1 = new lib.IMG_11();
	this.instance_1.setTransform(723.6,343.7,0.432,0.432,0,0,0,-0.2,-2.1);

		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.siguiente, this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        texto(this, txt['txt_03_05'],0,300);
       

    this.instance_1 = new lib.IMG_12();
	this.instance_1.setTransform(723.6,343.7,0.432,0.432,0,0,0,-0.2,-2.1);

		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.siguiente,this.home,this.anterior,this.informacion, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
       texto(this, txt['txt_03_06'],0,330);
       

      this.instance_1 = new lib.IMG_13();
	this.instance_1.setTransform(734.2,341.7,0.432,0.432,0,0,0,-0.2,-2.1);
		
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });


        this.addChild(this.logo,  this.texto,this.home,this.anterior,this.informacion, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame3_8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_info_03'],0,330);
       

       this.instance_1 = new lib.IMG_info_03();
	this.instance_1.setTransform(723.6,343.7,0.432,0.432,0,0,0,-0.2,-2.1);

		
        
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });


        this.addChild(this.logo,  this.texto,this.cerrar, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }





(lib.IMG_info_03 = function() {
	this.initialize();

	// puntos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AA1g0QAWAWAAAeQAAAfgWAWQgWAWgfAAQgdAAgXgWQgWgWAAgfQAAgeAWgWQAXgWAdAAQAfAAAWAWg");
	this.shape.setTransform(-74.6,37.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A52F").s().p("Ag0A0QgVgVgBgfQABgdAVgXQAXgVAdAAQAfAAAVAVQAXAXAAAdQAAAfgXAVQgVAXgfAAQgdAAgXgXg");
	this.shape_1.setTransform(-74.6,37.7);

	// GRAFICA 3
	this.instance = new lib.Path_7();
	this.instance.setTransform(-74.7,-183.5,1,1,0,0,0,199.9,222.8);

	// textos
	this.text = new cjs.Text("(–p, q)", "bold 36px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 36;
	this.text.lineWidth = 224;
	this.text.setTransform(-86.9,40.7);

	// coordenadas
	this.instance_1 = new lib.Path_8();
	this.instance_1.setTransform(-75.2,-0.6,1,1,0,0,0,2,406.2);

	// EJE ORI
	this.text_1 = new cjs.Text("X", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(480.6,159.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmAqIApgqIgpgqIASgSIA7A8Ig7A9g");
	this.shape_2.setTransform(471.2,237.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_3.setTransform(-0.9,237.1);

	// EJE VERTI
	this.text_2 = new cjs.Text("Y", "45px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 49;
	this.text_2.lineWidth = 31;
	this.text_2.setTransform(8.7,-483);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA8A7IgSASg");
	this.shape_4.setTransform(-0.5,-403.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA/cMAAAh+3");
	this.shape_5.setTransform(-0.5,1.5);

	this.addChild(this.shape_5,this.shape_4,this.text_2,this.shape_3,this.shape_2,this.text_1,this.instance_1,this.text,this.instance,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-474.1,-483,974.2,890.6);


(lib.IMG_info_02 = function() {
	this.initialize();

	// puntos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AA1g0QAWAWAAAeQAAAfgWAVQgWAXgfAAQgdAAgXgXQgWgVAAgfQAAgeAWgWQAXgWAdAAQAfAAAWAWg");
	this.shape.setTransform(-74.6,200.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9907D7").s().p("Ag0A1QgVgXgBgeQABgeAVgVQAXgXAdAAQAfAAAVAXQAXAVAAAeQAAAegXAXQgVAVgfAAQgdAAgXgVg");
	this.shape_1.setTransform(-74.6,200.2);

	// GRAFICA 1
	this.instance = new lib.Path_5();
	this.instance.setTransform(-73.6,-85.8,1,1,0,0,0,258.9,286);

	// GRAFICA 2
	this.instance_1 = new lib.Path_4();
	this.instance_1.setTransform(40.3,-85.5,1,1,0,0,0,258.9,286);

	// textos
	this.text = new cjs.Text("(–p, 0)", "bold 36px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 36;
	this.text.lineWidth = 154;
	this.text.setTransform(-81.5,209.3);

	this.text_1 = new cjs.Text("x = –p", "bold 36px Verdana", "#00A52F");
	this.text_1.lineHeight = 41;
	this.text_1.lineWidth = 155;
	this.text_1.setTransform(-109,-237.5);

	// coordenadas
	this.instance_2 = new lib.Path_6();
	this.instance_2.setTransform(-75.2,0.8,1,1,0,0,0,2,368.3);

	// EJE ORI
	this.text_2 = new cjs.Text("X", "45px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 49;
	this.text_2.lineWidth = 31;
	this.text_2.setTransform(466.4,116.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_2.setTransform(471.2,200.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_3.setTransform(-0.9,200.8);

	// EJE VERTI
	this.text_3 = new cjs.Text("Y", "45px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 49;
	this.text_3.lineWidth = 31;
	this.text_3.setTransform(48.5,-440.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_4.setTransform(39.2,-366.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_5.setTransform(39.2,1.9);

	this.addChild(this.shape_5,this.shape_4,this.text_3,this.shape_3,this.shape_2,this.text_2,this.instance_2,this.text_1,this.text,this.instance_1,this.instance,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-474.1,-440.3,960,811.6);


(lib.IMG_info_01 = function() {
	this.initialize();

	// punto
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("ABkAAQAAApgeAdQgdAegpAAQgoAAgdgeQgegdAAgpQAAgoAegeQAdgdAoAAQApAAAdAdQAeAeAAAog");
	this.shape.setTransform(-1.2,59.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9907D7").s().p("AhGBGQgdgdAAgpQAAgoAdgdQAegdAogBQApABAdAdQAdAdAAAoQAAApgdAdQgdAegpAAQgoAAgegeg");
	this.shape_1.setTransform(-1.2,59.5);

	// GRAFICA 2
	this.text = new cjs.Text("(0, q)", "bold 36px Verdana");
	this.text.lineHeight = 41;
	this.text.lineWidth = 224;
	this.text.setTransform(20,72.9);

	this.instance = new lib.Path_3();
	this.instance.setTransform(0,-128.9,1,1,0,0,0,193.6,189.6);

	// EJE ORI
	this.text_1 = new cjs.Text("X", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(468.7,169.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g4IAYgYIBPBQIhPBRg");
	this.shape_2.setTransform(469.7,250.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,0,0,4).p("EhJzAAAMCTnAAA");
	this.shape_3.setTransform(-1.4,250.9);

	// EJE VERTI
	this.text_2 = new cjs.Text("Y", "45px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 49;
	this.text_2.lineWidth = 31;
	this.text_2.setTransform(5.6,-390.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAAgDIg3A3IgZgYIBQhPIBRBPIgYAYg");
	this.shape_4.setTransform(-1.6,-310.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAAxNMAAAhiZ");
	this.shape_5.setTransform(-1.6,3);

	this.addChild(this.shape_5,this.shape_4,this.text_2,this.shape_3,this.shape_2,this.text_1,this.instance,this.text,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-473.9,-390.5,962.2,708.6);


(lib.IMG_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// GUIAS (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_44 = new cjs.Graphics().p("Ar7CWIAAkrIX3AAIAAErg");
	var mask_graphics_45 = new cjs.Graphics().p("Ar7FRIAAqhIX3AAIAAKhg");
	var mask_graphics_46 = new cjs.Graphics().p("Ar7INIAAwZIX3AAIAAQZg");
	var mask_graphics_47 = new cjs.Graphics().p("Ar7LIIAA2PIX3AAIAAWPg");
	var mask_graphics_48 = new cjs.Graphics().p("Ar7ODIAA8FIX3AAIAAcFg");
	var mask_graphics_49 = new cjs.Graphics().p("Ar7Q/MAAAgh9IX3AAMAAAAh9g");
	var mask_graphics_50 = new cjs.Graphics().p("Ar7T6MAAAgnzIX3AAMAAAAnzg");
	var mask_graphics_51 = new cjs.Graphics().p("Ar7W2MAAAgtrIX3AAMAAAAtrg");
	var mask_graphics_52 = new cjs.Graphics().p("Ar7ZxMAAAgzhIX3AAMAAAAzhg");
	var mask_graphics_53 = new cjs.Graphics().p("Ar7csMAAAg5XIX3AAMAAAA5Xg");
	var mask_graphics_54 = new cjs.Graphics().p("Ar7foMAAAg/PIX3AAMAAAA/Pg");
	var mask_graphics_55 = new cjs.Graphics().p("EgL7AijMAAAhFFIX3AAMAAABFFg");
	var mask_graphics_56 = new cjs.Graphics().p("EgL7AleMAAAhK7IX3AAMAAABK7g");
	var mask_graphics_57 = new cjs.Graphics().p("EgL7AoaMAAAhQzIX3AAMAAABQzg");
	var mask_graphics_58 = new cjs.Graphics().p("EgL7ArVMAAAhWpIX3AAMAAABWpg");
	var mask_graphics_59 = new cjs.Graphics().p("EgL7AuQMAAAhcfIX3AAMAAABcfg");
	var mask_graphics_60 = new cjs.Graphics().p("EgL7AxMMAAAhiXIX3AAMAAABiXg");
	var mask_graphics_61 = new cjs.Graphics().p("EgL7A0HMAAAhoNIX3AAMAAABoNg");
	var mask_graphics_62 = new cjs.Graphics().p("EgL7A3DMAAAhuFIX3AAMAAABuFg");
	var mask_graphics_63 = new cjs.Graphics().p("EgL7A5+MAAAhz7IX3AAMAAABz7g");
	var mask_graphics_64 = new cjs.Graphics().p("EgL7A85MAAAh5xIX3AAMAAAB5xg");
	var mask_graphics_65 = new cjs.Graphics().p("EgL7A/1MAAAh/pIX3AAMAAAB/pg");
	var mask_graphics_66 = new cjs.Graphics().p("EgOhBCwMAAAiFfIX3AAMAAACFfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_graphics_44,x:-109.6,y:430.6}).wait(1).to({graphics:mask_graphics_45,x:-109.6,y:411.8}).wait(1).to({graphics:mask_graphics_46,x:-109.6,y:393.1}).wait(1).to({graphics:mask_graphics_47,x:-109.6,y:374.3}).wait(1).to({graphics:mask_graphics_48,x:-109.6,y:355.6}).wait(1).to({graphics:mask_graphics_49,x:-109.6,y:336.9}).wait(1).to({graphics:mask_graphics_50,x:-109.6,y:318.1}).wait(1).to({graphics:mask_graphics_51,x:-109.6,y:299.4}).wait(1).to({graphics:mask_graphics_52,x:-109.6,y:280.7}).wait(1).to({graphics:mask_graphics_53,x:-109.6,y:261.9}).wait(1).to({graphics:mask_graphics_54,x:-109.6,y:243.2}).wait(1).to({graphics:mask_graphics_55,x:-109.6,y:224.5}).wait(1).to({graphics:mask_graphics_56,x:-109.6,y:205.7}).wait(1).to({graphics:mask_graphics_57,x:-109.6,y:187}).wait(1).to({graphics:mask_graphics_58,x:-109.6,y:168.2}).wait(1).to({graphics:mask_graphics_59,x:-109.6,y:149.5}).wait(1).to({graphics:mask_graphics_60,x:-109.6,y:130.8}).wait(1).to({graphics:mask_graphics_61,x:-109.6,y:112}).wait(1).to({graphics:mask_graphics_62,x:-109.6,y:93.3}).wait(1).to({graphics:mask_graphics_63,x:-109.6,y:74.6}).wait(1).to({graphics:mask_graphics_64,x:-109.6,y:55.8}).wait(1).to({graphics:mask_graphics_65,x:-109.6,y:37.1}).wait(1).to({graphics:mask_graphics_66,x:-93,y:18.3}).wait(30));

	// coordenadas
	this.instance = new lib.Path_10();
	this.instance.setTransform(-112.3,-1.5,1,1,0,0,0,2,383.8);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44).to({_off:false},0).wait(52));

	// puntos
	this.text = new cjs.Text("(–1, –2)", "bold 40px Verdana");
	this.text.lineHeight = 40;
	this.text.setTransform(-291.1,276.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAAhKQAfAAAWAXQAWAVAAAeQAAAfgWAVQgWAXgfAAQgdAAgWgXQgXgVAAgfQAAgeAXgVQAWgXAdAAg");
	this.shape.setTransform(-111.8,269);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9907D7").s().p("AgzA0QgXgWAAgeQAAgdAXgXQAVgVAeAAQAfAAAVAVQAXAXAAAdQAAAegXAWQgVAXgfAAQgeAAgVgXg");
	this.shape_1.setTransform(-111.8,269);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},28).wait(68));

	// GRAFICA 3
	this.instance_1 = new lib.Path_9();
	this.instance_1.setTransform(-113.6,-56.2,1,1,0,0,0,226.6,327.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(96));

	// EJE ORI
	this.text_1 = new cjs.Text("X", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(475.8,12);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_2.setTransform(432.6,104.4);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(424.1,115.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(238.4,104.4);

	this.text_3 = new cjs.Text("3", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(227.8,115.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(54,104.3);

	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(43.4,115);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(-454.8,104.5);

	this.text_5 = new cjs.Text("–5", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-475.4,115.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-270.5,104.5);

	this.text_6 = new cjs.Text("–3", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-291.1,115.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(-110.3,104.7);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-130.9,115.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(333.3,105);

	this.text_8 = new cjs.Text("4", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(323.9,115.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(-357.2,106.9);

	this.text_9 = new cjs.Text("–4", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-382,117.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(-187.4,104.5);

	this.text_10 = new cjs.Text("–2", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-208,115.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(142.8,105.1);

	this.text_11 = new cjs.Text("2", "20px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(133.4,115.2);

	this.text_12 = new cjs.Text("0", "20px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-36.5,107);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_12.setTransform(472.5,99.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_13.setTransform(0.3,99.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.text_12},{t:this.text_11},{t:this.shape_11},{t:this.text_10},{t:this.shape_10},{t:this.text_9},{t:this.shape_9},{t:this.text_8},{t:this.shape_8},{t:this.text_7},{t:this.shape_7},{t:this.text_6},{t:this.shape_6},{t:this.text_5},{t:this.shape_5},{t:this.text_4},{t:this.shape_4},{t:this.text_3},{t:this.shape_3},{t:this.text_2},{t:this.shape_2},{t:this.text_1}]}).wait(96));

	// EJE VERTI
	this.text_13 = new cjs.Text("Y", "45px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 49;
	this.text_13.lineWidth = 31;
	this.text_13.setTransform(-24.2,-445.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA6AAIhzAA");
	this.shape_14.setTransform(-48.5,183.7);

	this.text_14 = new cjs.Text("–1", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(-85.8,169.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhyAA");
	this.shape_15.setTransform(-48.8,-331.8);

	this.text_15 = new cjs.Text("4", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(-75.4,-345.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA6AAIhzAA");
	this.shape_16.setTransform(-48.9,269.4);

	this.text_16 = new cjs.Text("–2", "29px Verdana");
	this.text_16.lineHeight = 35;
	this.text_16.setTransform(-86.2,255.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(-50.6,349.5);

	this.text_17 = new cjs.Text("–3", "29px Verdana");
	this.text_17.lineHeight = 35;
	this.text_17.setTransform(-87.9,335.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(-50.1,-104.5);

	this.text_18 = new cjs.Text("2", "29px Verdana");
	this.text_18.lineHeight = 35;
	this.text_18.setTransform(-75.6,-118.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_19.setTransform(-50.1,-213.2);

	this.text_19 = new cjs.Text("3", "29px Verdana");
	this.text_19.lineHeight = 35;
	this.text_19.setTransform(-76.8,-227.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_20.setTransform(-50.1,4.2);

	this.text_20 = new cjs.Text("1", "29px Verdana");
	this.text_20.lineHeight = 35;
	this.text_20.setTransform(-74.5,-9.8);

	this.text_21 = new cjs.Text("0", "29px Verdana");
	this.text_21.lineHeight = 35;
	this.text_21.setTransform(-65.8,70);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_21.setTransform(-44.4,-381.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_22.setTransform(-44.4,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.text_21},{t:this.text_20},{t:this.shape_20},{t:this.text_19},{t:this.shape_19},{t:this.text_18},{t:this.shape_18},{t:this.text_17},{t:this.shape_17},{t:this.text_16},{t:this.shape_16},{t:this.text_15},{t:this.shape_15},{t:this.text_14},{t:this.shape_14},{t:this.text_13}]}).wait(96));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-475.4,-445.3,970.8,830.9);

(lib.IMG_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// GUIAS (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_44 = new cjs.Graphics().p("Ar7CWIAAkrIX3AAIAAErg");
	var mask_graphics_45 = new cjs.Graphics().p("Ar7FRIAAqhIX3AAIAAKhg");
	var mask_graphics_46 = new cjs.Graphics().p("Ar7INIAAwZIX3AAIAAQZg");
	var mask_graphics_47 = new cjs.Graphics().p("Ar7LIIAA2PIX3AAIAAWPg");
	var mask_graphics_48 = new cjs.Graphics().p("Ar7ODIAA8FIX3AAIAAcFg");
	var mask_graphics_49 = new cjs.Graphics().p("Ar7Q/MAAAgh9IX3AAMAAAAh9g");
	var mask_graphics_50 = new cjs.Graphics().p("Ar7T6MAAAgnzIX3AAMAAAAnzg");
	var mask_graphics_51 = new cjs.Graphics().p("Ar7W2MAAAgtrIX3AAMAAAAtrg");
	var mask_graphics_52 = new cjs.Graphics().p("Ar7ZxMAAAgzhIX3AAMAAAAzhg");
	var mask_graphics_53 = new cjs.Graphics().p("Ar7csMAAAg5XIX3AAMAAAA5Xg");
	var mask_graphics_54 = new cjs.Graphics().p("Ar7foMAAAg/PIX3AAMAAAA/Pg");
	var mask_graphics_55 = new cjs.Graphics().p("EgL7AijMAAAhFFIX3AAMAAABFFg");
	var mask_graphics_56 = new cjs.Graphics().p("EgL7AleMAAAhK7IX3AAMAAABK7g");
	var mask_graphics_57 = new cjs.Graphics().p("EgL7AoaMAAAhQzIX3AAMAAABQzg");
	var mask_graphics_58 = new cjs.Graphics().p("EgL7ArVMAAAhWpIX3AAMAAABWpg");
	var mask_graphics_59 = new cjs.Graphics().p("EgL7AuQMAAAhcfIX3AAMAAABcfg");
	var mask_graphics_60 = new cjs.Graphics().p("EgL7AxMMAAAhiXIX3AAMAAABiXg");
	var mask_graphics_61 = new cjs.Graphics().p("EgL7A0HMAAAhoNIX3AAMAAABoNg");
	var mask_graphics_62 = new cjs.Graphics().p("EgL7A3DMAAAhuFIX3AAMAAABuFg");
	var mask_graphics_63 = new cjs.Graphics().p("EgL7A5+MAAAhz7IX3AAMAAABz7g");
	var mask_graphics_64 = new cjs.Graphics().p("EgL7A85MAAAh5xIX3AAMAAAB5xg");
	var mask_graphics_65 = new cjs.Graphics().p("EgL7A/1MAAAh/pIX3AAMAAAB/pg");
	var mask_graphics_66 = new cjs.Graphics().p("EgOhBCwMAAAiFfIX3AAMAAACFfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_graphics_44,x:-109.6,y:430.6}).wait(1).to({graphics:mask_graphics_45,x:-109.6,y:411.8}).wait(1).to({graphics:mask_graphics_46,x:-109.6,y:393.1}).wait(1).to({graphics:mask_graphics_47,x:-109.6,y:374.3}).wait(1).to({graphics:mask_graphics_48,x:-109.6,y:355.6}).wait(1).to({graphics:mask_graphics_49,x:-109.6,y:336.9}).wait(1).to({graphics:mask_graphics_50,x:-109.6,y:318.1}).wait(1).to({graphics:mask_graphics_51,x:-109.6,y:299.4}).wait(1).to({graphics:mask_graphics_52,x:-109.6,y:280.7}).wait(1).to({graphics:mask_graphics_53,x:-109.6,y:261.9}).wait(1).to({graphics:mask_graphics_54,x:-109.6,y:243.2}).wait(1).to({graphics:mask_graphics_55,x:-109.6,y:224.5}).wait(1).to({graphics:mask_graphics_56,x:-109.6,y:205.7}).wait(1).to({graphics:mask_graphics_57,x:-109.6,y:187}).wait(1).to({graphics:mask_graphics_58,x:-109.6,y:168.2}).wait(1).to({graphics:mask_graphics_59,x:-109.6,y:149.5}).wait(1).to({graphics:mask_graphics_60,x:-109.6,y:130.8}).wait(1).to({graphics:mask_graphics_61,x:-109.6,y:112}).wait(1).to({graphics:mask_graphics_62,x:-109.6,y:93.3}).wait(1).to({graphics:mask_graphics_63,x:-109.6,y:74.6}).wait(1).to({graphics:mask_graphics_64,x:-109.6,y:55.8}).wait(1).to({graphics:mask_graphics_65,x:-109.6,y:37.1}).wait(1).to({graphics:mask_graphics_66,x:-93,y:18.3}).wait(30));

	// coordenadas
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(-114.3,-387.4);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},44).wait(52));

	// puntos
	this.text = new cjs.Text("(–1, –2)", "bold 40px Verdana");
	this.text.lineHeight = 40;
	this.text.setTransform(-291.1,276.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AAAhKQAfAAAWAXQAWAVAAAeQAAAfgWAVQgWAXgfAAQgdAAgWgXQgXgVAAgfQAAgeAXgVQAWgXAdAAg");
	this.shape.setTransform(-111.8,269);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9907D7").s().p("AgzA0QgXgWAAgeQAAgdAXgXQAVgVAeAAQAfAAAVAVQAXAXAAAdQAAAegXAWQgVAXgfAAQgeAAgVgXg");
	this.shape_1.setTransform(-111.8,269);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]},28).wait(68));

	// GRAFICA 3
	this.instance_1 = new lib.Path_9();
	this.instance_1.setTransform(-113.6,-56.2,1,1,0,0,0,226.6,327.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(96));

	// EJE ORI
	this.text_1 = new cjs.Text("X", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(475.8,12);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_2.setTransform(432.6,104.4);

	this.text_2 = new cjs.Text("5", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(424.1,115.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(238.4,104.4);

	this.text_3 = new cjs.Text("3", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(227.8,115.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(54,104.3);

	this.text_4 = new cjs.Text("1", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(43.4,115);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(-454.8,104.5);

	this.text_5 = new cjs.Text("–5", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-475.4,115.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-270.5,104.5);

	this.text_6 = new cjs.Text("–3", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-291.1,115.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(-110.3,104.7);

	this.text_7 = new cjs.Text("–1", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-130.9,115.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(333.3,105);

	this.text_8 = new cjs.Text("4", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(323.9,115.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(-357.2,106.9);

	this.text_9 = new cjs.Text("–4", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-382,117.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(-187.4,104.5);

	this.text_10 = new cjs.Text("–2", "30px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-208,115.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(142.8,105.1);

	this.text_11 = new cjs.Text("2", "30px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(133.4,115.2);

	this.text_12 = new cjs.Text("0", "30px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-36.5,107);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_12.setTransform(472.5,99.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_13.setTransform(0.3,99.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.text_12},{t:this.text_11},{t:this.shape_11},{t:this.text_10},{t:this.shape_10},{t:this.text_9},{t:this.shape_9},{t:this.text_8},{t:this.shape_8},{t:this.text_7},{t:this.shape_7},{t:this.text_6},{t:this.shape_6},{t:this.text_5},{t:this.shape_5},{t:this.text_4},{t:this.shape_4},{t:this.text_3},{t:this.shape_3},{t:this.text_2},{t:this.shape_2},{t:this.text_1}]}).wait(96));

	// EJE VERTI
	this.text_13 = new cjs.Text("Y", "45px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 49;
	this.text_13.lineWidth = 31;
	this.text_13.setTransform(-24.2,-445.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA6AAIhzAA");
	this.shape_14.setTransform(-48.5,183.7);

	this.text_14 = new cjs.Text("–1", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(-85.8,169.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhyAA");
	this.shape_15.setTransform(-48.8,-331.8);

	this.text_15 = new cjs.Text("4", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(-75.4,-345.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA6AAIhzAA");
	this.shape_16.setTransform(-48.9,269.4);

	this.text_16 = new cjs.Text("–2", "29px Verdana");
	this.text_16.lineHeight = 35;
	this.text_16.setTransform(-86.2,255.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(-50.6,349.5);

	this.text_17 = new cjs.Text("–3", "29px Verdana");
	this.text_17.lineHeight = 35;
	this.text_17.setTransform(-87.9,335.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(-50.1,-104.5);

	this.text_18 = new cjs.Text("2", "29px Verdana");
	this.text_18.lineHeight = 35;
	this.text_18.setTransform(-75.6,-118.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_19.setTransform(-50.1,-213.2);

	this.text_19 = new cjs.Text("3", "29px Verdana");
	this.text_19.lineHeight = 35;
	this.text_19.setTransform(-76.8,-227.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_20.setTransform(-50.1,4.2);

	this.text_20 = new cjs.Text("1", "29px Verdana");
	this.text_20.lineHeight = 35;
	this.text_20.setTransform(-74.5,-9.8);

	this.text_21 = new cjs.Text("0", "29px Verdana");
	this.text_21.lineHeight = 35;
	this.text_21.setTransform(-65.8,70);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_21.setTransform(-44.4,-381.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_22.setTransform(-44.4,1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.text_21},{t:this.text_20},{t:this.shape_20},{t:this.text_19},{t:this.shape_19},{t:this.text_18},{t:this.shape_18},{t:this.text_17},{t:this.shape_17},{t:this.text_16},{t:this.shape_16},{t:this.text_15},{t:this.shape_15},{t:this.text_14},{t:this.shape_14},{t:this.text_13}]}).wait(96));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-475.4,-445.3,970.8,830.9);

(lib.IMG_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4
	this.text = new cjs.Text("y = (x + 1)² – 2", "italic bold 35px Verdana", "#00A52F");
	this.text.lineHeight = 35;
	this.text.lineWidth = 367;
	this.text.setTransform(-20,167.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},87).wait(20));

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_59 = new cjs.Graphics().p("EgE3Ay1MAAAhlpIJvAAMAAABlpg");
	var mask_graphics_60 = new cjs.Graphics().p("EgGZAy1MAAAhlpIMzAAMAAABlpg");
	var mask_graphics_61 = new cjs.Graphics().p("EgH6Ay1MAAAhlpIP1AAMAAABlpg");
	var mask_graphics_62 = new cjs.Graphics().p("EgJbAy1MAAAhlpIS3AAMAAABlpg");
	var mask_graphics_63 = new cjs.Graphics().p("EgK9Ay1MAAAhlpIV7AAMAAABlpg");
	var mask_graphics_64 = new cjs.Graphics().p("EgMeAy1MAAAhlpIY9AAMAAABlpg");
	var mask_graphics_65 = new cjs.Graphics().p("EgN/Ay1MAAAhlpIb/AAMAAABlpg");
	var mask_graphics_66 = new cjs.Graphics().p("EgPhAy1MAAAhlpIfDAAMAAABlpg");
	var mask_graphics_67 = new cjs.Graphics().p("EgRCAy1MAAAhlpMAiFAAAMAAABlpg");
	var mask_graphics_68 = new cjs.Graphics().p("EgSjAy1MAAAhlpMAlHAAAMAAABlpg");
	var mask_graphics_69 = new cjs.Graphics().p("EgUFAy1MAAAhlpMAoLAAAMAAABlpg");
	var mask_graphics_70 = new cjs.Graphics().p("EgVmAy1MAAAhlpMArNAAAMAAABlpg");
	var mask_graphics_71 = new cjs.Graphics().p("EgXHAy1MAAAhlpMAuPAAAMAAABlpg");
	var mask_graphics_72 = new cjs.Graphics().p("EgYpAy1MAAAhlpMAxTAAAMAAABlpg");
	var mask_graphics_73 = new cjs.Graphics().p("EgaKAy1MAAAhlpMA0VAAAMAAABlpg");
	var mask_graphics_74 = new cjs.Graphics().p("EgbrAy1MAAAhlpMA3XAAAMAAABlpg");
	var mask_graphics_75 = new cjs.Graphics().p("EgdNAy1MAAAhlpMA6bAAAMAAABlpg");
	var mask_graphics_76 = new cjs.Graphics().p("EgeuAy1MAAAhlpMA9dAAAMAAABlpg");
	var mask_graphics_77 = new cjs.Graphics().p("EggPAy1MAAAhlpMBAfAAAMAAABlpg");
	var mask_graphics_78 = new cjs.Graphics().p("EghxAy1MAAAhlpMBDjAAAMAAABlpg");
	var mask_graphics_79 = new cjs.Graphics().p("EgjSAy1MAAAhlpMBGlAAAMAAABlpg");
	var mask_graphics_80 = new cjs.Graphics().p("EgkzAy1MAAAhlpMBJnAAAMAAABlpg");
	var mask_graphics_81 = new cjs.Graphics().p("EgmVAy1MAAAhlpMBMrAAAMAAABlpg");
	var mask_graphics_82 = new cjs.Graphics().p("Egn2Ay1MAAAhlpMBPtAAAMAAABlpg");
	var mask_graphics_83 = new cjs.Graphics().p("EgpXAy1MAAAhlpMBSvAAAMAAABlpg");
	var mask_graphics_84 = new cjs.Graphics().p("Egq5Ay1MAAAhlpMBVzAAAMAAABlpg");
	var mask_graphics_85 = new cjs.Graphics().p("EgsaAy1MAAAhlpMBY1AAAMAAABlpg");
	var mask_graphics_86 = new cjs.Graphics().p("Egt7Ay1MAAAhlpMBb4AAAMAAABlpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(59).to({graphics:mask_graphics_59,x:-372.5,y:-74.2}).wait(1).to({graphics:mask_graphics_60,x:-362.7,y:-74.2}).wait(1).to({graphics:mask_graphics_61,x:-353,y:-74.2}).wait(1).to({graphics:mask_graphics_62,x:-343.3,y:-74.2}).wait(1).to({graphics:mask_graphics_63,x:-333.5,y:-74.2}).wait(1).to({graphics:mask_graphics_64,x:-323.8,y:-74.2}).wait(1).to({graphics:mask_graphics_65,x:-314.1,y:-74.2}).wait(1).to({graphics:mask_graphics_66,x:-304.3,y:-74.2}).wait(1).to({graphics:mask_graphics_67,x:-294.6,y:-74.2}).wait(1).to({graphics:mask_graphics_68,x:-284.9,y:-74.2}).wait(1).to({graphics:mask_graphics_69,x:-275.1,y:-74.2}).wait(1).to({graphics:mask_graphics_70,x:-265.4,y:-74.2}).wait(1).to({graphics:mask_graphics_71,x:-255.7,y:-74.2}).wait(1).to({graphics:mask_graphics_72,x:-245.9,y:-74.2}).wait(1).to({graphics:mask_graphics_73,x:-236.2,y:-74.2}).wait(1).to({graphics:mask_graphics_74,x:-226.5,y:-74.2}).wait(1).to({graphics:mask_graphics_75,x:-216.7,y:-74.2}).wait(1).to({graphics:mask_graphics_76,x:-207,y:-74.2}).wait(1).to({graphics:mask_graphics_77,x:-197.3,y:-74.2}).wait(1).to({graphics:mask_graphics_78,x:-187.5,y:-74.2}).wait(1).to({graphics:mask_graphics_79,x:-177.8,y:-74.2}).wait(1).to({graphics:mask_graphics_80,x:-168.1,y:-74.2}).wait(1).to({graphics:mask_graphics_81,x:-158.3,y:-74.2}).wait(1).to({graphics:mask_graphics_82,x:-148.6,y:-74.2}).wait(1).to({graphics:mask_graphics_83,x:-138.9,y:-74.2}).wait(1).to({graphics:mask_graphics_84,x:-129.1,y:-74.2}).wait(1).to({graphics:mask_graphics_85,x:-119.4,y:-74.2}).wait(1).to({graphics:mask_graphics_86,x:-109.7,y:-74.2}).wait(21));

	// GRAFICA 3
	this.instance = new lib.Path_11();
	this.instance.setTransform(-112.5,-78,1,1,0,0,0,204.8,307.1);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).wait(48));

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_31 = new cjs.Graphics().p("Ao2DEIAAmHIRtAAIAAGHg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Ao2DqIAAnTIRtAAIAAHTg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ao2EPIAAodIRtAAIAAIdg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Ao2E0IAApnIRtAAIAAJng");
	var mask_1_graphics_35 = new cjs.Graphics().p("Ao2FaIAAqzIRtAAIAAKzg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Ao2F/IAAr9IRtAAIAAL9g");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ao2GlIAAtJIRtAAIAANJg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ao2HKIAAuTIRtAAIAAOTg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Ao2HvIAAvdIRtAAIAAPdg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Ao2IVIAAwpIRtAAIAAQpg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Ao2I6IAAxzIRtAAIAARzg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Ao2JgIAAy/IRtAAIAAS/g");
	var mask_1_graphics_43 = new cjs.Graphics().p("Ao2KFIAA0JIRtAAIAAUJg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AvbPGIAA1UIRtAAIAAVUg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_1_graphics_31,x:-140.9,y:76.3}).wait(1).to({graphics:mask_1_graphics_32,x:-140.9,y:80.1}).wait(1).to({graphics:mask_1_graphics_33,x:-140.9,y:83.8}).wait(1).to({graphics:mask_1_graphics_34,x:-140.9,y:87.5}).wait(1).to({graphics:mask_1_graphics_35,x:-140.9,y:91.3}).wait(1).to({graphics:mask_1_graphics_36,x:-140.9,y:95}).wait(1).to({graphics:mask_1_graphics_37,x:-140.9,y:98.8}).wait(1).to({graphics:mask_1_graphics_38,x:-140.9,y:102.5}).wait(1).to({graphics:mask_1_graphics_39,x:-140.9,y:106.2}).wait(1).to({graphics:mask_1_graphics_40,x:-140.9,y:110}).wait(1).to({graphics:mask_1_graphics_41,x:-140.9,y:113.7}).wait(1).to({graphics:mask_1_graphics_42,x:-140.9,y:117.5}).wait(1).to({graphics:mask_1_graphics_43,x:-140.9,y:121.2}).wait(1).to({graphics:mask_1_graphics_44,x:-98.8,y:96.6}).wait(63));

	// flecha2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgogGQgNgsgVg2QgRgugIgSIDHAAIgeBMQgQAsgNAqQggBpgJBGQgHhFghhqg");
	this.shape.setTransform(-137.3,165.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAi3IAAFu");
	this.shape_1.setTransform(-137.3,137);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AgJAAQgIgagHgPIAxAAIgPApQgJAcgBAOQgBgTgIgXg");
	this.shape_2.setTransform(-137.3,157.9);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},31).wait(76));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Egu2BCwMAAAiFfMBdtAAAMAAACFfg");
	mask_2.setTransform(-117.7,-0.1);

	// GRAFICA 1
	this.instance_1 = new lib.Path_14();
	this.instance_1.setTransform(-113.6,-3.4,1,1,0,0,0,2,383.8);

	this.instance_2 = new lib.Path_13();
	this.instance_2.setTransform(-113.2,-143.8,1,1,0,0,0,183.1,241.7);

	this.instance_1.mask = this.instance_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(107));

	// Capa 10 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuQKgIAAojIchAAIAAIjg");
	mask_3.setTransform(-75.9,67.2);

	// flecha
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhpgghGgJQBAgGBvghQAsgOA2gUQAtgRATgJIAADHIhMgeg");
	this.shape_3.setTransform(-94.3,115);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("ACtAAIlZAA");
	this.shape_4.setTransform(-66.8,115.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AABAKQgXgIgTgCQASAAAYgJQAbgIAOgHIAAAxQgagLgPgEg");
	this.shape_5.setTransform(-86.7,115);

	this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(107));

	// coordenadas
	this.text_1 = new cjs.Text(" y = (x + 1)²", "bold 35px Verdana", "#F307B6");
	this.text_1.lineHeight = 35;
	this.text_1.setTransform(-426.4,30.1);

	this.text_2 = new cjs.Text(" y = x²", "bold 35px Verdana");
	this.text_2.lineHeight = 35;
	this.text_2.setTransform(130.2,-336.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1}]}).wait(107));

	// GRAFICA 2
	this.instance_3 = new lib.Path_12();
	this.instance_3.setTransform(-45.6,-144.8,1,1,0,0,0,184.9,242.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(107));

	// EJE ORI
	this.text_3 = new cjs.Text("X", "45px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 49;
	this.text_3.lineWidth = 31;
	this.text_3.setTransform(468.7,21.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-450.3,102.7);

	this.text_4 = new cjs.Text("–6", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-472.7,112.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(360.9,101.9);

	this.text_5 = new cjs.Text("6", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(351.5,112);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(224.9,103.2);

	this.text_6 = new cjs.Text("4", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(215.5,113.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(-314.7,105);

	this.text_7 = new cjs.Text("–4", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-339.5,115.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(-178.8,102.6);

	this.text_8 = new cjs.Text("–2", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(-199.4,113.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(90.5,102.3);

	this.text_9 = new cjs.Text("2", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(81.1,112.4);

	this.text_10 = new cjs.Text("0", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-37.9,105.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_12.setTransform(471.2,97.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_13.setTransform(-0.9,97.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.text_10},{t:this.text_9},{t:this.shape_11},{t:this.text_8},{t:this.shape_10},{t:this.text_7},{t:this.shape_9},{t:this.text_6},{t:this.shape_8},{t:this.text_5},{t:this.shape_7},{t:this.text_4},{t:this.shape_6},{t:this.text_3}]}).wait(107));

	// EJE VERTI
	this.text_11 = new cjs.Text("Y", "45px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 49;
	this.text_11.lineWidth = 31;
	this.text_11.setTransform(-24.2,-445.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhyAA");
	this.shape_14.setTransform(-50.2,231.5);

	this.text_12 = new cjs.Text("–2", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(-87.5,217.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(-51.9,367.7);

	this.text_13 = new cjs.Text("–4", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(-89.3,353.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(-51.5,-173.4);

	this.text_14 = new cjs.Text("4", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(-77,-187.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(-51.5,-309);

	this.text_15 = new cjs.Text("6", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(-78.1,-323.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(-51.5,-39.6);

	this.text_16 = new cjs.Text("2", "29px Verdana");
	this.text_16.lineHeight = 35;
	this.text_16.setTransform(-75.8,-53.6);

	this.text_17 = new cjs.Text("0", "29px Verdana");
	this.text_17.lineHeight = 35;
	this.text_17.setTransform(-67.1,68.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_19.setTransform(-45.7,-383.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_20.setTransform(-45.7,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.text_17},{t:this.text_16},{t:this.shape_18},{t:this.text_15},{t:this.shape_17},{t:this.text_14},{t:this.shape_16},{t:this.text_13},{t:this.shape_15},{t:this.text_12},{t:this.shape_14},{t:this.text_11}]}).wait(107));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-445.3,962.3,829);


(lib.IMG_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	

	// Capa 13
	this.text = new cjs.Text(" y = (x + 1)²", "bold 35px Verdana", "#F307B6");
	this.text.lineHeight = 35;
	this.text.setTransform(-431.8,19.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},108).wait(64));

	// Capa 11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_71 = new cjs.Graphics().p("EgIIBCwMAAAiFfIQRAAMAAACFfg");
	var mask_graphics_72 = new cjs.Graphics().p("EgJLBCwMAAAiFfISXAAMAAACFfg");
	var mask_graphics_73 = new cjs.Graphics().p("EgKOBCwMAAAiFfIUdAAMAAACFfg");
	var mask_graphics_74 = new cjs.Graphics().p("EgLRBCwMAAAiFfIWjAAMAAACFfg");
	var mask_graphics_75 = new cjs.Graphics().p("EgMUBCwMAAAiFfIYpAAMAAACFfg");
	var mask_graphics_76 = new cjs.Graphics().p("EgNXBCwMAAAiFfIavAAMAAACFfg");
	var mask_graphics_77 = new cjs.Graphics().p("EgOaBCwMAAAiFfIc1AAMAAACFfg");
	var mask_graphics_78 = new cjs.Graphics().p("EgPdBCwMAAAiFfIe7AAMAAACFfg");
	var mask_graphics_79 = new cjs.Graphics().p("EgQgBCwMAAAiFfMAhBAAAMAAACFfg");
	var mask_graphics_80 = new cjs.Graphics().p("EgRjBCwMAAAiFfMAjHAAAMAAACFfg");
	var mask_graphics_81 = new cjs.Graphics().p("EgSlBCwMAAAiFfMAlLAAAMAAACFfg");
	var mask_graphics_82 = new cjs.Graphics().p("EgToBCwMAAAiFfMAnRAAAMAAACFfg");
	var mask_graphics_83 = new cjs.Graphics().p("EgUrBCwMAAAiFfMApXAAAMAAACFfg");
	var mask_graphics_84 = new cjs.Graphics().p("EgVuBCwMAAAiFfMArdAAAMAAACFfg");
	var mask_graphics_85 = new cjs.Graphics().p("EgWxBCwMAAAiFfMAtjAAAMAAACFfg");
	var mask_graphics_86 = new cjs.Graphics().p("EgX0BCwMAAAiFfMAvpAAAMAAACFfg");
	var mask_graphics_87 = new cjs.Graphics().p("EgY3BCwMAAAiFfMAxvAAAMAAACFfg");
	var mask_graphics_88 = new cjs.Graphics().p("EgZ6BCwMAAAiFfMAz1AAAMAAACFfg");
	var mask_graphics_89 = new cjs.Graphics().p("Ega9BCwMAAAiFfMA17AAAMAAACFfg");
	var mask_graphics_90 = new cjs.Graphics().p("EgcABCwMAAAiFfMA4BAAAMAAACFfg");
	var mask_graphics_91 = new cjs.Graphics().p("EgdDBCwMAAAiFfMA6HAAAMAAACFfg");
	var mask_graphics_92 = new cjs.Graphics().p("EgeGBCwMAAAiFfMA8NAAAMAAACFfg");
	var mask_graphics_93 = new cjs.Graphics().p("EgfJBCwMAAAiFfMA+TAAAMAAACFfg");
	var mask_graphics_94 = new cjs.Graphics().p("EggMBCwMAAAiFfMBAZAAAMAAACFfg");
	var mask_graphics_95 = new cjs.Graphics().p("EghPBCwMAAAiFfMBCfAAAMAAACFfg");
	var mask_graphics_96 = new cjs.Graphics().p("EgiSBCwMAAAiFfMBElAAAMAAACFfg");
	var mask_graphics_97 = new cjs.Graphics().p("EgjVBCwMAAAiFfMBGrAAAMAAACFfg");
	var mask_graphics_98 = new cjs.Graphics().p("EgkYBCwMAAAiFfMBIxAAAMAAACFfg");
	var mask_graphics_99 = new cjs.Graphics().p("EglbBCwMAAAiFfMBK3AAAMAAACFfg");
	var mask_graphics_100 = new cjs.Graphics().p("EgmeBCwMAAAiFfMBM9AAAMAAACFfg");
	var mask_graphics_101 = new cjs.Graphics().p("EgnhBCwMAAAiFfMBPDAAAMAAACFfg");
	var mask_graphics_102 = new cjs.Graphics().p("EgokBCwMAAAiFfMBRJAAAMAAACFfg");
	var mask_graphics_103 = new cjs.Graphics().p("EgpnBCwMAAAiFfMBTPAAAMAAACFfg");
	var mask_graphics_104 = new cjs.Graphics().p("EgqqBCwMAAAiFfMBVVAAAMAAACFfg");
	var mask_graphics_105 = new cjs.Graphics().p("EgrtBCwMAAAiFfMBXbAAAMAAACFfg");
	var mask_graphics_106 = new cjs.Graphics().p("EgswBCwMAAAiFfMBZhAAAMAAACFfg");
	var mask_graphics_107 = new cjs.Graphics().p("EgtzBCwMAAAiFfMBbnAAAMAAACFfg");
	var mask_graphics_108 = new cjs.Graphics().p("Egu2BCwMAAAiFfMBdtAAAMAAACFfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(71).to({graphics:mask_graphics_71,x:-365.5,y:-0.1}).wait(1).to({graphics:mask_graphics_72,x:-358.8,y:-0.1}).wait(1).to({graphics:mask_graphics_73,x:-352.1,y:-0.1}).wait(1).to({graphics:mask_graphics_74,x:-345.4,y:-0.1}).wait(1).to({graphics:mask_graphics_75,x:-338.7,y:-0.1}).wait(1).to({graphics:mask_graphics_76,x:-332,y:-0.1}).wait(1).to({graphics:mask_graphics_77,x:-325.3,y:-0.1}).wait(1).to({graphics:mask_graphics_78,x:-318.6,y:-0.1}).wait(1).to({graphics:mask_graphics_79,x:-311.9,y:-0.1}).wait(1).to({graphics:mask_graphics_80,x:-305.2,y:-0.1}).wait(1).to({graphics:mask_graphics_81,x:-298.6,y:-0.1}).wait(1).to({graphics:mask_graphics_82,x:-291.9,y:-0.1}).wait(1).to({graphics:mask_graphics_83,x:-285.2,y:-0.1}).wait(1).to({graphics:mask_graphics_84,x:-278.5,y:-0.1}).wait(1).to({graphics:mask_graphics_85,x:-271.8,y:-0.1}).wait(1).to({graphics:mask_graphics_86,x:-265.1,y:-0.1}).wait(1).to({graphics:mask_graphics_87,x:-258.4,y:-0.1}).wait(1).to({graphics:mask_graphics_88,x:-251.7,y:-0.1}).wait(1).to({graphics:mask_graphics_89,x:-245,y:-0.1}).wait(1).to({graphics:mask_graphics_90,x:-238.3,y:-0.1}).wait(1).to({graphics:mask_graphics_91,x:-231.6,y:-0.1}).wait(1).to({graphics:mask_graphics_92,x:-224.9,y:-0.1}).wait(1).to({graphics:mask_graphics_93,x:-218.2,y:-0.1}).wait(1).to({graphics:mask_graphics_94,x:-211.5,y:-0.1}).wait(1).to({graphics:mask_graphics_95,x:-204.8,y:-0.1}).wait(1).to({graphics:mask_graphics_96,x:-198.1,y:-0.1}).wait(1).to({graphics:mask_graphics_97,x:-191.4,y:-0.1}).wait(1).to({graphics:mask_graphics_98,x:-184.7,y:-0.1}).wait(1).to({graphics:mask_graphics_99,x:-178,y:-0.1}).wait(1).to({graphics:mask_graphics_100,x:-171.3,y:-0.1}).wait(1).to({graphics:mask_graphics_101,x:-164.6,y:-0.1}).wait(1).to({graphics:mask_graphics_102,x:-157.9,y:-0.1}).wait(1).to({graphics:mask_graphics_103,x:-151.2,y:-0.1}).wait(1).to({graphics:mask_graphics_104,x:-144.5,y:-0.1}).wait(1).to({graphics:mask_graphics_105,x:-137.8,y:-0.1}).wait(1).to({graphics:mask_graphics_106,x:-131.1,y:-0.1}).wait(1).to({graphics:mask_graphics_107,x:-124.4,y:-0.1}).wait(1).to({graphics:mask_graphics_108,x:-117.7,y:-0.1}).wait(64));

	// GRAFICA 1
	this.instance_1 = new lib.Path_14();
	this.instance_1.setTransform(-113.6,-3.4,1,1,0,0,0,2,383.8);

	this.instance_2 = new lib.Path_13();
	this.instance_2.setTransform(-113.2,-143.8,1,1,0,0,0,183.1,241.7);

	this.instance_1.mask = this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},71).wait(101));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_40 = new cjs.Graphics().p("AjaERIAAohIG0AAIAAIhg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AkfERIAAohII/AAIAAIhg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AlkERIAAohILJAAIAAIhg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AmqERIAAohINVAAIAAIhg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AnvERIAAohIPfAAIAAIhg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Ao1ERIAAohIRrAAIAAIhg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Ap6ERIAAohIT1AAIAAIhg");
	var mask_1_graphics_47 = new cjs.Graphics().p("ArAERIAAohIWBAAIAAIhg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AsFERIAAohIYLAAIAAIhg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AtLERIAAohIaXAAIAAIhg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AuQKgIAAojIchAAIAAIjg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(40).to({graphics:mask_1_graphics_40,x:-6.4,y:107.1}).wait(1).to({graphics:mask_1_graphics_41,x:-13.3,y:107.1}).wait(1).to({graphics:mask_1_graphics_42,x:-20.3,y:107.1}).wait(1).to({graphics:mask_1_graphics_43,x:-27.2,y:107.1}).wait(1).to({graphics:mask_1_graphics_44,x:-34.2,y:107.1}).wait(1).to({graphics:mask_1_graphics_45,x:-41.1,y:107.1}).wait(1).to({graphics:mask_1_graphics_46,x:-48.1,y:107.1}).wait(1).to({graphics:mask_1_graphics_47,x:-55,y:107.1}).wait(1).to({graphics:mask_1_graphics_48,x:-62,y:107.1}).wait(1).to({graphics:mask_1_graphics_49,x:-68.9,y:107.1}).wait(1).to({graphics:mask_1_graphics_50,x:-75.9,y:67.2}).wait(122));

	// flecha
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhpgghGgJQBAgGBvghQAsgOA2gUQAtgRATgJIAADHIhMgeg");
	this.shape_3.setTransform(-94.3,115);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("ACtAAIlZAA");
	this.shape_4.setTransform(-66.8,115.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AABAKQgXgIgTgCQASAAAYgJQAbgIAOgHIAAAxQgagLgPgEg");
	this.shape_5.setTransform(-86.7,115);

	this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},40).wait(132));

	// Capa 12
	this.text_1 = new cjs.Text(" y = x²", "bold 35px Verdana");
	this.text_1.lineHeight = 35;
	this.text_1.setTransform(130.2,-336.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1}]}).wait(172));

	// GRAFICA 2
	this.instance_3 = new lib.Path_12();
	this.instance_3.setTransform(-45.6,-144.8,1,1,0,0,0,184.9,242.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(172));

	// EJE ORI
	this.text_2 = new cjs.Text("X", "45px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 49;
	this.text_2.lineWidth = 31;
	this.text_2.setTransform(471.1,22);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-450.3,102.7);

	this.text_3 = new cjs.Text("–6", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-472.7,112.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(360.9,101.9);

	this.text_4 = new cjs.Text("6", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(351.5,112);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(224.9,103.2);

	this.text_5 = new cjs.Text("4", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(215.5,113.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(-314.7,105);

	this.text_6 = new cjs.Text("–4", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-339.5,115.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(-178.8,102.6);

	this.text_7 = new cjs.Text("–2", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-199.4,113.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(90.5,102.3);

	this.text_8 = new cjs.Text("2", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(81.1,112.4);

	this.text_9 = new cjs.Text("0", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-37.9,105.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_12.setTransform(471.2,97.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_13.setTransform(-0.9,97.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.text_9},{t:this.text_8},{t:this.shape_11},{t:this.text_7},{t:this.shape_10},{t:this.text_6},{t:this.shape_9},{t:this.text_5},{t:this.shape_8},{t:this.text_4},{t:this.shape_7},{t:this.text_3},{t:this.shape_6},{t:this.text_2}]}).wait(172));

	// EJE VERTI
	this.text_10 = new cjs.Text("Y", "45px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 49;
	this.text_10.lineWidth = 31;
	this.text_10.setTransform(-24.2,-445.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhyAA");
	this.shape_14.setTransform(-50.2,231.5);

	this.text_11 = new cjs.Text("–2", "29px Verdana");
	this.text_11.lineHeight = 35;
	this.text_11.setTransform(-87.5,217.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(-51.9,367.7);

	this.text_12 = new cjs.Text("–4", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(-89.3,353.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(-51.5,-173.4);

	this.text_13 = new cjs.Text("4", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(-77,-187.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(-51.5,-309);

	this.text_14 = new cjs.Text("6", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(-78.1,-323.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(-51.5,-39.6);

	this.text_15 = new cjs.Text("2", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(-75.8,-53.6);

	this.text_16 = new cjs.Text("0", "29px Verdana");
	this.text_16.lineHeight = 35;
	this.text_16.setTransform(-67.1,68.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_19.setTransform(-45.7,-383.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_20.setTransform(-45.7,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.text_16},{t:this.text_15},{t:this.shape_18},{t:this.text_14},{t:this.shape_17},{t:this.text_13},{t:this.shape_16},{t:this.text_12},{t:this.shape_15},{t:this.text_11},{t:this.shape_14},{t:this.text_10}]}).wait(172));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-445.3,964.7,829);


(lib.IMG_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_87 = new cjs.Graphics().p("EgDoAm4MAAAhNvIHRAAMAAABNvg");
	var mask_graphics_88 = new cjs.Graphics().p("EgGjAm4MAAAhNvINHAAMAAABNvg");
	var mask_graphics_89 = new cjs.Graphics().p("EgJeAm4MAAAhNvIS9AAMAAABNvg");
	var mask_graphics_90 = new cjs.Graphics().p("EgMZAm4MAAAhNvIYzAAMAAABNvg");
	var mask_graphics_91 = new cjs.Graphics().p("EgPUAm4MAAAhNvIepAAMAAABNvg");
	var mask_graphics_92 = new cjs.Graphics().p("EgSPAm4MAAAhNvMAkfAAAMAAABNvg");
	var mask_graphics_93 = new cjs.Graphics().p("EgVKAm4MAAAhNvMAqVAAAMAAABNvg");
	var mask_graphics_94 = new cjs.Graphics().p("EgYFAm4MAAAhNvMAwLAAAMAAABNvg");
	var mask_graphics_95 = new cjs.Graphics().p("EgbAAm4MAAAhNvMA2BAAAMAAABNvg");
	var mask_graphics_96 = new cjs.Graphics().p("Egd7Am4MAAAhNvMA73AAAMAAABNvg");
	var mask_graphics_97 = new cjs.Graphics().p("Egg2Am4MAAAhNvMBBtAAAMAAABNvg");
	var mask_graphics_98 = new cjs.Graphics().p("EgjxAm4MAAAhNvMBHjAAAMAAABNvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(87).to({graphics:mask_graphics_87,x:-75.5,y:-216.6}).wait(1).to({graphics:mask_graphics_88,x:-56.8,y:-216.6}).wait(1).to({graphics:mask_graphics_89,x:-38.1,y:-216.6}).wait(1).to({graphics:mask_graphics_90,x:-19.4,y:-216.6}).wait(1).to({graphics:mask_graphics_91,x:-0.7,y:-216.6}).wait(1).to({graphics:mask_graphics_92,x:17.9,y:-216.6}).wait(1).to({graphics:mask_graphics_93,x:36.6,y:-216.6}).wait(1).to({graphics:mask_graphics_94,x:55.3,y:-216.6}).wait(1).to({graphics:mask_graphics_95,x:74,y:-216.6}).wait(1).to({graphics:mask_graphics_96,x:92.7,y:-216.6}).wait(1).to({graphics:mask_graphics_97,x:111.4,y:-216.6}).wait(1).to({graphics:mask_graphics_98,x:130.1,y:-216.6}).wait(25));

	// GRAFICA 3
	this.instance = new lib.Path_15();
	this.instance.setTransform(138.4,-209,1,1,0,0,0,149.3,190.3);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).wait(36));

	// Capa 12 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_65 = new cjs.Graphics().p("AoYBFIAAiJIQxAAIAACJg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AoYCGIAAkLIQxAAIAAELg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AoYDGIAAmLIQxAAIAAGLg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AoYEGIAAoLIQxAAIAAILg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AoYFHIAAqNIQxAAIAAKNg");
	var mask_1_graphics_70 = new cjs.Graphics().p("AoYGHIAAsNIQxAAIAAMNg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AoYHHIAAuNIQxAAIAAONg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AoYIHIAAwNIQxAAIAAQNg");
	var mask_1_graphics_73 = new cjs.Graphics().p("AjsLpIAAyPIQxAAIAASPg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(65).to({graphics:mask_1_graphics_65,x:113.7,y:142.1}).wait(1).to({graphics:mask_1_graphics_66,x:113.7,y:135.6}).wait(1).to({graphics:mask_1_graphics_67,x:113.7,y:129.2}).wait(1).to({graphics:mask_1_graphics_68,x:113.7,y:122.8}).wait(1).to({graphics:mask_1_graphics_69,x:113.7,y:116.3}).wait(1).to({graphics:mask_1_graphics_70,x:113.7,y:109.9}).wait(1).to({graphics:mask_1_graphics_71,x:113.7,y:103.5}).wait(1).to({graphics:mask_1_graphics_72,x:113.7,y:97.1}).wait(1).to({graphics:mask_1_graphics_73,x:83.7,y:74.5}).wait(50));

	// flecha_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhjCpIAehMQAQgsANgqQAghpAIhGQAIBFAhBqQANAsAVA2QARAuAIASg");
	this.shape.setTransform(117,50.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAEMIAAoX");
	this.shape_1.setTransform(117,87.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AgYAqIAPgpQAJgdAAgNQACATAIAXQAIAbAHAOg");
	this.shape_2.setTransform(117,58.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},65).wait(58));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_39 = new cjs.Graphics().p("EgN6BEdMAAAiI5IQBAAMAAACI5g");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgKxBEdMAAAiI5IVjAAMAAACI5g");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgNhBEdMAAAiI5IbDAAMAAACI5g");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgQRBEdMAAAiI5MAgjAAAMAAACI5g");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgTBBEdMAAAiI5MAmDAAAMAAACI5g");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgVxBEdMAAAiI5MArjAAAMAAACI5g");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgYiBEdMAAAiI5MAxFAAAMAAACI5g");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgbSBEdMAAAiI5MA2lAAAMAAACI5g");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgeCBEdMAAAiI5MA8FAAAMAAACI5g");
	var mask_2_graphics_48 = new cjs.Graphics().p("EggyBEdMAAAiI5MBBlAAAMAAACI5g");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgjiBEdMAAAiI5MBHFAAAMAAACI5g");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgmTBEdMAAAiI5MBMnAAAMAAACI5g");
	var mask_2_graphics_51 = new cjs.Graphics().p("EgpDBEdMAAAiI5MBSHAAAMAAACI5g");
	var mask_2_graphics_52 = new cjs.Graphics().p("EgrzBEdMAAAiI5MBXnAAAMAAACI5g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(39).to({graphics:mask_2_graphics_39,x:-89.1,y:31.1}).wait(1).to({graphics:mask_2_graphics_40,x:-109.3,y:31.1}).wait(1).to({graphics:mask_2_graphics_41,x:-91.7,y:31.1}).wait(1).to({graphics:mask_2_graphics_42,x:-74,y:31.1}).wait(1).to({graphics:mask_2_graphics_43,x:-56.4,y:31.1}).wait(1).to({graphics:mask_2_graphics_44,x:-38.8,y:31.1}).wait(1).to({graphics:mask_2_graphics_45,x:-21.2,y:31.1}).wait(1).to({graphics:mask_2_graphics_46,x:-3.6,y:31.1}).wait(1).to({graphics:mask_2_graphics_47,x:14,y:31.1}).wait(1).to({graphics:mask_2_graphics_48,x:31.6,y:31.1}).wait(1).to({graphics:mask_2_graphics_49,x:49.2,y:31.1}).wait(1).to({graphics:mask_2_graphics_50,x:66.8,y:31.1}).wait(1).to({graphics:mask_2_graphics_51,x:84.4,y:31.1}).wait(1).to({graphics:mask_2_graphics_52,x:102.1,y:31.1}).wait(71));

	// GRAFICA 1
	this.instance_1 = new lib.Path_18();
	this.instance_1.setTransform(138.8,0.1,1,1,0,0,0,2,398.7);

	this.instance_2 = new lib.Path_17();
	this.instance_2.setTransform(137.2,-96.9,1,1,0,0,0,187.9,301.4);

	this.instance_1.mask = this.instance_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},39).wait(84));

	// Capa 10 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_14 = new cjs.Graphics().p("AkjFqIAArTIJHAAIAALTg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AlnFqIAArTILPAAIAALTg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AmsFqIAArTINZAAIAALTg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AnxFqIAArTIPjAAIAALTg");
	var mask_3_graphics_18 = new cjs.Graphics().p("Ao1FqIAArTIRrAAIAALTg");
	var mask_3_graphics_19 = new cjs.Graphics().p("Ap6FqIAArTIT1AAIAALTg");
	var mask_3_graphics_20 = new cjs.Graphics().p("Aq/FqIAArTIV/AAIAALTg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AsDFqIAArTIYHAAIAALTg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AtIMMIAArVIaRAAIAALVg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_3_graphics_14,x:-109.4,y:119.9}).wait(1).to({graphics:mask_3_graphics_15,x:-102.5,y:119.9}).wait(1).to({graphics:mask_3_graphics_16,x:-95.6,y:119.9}).wait(1).to({graphics:mask_3_graphics_17,x:-88.8,y:119.9}).wait(1).to({graphics:mask_3_graphics_18,x:-81.9,y:119.9}).wait(1).to({graphics:mask_3_graphics_19,x:-75,y:119.9}).wait(1).to({graphics:mask_3_graphics_20,x:-68.2,y:119.9}).wait(1).to({graphics:mask_3_graphics_21,x:-61.3,y:119.9}).wait(1).to({graphics:mask_3_graphics_22,x:-54.5,y:78.1}).wait(101));

	// flecha
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AiohjIBMAeQAsAQAqANQBqAhBFAHQhGAJhpAgQgsANg2AVQguARgSAIg");
	this.shape_3.setTransform(6.5,118.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("AlTAAIKoAA");
	this.shape_4.setTransform(-37.7,118.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AgpgYIApAPQAXAIATABQgTACgXAIQgbAIgOAHg");
	this.shape_5.setTransform(-1,118.1);

	this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},14).wait(109));

	// GRAFICA 2
	this.instance_3 = new lib.Path_16();
	this.instance_3.setTransform(-200,-94.5,1,1,0,0,0,187.3,299.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(123));

	// EJE ORI
	this.text = new cjs.Text("X", "45px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 49;
	this.text.lineWidth = 31;
	this.text.setTransform(455.8,120.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgmAqIApgqIgpgqIASgSIA7A8Ig7A9g");
	this.shape_6.setTransform(471.2,205.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_7.setTransform(-0.9,205.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.text}]}).wait(123));

	// EJE VERTI
	this.text_1 = new cjs.Text("Y", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(-177.8,-458.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_8.setTransform(-199.3,-393.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA9qMAAAh7T");
	this.shape_9.setTransform(-199.3,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.text_1}]}).wait(123));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-458.6,949.4,853.8);


(lib.IMG_08 = function() {
	this.initialize();

	// GRAFICA 1
	this.instance = new lib.Path_19();
	this.instance.setTransform(-24.3,412,1,1,0,0,0,193.9,243.5);

	// EJE ORI
	this.text = new cjs.Text("X", "45px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 49;
	this.text.lineWidth = 31;
	this.text.setTransform(517.4,769.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgmAqIAogqIgogpIASgSIA7A7Ig7A8g");
	this.shape.setTransform(485.9,821.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_1.setTransform(13.7,821.6);

	// EJE VERTI
	this.text_1 = new cjs.Text("Y", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(-235.2,93);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_2.setTransform(-241.6,172.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA8EMAAAh4H");
	this.shape_3.setTransform(-241.6,556);

	this.addChild(this.shape_3,this.shape_2,this.text_1,this.shape_1,this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-459.4,93,996.3,847.4);


(lib.IMG_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// GRAFICA 3
	this.instance = new lib.Path_11();
	this.instance.setTransform(-112.5,-78,1,1,0,0,0,204.8,307.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(172));

	// flecha2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgogGQgNgsgVg2QgRgugIgSIDHAAIgeBMQgQAsgNAqQggBpgJBGQgHhFghhqg");
	this.shape.setTransform(-137.3,165.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAi3IAAFu");
	this.shape_1.setTransform(-137.3,137);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AgJAAQgIgagHgPIAxAAIgPApQgJAcgBAOQgBgTgIgXg");
	this.shape_2.setTransform(-137.3,157.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(172));

	// Capa 13
	this.text = new cjs.Text(" y = (x + 1)²", "bold 35px Verdana", "#F307B6");
	this.text.lineHeight = 35;
	this.text.setTransform(-431.8,19.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},108).wait(64));

	// Capa 11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_71 = new cjs.Graphics().p("EgIIBCwMAAAiFfIQRAAMAAACFfg");
	var mask_graphics_72 = new cjs.Graphics().p("EgJLBCwMAAAiFfISXAAMAAACFfg");
	var mask_graphics_73 = new cjs.Graphics().p("EgKOBCwMAAAiFfIUdAAMAAACFfg");
	var mask_graphics_74 = new cjs.Graphics().p("EgLRBCwMAAAiFfIWjAAMAAACFfg");
	var mask_graphics_75 = new cjs.Graphics().p("EgMUBCwMAAAiFfIYpAAMAAACFfg");
	var mask_graphics_76 = new cjs.Graphics().p("EgNXBCwMAAAiFfIavAAMAAACFfg");
	var mask_graphics_77 = new cjs.Graphics().p("EgOaBCwMAAAiFfIc1AAMAAACFfg");
	var mask_graphics_78 = new cjs.Graphics().p("EgPdBCwMAAAiFfIe7AAMAAACFfg");
	var mask_graphics_79 = new cjs.Graphics().p("EgQgBCwMAAAiFfMAhBAAAMAAACFfg");
	var mask_graphics_80 = new cjs.Graphics().p("EgRjBCwMAAAiFfMAjHAAAMAAACFfg");
	var mask_graphics_81 = new cjs.Graphics().p("EgSlBCwMAAAiFfMAlLAAAMAAACFfg");
	var mask_graphics_82 = new cjs.Graphics().p("EgToBCwMAAAiFfMAnRAAAMAAACFfg");
	var mask_graphics_83 = new cjs.Graphics().p("EgUrBCwMAAAiFfMApXAAAMAAACFfg");
	var mask_graphics_84 = new cjs.Graphics().p("EgVuBCwMAAAiFfMArdAAAMAAACFfg");
	var mask_graphics_85 = new cjs.Graphics().p("EgWxBCwMAAAiFfMAtjAAAMAAACFfg");
	var mask_graphics_86 = new cjs.Graphics().p("EgX0BCwMAAAiFfMAvpAAAMAAACFfg");
	var mask_graphics_87 = new cjs.Graphics().p("EgY3BCwMAAAiFfMAxvAAAMAAACFfg");
	var mask_graphics_88 = new cjs.Graphics().p("EgZ6BCwMAAAiFfMAz1AAAMAAACFfg");
	var mask_graphics_89 = new cjs.Graphics().p("Ega9BCwMAAAiFfMA17AAAMAAACFfg");
	var mask_graphics_90 = new cjs.Graphics().p("EgcABCwMAAAiFfMA4BAAAMAAACFfg");
	var mask_graphics_91 = new cjs.Graphics().p("EgdDBCwMAAAiFfMA6HAAAMAAACFfg");
	var mask_graphics_92 = new cjs.Graphics().p("EgeGBCwMAAAiFfMA8NAAAMAAACFfg");
	var mask_graphics_93 = new cjs.Graphics().p("EgfJBCwMAAAiFfMA+TAAAMAAACFfg");
	var mask_graphics_94 = new cjs.Graphics().p("EggMBCwMAAAiFfMBAZAAAMAAACFfg");
	var mask_graphics_95 = new cjs.Graphics().p("EghPBCwMAAAiFfMBCfAAAMAAACFfg");
	var mask_graphics_96 = new cjs.Graphics().p("EgiSBCwMAAAiFfMBElAAAMAAACFfg");
	var mask_graphics_97 = new cjs.Graphics().p("EgjVBCwMAAAiFfMBGrAAAMAAACFfg");
	var mask_graphics_98 = new cjs.Graphics().p("EgkYBCwMAAAiFfMBIxAAAMAAACFfg");
	var mask_graphics_99 = new cjs.Graphics().p("EglbBCwMAAAiFfMBK3AAAMAAACFfg");
	var mask_graphics_100 = new cjs.Graphics().p("EgmeBCwMAAAiFfMBM9AAAMAAACFfg");
	var mask_graphics_101 = new cjs.Graphics().p("EgnhBCwMAAAiFfMBPDAAAMAAACFfg");
	var mask_graphics_102 = new cjs.Graphics().p("EgokBCwMAAAiFfMBRJAAAMAAACFfg");
	var mask_graphics_103 = new cjs.Graphics().p("EgpnBCwMAAAiFfMBTPAAAMAAACFfg");
	var mask_graphics_104 = new cjs.Graphics().p("EgqqBCwMAAAiFfMBVVAAAMAAACFfg");
	var mask_graphics_105 = new cjs.Graphics().p("EgrtBCwMAAAiFfMBXbAAAMAAACFfg");
	var mask_graphics_106 = new cjs.Graphics().p("EgswBCwMAAAiFfMBZhAAAMAAACFfg");
	var mask_graphics_107 = new cjs.Graphics().p("EgtzBCwMAAAiFfMBbnAAAMAAACFfg");
	var mask_graphics_108 = new cjs.Graphics().p("Egu2BCwMAAAiFfMBdtAAAMAAACFfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(71).to({graphics:mask_graphics_71,x:-365.5,y:-0.1}).wait(1).to({graphics:mask_graphics_72,x:-358.8,y:-0.1}).wait(1).to({graphics:mask_graphics_73,x:-352.1,y:-0.1}).wait(1).to({graphics:mask_graphics_74,x:-345.4,y:-0.1}).wait(1).to({graphics:mask_graphics_75,x:-338.7,y:-0.1}).wait(1).to({graphics:mask_graphics_76,x:-332,y:-0.1}).wait(1).to({graphics:mask_graphics_77,x:-325.3,y:-0.1}).wait(1).to({graphics:mask_graphics_78,x:-318.6,y:-0.1}).wait(1).to({graphics:mask_graphics_79,x:-311.9,y:-0.1}).wait(1).to({graphics:mask_graphics_80,x:-305.2,y:-0.1}).wait(1).to({graphics:mask_graphics_81,x:-298.6,y:-0.1}).wait(1).to({graphics:mask_graphics_82,x:-291.9,y:-0.1}).wait(1).to({graphics:mask_graphics_83,x:-285.2,y:-0.1}).wait(1).to({graphics:mask_graphics_84,x:-278.5,y:-0.1}).wait(1).to({graphics:mask_graphics_85,x:-271.8,y:-0.1}).wait(1).to({graphics:mask_graphics_86,x:-265.1,y:-0.1}).wait(1).to({graphics:mask_graphics_87,x:-258.4,y:-0.1}).wait(1).to({graphics:mask_graphics_88,x:-251.7,y:-0.1}).wait(1).to({graphics:mask_graphics_89,x:-245,y:-0.1}).wait(1).to({graphics:mask_graphics_90,x:-238.3,y:-0.1}).wait(1).to({graphics:mask_graphics_91,x:-231.6,y:-0.1}).wait(1).to({graphics:mask_graphics_92,x:-224.9,y:-0.1}).wait(1).to({graphics:mask_graphics_93,x:-218.2,y:-0.1}).wait(1).to({graphics:mask_graphics_94,x:-211.5,y:-0.1}).wait(1).to({graphics:mask_graphics_95,x:-204.8,y:-0.1}).wait(1).to({graphics:mask_graphics_96,x:-198.1,y:-0.1}).wait(1).to({graphics:mask_graphics_97,x:-191.4,y:-0.1}).wait(1).to({graphics:mask_graphics_98,x:-184.7,y:-0.1}).wait(1).to({graphics:mask_graphics_99,x:-178,y:-0.1}).wait(1).to({graphics:mask_graphics_100,x:-171.3,y:-0.1}).wait(1).to({graphics:mask_graphics_101,x:-164.6,y:-0.1}).wait(1).to({graphics:mask_graphics_102,x:-157.9,y:-0.1}).wait(1).to({graphics:mask_graphics_103,x:-151.2,y:-0.1}).wait(1).to({graphics:mask_graphics_104,x:-144.5,y:-0.1}).wait(1).to({graphics:mask_graphics_105,x:-137.8,y:-0.1}).wait(1).to({graphics:mask_graphics_106,x:-131.1,y:-0.1}).wait(1).to({graphics:mask_graphics_107,x:-124.4,y:-0.1}).wait(1).to({graphics:mask_graphics_108,x:-117.7,y:-0.1}).wait(64));

	// GRAFICA 1
	this.instance_1 = new lib.Mapadebits5();
	this.instance_1.setTransform(-115.7,-389.2);

	this.instance_2 = new lib.Path_13();
	this.instance_2.setTransform(-113.2,-143.8,1,1,0,0,0,183.1,241.7);

	this.instance_1.mask = this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},71).wait(101));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_40 = new cjs.Graphics().p("AjaERIAAohIG0AAIAAIhg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AkfERIAAohII/AAIAAIhg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AlkERIAAohILJAAIAAIhg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AmqERIAAohINVAAIAAIhg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AnvERIAAohIPfAAIAAIhg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Ao1ERIAAohIRrAAIAAIhg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Ap6ERIAAohIT1AAIAAIhg");
	var mask_1_graphics_47 = new cjs.Graphics().p("ArAERIAAohIWBAAIAAIhg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AsFERIAAohIYLAAIAAIhg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AtLERIAAohIaXAAIAAIhg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AuQKgIAAojIchAAIAAIjg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(40).to({graphics:mask_1_graphics_40,x:-6.4,y:107.1}).wait(1).to({graphics:mask_1_graphics_41,x:-13.3,y:107.1}).wait(1).to({graphics:mask_1_graphics_42,x:-20.3,y:107.1}).wait(1).to({graphics:mask_1_graphics_43,x:-27.2,y:107.1}).wait(1).to({graphics:mask_1_graphics_44,x:-34.2,y:107.1}).wait(1).to({graphics:mask_1_graphics_45,x:-41.1,y:107.1}).wait(1).to({graphics:mask_1_graphics_46,x:-48.1,y:107.1}).wait(1).to({graphics:mask_1_graphics_47,x:-55,y:107.1}).wait(1).to({graphics:mask_1_graphics_48,x:-62,y:107.1}).wait(1).to({graphics:mask_1_graphics_49,x:-68.9,y:107.1}).wait(1).to({graphics:mask_1_graphics_50,x:-75.9,y:67.2}).wait(122));

	// flecha
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhpgghGgJQBAgGBvghQAsgOA2gUQAtgRATgJIAADHIhMgeg");
	this.shape_3.setTransform(-94.3,115);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("ACtAAIlZAA");
	this.shape_4.setTransform(-66.8,115.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AABAKQgXgIgTgCQASAAAYgJQAbgIAOgHIAAAxQgagLgPgEg");
	this.shape_5.setTransform(-86.7,115);

	this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},40).wait(132));

	// Capa 12
	this.text_1 = new cjs.Text(" y = x²", "bold 35px Verdana");
	this.text_1.lineHeight = 35;
	this.text_1.setTransform(130.2,-336.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1}]}).wait(172));

	// GRAFICA 2
	this.instance_3 = new lib.Path_12();
	this.instance_3.setTransform(-45.6,-144.8,1,1,0,0,0,184.9,242.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(172));

	// EJE ORI
	this.text_2 = new cjs.Text("X", "45px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 49;
	this.text_2.lineWidth = 31;
	this.text_2.setTransform(471.1,22);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-450.3,102.7);

	this.text_3 = new cjs.Text("–6", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-472.7,112.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(360.9,101.9);

	this.text_4 = new cjs.Text("6", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(351.5,112);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(224.9,103.2);

	this.text_5 = new cjs.Text("4", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(215.5,113.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(-314.7,105);

	this.text_6 = new cjs.Text("–4", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(-339.5,115.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_10.setTransform(-178.8,102.6);

	this.text_7 = new cjs.Text("–2", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(-199.4,113.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(90.5,102.3);

	this.text_8 = new cjs.Text("2", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(81.1,112.4);

	this.text_9 = new cjs.Text("0", "30px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-37.9,105.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_12.setTransform(471.2,97.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_13.setTransform(-0.9,97.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.text_9},{t:this.text_8},{t:this.shape_11},{t:this.text_7},{t:this.shape_10},{t:this.text_6},{t:this.shape_9},{t:this.text_5},{t:this.shape_8},{t:this.text_4},{t:this.shape_7},{t:this.text_3},{t:this.shape_6},{t:this.text_2}]}).wait(172));

	// EJE VERTI
	this.text_10 = new cjs.Text("Y", "45px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 49;
	this.text_10.lineWidth = 31;
	this.text_10.setTransform(-24.2,-445.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhyAA");
	this.shape_14.setTransform(-50.2,231.5);

	this.text_11 = new cjs.Text("–2", "29px Verdana");
	this.text_11.lineHeight = 35;
	this.text_11.setTransform(-87.5,217.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(-51.9,367.7);

	this.text_12 = new cjs.Text("–4", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(-89.3,353.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(-51.5,-173.4);

	this.text_13 = new cjs.Text("4", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(-77,-187.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_17.setTransform(-51.5,-309);

	this.text_14 = new cjs.Text("6", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(-78.1,-323.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_18.setTransform(-51.5,-39.6);

	this.text_15 = new cjs.Text("2", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(-75.8,-53.6);

	this.text_16 = new cjs.Text("0", "29px Verdana");
	this.text_16.lineHeight = 35;
	this.text_16.setTransform(-67.1,68.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_19.setTransform(-45.7,-383.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA7/MAAAh39");
	this.shape_20.setTransform(-45.7,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.text_16},{t:this.text_15},{t:this.shape_18},{t:this.text_14},{t:this.shape_17},{t:this.text_13},{t:this.shape_16},{t:this.text_12},{t:this.shape_15},{t:this.text_11},{t:this.shape_14},{t:this.text_10}]}).wait(172));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-445.3,964.7,829);


(lib.IMG_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_87 = new cjs.Graphics().p("EgDoAm4MAAAhNvIHRAAMAAABNvg");
	var mask_graphics_88 = new cjs.Graphics().p("EgGjAm4MAAAhNvINHAAMAAABNvg");
	var mask_graphics_89 = new cjs.Graphics().p("EgJeAm4MAAAhNvIS9AAMAAABNvg");
	var mask_graphics_90 = new cjs.Graphics().p("EgMZAm4MAAAhNvIYzAAMAAABNvg");
	var mask_graphics_91 = new cjs.Graphics().p("EgPUAm4MAAAhNvIepAAMAAABNvg");
	var mask_graphics_92 = new cjs.Graphics().p("EgSPAm4MAAAhNvMAkfAAAMAAABNvg");
	var mask_graphics_93 = new cjs.Graphics().p("EgVKAm4MAAAhNvMAqVAAAMAAABNvg");
	var mask_graphics_94 = new cjs.Graphics().p("EgYFAm4MAAAhNvMAwLAAAMAAABNvg");
	var mask_graphics_95 = new cjs.Graphics().p("EgbAAm4MAAAhNvMA2BAAAMAAABNvg");
	var mask_graphics_96 = new cjs.Graphics().p("Egd7Am4MAAAhNvMA73AAAMAAABNvg");
	var mask_graphics_97 = new cjs.Graphics().p("Egg2Am4MAAAhNvMBBtAAAMAAABNvg");
	var mask_graphics_98 = new cjs.Graphics().p("EgjxAm4MAAAhNvMBHjAAAMAAABNvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(87).to({graphics:mask_graphics_87,x:-75.5,y:-216.6}).wait(1).to({graphics:mask_graphics_88,x:-56.8,y:-216.6}).wait(1).to({graphics:mask_graphics_89,x:-38.1,y:-216.6}).wait(1).to({graphics:mask_graphics_90,x:-19.4,y:-216.6}).wait(1).to({graphics:mask_graphics_91,x:-0.7,y:-216.6}).wait(1).to({graphics:mask_graphics_92,x:17.9,y:-216.6}).wait(1).to({graphics:mask_graphics_93,x:36.6,y:-216.6}).wait(1).to({graphics:mask_graphics_94,x:55.3,y:-216.6}).wait(1).to({graphics:mask_graphics_95,x:74,y:-216.6}).wait(1).to({graphics:mask_graphics_96,x:92.7,y:-216.6}).wait(1).to({graphics:mask_graphics_97,x:111.4,y:-216.6}).wait(1).to({graphics:mask_graphics_98,x:130.1,y:-216.6}).wait(25));

	// GRAFICA 3
	this.instance = new lib.Path_15();
	this.instance.setTransform(138.4,-209,1,1,0,0,0,149.3,190.3);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).wait(36));

	// Capa 12 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_65 = new cjs.Graphics().p("AoYBFIAAiJIQxAAIAACJg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AoYCGIAAkLIQxAAIAAELg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AoYDGIAAmLIQxAAIAAGLg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AoYEGIAAoLIQxAAIAAILg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AoYFHIAAqNIQxAAIAAKNg");
	var mask_1_graphics_70 = new cjs.Graphics().p("AoYGHIAAsNIQxAAIAAMNg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AoYHHIAAuNIQxAAIAAONg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AoYIHIAAwNIQxAAIAAQNg");
	var mask_1_graphics_73 = new cjs.Graphics().p("AjsLpIAAyPIQxAAIAASPg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(65).to({graphics:mask_1_graphics_65,x:113.7,y:142.1}).wait(1).to({graphics:mask_1_graphics_66,x:113.7,y:135.6}).wait(1).to({graphics:mask_1_graphics_67,x:113.7,y:129.2}).wait(1).to({graphics:mask_1_graphics_68,x:113.7,y:122.8}).wait(1).to({graphics:mask_1_graphics_69,x:113.7,y:116.3}).wait(1).to({graphics:mask_1_graphics_70,x:113.7,y:109.9}).wait(1).to({graphics:mask_1_graphics_71,x:113.7,y:103.5}).wait(1).to({graphics:mask_1_graphics_72,x:113.7,y:97.1}).wait(1).to({graphics:mask_1_graphics_73,x:83.7,y:74.5}).wait(50));

	// flecha_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhjCpIAehMQAQgsANgqQAghpAIhGQAIBFAhBqQANAsAVA2QARAuAIASg");
	this.shape.setTransform(117,50.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAEMIAAoX");
	this.shape_1.setTransform(117,87.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AgYAqIAPgpQAJgdAAgNQACATAIAXQAIAbAHAOg");
	this.shape_2.setTransform(117,58.3);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},65).wait(58));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_39 = new cjs.Graphics().p("EgN6BEdMAAAiI5IQBAAMAAACI5g");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgKxBEdMAAAiI5IVjAAMAAACI5g");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgNhBEdMAAAiI5IbDAAMAAACI5g");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgQRBEdMAAAiI5MAgjAAAMAAACI5g");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgTBBEdMAAAiI5MAmDAAAMAAACI5g");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgVxBEdMAAAiI5MArjAAAMAAACI5g");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgYiBEdMAAAiI5MAxFAAAMAAACI5g");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgbSBEdMAAAiI5MA2lAAAMAAACI5g");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgeCBEdMAAAiI5MA8FAAAMAAACI5g");
	var mask_2_graphics_48 = new cjs.Graphics().p("EggyBEdMAAAiI5MBBlAAAMAAACI5g");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgjiBEdMAAAiI5MBHFAAAMAAACI5g");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgmTBEdMAAAiI5MBMnAAAMAAACI5g");
	var mask_2_graphics_51 = new cjs.Graphics().p("EgpDBEdMAAAiI5MBSHAAAMAAACI5g");
	var mask_2_graphics_52 = new cjs.Graphics().p("EgrzBEdMAAAiI5MBXnAAAMAAACI5g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(39).to({graphics:mask_2_graphics_39,x:-89.1,y:31.1}).wait(1).to({graphics:mask_2_graphics_40,x:-109.3,y:31.1}).wait(1).to({graphics:mask_2_graphics_41,x:-91.7,y:31.1}).wait(1).to({graphics:mask_2_graphics_42,x:-74,y:31.1}).wait(1).to({graphics:mask_2_graphics_43,x:-56.4,y:31.1}).wait(1).to({graphics:mask_2_graphics_44,x:-38.8,y:31.1}).wait(1).to({graphics:mask_2_graphics_45,x:-21.2,y:31.1}).wait(1).to({graphics:mask_2_graphics_46,x:-3.6,y:31.1}).wait(1).to({graphics:mask_2_graphics_47,x:14,y:31.1}).wait(1).to({graphics:mask_2_graphics_48,x:31.6,y:31.1}).wait(1).to({graphics:mask_2_graphics_49,x:49.2,y:31.1}).wait(1).to({graphics:mask_2_graphics_50,x:66.8,y:31.1}).wait(1).to({graphics:mask_2_graphics_51,x:84.4,y:31.1}).wait(1).to({graphics:mask_2_graphics_52,x:102.1,y:31.1}).wait(71));

	// GRAFICA 1
	this.instance_1 = new lib.Mapadebits4();
	this.instance_1.setTransform(136.8,-400.5);

	this.instance_2 = new lib.Path_17();
	this.instance_2.setTransform(137.2,-96.9,1,1,0,0,0,187.9,301.4);

	this.instance_1.mask = this.instance_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2},{t:this.instance_1}]},39).wait(84));

	// Capa 10 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_14 = new cjs.Graphics().p("AkjFqIAArTIJHAAIAALTg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AlnFqIAArTILPAAIAALTg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AmsFqIAArTINZAAIAALTg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AnxFqIAArTIPjAAIAALTg");
	var mask_3_graphics_18 = new cjs.Graphics().p("Ao1FqIAArTIRrAAIAALTg");
	var mask_3_graphics_19 = new cjs.Graphics().p("Ap6FqIAArTIT1AAIAALTg");
	var mask_3_graphics_20 = new cjs.Graphics().p("Aq/FqIAArTIV/AAIAALTg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AsDFqIAArTIYHAAIAALTg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AtIMMIAArVIaRAAIAALVg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_3_graphics_14,x:-109.4,y:119.9}).wait(1).to({graphics:mask_3_graphics_15,x:-102.5,y:119.9}).wait(1).to({graphics:mask_3_graphics_16,x:-95.6,y:119.9}).wait(1).to({graphics:mask_3_graphics_17,x:-88.8,y:119.9}).wait(1).to({graphics:mask_3_graphics_18,x:-81.9,y:119.9}).wait(1).to({graphics:mask_3_graphics_19,x:-75,y:119.9}).wait(1).to({graphics:mask_3_graphics_20,x:-68.2,y:119.9}).wait(1).to({graphics:mask_3_graphics_21,x:-61.3,y:119.9}).wait(1).to({graphics:mask_3_graphics_22,x:-54.5,y:78.1}).wait(101));

	// flecha
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AiohjIBMAeQAsAQAqANQBqAhBFAHQhGAJhpAgQgsANg2AVQguARgSAIg");
	this.shape_3.setTransform(6.5,118.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("AlTAAIKoAA");
	this.shape_4.setTransform(-37.7,118.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AgpgYIApAPQAXAIATABQgTACgXAIQgbAIgOAHg");
	this.shape_5.setTransform(-1,118.1);

	this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},14).wait(109));

	// GRAFICA 2
	this.instance_3 = new lib.Path_16();
	this.instance_3.setTransform(-200,-94.5,1,1,0,0,0,187.3,299.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(123));

	// EJE ORI
	this.text = new cjs.Text("X", "45px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 49;
	this.text.lineWidth = 31;
	this.text.setTransform(455.8,120.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgmAqIApgqIgpgqIASgSIA7A8Ig7A9g");
	this.shape_6.setTransform(471.2,205.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_7.setTransform(-0.9,205.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.text}]}).wait(123));

	// EJE VERTI
	this.text_1 = new cjs.Text("Y", "45px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 49;
	this.text_1.lineWidth = 31;
	this.text_1.setTransform(-177.8,-458.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_8.setTransform(-199.3,-393.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA9qMAAAh7T");
	this.shape_9.setTransform(-199.3,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.text_1}]}).wait(123));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-458.6,949.4,853.8);

(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,801);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,772);

(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,518,741);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,741);

(lib.IMG_07_bk = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_268 = new cjs.Graphics().p("EgFoA9bMAAAh61ILRAAMAAAB61g");
	var mask_graphics_269 = new cjs.Graphics().p("EgHKA9bMAAAh61IOVAAMAAAB61g");
	var mask_graphics_270 = new cjs.Graphics().p("EgItA9bMAAAh61IRbAAMAAAB61g");
	var mask_graphics_271 = new cjs.Graphics().p("EgKQA9bMAAAh61IUhAAMAAAB61g");
	var mask_graphics_272 = new cjs.Graphics().p("EgLzA9bMAAAh61IXnAAMAAAB61g");
	var mask_graphics_273 = new cjs.Graphics().p("EgNVA9bMAAAh61IarAAMAAAB61g");
	var mask_graphics_274 = new cjs.Graphics().p("EgO4A9bMAAAh61IdxAAMAAAB61g");
	var mask_graphics_275 = new cjs.Graphics().p("EgQbA9bMAAAh61MAg3AAAMAAAB61g");
	var mask_graphics_276 = new cjs.Graphics().p("EgR9A9bMAAAh61MAj7AAAMAAAB61g");
	var mask_graphics_277 = new cjs.Graphics().p("EgTgA9bMAAAh61MAnBAAAMAAAB61g");
	var mask_graphics_278 = new cjs.Graphics().p("EgVDA9bMAAAh61MAqHAAAMAAAB61g");
	var mask_graphics_279 = new cjs.Graphics().p("EgWmA9bMAAAh61MAtNAAAMAAAB61g");
	var mask_graphics_280 = new cjs.Graphics().p("EgYIA9bMAAAh61MAwRAAAMAAAB61g");
	var mask_graphics_281 = new cjs.Graphics().p("EgZrA9bMAAAh61MAzXAAAMAAAB61g");
	var mask_graphics_282 = new cjs.Graphics().p("EgbOA9bMAAAh61MA2dAAAMAAAB61g");
	var mask_graphics_283 = new cjs.Graphics().p("EgcwA9bMAAAh61MA5hAAAMAAAB61g");
	var mask_graphics_284 = new cjs.Graphics().p("EgeTA9bMAAAh61MA8nAAAMAAAB61g");
	var mask_graphics_285 = new cjs.Graphics().p("Egf2A9bMAAAh61MA/tAAAMAAAB61g");
	var mask_graphics_286 = new cjs.Graphics().p("EghZA9bMAAAh61MBCzAAAMAAAB61g");
	var mask_graphics_287 = new cjs.Graphics().p("Egi7A9bMAAAh61MBF3AAAMAAAB61g");
	var mask_graphics_288 = new cjs.Graphics().p("EgkeA9bMAAAh61MBI9AAAMAAAB61g");
	var mask_graphics_289 = new cjs.Graphics().p("EgmBA9bMAAAh61MBMDAAAMAAAB61g");
	var mask_graphics_290 = new cjs.Graphics().p("EgnjA9bMAAAh61MBPHAAAMAAAB61g");
	var mask_graphics_291 = new cjs.Graphics().p("EgpGA9bMAAAh61MBSNAAAMAAAB61g");
	var mask_graphics_292 = new cjs.Graphics().p("EgqpA9bMAAAh61MBVTAAAMAAAB61g");
	var mask_graphics_293 = new cjs.Graphics().p("EgsMA9bMAAAh61MBYZAAAMAAAB61g");
	var mask_graphics_294 = new cjs.Graphics().p("EgtuA9bMAAAh61MBbdAAAMAAAB61g");
	var mask_graphics_295 = new cjs.Graphics().p("EgvRA9bMAAAh61MBejAAAMAAAB61g");
	var mask_graphics_296 = new cjs.Graphics().p("Egw0A9bMAAAh61MBhpAAAMAAAB61g");
	var mask_graphics_297 = new cjs.Graphics().p("EgyWA9bMAAAh61MBktAAAMAAAB61g");
	var mask_graphics_298 = new cjs.Graphics().p("Egz5A9bMAAAh61MBnzAAAMAAAB61g");
	var mask_graphics_299 = new cjs.Graphics().p("Eg1cA9bMAAAh61MBq5AAAMAAAB61g");
	var mask_graphics_300 = new cjs.Graphics().p("Eg2/A9bMAAAh61MBt/AAAMAAAB61g");
	var mask_graphics_301 = new cjs.Graphics().p("Eg4hA9bMAAAh61MBxDAAAMAAAB61g");
	var mask_graphics_302 = new cjs.Graphics().p("Eg6EA9bMAAAh61MB0JAAAMAAAB61g");
	var mask_graphics_303 = new cjs.Graphics().p("Eg7nA9bMAAAh61MB3PAAAMAAAB61g");
	var mask_graphics_304 = new cjs.Graphics().p("Eg9JA9bMAAAh61MB6TAAAMAAAB61g");
	var mask_graphics_305 = new cjs.Graphics().p("Eg+sA9bMAAAh61MB9ZAAAMAAAB61g");
	var mask_graphics_306 = new cjs.Graphics().p("EhAPA9bMAAAh61MCAfAAAMAAAB61g");
	var mask_graphics_307 = new cjs.Graphics().p("EhByA9bMAAAh61MCDlAAAMAAAB61g");
	var mask_graphics_308 = new cjs.Graphics().p("EhDUA9bMAAAh61MCGpAAAMAAAB61g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(268).to({graphics:mask_graphics_268,x:-386.5,y:-12.4}).wait(1).to({graphics:mask_graphics_269,x:-376.6,y:-12.4}).wait(1).to({graphics:mask_graphics_270,x:-366.8,y:-12.4}).wait(1).to({graphics:mask_graphics_271,x:-356.9,y:-12.4}).wait(1).to({graphics:mask_graphics_272,x:-347,y:-12.4}).wait(1).to({graphics:mask_graphics_273,x:-337.1,y:-12.4}).wait(1).to({graphics:mask_graphics_274,x:-327.3,y:-12.4}).wait(1).to({graphics:mask_graphics_275,x:-317.4,y:-12.4}).wait(1).to({graphics:mask_graphics_276,x:-307.5,y:-12.4}).wait(1).to({graphics:mask_graphics_277,x:-297.6,y:-12.4}).wait(1).to({graphics:mask_graphics_278,x:-287.8,y:-12.4}).wait(1).to({graphics:mask_graphics_279,x:-277.9,y:-12.4}).wait(1).to({graphics:mask_graphics_280,x:-268,y:-12.4}).wait(1).to({graphics:mask_graphics_281,x:-258.1,y:-12.4}).wait(1).to({graphics:mask_graphics_282,x:-248.3,y:-12.4}).wait(1).to({graphics:mask_graphics_283,x:-238.4,y:-12.4}).wait(1).to({graphics:mask_graphics_284,x:-228.5,y:-12.4}).wait(1).to({graphics:mask_graphics_285,x:-218.6,y:-12.4}).wait(1).to({graphics:mask_graphics_286,x:-208.8,y:-12.4}).wait(1).to({graphics:mask_graphics_287,x:-198.9,y:-12.4}).wait(1).to({graphics:mask_graphics_288,x:-189,y:-12.4}).wait(1).to({graphics:mask_graphics_289,x:-179.1,y:-12.4}).wait(1).to({graphics:mask_graphics_290,x:-169.2,y:-12.4}).wait(1).to({graphics:mask_graphics_291,x:-159.4,y:-12.4}).wait(1).to({graphics:mask_graphics_292,x:-149.5,y:-12.4}).wait(1).to({graphics:mask_graphics_293,x:-139.6,y:-12.4}).wait(1).to({graphics:mask_graphics_294,x:-129.7,y:-12.4}).wait(1).to({graphics:mask_graphics_295,x:-119.9,y:-12.4}).wait(1).to({graphics:mask_graphics_296,x:-110,y:-12.4}).wait(1).to({graphics:mask_graphics_297,x:-100.1,y:-12.4}).wait(1).to({graphics:mask_graphics_298,x:-90.2,y:-12.4}).wait(1).to({graphics:mask_graphics_299,x:-80.4,y:-12.4}).wait(1).to({graphics:mask_graphics_300,x:-70.5,y:-12.4}).wait(1).to({graphics:mask_graphics_301,x:-60.6,y:-12.4}).wait(1).to({graphics:mask_graphics_302,x:-50.7,y:-12.4}).wait(1).to({graphics:mask_graphics_303,x:-40.9,y:-12.4}).wait(1).to({graphics:mask_graphics_304,x:-31,y:-12.4}).wait(1).to({graphics:mask_graphics_305,x:-21.1,y:-12.4}).wait(1).to({graphics:mask_graphics_306,x:-11.2,y:-12.4}).wait(1).to({graphics:mask_graphics_307,x:-1.4,y:-12.4}).wait(1).to({graphics:mask_graphics_308,x:8.4,y:-12.4}).wait(16));

	// GRAFICA 1
	this.instance = new lib.Path_1_1();
	this.instance.setTransform(-75.2,0.8,1,1,0,0,0,2,368.3);

	this.instance_1 = new lib.Path_22();
	this.instance_1.setTransform(-73.6,-85.8,1,1,0,0,0,258.9,286);

	this.instance.mask = this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},268).wait(56));

	// Capa 12 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_234 = new cjs.Graphics().p("AjaGAIAAr/IG1AAIAAL/g");
	var mask_1_graphics_235 = new cjs.Graphics().p("Aj4GAIAAr/IHxAAIAAL/g");
	var mask_1_graphics_236 = new cjs.Graphics().p("AkWGAIAAr/IItAAIAAL/g");
	var mask_1_graphics_237 = new cjs.Graphics().p("Ak0GAIAAr/IJpAAIAAL/g");
	var mask_1_graphics_238 = new cjs.Graphics().p("AlSGAIAAr/IKlAAIAAL/g");
	var mask_1_graphics_239 = new cjs.Graphics().p("AlwGAIAAr/ILhAAIAAL/g");
	var mask_1_graphics_240 = new cjs.Graphics().p("AmOGAIAAr/IMdAAIAAL/g");
	var mask_1_graphics_241 = new cjs.Graphics().p("AmsGAIAAr/INZAAIAAL/g");
	var mask_1_graphics_242 = new cjs.Graphics().p("AnKGAIAAr/IOVAAIAAL/g");
	var mask_1_graphics_243 = new cjs.Graphics().p("AnoGAIAAr/IPRAAIAAL/g");
	var mask_1_graphics_244 = new cjs.Graphics().p("AoGGAIAAr/IQNAAIAAL/g");
	var mask_1_graphics_245 = new cjs.Graphics().p("AokGAIAAr/IRJAAIAAL/g");
	var mask_1_graphics_246 = new cjs.Graphics().p("ApCGAIAAr/ISFAAIAAL/g");
	var mask_1_graphics_247 = new cjs.Graphics().p("ApgGAIAAr/ITBAAIAAL/g");
	var mask_1_graphics_248 = new cjs.Graphics().p("Ap+GAIAAr/IT9AAIAAL/g");
	var mask_1_graphics_249 = new cjs.Graphics().p("AqcGAIAAr/IU5AAIAAL/g");
	var mask_1_graphics_250 = new cjs.Graphics().p("Aq6GAIAAr/IV1AAIAAL/g");
	var mask_1_graphics_251 = new cjs.Graphics().p("ArYmaIAAsBIWxAAIAAMBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(234).to({graphics:mask_1_graphics_234,x:70.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_235,x:67.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_236,x:64.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_237,x:61.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_238,x:58.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_239,x:55.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_240,x:52.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_241,x:49.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_242,x:46.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_243,x:43.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_244,x:40.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_245,x:37.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_246,x:34.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_247,x:31.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_248,x:28.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_249,x:25.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_250,x:22.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_251,x:19.1,y:-118}).wait(73));

	// flecha iz
	this.text = new cjs.Text("p>0 ", "italic bold 36px Verdana", "#FF0000");
	this.text.lineHeight = 36;
	this.text.lineWidth = 128;
	this.text.setTransform(-51.4,-243.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhpgghGgJQBAgGBvghQAsgOA2gUQAtgRATgJIAADHIhMgeg");
	this.shape.setTransform(-30.8,-186.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AEMAAIoXAA");
	this.shape_1.setTransform(6.1,-186.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AACAKQgYgIgTgCQARAAAagJQAagIAOgHIAAAxQgagLgOgEg");
	this.shape_2.setTransform(-23.2,-186.8);

	this.text.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text}]},234).wait(90));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_132 = new cjs.Graphics().p("EgSDA8sMAAAh5XIPdAAMAAAB5Xg");
	var mask_2_graphics_133 = new cjs.Graphics().p("EgI1A8sMAAAh5XIRrAAMAAAB5Xg");
	var mask_2_graphics_134 = new cjs.Graphics().p("EgJ9A8sMAAAh5XIT7AAMAAAB5Xg");
	var mask_2_graphics_135 = new cjs.Graphics().p("EgLEA8sMAAAh5XIWJAAMAAAB5Xg");
	var mask_2_graphics_136 = new cjs.Graphics().p("EgMMA8sMAAAh5XIYZAAMAAAB5Xg");
	var mask_2_graphics_137 = new cjs.Graphics().p("EgNUA8sMAAAh5XIapAAMAAAB5Xg");
	var mask_2_graphics_138 = new cjs.Graphics().p("EgOcA8sMAAAh5XIc5AAMAAAB5Xg");
	var mask_2_graphics_139 = new cjs.Graphics().p("EgPkA8sMAAAh5XIfJAAMAAAB5Xg");
	var mask_2_graphics_140 = new cjs.Graphics().p("EgQsA8sMAAAh5XMAhZAAAMAAAB5Xg");
	var mask_2_graphics_141 = new cjs.Graphics().p("EgRzA8sMAAAh5XMAjnAAAMAAAB5Xg");
	var mask_2_graphics_142 = new cjs.Graphics().p("EgS7A8sMAAAh5XMAl3AAAMAAAB5Xg");
	var mask_2_graphics_143 = new cjs.Graphics().p("EgUDA8sMAAAh5XMAoHAAAMAAAB5Xg");
	var mask_2_graphics_144 = new cjs.Graphics().p("EgVLA8sMAAAh5XMAqXAAAMAAAB5Xg");
	var mask_2_graphics_145 = new cjs.Graphics().p("EgWTA8sMAAAh5XMAsnAAAMAAAB5Xg");
	var mask_2_graphics_146 = new cjs.Graphics().p("EgXbA8sMAAAh5XMAu3AAAMAAAB5Xg");
	var mask_2_graphics_147 = new cjs.Graphics().p("EgYiA8sMAAAh5XMAxFAAAMAAAB5Xg");
	var mask_2_graphics_148 = new cjs.Graphics().p("EgZqA8sMAAAh5XMAzVAAAMAAAB5Xg");
	var mask_2_graphics_149 = new cjs.Graphics().p("EgayA8sMAAAh5XMA1lAAAMAAAB5Xg");
	var mask_2_graphics_150 = new cjs.Graphics().p("Egb6A8sMAAAh5XMA31AAAMAAAB5Xg");
	var mask_2_graphics_151 = new cjs.Graphics().p("EgdCA8sMAAAh5XMA6FAAAMAAAB5Xg");
	var mask_2_graphics_152 = new cjs.Graphics().p("EgeKA8sMAAAh5XMA8VAAAMAAAB5Xg");
	var mask_2_graphics_153 = new cjs.Graphics().p("EgfRA8sMAAAh5XMA+jAAAMAAAB5Xg");
	var mask_2_graphics_154 = new cjs.Graphics().p("EggZA8sMAAAh5XMBAzAAAMAAAB5Xg");
	var mask_2_graphics_155 = new cjs.Graphics().p("EghhA8sMAAAh5XMBDDAAAMAAAB5Xg");
	var mask_2_graphics_156 = new cjs.Graphics().p("EgipA8sMAAAh5XMBFTAAAMAAAB5Xg");
	var mask_2_graphics_157 = new cjs.Graphics().p("EgjxA8sMAAAh5XMBHjAAAMAAAB5Xg");
	var mask_2_graphics_158 = new cjs.Graphics().p("Egk5A8sMAAAh5XMBJyAAAMAAAB5Xg");
	var mask_2_graphics_159 = new cjs.Graphics().p("EgmAA8sMAAAh5XMBMBAAAMAAAB5Xg");
	var mask_2_graphics_160 = new cjs.Graphics().p("EgnIA8sMAAAh5XMBORAAAMAAAB5Xg");
	var mask_2_graphics_161 = new cjs.Graphics().p("EgoQA8sMAAAh5XMBQhAAAMAAAB5Xg");
	var mask_2_graphics_162 = new cjs.Graphics().p("EgpYA8sMAAAh5XMBSxAAAMAAAB5Xg");
	var mask_2_graphics_163 = new cjs.Graphics().p("EgqgA8sMAAAh5XMBVBAAAMAAAB5Xg");
	var mask_2_graphics_164 = new cjs.Graphics().p("EgrnA8sMAAAh5XMBXPAAAMAAAB5Xg");
	var mask_2_graphics_165 = new cjs.Graphics().p("EgsvA8sMAAAh5XMBZfAAAMAAAB5Xg");
	var mask_2_graphics_166 = new cjs.Graphics().p("Egt3A8sMAAAh5XMBbvAAAMAAAB5Xg");
	var mask_2_graphics_167 = new cjs.Graphics().p("Egu/A8sMAAAh5XMBd/AAAMAAAB5Xg");
	var mask_2_graphics_168 = new cjs.Graphics().p("EgwHA8sMAAAh5XMBgPAAAMAAAB5Xg");
	var mask_2_graphics_169 = new cjs.Graphics().p("EgxPA8sMAAAh5XMBifAAAMAAAB5Xg");
	var mask_2_graphics_170 = new cjs.Graphics().p("EgyWA8sMAAAh5XMBktAAAMAAAB5Xg");
	var mask_2_graphics_171 = new cjs.Graphics().p("EgzeA8sMAAAh5XMBm9AAAMAAAB5Xg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(132).to({graphics:mask_2_graphics_132,x:-115.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_133,x:-174.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_134,x:-167.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_135,x:-160.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_136,x:-152.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_137,x:-145.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_138,x:-138.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_139,x:-131.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_140,x:-124.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_141,x:-117,y:3.2}).wait(1).to({graphics:mask_2_graphics_142,x:-109.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_143,x:-102.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_144,x:-95.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_145,x:-88.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_146,x:-81.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_147,x:-73.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_148,x:-66.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_149,x:-59.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_150,x:-52.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_151,x:-45.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_152,x:-38,y:3.2}).wait(1).to({graphics:mask_2_graphics_153,x:-30.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_154,x:-23.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_155,x:-16.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_156,x:-9.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_157,x:-2.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_158,x:5,y:3.2}).wait(1).to({graphics:mask_2_graphics_159,x:12.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_160,x:19.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_161,x:26.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_162,x:33.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_163,x:40.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_164,x:48.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_165,x:55.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_166,x:62.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_167,x:69.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_168,x:76.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_169,x:84,y:3.2}).wait(1).to({graphics:mask_2_graphics_170,x:91.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_171,x:98.4,y:3.2}).wait(153));

	// GRAFICA 3
	this.instance_2 = new lib.Path_23();
	this.instance_2.setTransform(156.9,-2.3,1,1,0,0,0,2,368.3);

	this.instance_3 = new lib.Path_20();
	this.instance_3.setTransform(155.3,-85.5,1,1,0,0,0,258.9,286);

	this.instance_2.mask = this.instance_3.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3},{t:this.instance_2}]},132).wait(192));

	// Capa 10 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_89 = new cjs.Graphics().p("AkJnCIAAsAIITAAIAAMAg");
	var mask_3_graphics_90 = new cjs.Graphics().p("AkoGAIAAr/IJRAAIAAL/g");
	var mask_3_graphics_91 = new cjs.Graphics().p("AlHGAIAAr/IKPAAIAAL/g");
	var mask_3_graphics_92 = new cjs.Graphics().p("AlmGAIAAr/ILNAAIAAL/g");
	var mask_3_graphics_93 = new cjs.Graphics().p("AmFGAIAAr/IMLAAIAAL/g");
	var mask_3_graphics_94 = new cjs.Graphics().p("AmkGAIAAr/INJAAIAAL/g");
	var mask_3_graphics_95 = new cjs.Graphics().p("AnDGAIAAr/IOHAAIAAL/g");
	var mask_3_graphics_96 = new cjs.Graphics().p("AnhGAIAAr/IPDAAIAAL/g");
	var mask_3_graphics_97 = new cjs.Graphics().p("AoAGAIAAr/IQBAAIAAL/g");
	var mask_3_graphics_98 = new cjs.Graphics().p("AofGAIAAr/IQ/AAIAAL/g");
	var mask_3_graphics_99 = new cjs.Graphics().p("Ao+GAIAAr/IR9AAIAAL/g");
	var mask_3_graphics_100 = new cjs.Graphics().p("ApdGAIAAr/IS7AAIAAL/g");
	var mask_3_graphics_101 = new cjs.Graphics().p("Ap8GAIAAr/IT5AAIAAL/g");
	var mask_3_graphics_102 = new cjs.Graphics().p("AqbGAIAAr/IU3AAIAAL/g");
	var mask_3_graphics_103 = new cjs.Graphics().p("Aq6GAIAAr/IV1AAIAAL/g");
	var mask_3_graphics_104 = new cjs.Graphics().p("ArZGAIAAr/IWzAAIAAL/g");
	var mask_3_graphics_105 = new cjs.Graphics().p("Ar4GAIAAr/IXxAAIAAL/g");
	var mask_3_graphics_106 = new cjs.Graphics().p("AsXnCIAAsAIYvAAIAAMAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(89).to({graphics:mask_3_graphics_89,x:12.1,y:-121.9}).wait(1).to({graphics:mask_3_graphics_90,x:15.2,y:-205.5}).wait(1).to({graphics:mask_3_graphics_91,x:18.3,y:-205.5}).wait(1).to({graphics:mask_3_graphics_92,x:21.4,y:-205.5}).wait(1).to({graphics:mask_3_graphics_93,x:24.5,y:-205.5}).wait(1).to({graphics:mask_3_graphics_94,x:27.6,y:-205.5}).wait(1).to({graphics:mask_3_graphics_95,x:30.7,y:-205.5}).wait(1).to({graphics:mask_3_graphics_96,x:33.7,y:-205.5}).wait(1).to({graphics:mask_3_graphics_97,x:36.8,y:-205.5}).wait(1).to({graphics:mask_3_graphics_98,x:39.9,y:-205.5}).wait(1).to({graphics:mask_3_graphics_99,x:43,y:-205.5}).wait(1).to({graphics:mask_3_graphics_100,x:46.1,y:-205.5}).wait(1).to({graphics:mask_3_graphics_101,x:49.2,y:-205.5}).wait(1).to({graphics:mask_3_graphics_102,x:52.3,y:-205.5}).wait(1).to({graphics:mask_3_graphics_103,x:55.4,y:-205.5}).wait(1).to({graphics:mask_3_graphics_104,x:58.5,y:-205.5}).wait(1).to({graphics:mask_3_graphics_105,x:61.6,y:-205.5}).wait(1).to({graphics:mask_3_graphics_106,x:64.7,y:-121.9}).wait(218));

	// flecha dcha
	this.text_1 = new cjs.Text("p<0", "italic bold 36px Verdana", "#FF0000");
	this.text_1.lineHeight = 36;
	this.text_1.lineWidth = 128;
	this.text_1.setTransform(52.4,-243.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AiohkIBMAfQArAQArAOQBvAhBAAGQhGAJhpAgQgsANg2AVQgtAQgTAKg");
	this.shape_3.setTransform(110.5,-187.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("AkLAAIIXAA");
	this.shape_4.setTransform(73.5,-187.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AgpgYQAXAKASAFQAWAIAUABQgOABgcAJQgVAGgUAJg");
	this.shape_5.setTransform(102.9,-187.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AiohkIBMAfQArAQArAOQBvAhBAAGQhGAJhpAgQgsANg2AVQgtAQgTAKg");
	this.shape_6.setTransform(110.5,-187.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF0000").ss(4,0,0,4).p("AkLAAIIXAA");
	this.shape_7.setTransform(73.5,-187.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AgpgYQAXAKASAFQAWAIAUABQgOABgcAJQgVAGgUAJg");
	this.shape_8.setTransform(102.9,-187.1);

	this.text_1.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_1}]},89).wait(235));

	// GRAFICA 2
	this.instance_4 = new lib.Path_21();
	this.instance_4.setTransform(40.3,-85.5,1,1,0,0,0,258.9,286);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).wait(324));

	// EJE ORI
	this.text_2 = new cjs.Text("X", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 34;
	this.text_2.lineWidth = 33;
	this.text_2.setTransform(491.8,154.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_9.setTransform(471.2,200.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_10.setTransform(-0.9,200.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.text_2}]}).wait(324));

	// EJE VERTI
	this.text_3 = new cjs.Text("Y", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 34;
	this.text_3.lineWidth = 33;
	this.text_3.setTransform(49.8,-429.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_11.setTransform(39.2,-366.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_12.setTransform(39.2,1.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.text_3}]}).wait(324));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-429.5,986.6,800.8);

(lib.IMG_07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 13 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_268 = new cjs.Graphics().p("EgFoA9bMAAAh61ILRAAMAAAB61g");
	var mask_graphics_269 = new cjs.Graphics().p("EgHKA9bMAAAh61IOVAAMAAAB61g");
	var mask_graphics_270 = new cjs.Graphics().p("EgItA9bMAAAh61IRbAAMAAAB61g");
	var mask_graphics_271 = new cjs.Graphics().p("EgKQA9bMAAAh61IUhAAMAAAB61g");
	var mask_graphics_272 = new cjs.Graphics().p("EgLzA9bMAAAh61IXnAAMAAAB61g");
	var mask_graphics_273 = new cjs.Graphics().p("EgNVA9bMAAAh61IarAAMAAAB61g");
	var mask_graphics_274 = new cjs.Graphics().p("EgO4A9bMAAAh61IdxAAMAAAB61g");
	var mask_graphics_275 = new cjs.Graphics().p("EgQbA9bMAAAh61MAg3AAAMAAAB61g");
	var mask_graphics_276 = new cjs.Graphics().p("EgR9A9bMAAAh61MAj7AAAMAAAB61g");
	var mask_graphics_277 = new cjs.Graphics().p("EgTgA9bMAAAh61MAnBAAAMAAAB61g");
	var mask_graphics_278 = new cjs.Graphics().p("EgVDA9bMAAAh61MAqHAAAMAAAB61g");
	var mask_graphics_279 = new cjs.Graphics().p("EgWmA9bMAAAh61MAtNAAAMAAAB61g");
	var mask_graphics_280 = new cjs.Graphics().p("EgYIA9bMAAAh61MAwRAAAMAAAB61g");
	var mask_graphics_281 = new cjs.Graphics().p("EgZrA9bMAAAh61MAzXAAAMAAAB61g");
	var mask_graphics_282 = new cjs.Graphics().p("EgbOA9bMAAAh61MA2dAAAMAAAB61g");
	var mask_graphics_283 = new cjs.Graphics().p("EgcwA9bMAAAh61MA5hAAAMAAAB61g");
	var mask_graphics_284 = new cjs.Graphics().p("EgeTA9bMAAAh61MA8nAAAMAAAB61g");
	var mask_graphics_285 = new cjs.Graphics().p("Egf2A9bMAAAh61MA/tAAAMAAAB61g");
	var mask_graphics_286 = new cjs.Graphics().p("EghZA9bMAAAh61MBCzAAAMAAAB61g");
	var mask_graphics_287 = new cjs.Graphics().p("Egi7A9bMAAAh61MBF3AAAMAAAB61g");
	var mask_graphics_288 = new cjs.Graphics().p("EgkeA9bMAAAh61MBI9AAAMAAAB61g");
	var mask_graphics_289 = new cjs.Graphics().p("EgmBA9bMAAAh61MBMDAAAMAAAB61g");
	var mask_graphics_290 = new cjs.Graphics().p("EgnjA9bMAAAh61MBPHAAAMAAAB61g");
	var mask_graphics_291 = new cjs.Graphics().p("EgpGA9bMAAAh61MBSNAAAMAAAB61g");
	var mask_graphics_292 = new cjs.Graphics().p("EgqpA9bMAAAh61MBVTAAAMAAAB61g");
	var mask_graphics_293 = new cjs.Graphics().p("EgsMA9bMAAAh61MBYZAAAMAAAB61g");
	var mask_graphics_294 = new cjs.Graphics().p("EgtuA9bMAAAh61MBbdAAAMAAAB61g");
	var mask_graphics_295 = new cjs.Graphics().p("EgvRA9bMAAAh61MBejAAAMAAAB61g");
	var mask_graphics_296 = new cjs.Graphics().p("Egw0A9bMAAAh61MBhpAAAMAAAB61g");
	var mask_graphics_297 = new cjs.Graphics().p("EgyWA9bMAAAh61MBktAAAMAAAB61g");
	var mask_graphics_298 = new cjs.Graphics().p("Egz5A9bMAAAh61MBnzAAAMAAAB61g");
	var mask_graphics_299 = new cjs.Graphics().p("Eg1cA9bMAAAh61MBq5AAAMAAAB61g");
	var mask_graphics_300 = new cjs.Graphics().p("Eg2/A9bMAAAh61MBt/AAAMAAAB61g");
	var mask_graphics_301 = new cjs.Graphics().p("Eg4hA9bMAAAh61MBxDAAAMAAAB61g");
	var mask_graphics_302 = new cjs.Graphics().p("Eg6EA9bMAAAh61MB0JAAAMAAAB61g");
	var mask_graphics_303 = new cjs.Graphics().p("Eg7nA9bMAAAh61MB3PAAAMAAAB61g");
	var mask_graphics_304 = new cjs.Graphics().p("Eg9JA9bMAAAh61MB6TAAAMAAAB61g");
	var mask_graphics_305 = new cjs.Graphics().p("Eg+sA9bMAAAh61MB9ZAAAMAAAB61g");
	var mask_graphics_306 = new cjs.Graphics().p("EhAPA9bMAAAh61MCAfAAAMAAAB61g");
	var mask_graphics_307 = new cjs.Graphics().p("EhByA9bMAAAh61MCDlAAAMAAAB61g");
	var mask_graphics_308 = new cjs.Graphics().p("EhDUA9bMAAAh61MCGpAAAMAAAB61g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(268).to({graphics:mask_graphics_268,x:-386.5,y:-12.4}).wait(1).to({graphics:mask_graphics_269,x:-376.6,y:-12.4}).wait(1).to({graphics:mask_graphics_270,x:-366.8,y:-12.4}).wait(1).to({graphics:mask_graphics_271,x:-356.9,y:-12.4}).wait(1).to({graphics:mask_graphics_272,x:-347,y:-12.4}).wait(1).to({graphics:mask_graphics_273,x:-337.1,y:-12.4}).wait(1).to({graphics:mask_graphics_274,x:-327.3,y:-12.4}).wait(1).to({graphics:mask_graphics_275,x:-317.4,y:-12.4}).wait(1).to({graphics:mask_graphics_276,x:-307.5,y:-12.4}).wait(1).to({graphics:mask_graphics_277,x:-297.6,y:-12.4}).wait(1).to({graphics:mask_graphics_278,x:-287.8,y:-12.4}).wait(1).to({graphics:mask_graphics_279,x:-277.9,y:-12.4}).wait(1).to({graphics:mask_graphics_280,x:-268,y:-12.4}).wait(1).to({graphics:mask_graphics_281,x:-258.1,y:-12.4}).wait(1).to({graphics:mask_graphics_282,x:-248.3,y:-12.4}).wait(1).to({graphics:mask_graphics_283,x:-238.4,y:-12.4}).wait(1).to({graphics:mask_graphics_284,x:-228.5,y:-12.4}).wait(1).to({graphics:mask_graphics_285,x:-218.6,y:-12.4}).wait(1).to({graphics:mask_graphics_286,x:-208.8,y:-12.4}).wait(1).to({graphics:mask_graphics_287,x:-198.9,y:-12.4}).wait(1).to({graphics:mask_graphics_288,x:-189,y:-12.4}).wait(1).to({graphics:mask_graphics_289,x:-179.1,y:-12.4}).wait(1).to({graphics:mask_graphics_290,x:-169.2,y:-12.4}).wait(1).to({graphics:mask_graphics_291,x:-159.4,y:-12.4}).wait(1).to({graphics:mask_graphics_292,x:-149.5,y:-12.4}).wait(1).to({graphics:mask_graphics_293,x:-139.6,y:-12.4}).wait(1).to({graphics:mask_graphics_294,x:-129.7,y:-12.4}).wait(1).to({graphics:mask_graphics_295,x:-119.9,y:-12.4}).wait(1).to({graphics:mask_graphics_296,x:-110,y:-12.4}).wait(1).to({graphics:mask_graphics_297,x:-100.1,y:-12.4}).wait(1).to({graphics:mask_graphics_298,x:-90.2,y:-12.4}).wait(1).to({graphics:mask_graphics_299,x:-80.4,y:-12.4}).wait(1).to({graphics:mask_graphics_300,x:-70.5,y:-12.4}).wait(1).to({graphics:mask_graphics_301,x:-60.6,y:-12.4}).wait(1).to({graphics:mask_graphics_302,x:-50.7,y:-12.4}).wait(1).to({graphics:mask_graphics_303,x:-40.9,y:-12.4}).wait(1).to({graphics:mask_graphics_304,x:-31,y:-12.4}).wait(1).to({graphics:mask_graphics_305,x:-21.1,y:-12.4}).wait(1).to({graphics:mask_graphics_306,x:-11.2,y:-12.4}).wait(1).to({graphics:mask_graphics_307,x:-1.4,y:-12.4}).wait(1).to({graphics:mask_graphics_308,x:8.4,y:-12.4}).wait(16));

	// GRAFICA 1
	this.instance = new lib.Mapadebits3();
	this.instance.setTransform(-77.2,-369.4);

	this.instance_1 = new lib.Path_21();
	this.instance_1.setTransform(-73.6,-85.8,1,1,0,0,0,258.9,286);

	this.instance.mask = this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},268).wait(56));

	// Capa 12 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_234 = new cjs.Graphics().p("AjaGAIAAr/IG1AAIAAL/g");
	var mask_1_graphics_235 = new cjs.Graphics().p("Aj4GAIAAr/IHxAAIAAL/g");
	var mask_1_graphics_236 = new cjs.Graphics().p("AkWGAIAAr/IItAAIAAL/g");
	var mask_1_graphics_237 = new cjs.Graphics().p("Ak0GAIAAr/IJpAAIAAL/g");
	var mask_1_graphics_238 = new cjs.Graphics().p("AlSGAIAAr/IKlAAIAAL/g");
	var mask_1_graphics_239 = new cjs.Graphics().p("AlwGAIAAr/ILhAAIAAL/g");
	var mask_1_graphics_240 = new cjs.Graphics().p("AmOGAIAAr/IMdAAIAAL/g");
	var mask_1_graphics_241 = new cjs.Graphics().p("AmsGAIAAr/INZAAIAAL/g");
	var mask_1_graphics_242 = new cjs.Graphics().p("AnKGAIAAr/IOVAAIAAL/g");
	var mask_1_graphics_243 = new cjs.Graphics().p("AnoGAIAAr/IPRAAIAAL/g");
	var mask_1_graphics_244 = new cjs.Graphics().p("AoGGAIAAr/IQNAAIAAL/g");
	var mask_1_graphics_245 = new cjs.Graphics().p("AokGAIAAr/IRJAAIAAL/g");
	var mask_1_graphics_246 = new cjs.Graphics().p("ApCGAIAAr/ISFAAIAAL/g");
	var mask_1_graphics_247 = new cjs.Graphics().p("ApgGAIAAr/ITBAAIAAL/g");
	var mask_1_graphics_248 = new cjs.Graphics().p("Ap+GAIAAr/IT9AAIAAL/g");
	var mask_1_graphics_249 = new cjs.Graphics().p("AqcGAIAAr/IU5AAIAAL/g");
	var mask_1_graphics_250 = new cjs.Graphics().p("Aq6GAIAAr/IV1AAIAAL/g");
	var mask_1_graphics_251 = new cjs.Graphics().p("ArYmaIAAsBIWxAAIAAMBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(234).to({graphics:mask_1_graphics_234,x:70.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_235,x:67.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_236,x:64.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_237,x:61.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_238,x:58.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_239,x:55.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_240,x:52.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_241,x:49.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_242,x:46.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_243,x:43.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_244,x:40.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_245,x:37.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_246,x:34.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_247,x:31.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_248,x:28.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_249,x:25.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_250,x:22.1,y:-197.6}).wait(1).to({graphics:mask_1_graphics_251,x:19.1,y:-118}).wait(73));

	// flecha iz
	this.text = new cjs.Text("p>0 ", "italic bold 36px Verdana", "#FF0000");
	this.text.lineHeight = 36;
	this.text.lineWidth = 128;
	this.text.setTransform(-51.4,-243.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhpgghGgJQBAgGBvghQAsgOA2gUQAtgRATgJIAADHIhMgeg");
	this.shape.setTransform(-30.8,-186.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AEMAAIoXAA");
	this.shape_1.setTransform(6.1,-186.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AACAKQgYgIgTgCQARAAAagJQAagIAOgHIAAAxQgagLgOgEg");
	this.shape_2.setTransform(-23.2,-186.8);

	this.text.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text}]},234).wait(90));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_132 = new cjs.Graphics().p("EgSDA8sMAAAh5XIPdAAMAAAB5Xg");
	var mask_2_graphics_133 = new cjs.Graphics().p("EgI1A8sMAAAh5XIRrAAMAAAB5Xg");
	var mask_2_graphics_134 = new cjs.Graphics().p("EgJ9A8sMAAAh5XIT7AAMAAAB5Xg");
	var mask_2_graphics_135 = new cjs.Graphics().p("EgLEA8sMAAAh5XIWJAAMAAAB5Xg");
	var mask_2_graphics_136 = new cjs.Graphics().p("EgMMA8sMAAAh5XIYZAAMAAAB5Xg");
	var mask_2_graphics_137 = new cjs.Graphics().p("EgNUA8sMAAAh5XIapAAMAAAB5Xg");
	var mask_2_graphics_138 = new cjs.Graphics().p("EgOcA8sMAAAh5XIc5AAMAAAB5Xg");
	var mask_2_graphics_139 = new cjs.Graphics().p("EgPkA8sMAAAh5XIfJAAMAAAB5Xg");
	var mask_2_graphics_140 = new cjs.Graphics().p("EgQsA8sMAAAh5XMAhZAAAMAAAB5Xg");
	var mask_2_graphics_141 = new cjs.Graphics().p("EgRzA8sMAAAh5XMAjnAAAMAAAB5Xg");
	var mask_2_graphics_142 = new cjs.Graphics().p("EgS7A8sMAAAh5XMAl3AAAMAAAB5Xg");
	var mask_2_graphics_143 = new cjs.Graphics().p("EgUDA8sMAAAh5XMAoHAAAMAAAB5Xg");
	var mask_2_graphics_144 = new cjs.Graphics().p("EgVLA8sMAAAh5XMAqXAAAMAAAB5Xg");
	var mask_2_graphics_145 = new cjs.Graphics().p("EgWTA8sMAAAh5XMAsnAAAMAAAB5Xg");
	var mask_2_graphics_146 = new cjs.Graphics().p("EgXbA8sMAAAh5XMAu3AAAMAAAB5Xg");
	var mask_2_graphics_147 = new cjs.Graphics().p("EgYiA8sMAAAh5XMAxFAAAMAAAB5Xg");
	var mask_2_graphics_148 = new cjs.Graphics().p("EgZqA8sMAAAh5XMAzVAAAMAAAB5Xg");
	var mask_2_graphics_149 = new cjs.Graphics().p("EgayA8sMAAAh5XMA1lAAAMAAAB5Xg");
	var mask_2_graphics_150 = new cjs.Graphics().p("Egb6A8sMAAAh5XMA31AAAMAAAB5Xg");
	var mask_2_graphics_151 = new cjs.Graphics().p("EgdCA8sMAAAh5XMA6FAAAMAAAB5Xg");
	var mask_2_graphics_152 = new cjs.Graphics().p("EgeKA8sMAAAh5XMA8VAAAMAAAB5Xg");
	var mask_2_graphics_153 = new cjs.Graphics().p("EgfRA8sMAAAh5XMA+jAAAMAAAB5Xg");
	var mask_2_graphics_154 = new cjs.Graphics().p("EggZA8sMAAAh5XMBAzAAAMAAAB5Xg");
	var mask_2_graphics_155 = new cjs.Graphics().p("EghhA8sMAAAh5XMBDDAAAMAAAB5Xg");
	var mask_2_graphics_156 = new cjs.Graphics().p("EgipA8sMAAAh5XMBFTAAAMAAAB5Xg");
	var mask_2_graphics_157 = new cjs.Graphics().p("EgjxA8sMAAAh5XMBHjAAAMAAAB5Xg");
	var mask_2_graphics_158 = new cjs.Graphics().p("Egk5A8sMAAAh5XMBJyAAAMAAAB5Xg");
	var mask_2_graphics_159 = new cjs.Graphics().p("EgmAA8sMAAAh5XMBMBAAAMAAAB5Xg");
	var mask_2_graphics_160 = new cjs.Graphics().p("EgnIA8sMAAAh5XMBORAAAMAAAB5Xg");
	var mask_2_graphics_161 = new cjs.Graphics().p("EgoQA8sMAAAh5XMBQhAAAMAAAB5Xg");
	var mask_2_graphics_162 = new cjs.Graphics().p("EgpYA8sMAAAh5XMBSxAAAMAAAB5Xg");
	var mask_2_graphics_163 = new cjs.Graphics().p("EgqgA8sMAAAh5XMBVBAAAMAAAB5Xg");
	var mask_2_graphics_164 = new cjs.Graphics().p("EgrnA8sMAAAh5XMBXPAAAMAAAB5Xg");
	var mask_2_graphics_165 = new cjs.Graphics().p("EgsvA8sMAAAh5XMBZfAAAMAAAB5Xg");
	var mask_2_graphics_166 = new cjs.Graphics().p("Egt3A8sMAAAh5XMBbvAAAMAAAB5Xg");
	var mask_2_graphics_167 = new cjs.Graphics().p("Egu/A8sMAAAh5XMBd/AAAMAAAB5Xg");
	var mask_2_graphics_168 = new cjs.Graphics().p("EgwHA8sMAAAh5XMBgPAAAMAAAB5Xg");
	var mask_2_graphics_169 = new cjs.Graphics().p("EgxPA8sMAAAh5XMBifAAAMAAAB5Xg");
	var mask_2_graphics_170 = new cjs.Graphics().p("EgyWA8sMAAAh5XMBktAAAMAAAB5Xg");
	var mask_2_graphics_171 = new cjs.Graphics().p("EgzeA8sMAAAh5XMBm9AAAMAAAB5Xg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(132).to({graphics:mask_2_graphics_132,x:-115.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_133,x:-174.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_134,x:-167.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_135,x:-160.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_136,x:-152.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_137,x:-145.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_138,x:-138.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_139,x:-131.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_140,x:-124.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_141,x:-117,y:3.2}).wait(1).to({graphics:mask_2_graphics_142,x:-109.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_143,x:-102.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_144,x:-95.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_145,x:-88.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_146,x:-81.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_147,x:-73.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_148,x:-66.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_149,x:-59.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_150,x:-52.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_151,x:-45.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_152,x:-38,y:3.2}).wait(1).to({graphics:mask_2_graphics_153,x:-30.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_154,x:-23.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_155,x:-16.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_156,x:-9.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_157,x:-2.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_158,x:5,y:3.2}).wait(1).to({graphics:mask_2_graphics_159,x:12.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_160,x:19.4,y:3.2}).wait(1).to({graphics:mask_2_graphics_161,x:26.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_162,x:33.7,y:3.2}).wait(1).to({graphics:mask_2_graphics_163,x:40.9,y:3.2}).wait(1).to({graphics:mask_2_graphics_164,x:48.1,y:3.2}).wait(1).to({graphics:mask_2_graphics_165,x:55.3,y:3.2}).wait(1).to({graphics:mask_2_graphics_166,x:62.5,y:3.2}).wait(1).to({graphics:mask_2_graphics_167,x:69.6,y:3.2}).wait(1).to({graphics:mask_2_graphics_168,x:76.8,y:3.2}).wait(1).to({graphics:mask_2_graphics_169,x:84,y:3.2}).wait(1).to({graphics:mask_2_graphics_170,x:91.2,y:3.2}).wait(1).to({graphics:mask_2_graphics_171,x:98.4,y:3.2}).wait(153));

	// GRAFICA 3
	this.instance_2 = new lib.Mapadebits2();
	this.instance_2.setTransform(-103.7,-373.4);

	this.instance_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},132).wait(192));

	// Capa 10 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_89 = new cjs.Graphics().p("AkJnCIAAsAIITAAIAAMAg");
	var mask_3_graphics_90 = new cjs.Graphics().p("AkoGAIAAr/IJRAAIAAL/g");
	var mask_3_graphics_91 = new cjs.Graphics().p("AlHGAIAAr/IKPAAIAAL/g");
	var mask_3_graphics_92 = new cjs.Graphics().p("AlmGAIAAr/ILNAAIAAL/g");
	var mask_3_graphics_93 = new cjs.Graphics().p("AmFGAIAAr/IMLAAIAAL/g");
	var mask_3_graphics_94 = new cjs.Graphics().p("AmkGAIAAr/INJAAIAAL/g");
	var mask_3_graphics_95 = new cjs.Graphics().p("AnDGAIAAr/IOHAAIAAL/g");
	var mask_3_graphics_96 = new cjs.Graphics().p("AnhGAIAAr/IPDAAIAAL/g");
	var mask_3_graphics_97 = new cjs.Graphics().p("AoAGAIAAr/IQBAAIAAL/g");
	var mask_3_graphics_98 = new cjs.Graphics().p("AofGAIAAr/IQ/AAIAAL/g");
	var mask_3_graphics_99 = new cjs.Graphics().p("Ao+GAIAAr/IR9AAIAAL/g");
	var mask_3_graphics_100 = new cjs.Graphics().p("ApdGAIAAr/IS7AAIAAL/g");
	var mask_3_graphics_101 = new cjs.Graphics().p("Ap8GAIAAr/IT5AAIAAL/g");
	var mask_3_graphics_102 = new cjs.Graphics().p("AqbGAIAAr/IU3AAIAAL/g");
	var mask_3_graphics_103 = new cjs.Graphics().p("Aq6GAIAAr/IV1AAIAAL/g");
	var mask_3_graphics_104 = new cjs.Graphics().p("ArZGAIAAr/IWzAAIAAL/g");
	var mask_3_graphics_105 = new cjs.Graphics().p("Ar4GAIAAr/IXxAAIAAL/g");
	var mask_3_graphics_106 = new cjs.Graphics().p("AsXnCIAAsAIYvAAIAAMAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(89).to({graphics:mask_3_graphics_89,x:12.1,y:-121.9}).wait(1).to({graphics:mask_3_graphics_90,x:15.2,y:-205.5}).wait(1).to({graphics:mask_3_graphics_91,x:18.3,y:-205.5}).wait(1).to({graphics:mask_3_graphics_92,x:21.4,y:-205.5}).wait(1).to({graphics:mask_3_graphics_93,x:24.5,y:-205.5}).wait(1).to({graphics:mask_3_graphics_94,x:27.6,y:-205.5}).wait(1).to({graphics:mask_3_graphics_95,x:30.7,y:-205.5}).wait(1).to({graphics:mask_3_graphics_96,x:33.7,y:-205.5}).wait(1).to({graphics:mask_3_graphics_97,x:36.8,y:-205.5}).wait(1).to({graphics:mask_3_graphics_98,x:39.9,y:-205.5}).wait(1).to({graphics:mask_3_graphics_99,x:43,y:-205.5}).wait(1).to({graphics:mask_3_graphics_100,x:46.1,y:-205.5}).wait(1).to({graphics:mask_3_graphics_101,x:49.2,y:-205.5}).wait(1).to({graphics:mask_3_graphics_102,x:52.3,y:-205.5}).wait(1).to({graphics:mask_3_graphics_103,x:55.4,y:-205.5}).wait(1).to({graphics:mask_3_graphics_104,x:58.5,y:-205.5}).wait(1).to({graphics:mask_3_graphics_105,x:61.6,y:-205.5}).wait(1).to({graphics:mask_3_graphics_106,x:64.7,y:-121.9}).wait(218));

	// flecha dcha
	this.text_1 = new cjs.Text("p<0", "italic bold 36px Verdana", "#FF0000");
	this.text_1.lineHeight = 36;
	this.text_1.lineWidth = 128;
	this.text_1.setTransform(52.4,-243.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AiohkIBMAfQArAQArAOQBvAhBAAGQhGAJhpAgQgsANg2AVQgtAQgTAKg");
	this.shape_3.setTransform(110.5,-187.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(4,0,0,4).p("AkLAAIIXAA");
	this.shape_4.setTransform(73.5,-187.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AgpgYQAXAKASAFQAWAIAUABQgOABgcAJQgVAGgUAJg");
	this.shape_5.setTransform(102.9,-187.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AiohkIBMAfQArAQArAOQBvAhBAAGQhGAJhpAgQgsANg2AVQgtAQgTAKg");
	this.shape_6.setTransform(110.5,-187.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF0000").ss(4,0,0,4).p("AkLAAIIXAA");
	this.shape_7.setTransform(73.5,-187.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AgpgYQAXAKASAFQAWAIAUABQgOABgcAJQgVAGgUAJg");
	this.shape_8.setTransform(102.9,-187.1);

	this.text_1.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.text_1}]},89).wait(235));

	// GRAFICA 2
	this.instance_3 = new lib.Path_20();
	this.instance_3.setTransform(40.3,-85.5,1,1,0,0,0,258.9,286);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3}]}).wait(324));

	// EJE ORI
	this.text_2 = new cjs.Text("X", "30px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 34;
	this.text_2.lineWidth = 33;
	this.text_2.setTransform(491.8,154.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_9.setTransform(471.2,200.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_10.setTransform(-0.9,200.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.text_2}]}).wait(324));

	// EJE VERTI
	this.text_3 = new cjs.Text("Y", "30px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 34;
	this.text_3.lineWidth = 33;
	this.text_3.setTransform(49.8,-429.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_11.setTransform(39.2,-366.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_12.setTransform(39.2,1.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.text_3}]}).wait(324));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-429.5,986.6,800.8);

(lib.IMG_06_bk = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 15 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_218 = new cjs.Graphics().p("EgIQAxPMAAAhidIQgAAMAAABidg");
	var mask_graphics_219 = new cjs.Graphics().p("EgKNAxPMAAAhidIUbAAMAAABidg");
	var mask_graphics_220 = new cjs.Graphics().p("EgMLAxPMAAAhidIYXAAMAAABidg");
	var mask_graphics_221 = new cjs.Graphics().p("EgOIAxPMAAAhidIcRAAMAAABidg");
	var mask_graphics_222 = new cjs.Graphics().p("EgQGAxPMAAAhidMAgNAAAMAAABidg");
	var mask_graphics_223 = new cjs.Graphics().p("EgSDAxPMAAAhidMAkHAAAMAAABidg");
	var mask_graphics_224 = new cjs.Graphics().p("EgUBAxPMAAAhidMAoDAAAMAAABidg");
	var mask_graphics_225 = new cjs.Graphics().p("EgV+AxPMAAAhidMAr9AAAMAAABidg");
	var mask_graphics_226 = new cjs.Graphics().p("EgX8AxPMAAAhidMAv5AAAMAAABidg");
	var mask_graphics_227 = new cjs.Graphics().p("EgZ5AxPMAAAhidMAzzAAAMAAABidg");
	var mask_graphics_228 = new cjs.Graphics().p("Egb3AxPMAAAhidMA3vAAAMAAABidg");
	var mask_graphics_229 = new cjs.Graphics().p("Egd0AxPMAAAhidMA7pAAAMAAABidg");
	var mask_graphics_230 = new cjs.Graphics().p("EgfyAxPMAAAhidMA/lAAAMAAABidg");
	var mask_graphics_231 = new cjs.Graphics().p("EghvAxPMAAAhidMBDfAAAMAAABidg");
	var mask_graphics_232 = new cjs.Graphics().p("EgjtAxPMAAAhidMBHbAAAMAAABidg");
	var mask_graphics_233 = new cjs.Graphics().p("EglqAxPMAAAhidMBLVAAAMAAABidg");
	var mask_graphics_234 = new cjs.Graphics().p("EgnoAxPMAAAhidMBPRAAAMAAABidg");
	var mask_graphics_235 = new cjs.Graphics().p("EgplAxPMAAAhidMBTLAAAMAAABidg");
	var mask_graphics_236 = new cjs.Graphics().p("EgrjAxPMAAAhidMBXHAAAMAAABidg");
	var mask_graphics_237 = new cjs.Graphics().p("EgtgAxPMAAAhidMBbBAAAMAAABidg");
	var mask_graphics_238 = new cjs.Graphics().p("EgveAxPMAAAhidMBe9AAAMAAABidg");
	var mask_graphics_239 = new cjs.Graphics().p("EgxbAxPMAAAhidMBi3AAAMAAABidg");
	var mask_graphics_240 = new cjs.Graphics().p("EgzZAxPMAAAhidMBmzAAAMAAABidg");
	var mask_graphics_241 = new cjs.Graphics().p("Eg1WAxPMAAAhidMBqtAAAMAAABidg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(218).to({graphics:mask_graphics_218,x:-412.8,y:-1.9}).wait(1).to({graphics:mask_graphics_219,x:-400.2,y:-1.9}).wait(1).to({graphics:mask_graphics_220,x:-387.7,y:-1.9}).wait(1).to({graphics:mask_graphics_221,x:-375.1,y:-1.9}).wait(1).to({graphics:mask_graphics_222,x:-362.6,y:-1.9}).wait(1).to({graphics:mask_graphics_223,x:-350,y:-1.9}).wait(1).to({graphics:mask_graphics_224,x:-337.5,y:-1.9}).wait(1).to({graphics:mask_graphics_225,x:-324.9,y:-1.9}).wait(1).to({graphics:mask_graphics_226,x:-312.4,y:-1.9}).wait(1).to({graphics:mask_graphics_227,x:-299.8,y:-1.9}).wait(1).to({graphics:mask_graphics_228,x:-287.3,y:-1.9}).wait(1).to({graphics:mask_graphics_229,x:-274.7,y:-1.9}).wait(1).to({graphics:mask_graphics_230,x:-262.2,y:-1.9}).wait(1).to({graphics:mask_graphics_231,x:-249.6,y:-1.9}).wait(1).to({graphics:mask_graphics_232,x:-237.1,y:-1.9}).wait(1).to({graphics:mask_graphics_233,x:-224.5,y:-1.9}).wait(1).to({graphics:mask_graphics_234,x:-212,y:-1.9}).wait(1).to({graphics:mask_graphics_235,x:-199.4,y:-1.9}).wait(1).to({graphics:mask_graphics_236,x:-186.9,y:-1.9}).wait(1).to({graphics:mask_graphics_237,x:-174.3,y:-1.9}).wait(1).to({graphics:mask_graphics_238,x:-161.8,y:-1.9}).wait(1).to({graphics:mask_graphics_239,x:-149.2,y:-1.9}).wait(1).to({graphics:mask_graphics_240,x:-136.7,y:-1.9}).wait(1).to({graphics:mask_graphics_241,x:-124.1,y:-1.9}).wait(5));

	// GRAFICA 1
	this.instance = new lib.Path_25();
	this.instance.setTransform(-73.6,4.1,1,1,0,0,0,258.9,286);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(218).to({_off:false},0).wait(28));

	// Capa 14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_168 = new cjs.Graphics().p("At7C7IAAl1Ib3AAIAAF1g");
	var mask_1_graphics_169 = new cjs.Graphics().p("At7FYIAAqvIb3AAIAAKvg");
	var mask_1_graphics_170 = new cjs.Graphics().p("At7H1IAAvpIb3AAIAAPpg");
	var mask_1_graphics_171 = new cjs.Graphics().p("At7KRIAA0hIb3AAIAAUhg");
	var mask_1_graphics_172 = new cjs.Graphics().p("At7MuIAA5bIb3AAIAAZbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("At7PLIAA+VIb3AAIAAeVg");
	var mask_1_graphics_174 = new cjs.Graphics().p("At7RoMAAAgjPIb3AAMAAAAjPg");
	var mask_1_graphics_175 = new cjs.Graphics().p("At7UFMAAAgoJIb3AAMAAAAoJg");
	var mask_1_graphics_176 = new cjs.Graphics().p("At7WhMAAAgtBIb3AAMAAAAtBg");
	var mask_1_graphics_177 = new cjs.Graphics().p("At7Y+MAAAgx7Ib3AAMAAAAx7g");
	var mask_1_graphics_178 = new cjs.Graphics().p("At7bbMAAAg21Ib3AAMAAAA21g");
	var mask_1_graphics_179 = new cjs.Graphics().p("At7d4MAAAg7vIb3AAMAAAA7vg");
	var mask_1_graphics_180 = new cjs.Graphics().p("EgN7AgVMAAAhApIb3AAMAAABApg");
	var mask_1_graphics_181 = new cjs.Graphics().p("EgN7AixMAAAhFhIb3AAMAAABFhg");
	var mask_1_graphics_182 = new cjs.Graphics().p("EgN7AlOMAAAhKbIb3AAMAAABKbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("EgN7AnrMAAAhPVIb3AAMAAABPVg");
	var mask_1_graphics_184 = new cjs.Graphics().p("EgN7AqIMAAAhUPIb3AAMAAABUPg");
	var mask_1_graphics_185 = new cjs.Graphics().p("EgN7AslMAAAhZJIb3AAMAAABZJg");
	var mask_1_graphics_186 = new cjs.Graphics().p("EgN7AvBMAAAheBIb3AAMAAABeBg");
	var mask_1_graphics_187 = new cjs.Graphics().p("EgN7AxeMAAAhi7Ib3AAMAAABi7g");
	var mask_1_graphics_188 = new cjs.Graphics().p("EgN7Az7MAAAhn1Ib3AAMAAABn1g");
	var mask_1_graphics_189 = new cjs.Graphics().p("EgN7A2YMAAAhsvIb3AAMAAABsvg");
	var mask_1_graphics_190 = new cjs.Graphics().p("EgN7A41MAAAhxpIb3AAMAAABxpg");
	var mask_1_graphics_191 = new cjs.Graphics().p("EgN7A7RMAAAh2hIb3AAMAAAB2hg");
	var mask_1_graphics_192 = new cjs.Graphics().p("EgN7A9uMAAAh7bIb3AAMAAAB7bg");
	var mask_1_graphics_193 = new cjs.Graphics().p("EgN7BALMAAAiAVIb3AAMAAACAVg");
	var mask_1_graphics_194 = new cjs.Graphics().p("EgN7BCoMAAAiFPIb3AAMAAACFPg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(168).to({graphics:mask_1_graphics_168,x:-81.1,y:508.2}).wait(1).to({graphics:mask_1_graphics_169,x:-81.1,y:492.5}).wait(1).to({graphics:mask_1_graphics_170,x:-81.1,y:476.8}).wait(1).to({graphics:mask_1_graphics_171,x:-81.1,y:461.1}).wait(1).to({graphics:mask_1_graphics_172,x:-81.1,y:445.4}).wait(1).to({graphics:mask_1_graphics_173,x:-81.1,y:429.8}).wait(1).to({graphics:mask_1_graphics_174,x:-81.1,y:414.1}).wait(1).to({graphics:mask_1_graphics_175,x:-81.1,y:398.4}).wait(1).to({graphics:mask_1_graphics_176,x:-81.1,y:382.7}).wait(1).to({graphics:mask_1_graphics_177,x:-81.1,y:367}).wait(1).to({graphics:mask_1_graphics_178,x:-81.1,y:351.4}).wait(1).to({graphics:mask_1_graphics_179,x:-81.1,y:335.7}).wait(1).to({graphics:mask_1_graphics_180,x:-81.1,y:320}).wait(1).to({graphics:mask_1_graphics_181,x:-81.1,y:304.3}).wait(1).to({graphics:mask_1_graphics_182,x:-81.1,y:288.6}).wait(1).to({graphics:mask_1_graphics_183,x:-81.1,y:273}).wait(1).to({graphics:mask_1_graphics_184,x:-81.1,y:257.3}).wait(1).to({graphics:mask_1_graphics_185,x:-81.1,y:241.6}).wait(1).to({graphics:mask_1_graphics_186,x:-81.1,y:225.9}).wait(1).to({graphics:mask_1_graphics_187,x:-81.1,y:210.2}).wait(1).to({graphics:mask_1_graphics_188,x:-81.1,y:194.6}).wait(1).to({graphics:mask_1_graphics_189,x:-81.1,y:178.9}).wait(1).to({graphics:mask_1_graphics_190,x:-81.1,y:163.2}).wait(1).to({graphics:mask_1_graphics_191,x:-81.1,y:147.5}).wait(1).to({graphics:mask_1_graphics_192,x:-81.1,y:131.8}).wait(1).to({graphics:mask_1_graphics_193,x:-81.1,y:116.2}).wait(1).to({graphics:mask_1_graphics_194,x:-81.1,y:100.5}).wait(52));

	// coordenadas
	this.instance_1 = new lib.Path_26();
	this.instance_1.setTransform(-75.2,90.8,1,1,0,0,0,2,368.3);
	this.instance_1._off = true;

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(168).to({_off:false},0).wait(78));

	// Capa 13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_117 = new cjs.Graphics().p("AhaCJIAAtDIJ9AAIAANDg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AlbGiIAAtDIK3AAIAANDg");
	var mask_2_graphics_119 = new cjs.Graphics().p("Al3GiIAAtDILvAAIAANDg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AmUGiIAAtDIMpAAIAANDg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AmxGiIAAtDINjAAIAANDg");
	var mask_2_graphics_122 = new cjs.Graphics().p("AnOGiIAAtDIOdAAIAANDg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AnqGiIAAtDIPVAAIAANDg");
	var mask_2_graphics_124 = new cjs.Graphics().p("AoHGiIAAtDIQPAAIAANDg");
	var mask_2_graphics_125 = new cjs.Graphics().p("AokGiIAAtDIRJAAIAANDg");
	var mask_2_graphics_126 = new cjs.Graphics().p("ApBGiIAAtDISDAAIAANDg");
	var mask_2_graphics_127 = new cjs.Graphics().p("ApdGiIAAtDIS7AAIAANDg");
	var mask_2_graphics_128 = new cjs.Graphics().p("Ap6GiIAAtDIT1AAIAANDg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AqXGiIAAtDIUvAAIAANDg");
	var mask_2_graphics_130 = new cjs.Graphics().p("Aq0GiIAAtDIVpAAIAANDg");
	var mask_2_graphics_131 = new cjs.Graphics().p("ArQGiIAAtDIWhAAIAANDg");
	var mask_2_graphics_132 = new cjs.Graphics().p("ArtGiIAAtDIXbAAIAANDg");
	var mask_2_graphics_133 = new cjs.Graphics().p("AsKGiIAAtDIYVAAIAANDg");
	var mask_2_graphics_134 = new cjs.Graphics().p("AsnGiIAAtDIZPAAIAANDg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AtDGiIAAtDIaHAAIAANDg");
	var mask_2_graphics_136 = new cjs.Graphics().p("AtgGiIAAtDIbBAAIAANDg");
	var mask_2_graphics_137 = new cjs.Graphics().p("At9GiIAAtDIb7AAIAANDg");
	var mask_2_graphics_138 = new cjs.Graphics().p("AuaGiIAAtDIc1AAIAANDg");
	var mask_2_graphics_139 = new cjs.Graphics().p("Au2GiIAAtDIdtAAIAANDg");
	var mask_2_graphics_140 = new cjs.Graphics().p("AvTCJIAAtDIenAAIAANDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(117).to({graphics:mask_2_graphics_117,x:54.7,y:-69.9}).wait(1).to({graphics:mask_2_graphics_118,x:74.6,y:-98}).wait(1).to({graphics:mask_2_graphics_119,x:71.7,y:-98}).wait(1).to({graphics:mask_2_graphics_120,x:68.8,y:-98}).wait(1).to({graphics:mask_2_graphics_121,x:65.9,y:-98}).wait(1).to({graphics:mask_2_graphics_122,x:63.1,y:-98}).wait(1).to({graphics:mask_2_graphics_123,x:60.2,y:-98}).wait(1).to({graphics:mask_2_graphics_124,x:57.3,y:-98}).wait(1).to({graphics:mask_2_graphics_125,x:54.4,y:-98}).wait(1).to({graphics:mask_2_graphics_126,x:51.6,y:-98}).wait(1).to({graphics:mask_2_graphics_127,x:48.7,y:-98}).wait(1).to({graphics:mask_2_graphics_128,x:45.8,y:-98}).wait(1).to({graphics:mask_2_graphics_129,x:42.9,y:-98}).wait(1).to({graphics:mask_2_graphics_130,x:40.1,y:-98}).wait(1).to({graphics:mask_2_graphics_131,x:37.2,y:-98}).wait(1).to({graphics:mask_2_graphics_132,x:34.3,y:-98}).wait(1).to({graphics:mask_2_graphics_133,x:31.4,y:-98}).wait(1).to({graphics:mask_2_graphics_134,x:28.6,y:-98}).wait(1).to({graphics:mask_2_graphics_135,x:25.7,y:-98}).wait(1).to({graphics:mask_2_graphics_136,x:22.8,y:-98}).wait(1).to({graphics:mask_2_graphics_137,x:19.9,y:-98}).wait(1).to({graphics:mask_2_graphics_138,x:17.1,y:-98}).wait(1).to({graphics:mask_2_graphics_139,x:14.2,y:-98}).wait(1).to({graphics:mask_2_graphics_140,x:11.3,y:-69.9}).wait(106));

	// flecha
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhngghIgJQBBgGBughQAsgOA3gUQAsgRATgJIAADHIhMgeg");
	this.shape.setTransform(-47.7,-96.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AFHAAIqOAA");
	this.shape_1.setTransform(-4.7,-96.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AABAKQgWgIgUgCQASAAAYgJQAegJALgGIAAAxQgXgKgSgFg");
	this.shape_2.setTransform(-40,-96.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},117).wait(129));

	// Capa 12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_69 = new cjs.Graphics().p("EgKqAyyMAAAhljIVUAAMAAABljg");
	var mask_3_graphics_70 = new cjs.Graphics().p("EgMgAyyMAAAhljIZBAAMAAABljg");
	var mask_3_graphics_71 = new cjs.Graphics().p("EgOXAyyMAAAhljIcvAAMAAABljg");
	var mask_3_graphics_72 = new cjs.Graphics().p("EgQOAyyMAAAhljMAgdAAAMAAABljg");
	var mask_3_graphics_73 = new cjs.Graphics().p("EgSFAyyMAAAhljMAkLAAAMAAABljg");
	var mask_3_graphics_74 = new cjs.Graphics().p("EgT8AyyMAAAhljMAn5AAAMAAABljg");
	var mask_3_graphics_75 = new cjs.Graphics().p("EgVzAyyMAAAhljMArnAAAMAAABljg");
	var mask_3_graphics_76 = new cjs.Graphics().p("EgXqAyyMAAAhljMAvVAAAMAAABljg");
	var mask_3_graphics_77 = new cjs.Graphics().p("EgZhAyyMAAAhljMAzDAAAMAAABljg");
	var mask_3_graphics_78 = new cjs.Graphics().p("EgbYAyyMAAAhljMA2xAAAMAAABljg");
	var mask_3_graphics_79 = new cjs.Graphics().p("EgdPAyyMAAAhljMA6fAAAMAAABljg");
	var mask_3_graphics_80 = new cjs.Graphics().p("EgfGAyyMAAAhljMA+NAAAMAAABljg");
	var mask_3_graphics_81 = new cjs.Graphics().p("Egg9AyyMAAAhljMBB7AAAMAAABljg");
	var mask_3_graphics_82 = new cjs.Graphics().p("Egi0AyyMAAAhljMBFpAAAMAAABljg");
	var mask_3_graphics_83 = new cjs.Graphics().p("EgkrAyyMAAAhljMBJXAAAMAAABljg");
	var mask_3_graphics_84 = new cjs.Graphics().p("EgmiAyyMAAAhljMBNFAAAMAAABljg");
	var mask_3_graphics_85 = new cjs.Graphics().p("EgoZAyyMAAAhljMBQzAAAMAAABljg");
	var mask_3_graphics_86 = new cjs.Graphics().p("EgqQAyyMAAAhljMBUhAAAMAAABljg");
	var mask_3_graphics_87 = new cjs.Graphics().p("EgsHAyyMAAAhljMBYPAAAMAAABljg");
	var mask_3_graphics_88 = new cjs.Graphics().p("Egt+AyyMAAAhljMBb9AAAMAAABljg");
	var mask_3_graphics_89 = new cjs.Graphics().p("Egv1AyyMAAAhljMBfrAAAMAAABljg");
	var mask_3_graphics_90 = new cjs.Graphics().p("EgxsAyyMAAAhljMBjZAAAMAAABljg");
	var mask_3_graphics_91 = new cjs.Graphics().p("EgzjAyyMAAAhljMBnHAAAMAAABljg");
	var mask_3_graphics_92 = new cjs.Graphics().p("Eg1aAyyMAAAhljMBq1AAAMAAABljg");
	var mask_3_graphics_93 = new cjs.Graphics().p("Eg3RAyyMAAAhljMBujAAAMAAABljg");
	var mask_3_graphics_94 = new cjs.Graphics().p("Eg5IAyyMAAAhljMByRAAAMAAABljg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(69).to({graphics:mask_3_graphics_69,x:-322.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_70,x:-310.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_71,x:-298.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_72,x:-286.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_73,x:-274.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_74,x:-263,y:7.9}).wait(1).to({graphics:mask_3_graphics_75,x:-251.1,y:7.9}).wait(1).to({graphics:mask_3_graphics_76,x:-239.2,y:7.9}).wait(1).to({graphics:mask_3_graphics_77,x:-227.3,y:7.9}).wait(1).to({graphics:mask_3_graphics_78,x:-215.4,y:7.9}).wait(1).to({graphics:mask_3_graphics_79,x:-203.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_80,x:-191.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_81,x:-179.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_82,x:-167.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_83,x:-155.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_84,x:-144,y:7.9}).wait(1).to({graphics:mask_3_graphics_85,x:-132.1,y:7.9}).wait(1).to({graphics:mask_3_graphics_86,x:-120.2,y:7.9}).wait(1).to({graphics:mask_3_graphics_87,x:-108.3,y:7.9}).wait(1).to({graphics:mask_3_graphics_88,x:-96.4,y:7.9}).wait(1).to({graphics:mask_3_graphics_89,x:-84.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_90,x:-72.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_91,x:-60.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_92,x:-48.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_93,x:-36.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_94,x:-25,y:7.9}).wait(152));

	// GRAFICA 2
	this.instance_2 = new lib.Path_24();
	this.instance_2.setTransform(40.3,4.4,1,1,0,0,0,258.9,286);
	this.instance_2._off = true;

	this.instance_2.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).wait(177));

	// Capa 11 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("EgtfBACMAAAiADIJ/AAMAAACADg");
	var mask_4_graphics_1 = new cjs.Graphics().p("EgIJBAEMAAAiAHIQTAAMAAACAHg");
	var mask_4_graphics_2 = new cjs.Graphics().p("EgLUBAGMAAAiALIWpAAMAAACALg");
	var mask_4_graphics_3 = new cjs.Graphics().p("EgOgBAHMAAAiANIdBAAMAAACANg");
	var mask_4_graphics_4 = new cjs.Graphics().p("EgRrBAJMAAAiARMAjXAAAMAAACARg");
	var mask_4_graphics_5 = new cjs.Graphics().p("EgU2BALMAAAiAVMAptAAAMAAACAVg");
	var mask_4_graphics_6 = new cjs.Graphics().p("EgYBBANMAAAiAZMAwDAAAMAAACAZg");
	var mask_4_graphics_7 = new cjs.Graphics().p("EgbMBAOMAAAiAbMA2ZAAAMAAACAbg");
	var mask_4_graphics_8 = new cjs.Graphics().p("EgeXBAQMAAAiAfMA8vAAAMAAACAfg");
	var mask_4_graphics_9 = new cjs.Graphics().p("EghjBASMAAAiAjMBDHAAAMAAACAjg");
	var mask_4_graphics_10 = new cjs.Graphics().p("EgkuBAUMAAAiAnMBJdAAAMAAACAng");
	var mask_4_graphics_11 = new cjs.Graphics().p("Egn5BAVMAAAiApMBPzAAAMAAACApg");
	var mask_4_graphics_12 = new cjs.Graphics().p("EgrEBAXMAAAiAtMBWJAAAMAAACAtg");
	var mask_4_graphics_13 = new cjs.Graphics().p("EguPBAZMAAAiAxMBcfAAAMAAACAxg");
	var mask_4_graphics_14 = new cjs.Graphics().p("EgxaBAbMAAAiA1MBi1AAAMAAACA1g");
	var mask_4_graphics_15 = new cjs.Graphics().p("Eg0mBAdMAAAiA5MBpNAAAMAAACA5g");
	var mask_4_graphics_16 = new cjs.Graphics().p("Eg3xBAeMAAAiA7MBvjAAAMAAACA7g");
	var mask_4_graphics_17 = new cjs.Graphics().p("Eg68BAgMAAAiA/MB15AAAMAAACA/g");
	var mask_4_graphics_18 = new cjs.Graphics().p("Eg+HBAiMAAAiBDMB8PAAAMAAACBDg");
	var mask_4_graphics_19 = new cjs.Graphics().p("EhBSBAkMAAAiBHMCClAAAMAAACBHg");
	var mask_4_graphics_20 = new cjs.Graphics().p("EhEdBAlMAAAiBJMCI7AAAMAAACBJg");
	var mask_4_graphics_21 = new cjs.Graphics().p("EhHpBAnMAAAiBNMCPTAAAMAAACBNg");
	var mask_4_graphics_22 = new cjs.Graphics().p("EhK0BApMAAAiBRMCVpAAAMAAACBRg");
	var mask_4_graphics_23 = new cjs.Graphics().p("EhN/BArMAAAiBVMCb/AAAMAAACBVg");
	var mask_4_graphics_24 = new cjs.Graphics().p("EhRKBAsMAAAiBXMCiVAAAMAAACBXg");
	var mask_4_graphics_25 = new cjs.Graphics().p("EhUVBAuMAAAiBbMCorAAAMAAACBbg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:-291.2,y:79.5}).wait(1).to({graphics:mask_4_graphics_1,x:-530.2,y:79.4}).wait(1).to({graphics:mask_4_graphics_2,x:-509.9,y:79.2}).wait(1).to({graphics:mask_4_graphics_3,x:-489.6,y:79}).wait(1).to({graphics:mask_4_graphics_4,x:-469.3,y:78.8}).wait(1).to({graphics:mask_4_graphics_5,x:-449,y:78.7}).wait(1).to({graphics:mask_4_graphics_6,x:-428.6,y:78.5}).wait(1).to({graphics:mask_4_graphics_7,x:-408.3,y:78.3}).wait(1).to({graphics:mask_4_graphics_8,x:-388,y:78.1}).wait(1).to({graphics:mask_4_graphics_9,x:-367.7,y:78}).wait(1).to({graphics:mask_4_graphics_10,x:-347.4,y:77.8}).wait(1).to({graphics:mask_4_graphics_11,x:-327,y:77.6}).wait(1).to({graphics:mask_4_graphics_12,x:-306.7,y:77.4}).wait(1).to({graphics:mask_4_graphics_13,x:-286.4,y:77.2}).wait(1).to({graphics:mask_4_graphics_14,x:-266.1,y:77.1}).wait(1).to({graphics:mask_4_graphics_15,x:-245.8,y:76.9}).wait(1).to({graphics:mask_4_graphics_16,x:-225.4,y:76.7}).wait(1).to({graphics:mask_4_graphics_17,x:-205.1,y:76.5}).wait(1).to({graphics:mask_4_graphics_18,x:-184.8,y:76.4}).wait(1).to({graphics:mask_4_graphics_19,x:-164.5,y:76.2}).wait(1).to({graphics:mask_4_graphics_20,x:-144.2,y:76}).wait(1).to({graphics:mask_4_graphics_21,x:-123.9,y:75.8}).wait(1).to({graphics:mask_4_graphics_22,x:-103.5,y:75.7}).wait(1).to({graphics:mask_4_graphics_23,x:-83.2,y:75.5}).wait(1).to({graphics:mask_4_graphics_24,x:-62.9,y:75.3}).wait(1).to({graphics:mask_4_graphics_25,x:-42.6,y:75.1}).wait(221));

	// EJE ORI
	this.text = new cjs.Text("X", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 34;
	this.text.lineWidth = 33;
	this.text.setTransform(471.4,236.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(387.4,296.3);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(378,306.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(-419.7,298.1);

	this.text_2 = new cjs.Text("–4", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-444.5,308.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(-301.9,297);

	this.text_3 = new cjs.Text("–3", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-322.5,307.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-190.8,295.7);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-211.4,306.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(-74.4,299.1);

	this.text_5 = new cjs.Text("–1", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-95,309.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(271.7,296.6);

	this.text_6 = new cjs.Text("2", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(262.3,306.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(156.1,297.5);

	this.text_7 = new cjs.Text("1", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(146.7,307.6);

	this.text_8 = new cjs.Text("0", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(45.8,298.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_10.setTransform(471.2,290.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_11.setTransform(-0.9,290.8);

	this.text.mask = this.shape_3.mask = this.text_1.mask = this.shape_4.mask = this.text_2.mask = this.shape_5.mask = this.text_3.mask = this.shape_6.mask = this.text_4.mask = this.shape_7.mask = this.text_5.mask = this.shape_8.mask = this.text_6.mask = this.shape_9.mask = this.text_7.mask = this.text_8.mask = this.shape_10.mask = this.shape_11.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.text_8},{t:this.text_7},{t:this.shape_9},{t:this.text_6},{t:this.shape_8},{t:this.text_5},{t:this.shape_7},{t:this.text_4},{t:this.shape_6},{t:this.text_3},{t:this.shape_5},{t:this.text_2},{t:this.shape_4},{t:this.text_1},{t:this.shape_3},{t:this.text}]}).wait(246));

	// EJE VERTI
	this.text_9 = new cjs.Text("Y", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 34;
	this.text_9.lineWidth = 33;
	this.text_9.setTransform(49.4,-332);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_12.setTransform(34.4,407.3);

	this.text_10 = new cjs.Text("–1", "29px Verdana");
	this.text_10.lineHeight = 35;
	this.text_10.setTransform(-2.8,393.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_13.setTransform(33.4,-53.5);

	this.text_11 = new cjs.Text("3", "29px Verdana");
	this.text_11.lineHeight = 35;
	this.text_11.setTransform(8,-67.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_14.setTransform(33.4,-168.2);

	this.text_12 = new cjs.Text("4", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(6.8,-182.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(33.4,62.2);

	this.text_13 = new cjs.Text("2", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(9.1,48.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(33.4,181.1);

	this.text_14 = new cjs.Text("1", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(10.3,167);

	this.text_15 = new cjs.Text("0", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(13.5,261.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_17.setTransform(39.2,-276.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_18.setTransform(39.2,91.9);

	this.text_9.mask = this.shape_12.mask = this.text_10.mask = this.shape_13.mask = this.text_11.mask = this.shape_14.mask = this.text_12.mask = this.shape_15.mask = this.text_13.mask = this.shape_16.mask = this.text_14.mask = this.text_15.mask = this.shape_17.mask = this.shape_18.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.text_15},{t:this.text_14},{t:this.shape_16},{t:this.text_13},{t:this.shape_15},{t:this.text_12},{t:this.shape_14},{t:this.text_11},{t:this.shape_13},{t:this.text_10},{t:this.shape_12},{t:this.text_9}]}).wait(246));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-332,966.2,793.3);

(lib.IMG_06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 15 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_218 = new cjs.Graphics().p("EgIQAxPMAAAhidIQgAAMAAABidg");
	var mask_graphics_219 = new cjs.Graphics().p("EgKNAxPMAAAhidIUbAAMAAABidg");
	var mask_graphics_220 = new cjs.Graphics().p("EgMLAxPMAAAhidIYXAAMAAABidg");
	var mask_graphics_221 = new cjs.Graphics().p("EgOIAxPMAAAhidIcRAAMAAABidg");
	var mask_graphics_222 = new cjs.Graphics().p("EgQGAxPMAAAhidMAgNAAAMAAABidg");
	var mask_graphics_223 = new cjs.Graphics().p("EgSDAxPMAAAhidMAkHAAAMAAABidg");
	var mask_graphics_224 = new cjs.Graphics().p("EgUBAxPMAAAhidMAoDAAAMAAABidg");
	var mask_graphics_225 = new cjs.Graphics().p("EgV+AxPMAAAhidMAr9AAAMAAABidg");
	var mask_graphics_226 = new cjs.Graphics().p("EgX8AxPMAAAhidMAv5AAAMAAABidg");
	var mask_graphics_227 = new cjs.Graphics().p("EgZ5AxPMAAAhidMAzzAAAMAAABidg");
	var mask_graphics_228 = new cjs.Graphics().p("Egb3AxPMAAAhidMA3vAAAMAAABidg");
	var mask_graphics_229 = new cjs.Graphics().p("Egd0AxPMAAAhidMA7pAAAMAAABidg");
	var mask_graphics_230 = new cjs.Graphics().p("EgfyAxPMAAAhidMA/lAAAMAAABidg");
	var mask_graphics_231 = new cjs.Graphics().p("EghvAxPMAAAhidMBDfAAAMAAABidg");
	var mask_graphics_232 = new cjs.Graphics().p("EgjtAxPMAAAhidMBHbAAAMAAABidg");
	var mask_graphics_233 = new cjs.Graphics().p("EglqAxPMAAAhidMBLVAAAMAAABidg");
	var mask_graphics_234 = new cjs.Graphics().p("EgnoAxPMAAAhidMBPRAAAMAAABidg");
	var mask_graphics_235 = new cjs.Graphics().p("EgplAxPMAAAhidMBTLAAAMAAABidg");
	var mask_graphics_236 = new cjs.Graphics().p("EgrjAxPMAAAhidMBXHAAAMAAABidg");
	var mask_graphics_237 = new cjs.Graphics().p("EgtgAxPMAAAhidMBbBAAAMAAABidg");
	var mask_graphics_238 = new cjs.Graphics().p("EgveAxPMAAAhidMBe9AAAMAAABidg");
	var mask_graphics_239 = new cjs.Graphics().p("EgxbAxPMAAAhidMBi3AAAMAAABidg");
	var mask_graphics_240 = new cjs.Graphics().p("EgzZAxPMAAAhidMBmzAAAMAAABidg");
	var mask_graphics_241 = new cjs.Graphics().p("Eg1WAxPMAAAhidMBqtAAAMAAABidg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(218).to({graphics:mask_graphics_218,x:-412.8,y:-1.9}).wait(1).to({graphics:mask_graphics_219,x:-400.2,y:-1.9}).wait(1).to({graphics:mask_graphics_220,x:-387.7,y:-1.9}).wait(1).to({graphics:mask_graphics_221,x:-375.1,y:-1.9}).wait(1).to({graphics:mask_graphics_222,x:-362.6,y:-1.9}).wait(1).to({graphics:mask_graphics_223,x:-350,y:-1.9}).wait(1).to({graphics:mask_graphics_224,x:-337.5,y:-1.9}).wait(1).to({graphics:mask_graphics_225,x:-324.9,y:-1.9}).wait(1).to({graphics:mask_graphics_226,x:-312.4,y:-1.9}).wait(1).to({graphics:mask_graphics_227,x:-299.8,y:-1.9}).wait(1).to({graphics:mask_graphics_228,x:-287.3,y:-1.9}).wait(1).to({graphics:mask_graphics_229,x:-274.7,y:-1.9}).wait(1).to({graphics:mask_graphics_230,x:-262.2,y:-1.9}).wait(1).to({graphics:mask_graphics_231,x:-249.6,y:-1.9}).wait(1).to({graphics:mask_graphics_232,x:-237.1,y:-1.9}).wait(1).to({graphics:mask_graphics_233,x:-224.5,y:-1.9}).wait(1).to({graphics:mask_graphics_234,x:-212,y:-1.9}).wait(1).to({graphics:mask_graphics_235,x:-199.4,y:-1.9}).wait(1).to({graphics:mask_graphics_236,x:-186.9,y:-1.9}).wait(1).to({graphics:mask_graphics_237,x:-174.3,y:-1.9}).wait(1).to({graphics:mask_graphics_238,x:-161.8,y:-1.9}).wait(1).to({graphics:mask_graphics_239,x:-149.2,y:-1.9}).wait(1).to({graphics:mask_graphics_240,x:-136.7,y:-1.9}).wait(1).to({graphics:mask_graphics_241,x:-124.1,y:-1.9}).wait(5));

	// GRAFICA 1
	this.instance = new lib.Path_25();
	this.instance.setTransform(-73.6,4.1,1,1,0,0,0,258.9,286);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(218).to({_off:false},0).wait(28));

	// Capa 14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_168 = new cjs.Graphics().p("At7C7IAAl1Ib3AAIAAF1g");
	var mask_1_graphics_169 = new cjs.Graphics().p("At7FYIAAqvIb3AAIAAKvg");
	var mask_1_graphics_170 = new cjs.Graphics().p("At7H1IAAvpIb3AAIAAPpg");
	var mask_1_graphics_171 = new cjs.Graphics().p("At7KRIAA0hIb3AAIAAUhg");
	var mask_1_graphics_172 = new cjs.Graphics().p("At7MuIAA5bIb3AAIAAZbg");
	var mask_1_graphics_173 = new cjs.Graphics().p("At7PLIAA+VIb3AAIAAeVg");
	var mask_1_graphics_174 = new cjs.Graphics().p("At7RoMAAAgjPIb3AAMAAAAjPg");
	var mask_1_graphics_175 = new cjs.Graphics().p("At7UFMAAAgoJIb3AAMAAAAoJg");
	var mask_1_graphics_176 = new cjs.Graphics().p("At7WhMAAAgtBIb3AAMAAAAtBg");
	var mask_1_graphics_177 = new cjs.Graphics().p("At7Y+MAAAgx7Ib3AAMAAAAx7g");
	var mask_1_graphics_178 = new cjs.Graphics().p("At7bbMAAAg21Ib3AAMAAAA21g");
	var mask_1_graphics_179 = new cjs.Graphics().p("At7d4MAAAg7vIb3AAMAAAA7vg");
	var mask_1_graphics_180 = new cjs.Graphics().p("EgN7AgVMAAAhApIb3AAMAAABApg");
	var mask_1_graphics_181 = new cjs.Graphics().p("EgN7AixMAAAhFhIb3AAMAAABFhg");
	var mask_1_graphics_182 = new cjs.Graphics().p("EgN7AlOMAAAhKbIb3AAMAAABKbg");
	var mask_1_graphics_183 = new cjs.Graphics().p("EgN7AnrMAAAhPVIb3AAMAAABPVg");
	var mask_1_graphics_184 = new cjs.Graphics().p("EgN7AqIMAAAhUPIb3AAMAAABUPg");
	var mask_1_graphics_185 = new cjs.Graphics().p("EgN7AslMAAAhZJIb3AAMAAABZJg");
	var mask_1_graphics_186 = new cjs.Graphics().p("EgN7AvBMAAAheBIb3AAMAAABeBg");
	var mask_1_graphics_187 = new cjs.Graphics().p("EgN7AxeMAAAhi7Ib3AAMAAABi7g");
	var mask_1_graphics_188 = new cjs.Graphics().p("EgN7Az7MAAAhn1Ib3AAMAAABn1g");
	var mask_1_graphics_189 = new cjs.Graphics().p("EgN7A2YMAAAhsvIb3AAMAAABsvg");
	var mask_1_graphics_190 = new cjs.Graphics().p("EgN7A41MAAAhxpIb3AAMAAABxpg");
	var mask_1_graphics_191 = new cjs.Graphics().p("EgN7A7RMAAAh2hIb3AAMAAAB2hg");
	var mask_1_graphics_192 = new cjs.Graphics().p("EgN7A9uMAAAh7bIb3AAMAAAB7bg");
	var mask_1_graphics_193 = new cjs.Graphics().p("EgN7BALMAAAiAVIb3AAMAAACAVg");
	var mask_1_graphics_194 = new cjs.Graphics().p("EgN7BCoMAAAiFPIb3AAMAAACFPg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(168).to({graphics:mask_1_graphics_168,x:-81.1,y:508.2}).wait(1).to({graphics:mask_1_graphics_169,x:-81.1,y:492.5}).wait(1).to({graphics:mask_1_graphics_170,x:-81.1,y:476.8}).wait(1).to({graphics:mask_1_graphics_171,x:-81.1,y:461.1}).wait(1).to({graphics:mask_1_graphics_172,x:-81.1,y:445.4}).wait(1).to({graphics:mask_1_graphics_173,x:-81.1,y:429.8}).wait(1).to({graphics:mask_1_graphics_174,x:-81.1,y:414.1}).wait(1).to({graphics:mask_1_graphics_175,x:-81.1,y:398.4}).wait(1).to({graphics:mask_1_graphics_176,x:-81.1,y:382.7}).wait(1).to({graphics:mask_1_graphics_177,x:-81.1,y:367}).wait(1).to({graphics:mask_1_graphics_178,x:-81.1,y:351.4}).wait(1).to({graphics:mask_1_graphics_179,x:-81.1,y:335.7}).wait(1).to({graphics:mask_1_graphics_180,x:-81.1,y:320}).wait(1).to({graphics:mask_1_graphics_181,x:-81.1,y:304.3}).wait(1).to({graphics:mask_1_graphics_182,x:-81.1,y:288.6}).wait(1).to({graphics:mask_1_graphics_183,x:-81.1,y:273}).wait(1).to({graphics:mask_1_graphics_184,x:-81.1,y:257.3}).wait(1).to({graphics:mask_1_graphics_185,x:-81.1,y:241.6}).wait(1).to({graphics:mask_1_graphics_186,x:-81.1,y:225.9}).wait(1).to({graphics:mask_1_graphics_187,x:-81.1,y:210.2}).wait(1).to({graphics:mask_1_graphics_188,x:-81.1,y:194.6}).wait(1).to({graphics:mask_1_graphics_189,x:-81.1,y:178.9}).wait(1).to({graphics:mask_1_graphics_190,x:-81.1,y:163.2}).wait(1).to({graphics:mask_1_graphics_191,x:-81.1,y:147.5}).wait(1).to({graphics:mask_1_graphics_192,x:-81.1,y:131.8}).wait(1).to({graphics:mask_1_graphics_193,x:-81.1,y:116.2}).wait(1).to({graphics:mask_1_graphics_194,x:-81.1,y:100.5}).wait(52));

	// coordenadas
	this.instance_1 = new lib.Mapadebits1();
	this.instance_1.setTransform(-77.2,-279.4);

	this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},168).wait(78));

	// Capa 13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_117 = new cjs.Graphics().p("AhaCJIAAtDIJ9AAIAANDg");
	var mask_2_graphics_118 = new cjs.Graphics().p("AlbGiIAAtDIK3AAIAANDg");
	var mask_2_graphics_119 = new cjs.Graphics().p("Al3GiIAAtDILvAAIAANDg");
	var mask_2_graphics_120 = new cjs.Graphics().p("AmUGiIAAtDIMpAAIAANDg");
	var mask_2_graphics_121 = new cjs.Graphics().p("AmxGiIAAtDINjAAIAANDg");
	var mask_2_graphics_122 = new cjs.Graphics().p("AnOGiIAAtDIOdAAIAANDg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AnqGiIAAtDIPVAAIAANDg");
	var mask_2_graphics_124 = new cjs.Graphics().p("AoHGiIAAtDIQPAAIAANDg");
	var mask_2_graphics_125 = new cjs.Graphics().p("AokGiIAAtDIRJAAIAANDg");
	var mask_2_graphics_126 = new cjs.Graphics().p("ApBGiIAAtDISDAAIAANDg");
	var mask_2_graphics_127 = new cjs.Graphics().p("ApdGiIAAtDIS7AAIAANDg");
	var mask_2_graphics_128 = new cjs.Graphics().p("Ap6GiIAAtDIT1AAIAANDg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AqXGiIAAtDIUvAAIAANDg");
	var mask_2_graphics_130 = new cjs.Graphics().p("Aq0GiIAAtDIVpAAIAANDg");
	var mask_2_graphics_131 = new cjs.Graphics().p("ArQGiIAAtDIWhAAIAANDg");
	var mask_2_graphics_132 = new cjs.Graphics().p("ArtGiIAAtDIXbAAIAANDg");
	var mask_2_graphics_133 = new cjs.Graphics().p("AsKGiIAAtDIYVAAIAANDg");
	var mask_2_graphics_134 = new cjs.Graphics().p("AsnGiIAAtDIZPAAIAANDg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AtDGiIAAtDIaHAAIAANDg");
	var mask_2_graphics_136 = new cjs.Graphics().p("AtgGiIAAtDIbBAAIAANDg");
	var mask_2_graphics_137 = new cjs.Graphics().p("At9GiIAAtDIb7AAIAANDg");
	var mask_2_graphics_138 = new cjs.Graphics().p("AuaGiIAAtDIc1AAIAANDg");
	var mask_2_graphics_139 = new cjs.Graphics().p("Au2GiIAAtDIdtAAIAANDg");
	var mask_2_graphics_140 = new cjs.Graphics().p("AvTCJIAAtDIenAAIAANDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(117).to({graphics:mask_2_graphics_117,x:54.7,y:-69.9}).wait(1).to({graphics:mask_2_graphics_118,x:74.6,y:-98}).wait(1).to({graphics:mask_2_graphics_119,x:71.7,y:-98}).wait(1).to({graphics:mask_2_graphics_120,x:68.8,y:-98}).wait(1).to({graphics:mask_2_graphics_121,x:65.9,y:-98}).wait(1).to({graphics:mask_2_graphics_122,x:63.1,y:-98}).wait(1).to({graphics:mask_2_graphics_123,x:60.2,y:-98}).wait(1).to({graphics:mask_2_graphics_124,x:57.3,y:-98}).wait(1).to({graphics:mask_2_graphics_125,x:54.4,y:-98}).wait(1).to({graphics:mask_2_graphics_126,x:51.6,y:-98}).wait(1).to({graphics:mask_2_graphics_127,x:48.7,y:-98}).wait(1).to({graphics:mask_2_graphics_128,x:45.8,y:-98}).wait(1).to({graphics:mask_2_graphics_129,x:42.9,y:-98}).wait(1).to({graphics:mask_2_graphics_130,x:40.1,y:-98}).wait(1).to({graphics:mask_2_graphics_131,x:37.2,y:-98}).wait(1).to({graphics:mask_2_graphics_132,x:34.3,y:-98}).wait(1).to({graphics:mask_2_graphics_133,x:31.4,y:-98}).wait(1).to({graphics:mask_2_graphics_134,x:28.6,y:-98}).wait(1).to({graphics:mask_2_graphics_135,x:25.7,y:-98}).wait(1).to({graphics:mask_2_graphics_136,x:22.8,y:-98}).wait(1).to({graphics:mask_2_graphics_137,x:19.9,y:-98}).wait(1).to({graphics:mask_2_graphics_138,x:17.1,y:-98}).wait(1).to({graphics:mask_2_graphics_139,x:14.2,y:-98}).wait(1).to({graphics:mask_2_graphics_140,x:11.3,y:-69.9}).wait(106));

	// flecha
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ABdBGQgrgQgrgNQhngghIgJQBBgGBughQAsgOA3gUQAsgRATgJIAADHIhMgeg");
	this.shape.setTransform(-47.7,-96.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AFHAAIqOAA");
	this.shape_1.setTransform(-4.7,-96.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AABAKQgWgIgUgCQASAAAYgJQAegJALgGIAAAxQgXgKgSgFg");
	this.shape_2.setTransform(-40,-96.8);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},117).wait(129));

	// Capa 12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_69 = new cjs.Graphics().p("EgKqAyyMAAAhljIVUAAMAAABljg");
	var mask_3_graphics_70 = new cjs.Graphics().p("EgMgAyyMAAAhljIZBAAMAAABljg");
	var mask_3_graphics_71 = new cjs.Graphics().p("EgOXAyyMAAAhljIcvAAMAAABljg");
	var mask_3_graphics_72 = new cjs.Graphics().p("EgQOAyyMAAAhljMAgdAAAMAAABljg");
	var mask_3_graphics_73 = new cjs.Graphics().p("EgSFAyyMAAAhljMAkLAAAMAAABljg");
	var mask_3_graphics_74 = new cjs.Graphics().p("EgT8AyyMAAAhljMAn5AAAMAAABljg");
	var mask_3_graphics_75 = new cjs.Graphics().p("EgVzAyyMAAAhljMArnAAAMAAABljg");
	var mask_3_graphics_76 = new cjs.Graphics().p("EgXqAyyMAAAhljMAvVAAAMAAABljg");
	var mask_3_graphics_77 = new cjs.Graphics().p("EgZhAyyMAAAhljMAzDAAAMAAABljg");
	var mask_3_graphics_78 = new cjs.Graphics().p("EgbYAyyMAAAhljMA2xAAAMAAABljg");
	var mask_3_graphics_79 = new cjs.Graphics().p("EgdPAyyMAAAhljMA6fAAAMAAABljg");
	var mask_3_graphics_80 = new cjs.Graphics().p("EgfGAyyMAAAhljMA+NAAAMAAABljg");
	var mask_3_graphics_81 = new cjs.Graphics().p("Egg9AyyMAAAhljMBB7AAAMAAABljg");
	var mask_3_graphics_82 = new cjs.Graphics().p("Egi0AyyMAAAhljMBFpAAAMAAABljg");
	var mask_3_graphics_83 = new cjs.Graphics().p("EgkrAyyMAAAhljMBJXAAAMAAABljg");
	var mask_3_graphics_84 = new cjs.Graphics().p("EgmiAyyMAAAhljMBNFAAAMAAABljg");
	var mask_3_graphics_85 = new cjs.Graphics().p("EgoZAyyMAAAhljMBQzAAAMAAABljg");
	var mask_3_graphics_86 = new cjs.Graphics().p("EgqQAyyMAAAhljMBUhAAAMAAABljg");
	var mask_3_graphics_87 = new cjs.Graphics().p("EgsHAyyMAAAhljMBYPAAAMAAABljg");
	var mask_3_graphics_88 = new cjs.Graphics().p("Egt+AyyMAAAhljMBb9AAAMAAABljg");
	var mask_3_graphics_89 = new cjs.Graphics().p("Egv1AyyMAAAhljMBfrAAAMAAABljg");
	var mask_3_graphics_90 = new cjs.Graphics().p("EgxsAyyMAAAhljMBjZAAAMAAABljg");
	var mask_3_graphics_91 = new cjs.Graphics().p("EgzjAyyMAAAhljMBnHAAAMAAABljg");
	var mask_3_graphics_92 = new cjs.Graphics().p("Eg1aAyyMAAAhljMBq1AAAMAAABljg");
	var mask_3_graphics_93 = new cjs.Graphics().p("Eg3RAyyMAAAhljMBujAAAMAAABljg");
	var mask_3_graphics_94 = new cjs.Graphics().p("Eg5IAyyMAAAhljMByRAAAMAAABljg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(69).to({graphics:mask_3_graphics_69,x:-322.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_70,x:-310.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_71,x:-298.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_72,x:-286.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_73,x:-274.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_74,x:-263,y:7.9}).wait(1).to({graphics:mask_3_graphics_75,x:-251.1,y:7.9}).wait(1).to({graphics:mask_3_graphics_76,x:-239.2,y:7.9}).wait(1).to({graphics:mask_3_graphics_77,x:-227.3,y:7.9}).wait(1).to({graphics:mask_3_graphics_78,x:-215.4,y:7.9}).wait(1).to({graphics:mask_3_graphics_79,x:-203.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_80,x:-191.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_81,x:-179.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_82,x:-167.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_83,x:-155.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_84,x:-144,y:7.9}).wait(1).to({graphics:mask_3_graphics_85,x:-132.1,y:7.9}).wait(1).to({graphics:mask_3_graphics_86,x:-120.2,y:7.9}).wait(1).to({graphics:mask_3_graphics_87,x:-108.3,y:7.9}).wait(1).to({graphics:mask_3_graphics_88,x:-96.4,y:7.9}).wait(1).to({graphics:mask_3_graphics_89,x:-84.5,y:7.9}).wait(1).to({graphics:mask_3_graphics_90,x:-72.6,y:7.9}).wait(1).to({graphics:mask_3_graphics_91,x:-60.7,y:7.9}).wait(1).to({graphics:mask_3_graphics_92,x:-48.8,y:7.9}).wait(1).to({graphics:mask_3_graphics_93,x:-36.9,y:7.9}).wait(1).to({graphics:mask_3_graphics_94,x:-25,y:7.9}).wait(152));

	// GRAFICA 2
	this.instance_2 = new lib.Path_24();
	this.instance_2.setTransform(40.3,4.4,1,1,0,0,0,258.9,286);
	this.instance_2._off = true;

	this.instance_2.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).wait(177));

	// Capa 11 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("EgtfBACMAAAiADIJ/AAMAAACADg");
	var mask_4_graphics_1 = new cjs.Graphics().p("EgIJBAEMAAAiAHIQTAAMAAACAHg");
	var mask_4_graphics_2 = new cjs.Graphics().p("EgLUBAGMAAAiALIWpAAMAAACALg");
	var mask_4_graphics_3 = new cjs.Graphics().p("EgOgBAHMAAAiANIdBAAMAAACANg");
	var mask_4_graphics_4 = new cjs.Graphics().p("EgRrBAJMAAAiARMAjXAAAMAAACARg");
	var mask_4_graphics_5 = new cjs.Graphics().p("EgU2BALMAAAiAVMAptAAAMAAACAVg");
	var mask_4_graphics_6 = new cjs.Graphics().p("EgYBBANMAAAiAZMAwDAAAMAAACAZg");
	var mask_4_graphics_7 = new cjs.Graphics().p("EgbMBAOMAAAiAbMA2ZAAAMAAACAbg");
	var mask_4_graphics_8 = new cjs.Graphics().p("EgeXBAQMAAAiAfMA8vAAAMAAACAfg");
	var mask_4_graphics_9 = new cjs.Graphics().p("EghjBASMAAAiAjMBDHAAAMAAACAjg");
	var mask_4_graphics_10 = new cjs.Graphics().p("EgkuBAUMAAAiAnMBJdAAAMAAACAng");
	var mask_4_graphics_11 = new cjs.Graphics().p("Egn5BAVMAAAiApMBPzAAAMAAACApg");
	var mask_4_graphics_12 = new cjs.Graphics().p("EgrEBAXMAAAiAtMBWJAAAMAAACAtg");
	var mask_4_graphics_13 = new cjs.Graphics().p("EguPBAZMAAAiAxMBcfAAAMAAACAxg");
	var mask_4_graphics_14 = new cjs.Graphics().p("EgxaBAbMAAAiA1MBi1AAAMAAACA1g");
	var mask_4_graphics_15 = new cjs.Graphics().p("Eg0mBAdMAAAiA5MBpNAAAMAAACA5g");
	var mask_4_graphics_16 = new cjs.Graphics().p("Eg3xBAeMAAAiA7MBvjAAAMAAACA7g");
	var mask_4_graphics_17 = new cjs.Graphics().p("Eg68BAgMAAAiA/MB15AAAMAAACA/g");
	var mask_4_graphics_18 = new cjs.Graphics().p("Eg+HBAiMAAAiBDMB8PAAAMAAACBDg");
	var mask_4_graphics_19 = new cjs.Graphics().p("EhBSBAkMAAAiBHMCClAAAMAAACBHg");
	var mask_4_graphics_20 = new cjs.Graphics().p("EhEdBAlMAAAiBJMCI7AAAMAAACBJg");
	var mask_4_graphics_21 = new cjs.Graphics().p("EhHpBAnMAAAiBNMCPTAAAMAAACBNg");
	var mask_4_graphics_22 = new cjs.Graphics().p("EhK0BApMAAAiBRMCVpAAAMAAACBRg");
	var mask_4_graphics_23 = new cjs.Graphics().p("EhN/BArMAAAiBVMCb/AAAMAAACBVg");
	var mask_4_graphics_24 = new cjs.Graphics().p("EhRKBAsMAAAiBXMCiVAAAMAAACBXg");
	var mask_4_graphics_25 = new cjs.Graphics().p("EhUVBAuMAAAiBbMCorAAAMAAACBbg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:-291.2,y:79.5}).wait(1).to({graphics:mask_4_graphics_1,x:-530.2,y:79.4}).wait(1).to({graphics:mask_4_graphics_2,x:-509.9,y:79.2}).wait(1).to({graphics:mask_4_graphics_3,x:-489.6,y:79}).wait(1).to({graphics:mask_4_graphics_4,x:-469.3,y:78.8}).wait(1).to({graphics:mask_4_graphics_5,x:-449,y:78.7}).wait(1).to({graphics:mask_4_graphics_6,x:-428.6,y:78.5}).wait(1).to({graphics:mask_4_graphics_7,x:-408.3,y:78.3}).wait(1).to({graphics:mask_4_graphics_8,x:-388,y:78.1}).wait(1).to({graphics:mask_4_graphics_9,x:-367.7,y:78}).wait(1).to({graphics:mask_4_graphics_10,x:-347.4,y:77.8}).wait(1).to({graphics:mask_4_graphics_11,x:-327,y:77.6}).wait(1).to({graphics:mask_4_graphics_12,x:-306.7,y:77.4}).wait(1).to({graphics:mask_4_graphics_13,x:-286.4,y:77.2}).wait(1).to({graphics:mask_4_graphics_14,x:-266.1,y:77.1}).wait(1).to({graphics:mask_4_graphics_15,x:-245.8,y:76.9}).wait(1).to({graphics:mask_4_graphics_16,x:-225.4,y:76.7}).wait(1).to({graphics:mask_4_graphics_17,x:-205.1,y:76.5}).wait(1).to({graphics:mask_4_graphics_18,x:-184.8,y:76.4}).wait(1).to({graphics:mask_4_graphics_19,x:-164.5,y:76.2}).wait(1).to({graphics:mask_4_graphics_20,x:-144.2,y:76}).wait(1).to({graphics:mask_4_graphics_21,x:-123.9,y:75.8}).wait(1).to({graphics:mask_4_graphics_22,x:-103.5,y:75.7}).wait(1).to({graphics:mask_4_graphics_23,x:-83.2,y:75.5}).wait(1).to({graphics:mask_4_graphics_24,x:-62.9,y:75.3}).wait(1).to({graphics:mask_4_graphics_25,x:-42.6,y:75.1}).wait(221));

	// EJE ORI
	this.text = new cjs.Text("X", "30px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 34;
	this.text.lineWidth = 33;
	this.text.setTransform(471.4,236.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_3.setTransform(387.4,296.3);

	this.text_1 = new cjs.Text("3", "30px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(378,306.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_4.setTransform(-419.7,298.1);

	this.text_2 = new cjs.Text("–4", "30px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-444.5,308.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_5.setTransform(-301.9,297);

	this.text_3 = new cjs.Text("–3", "30px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-322.5,307.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_6.setTransform(-190.8,295.7);

	this.text_4 = new cjs.Text("–2", "30px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-211.4,306.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_7.setTransform(-74.4,299.1);

	this.text_5 = new cjs.Text("–1", "30px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-95,309.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_8.setTransform(271.7,296.6);

	this.text_6 = new cjs.Text("2", "30px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(262.3,306.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_9.setTransform(156.1,297.5);

	this.text_7 = new cjs.Text("1", "30px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(146.7,307.6);

	this.text_8 = new cjs.Text("0", "30px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(45.8,298.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_10.setTransform(471.2,290.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_11.setTransform(-0.9,290.8);

	this.text.mask = this.shape_3.mask = this.text_1.mask = this.shape_4.mask = this.text_2.mask = this.shape_5.mask = this.text_3.mask = this.shape_6.mask = this.text_4.mask = this.shape_7.mask = this.text_5.mask = this.shape_8.mask = this.text_6.mask = this.shape_9.mask = this.text_7.mask = this.text_8.mask = this.shape_10.mask = this.shape_11.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.text_8},{t:this.text_7},{t:this.shape_9},{t:this.text_6},{t:this.shape_8},{t:this.text_5},{t:this.shape_7},{t:this.text_4},{t:this.shape_6},{t:this.text_3},{t:this.shape_5},{t:this.text_2},{t:this.shape_4},{t:this.text_1},{t:this.shape_3},{t:this.text}]}).wait(246));

	// EJE VERTI
	this.text_9 = new cjs.Text("Y", "30px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 34;
	this.text_9.lineWidth = 33;
	this.text_9.setTransform(49.4,-332);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_12.setTransform(34.4,407.3);

	this.text_10 = new cjs.Text("–1", "29px Verdana");
	this.text_10.lineHeight = 35;
	this.text_10.setTransform(-2.8,393.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_13.setTransform(33.4,-53.5);

	this.text_11 = new cjs.Text("3", "29px Verdana");
	this.text_11.lineHeight = 35;
	this.text_11.setTransform(8,-67.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_14.setTransform(33.4,-168.2);

	this.text_12 = new cjs.Text("4", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(6.8,-182.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_15.setTransform(33.4,62.2);

	this.text_13 = new cjs.Text("2", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(9.1,48.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_16.setTransform(33.4,181.1);

	this.text_14 = new cjs.Text("1", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(10.3,167);

	this.text_15 = new cjs.Text("0", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(13.5,261.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_17.setTransform(39.2,-276.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_18.setTransform(39.2,91.9);

	this.text_9.mask = this.shape_12.mask = this.text_10.mask = this.shape_13.mask = this.text_11.mask = this.shape_14.mask = this.text_12.mask = this.shape_15.mask = this.text_13.mask = this.shape_16.mask = this.text_14.mask = this.text_15.mask = this.shape_17.mask = this.shape_18.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.text_15},{t:this.text_14},{t:this.shape_16},{t:this.text_13},{t:this.shape_15},{t:this.text_12},{t:this.shape_14},{t:this.text_11},{t:this.shape_13},{t:this.text_10},{t:this.shape_12},{t:this.text_9}]}).wait(246));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-332,966.2,793.3);


(lib.IMG_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// GUIAS (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_109 = new cjs.Graphics().p("EgK6A1uMAAAhrbIV1AAMAAABrbg");
	var mask_graphics_110 = new cjs.Graphics().p("EgNOA1uMAAAhrbIadAAMAAABrbg");
	var mask_graphics_111 = new cjs.Graphics().p("EgPiA1uMAAAhrbIfFAAMAAABrbg");
	var mask_graphics_112 = new cjs.Graphics().p("EgR2A1uMAAAhrbMAjtAAAMAAABrbg");
	var mask_graphics_113 = new cjs.Graphics().p("EgUKA1uMAAAhrbMAoVAAAMAAABrbg");
	var mask_graphics_114 = new cjs.Graphics().p("EgWdA1uMAAAhrbMAs7AAAMAAABrbg");
	var mask_graphics_115 = new cjs.Graphics().p("EgYxA1uMAAAhrbMAxjAAAMAAABrbg");
	var mask_graphics_116 = new cjs.Graphics().p("EgbFA1uMAAAhrbMA2LAAAMAAABrbg");
	var mask_graphics_117 = new cjs.Graphics().p("EgdZA1uMAAAhrbMA6zAAAMAAABrbg");
	var mask_graphics_118 = new cjs.Graphics().p("EgftA1uMAAAhrbMA/bAAAMAAABrbg");
	var mask_graphics_119 = new cjs.Graphics().p("EgiBA1uMAAAhrbMBEDAAAMAAABrbg");
	var mask_graphics_120 = new cjs.Graphics().p("EgkVA1uMAAAhrbMBIrAAAMAAABrbg");
	var mask_graphics_121 = new cjs.Graphics().p("EgmoA1uMAAAhrbMBNRAAAMAAABrbg");
	var mask_graphics_122 = new cjs.Graphics().p("Ego8A1uMAAAhrbMBR5AAAMAAABrbg");
	var mask_graphics_123 = new cjs.Graphics().p("EgrQA1uMAAAhrbMBWhAAAMAAABrbg");
	var mask_graphics_124 = new cjs.Graphics().p("EgtkA1uMAAAhrbMBbJAAAMAAABrbg");
	var mask_graphics_125 = new cjs.Graphics().p("Egv4A1uMAAAhrbMBfxAAAMAAABrbg");
	var mask_graphics_126 = new cjs.Graphics().p("EgyMA1uMAAAhrbMBkZAAAMAAABrbg");
	var mask_graphics_127 = new cjs.Graphics().p("Eg0fA1uMAAAhrbMBo/AAAMAAABrbg");
	var mask_graphics_128 = new cjs.Graphics().p("Eg2zA1uMAAAhrbMBtnAAAMAAABrbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(109).to({graphics:mask_graphics_109,x:-419.8,y:-85.9}).wait(1).to({graphics:mask_graphics_110,x:-405,y:-85.9}).wait(1).to({graphics:mask_graphics_111,x:-390.2,y:-85.9}).wait(1).to({graphics:mask_graphics_112,x:-375.4,y:-85.9}).wait(1).to({graphics:mask_graphics_113,x:-360.6,y:-85.9}).wait(1).to({graphics:mask_graphics_114,x:-345.9,y:-85.9}).wait(1).to({graphics:mask_graphics_115,x:-331.1,y:-85.9}).wait(1).to({graphics:mask_graphics_116,x:-316.3,y:-85.9}).wait(1).to({graphics:mask_graphics_117,x:-301.5,y:-85.9}).wait(1).to({graphics:mask_graphics_118,x:-286.7,y:-85.9}).wait(1).to({graphics:mask_graphics_119,x:-271.9,y:-85.9}).wait(1).to({graphics:mask_graphics_120,x:-257.1,y:-85.9}).wait(1).to({graphics:mask_graphics_121,x:-242.4,y:-85.9}).wait(1).to({graphics:mask_graphics_122,x:-227.6,y:-85.9}).wait(1).to({graphics:mask_graphics_123,x:-212.8,y:-85.9}).wait(1).to({graphics:mask_graphics_124,x:-198,y:-85.9}).wait(1).to({graphics:mask_graphics_125,x:-183.2,y:-85.9}).wait(1).to({graphics:mask_graphics_126,x:-168.4,y:-85.9}).wait(1).to({graphics:mask_graphics_127,x:-153.7,y:-85.9}).wait(1).to({graphics:mask_graphics_128,x:-138.9,y:-85.9}).wait(4));

	// GRAFICA 1
	this.instance = new lib.Path_27();
	this.instance.setTransform(-73.6,-85.8,1,1,0,0,0,258.9,286);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(109).to({_off:false},0).wait(23));

	// puntos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,0,4).p("AA1g0QAWAXAAAdQAAAegWAWQgWAXgfAAQgdAAgWgXQgXgWAAgeQAAgdAXgXQAWgWAdAAQAfAAAWAWg");
	this.shape.setTransform(-74.1,199.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9907D7").s().p("Ag0A1QgVgXAAgeQAAgeAVgVQAXgXAdAAQAeAAAWAXQAXAVgBAeQABAegXAXQgWAVgeAAQgdAAgXgVg");
	this.shape_1.setTransform(-74.1,199.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("AHkoeQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfgAouHUQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAg");
	this.shape_2.setTransform(-18.1,144.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#9907D7").s().p("ApjJUQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWgAH6npQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWg");
	this.shape_3.setTransform(-18.1,144.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("AQkpTQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWgAAvHqQAWAWAAAfQAAAfgWAWQgWAWgdAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAQAdAAAWAWgAxYppQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAg");
	this.shape_4.setTransform(-73.5,144.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9907D7").s().p("Ag5JUQgWgWAAgfQAAgfAWgWQAWgWAfAAQAdAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgdAAQgfAAgWgWgAQjnpQgWgWABgfQgBgfAWgWQAXgWAfAAQAeAAAXAWQAVAWAAAfQAAAfgVAWQgXAWgeAAQgfAAgXgWgAyMnpQgXgWAAgfQAAgfAXgWQAVgWAgAAQAfAAAVAWQAXAWAAAfQAAAfgXAWQgVAWgfAAQggAAgVgWg");
	this.shape_5.setTransform(-73.5,144.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("EAb+gjyQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfgAH/RpQAfAAAWAVQAWAWAAAgQAAAegWAXQgWAWgfAAQgfAAgWgWQgWgXAAgeQAAggAWgWQAWgVAfAAgEgJeAioQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAgA59R+QAWAWAAAgQAAAegWAXQgWAWgfAAQgfAAgVgWQgXgXAAgeQAAggAXgWQAVgVAfAAQAfAAAWAVg");
	this.shape_6.setTransform(-13.3,-29.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#9907D7").s().p("EgKTAkoQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWgAHJToQgWgVABggQgBgfAWgVQAXgXAfAAQAeAAAXAXQAVAVAAAfQAAAggVAVQgXAXgeAAQgfAAgXgXgA7mToQgXgVAAggQAAgfAXgVQAVgXAgAAQAfAAAVAXQAXAVAAAfQAAAggXAVQgVAXgfAAQggAAgVgXgEAZ+gi9QgXgWAAgfQAAgfAXgWQAVgWAgAAQAeAAAXAWQAVAWAAAfQAAAfgVAWQgXAWgeAAQggAAgVgWg");
	this.shape_7.setTransform(-13.3,-29.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("EAk3gi9QgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWgAQZTpQgWgXAAgeQAAggAWgWQAWgVAfAAQAfAAAWAVQAWAWAAAgQAAAegWAXQgWAWgfAAQgfAAgWgWgEgk2gkYQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWgEAAlAi+QAVAWAAAfQAAAfgVAWQgWAWgeAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAQAeAAAWAWgAwXS0QAAAegWAXQgWAWgfAAQgfAAgWgWQgWgXAAgeQAAggAWgWQAWgVAfAAQAfAAAWAVQAWAWAAAgg");
	this.shape_8.setTransform(-72.5,-29.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9907D7").s().p("EgBEAkoQgVgWAAgfQAAgfAVgWQAXgWAeAAQAdAAAWAWQAXAWgBAfQABAfgXAWQgWAWgdAAQgeAAgXgWgAQZToQgWgVAAggQAAgfAWgVQAWgXAfAAQAfAAAWAXQAWAVAAAfQAAAggWAVQgWAXgfAAQgfAAgWgXgAyXToQgWgVAAggQAAgfAWgVQAWgXAfAAQAfAAAWAXQAWAVAAAfQAAAggWAVQgWAXgfAAQgfAAgWgXgEgk2gitQgWgXAAgeQAAggAWgVQAWgXAfAAQAfAAAWAXQAWAVAAAgQAAAegWAXQgWAVgfAAQgfAAgWgVgEAjNgi9QgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWg");
	this.shape_9.setTransform(-72.5,-29.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("EAlNgjyQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAQAfAAAWAWQAWAWAAAfgAQDS0QAAggAWgWQAWgVAfAAQAfAAAWAVQAWAWAAAgQAAAegWAXQgWAWgfAAQgfAAgWgWQgWgXAAgegEgkBgkuQAfAAAWAWQAWAWAAAfQAAAfgWAWQgWAWgfAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAgEgAPAioQAeAAAWAWQAVAWAAAfQAAAfgVAWQgWAWgeAAQgfAAgWgWQgWgWAAgfQAAgfAWgWQAWgWAfAAgAwtTpQgWAWgfAAQgfAAgWgWQgWgXAAgeQAAggAWgWQAWgVAfAAQAfAAAWAVQAWAWAAAgQAAAegWAXg");
	this.shape_10.setTransform(-72.5,-29.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},41).to({state:[{t:this.shape_3},{t:this.shape_2}]},12).to({state:[{t:this.shape_5},{t:this.shape_4}]},11).to({state:[{t:this.shape_7},{t:this.shape_6}]},12).to({state:[{t:this.shape_9},{t:this.shape_8}]},11).to({state:[{t:this.shape_9},{t:this.shape_10}]},12).wait(33));

	// Capa 6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgtmA+KMAAAh8TIMMAAMAAAB8Tg");
	var mask_1_graphics_1 = new cjs.Graphics().p("EgI2A+KMAAAh8TIRtAAMAAAB8Tg");
	var mask_1_graphics_2 = new cjs.Graphics().p("EgLpA+KMAAAh8TIXTAAMAAAB8Tg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EgObA+KMAAAh8TIc3AAMAAAB8Tg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EgRNA+KMAAAh8TMAibAAAMAAAB8Tg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EgT/A+KMAAAh8TMAn/AAAMAAAB8Tg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EgWxA+KMAAAh8TMAtjAAAMAAAB8Tg");
	var mask_1_graphics_7 = new cjs.Graphics().p("EgZkA+KMAAAh8TMAzJAAAMAAAB8Tg");
	var mask_1_graphics_8 = new cjs.Graphics().p("EgcWA+KMAAAh8TMA4tAAAMAAAB8Tg");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgfIA+KMAAAh8TMA+RAAAMAAAB8Tg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Egh6A+KMAAAh8TMBD1AAAMAAAB8Tg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgksA+KMAAAh8TMBJZAAAMAAAB8Tg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgneA+KMAAAh8TMBO9AAAMAAAB8Tg");
	var mask_1_graphics_13 = new cjs.Graphics().p("EgqRA+KMAAAh8TMBUjAAAMAAAB8Tg");
	var mask_1_graphics_14 = new cjs.Graphics().p("EgtDA+KMAAAh8TMBaHAAAMAAAB8Tg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Egv1A+KMAAAh8TMBfrAAAMAAAB8Tg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EgynA+KMAAAh8TMBlPAAAMAAAB8Tg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Eg1ZA+KMAAAh8TMBqzAAAMAAAB8Tg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Eg4MA+KMAAAh8TMBwZAAAMAAAB8Tg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Eg6+A+KMAAAh8TMB19AAAMAAAB8Tg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Eg9wA+KMAAAh8TMB7hAAAMAAAB8Tg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EhAiA+KMAAAh8TMCBFAAAMAAAB8Tg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EhDUA+KMAAAh8TMCGpAAAMAAAB8Tg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EhGGA+KMAAAh8TMCMNAAAMAAAB8Tg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EhI5A+KMAAAh8TMCRzAAAMAAAB8Tg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EhLrA+KMAAAh8TMCXXAAAMAAAB8Tg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EhOdA+KMAAAh8TMCc7AAAMAAAB8Tg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EhRPA+KMAAAh8TMCifAAAMAAAB8Tg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EhUBA+KMAAAh8TMCoDAAAMAAAB8Tg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EhWzA+KMAAAh8TMCtnAAAMAAAB8Tg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-291.8,y:-21.9}).wait(1).to({graphics:mask_1_graphics_1,x:-526.9,y:-21.9}).wait(1).to({graphics:mask_1_graphics_2,x:-509.1,y:-21.9}).wait(1).to({graphics:mask_1_graphics_3,x:-491.3,y:-21.9}).wait(1).to({graphics:mask_1_graphics_4,x:-473.5,y:-21.9}).wait(1).to({graphics:mask_1_graphics_5,x:-455.7,y:-21.9}).wait(1).to({graphics:mask_1_graphics_6,x:-437.9,y:-21.9}).wait(1).to({graphics:mask_1_graphics_7,x:-420.1,y:-21.9}).wait(1).to({graphics:mask_1_graphics_8,x:-402.2,y:-21.9}).wait(1).to({graphics:mask_1_graphics_9,x:-384.4,y:-21.9}).wait(1).to({graphics:mask_1_graphics_10,x:-366.6,y:-21.9}).wait(1).to({graphics:mask_1_graphics_11,x:-348.8,y:-21.9}).wait(1).to({graphics:mask_1_graphics_12,x:-331,y:-21.9}).wait(1).to({graphics:mask_1_graphics_13,x:-313.2,y:-21.9}).wait(1).to({graphics:mask_1_graphics_14,x:-295.4,y:-21.9}).wait(1).to({graphics:mask_1_graphics_15,x:-277.6,y:-21.9}).wait(1).to({graphics:mask_1_graphics_16,x:-259.8,y:-21.9}).wait(1).to({graphics:mask_1_graphics_17,x:-242,y:-21.9}).wait(1).to({graphics:mask_1_graphics_18,x:-224.2,y:-21.9}).wait(1).to({graphics:mask_1_graphics_19,x:-206.3,y:-21.9}).wait(1).to({graphics:mask_1_graphics_20,x:-188.5,y:-21.9}).wait(1).to({graphics:mask_1_graphics_21,x:-170.7,y:-21.9}).wait(1).to({graphics:mask_1_graphics_22,x:-152.9,y:-21.9}).wait(1).to({graphics:mask_1_graphics_23,x:-135.1,y:-21.9}).wait(1).to({graphics:mask_1_graphics_24,x:-117.3,y:-21.9}).wait(1).to({graphics:mask_1_graphics_25,x:-99.5,y:-21.9}).wait(1).to({graphics:mask_1_graphics_26,x:-81.7,y:-21.9}).wait(1).to({graphics:mask_1_graphics_27,x:-63.9,y:-21.9}).wait(1).to({graphics:mask_1_graphics_28,x:-46.1,y:-21.9}).wait(1).to({graphics:mask_1_graphics_29,x:-28.3,y:-21.9}).wait(103));

	// EJE ORI
	this.text = new cjs.Text("X", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 34;
	this.text.lineWidth = 33;
	this.text.setTransform(497.8,180.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_11.setTransform(387.4,206.3);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(378,216.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_12.setTransform(-419.7,208.1);

	this.text_2 = new cjs.Text("–4", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-444.5,218.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_13.setTransform(-301.9,207);

	this.text_3 = new cjs.Text("–3", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-322.5,217.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_14.setTransform(-190.8,205.7);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-211.4,216.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_15.setTransform(-74.4,209.1);

	this.text_5 = new cjs.Text("–1", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-95,219.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_16.setTransform(271.7,206.6);

	this.text_6 = new cjs.Text("2", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(262.3,216.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg7IAAB3");
	this.shape_17.setTransform(156.1,207.5);

	this.text_7 = new cjs.Text("1", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(146.7,217.6);

	this.text_8 = new cjs.Text("0", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(45.8,208.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgmAqIApgqIgpgpIASgSIA7A7Ig7A8g");
	this.shape_18.setTransform(471.2,200.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(3,0,0,4).p("EhJ6AAAMCT1AAA");
	this.shape_19.setTransform(-0.9,200.8);

	this.text.mask = this.shape_11.mask = this.text_1.mask = this.shape_12.mask = this.text_2.mask = this.shape_13.mask = this.text_3.mask = this.shape_14.mask = this.text_4.mask = this.shape_15.mask = this.text_5.mask = this.shape_16.mask = this.text_6.mask = this.shape_17.mask = this.text_7.mask = this.text_8.mask = this.shape_18.mask = this.shape_19.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.text_8},{t:this.text_7},{t:this.shape_17},{t:this.text_6},{t:this.shape_16},{t:this.text_5},{t:this.shape_15},{t:this.text_4},{t:this.shape_14},{t:this.text_3},{t:this.shape_13},{t:this.text_2},{t:this.shape_12},{t:this.text_1},{t:this.shape_11},{t:this.text}]}).wait(132));

	// EJE VERTI
	this.text_9 = new cjs.Text("Y", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 34;
	this.text_9.lineWidth = 33;
	this.text_9.setTransform(44.3,-419.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_20.setTransform(34.4,317.3);

	this.text_10 = new cjs.Text("–1", "29px Verdana");
	this.text_10.lineHeight = 35;
	this.text_10.setTransform(-2.8,303.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_21.setTransform(33.4,-143.5);

	this.text_11 = new cjs.Text("3", "29px Verdana");
	this.text_11.lineHeight = 35;
	this.text_11.setTransform(8,-157.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_22.setTransform(33.4,-258.2);

	this.text_12 = new cjs.Text("4", "29px Verdana");
	this.text_12.lineHeight = 35;
	this.text_12.setTransform(6.8,-272.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_23.setTransform(33.4,-27.7);

	this.text_13 = new cjs.Text("2", "29px Verdana");
	this.text_13.lineHeight = 35;
	this.text_13.setTransform(9.1,-41.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(3,0,0,4).p("AA5AAIhxAA");
	this.shape_24.setTransform(33.4,91.1);

	this.text_14 = new cjs.Text("1", "29px Verdana");
	this.text_14.lineHeight = 35;
	this.text_14.setTransform(10.3,77);

	this.text_15 = new cjs.Text("0", "29px Verdana");
	this.text_15.lineHeight = 35;
	this.text_15.setTransform(13.5,171.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_25.setTransform(39.2,-366.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(3,0,0,4).p("EAAAA5tMAAAhzZ");
	this.shape_26.setTransform(39.2,1.9);

	this.text_9.mask = this.shape_20.mask = this.text_10.mask = this.shape_21.mask = this.text_11.mask = this.shape_22.mask = this.text_12.mask = this.shape_23.mask = this.text_13.mask = this.shape_24.mask = this.text_14.mask = this.text_15.mask = this.shape_25.mask = this.shape_26.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.text_15},{t:this.text_14},{t:this.shape_24},{t:this.text_13},{t:this.shape_23},{t:this.text_12},{t:this.shape_22},{t:this.text_11},{t:this.shape_21},{t:this.text_10},{t:this.shape_20},{t:this.text_9}]}).wait(132));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-474.1,-419.8,992.6,791.1);


(lib.IMG_04 = function() {
	this.initialize();

	// GRAFICA 1
	this.instance = new lib.Path_28();
	this.instance.setTransform(-17.4,529.8,1,1,0,0,0,268.6,337.5);

	// EJE ORI
	this.text = new cjs.Text("X", "40px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 62;
	this.text.setTransform(564.4,859.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgzA5IA3g5Ig3g4IAYgYIBPBQIhPBRg");
	this.shape.setTransform(525.1,867.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EhJzAAAMCTnAAA");
	this.shape_1.setTransform(53.9,867.6);

	// EJE VERTI
	this.text_1 = new cjs.Text("Y", "40px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 62;
	this.text_1.setTransform(196.4,141.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAAgDIg4A3IgYgYIBQhPIBRBPIgYAYg");
	this.shape_2.setTransform(192.5,194.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,0,0,4).p("EAAAA8KMAAAh4T");
	this.shape_3.setTransform(192.5,578);

	this.addChild(this.shape_3,this.shape_2,this.text_1,this.shape_1,this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-418.5,141.9,1000.5,821.3);


(lib.IMG_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_171 = new cjs.Graphics().p("EgKQBOhMAAAidBIUhAAMAAACdBg");
	var mask_graphics_172 = new cjs.Graphics().p("EgLCBOhMAAAidBIWFAAMAAACdBg");
	var mask_graphics_173 = new cjs.Graphics().p("EgL0BOhMAAAidBIXpAAMAAACdBg");
	var mask_graphics_174 = new cjs.Graphics().p("EgMmBOhMAAAidBIZNAAMAAACdBg");
	var mask_graphics_175 = new cjs.Graphics().p("EgNYBOhMAAAidBIaxAAMAAACdBg");
	var mask_graphics_176 = new cjs.Graphics().p("EgOKBOhMAAAidBIcVAAMAAACdBg");
	var mask_graphics_177 = new cjs.Graphics().p("EgO8BOhMAAAidBId5AAMAAACdBg");
	var mask_graphics_178 = new cjs.Graphics().p("EgPuBOhMAAAidBIfdAAMAAACdBg");
	var mask_graphics_179 = new cjs.Graphics().p("EgQgBOhMAAAidBMAhBAAAMAAACdBg");
	var mask_graphics_180 = new cjs.Graphics().p("EgRSBOhMAAAidBMAilAAAMAAACdBg");
	var mask_graphics_181 = new cjs.Graphics().p("EgSEBOhMAAAidBMAkJAAAMAAACdBg");
	var mask_graphics_182 = new cjs.Graphics().p("EgS2BOhMAAAidBMAltAAAMAAACdBg");
	var mask_graphics_183 = new cjs.Graphics().p("EgToBOhMAAAidBMAnRAAAMAAACdBg");
	var mask_graphics_184 = new cjs.Graphics().p("EgUaBOhMAAAidBMAo1AAAMAAACdBg");
	var mask_graphics_185 = new cjs.Graphics().p("EgVMBOhMAAAidBMAqZAAAMAAACdBg");
	var mask_graphics_186 = new cjs.Graphics().p("EgV+BOhMAAAidBMAr9AAAMAAACdBg");
	var mask_graphics_187 = new cjs.Graphics().p("EgWwBOhMAAAidBMAthAAAMAAACdBg");
	var mask_graphics_188 = new cjs.Graphics().p("EgXjBOhMAAAidBMAvHAAAMAAACdBg");
	var mask_graphics_189 = new cjs.Graphics().p("EgYVBOhMAAAidBMAwrAAAMAAACdBg");
	var mask_graphics_190 = new cjs.Graphics().p("EgZHBOhMAAAidBMAyPAAAMAAACdBg");
	var mask_graphics_191 = new cjs.Graphics().p("EgZ5BOhMAAAidBMAzzAAAMAAACdBg");
	var mask_graphics_192 = new cjs.Graphics().p("EgarBOhMAAAidBMA1XAAAMAAACdBg");
	var mask_graphics_193 = new cjs.Graphics().p("EgbdBOhMAAAidBMA27AAAMAAACdBg");
	var mask_graphics_194 = new cjs.Graphics().p("EgcPBOhMAAAidBMA4fAAAMAAACdBg");
	var mask_graphics_195 = new cjs.Graphics().p("EgdBBOhMAAAidBMA6DAAAMAAACdBg");
	var mask_graphics_196 = new cjs.Graphics().p("EgdzBOhMAAAidBMA7nAAAMAAACdBg");
	var mask_graphics_197 = new cjs.Graphics().p("EgelBOhMAAAidBMA9LAAAMAAACdBg");
	var mask_graphics_198 = new cjs.Graphics().p("EgfXBOhMAAAidBMA+vAAAMAAACdBg");
	var mask_graphics_199 = new cjs.Graphics().p("EggJBOhMAAAidBMBATAAAMAAACdBg");
	var mask_graphics_200 = new cjs.Graphics().p("Egg7BOhMAAAidBMBB3AAAMAAACdBg");
	var mask_graphics_201 = new cjs.Graphics().p("EghtBOhMAAAidBMBDbAAAMAAACdBg");
	var mask_graphics_202 = new cjs.Graphics().p("EgifBOhMAAAidBMBE/AAAMAAACdBg");
	var mask_graphics_203 = new cjs.Graphics().p("EgjRBOhMAAAidBMBGjAAAMAAACdBg");
	var mask_graphics_204 = new cjs.Graphics().p("EgkDBOhMAAAidBMBIHAAAMAAACdBg");
	var mask_graphics_205 = new cjs.Graphics().p("Egk1BOhMAAAidBMBJrAAAMAAACdBg");
	var mask_graphics_206 = new cjs.Graphics().p("EglnBOhMAAAidBMBLPAAAMAAACdBg");
	var mask_graphics_207 = new cjs.Graphics().p("EgmZBOhMAAAidBMBMzAAAMAAACdBg");
	var mask_graphics_208 = new cjs.Graphics().p("EgnLBOhMAAAidBMBOXAAAMAAACdBg");
	var mask_graphics_209 = new cjs.Graphics().p("Egn9BOhMAAAidBMBP7AAAMAAACdBg");
	var mask_graphics_210 = new cjs.Graphics().p("EgovBOhMAAAidBMBRfAAAMAAACdBg");
	var mask_graphics_211 = new cjs.Graphics().p("EgphBOhMAAAidBMBTDAAAMAAACdBg");
	var mask_graphics_212 = new cjs.Graphics().p("EgqTBOhMAAAidBMBUnAAAMAAACdBg");
	var mask_graphics_213 = new cjs.Graphics().p("EgrFBOhMAAAidBMBWLAAAMAAACdBg");
	var mask_graphics_214 = new cjs.Graphics().p("Egr3BOhMAAAidBMBXvAAAMAAACdBg");
	var mask_graphics_215 = new cjs.Graphics().p("EgspBOhMAAAidBMBZTAAAMAAACdBg");
	var mask_graphics_216 = new cjs.Graphics().p("EgtbBOhMAAAidBMBa3AAAMAAACdBg");
	var mask_graphics_217 = new cjs.Graphics().p("EguNBOhMAAAidBMBcbAAAMAAACdBg");
	var mask_graphics_218 = new cjs.Graphics().p("Egu/BOhMAAAidBMBd/AAAMAAACdBg");
	var mask_graphics_219 = new cjs.Graphics().p("EgvxBOhMAAAidBMBfjAAAMAAACdBg");
	var mask_graphics_220 = new cjs.Graphics().p("EgwjBPRMAAAidAMBhHAAAMAAACdAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(171).to({graphics:mask_graphics_171,x:-409.1,y:512.3}).wait(1).to({graphics:mask_graphics_172,x:-404.1,y:512.3}).wait(1).to({graphics:mask_graphics_173,x:-399.1,y:512.3}).wait(1).to({graphics:mask_graphics_174,x:-394.1,y:512.3}).wait(1).to({graphics:mask_graphics_175,x:-389.1,y:512.3}).wait(1).to({graphics:mask_graphics_176,x:-384.1,y:512.3}).wait(1).to({graphics:mask_graphics_177,x:-379.1,y:512.3}).wait(1).to({graphics:mask_graphics_178,x:-374.1,y:512.3}).wait(1).to({graphics:mask_graphics_179,x:-369.1,y:512.3}).wait(1).to({graphics:mask_graphics_180,x:-364.1,y:512.3}).wait(1).to({graphics:mask_graphics_181,x:-359.1,y:512.3}).wait(1).to({graphics:mask_graphics_182,x:-354.1,y:512.3}).wait(1).to({graphics:mask_graphics_183,x:-349.1,y:512.3}).wait(1).to({graphics:mask_graphics_184,x:-344.1,y:512.3}).wait(1).to({graphics:mask_graphics_185,x:-339.1,y:512.3}).wait(1).to({graphics:mask_graphics_186,x:-334.1,y:512.3}).wait(1).to({graphics:mask_graphics_187,x:-329.1,y:512.3}).wait(1).to({graphics:mask_graphics_188,x:-324,y:512.3}).wait(1).to({graphics:mask_graphics_189,x:-319,y:512.3}).wait(1).to({graphics:mask_graphics_190,x:-314,y:512.3}).wait(1).to({graphics:mask_graphics_191,x:-309,y:512.3}).wait(1).to({graphics:mask_graphics_192,x:-304,y:512.3}).wait(1).to({graphics:mask_graphics_193,x:-299,y:512.3}).wait(1).to({graphics:mask_graphics_194,x:-294,y:512.3}).wait(1).to({graphics:mask_graphics_195,x:-289,y:512.3}).wait(1).to({graphics:mask_graphics_196,x:-284,y:512.3}).wait(1).to({graphics:mask_graphics_197,x:-279,y:512.3}).wait(1).to({graphics:mask_graphics_198,x:-274,y:512.3}).wait(1).to({graphics:mask_graphics_199,x:-269,y:512.3}).wait(1).to({graphics:mask_graphics_200,x:-264,y:512.3}).wait(1).to({graphics:mask_graphics_201,x:-259,y:512.3}).wait(1).to({graphics:mask_graphics_202,x:-254,y:512.3}).wait(1).to({graphics:mask_graphics_203,x:-249,y:512.3}).wait(1).to({graphics:mask_graphics_204,x:-244,y:512.3}).wait(1).to({graphics:mask_graphics_205,x:-239,y:512.3}).wait(1).to({graphics:mask_graphics_206,x:-234,y:512.3}).wait(1).to({graphics:mask_graphics_207,x:-229,y:512.3}).wait(1).to({graphics:mask_graphics_208,x:-224,y:512.3}).wait(1).to({graphics:mask_graphics_209,x:-219,y:512.3}).wait(1).to({graphics:mask_graphics_210,x:-214,y:512.3}).wait(1).to({graphics:mask_graphics_211,x:-209,y:512.3}).wait(1).to({graphics:mask_graphics_212,x:-204,y:512.3}).wait(1).to({graphics:mask_graphics_213,x:-199,y:512.3}).wait(1).to({graphics:mask_graphics_214,x:-194,y:512.3}).wait(1).to({graphics:mask_graphics_215,x:-189,y:512.3}).wait(1).to({graphics:mask_graphics_216,x:-184,y:512.3}).wait(1).to({graphics:mask_graphics_217,x:-179,y:512.3}).wait(1).to({graphics:mask_graphics_218,x:-174,y:512.3}).wait(1).to({graphics:mask_graphics_219,x:-169,y:512.3}).wait(1).to({graphics:mask_graphics_220,x:-164,y:507.4}).wait(9));

	// grafica 3
	this.text = new cjs.Text("q<0", "italic bold 36px Verdana", "#FF0000");
	this.text.lineHeight = 41;
	this.text.lineWidth = 115;
	this.text.setTransform(-4.2,613.4);

	this.instance = new lib.Path_29();
	this.instance.setTransform(-133.7,512.1,1,1,0,0,0,184.7,454.8);

	this.text.mask = this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance},{t:this.text}]},171).wait(58));

	// Capa 13 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_67 = new cjs.Graphics().p("EgHEAqtMAAAhVZIOJAAMAAABVZg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgHvAqtMAAAhVZIPfAAMAAABVZg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgIaAqtMAAAhVZIQ1AAMAAABVZg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EgJEAqtMAAAhVZISJAAMAAABVZg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EgJvAqtMAAAhVZITfAAMAAABVZg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EgKaAqtMAAAhVZIU1AAMAAABVZg");
	var mask_1_graphics_73 = new cjs.Graphics().p("EgLEAqtMAAAhVZIWJAAMAAABVZg");
	var mask_1_graphics_74 = new cjs.Graphics().p("EgLvAqtMAAAhVZIXfAAMAAABVZg");
	var mask_1_graphics_75 = new cjs.Graphics().p("EgMaAqtMAAAhVZIY1AAMAAABVZg");
	var mask_1_graphics_76 = new cjs.Graphics().p("EgNEAqtMAAAhVZIaJAAMAAABVZg");
	var mask_1_graphics_77 = new cjs.Graphics().p("EgNvAqtMAAAhVZIbfAAMAAABVZg");
	var mask_1_graphics_78 = new cjs.Graphics().p("EgOaAqtMAAAhVZIc1AAMAAABVZg");
	var mask_1_graphics_79 = new cjs.Graphics().p("EgPEAqtMAAAhVZIeJAAMAAABVZg");
	var mask_1_graphics_80 = new cjs.Graphics().p("EgPvAqtMAAAhVZIffAAMAAABVZg");
	var mask_1_graphics_81 = new cjs.Graphics().p("EgQaAqtMAAAhVZMAg1AAAMAAABVZg");
	var mask_1_graphics_82 = new cjs.Graphics().p("EgREAqtMAAAhVZMAiJAAAMAAABVZg");
	var mask_1_graphics_83 = new cjs.Graphics().p("EgRvAqtMAAAhVZMAjfAAAMAAABVZg");
	var mask_1_graphics_84 = new cjs.Graphics().p("EgSaAqtMAAAhVZMAk1AAAMAAABVZg");
	var mask_1_graphics_85 = new cjs.Graphics().p("EgTEAqtMAAAhVZMAmJAAAMAAABVZg");
	var mask_1_graphics_86 = new cjs.Graphics().p("EgTvAqtMAAAhVZMAnfAAAMAAABVZg");
	var mask_1_graphics_87 = new cjs.Graphics().p("EgUaAqtMAAAhVZMAo1AAAMAAABVZg");
	var mask_1_graphics_88 = new cjs.Graphics().p("EgVEAqtMAAAhVZMAqJAAAMAAABVZg");
	var mask_1_graphics_89 = new cjs.Graphics().p("EgVvAqtMAAAhVZMArfAAAMAAABVZg");
	var mask_1_graphics_90 = new cjs.Graphics().p("EgWaAqtMAAAhVZMAs1AAAMAAABVZg");
	var mask_1_graphics_91 = new cjs.Graphics().p("EgXEAqtMAAAhVZMAuJAAAMAAABVZg");
	var mask_1_graphics_92 = new cjs.Graphics().p("EgXvAqtMAAAhVZMAvfAAAMAAABVZg");
	var mask_1_graphics_93 = new cjs.Graphics().p("EgYaAqtMAAAhVZMAw1AAAMAAABVZg");
	var mask_1_graphics_94 = new cjs.Graphics().p("EgZEAqtMAAAhVZMAyJAAAMAAABVZg");
	var mask_1_graphics_95 = new cjs.Graphics().p("EgZvAqtMAAAhVZMAzfAAAMAAABVZg");
	var mask_1_graphics_96 = new cjs.Graphics().p("EgaaAqtMAAAhVZMA01AAAMAAABVZg");
	var mask_1_graphics_97 = new cjs.Graphics().p("EgbEAqtMAAAhVZMA2JAAAMAAABVZg");
	var mask_1_graphics_98 = new cjs.Graphics().p("EgbvAqtMAAAhVZMA3fAAAMAAABVZg");
	var mask_1_graphics_99 = new cjs.Graphics().p("EgcaAqtMAAAhVZMA41AAAMAAABVZg");
	var mask_1_graphics_100 = new cjs.Graphics().p("EgdEAqtMAAAhVZMA6JAAAMAAABVZg");
	var mask_1_graphics_101 = new cjs.Graphics().p("EgdvAqtMAAAhVZMA7fAAAMAAABVZg");
	var mask_1_graphics_102 = new cjs.Graphics().p("EgeaAqtMAAAhVZMA81AAAMAAABVZg");
	var mask_1_graphics_103 = new cjs.Graphics().p("EgfEAqtMAAAhVZMA+JAAAMAAABVZg");
	var mask_1_graphics_104 = new cjs.Graphics().p("EgfvAqtMAAAhVZMA/fAAAMAAABVZg");
	var mask_1_graphics_105 = new cjs.Graphics().p("EggaAqtMAAAhVZMBA1AAAMAAABVZg");
	var mask_1_graphics_106 = new cjs.Graphics().p("EghEAqtMAAAhVZMBCJAAAMAAABVZg");
	var mask_1_graphics_107 = new cjs.Graphics().p("EghvAqtMAAAhVZMBDfAAAMAAABVZg");
	var mask_1_graphics_108 = new cjs.Graphics().p("EgiaAqtMAAAhVZMBE1AAAMAAABVZg");
	var mask_1_graphics_109 = new cjs.Graphics().p("EgjEAqtMAAAhVZMBGJAAAMAAABVZg");
	var mask_1_graphics_110 = new cjs.Graphics().p("EgjvAqtMAAAhVZMBHfAAAMAAABVZg");
	var mask_1_graphics_111 = new cjs.Graphics().p("EgkaAqtMAAAhVZMBI1AAAMAAABVZg");
	var mask_1_graphics_112 = new cjs.Graphics().p("EglEAqtMAAAhVZMBKJAAAMAAABVZg");
	var mask_1_graphics_113 = new cjs.Graphics().p("EglvAqtMAAAhVZMBLfAAAMAAABVZg");
	var mask_1_graphics_114 = new cjs.Graphics().p("EgmaAqtMAAAhVZMBM1AAAMAAABVZg");
	var mask_1_graphics_115 = new cjs.Graphics().p("EgnEAqtMAAAhVZMBOJAAAMAAABVZg");
	var mask_1_graphics_116 = new cjs.Graphics().p("EgnvAqtMAAAhVZMBPfAAAMAAABVZg");
	var mask_1_graphics_117 = new cjs.Graphics().p("EgoZAsLMAAAhVZMBQzAAAMAAABVZg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(67).to({graphics:mask_1_graphics_67,x:-395.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_68,x:-391.2,y:292.2}).wait(1).to({graphics:mask_1_graphics_69,x:-386.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_70,x:-382.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_71,x:-378.4,y:292.2}).wait(1).to({graphics:mask_1_graphics_72,x:-374.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_73,x:-369.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_74,x:-365.6,y:292.2}).wait(1).to({graphics:mask_1_graphics_75,x:-361.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_76,x:-357.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_77,x:-352.8,y:292.2}).wait(1).to({graphics:mask_1_graphics_78,x:-348.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_79,x:-344.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_80,x:-340,y:292.2}).wait(1).to({graphics:mask_1_graphics_81,x:-335.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_82,x:-331.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_83,x:-327.2,y:292.2}).wait(1).to({graphics:mask_1_graphics_84,x:-322.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_85,x:-318.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_86,x:-314.4,y:292.2}).wait(1).to({graphics:mask_1_graphics_87,x:-310.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_88,x:-305.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_89,x:-301.6,y:292.2}).wait(1).to({graphics:mask_1_graphics_90,x:-297.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_91,x:-293.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_92,x:-288.8,y:292.2}).wait(1).to({graphics:mask_1_graphics_93,x:-284.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_94,x:-280.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_95,x:-276,y:292.2}).wait(1).to({graphics:mask_1_graphics_96,x:-271.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_97,x:-267.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_98,x:-263.2,y:292.2}).wait(1).to({graphics:mask_1_graphics_99,x:-258.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_100,x:-254.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_101,x:-250.4,y:292.2}).wait(1).to({graphics:mask_1_graphics_102,x:-246.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_103,x:-241.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_104,x:-237.6,y:292.2}).wait(1).to({graphics:mask_1_graphics_105,x:-233.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_106,x:-229.1,y:292.2}).wait(1).to({graphics:mask_1_graphics_107,x:-224.8,y:292.2}).wait(1).to({graphics:mask_1_graphics_108,x:-220.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_109,x:-216.3,y:292.2}).wait(1).to({graphics:mask_1_graphics_110,x:-212,y:292.2}).wait(1).to({graphics:mask_1_graphics_111,x:-207.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_112,x:-203.5,y:292.2}).wait(1).to({graphics:mask_1_graphics_113,x:-199.2,y:292.2}).wait(1).to({graphics:mask_1_graphics_114,x:-194.9,y:292.2}).wait(1).to({graphics:mask_1_graphics_115,x:-190.7,y:292.2}).wait(1).to({graphics:mask_1_graphics_116,x:-186.4,y:292.2}).wait(1).to({graphics:mask_1_graphics_117,x:-182.2,y:282.8}).wait(112));

	// GRAFICA 2
	this.text_1 = new cjs.Text("q>0", "italic bold 36px Verdana", "#00A52F");
	this.text_1.lineHeight = 41;
	this.text_1.lineWidth = 131;
	this.text_1.setTransform(-127.5,201);

	this.instance_1 = new lib.Path_30();
	this.instance_1.setTransform(-136.8,296,1,1,0,0,0,133.6,237.3);

	this.text_1.mask = this.instance_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.text_1}]},67).wait(162));

	// GRAFICA 1
	this.instance_2 = new lib.Path_31();
	this.instance_2.setTransform(-136.7,403,1,1,0,0,0,160.7,344.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(229));

	// EJE ORI
	this.text_2 = new cjs.Text("X", "40px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 62;
	this.text_2.setTransform(407.8,739.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g4IAYgYIBPBQIhPBRg");
	this.shape.setTransform(380,747.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,0,0,4).p("EhJzAAAMCTnAAA");
	this.shape_1.setTransform(-91.1,747.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_2}]}).wait(229));

	// EJE VERTI
	this.text_3 = new cjs.Text("Y", "40px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 62;
	this.text_3.setTransform(-131.3,7.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAAgDIg3A3IgZgYIBQhPIBRBPIgYAYg");
	this.shape_2.setTransform(-135.3,60.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,0,0,4).p("EAAABKDMAAAiUF");
	this.shape_3.setTransform(-135.3,533);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text_3}]}).wait(229));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-563.6,7.6,988.9,999.4);


(lib.IMG_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_144 = new cjs.Graphics().p("EgZvAwNMAAAhgZIVRAAMAAABgZg");
	var mask_graphics_145 = new cjs.Graphics().p("EgL2AwNMAAAhgZIXtAAMAAABgZg");
	var mask_graphics_146 = new cjs.Graphics().p("EgNGAwOMAAAhgbIaNAAMAAABgbg");
	var mask_graphics_147 = new cjs.Graphics().p("EgOVAwOMAAAhgbIcrAAMAAABgbg");
	var mask_graphics_148 = new cjs.Graphics().p("EgPlAwOMAAAhgbIfLAAMAAABgbg");
	var mask_graphics_149 = new cjs.Graphics().p("EgQ0AwOMAAAhgbMAhpAAAMAAABgbg");
	var mask_graphics_150 = new cjs.Graphics().p("EgSEAwPMAAAhgdMAkJAAAMAAABgdg");
	var mask_graphics_151 = new cjs.Graphics().p("EgTTAwPMAAAhgdMAmnAAAMAAABgdg");
	var mask_graphics_152 = new cjs.Graphics().p("EgUjAwPMAAAhgdMApHAAAMAAABgdg");
	var mask_graphics_153 = new cjs.Graphics().p("EgVyAwQMAAAhgfMArlAAAMAAABgfg");
	var mask_graphics_154 = new cjs.Graphics().p("EgXBAwQMAAAhgfMAuDAAAMAAABgfg");
	var mask_graphics_155 = new cjs.Graphics().p("EgYRAwQMAAAhgfMAwjAAAMAAABgfg");
	var mask_graphics_156 = new cjs.Graphics().p("EgZgAwQMAAAhgfMAzBAAAMAAABgfg");
	var mask_graphics_157 = new cjs.Graphics().p("EgawAwRMAAAhghMA1hAAAMAAABghg");
	var mask_graphics_158 = new cjs.Graphics().p("Egb/AwRMAAAhghMA3/AAAMAAABghg");
	var mask_graphics_159 = new cjs.Graphics().p("EgdPAwRMAAAhghMA6fAAAMAAABghg");
	var mask_graphics_160 = new cjs.Graphics().p("EgeeAwSMAAAhgjMA89AAAMAAABgjg");
	var mask_graphics_161 = new cjs.Graphics().p("EgfuAwSMAAAhgjMA/dAAAMAAABgjg");
	var mask_graphics_162 = new cjs.Graphics().p("Egg9AwSMAAAhgjMBB7AAAMAAABgjg");
	var mask_graphics_163 = new cjs.Graphics().p("EgiMAwSMAAAhgjMBEZAAAMAAABgjg");
	var mask_graphics_164 = new cjs.Graphics().p("EgjcAwTMAAAhglMBG5AAAMAAABglg");
	var mask_graphics_165 = new cjs.Graphics().p("EgkrAwTMAAAhglMBJXAAAMAAABglg");
	var mask_graphics_166 = new cjs.Graphics().p("Egl7AwTMAAAhglMBL3AAAMAAABglg");
	var mask_graphics_167 = new cjs.Graphics().p("EgnKAwUMAAAhgnMBOVAAAMAAABgng");
	var mask_graphics_168 = new cjs.Graphics().p("EgoaAwUMAAAhgnMBQ1AAAMAAABgng");
	var mask_graphics_169 = new cjs.Graphics().p("EgppAwUMAAAhgnMBTTAAAMAAABgng");
	var mask_graphics_170 = new cjs.Graphics().p("Egq5AwUMAAAhgnMBVzAAAMAAABgng");
	var mask_graphics_171 = new cjs.Graphics().p("EgsIAwVMAAAhgpMBYRAAAMAAABgpg");
	var mask_graphics_172 = new cjs.Graphics().p("EgtXAwVMAAAhgpMBavAAAMAAABgpg");
	var mask_graphics_173 = new cjs.Graphics().p("EgunAwVMAAAhgpMBdPAAAMAAABgpg");
	var mask_graphics_174 = new cjs.Graphics().p("Egv2AwWMAAAhgrMBftAAAMAAABgrg");
	var mask_graphics_175 = new cjs.Graphics().p("EgxGAwWMAAAhgrMBiNAAAMAAABgrg");
	var mask_graphics_176 = new cjs.Graphics().p("EgyVAwWMAAAhgrMBkrAAAMAAABgrg");
	var mask_graphics_177 = new cjs.Graphics().p("EgzlAwWMAAAhgrMBnLAAAMAAABgrg");
	var mask_graphics_178 = new cjs.Graphics().p("Eg00AwXMAAAhgtMBppAAAMAAABgtg");
	var mask_graphics_179 = new cjs.Graphics().p("Eg2EAwXMAAAhgtMBsJAAAMAAABgtg");
	var mask_graphics_180 = new cjs.Graphics().p("Eg3TAwXMAAAhgtMBunAAAMAAABgtg");
	var mask_graphics_181 = new cjs.Graphics().p("Eg4iAwYMAAAhgvMBxFAAAMAAABgvg");
	var mask_graphics_182 = new cjs.Graphics().p("Eg5yAwYMAAAhgvMBzlAAAMAAABgvg");
	var mask_graphics_183 = new cjs.Graphics().p("Eg7BAwYMAAAhgvMB2DAAAMAAABgvg");
	var mask_graphics_184 = new cjs.Graphics().p("Eg8RAwYMAAAhgvMB4jAAAMAAABgvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(144).to({graphics:mask_graphics_144,x:-164.7,y:241.2}).wait(1).to({graphics:mask_graphics_145,x:-253.6,y:241.2}).wait(1).to({graphics:mask_graphics_146,x:-245.6,y:241.1}).wait(1).to({graphics:mask_graphics_147,x:-237.7,y:241.1}).wait(1).to({graphics:mask_graphics_148,x:-229.7,y:241.1}).wait(1).to({graphics:mask_graphics_149,x:-221.8,y:241.1}).wait(1).to({graphics:mask_graphics_150,x:-213.8,y:241}).wait(1).to({graphics:mask_graphics_151,x:-205.9,y:241}).wait(1).to({graphics:mask_graphics_152,x:-197.9,y:241}).wait(1).to({graphics:mask_graphics_153,x:-190,y:240.9}).wait(1).to({graphics:mask_graphics_154,x:-182.1,y:240.9}).wait(1).to({graphics:mask_graphics_155,x:-174.1,y:240.9}).wait(1).to({graphics:mask_graphics_156,x:-166.2,y:240.9}).wait(1).to({graphics:mask_graphics_157,x:-158.2,y:240.8}).wait(1).to({graphics:mask_graphics_158,x:-150.3,y:240.8}).wait(1).to({graphics:mask_graphics_159,x:-142.3,y:240.8}).wait(1).to({graphics:mask_graphics_160,x:-134.4,y:240.7}).wait(1).to({graphics:mask_graphics_161,x:-126.4,y:240.7}).wait(1).to({graphics:mask_graphics_162,x:-118.5,y:240.7}).wait(1).to({graphics:mask_graphics_163,x:-110.6,y:240.7}).wait(1).to({graphics:mask_graphics_164,x:-102.6,y:240.6}).wait(1).to({graphics:mask_graphics_165,x:-94.7,y:240.6}).wait(1).to({graphics:mask_graphics_166,x:-86.7,y:240.6}).wait(1).to({graphics:mask_graphics_167,x:-78.8,y:240.5}).wait(1).to({graphics:mask_graphics_168,x:-70.8,y:240.5}).wait(1).to({graphics:mask_graphics_169,x:-62.9,y:240.5}).wait(1).to({graphics:mask_graphics_170,x:-54.9,y:240.5}).wait(1).to({graphics:mask_graphics_171,x:-47,y:240.4}).wait(1).to({graphics:mask_graphics_172,x:-39.1,y:240.4}).wait(1).to({graphics:mask_graphics_173,x:-31.1,y:240.4}).wait(1).to({graphics:mask_graphics_174,x:-23.2,y:240.3}).wait(1).to({graphics:mask_graphics_175,x:-15.2,y:240.3}).wait(1).to({graphics:mask_graphics_176,x:-7.3,y:240.3}).wait(1).to({graphics:mask_graphics_177,x:0.6,y:240.3}).wait(1).to({graphics:mask_graphics_178,x:8.5,y:240.2}).wait(1).to({graphics:mask_graphics_179,x:16.5,y:240.2}).wait(1).to({graphics:mask_graphics_180,x:24.4,y:240.2}).wait(1).to({graphics:mask_graphics_181,x:32.3,y:240.1}).wait(1).to({graphics:mask_graphics_182,x:40.3,y:240.1}).wait(1).to({graphics:mask_graphics_183,x:48.2,y:240.1}).wait(1).to({graphics:mask_graphics_184,x:56.2,y:240}).wait(8));

	// Capa 5
	this.text = new cjs.Text("y = 2x² + 3", "italic bold 40px Verdana", "#00CE25");
	this.text.lineHeight = 42;
	this.text.setTransform(132.6,-17.2);

	this.text.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},144).wait(48));

	// GRAFICA 2
	this.instance = new lib.Path_32();
	this.instance.setTransform(-8.7,288.6,1,1,0,0,0,172.7,229.6);
	this.instance._off = true;

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(144).to({_off:false},0).wait(48));

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_73 = new cjs.Graphics().p("AqyCIIAAkPIVlAAIAAEPg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AqyDDIAAmFIVlAAIAAGFg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AqyD+IAAn7IVlAAIAAH7g");
	var mask_1_graphics_76 = new cjs.Graphics().p("AqyE6IAApzIVlAAIAAJzg");
	var mask_1_graphics_77 = new cjs.Graphics().p("AqyF1IAArpIVlAAIAALpg");
	var mask_1_graphics_78 = new cjs.Graphics().p("AqyGwIAAtfIVlAAIAANfg");
	var mask_1_graphics_79 = new cjs.Graphics().p("AqyHsIAAvXIVlAAIAAPXg");
	var mask_1_graphics_80 = new cjs.Graphics().p("AqyInIAAxNIVlAAIAARNg");
	var mask_1_graphics_81 = new cjs.Graphics().p("AqyJiIAAzDIVlAAIAATDg");
	var mask_1_graphics_82 = new cjs.Graphics().p("AqyKeIAA07IVlAAIAAU7g");
	var mask_1_graphics_83 = new cjs.Graphics().p("AqyLZIAA2xIVlAAIAAWxg");
	var mask_1_graphics_84 = new cjs.Graphics().p("AqyMUIAA4nIVlAAIAAYng");
	var mask_1_graphics_85 = new cjs.Graphics().p("AqyNQIAA6fIVlAAIAAafg");
	var mask_1_graphics_86 = new cjs.Graphics().p("AqyOLIAA8VIVlAAIAAcVg");
	var mask_1_graphics_87 = new cjs.Graphics().p("AqyPGIAA+LIVlAAIAAeLg");
	var mask_1_graphics_88 = new cjs.Graphics().p("AqyQCMAAAggDIVlAAMAAAAgDg");
	var mask_1_graphics_89 = new cjs.Graphics().p("AqyQ9MAAAgh5IVlAAMAAAAh5g");
	var mask_1_graphics_90 = new cjs.Graphics().p("AqyR4MAAAgjvIVlAAMAAAAjvg");
	var mask_1_graphics_91 = new cjs.Graphics().p("AqyS0MAAAglnIVlAAMAAAAlng");
	var mask_1_graphics_92 = new cjs.Graphics().p("AqyTvMAAAgndIVlAAMAAAAndg");
	var mask_1_graphics_93 = new cjs.Graphics().p("AqyUqMAAAgpTIVlAAMAAAApTg");
	var mask_1_graphics_94 = new cjs.Graphics().p("AqyVmMAAAgrLIVlAAMAAAArLg");
	var mask_1_graphics_95 = new cjs.Graphics().p("AqyWhMAAAgtBIVlAAMAAAAtBg");
	var mask_1_graphics_96 = new cjs.Graphics().p("AqyXcMAAAgu3IVlAAMAAAAu3g");
	var mask_1_graphics_97 = new cjs.Graphics().p("AqyYYMAAAgwvIVlAAMAAAAwvg");
	var mask_1_graphics_98 = new cjs.Graphics().p("AqyZTMAAAgylIVlAAMAAAAylg");
	var mask_1_graphics_99 = new cjs.Graphics().p("AqyaOMAAAg0bIVlAAMAAAA0bg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AqybKMAAAg2TIVlAAMAAAA2Tg");
	var mask_1_graphics_101 = new cjs.Graphics().p("AqycFMAAAg4JIVlAAMAAAA4Jg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AqydAMAAAg5/IVlAAMAAAA5/g");
	var mask_1_graphics_103 = new cjs.Graphics().p("Aqyd8MAAAg73IVlAAMAAAA73g");
	var mask_1_graphics_104 = new cjs.Graphics().p("Aqye3MAAAg9tIVlAAMAAAA9tg");
	var mask_1_graphics_105 = new cjs.Graphics().p("AqyfyMAAAg/jIVlAAMAAAA/jg");
	var mask_1_graphics_106 = new cjs.Graphics().p("EgKyAguMAAAhBbIVlAAMAAABBbg");
	var mask_1_graphics_107 = new cjs.Graphics().p("EgKyAhpMAAAhDRIVlAAMAAABDRg");
	var mask_1_graphics_108 = new cjs.Graphics().p("EgKyBJQMAAAhFKIVlAAMAAABFKg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(73).to({graphics:mask_1_graphics_73,x:-8.5,y:924}).wait(1).to({graphics:mask_1_graphics_74,x:-8.5,y:918}).wait(1).to({graphics:mask_1_graphics_75,x:-8.5,y:912.1}).wait(1).to({graphics:mask_1_graphics_76,x:-8.5,y:906.2}).wait(1).to({graphics:mask_1_graphics_77,x:-8.5,y:900.2}).wait(1).to({graphics:mask_1_graphics_78,x:-8.5,y:894.3}).wait(1).to({graphics:mask_1_graphics_79,x:-8.5,y:888.4}).wait(1).to({graphics:mask_1_graphics_80,x:-8.5,y:882.4}).wait(1).to({graphics:mask_1_graphics_81,x:-8.5,y:876.5}).wait(1).to({graphics:mask_1_graphics_82,x:-8.5,y:870.6}).wait(1).to({graphics:mask_1_graphics_83,x:-8.5,y:864.6}).wait(1).to({graphics:mask_1_graphics_84,x:-8.5,y:858.7}).wait(1).to({graphics:mask_1_graphics_85,x:-8.5,y:852.8}).wait(1).to({graphics:mask_1_graphics_86,x:-8.5,y:846.8}).wait(1).to({graphics:mask_1_graphics_87,x:-8.5,y:840.9}).wait(1).to({graphics:mask_1_graphics_88,x:-8.5,y:835}).wait(1).to({graphics:mask_1_graphics_89,x:-8.5,y:829}).wait(1).to({graphics:mask_1_graphics_90,x:-8.5,y:823.1}).wait(1).to({graphics:mask_1_graphics_91,x:-8.5,y:817.2}).wait(1).to({graphics:mask_1_graphics_92,x:-8.5,y:811.3}).wait(1).to({graphics:mask_1_graphics_93,x:-8.5,y:805.3}).wait(1).to({graphics:mask_1_graphics_94,x:-8.5,y:799.4}).wait(1).to({graphics:mask_1_graphics_95,x:-8.5,y:793.5}).wait(1).to({graphics:mask_1_graphics_96,x:-8.5,y:787.5}).wait(1).to({graphics:mask_1_graphics_97,x:-8.5,y:781.6}).wait(1).to({graphics:mask_1_graphics_98,x:-8.5,y:775.7}).wait(1).to({graphics:mask_1_graphics_99,x:-8.5,y:769.7}).wait(1).to({graphics:mask_1_graphics_100,x:-8.5,y:763.8}).wait(1).to({graphics:mask_1_graphics_101,x:-8.5,y:757.9}).wait(1).to({graphics:mask_1_graphics_102,x:-8.5,y:751.9}).wait(1).to({graphics:mask_1_graphics_103,x:-8.5,y:746}).wait(1).to({graphics:mask_1_graphics_104,x:-8.5,y:740.1}).wait(1).to({graphics:mask_1_graphics_105,x:-8.5,y:734.1}).wait(1).to({graphics:mask_1_graphics_106,x:-8.5,y:728.2}).wait(1).to({graphics:mask_1_graphics_107,x:-8.5,y:722.3}).wait(1).to({graphics:mask_1_graphics_108,x:-8.5,y:468.8}).wait(84));

	// FLECHA
	this.text_1 = new cjs.Text("+3", "bold 34px Verdana", "#FF0000");
	this.text_1.lineHeight = 38;
	this.text_1.lineWidth = 67;
	this.text_1.setTransform(-4.2,648.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhkCpIAfhMQAQgrANgrQAghnAIhIQAHBCAhBtQAOAsAVA2QAQAtAKATg");
	this.shape.setTransform(-8.2,536.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAbCMAAAg2D");
	this.shape_1.setTransform(-8.2,720);

	this.text_1.mask = this.shape.mask = this.shape_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text_1}]},73).wait(119));

	// GRAFICA 1
	this.text_2 = new cjs.Text("y = 2x²", "italic bold 40px Verdana", "#6C07D7");
	this.text_2.lineHeight = 42;
	this.text_2.setTransform(120.6,792.5);

	this.instance_1 = new lib.Path_33();
	this.instance_1.setTransform(-11.3,474.3,1,1,0,0,0,231.1,416.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.text_2}]}).wait(192));

	// EJE ORI
	this.text_3 = new cjs.Text("X", "40px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 62;
	this.text_3.setTransform(367.2,877.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_2.setTransform(-257.1,895.1);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-277.5,905.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_3.setTransform(-132.3,897);

	this.text_5 = new cjs.Text("–1", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-152.7,907.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_4.setTransform(240.8,899.7);

	this.text_6 = new cjs.Text("2", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(231.5,909.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_5.setTransform(117,897.6);

	this.text_7 = new cjs.Text("1", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(107.8,907.6);

	this.text_8 = new cjs.Text("0", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(2.8,899.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g3IAYgZIBPBQIhPBRg");
	this.shape_6.setTransform(334,890.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(4,0,0,4).p("Eg0mAAAMBpNAAA");
	this.shape_7.setTransform(-1.4,890.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.text_8},{t:this.text_7},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.text_5},{t:this.shape_3},{t:this.text_4},{t:this.shape_2},{t:this.text_3}]}).wait(192));

	// EJE VERTI
	this.text_9 = new cjs.Text("Y", "40px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 62;
	this.text_9.setTransform(-13.3,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_8.setTransform(-9.9,145.2);

	this.text_10 = new cjs.Text("6", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-38.5,129.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_9.setTransform(-12.3,515.5);

	this.text_11 = new cjs.Text("3", "20px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-38.5,501);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_10.setTransform(-12.1,269.9);

	this.text_12 = new cjs.Text("5", "20px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-39.5,256.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_11.setTransform(-12.3,393.7);

	this.text_13 = new cjs.Text("4", "20px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-39.7,379.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_12.setTransform(-13.3,643.9);

	this.text_14 = new cjs.Text("2", "20px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(-38.3,629.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_13.setTransform(-12.3,767.8);

	this.text_15 = new cjs.Text("1", "20px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(-36.1,753.3);

	this.text_16 = new cjs.Text("0", "20px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(-36.8,855);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_14.setTransform(-9.3,59.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABKDMAAAiUF");
	this.shape_15.setTransform(-9.3,533);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.text_16},{t:this.text_15},{t:this.shape_13},{t:this.text_14},{t:this.shape_12},{t:this.text_13},{t:this.shape_11},{t:this.text_12},{t:this.shape_10},{t:this.text_11},{t:this.shape_9},{t:this.text_10},{t:this.shape_8},{t:this.text_9}]}).wait(192));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-338.2,0,722.8,1007);


(lib.IMG_01 = function() {
	this.initialize();

	// GRAFICA 1
	this.instance = new lib.Path_33();
	this.instance.setTransform(-11.3,474.3,1,1,0,0,0,231.1,416.1);

	// FLECHA
	this.text = new cjs.Text("+3", "34px Verdana", "#FF0000");
	this.text.lineHeight = 41;
	this.text.setTransform(6,648.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AhkCpIAfhMQAQgrANgrQAghnAIhIQAHBCAhBtQAOAsAVA2QAQAtAKATg");
	this.shape.setTransform(-8.2,536.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4,0,0,4).p("AAAbCMAAAg2D");
	this.shape_1.setTransform(-8.2,720);

	// GRAFICA 2
	this.instance_1 = new lib.Path_32();
	this.instance_1.setTransform(-8.7,288.6,1,1,0,0,0,172.7,229.6);

	// EJE ORI
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_2.setTransform(-257.1,895.1);

	this.text_1 = new cjs.Text("–2", "20px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(-277.5,905.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_3.setTransform(-132.3,897);

	this.text_2 = new cjs.Text("–1", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-152.7,907.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_4.setTransform(240.8,899.7);

	this.text_3 = new cjs.Text("2", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(231.5,909.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_5.setTransform(117,897.6);

	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(107.8,907.6);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(2.8,899.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g3IAYgZIBPBQIhPBRg");
	this.shape_6.setTransform(334,890.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(4,0,0,4).p("Eg0mAAAMBpNAAA");
	this.shape_7.setTransform(-1.4,890.4);

	// EJE VERTI
	this.text_6 = new cjs.Text("X", "40px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 62;
	this.text_6.setTransform(374,877.9);

	this.text_7 = new cjs.Text("Y", "40px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 62;
	this.text_7.setTransform(-13.3,7.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_8.setTransform(-9.9,145.2);

	this.text_8 = new cjs.Text("6", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(-38.5,129.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_9.setTransform(-12.3,515.5);

	this.text_9 = new cjs.Text("3", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-38.5,501);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_10.setTransform(-12.1,269.9);

	this.text_10 = new cjs.Text("5", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-39.5,256.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_11.setTransform(-12.3,393.7);

	this.text_11 = new cjs.Text("4", "20px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-39.7,379.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_12.setTransform(-13.3,643.9);

	this.text_12 = new cjs.Text("2", "20px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-38.3,629.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_13.setTransform(-12.3,767.8);

	this.text_13 = new cjs.Text("1", "20px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-36.1,753.3);

	this.text_14 = new cjs.Text("0", "20px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(-36.8,855);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_14.setTransform(-9.3,59.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABKDMAAAiUF");
	this.shape_15.setTransform(-9.3,533);

	this.addChild(this.shape_15,this.shape_14,this.text_14,this.text_13,this.shape_13,this.text_12,this.shape_12,this.text_11,this.shape_11,this.text_10,this.shape_10,this.text_9,this.shape_9,this.text_8,this.shape_8,this.text_7,this.text_6,this.shape_7,this.shape_6,this.text_5,this.text_4,this.shape_5,this.text_3,this.shape_4,this.text_2,this.shape_3,this.text_1,this.shape_2,this.instance_1,this.shape_1,this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-338.2,7.6,729.7,999.4);
(lib.IMG_01b = function() {
	this.initialize();

	// GRAFICA 1
	this.instance = new lib.Path_33();
	this.instance.setTransform(-11.3,474.3,1,1,0,0,0,231.1,416.1);

	

	
	// EJE ORI
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_2.setTransform(-257.1,895.1);

	this.text_1 = new cjs.Text("–2", "20px Verdana");
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(-277.5,905.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_3.setTransform(-132.3,897);

	this.text_2 = new cjs.Text("–1", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-152.7,907.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_4.setTransform(240.8,899.7);

	this.text_3 = new cjs.Text("2", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(231.5,909.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_5.setTransform(117,897.6);

	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(107.8,907.6);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(2.8,899.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g3IAYgZIBPBQIhPBRg");
	this.shape_6.setTransform(334,890.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(4,0,0,4).p("Eg0mAAAMBpNAAA");
	this.shape_7.setTransform(-1.4,890.4);

	// EJE VERTI
	this.text_6 = new cjs.Text("X", "40px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 62;
	this.text_6.setTransform(374,877.9);

	this.text_7 = new cjs.Text("Y", "40px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 62;
	this.text_7.setTransform(-13.3,7.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_8.setTransform(-9.9,145.2);

	this.text_8 = new cjs.Text("6", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(-38.5,129.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_9.setTransform(-12.3,515.5);

	this.text_9 = new cjs.Text("3", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(-38.5,501);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_10.setTransform(-12.1,269.9);

	this.text_10 = new cjs.Text("5", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(-39.5,256.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_11.setTransform(-12.3,393.7);

	this.text_11 = new cjs.Text("4", "20px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-39.7,379.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_12.setTransform(-13.3,643.9);

	this.text_12 = new cjs.Text("2", "20px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-38.3,629.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_13.setTransform(-12.3,767.8);

	this.text_13 = new cjs.Text("1", "20px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-36.1,753.3);

	this.text_14 = new cjs.Text("0", "20px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(-36.8,855);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAAgCIgqApIgSgSIA8g7IA9A7IgTASg");
	this.shape_14.setTransform(-9.3,59.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABKDMAAAiUF");
	this.shape_15.setTransform(-9.3,533);

	this.addChild(this.shape_15,this.shape_14,this.text_14,this.text_13,this.shape_13,this.text_12,this.shape_12,this.text_11,this.shape_11,this.text_10,this.shape_10,this.text_9,this.shape_9,this.text_8,this.shape_8,this.text_7,this.text_6,this.shape_7,this.shape_6,this.text_5,this.text_4,this.shape_5,this.text_3,this.shape_4,this.text_2,this.shape_3,this.text_1,this.shape_2,this.instance_1,this.shape_1,this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-338.2,7.6,729.7,999.4);


(lib.IMG_00 = function() {
	this.initialize();

	// GRAFICA
	this.text = new cjs.Text("X", "40px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 62;
	this.text.setTransform(517.2,211.3);

	this.text_1 = new cjs.Text("Y", "40px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 62;
	this.text_1.setTransform(-0.9,-487.9);

	this.instance = new lib.Path();
	this.instance.setTransform(188.9,-108.6,1,1,0,0,0,255.1,330.8);

	this.instance_1 = new lib.Path_1();
	this.instance_1.setTransform(-1.4,-106.6,1,1,0,0,0,255.2,330.8);

	this.instance_2 = new lib.Path_2();
	this.instance_2.setTransform(-193.9,-108.1,1,1,0,0,0,255.2,330.8);

	// EJE ORI
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape.setTransform(-382.2,230);

	this.text_2 = new cjs.Text("–4", "20px Verdana");
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(-406.7,240.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_1.setTransform(-286.8,227.9);

	this.text_3 = new cjs.Text("–3", "20px Verdana");
	this.text_3.lineHeight = 36;
	this.text_3.setTransform(-307.1,238.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_2.setTransform(-192.3,228.6);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.lineHeight = 36;
	this.text_4.setTransform(-212.6,239.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_3.setTransform(-95.5,230);

	this.text_5 = new cjs.Text("–1", "20px Verdana");
	this.text_5.lineHeight = 36;
	this.text_5.setTransform(-115.8,240.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_4.setTransform(381.9,231.7);

	this.text_6 = new cjs.Text("4", "20px Verdana");
	this.text_6.lineHeight = 36;
	this.text_6.setTransform(373.5,241.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_5.setTransform(282.6,231.7);

	this.text_7 = new cjs.Text("3", "20px Verdana");
	this.text_7.lineHeight = 36;
	this.text_7.setTransform(273.4,241.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_6.setTransform(189.6,231.7);

	this.text_8 = new cjs.Text("2", "20px Verdana");
	this.text_8.lineHeight = 36;
	this.text_8.setTransform(180.4,241.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(3,0,0,4).p("AAAg6IAAB1");
	this.shape_7.setTransform(94.4,232.6);

	this.text_9 = new cjs.Text("1", "20px Verdana");
	this.text_9.lineHeight = 36;
	this.text_9.setTransform(85.1,242.6);

	this.text_10 = new cjs.Text("0", "20px Verdana");
	this.text_10.lineHeight = 36;
	this.text_10.setTransform(7.1,233.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgzA4IA3g4Ig3g4IAYgYIBPBQIhPBRg");
	this.shape_8.setTransform(473,223.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(4,0,0,4).p("EhKUAAAMCUpAAA");
	this.shape_9.setTransform(-1.4,223.8);

	// EJE VERTI
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_10.setTransform(-2.5,-349.8);

	this.text_11 = new cjs.Text("6", "20px Verdana");
	this.text_11.lineHeight = 36;
	this.text_11.setTransform(-31.1,-365.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_11.setTransform(-4.9,-63.5);

	this.text_12 = new cjs.Text("3", "20px Verdana");
	this.text_12.lineHeight = 36;
	this.text_12.setTransform(-31.1,-78);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_12.setTransform(-3.7,-253.1);

	this.text_13 = new cjs.Text("5", "20px Verdana");
	this.text_13.lineHeight = 36;
	this.text_13.setTransform(-31.1,-266.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_13.setTransform(-4.9,-157.3);

	this.text_14 = new cjs.Text("4", "20px Verdana");
	this.text_14.lineHeight = 36;
	this.text_14.setTransform(-32.3,-171.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_14.setTransform(-4.9,33.9);

	this.text_15 = new cjs.Text("2", "20px Verdana");
	this.text_15.lineHeight = 36;
	this.text_15.setTransform(-29.9,19.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(3,0,0,4).p("AA7AAIh1AA");
	this.shape_15.setTransform(-4.9,127.7);

	this.text_16 = new cjs.Text("1", "20px Verdana");
	this.text_16.lineHeight = 36;
	this.text_16.setTransform(-28.7,113.2);

	this.text_17 = new cjs.Text("0", "20px Verdana");
	this.text_17.lineHeight = 36;
	this.text_17.setTransform(-25.5,237);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAAgCIgpApIgSgSIA7g7IA8A7IgSASg");
	this.shape_16.setTransform(1,-433.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(3,0,0,4).p("EAAABEOMAAAiIb");
	this.shape_17.setTransform(1,2.3);

	this.addChild(this.shape_17,this.shape_16,this.text_17,this.text_16,this.shape_15,this.text_15,this.shape_14,this.text_14,this.shape_13,this.text_13,this.shape_12,this.text_12,this.shape_11,this.text_11,this.shape_10,this.shape_9,this.shape_8,this.text_10,this.text_9,this.shape_7,this.text_8,this.shape_6,this.text_7,this.shape_5,this.text_6,this.shape_4,this.text_5,this.shape_3,this.text_4,this.shape_2,this.text_3,this.shape_1,this.text_2,this.shape,this.instance_2,this.instance_1,this.instance,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-477.2,-487.9,1011.9,926.9);

    (lib.boton_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("y = a(x + p)² + q", "italic bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 192;
        this.text.setTransform(97.1, 5.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.text, p: {color: "#FFFFFF"}}]}, 2).to({state: []}, 1).wait(1));

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_1.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_2.setTransform(98.6, 18, 1.516, 1.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(2));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 197.1, 36);


    (lib.boton_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text("y = a(x + p)²", "italic bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 189;
        this.text.setTransform(96.4, 5.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.text, p: {color: "#FFFFFF"}}]}, 2).to({state: []}, 1).wait(1));

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_1.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_2.setTransform(98.6, 18, 1.516, 1.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(2));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 197.1, 36);


    (lib.boton_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.text = new cjs.Text("y = ax² + q", "italic bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 188;
        this.text.setTransform(96.1, 5.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.text, p: {color: "#FFFFFF"}}]}, 2).to({state: []}, 1).wait(1));

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_1.setTransform(98.6, 18, 1.516, 1.2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#000000").ss(1.3, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_2.setTransform(98.6, 18, 1.516, 1.2);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(2));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 197.1, 36);


 

(lib.tabla_02_MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 9 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("AmEBKIAAiUIMKAAIAACUg");
	var mask_graphics_22 = new cjs.Graphics().p("AmECLIAAkVIMKAAIAAEVg");
	var mask_graphics_23 = new cjs.Graphics().p("AmEDMIAAmXIMKAAIAAGXg");
	var mask_graphics_24 = new cjs.Graphics().p("AmEEMIAAoXIMKAAIAAIXg");
	var mask_graphics_25 = new cjs.Graphics().p("AmEFMIAAqYIMKAAIAAKYg");
	var mask_graphics_26 = new cjs.Graphics().p("AmEGNIAAsZIMKAAIAAMZg");
	var mask_graphics_27 = new cjs.Graphics().p("AmEHNIAAuaIMKAAIAAOag");
	var mask_graphics_28 = new cjs.Graphics().p("AmEIOIAAwbIMKAAIAAQbg");
	var mask_graphics_29 = new cjs.Graphics().p("AmEJPIAAydIMKAAIAASdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmEKPIAA0dIMKAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmELPIAA2eIMKAAIAAWeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:29,y:-15.4}).wait(1).to({graphics:mask_graphics_22,x:29,y:-9}).wait(1).to({graphics:mask_graphics_23,x:29,y:-2.5}).wait(1).to({graphics:mask_graphics_24,x:29,y:3.9}).wait(1).to({graphics:mask_graphics_25,x:29,y:10.3}).wait(1).to({graphics:mask_graphics_26,x:29,y:16.8}).wait(1).to({graphics:mask_graphics_27,x:29,y:23.2}).wait(1).to({graphics:mask_graphics_28,x:29,y:29.7}).wait(1).to({graphics:mask_graphics_29,x:29,y:36.1}).wait(1).to({graphics:mask_graphics_30,x:29,y:42.6}).wait(1).to({graphics:mask_graphics_31,x:29,y:49}).wait(1).to({graphics:null,x:0,y:0}).wait(79));

	// Capa 6
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 50;
	this.text.setTransform(31,62.9);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 50;
	this.text_1.setTransform(31,12.9);

	this.text.mask = this.text_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},21).wait(90));

	// Capa 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_32 = new cjs.Graphics().p("Ak5AsIAAhYIJzAAIAABYg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ak5B2IAAjrIJzAAIAADrg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Ak5C/IAAl9IJzAAIAAF9g");
	var mask_1_graphics_35 = new cjs.Graphics().p("Ak5EIIAAoPIJzAAIAAIPg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Ak5FRIAAqhIJzAAIAAKhg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ak5GaIAAszIJzAAIAAMzg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ak5HjIAAvFIJzAAIAAPFg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Ak5IsIAAxXIJzAAIAARXg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AAZJ1IAAzqIJ1AAIAATqg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(32).to({graphics:mask_1_graphics_32,x:99.5,y:-10.4}).wait(1).to({graphics:mask_1_graphics_33,x:99.5,y:-3.1}).wait(1).to({graphics:mask_1_graphics_34,x:99.5,y:4.1}).wait(1).to({graphics:mask_1_graphics_35,x:99.5,y:11.4}).wait(1).to({graphics:mask_1_graphics_36,x:99.5,y:18.8}).wait(1).to({graphics:mask_1_graphics_37,x:99.5,y:26.1}).wait(1).to({graphics:mask_1_graphics_38,x:99.5,y:33.4}).wait(1).to({graphics:mask_1_graphics_39,x:99.5,y:40.7}).wait(1).to({graphics:mask_1_graphics_40,x:65.5,y:48}).wait(1).to({graphics:null,x:0,y:0}).wait(70));

	// Capa 5
	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 50;
	this.text_2.setTransform(97,66.9);

	this.text_3 = new cjs.Text("–1", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,12.9);

	this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_3},{t:this.text_2}]},32).wait(79));

	// Capa 11 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_43 = new cjs.Graphics().p("AkrAnIAAhNIJWAAIAABNg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AkrBpIAAjRIJWAAIAADRg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AkrCrIAAlVIJWAAIAAFVg");
	var mask_2_graphics_46 = new cjs.Graphics().p("AkrDsIAAnXIJWAAIAAHXg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AkrEuIAApbIJWAAIAAJbg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AkrFwIAArfIJWAAIAALfg");
	var mask_2_graphics_49 = new cjs.Graphics().p("AkrGxIAAthIJWAAIAANhg");
	var mask_2_graphics_50 = new cjs.Graphics().p("AkrHzIAAvlIJWAAIAAPlg");
	var mask_2_graphics_51 = new cjs.Graphics().p("AF2I1IAAxpIJYAAIAARpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(43).to({graphics:mask_2_graphics_43,x:165,y:-8.9}).wait(1).to({graphics:mask_2_graphics_44,x:165,y:-2.3}).wait(1).to({graphics:mask_2_graphics_45,x:165,y:4.1}).wait(1).to({graphics:mask_2_graphics_46,x:165,y:10.7}).wait(1).to({graphics:mask_2_graphics_47,x:165,y:17.3}).wait(1).to({graphics:mask_2_graphics_48,x:165,y:23.8}).wait(1).to({graphics:mask_2_graphics_49,x:165,y:30.4}).wait(1).to({graphics:mask_2_graphics_50,x:165,y:37}).wait(1).to({graphics:mask_2_graphics_51,x:97.5,y:43.5}).wait(60));

	// Capa 4
	this.text_4 = new cjs.Text("1", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,66.9);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(163,12.9);

	this.text_4.mask = this.text_5.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_5},{t:this.text_4}]},43).wait(68));

	// Capa 12 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_54 = new cjs.Graphics().p("AlHA3IAAhsIKPAAIAABsg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AlHCDIAAkFIKPAAIAAEFg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AlHDPIAAmdIKPAAIAAGdg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AlHEcIAAo3IKPAAIAAI3g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AlHFoIAArPIKPAAIAALPg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AlHG1IAAtpIKPAAIAANpg");
	var mask_3_graphics_60 = new cjs.Graphics().p("AlHIBIAAwBIKPAAIAAQBg");
	var mask_3_graphics_61 = new cjs.Graphics().p("AKaJOIAAyaIKRAAIAASag");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_3_graphics_54,x:231.8,y:-5.4}).wait(1).to({graphics:mask_3_graphics_55,x:231.8,y:2.1}).wait(1).to({graphics:mask_3_graphics_56,x:231.8,y:9.8}).wait(1).to({graphics:mask_3_graphics_57,x:231.8,y:17.4}).wait(1).to({graphics:mask_3_graphics_58,x:231.8,y:25.1}).wait(1).to({graphics:mask_3_graphics_59,x:231.8,y:32.7}).wait(1).to({graphics:mask_3_graphics_60,x:231.8,y:40.4}).wait(1).to({graphics:mask_3_graphics_61,x:132.3,y:48}).wait(50));

	// Capa 3
	this.text_6 = new cjs.Text("1", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(229,66.9);

	this.text_7 = new cjs.Text("–2", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(229,12.9);

	this.text_6.mask = this.text_7.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_7},{t:this.text_6}]},54).wait(57));

	// Capa 13 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_64 = new cjs.Graphics().p("Ak+A8IAAh3IJ+AAIAAB3g");
	var mask_4_graphics_65 = new cjs.Graphics().p("Ak+CQIAAkfIJ+AAIAAEfg");
	var mask_4_graphics_66 = new cjs.Graphics().p("Ak+DkIAAnHIJ+AAIAAHHg");
	var mask_4_graphics_67 = new cjs.Graphics().p("Ak+E4IAApvIJ+AAIAAJvg");
	var mask_4_graphics_68 = new cjs.Graphics().p("Ak+GNIAAsZIJ+AAIAAMZg");
	var mask_4_graphics_69 = new cjs.Graphics().p("Ak+HhIAAvBIJ+AAIAAPBg");
	var mask_4_graphics_70 = new cjs.Graphics().p("Ak+I1IAAxpIJ+AAIAARpg");
	var mask_4_graphics_71 = new cjs.Graphics().p("APdKJIAA0RIKAAAIAAURg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(64).to({graphics:mask_4_graphics_64,x:294,y:-9.9}).wait(1).to({graphics:mask_4_graphics_65,x:294,y:-1.5}).wait(1).to({graphics:mask_4_graphics_66,x:294,y:6.9}).wait(1).to({graphics:mask_4_graphics_67,x:294,y:15.3}).wait(1).to({graphics:mask_4_graphics_68,x:294,y:23.7}).wait(1).to({graphics:mask_4_graphics_69,x:294,y:32.1}).wait(1).to({graphics:mask_4_graphics_70,x:294,y:40.6}).wait(1).to({graphics:mask_4_graphics_71,x:163,y:49}).wait(40));

	// Capa 2
	this.text_8 = new cjs.Text("4", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(296,66.9);

	this.text_9 = new cjs.Text("1", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(296,12.9);

	this.text_8.mask = this.text_9.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_9},{t:this.text_8}]},64).wait(47));

	// Capa 14 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_75 = new cjs.Graphics().p("AkYA1IAAhpIIxAAIAABpg");
	var mask_5_graphics_76 = new cjs.Graphics().p("AkYCNIAAkZIIxAAIAAEZg");
	var mask_5_graphics_77 = new cjs.Graphics().p("AkYDmIAAnLIIxAAIAAHLg");
	var mask_5_graphics_78 = new cjs.Graphics().p("AkYE/IAAp9IIxAAIAAJ9g");
	var mask_5_graphics_79 = new cjs.Graphics().p("AkYGXIAAstIIxAAIAAMtg");
	var mask_5_graphics_80 = new cjs.Graphics().p("AkYHwIAAvfIIxAAIAAPfg");
	var mask_5_graphics_81 = new cjs.Graphics().p("AVrJJIAAyQII0AAIAASQg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(75).to({graphics:mask_5_graphics_75,x:362.2,y:-4.6}).wait(1).to({graphics:mask_5_graphics_76,x:362.2,y:4.2}).wait(1).to({graphics:mask_5_graphics_77,x:362.2,y:13.1}).wait(1).to({graphics:mask_5_graphics_78,x:362.2,y:21.9}).wait(1).to({graphics:mask_5_graphics_79,x:362.2,y:30.8}).wait(1).to({graphics:mask_5_graphics_80,x:362.2,y:39.6}).wait(1).to({graphics:mask_5_graphics_81,x:195.2,y:48.5}).wait(30));

	// Capa 7
	this.text_10 = new cjs.Text("4", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(361,66.9);

	this.text_11 = new cjs.Text("–3", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(361,12.9);

	this.text_10.mask = this.text_11.mask = mask_5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_11},{t:this.text_10}]},75).wait(36));

	// Capa 8 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_0 = new cjs.Graphics().p("Aj0K8IAA13IHpAAIAAV3g");
	var mask_6_graphics_1 = new cjs.Graphics().p("AlZK8IAA13IKzAAIAAV3g");
	var mask_6_graphics_2 = new cjs.Graphics().p("Am/K8IAA13IN/AAIAAV3g");
	var mask_6_graphics_3 = new cjs.Graphics().p("AokK8IAA13IRJAAIAAV3g");
	var mask_6_graphics_4 = new cjs.Graphics().p("AqKK8IAA13IUVAAIAAV3g");
	var mask_6_graphics_5 = new cjs.Graphics().p("ArwK8IAA13IXhAAIAAV3g");
	var mask_6_graphics_6 = new cjs.Graphics().p("AtVK8IAA13IarAAIAAV3g");
	var mask_6_graphics_7 = new cjs.Graphics().p("Au7K8IAA13Id3AAIAAV3g");
	var mask_6_graphics_8 = new cjs.Graphics().p("AwhK8IAA13MAhDAAAIAAV3g");
	var mask_6_graphics_9 = new cjs.Graphics().p("AyGK8IAA13MAkNAAAIAAV3g");
	var mask_6_graphics_10 = new cjs.Graphics().p("AzsK8IAA13MAnZAAAIAAV3g");
	var mask_6_graphics_11 = new cjs.Graphics().p("A1SK8IAA13MAqlAAAIAAV3g");
	var mask_6_graphics_12 = new cjs.Graphics().p("A23K8IAA13MAtvAAAIAAV3g");
	var mask_6_graphics_13 = new cjs.Graphics().p("A4dK8IAA13MAw7AAAIAAV3g");
	var mask_6_graphics_14 = new cjs.Graphics().p("A6DK8IAA13MA0HAAAIAAV3g");
	var mask_6_graphics_15 = new cjs.Graphics().p("A7oK8IAA13MA3RAAAIAAV3g");
	var mask_6_graphics_16 = new cjs.Graphics().p("A9OK8IAA13MA6dAAAIAAV3g");
	var mask_6_graphics_17 = new cjs.Graphics().p("A+0K8IAA13MA9pAAAIAAV3g");
	var mask_6_graphics_18 = new cjs.Graphics().p("EggZAK8IAA13MBAzAAAIAAV3g");
	var mask_6_graphics_19 = new cjs.Graphics().p("Egh/AK8IAA13MBD/AAAIAAV3g");
	var mask_6_graphics_20 = new cjs.Graphics().p("EgjlAK8IAA13MBHLAAAIAAV3g");
	var mask_6_graphics_21 = new cjs.Graphics().p("EglKAK8IAA13MBKVAAAIAAV3g");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:mask_6_graphics_0,x:-37.4,y:47}).wait(1).to({graphics:mask_6_graphics_1,x:-27.2,y:47}).wait(1).to({graphics:mask_6_graphics_2,x:-17.1,y:47}).wait(1).to({graphics:mask_6_graphics_3,x:-6.9,y:47}).wait(1).to({graphics:mask_6_graphics_4,x:3.2,y:47}).wait(1).to({graphics:mask_6_graphics_5,x:13.3,y:47}).wait(1).to({graphics:mask_6_graphics_6,x:23.5,y:47}).wait(1).to({graphics:mask_6_graphics_7,x:33.7,y:47}).wait(1).to({graphics:mask_6_graphics_8,x:43.8,y:47}).wait(1).to({graphics:mask_6_graphics_9,x:54,y:47}).wait(1).to({graphics:mask_6_graphics_10,x:64.2,y:47}).wait(1).to({graphics:mask_6_graphics_11,x:74.3,y:47}).wait(1).to({graphics:mask_6_graphics_12,x:84.5,y:47}).wait(1).to({graphics:mask_6_graphics_13,x:94.7,y:47}).wait(1).to({graphics:mask_6_graphics_14,x:104.8,y:47}).wait(1).to({graphics:mask_6_graphics_15,x:115,y:47}).wait(1).to({graphics:mask_6_graphics_16,x:125.1,y:47}).wait(1).to({graphics:mask_6_graphics_17,x:135.3,y:47}).wait(1).to({graphics:mask_6_graphics_18,x:145.5,y:47}).wait(1).to({graphics:mask_6_graphics_19,x:155.6,y:47}).wait(1).to({graphics:mask_6_graphics_20,x:165.8,y:47}).wait(1).to({graphics:mask_6_graphics_21,x:176,y:47}).wait(90));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape.setTransform(330.8,53.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(264.6,53.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(198.5,53.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(132.3,53.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(66.2,53.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_5.setTransform(198,53.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_6.setTransform(198,53.5);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = mask_6;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,396,107);

(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4,741);


(lib.tabla_01_MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 16 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Au+QeMAAAgg7ILPAAMAAAAg7g");
	var mask_graphics_1 = new cjs.Graphics().p("Am0QeMAAAgg7INpAAMAAAAg7g");
	var mask_graphics_2 = new cjs.Graphics().p("AoCQeMAAAgg7IQFAAMAAAAg7g");
	var mask_graphics_3 = new cjs.Graphics().p("ApQQeMAAAgg7IShAAMAAAAg7g");
	var mask_graphics_4 = new cjs.Graphics().p("AqdQeMAAAgg7IU7AAMAAAAg7g");
	var mask_graphics_5 = new cjs.Graphics().p("ArrQeMAAAgg7IXXAAMAAAAg7g");
	var mask_graphics_6 = new cjs.Graphics().p("As5QeMAAAgg7IZzAAMAAAAg7g");
	var mask_graphics_7 = new cjs.Graphics().p("AuHQeMAAAgg7IcPAAMAAAAg7g");
	var mask_graphics_8 = new cjs.Graphics().p("AvVQeMAAAgg7IerAAMAAAAg7g");
	var mask_graphics_9 = new cjs.Graphics().p("AwiQeMAAAgg7MAhFAAAMAAAAg7g");
	var mask_graphics_10 = new cjs.Graphics().p("AxwQeMAAAgg7MAjhAAAMAAAAg7g");
	var mask_graphics_11 = new cjs.Graphics().p("Ay+QeMAAAgg7MAl9AAAMAAAAg7g");
	var mask_graphics_12 = new cjs.Graphics().p("A0MQeMAAAgg7MAoZAAAMAAAAg7g");
	var mask_graphics_13 = new cjs.Graphics().p("A1ZQeMAAAgg7MAqzAAAMAAAAg7g");
	var mask_graphics_14 = new cjs.Graphics().p("A2nQeMAAAgg7MAtPAAAMAAAAg7g");
	var mask_graphics_15 = new cjs.Graphics().p("A31QeMAAAgg7MAvrAAAMAAAAg7g");
	var mask_graphics_16 = new cjs.Graphics().p("A5DQeMAAAgg7MAyHAAAMAAAAg7g");
	var mask_graphics_17 = new cjs.Graphics().p("A6RQeMAAAgg7MA0jAAAMAAAAg7g");
	var mask_graphics_18 = new cjs.Graphics().p("A7eQeMAAAgg7MA29AAAMAAAAg7g");
	var mask_graphics_19 = new cjs.Graphics().p("A8sQeMAAAgg7MA5ZAAAMAAAAg7g");
	var mask_graphics_20 = new cjs.Graphics().p("A96QeMAAAgg7MA71AAAMAAAAg7g");
	var mask_graphics_21 = new cjs.Graphics().p("A/IQeMAAAgg7MA+RAAAMAAAAg7g");
	var mask_graphics_22 = new cjs.Graphics().p("EggWAQeMAAAgg7MBAtAAAMAAAAg7g");
	var mask_graphics_23 = new cjs.Graphics().p("EghjAQeMAAAgg7MBDHAAAMAAAAg7g");
	var mask_graphics_24 = new cjs.Graphics().p("EgixAQeMAAAgg7MBFjAAAMAAAAg7g");
	var mask_graphics_25 = new cjs.Graphics().p("Egj/AQeMAAAgg7MBH/AAAMAAAAg7g");
	var mask_graphics_26 = new cjs.Graphics().p("EglNAQeMAAAgg7MBKbAAAMAAAAg7g");
	var mask_graphics_27 = new cjs.Graphics().p("EgmaAQeMAAAgg7MBM1AAAMAAAAg7g");
	var mask_graphics_28 = new cjs.Graphics().p("EgnoAQeMAAAgg7MBPRAAAMAAAAg7g");
	var mask_graphics_29 = new cjs.Graphics().p("Ego2AQeMAAAgg7MBRtAAAMAAAAg7g");
	var mask_graphics_30 = new cjs.Graphics().p("EgqEAQeMAAAgg7MBUJAAAMAAAAg7g");
	var mask_graphics_31 = new cjs.Graphics().p("EgrSAQeMAAAgg7MBWlAAAMAAAAg7g");
	var mask_graphics_32 = new cjs.Graphics().p("EgsfAQeMAAAgg7MBY/AAAMAAAAg7g");
	var mask_graphics_33 = new cjs.Graphics().p("EgttAQeMAAAgg7MBbbAAAMAAAAg7g");
	var mask_graphics_34 = new cjs.Graphics().p("Egu7AQeMAAAgg7MBd3AAAMAAAAg7g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-95.9,y:24.5}).wait(1).to({graphics:mask_graphics_1,x:-148.1,y:24.5}).wait(1).to({graphics:mask_graphics_2,x:-140.3,y:24.5}).wait(1).to({graphics:mask_graphics_3,x:-132.5,y:24.5}).wait(1).to({graphics:mask_graphics_4,x:-124.8,y:24.5}).wait(1).to({graphics:mask_graphics_5,x:-117,y:24.5}).wait(1).to({graphics:mask_graphics_6,x:-109.2,y:24.5}).wait(1).to({graphics:mask_graphics_7,x:-101.4,y:24.5}).wait(1).to({graphics:mask_graphics_8,x:-93.6,y:24.5}).wait(1).to({graphics:mask_graphics_9,x:-85.9,y:24.5}).wait(1).to({graphics:mask_graphics_10,x:-78.1,y:24.5}).wait(1).to({graphics:mask_graphics_11,x:-70.3,y:24.5}).wait(1).to({graphics:mask_graphics_12,x:-62.5,y:24.5}).wait(1).to({graphics:mask_graphics_13,x:-54.8,y:24.5}).wait(1).to({graphics:mask_graphics_14,x:-47,y:24.5}).wait(1).to({graphics:mask_graphics_15,x:-39.2,y:24.5}).wait(1).to({graphics:mask_graphics_16,x:-31.4,y:24.5}).wait(1).to({graphics:mask_graphics_17,x:-23.6,y:24.5}).wait(1).to({graphics:mask_graphics_18,x:-15.9,y:24.5}).wait(1).to({graphics:mask_graphics_19,x:-8.1,y:24.5}).wait(1).to({graphics:mask_graphics_20,x:-0.3,y:24.5}).wait(1).to({graphics:mask_graphics_21,x:7.4,y:24.5}).wait(1).to({graphics:mask_graphics_22,x:15.2,y:24.5}).wait(1).to({graphics:mask_graphics_23,x:22.9,y:24.5}).wait(1).to({graphics:mask_graphics_24,x:30.7,y:24.5}).wait(1).to({graphics:mask_graphics_25,x:38.5,y:24.5}).wait(1).to({graphics:mask_graphics_26,x:46.3,y:24.5}).wait(1).to({graphics:mask_graphics_27,x:54,y:24.5}).wait(1).to({graphics:mask_graphics_28,x:61.8,y:24.5}).wait(1).to({graphics:mask_graphics_29,x:69.6,y:24.5}).wait(1).to({graphics:mask_graphics_30,x:77.4,y:24.5}).wait(1).to({graphics:mask_graphics_31,x:85.2,y:24.5}).wait(1).to({graphics:mask_graphics_32,x:92.9,y:24.5}).wait(1).to({graphics:mask_graphics_33,x:100.7,y:24.5}).wait(1).to({graphics:mask_graphics_34,x:108.5,y:24.5}).wait(77));

	// Capa 6
	this.text = new cjs.Text("y = 2x² + 3", "italic bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 143;
	this.text.setTransform(-86.9,65.9);

	this.text_1 = new cjs.Text("y = 2x²", "italic bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 143;
	this.text_1.setTransform(-86.9,15.9);

	this.text_2 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 143;
	this.text_2.setTransform(-86.9,-34);

	this.text.mask = this.text_1.mask = this.text_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(111));

	// Capa 5
	this.text_3 = new cjs.Text("3", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 50;
	this.text_3.setTransform(97,66.9);

	this.text_4 = new cjs.Text("5", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 50;
	this.text_4.setTransform(163,66.9);

	this.text_5 = new cjs.Text("5", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 50;
	this.text_5.setTransform(229,66.9);

	this.text_6 = new cjs.Text("11", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 50;
	this.text_6.setTransform(296,66.9);

	this.text_7 = new cjs.Text("11", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 50;
	this.text_7.setTransform(361,66.9);

	this.text_8 = new cjs.Text("0", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 50;
	this.text_8.setTransform(97,16.9);

	this.text_9 = new cjs.Text("0", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(97,-37);

	this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3}]}).wait(111));

	// Capa 4
	this.text_10 = new cjs.Text("2", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 50;
	this.text_10.setTransform(163,16.9);

	this.text_11 = new cjs.Text("1", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 50;
	this.text_11.setTransform(163,-37);

	this.text_10.mask = this.text_11.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_11},{t:this.text_10}]}).wait(111));

	// Capa 3
	this.text_12 = new cjs.Text("2", "20px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 22;
	this.text_12.lineWidth = 50;
	this.text_12.setTransform(229,16.9);

	this.text_13 = new cjs.Text("–1", "20px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 22;
	this.text_13.lineWidth = 50;
	this.text_13.setTransform(229,-37);

	this.text_12.mask = this.text_13.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_13},{t:this.text_12}]}).wait(111));

	// Capa 2
	this.text_14 = new cjs.Text("8", "20px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 22;
	this.text_14.lineWidth = 50;
	this.text_14.setTransform(296,16.9);

	this.text_15 = new cjs.Text("2", "20px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 22;
	this.text_15.lineWidth = 50;
	this.text_15.setTransform(296,-37);

	this.text_14.mask = this.text_15.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_15},{t:this.text_14}]}).wait(111));

	// Capa 7
	this.text_16 = new cjs.Text("8", "20px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 22;
	this.text_16.lineWidth = 50;
	this.text_16.setTransform(361,16.9);

	this.text_17 = new cjs.Text("–2", "20px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 22;
	this.text_17.lineWidth = 50;
	this.text_17.setTransform(361,-37);

	this.text_16.mask = this.text_17.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_17},{t:this.text_16}]}).wait(111));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape.setTransform(144.5,3.5,1.27,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_1.setTransform(330.8,30.6,1,1.428);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_2.setTransform(264.6,30.6,1,1.428);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_3.setTransform(198.5,30.6,1,1.428);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_4.setTransform(132.3,30.6,1,1.428);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AAAoWIAAQt");
	this.shape_5.setTransform(66.2,30.6,1,1.428);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("A+6AAMA91AAA");
	this.shape_6.setTransform(144.5,53.5,1.27,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("AdXoWMg6tAAAQhkAAAABkIAANlQAABkBkAAMA6tAAAQBkAAAAhkIAAtlQAAhkhkAAg");
	this.shape_7.setTransform(144.5,30.5,1.27,1.426);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-106.8,-45.7,502.7,152.6);



(lib.flechas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A3aAeIAAjQMAu1AAAIAADQg");
	var mask_graphics_1 = new cjs.Graphics().p("A3aCBIAAkBMAu1AAAIAAEBg");
	var mask_graphics_2 = new cjs.Graphics().p("A3aCaIAAkzMAu1AAAIAAEzg");
	var mask_graphics_3 = new cjs.Graphics().p("A3aCyIAAljMAu1AAAIAAFjg");
	var mask_graphics_4 = new cjs.Graphics().p("A3aDLIAAmVMAu1AAAIAAGVg");
	var mask_graphics_5 = new cjs.Graphics().p("A3aDkIAAnHMAu1AAAIAAHHg");
	var mask_graphics_6 = new cjs.Graphics().p("A3aD8IAAn3MAu1AAAIAAH3g");
	var mask_graphics_7 = new cjs.Graphics().p("A3aEVIAAopMAu1AAAIAAIpg");
	var mask_graphics_8 = new cjs.Graphics().p("A3aEuIAApaMAu1AAAIAAJag");
	var mask_graphics_9 = new cjs.Graphics().p("A3aFGIAAqLMAu1AAAIAAKLg");
	var mask_graphics_10 = new cjs.Graphics().p("A3aFfIAAq9MAu1AAAIAAK9g");
	var mask_graphics_11 = new cjs.Graphics().p("A3aF3IAArtMAu1AAAIAALtg");
	var mask_graphics_12 = new cjs.Graphics().p("A3aGQIAAsfMAu1AAAIAAMfg");
	var mask_graphics_13 = new cjs.Graphics().p("A3aGpIAAtRMAu1AAAIAANRg");
	var mask_graphics_14 = new cjs.Graphics().p("A3aHBIAAuBMAu1AAAIAAOBg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:130.1,y:-17.8}).wait(1).to({graphics:mask_graphics_1,x:130.1,y:-22.8}).wait(1).to({graphics:mask_graphics_2,x:130.1,y:-20.3}).wait(1).to({graphics:mask_graphics_3,x:130.1,y:-17.9}).wait(1).to({graphics:mask_graphics_4,x:130.1,y:-15.4}).wait(1).to({graphics:mask_graphics_5,x:130.1,y:-12.9}).wait(1).to({graphics:mask_graphics_6,x:130.1,y:-10.5}).wait(1).to({graphics:mask_graphics_7,x:130.1,y:-8}).wait(1).to({graphics:mask_graphics_8,x:130.1,y:-5.6}).wait(1).to({graphics:mask_graphics_9,x:130.1,y:-3.1}).wait(1).to({graphics:mask_graphics_10,x:130.1,y:-0.6}).wait(1).to({graphics:mask_graphics_11,x:130.1,y:1.7}).wait(1).to({graphics:mask_graphics_12,x:130.1,y:4.2}).wait(1).to({graphics:mask_graphics_13,x:130.1,y:6.7}).wait(1).to({graphics:mask_graphics_14,x:130.1,y:9.1}).wait(26));

	// Capa 1
	this.text = new cjs.Text("+3", "20px Verdana", "#CC0000");
	this.text.lineHeight = 22;
	this.text.lineWidth = 35;
	this.text.setTransform(243.1,4);

	this.text_1 = new cjs.Text("+3", "20px Verdana", "#CC0000");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 35;
	this.text_1.setTransform(243.1,4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CC0000").ss(5,1,1).p("AhFBzIBFBlIACgEIAAmvABGBzIhEBhIAAAIIgCgEIgBAE");
	this.shape.setTransform(233.1,22.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CC0000").ss(5,1,1).p("AhFBzIBFBlIACgEIAAmvABGBzIhEBhIAAAIIgCgEIgBAE");
	this.shape_1.setTransform(176.1,22.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#CC0000").ss(5,1,1).p("AhFBzIBFBlIACgEIAAmvABGBzIhEBhIAAAIIgCgEIgBAE");
	this.shape_2.setTransform(120.1,22.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#CC0000").ss(5,1,1).p("AhFBzIBFBlIACgEIAAmvABGBzIhEBhIAAAIIgCgEIgBAE");
	this.shape_3.setTransform(67.1,22.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#CC0000").ss(5,1,1).p("AhFBzIBFBlIACgEIAAmvABGBzIhEBhIAAAIIgCgEIgBAE");
	this.shape_4.setTransform(7.1,22.1);

	this.text.mask = this.text_1.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_1},{t:this.text}]}).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,282.1,44.1);


(lib.Path_2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(5,0,0,4).p("EgnegzvQC9N6CZKnQEiUCETOeUANEAsKAMmAAAQG7AAHKtrQF4rOF40FQEZu9EOzZQBrnoDAvR");
	this.shape.setTransform(255.2,331.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,505.4,660.5);


(lib.Path_1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(5,0,0,4).p("EgnegzvQC9N6CZKnQEiUCETOfUANEAsJAMmAAAQG7AAHKtrQF4rNF40GQEZu9EOzZQBqnlDBvU");
	this.shape.setTransform(255.2,331.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,505.4,660.5);


(lib.Path = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0039FF").ss(5,0,0,4).p("EgndgzvQC9N6CZKnQEhUCETOfUANFAsJAMmAAAQG6AAHKtrQF4rNF40GQEZu9EOzZQBqnlDBvU");
	this.shape.setTransform(255.1,331.8);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,505.4,660.5);


(lib.Path_3 = function() {
	this.initialize();

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00CE25").ss(5,0,0,4).p("A929lQCPH8B0GEQDbLdDQIRQJ5ZPJhAAQJlAAJ96BQDUonDNrOQBHj5CbpT");
	this.shape_1.setTransform(193.6,190.5);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.6,382.3,378);


(lib.Path_4 = function() {
	this.initialize();

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(5,0,0,4).p("EgoEgstQDAMACbJLQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBflyDRuI");
	this.shape_2.setTransform(259,286.9);

	this.addChild(this.shape_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_5 = function() {
	this.initialize();

	// Capa 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00FF00").ss(5,0,0,4).p("EgoEgstQDAMBCbJKQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBelvDSuK");
	this.shape_3.setTransform(259,286.9);

	this.addChild(this.shape_3);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_6 = function() {
	this.initialize();

	// Capa 1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#00FF00").ss(4,0,0,4).p("EAAAg5hMAAABzD");
	this.shape_4.setTransform(2,368.3);

	this.addChild(this.shape_4);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_7 = function() {
	this.initialize();

	// Capa 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#0000FF").ss(5,0,0,4).p("Ege2gi1QCUJXB4HIQDiNeDXJvQKOdsJ2AAQJ5AAKS+jQDbqIDUtLQBMktCdqy");
	this.shape_5.setTransform(199.9,223.7);

	this.addChild(this.shape_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,395,444.2);


(lib.Path_8 = function() {
	this.initialize();

	// Capa 1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#00A1C9").ss(4,0,0,4).p("EAAAg/cMAAAB+5");
	this.shape_6.setTransform(2,406.2);

	this.addChild(this.shape_6);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_9 = function() {
	this.initialize();

	// Capa 1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00A52F").ss(5,0,0,4).p("EgjAgzKQCoNwCIKfQEBT0D0OUUALmArqALLAAAQGIAAGWtqQFNrNFO0DQD4u6DxzXQBVm0C0v+");
	this.shape_7.setTransform(226.6,328.1);

	this.addChild(this.shape_7);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.5,448.3,653.1);


(lib.Path_10 = function() {
	this.initialize();

	// Capa 1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#00A52F").ss(4,0,0,4).p("EAAAg79MAAAB37");
	this.shape_8.setTransform(2,383.8);

	this.addChild(this.shape_8);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_11 = function() {
	this.initialize();

	// Capa 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#00A52F").ss(5,0,0,4).p("EgfmgwDQCYM6B6J2QDoSnDcNcUAKeApAAKFAAAUAKIAAAAKjgqLQDguADayLQBLmSCkvH");
	this.shape_9.setTransform(204.8,308.1);

	this.addChild(this.shape_9);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.5,404.7,613.4);


(lib.Path_12 = function() {
	this.initialize();

	// Capa 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(5,0,0,4).p("Egcfgl+QCIKMBvHyQDROsDGKnUAJcAgZAJGAAAUAJIAAAAJhghUQDKrDDEuXQBCk0CWsF");
	this.shape_10.setTransform(184.9,243.7);

	this.addChild(this.shape_10);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,364.9,484.4);


(lib.Path_13 = function() {
	this.initialize();

	// Capa 1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#F307B6").ss(5,0,0,4).p("EgcNgl0QCHKKBuHvQDPOpDEKkUAJXAgPAI/AAAUAJDAAAAJaghLQDIq/DCuTQBFlECRrx");
	this.shape_11.setTransform(183.1,242.7);

	this.addChild(this.shape_11);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,361.3,482.3);


(lib.Path_14 = function() {
	this.initialize();

	// Capa 1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#F307B6").ss(4,0,0,4).p("EAAAg79MAAAB37");
	this.shape_12.setTransform(2,383.8);

	this.addChild(this.shape_12);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_15 = function() {
	this.initialize();

	// Capa 1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#00FF00").ss(5,0,0,4).p("A279yQBuH/BZGGQCoLhCgIUQHmZXHUAAQHXAAHp6GQCjoqCerPQA3j8B2pT");
	this.shape_13.setTransform(149.3,191.3);

	this.addChild(this.shape_13);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,293.8,379.5);


(lib.Path_16 = function() {
	this.initialize();

	// Capa 1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(5,0,0,4).p("Egc3gu7QCKMmBwJoQDUSLDJNHUAJlAoCAJNAAAUAJQAAAAJogpLQDNtrDGxwQBGmOCVuq");
	this.shape_14.setTransform(187.3,300.9);

	this.addChild(this.shape_14);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.5,369.7,598.9);


(lib.Path_17 = function() {
	this.initialize();

	// Capa 1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#C807D7").ss(5,0,0,4).p("Egc9gvLQCLMrBwJrQDVSRDKNMUAJmAoPAJPAAAUAJSAAAAJqgpZQDOtwDHx1QBGmRCVuv");
	this.shape_15.setTransform(187.9,302.5);

	this.addChild(this.shape_15);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.5,371,602);


(lib.Path_18 = function() {
	this.initialize();

	// Capa 1
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#00A52F").ss(4,0,0,4).p("EAAAg+RMAAAB8j");
	this.shape_16.setTransform(2,398.7);

	this.addChild(this.shape_16);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_19 = function() {
	this.initialize();

	// Capa 1
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#00FF00").ss(5,0,0,4).p("Egd5gmGQCPKPB0HzQDcOvDQKqUAJ6AgeAJiAAAUAJmAAAAJ+ghaQDVrFDNuaQBHlACbr8");
	this.shape_17.setTransform(193.9,244.5);

	this.addChild(this.shape_17);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,383,485.9);


(lib.Path_20 = function() {
	this.initialize();

	// Capa 1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#0000FF").ss(5,0,0,4).p("EgoEgstQDAMACbJLQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBflyDRuI");
	this.shape_18.setTransform(259,286.9);

	this.addChild(this.shape_18);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_21 = function() {
	this.initialize();

	// Capa 1
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(5,0,0,4).p("EgoEgstQDAMACbJLQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBflyDRuI");
	this.shape_19.setTransform(259,286.9);

	this.addChild(this.shape_19);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_22 = function() {
	this.initialize();

	// Capa 1
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#00FF00").ss(5,0,0,4).p("EgoEgstQDAMBCbJKQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBelvDSuK");
	this.shape_20.setTransform(259,286.9);

	this.addChild(this.shape_20);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_1_1 = function() {
	this.initialize();

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FF00").ss(4,0,0,4).p("EAAAg5hMAAABzD");
	this.shape_1.setTransform(2,368.3);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_23 = function() {
	this.initialize();

	// Capa 1
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#0039FF").ss(4,0,0,4).p("EAAAg5hMAAABzD");
	this.shape_21.setTransform(2,368.3);

	this.addChild(this.shape_21);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_24 = function() {
	this.initialize();

	// Capa 1
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(5,0,0,4).p("EgoEgstQDAMACbJLQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBflyDRuI");
	this.shape_22.setTransform(259,286.9);

	this.addChild(this.shape_22);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_25 = function() {
	this.initialize();

	// Capa 1
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#00FF00").ss(5,0,0,4).p("EgoEgstQDAMBCbJKQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBelvDSuK");
	this.shape_23.setTransform(259,286.9);

	this.addChild(this.shape_23);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_26 = function() {
	this.initialize();

	// Capa 1
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#00FF00").ss(4,0,0,4).p("EAAAg5hMAAABzD");
	this.shape_24.setTransform(2,368.3);

	this.addChild(this.shape_24);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Path_27 = function() {
	this.initialize();

	// Capa 1
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#00FF00").ss(5,0,0,4).p("EgoEgstQDAMBCbJKQEmRUEXMgUANSAmKAMyAAAQHBAAHRr8QF+pyF+xiQEctBETw7QBelvDSuK");
	this.shape_25.setTransform(259,286.9);

	this.addChild(this.shape_25);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.4,0.7,513.1,570.7);


(lib.Path_28 = function() {
	this.initialize();

	// Capa 1
	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FF8000").ss(5,0,0,4).p("Egplg0yQDHOMCiK0QExUdEhOxUANyAtDANRAAAQHSAAHjuFQGMrkGM0tQEnvYEez/QBhmzDawt");
	this.shape_26.setTransform(268.7,338.5);

	this.addChild(this.shape_26);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,532.5,674);


(lib.Path_29 = function() {
	this.initialize();

	// Capa 1
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FF0000").ss(5,0,0,4).p("EgcchHFQCITHBuOmQDPbjDGT8UAJZA8uAJCAAAUAJFAAAAJkg+jQDM00DF67QBQq+CJ0w");
	this.shape_27.setTransform(184.7,455.9);

	this.addChild(this.shape_27);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.3,364.3,909);


(lib.Path_30 = function() {
	this.initialize();

	// Capa 1
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#00CE25").ss(5,0,0,4).p("EgUeglGQBiJ+BQHnQCWOXCPKXQGyfqGhAAUAGlAAAAG1ggoQCRq0CNuEQAxk4Bqrq");
	this.shape_28.setTransform(133.6,238.4);

	this.addChild(this.shape_28);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.4,262.3,474);


(lib.Path_31 = function() {
	this.initialize();

	// Capa 1
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#6C07D7").ss(5,0,0,4).p("EgYsg1+QB2OgBgLEQC1U6CsPGUAIMAuDAH4AAAUAH7AAAAIPgvYQCvvuCq0bQA9nXB+wr");
	this.shape_29.setTransform(160.7,345.9);

	this.addChild(this.shape_29);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.4,316.3,689);


(lib.Path_32 = function() {
	this.initialize();

	// Capa 1
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#00CE25").ss(5,0,0,4).p("Egalgj6QCAJpBnHWQDDN6C5KCQIzenIfAAQIhAAI3/MQC9qXC3tcQBFlHCEqx");
	this.shape_30.setTransform(172.7,230.5);

	this.addChild(this.shape_30);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.6,340.4,458);


(lib.Path_33 = function() {
	this.initialize();

	// Capa 1
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#6C07D7").ss(5,0,0,4).p("EgjthBGQCrRgCLNWQEFZOD5SPUAL2A3lALZAAAQGQAAGexNQFVuHFU5TQD+y2D14ZQBipwCszF");
	this.shape_31.setTransform(231.1,417.2);

	this.addChild(this.shape_31);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2.5,0.4,457.4,831.5);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}