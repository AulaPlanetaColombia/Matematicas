(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);


	this.instance_1 = new lib._63499027();
	this.instance_1.setTransform(258.3,129.9,0.66,0.66);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit2']);

	this.instance = new lib.mc_pant_2();
	this.instance.setTransform(98.1,119.8);
        
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3']);
this.instance = new lib.mc_pant_3();
	this.instance.setTransform(98.1,119.8);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         titulo2(this, txt['tit4']);
this.instance = new lib.mc_pant_4();
	this.instance.setTransform(98.1,119.8);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         titulo2(this, txt['tit5']);
this.instance = new lib.mc_pant_5();
	this.instance.setTransform(98.1,119.8);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
         titulo2(this, txt['tit6']);
this.instance = new lib.mc_pant_6();
	this.instance.setTransform(98.1,119.8);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       titulo2(this, txt['tit7']);
this.instance = new lib.mc_pant_7();
	this.instance.setTransform(98.1,119.8);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:
(lib._63499027 = function() {
	this.initialize(img._63499027);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,655,653);



(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,377);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,378);


(lib.mc_pant_7 = function() {
	this.initialize();

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AonnYIRPOx");
	this.shape.setTransform(746,202);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_1.setTransform(713.7,176.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_2.setTransform(713.7,176.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_3.setTransform(745.3,202.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_4.setTransform(745.3,202.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_5.setTransform(685.3,147.6);

	// funcio
	this.text = new cjs.Text("f(x)", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(23,87+incremento);

	this.text_1 = new cjs.Text("=", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(63,89+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAZGgIAAjfQAAhXgTgoQgRgngvgJIAAglQAvgIARgnQATgoAAhWIAAjfIAhAAIAADcQABBngaAqQgZAsg6AEIAAAFQA7AFAZAqQAYArAABmIAADdg");
	this.shape_6.setTransform(103.3,105.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AtbGrQgJgDgGgHQgJgIgFgNQgEgOAAgTQAAgTAEgPQAEgPAKgLQAIgLANgHQAOgGASAAIAKABIAIABIAAATIgBAAIgIgDQgGgBgGAAQgVAAgMANQgNANgCAXQAIgFAJgDQAHgDALAAQAJAAAHACQAHACAHAFQAJAGAFAJQAEAJAAANQAAAWgOAOQgQAOgUAAQgLAAgJgDgAtZFgQgIACgHAEIgBAFIAAAFQABAPADAJQADAJAFAFQAFAEAFACQAFACAHAAQAOAAAIgIQAIgJAAgQQAAgJgCgGQgDgGgGgFQgFgDgFgBIgMgBQgIAAgHACgAhSGrQgLgDgGgDIAAgVIAAAAQAKAHAKAEQAKADAKAAQAMAAAIgEQAGgDAAgJQAAgGgDgEQgEgDgLgCIgKgCIgLgDQgPgEgFgHQgHgHAAgLQAAgHADgGQADgGAFgFQAGgEAJgDQAIgCALAAQAJAAAKACQAKACAHAEIAAATIgBAAQgHgFgKgDQgLgEgJAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAEADAKACIALACIAKADQANADAHAHQAHAHAAAMQAAAPgNAJQgMAKgVAAQgMAAgKgDgAKwGrIAAgpIhFAAIAAgWIBGhSIASAAIAABZIAVAAIAAAPIgVAAIAAApgAJ4FzIA4AAIAAhCgAELGrIgXgpIgoApIgXAAIA5g3Igfg2IAUAAIAXAqIAogqIAXAAIg3A3IAeA2gAAKGrIAAhtIASAAIAABtgAmwGrIgWgpIgpApIgWAAIA4g3Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA2gAGTGSIBZgmIhZgnIAAgSIBxAzIAAAMIhxAygAq1FzIAAgPIBhAAIAAAPgAAJEsIAAgTIAVAAIAAATgAnVBDQgKgDgHgDIAAgVIABAAQAJAHAKAEQALADAKAAQAMAAAHgEQAHgDgBgJQABgGgEgEQgDgDgLgCIgLgCIgLgDQgOgEgGgHQgGgHAAgJQAAgHACgGQAEgGAFgFQAGgEAIgDQAJgCAKAAQAJAAAKACQALACAGAEIAAATIgBAAQgHgFgKgDQgKgEgJAAQgLAAgGAEQgIAEAAAHQAAAHAFAEQAEABAJACIALACIALADQAMADAIAHQAGAHAAAMQAAAPgMAJQgMAKgWAAQgMAAgKgDgANcBDIAAgpIhGAAIAAgWIBHhQIASAAIAABXIAVAAIAAAPIgVAAIAAApgAMkALIA4AAIAAhAgAI+BDIAAgPIBwAAIAAAPgAG3BDIgXgpIgoApIgXAAIA5g3Igfg0IAVAAIAWAoIApgoIAWAAIg3A1IAeA2gACXBDIAAgPIBwAAIAAAPgAgrBDIAAgPIAfAAIAAhfIgfAAIAAgNIAOgBQAHgBAEgCQAEgDADgDQACgEAAgHIAOAAIAACBIAdAAIAAAPgAl2BDIAAhrIASAAIAABrgAs8BDIAAgpIhGAAIAAgWIBHhQIARAAIAABXIAWAAIAAAPIgWAAIAAApgAt0ALIA4AAIAAhAgAI+gIIAAgMIBwgvIAAASIhWAjIBWAiIAAASgACXgIIAAgMIBwgvIAAASIhWAjIBWAiIAAASgAi1ALIAAgNIBhAAIAAANgAl4g6IAAgTIAWAAIAAATgAgukZQgKgDgHgDIAAgVIABAAQAJAHAKAEQALADAKAAQAMAAAHgEQAFgDgBgJQABgGgCgEQgDgDgLgCIgLgCIgLgDQgOgEgGgHQgGgHAAgLQAAgHACgGQAEgGAFgFQAGgEAIgDQAJgCAKAAQAJAAAJACQAKACAGAEIAAATIgBAAQgHgFgIgDQgKgEgJAAQgLAAgGAEQgIAEAAAHQAAAHAFAEQAEADAJACIALACIALADQAKADAIAHQAGAHAAAMQAAAPgMAJQgKAKgWAAQgMAAgKgDgAIqkZIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgADpkZIgWgpIgpApIgWAAIA4g3Igfg2IAVAAIAWAqIApgqIAWAAIg4A3IAfA2gAAvkZIAAhtIASAAIAABtgAnTkZIAAgUIAVgSIATgRQASgSAHgLQAIgLgBgMQAAgLgHgHQgIgGgMAAQgKAAgKADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAWAAANALQAMAKAAATQAAAIgCAHQgCAIgEAGQgDAGgGAGIgMANIgWAUIgVASIBOAAIAAAQgAswkZIgfgqIggAqIgVAAIArg2Igqg3IAXAAIAfApIAegpIAWAAIgrA2IArA3gAqDkbIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAEplSIAAgMIBxgzIAAASIhZAnIBZAmIAAASgAHDlQIAAgRIA9AAIAAARgAAtmYIAAgTIAWAAIAAATg");
	this.shape_7.setTransform(210.7,103.3);

	// grafica
	this.instance = new lib.Mapadebits2();
	this.instance.setTransform(684.7,0.2);

	this.instance_1 = new lib.Mapadebits1();
	this.instance_1.setTransform(521.7,4.5);

	this.text_2 = new cjs.Text("7", "14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(767.8,207.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_8.setTransform(687,87.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_9.setTransform(687,87.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_10.setTransform(522.3,86.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_11.setTransform(522.3,86.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("AsyAAIZlAA");
	this.shape_12.setTransform(604.5,87.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("ApVGoISrtP");
	this.shape_13.setTransform(460.9,225.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_14.setTransform(524.2,180.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_15.setTransform(495.4,200.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_16.setTransform(495.4,200.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_17.setTransform(465.8,218.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_18.setTransform(465.8,218.9);

	this.text_3 = new cjs.Text("-2", "14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(482.8,207);

	this.text_4 = new cjs.Text("-3", "14px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(452.8,207);

	this.text_5 = new cjs.Text("-4", "14px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(422.2,207);

	this.text_6 = new cjs.Text("-5", "14px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(392.8,207);

	this.text_7 = new cjs.Text("-6", "14px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(362.8,207);

	this.text_8 = new cjs.Text("-7", "14px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(332.2,207);

	this.text_9 = new cjs.Text("6", "14px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(738.9,207.8);

	this.text_10 = new cjs.Text("5", "14px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(708.9,207.8);

	this.text_11 = new cjs.Text("4", "14px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(678.3,207.8);

	this.text_12 = new cjs.Text("3", "14px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(648.9,207.8);

	this.text_13 = new cjs.Text("2", "14px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(618.9,207.8);

	this.text_14 = new cjs.Text("1", "14px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(587.1,206.6);

	this.text_15 = new cjs.Text("0", "14px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(561.3,205.6);

	this.text_16 = new cjs.Text("-1", "14px Verdana");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(515.7,207.9);

	this.text_17 = new cjs.Text("-2", "14px Verdana");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(533.7,238);

	this.text_18 = new cjs.Text("-3", "14px Verdana");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(534.4,268.9);

	this.text_19 = new cjs.Text("-4", "14px Verdana");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(533.7,296.1);

	this.text_20 = new cjs.Text("-5", "14px Verdana");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(533.7,326.2);

	this.text_21 = new cjs.Text("-6", "14px Verdana");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(534.4,357.1);

	this.text_22 = new cjs.Text("6", "14px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(538.5,15.6);

	this.text_23 = new cjs.Text("5", "14px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(538.5,45.8);

	this.text_24 = new cjs.Text("4", "14px Verdana");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(539.2,76.6);

	this.text_25 = new cjs.Text("3", "14px Verdana");
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(538.5,103.8);

	this.text_26 = new cjs.Text("2", "14px Verdana");
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(538.5,134);

	this.text_27 = new cjs.Text("1", "14px Verdana");
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(539.2,164.8);

	this.text_28 = new cjs.Text("0", "14px Verdana");
	this.text_28.lineHeight = 16;
	this.text_28.setTransform(548.7,182);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_19.setTransform(561.7,177.3,1,1,-89.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_20.setTransform(561.7,147.3,1,1,-89.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_21.setTransform(561.7,117.3,1,1,-89.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_22.setTransform(561.7,87.3,1,1,-89.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_23.setTransform(561.7,57.8,1,1,-89.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_24.setTransform(561.7,27.8,1,1,-89.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_25.setTransform(561.7,368.7,1,1,-89.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_26.setTransform(561.7,338.7,1,1,-89.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_27.setTransform(561.7,308.7,1,1,-89.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_28.setTransform(561.7,278.7,1,1,-89.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_29.setTransform(561.7,249.2,1,1,-89.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_30.setTransform(561.7,219.2,1,1,-89.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_31.setTransform(595.6,200.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_32.setTransform(625.6,200.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_33.setTransform(655.6,200.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_34.setTransform(685.1,200.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_35.setTransform(715.1,200.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_36.setTransform(745.1,200.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_37.setTransform(775.1,200.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_38.setTransform(345.7,199.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_39.setTransform(375.7,199.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_40.setTransform(405.7,199.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_41.setTransform(435.2,199.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_42.setTransform(465.2,199.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_43.setTransform(495.2,199.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_44.setTransform(525.2,199.6);

	this.text_29 = new cjs.Text("x", "italic 18px Verdana");
	this.text_29.lineHeight = 20;
	this.text_29.lineWidth = 144;
	this.text_29.setTransform(781,197.3+incremento);

	this.text_30 = new cjs.Text("y", "italic 18px Verdana");
	this.text_30.lineHeight = 20;
	this.text_30.lineWidth = 144;
	this.text_30.setTransform(566.4,-7.5+incremento);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(2,1,1).p("EAjoAAAMhHQAAA");
	this.shape_45.setTransform(554.3,200.1,1,1,0,0,0,-6.6,0);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(2,1,1).p("AAA9RMAAAA6j");
	this.shape_46.setTransform(561.7,190.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,153,0,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_47.setTransform(740.2,199.7,0.569,0.022,0,0,0,0.1,-0.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(0,204,255,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_48.setTransform(604.9,199.4,0.856,0.022,0,0,0,0.1,-0.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(0,153,51,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_49.setTransform(429,199.9,1,0.02,0,0,0,0,-0.4);

	this.addChild(this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.text_30,this.text_29,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.text_2,this.instance_1,this.instance,this.shape_7,this.shape_6,this.text_1,this.text,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(23,-7.5,906,389.1);


(lib.mc_pant_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// formula
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmAGrQgJgDgHgHQgIgIgFgNQgEgOAAgTQAAgTAEgPQAEgPAJgLQAJgLANgHQAOgGASAAIAJABIAIABIAAATIgBAAIgIgDQgFgBgGAAQgVAAgNANQgMANgCAXQAIgFAIgDQAIgDAKAAQAKAAAHACQAHACAHAFQAJAGAEAJQAFAJAAANQAAAWgPAOQgPAOgVAAQgLAAgIgDgAl/FgQgHACgHAEIgBAFIAAAFQAAAPAEAJQADAJAFAFQAFAEAFACQAFACAGAAQAPAAAIgIQAIgJAAgQQAAgJgDgGQgDgGgGgFQgEgDgGgBIgLgBQgIAAgIACgAGGGrQgKgDgHgDIAAgVIABAAQAJAHALAEQAKADAKAAQAMAAAHgEQAHgDAAgJQAAgGgEgEQgDgDgLgCIgKgCIgMgDQgOgEgGgHQgGgHAAgLQAAgHADgGQADgGAFgFQAGgEAIgDQAJgCAKAAQAKAAAKACQAKACAGAEIAAATIgBAAQgHgFgKgDQgKgEgJAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAEADAJACIAMACIAKADQANADAHAHQAHAHAAAMQAAAPgNAJQgMAKgVAAQgMAAgLgDgASLGrIAAgpIhGAAIAAgWIBHhSIASAAIAABZIAVAAIAAAPIgVAAIAAApgARTFzIA4AAIAAhCgALmGrIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAHlGrIAAhtIASAAIAABtgAApGrIgWgpIgnApIgWAAIA2g3Igdg2IATAAIAWAqIApgqIAWAAIg3A3IAeA2gANuGSIBZgmIhZgnIAAgSIBxAzIAAAMIhxAygAjaFzIAAgPIBhAAIAAAPgAHkEsIAAgTIAVAAIAAATgAxVBNIAAAAQAMgJAMgMQAMgMAJgQQALgSAGgQQAGgSAAgUQAAgVgGgRQgHgSgKgMIAAgBIAUAAQAJAOAGARQAGARAAASQAAASgFASQgFAQgIAQQgJAQgLAOQgMAOgNAMgAz8BNQgJgOgGgQQgFgRAAgSQAAgRAEgRQAFgRAIgRQAJgQALgOQAMgOAOgNIAWAAIAAABQgLAIgMANQgMANgKAPQgKAPgGATQgGATAAATQAAAVAGARQAGASAKAMIAAAAgAAEBDQgIgDgHgDIAAgVIABAAQAJAHAIAEQALADAKAAQAMAAAHgEQAGgDAAgJQAAgGgDgEQgEgDgKgCIgLgCIgLgDQgOgEgEgHQgHgHAAgJQAAgHADgGQADgGAFgFQAEgEAJgDQAIgCALAAQAJAAAKACQAKACAHAEIAAATIgBAAQgHgFgKgDQgKgEgKAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAFABAJACIALACIALADQAMADAHAHQAHAHAAAMQAAAPgMAJQgMAKgWAAQgMAAgKgDgAU3BDIAAgpIhGAAIAAgWIBHhQIASAAIAABXIAVAAIAAAPIgVAAIAAApgAT/ALIA4AAIAAhAgAQZBDIAAgPIBwAAIAAAPgAOSBDIgXgpIgoApIgXAAIA4g3Igeg0IAUAAIAXAoIAogoIAXAAIg4A1IAfA2gAJyBDIAAgPIBwAAIAAAPgAGuBDIAAgPIAfAAIAAhfIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACBIAeAAIAAAPgABjBDIAAhrIASAAIAABrgAliBDIAAgpIhFAAIAAgWIBGhQIASAAIAABXIAWAAIAAAPIgWAAIAAApgAmaALIA4AAIAAhAgAQZgIIAAgMIBwgvIAAASIhXAjIBXAiIAAASgAJygIIAAgMIBwgvIAAASIhXAjIBXAiIAAASgAx0AlIgXgnIgoAnIgXAAIA4g1Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA0gA1eAlIAVhcIgMAAIADgPIANAAIAAgDQAEgUAMgKQAMgLASAAIALABIAJABIgEAQIAAAAIgIgBIgIgBQgMAAgGAGQgGAGgEAMIAAAEIAhAAIgEAPIggAAIgWBcgAEjALIAAgNIBhAAIAAANgABhg6IAAgTIAVAAIAAATgAGrkZQgKgDgHgDIAAgVIABAAQAJAHAKAEQALADAKAAQAMAAAHgEQAGgDAAgJQAAgGgDgEQgEgDgKgCIgLgCIgLgDQgPgEgFgHQgHgHAAgLQAAgHADgGQADgGAGgFQAFgEAJgDQAIgCALAAQAJAAAKACQAKACAHAEIAAATIgBAAQgHgFgKgDQgKgEgKAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAFADAJACIALACIALADQAMADAHAHQAHAHAAAMQAAAPgMAJQgMAKgWAAQgMAAgKgDgAQFkZIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACDIAeAAIAAAPgALEkZIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAIKkZIAAhtIASAAIAABtgAAGkZIAAgUIAVgSIATgRQASgSAHgLQAHgLAAgMQAAgLgHgHQgIgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgMANIgWAUIgVASIBOAAIAAAQgAlVkZIgfgqIggAqIgVAAIArg2Igqg3IAXAAIAeApIAfgpIAWAAIgrA2IArA3gAiokbIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAMElSIAAgMIBxgzIAAASIhZAnIBZAmIAAASgAOelQIAAgRIA9AAIAAARgAIImYIAAgTIAVAAIAAATg");
	this.shape.setTransform(163.2,103.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(340));

	// formula_verfa
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AmtBUIAdgqIgShaIARAAIAOBHIAvhHIASAAIhZCEgAFVAwIAAgSIASgQIASgOQARgQAGgKQAGgJAAgLQABgLgIgFQgGgGgMAAQgIAAgKADQgJACgJAGIgBAAIAAgSQAHgDAKgDQAKgCAKAAQAVAAALAJQALAKAAARQAAAHgBAHQgCAGgFAGQgCAFgGAGIgLAKIgTARIgTAQIBHAAIAAAPgAASAwIgTglIglAlIgUAAIAygwIgbgwIASAAIASAmIAlgmIAVAAIgyAwIAbAwgAC2AuIAAguIgwAAIAAgOIAwAAIAAgwIAPAAIAAAwIAwAAIAAAOIgwAAIAAAugAjyAQIAAgOIBpAAIAAAOgAjygSIAAgPIBpAAIAAAPg");
	this.shape_1.setTransform(412.2,53.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ANXBUIAdgqIgShaIARAAIANBHIAvhHIASAAIhYCEgA04BUIAdgqIgShaIARAAIANBHIAwhHIASAAIhZCEgAUVAwIAAglIg/AAIAAgSIA/hKIARAAIAABQIATAAIAAAMIgTAAIAAAlgATigBIAzAAIAAg7gAo1AwIAAgSIATgQIARgOQASgQAFgKQAHgJAAgLQAAgLgHgFQgGgGgMAAQgJAAgJADQgJACgJAGIgBAAIAAgSQAGgDALgDQAKgCAKAAQAUAAALAJQAMAKAAARQAAAHgCAHQgCAGgEAGQgDAFgFAGIgLAKIgTARIgTAQIBGAAIAAAPgAt4AwIgVglIglAlIgTAAIAygwIgcgwIATAAIAUAmIAlgmIAUAAIgyAwIAcAwgArTAuIAAguIgwAAIAAgOIAwAAIAAgwIAOAAIAAAwIAxAAIAAAOIgxAAIAAAugAQSAQIAAgOIBpAAIAAAOgAx9AQIAAgOIBoAAIAAAOgAQSgSIAAgPIBpAAIAAAPgAx9gSIAAgPIBoAAIAAAPg");
	this.shape_2.setTransform(503,53.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("ACEBeIAcgqIgRhaIARAAIANBHIAvhHIASAAIhYCEgEggLABeIAcgqIgRhaIARAAIANBHIAvhHIASAAIhYCEgATwBLIAdgqIgShaIARAAIAOBHIAvhHIASAAIhZCEgAJCA6IAAglIg/AAIAAgUIA/hIIARAAIAABOIATAAIAAAOIgTAAIAAAlgAIPAHIAzAAIAAg5gA0IA6IAAgTIATgPIARgQQARgPAGgJQAHgKAAgLQAAgKgHgGQgHgGgMAAQgIAAgJADQgKADgIAGIgBAAIAAgTQAGgDAKgCQALgDAJAAQAVAAALAKQALAKAAAQQAAAIgBAGQgCAHgEAFQgDAGgFAFIgLAKIgUASIgSAQIBGAAIAAAPgA5LA6IgVgmIglAmIgUAAIAzgyIgcguIATAAIAUAlIAlglIAUAAIgyAvIAbAxgA2mA3IAAgwIgwAAIAAgMIAwAAIAAgvIAOAAIAAAvIAwAAIAAAMIgwAAIAAAwgAaSAmQgHgDgGgFQgIgIgEgMQgEgKAAgRQAAgRAEgOQADgNAIgKQAIgKAMgGQANgGAQAAIAJABIAHABIAAARIgBAAIgIgCIgKgBQgTAAgLALQgLAMgCAUQAHgEAIgCQAHgDAJAAQAIAAAHACQAGABAHAFQAIAFAEAIQADAJAAALQAAASgNANQgNAMgTAAQgKAAgIgDgAaUgbIgNAGIAAAEIAAAEQAAANACAHQADAIAFAFQAEAEAFABQAFACAFAAQANAAAHgIQAIgHAAgNQAAgIgDgGQgCgFgGgEQgEgDgFgBIgKAAQgIAAgGABgAfjAnIgUgmIglAmIgUAAIAygwIgbgwIASAAIAUAlIAlglIAUAAIgyAxIAcAvgAE/AaIAAgOIBoAAIAAAOgA9QAaIAAgOIBoAAIAAAOgAWrAHIAAgMIBpAAIAAAMgAcxgEIAAgZIAVAAIAAAZgAE/gJIAAgOIBoAAIAAAOgA9QgJIAAgOIBoAAIAAAOgAWrgcIAAgOIBpAAIAAAOg");
	this.shape_3.setTransform(575.3,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},113).to({state:[{t:this.shape_2}]},88).to({state:[{t:this.shape_3}]},107).wait(32));

	// formula
	this.text = new cjs.Text("=", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(63,89+incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAZGgIAAjfQAAhXgTgoQgRgngvgJIAAglQAvgIARgnQATgoAAhWIAAjfIAhAAIAADcQABBngaAqQgZAsg6AEIAAAFQA7AFAZAqQAYArAABmIAADdg");
	this.shape_4.setTransform(103.3,105.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.text}]}).wait(340));

	// mascara_linia_blava (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_153 = new cjs.Graphics().p("Af6RhIAAp8IIbAAIAAJ8g");
	var mask_graphics_154 = new cjs.Graphics().p("AlJE+IAAp7IKTAAIAAJ7g");
	var mask_graphics_155 = new cjs.Graphics().p("AmGE+IAAp7IMNAAIAAJ7g");
	var mask_graphics_156 = new cjs.Graphics().p("AnCE+IAAp7IOFAAIAAJ7g");
	var mask_graphics_157 = new cjs.Graphics().p("An/E+IAAp7IP/AAIAAJ7g");
	var mask_graphics_158 = new cjs.Graphics().p("Ao8E+IAAp7IR5AAIAAJ7g");
	var mask_graphics_159 = new cjs.Graphics().p("Ap4E+IAAp7ITxAAIAAJ7g");
	var mask_graphics_160 = new cjs.Graphics().p("Aq1E+IAAp7IVrAAIAAJ7g");
	var mask_graphics_161 = new cjs.Graphics().p("AryE+IAAp7IXlAAIAAJ7g");
	var mask_graphics_162 = new cjs.Graphics().p("AsuE+IAAp7IZdAAIAAJ7g");
	var mask_graphics_163 = new cjs.Graphics().p("AtrE+IAAp7IbXAAIAAJ7g");
	var mask_graphics_164 = new cjs.Graphics().p("AunE+IAAp7IdPAAIAAJ7g");
	var mask_graphics_165 = new cjs.Graphics().p("AvkE+IAAp7IfJAAIAAJ7g");
	var mask_graphics_166 = new cjs.Graphics().p("AwhE+IAAp7MAhDAAAIAAJ7g");
	var mask_graphics_167 = new cjs.Graphics().p("AxdE+IAAp7MAi7AAAIAAJ7g");
	var mask_graphics_168 = new cjs.Graphics().p("AyaE+IAAp7MAk1AAAIAAJ7g");
	var mask_graphics_169 = new cjs.Graphics().p("AQvRhIAAp8MAmwAAAIAAJ8g");
	var mask_graphics_250 = new cjs.Graphics().p("AQvRhIAAp8MAmwAAAIAAJ8g");
	var mask_graphics_251 = new cjs.Graphics().p("Az1E+IAAp7MAnrAAAIAAJ7g");
	var mask_graphics_252 = new cjs.Graphics().p("A0UE+IAAp7MAopAAAIAAJ7g");
	var mask_graphics_253 = new cjs.Graphics().p("A0yE+IAAp7MAplAAAIAAJ7g");
	var mask_graphics_254 = new cjs.Graphics().p("A1RE+IAAp7MAqjAAAIAAJ7g");
	var mask_graphics_255 = new cjs.Graphics().p("A1vE+IAAp7MArfAAAIAAJ7g");
	var mask_graphics_256 = new cjs.Graphics().p("A2OE+IAAp7MAsdAAAIAAJ7g");
	var mask_graphics_257 = new cjs.Graphics().p("A2sE+IAAp7MAtZAAAIAAJ7g");
	var mask_graphics_258 = new cjs.Graphics().p("A3LE+IAAp7MAuXAAAIAAJ7g");
	var mask_graphics_259 = new cjs.Graphics().p("A3qE+IAAp7MAvVAAAIAAJ7g");
	var mask_graphics_260 = new cjs.Graphics().p("A4IE+IAAp7MAwRAAAIAAJ7g");
	var mask_graphics_261 = new cjs.Graphics().p("A4nE+IAAp7MAxPAAAIAAJ7g");
	var mask_graphics_262 = new cjs.Graphics().p("A5FE+IAAp7MAyLAAAIAAJ7g");
	var mask_graphics_263 = new cjs.Graphics().p("A5kE+IAAp7MAzJAAAIAAJ7g");
	var mask_graphics_264 = new cjs.Graphics().p("A6CE+IAAp7MA0FAAAIAAJ7g");
	var mask_graphics_265 = new cjs.Graphics().p("AJkRhIAAp8MA1FAAAIAAJ8g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(153).to({graphics:mask_graphics_153,x:258.2,y:112.2}).wait(1).to({graphics:mask_graphics_154,x:495.5,y:192.6}).wait(1).to({graphics:mask_graphics_155,x:501.5,y:192.6}).wait(1).to({graphics:mask_graphics_156,x:507.6,y:192.6}).wait(1).to({graphics:mask_graphics_157,x:513.6,y:192.6}).wait(1).to({graphics:mask_graphics_158,x:519.7,y:192.6}).wait(1).to({graphics:mask_graphics_159,x:525.8,y:192.6}).wait(1).to({graphics:mask_graphics_160,x:531.8,y:192.6}).wait(1).to({graphics:mask_graphics_161,x:537.9,y:192.6}).wait(1).to({graphics:mask_graphics_162,x:543.9,y:192.6}).wait(1).to({graphics:mask_graphics_163,x:550,y:192.6}).wait(1).to({graphics:mask_graphics_164,x:556.1,y:192.6}).wait(1).to({graphics:mask_graphics_165,x:562.1,y:192.6}).wait(1).to({graphics:mask_graphics_166,x:568.2,y:192.6}).wait(1).to({graphics:mask_graphics_167,x:574.2,y:192.6}).wait(1).to({graphics:mask_graphics_168,x:580.3,y:192.6}).wait(1).to({graphics:mask_graphics_169,x:355.2,y:112.2}).wait(81).to({graphics:mask_graphics_250,x:355.2,y:112.2}).wait(1).to({graphics:mask_graphics_251,x:589.4,y:192.6}).wait(1).to({graphics:mask_graphics_252,x:592.5,y:192.6}).wait(1).to({graphics:mask_graphics_253,x:595.5,y:192.6}).wait(1).to({graphics:mask_graphics_254,x:598.6,y:192.6}).wait(1).to({graphics:mask_graphics_255,x:601.6,y:192.6}).wait(1).to({graphics:mask_graphics_256,x:604.7,y:192.6}).wait(1).to({graphics:mask_graphics_257,x:607.7,y:192.6}).wait(1).to({graphics:mask_graphics_258,x:610.8,y:192.6}).wait(1).to({graphics:mask_graphics_259,x:613.8,y:192.6}).wait(1).to({graphics:mask_graphics_260,x:616.9,y:192.6}).wait(1).to({graphics:mask_graphics_261,x:619.9,y:192.6}).wait(1).to({graphics:mask_graphics_262,x:623,y:192.6}).wait(1).to({graphics:mask_graphics_263,x:626,y:192.6}).wait(1).to({graphics:mask_graphics_264,x:629.1,y:192.6}).wait(1).to({graphics:mask_graphics_265,x:401,y:112.2}).wait(75));

	// linia_blava
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#00CCFF").ss(4,1,1).p("AsiAAIZFAA");
	this.shape_5.setTransform(605.2,200.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF0000").ss(4,1,1).p("AsiAAIZFAA");
	this.shape_6.setTransform(740.4,200.7,0.627,1);

	this.shape_5.mask = this.shape_6.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5}]},153).to({state:[{t:this.shape_5},{t:this.shape_6}]},97).wait(90));

	// linia_verda
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(521.7,4.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},87).wait(253));

	// destacats
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(255,153,0,0.498)").s().p("AtaCRIAAkgIa1AAIAAEgg");
	this.shape_7.setTransform(198,67.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_7,p:{scaleX:1,x:198,y:67.6}}]},57).to({state:[{t:this.shape_7,p:{scaleX:1.163,x:212,y:104.3}}]},86).to({state:[{t:this.shape_7,p:{scaleX:1.075,x:204.4,y:138.4}}]},98).wait(99));

	// numeros
	this.text_1 = new cjs.Text("7", "14px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(768.8,207.8);

	this.text_2 = new cjs.Text("-2", "14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(482.8,207);

	this.text_3 = new cjs.Text("-3", "14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(452.8,207);

	this.text_4 = new cjs.Text("-4", "14px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(422.2,207);

	this.text_5 = new cjs.Text("-5", "14px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(392.8,207);

	this.text_6 = new cjs.Text("-6", "14px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(362.8,207);

	this.text_7 = new cjs.Text("-7", "14px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(332.2,207);

	this.text_8 = new cjs.Text("6", "14px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(738.9,207.8);

	this.text_9 = new cjs.Text("5", "14px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(708.9,207.8);

	this.text_10 = new cjs.Text("4", "14px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(678.3,207.8);

	this.text_11 = new cjs.Text("3", "14px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(648.9,207.8);

	this.text_12 = new cjs.Text("2", "14px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(618.9,207.8);

	this.text_13 = new cjs.Text("1", "14px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(587.1,206.6);

	this.text_14 = new cjs.Text("0", "14px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(561.3,205.6);

	this.text_15 = new cjs.Text("-1", "14px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(515.7,207.9);

	this.text_16 = new cjs.Text("-2", "14px Verdana");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(533.7,238);

	this.text_17 = new cjs.Text("-3", "14px Verdana");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(534.4,268.9);

	this.text_18 = new cjs.Text("-4", "14px Verdana");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(533.7,296.1);

	this.text_19 = new cjs.Text("-5", "14px Verdana");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(533.7,326.2);

	this.text_20 = new cjs.Text("-6", "14px Verdana");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(534.4,357.1);

	this.text_21 = new cjs.Text("6", "14px Verdana");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(538.5,15.6);

	this.text_22 = new cjs.Text("5", "14px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(538.5,45.8);

	this.text_23 = new cjs.Text("4", "14px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(539.2,76.6);

	this.text_24 = new cjs.Text("3", "14px Verdana");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(538.5,103.8);

	this.text_25 = new cjs.Text("2", "14px Verdana");
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(538.5,134);

	this.text_26 = new cjs.Text("1", "14px Verdana");
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(539.2,164.8);

	this.text_27 = new cjs.Text("0", "14px Verdana");
	this.text_27.lineHeight = 16;
	this.text_27.setTransform(548.7,182);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_27},{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1}]},28).wait(312));

	// pastilla_verda
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(0,153,51,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_8.setTransform(429,190.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,153,0,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_9.setTransform(740.2,189.8,0.569,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_8}]},101).to({state:[{t:this.shape_8},{t:this.shape_9}]},189).wait(50));

	// numeracio_eixos
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_10.setTransform(561.7,177.3,1,1,-89.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_11.setTransform(561.7,147.3,1,1,-89.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_12.setTransform(561.7,117.3,1,1,-89.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_13.setTransform(561.7,87.3,1,1,-89.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_14.setTransform(561.7,57.8,1,1,-89.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_15.setTransform(561.7,27.8,1,1,-89.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_16.setTransform(561.7,368.7,1,1,-89.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_17.setTransform(561.7,338.7,1,1,-89.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_18.setTransform(561.7,308.7,1,1,-89.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_19.setTransform(561.7,278.7,1,1,-89.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_20.setTransform(561.7,249.2,1,1,-89.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_21.setTransform(561.7,219.2,1,1,-89.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_22.setTransform(595.6,200.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_23.setTransform(625.6,200.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_24.setTransform(655.6,200.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_25.setTransform(685.1,200.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_26.setTransform(715.1,200.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_27.setTransform(745.1,200.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_28.setTransform(775.1,200.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_29.setTransform(345.7,199.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_30.setTransform(375.7,199.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_31.setTransform(405.7,199.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_32.setTransform(435.2,199.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_33.setTransform(465.2,199.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_34.setTransform(495.2,199.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_35.setTransform(525.2,199.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]},28).wait(312));

	// linia_blava_discon
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#00CCFF").ss(2,1,1).p("AAA9YMAAAA6x");
	this.shape_36.setTransform(685.7,189.3);

	this.instance_1 = new lib.Mapadebits2();
	this.instance_1.setTransform(684.7,0.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(0,204,255,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_37.setTransform(604.8,190.4,0.856,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_36}]},169).to({state:[{t:this.shape_37},{t:this.instance_1}]},11).wait(160));

	// eixos
	this.text_28 = new cjs.Text("x", "italic 18px Verdana");
	this.text_28.lineHeight = 20;
	this.text_28.lineWidth = 144;
	this.text_28.setTransform(781,197.3+incremento);

	this.text_29 = new cjs.Text("y", "italic 18px Verdana");
	this.text_29.lineHeight = 20;
	this.text_29.lineWidth = 144;
	this.text_29.setTransform(566.4,-7.5+incremento);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(2,1,1).p("EAjoAAAMhHQAAA");
	this.shape_38.setTransform(554.3,200.1,1,1,0,0,0,-6.6,0);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(2,1,1).p("AAA9RMAAAA6j");
	this.shape_39.setTransform(561.7,190.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.text_29},{t:this.text_28}]},28).wait(312));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.7,60.3,275.2,86.8);


(lib.mc_pant_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmAGrQgJgDgHgHQgIgIgFgNQgEgOAAgTQAAgTAEgPQAEgPAJgLQAJgLANgHQAOgGASAAIAJABIAIABIAAATIgBAAIgIgDQgFgBgGAAQgVAAgNANQgMANgCAXQAIgFAIgDQAIgDAKAAQAKAAAHACQAHACAHAFQAJAGAEAJQAFAJAAANQAAAWgPAOQgPAOgVAAQgLAAgIgDgAl/FgQgHACgHAEIgBAFIAAAFQAAAPAEAJQADAJAFAFQAFAEAFACQAFACAGAAQAPAAAIgIQAIgJAAgQQAAgJgDgGQgDgGgGgFQgEgDgGgBIgLgBQgIAAgIACgAGGGrQgKgDgHgDIAAgVIABAAQAJAHALAEQAKADAKAAQAMAAAHgEQAHgDAAgJQAAgGgEgEQgDgDgLgCIgKgCIgMgDQgOgEgGgHQgGgHAAgLQAAgHADgGQADgGAFgFQAGgEAIgDQAJgCAKAAQAKAAAKACQAKACAGAEIAAATIgBAAQgHgFgKgDQgKgEgJAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAEADAJACIAMACIAKADQANADAHAHQAHAHAAAMQAAAPgNAJQgMAKgVAAQgMAAgLgDgASLGrIAAgpIhGAAIAAgWIBHhSIASAAIAABZIAVAAIAAAPIgVAAIAAApgARTFzIA4AAIAAhCgALmGrIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAHlGrIAAhtIASAAIAABtgAApGrIgWgpIgnApIgWAAIA2g3Igdg2IATAAIAWAqIApgqIAWAAIg3A3IAeA2gANuGSIBZgmIhZgnIAAgSIBxAzIAAAMIhxAygAjaFzIAAgPIBhAAIAAAPgAHkEsIAAgTIAVAAIAAATgAxVBNIAAAAQAMgJAMgMQAMgMAJgQQALgSAGgQQAGgSAAgUQAAgVgGgRQgHgSgKgMIAAgBIAUAAQAJAOAGARQAGARAAASQAAASgFASQgFAQgIAQQgJAQgLAOQgMAOgNAMgAz8BNQgJgOgGgQQgFgRAAgSQAAgRAEgRQAFgRAIgRQAJgQALgOQAMgOAOgNIAWAAIAAABQgLAIgMANQgMANgKAPQgKAPgGATQgGATAAATQAAAVAGARQAGASAKAMIAAAAgAAEBDQgIgDgHgDIAAgVIABAAQAJAHAIAEQALADAKAAQAMAAAHgEQAGgDAAgJQAAgGgDgEQgEgDgKgCIgLgCIgLgDQgOgEgEgHQgHgHAAgJQAAgHADgGQADgGAFgFQAEgEAJgDQAIgCALAAQAJAAAKACQAKACAHAEIAAATIgBAAQgHgFgKgDQgKgEgKAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAFABAJACIALACIALADQAMADAHAHQAHAHAAAMQAAAPgMAJQgMAKgWAAQgMAAgKgDgAU3BDIAAgpIhGAAIAAgWIBHhQIASAAIAABXIAVAAIAAAPIgVAAIAAApgAT/ALIA4AAIAAhAgAQZBDIAAgPIBwAAIAAAPgAOSBDIgXgpIgoApIgXAAIA4g3Igeg0IAUAAIAXAoIAogoIAXAAIg4A1IAfA2gAJyBDIAAgPIBwAAIAAAPgAGuBDIAAgPIAfAAIAAhfIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACBIAeAAIAAAPgABjBDIAAhrIASAAIAABrgAliBDIAAgpIhFAAIAAgWIBGhQIASAAIAABXIAWAAIAAAPIgWAAIAAApgAmaALIA4AAIAAhAgAQZgIIAAgMIBwgvIAAASIhXAjIBXAiIAAASgAJygIIAAgMIBwgvIAAASIhXAjIBXAiIAAASgAx0AlIgXgnIgoAnIgXAAIA4g1Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA0gA1eAlIAVhcIgMAAIADgPIANAAIAAgDQAEgUAMgKQAMgLASAAIALABIAJABIgEAQIAAAAIgIgBIgIgBQgMAAgGAGQgGAGgEAMIAAAEIAhAAIgEAPIggAAIgWBcgAEjALIAAgNIBhAAIAAANgABhg6IAAgTIAVAAIAAATgAGrkZQgKgDgHgDIAAgVIABAAQAJAHAKAEQALADAKAAQAMAAAHgEQAGgDAAgJQAAgGgDgEQgEgDgKgCIgLgCIgLgDQgPgEgFgHQgHgHAAgLQAAgHADgGQADgGAGgFQAFgEAJgDQAIgCALAAQAJAAAKACQAKACAHAEIAAATIgBAAQgHgFgKgDQgKgEgKAAQgKAAgHAEQgHAEAAAHQAAAHAEAEQAFADAJACIALACIALADQAMADAHAHQAHAHAAAMQAAAPgMAJQgMAKgWAAQgMAAgKgDgAQFkZIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACDIAeAAIAAAPgALEkZIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAIKkZIAAhtIASAAIAABtgAAGkZIAAgUIAVgSIATgRQASgSAHgLQAHgLAAgMQAAgLgHgHQgIgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgMANIgWAUIgVASIBOAAIAAAQgAlVkZIgfgqIggAqIgVAAIArg2Igqg3IAXAAIAeApIAfgpIAWAAIgrA2IArA3gAiokbIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAMElSIAAgMIBxgzIAAASIhZAnIBZAmIAAASgAOelQIAAgRIA9AAIAAARgAIImYIAAgTIAVAAIAAATg");
	this.shape.setTransform(163.2,103.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(2));

	// formula
	this.text = new cjs.Text("=", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(63,89+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZGgIAAjfQAAhXgTgoQgRgngvgJIAAglQAvgIARgnQATgoAAhWIAAjfIAhAAIAADcQABBngaAqQgZAsg6AEIAAAFQA7AFAZAqQAYArAABmIAADdg");
	this.shape_1.setTransform(103.3,105.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.text}]}).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.7,60.3,275.2,86.8);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.valors_3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("0", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(73,119+incremento);

	this.text_1 = new cjs.Text("1", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(73,59+incremento);

	this.text_2 = new cjs.Text("2", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(68.2,0+incremento);

	this.text_3 = new cjs.Text("6", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(4.2,119+incremento);

	this.text_4 = new cjs.Text("5", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(5.6,59+incremento);

	this.text_5 = new cjs.Text("4", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(4.2,0+incremento);

	this.addChild(this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(4.2,0,85.7,147.3);


(lib.valors_1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("1", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(73,119+incremento);

	this.text_1 = new cjs.Text("0", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(73,59+incremento);

	this.text_2 = new cjs.Text("–1", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(64,0+incremento);

	this.text_3 = new cjs.Text("–1", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(0,119+incremento);

	this.text_4 = new cjs.Text("–2", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(0,59+incremento);

	this.text_5 = new cjs.Text("–3", "20px Verdana");
	this.text_5.lineHeight = 22;
this.text_5.setTransform(0,incremento);
	this.addChild(this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,93.6,147.3);


(lib.text1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Hacemos una tabla de valores:", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(-158.1,-13.9);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-158.1,-13.9,316.3,28.3);


(lib.text_pant_4 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Hacemos una tabla de valores:", "20px Verdana");
	this.text.lineHeight = 22;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,316.3,28.3);


(lib.taula_sense_valors = function() {
	this.initialize();

	// Capa 2
	this.text = new cjs.Text("y", "italic bold 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(98,1+incremento);

	this.text_1 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(28,1+incremento);

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAQZMAAAggx");
	this.shape.setTransform(74,105);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AroAAIXRAA");
	this.shape_1.setTransform(74.5,155);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AroAAIXRAA");
	this.shape_2.setTransform(74.5,96);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AroAAIXRAA");
	this.shape_3.setTransform(74.5,37);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("ALuwdMAAAAg7I3bAAMAAAgg7g");
	this.shape_4.setTransform(75,105.5);

	this.addChild(this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,150,211);


(lib.segontram = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("4 si  –1 ≤ x ≤ 4", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(74,1);

	this.text_1 = new cjs.Text("f(x)", "italic 20px Verdana");
	this.text_1.lineHeight = 22;

	this.text_2 = new cjs.Text("=", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(43,3+incremento);

	this.addChild(this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,238.8,31.3);


(lib.primertram = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("x + 2    si x<-1", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(74,1);

	this.text_1 = new cjs.Text("f(x)", "italic 20px Verdana");
	this.text_1.lineHeight = 22;

	this.text_2 = new cjs.Text("=", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(43,3+incremento);

	this.addChild(this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,234.4,31.3);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_pant_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// formula
	this.instance = new lib.primertram("synched",0);
	this.instance.setTransform(139.1,25.5,1,1,0,0,0,117.1,15.5);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AtmBgIAAAAQAMgJALgNQAMgMAKgQQALgSAGgSQAFgPABgUQAAgVgHgRQgGgSgLgMIAAgBIAVAAQAJAOAFARQAHAQAAATQgBASgEAQQgFARgIAQQgJARgLAOQgMAOgNAMgAwNBgQgKgOgFgRQgGgQABgTQgBgSAFgPQAEgRAJgRQAJgQALgOQAMgOAOgNIAWAAIAAABQgMAIgMANQgLANgKAPQgKAPgHATQgFAQAAAVQAAAVAFASQAHASAKAMIAAAAgAHIBCQgKgDgHgDIAAgVIAAAAQAKAGAKAEQALAEAKAAQALAAAIgEQAGgDAAgJQAAgGgDgEQgEgDgLgDIgKgCIgMgCQgOgEgFgHQgHgGAAgKQAAgHADgGQADgGAFgFQAGgEAJgDQAIgDALABQAJAAAKABQAKADAGAEIAAATIAAAAQgIgFgJgDQgLgEgJAAQgKAAgHAEQgHADAAAIQAAAHAEADQAEADAJABIAMACIALADQAMACAHAIQAHAGAAANQAAAOgNAKQgMAKgVAAQgMAAgKgDgAQiBCIAAgPIAeAAIAAhfIgeAAIAAgOIANgBQAHgBADgBQAFgDACgEQADgEABgGIAOAAIAACBIAfAAIAAAPgALgBCIgWgpIgpApIgWAAIA4g3Igfg0IAVAAIAWApIApgpIAWAAIg3A1IAeA2gAImBCIAAhrIASAAIAABrgAAiBCIAAgVIAVgRIAUgSQASgPAHgLQAHgLAAgNQAAgKgIgHQgHgHgNABQgJAAgKACQgLADgJAHIgBAAIAAgUQAGgEAMgDQALgCALAAQAXgBAMAMQANAKAAASQAAAJgCAHQgCAIgFAFQgDAHgFAFIgNALIgVAUIgVASIBOAAIAAARgAlDBCIgWgpIgpApIgWAAIA4g3Igfg0IAVAAIAWApIApgpIAWAAIg4A1IAfA2gAiLA/IAAg1Ig1AAIAAgOIA1AAIAAg1IAQAAIAAA1IA1AAIAAAOIg1AAIAAA1gAMhAJIAAgKIBxgzIAAASIhZAkIBZAnIAAARgAuFA4IgXgpIgoApIgXAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAxvA4IAVhcIgMAAIADgPIANAAIAAgDQAEgUAMgLQAMgKASAAIALAAIAJACIgEAQIAAAAIgIgCIgIAAQgNgBgFAHQgHAFgDANIAAAEIAgAAIgDAPIghAAIgVBcgAqsAzIAAgQIB0AAIAAAQgAO6ALIAAgQIA9AAIAAAQgAqsAJIAAgNIB0AAIAAANgAIlg8IAAgTIAVAAIAAATg");
	this.shape.setTransform(138.4,26.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape}]},6).wait(252));

	// mascara_funcio (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_200 = new cjs.Graphics().p("Ag5KqIAA1TIB0AAIAAVTg");
	var mask_graphics_201 = new cjs.Graphics().p("AhSKqIAA1TIClAAIAAVTg");
	var mask_graphics_202 = new cjs.Graphics().p("AhrKqIAA1TIDXAAIAAVTg");
	var mask_graphics_203 = new cjs.Graphics().p("AiDKqIAA1TIEHAAIAAVTg");
	var mask_graphics_204 = new cjs.Graphics().p("AicKqIAA1TIE5AAIAAVTg");
	var mask_graphics_205 = new cjs.Graphics().p("Ai0KqIAA1TIFpAAIAAVTg");
	var mask_graphics_206 = new cjs.Graphics().p("AjNKqIAA1TIGbAAIAAVTg");
	var mask_graphics_207 = new cjs.Graphics().p("AjmKqIAA1TIHNAAIAAVTg");
	var mask_graphics_208 = new cjs.Graphics().p("Aj+KqIAA1TIH9AAIAAVTg");
	var mask_graphics_209 = new cjs.Graphics().p("AkXKqIAA1TIIvAAIAAVTg");
	var mask_graphics_210 = new cjs.Graphics().p("AkvKqIAA1TIJfAAIAAVTg");
	var mask_graphics_211 = new cjs.Graphics().p("AlIKqIAA1TIKRAAIAAVTg");
	var mask_graphics_212 = new cjs.Graphics().p("AlhKqIAA1TILDAAIAAVTg");
	var mask_graphics_213 = new cjs.Graphics().p("Al5KqIAA1TILzAAIAAVTg");
	var mask_graphics_214 = new cjs.Graphics().p("AmSKqIAA1TIMlAAIAAVTg");
	var mask_graphics_215 = new cjs.Graphics().p("AmqKqIAA1TINWAAIAAVTg");
	var mask_graphics_216 = new cjs.Graphics().p("AnDKqIAA1TIOHAAIAAVTg");
	var mask_graphics_217 = new cjs.Graphics().p("AncKqIAA1TIO5AAIAAVTg");
	var mask_graphics_218 = new cjs.Graphics().p("An0KqIAA1TIPpAAIAAVTg");
	var mask_graphics_219 = new cjs.Graphics().p("AoNKqIAA1TIQbAAIAAVTg");
	var mask_graphics_220 = new cjs.Graphics().p("AolKqIAA1TIRMAAIAAVTg");
	var mask_graphics_221 = new cjs.Graphics().p("Ao+KqIAA1TIR9AAIAAVTg");
	var mask_graphics_222 = new cjs.Graphics().p("ApXKqIAA1TISvAAIAAVTg");
	var mask_graphics_223 = new cjs.Graphics().p("ApvKqIAA1TITfAAIAAVTg");
	var mask_graphics_224 = new cjs.Graphics().p("AqIKqIAA1TIURAAIAAVTg");
	var mask_graphics_225 = new cjs.Graphics().p("EApAAU1IAA1SIVEAAIAAVSg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(200).to({graphics:mask_graphics_200,x:665.7,y:198.6}).wait(1).to({graphics:mask_graphics_201,x:668.1,y:198.6}).wait(1).to({graphics:mask_graphics_202,x:670.6,y:198.6}).wait(1).to({graphics:mask_graphics_203,x:673,y:198.6}).wait(1).to({graphics:mask_graphics_204,x:675.5,y:198.6}).wait(1).to({graphics:mask_graphics_205,x:678,y:198.6}).wait(1).to({graphics:mask_graphics_206,x:680.4,y:198.6}).wait(1).to({graphics:mask_graphics_207,x:682.9,y:198.6}).wait(1).to({graphics:mask_graphics_208,x:685.3,y:198.6}).wait(1).to({graphics:mask_graphics_209,x:687.8,y:198.6}).wait(1).to({graphics:mask_graphics_210,x:690.3,y:198.6}).wait(1).to({graphics:mask_graphics_211,x:692.7,y:198.6}).wait(1).to({graphics:mask_graphics_212,x:695.2,y:198.6}).wait(1).to({graphics:mask_graphics_213,x:697.6,y:198.6}).wait(1).to({graphics:mask_graphics_214,x:700.1,y:198.6}).wait(1).to({graphics:mask_graphics_215,x:702.6,y:198.6}).wait(1).to({graphics:mask_graphics_216,x:705,y:198.6}).wait(1).to({graphics:mask_graphics_217,x:707.5,y:198.6}).wait(1).to({graphics:mask_graphics_218,x:709.9,y:198.6}).wait(1).to({graphics:mask_graphics_219,x:712.4,y:198.6}).wait(1).to({graphics:mask_graphics_220,x:714.9,y:198.6}).wait(1).to({graphics:mask_graphics_221,x:717.3,y:198.6}).wait(1).to({graphics:mask_graphics_222,x:719.8,y:198.6}).wait(1).to({graphics:mask_graphics_223,x:722.2,y:198.6}).wait(1).to({graphics:mask_graphics_224,x:724.7,y:198.6}).wait(1).to({graphics:mask_graphics_225,x:397.3,y:133.4}).wait(33));

	// linia
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AonnYIRPOx");
	this.shape_1.setTransform(741.8,199);

	this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},200).wait(58));

	// punts
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_2.setTransform(685.3,147.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAtgyQATAVAAAdQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVg");
	this.shape_3.setTransform(713.7,176.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_4.setTransform(713.7,176.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AAtgyQATAVAAAdQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVg");
	this.shape_5.setTransform(685.3,147.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_6.setTransform(745.3,202.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_7.setTransform(745.3,202.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_8.setTransform(685.3,147.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2,p:{x:685.3,y:147.6}}]},68).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},49).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_4},{t:this.shape_2,p:{x:713.7,y:176.2}}]},47).wait(94));

	// valors
	this.instance_1 = new lib.valors_3("synched",0);
	this.instance_1.setTransform(144.8,238.5,1,1,0,0,0,46.8,73.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30).to({startPosition:0,_off:false},0).wait(228));

	// resaltats
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(255,153,51,0.498)").s().p("AjlCGIAAkMIHKAAIAAEMg");
	this.shape_9.setTransform(182,180.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,153,51,0.498)").s().p("AjlCGIAAkMIHKAAIAAEMg");
	this.shape_10.setTransform(113,180.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10,p:{x:113,y:180.6}},{t:this.shape_9,p:{x:182,y:180.6}}]},49).to({state:[{t:this.shape_10,p:{x:111.5,y:238.9}},{t:this.shape_9,p:{x:180.5,y:238.9}}]},45).to({state:[{t:this.shape_10,p:{x:109.1,y:298.1}},{t:this.shape_9,p:{x:178.1,y:298.1}}]},47).to({state:[]},90).wait(27));

	// taula
	this.instance_2 = new lib.taula_sense_valors("synched",0);
	this.instance_2.setTransform(145,221.6,1,1,0,0,0,75,105.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({startPosition:0,_off:false},0).wait(235));

	// text1
	this.instance_3 = new lib.text1("synched",0);
	this.instance_3.setTransform(157.2,78);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(15).to({startPosition:0,_off:false},0).wait(243));

	// grafica
	this.instance_4 = new lib.Mapadebits2();
	this.instance_4.setTransform(684.7,0.2);

	this.instance_5 = new lib.Mapadebits1();
	this.instance_5.setTransform(521.7,4.5);

	this.text = new cjs.Text("7", "14px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(767.8,207.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_11.setTransform(687,87.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_12.setTransform(687,87.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_13.setTransform(522.3,86.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_14.setTransform(522.3,86.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2,1,1).p("AsyAAIZlAA");
	this.shape_15.setTransform(604.5,87.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(2,1,1).p("ApVGoISrtP");
	this.shape_16.setTransform(460.9,225.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_17.setTransform(524.2,180.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_18.setTransform(495.4,200.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_19.setTransform(495.4,200.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2,1,1).p("ABAAAQAAAdgTAVQgTAVgaAAQgZAAgTgVQgTgVAAgdQAAgdATgVQATgVAZAAQAaAAATAVQATAVAAAdg");
	this.shape_20.setTransform(465.8,218.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAyQgTgUAAgeQAAgdATgVQATgVAZABQAagBATAVQATAVAAAdQAAAegTAUQgTAWgaAAQgZAAgTgWg");
	this.shape_21.setTransform(465.8,218.9);

	this.text_1 = new cjs.Text("-2", "14px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(482.8,207);

	this.text_2 = new cjs.Text("-3", "14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(452.8,207);

	this.text_3 = new cjs.Text("-4", "14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(422.2,207);

	this.text_4 = new cjs.Text("-5", "14px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(392.8,207);

	this.text_5 = new cjs.Text("-6", "14px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(362.8,207);

	this.text_6 = new cjs.Text("-7", "14px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(332.2,207);

	this.text_7 = new cjs.Text("6", "14px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(738.9,207.8);

	this.text_8 = new cjs.Text("5", "14px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(708.9,207.8);

	this.text_9 = new cjs.Text("4", "14px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(678.3,207.8);

	this.text_10 = new cjs.Text("3", "14px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(648.9,207.8);

	this.text_11 = new cjs.Text("2", "14px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(618.9,207.8);

	this.text_12 = new cjs.Text("1", "14px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(587.1,206.6);

	this.text_13 = new cjs.Text("0", "14px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(561.3,205.6);

	this.text_14 = new cjs.Text("-1", "14px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(515.7,207.9);

	this.text_15 = new cjs.Text("-2", "14px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(533.7,238);

	this.text_16 = new cjs.Text("-3", "14px Verdana");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(534.4,268.9);

	this.text_17 = new cjs.Text("-4", "14px Verdana");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(533.7,296.1);

	this.text_18 = new cjs.Text("-5", "14px Verdana");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(533.7,326.2);

	this.text_19 = new cjs.Text("-6", "14px Verdana");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(534.4,357.1);

	this.text_20 = new cjs.Text("6", "14px Verdana");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(538.5,15.6);

	this.text_21 = new cjs.Text("5", "14px Verdana");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(538.5,45.8);

	this.text_22 = new cjs.Text("4", "14px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(539.2,76.6);

	this.text_23 = new cjs.Text("3", "14px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(538.5,103.8);

	this.text_24 = new cjs.Text("2", "14px Verdana");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(538.5,134);

	this.text_25 = new cjs.Text("1", "14px Verdana");
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(539.2,164.8);

	this.text_26 = new cjs.Text("0", "14px Verdana");
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(548.7,182);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_22.setTransform(561.7,177.3,1,1,-89.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_23.setTransform(561.7,147.3,1,1,-89.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_24.setTransform(561.7,117.3,1,1,-89.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_25.setTransform(561.7,87.3,1,1,-89.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_26.setTransform(561.7,57.8,1,1,-89.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_27.setTransform(561.7,27.8,1,1,-89.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_28.setTransform(561.7,368.7,1,1,-89.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_29.setTransform(561.7,338.7,1,1,-89.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_30.setTransform(561.7,308.7,1,1,-89.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_31.setTransform(561.7,278.7,1,1,-89.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_32.setTransform(561.7,249.2,1,1,-89.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_33.setTransform(561.7,219.2,1,1,-89.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_34.setTransform(595.6,200.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_35.setTransform(625.6,200.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_36.setTransform(655.6,200.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_37.setTransform(685.1,200.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_38.setTransform(715.1,200.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_39.setTransform(745.1,200.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_40.setTransform(775.1,200.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_41.setTransform(345.7,199.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_42.setTransform(375.7,199.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_43.setTransform(405.7,199.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_44.setTransform(435.2,199.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_45.setTransform(465.2,199.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_46.setTransform(495.2,199.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_47.setTransform(525.2,199.6);

	this.text_27 = new cjs.Text("x", "italic 18px Verdana");
	this.text_27.lineHeight = 20;
	this.text_27.lineWidth = 144;
	this.text_27.setTransform(781,197.3+incremento);

	this.text_28 = new cjs.Text("y", "italic 18px Verdana");
	this.text_28.lineHeight = 20;
	this.text_28.lineWidth = 144;
	this.text_28.setTransform(566.4,-7.5+incremento);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#000000").ss(2,1,1).p("EAjoAAAMhHQAAA");
	this.shape_48.setTransform(554.3,200.1,1,1,0,0,0,-6.6,0);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(2,1,1).p("AAA9RMAAAA6j");
	this.shape_49.setTransform(561.7,190.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,153,0,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_50.setTransform(740.2,189.8,0.569,1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(0,204,255,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_51.setTransform(604.8,190.4,0.856,1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(0,153,51,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_52.setTransform(429,190.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.text_28},{t:this.text_27},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.text},{t:this.instance_5},{t:this.instance_4}]}).wait(258));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22,-7.5,907,389.1);


(lib.mc_pant_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// formula
	this.instance = new lib.segontram("synched",0);
	this.instance.setTransform(139.1,25.5,1,1,0,0,0,117.1,15.5);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AuCBgIAAAAQAMgJALgNQAMgMAKgQQALgSAGgSQAFgPABgUQAAgVgHgRQgGgSgLgMIAAgBIAVAAQAJAOAFARQAHAQAAATQgBASgEAQQgFARgIAQQgJARgLAOQgMAOgNAMgAwpBgQgKgOgFgRQgGgQABgTQgBgSAFgPQAEgRAJgRQAJgQALgOQAMgOAOgNIAWAAIAAABQgMAIgMANQgLANgKAPQgKAPgHATQgFAQAAAVQAAAVAFASQAHASAKAMIAAAAgAjNBCQgKgDgHgDIAAgVIABAAQAJAGALAEQAKAEAKAAQAMAAAHgEQAGgDABgJQgBgGgDgEQgDgDgLgDIgKgCIgMgCQgPgEgFgHQgHgGABgKQAAgHADgGQADgGAFgFQAGgEAIgDQAJgDAKABQAKAAAKABQAJADAHAEIAAATIgBAAQgHgFgKgDQgKgEgKAAQgJAAgIAEQgGADAAAIQAAAHADADQAFADAJABIAMACIAKADQAMACAHAIQAIAGgBANQAAAOgMAKQgMAKgVAAQgMAAgLgDgARkBCIAAgpIhFAAIAAgXIBGhQIASAAIAABXIAWAAIAAAQIgWAAIAAApgAQsAJIA4AAIAAg/gANGBCIAAgPIBxAAIAAAPgAK/BCIgWgpIgpApIgXAAIA4g3Igeg0IAUAAIAXApIAogpIAXAAIg4A1IAfA2gAGfBCIAAgPIBwAAIAAAPgADcBCIAAgPIAeAAIAAhfIgeAAIAAgOIANgBQAHgBADgBQAFgDACgEQADgEABgGIAOAAIAACBIAfAAIAAAPgAhuBCIAAhrIASAAIAABrgAlhBCIAAgpIhGAAIAAgXIBHhQIASAAIAABXIAVAAIAAAQIgVAAIAAApgAmZAJIA4AAIAAg/gAuhA4IgXgpIgoApIgXAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAyLA4IAVhcIgMAAIADgPIANAAIAAgDQAEgUAMgLQAMgKASAAIALAAIAJACIgEAQIAAAAIgIgCIgIAAQgNgBgFAHQgHAFgDANIAAAEIAgAAIgDAPIghAAIgVBcgArIAzIAAgQIB0AAIAAAQgANGgJIAAgMIBxgvIAAASIhYAjIBYAiIAAARgAGfgJIAAgMIBwgvIAAASIhXAjIBXAiIAAARgABQAKIAAgOIBhAAIAAAOgArIAJIAAgNIB0AAIAAANgAhvg8IAAgTIAUAAIAAATg");
	this.shape.setTransform(141.2,26.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape}]},6).wait(48));

	// mascara_linia (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_30 = new cjs.Graphics().p("AhlD0IAAnnIDLAAIAAHng");
	var mask_graphics_31 = new cjs.Graphics().p("AicD0IAAnnIE5AAIAAHng");
	var mask_graphics_32 = new cjs.Graphics().p("AjUD0IAAnnIGpAAIAAHng");
	var mask_graphics_33 = new cjs.Graphics().p("AkLD0IAAnnIIXAAIAAHng");
	var mask_graphics_34 = new cjs.Graphics().p("AlCD0IAAnnIKFAAIAAHng");
	var mask_graphics_35 = new cjs.Graphics().p("Al5D0IAAnnILzAAIAAHng");
	var mask_graphics_36 = new cjs.Graphics().p("AmwD0IAAnnINhAAIAAHng");
	var mask_graphics_37 = new cjs.Graphics().p("AnoD0IAAnnIPRAAIAAHng");
	var mask_graphics_38 = new cjs.Graphics().p("AofD0IAAnnIQ/AAIAAHng");
	var mask_graphics_39 = new cjs.Graphics().p("ApWD0IAAnnIStAAIAAHng");
	var mask_graphics_40 = new cjs.Graphics().p("AqND0IAAnnIUbAAIAAHng");
	var mask_graphics_41 = new cjs.Graphics().p("ArED0IAAnnIWJAAIAAHng");
	var mask_graphics_42 = new cjs.Graphics().p("Ar8D0IAAnnIX5AAIAAHng");
	var mask_graphics_43 = new cjs.Graphics().p("AszD0IAAnnIZnAAIAAHng");
	var mask_graphics_44 = new cjs.Graphics().p("AtqD0IAAnnIbVAAIAAHng");
	var mask_graphics_45 = new cjs.Graphics().p("AuhD0IAAnnIdDAAIAAHng");
	var mask_graphics_46 = new cjs.Graphics().p("AvYD0IAAnnIexAAIAAHng");
	var mask_graphics_47 = new cjs.Graphics().p("AwQD0IAAnnMAghAAAIAAHng");
	var mask_graphics_48 = new cjs.Graphics().p("AVMIQIAAnqMAiRAAAIAAHqg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(30).to({graphics:mask_graphics_30,x:500.9,y:81.2}).wait(1).to({graphics:mask_graphics_31,x:506.4,y:81.2}).wait(1).to({graphics:mask_graphics_32,x:512,y:81.2}).wait(1).to({graphics:mask_graphics_33,x:517.5,y:81.2}).wait(1).to({graphics:mask_graphics_34,x:523,y:81.2}).wait(1).to({graphics:mask_graphics_35,x:528.5,y:81.2}).wait(1).to({graphics:mask_graphics_36,x:534,y:81.2}).wait(1).to({graphics:mask_graphics_37,x:539.6,y:81.2}).wait(1).to({graphics:mask_graphics_38,x:545.1,y:81.2}).wait(1).to({graphics:mask_graphics_39,x:550.6,y:81.2}).wait(1).to({graphics:mask_graphics_40,x:556.1,y:81.2}).wait(1).to({graphics:mask_graphics_41,x:561.6,y:81.2}).wait(1).to({graphics:mask_graphics_42,x:567.2,y:81.2}).wait(1).to({graphics:mask_graphics_43,x:572.7,y:81.2}).wait(1).to({graphics:mask_graphics_44,x:578.2,y:81.2}).wait(1).to({graphics:mask_graphics_45,x:583.7,y:81.2}).wait(1).to({graphics:mask_graphics_46,x:589.2,y:81.2}).wait(1).to({graphics:mask_graphics_47,x:594.8,y:81.2}).wait(1).to({graphics:mask_graphics_48,x:354.9,y:52.8}).wait(6));

	// linea
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_1.setTransform(687,87.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_2.setTransform(687,87.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAAAuQgSAAgNgNQgOgOAAgTQAAgSAOgNQANgOASAAQATAAANAOQAOANAAASQAAATgOAOQgNANgTAAg");
	this.shape_3.setTransform(522.3,86.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(0,0,0,0.498)").s().p("AggAhQgNgOAAgTQAAgSANgOQAOgNASAAQATAAANANQAOAOAAASQAAATgOAOQgNANgTAAQgSAAgOgNg");
	this.shape_4.setTransform(522.3,86.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AsyAAIZlAA");
	this.shape_5.setTransform(604.5,87.2);

	this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},30).wait(24));

	// mascara_funcio (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AQWW7IAA0PIZdAAIAAUPg");
	mask_1.setTransform(267.5,146.7);

	// funcio
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("ApVGoISrtP");
	this.shape_6.setTransform(460.9,225.3);

	this.shape_6.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6}]}).wait(54));

	// resaltats
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_7.setTransform(524.2,180.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_8.setTransform(495.4,200.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_9.setTransform(495.4,200.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_10.setTransform(465.8,218.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_11.setTransform(465.8,218.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(54));

	// mascara (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AtMeGMAAAg8LMBLcAAAMAAAA8Lg");
	mask_2.setTransform(398.5,189.5);

	// numeros
	this.text = new cjs.Text("7", "14px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(768.8,207.8);

	this.text_1 = new cjs.Text("-2", "14px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(482.8,207);

	this.text_2 = new cjs.Text("-3", "14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(452.8,207);

	this.text_3 = new cjs.Text("-4", "14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(422.2,207);

	this.text_4 = new cjs.Text("-5", "14px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(392.8,207);

	this.text_5 = new cjs.Text("-6", "14px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(362.8,207);

	this.text_6 = new cjs.Text("-7", "14px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(332.2,207);

	this.text_7 = new cjs.Text("6", "14px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(738.9,207.8);

	this.text_8 = new cjs.Text("5", "14px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(708.9,207.8);

	this.text_9 = new cjs.Text("4", "14px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(678.3,207.8);

	this.text_10 = new cjs.Text("3", "14px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(648.9,207.8);

	this.text_11 = new cjs.Text("2", "14px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(618.9,207.8);

	this.text_12 = new cjs.Text("1", "14px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(587.1,206.6);

	this.text_13 = new cjs.Text("0", "14px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(561.3,205.6);

	this.text_14 = new cjs.Text("-1", "14px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(515.7,207.9);

	this.text_15 = new cjs.Text("-2", "14px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(533.7,238);

	this.text_16 = new cjs.Text("-3", "14px Verdana");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(534.4,268.9);

	this.text_17 = new cjs.Text("-4", "14px Verdana");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(533.7,296.1);

	this.text_18 = new cjs.Text("-5", "14px Verdana");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(533.7,326.2);

	this.text_19 = new cjs.Text("-6", "14px Verdana");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(534.4,357.1);

	this.text_20 = new cjs.Text("6", "14px Verdana");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(538.5,15.6);

	this.text_21 = new cjs.Text("5", "14px Verdana");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(538.5,45.8);

	this.text_22 = new cjs.Text("4", "14px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(539.2,76.6);

	this.text_23 = new cjs.Text("3", "14px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(538.5,103.8);

	this.text_24 = new cjs.Text("2", "14px Verdana");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(538.5,134);

	this.text_25 = new cjs.Text("1", "14px Verdana");
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(539.2,164.8);

	this.text_26 = new cjs.Text("0", "14px Verdana");
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(548.7,182);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.text_18.mask = this.text_19.mask = this.text_20.mask = this.text_21.mask = this.text_22.mask = this.text_23.mask = this.text_24.mask = this.text_25.mask = this.text_26.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(54));

	// numeracio_eixos
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_12.setTransform(561.7,177.3,1,1,-89.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_13.setTransform(561.7,147.3,1,1,-89.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_14.setTransform(561.7,117.3,1,1,-89.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_15.setTransform(561.7,87.3,1,1,-89.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_16.setTransform(561.7,57.8,1,1,-89.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_17.setTransform(561.7,27.8,1,1,-89.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_18.setTransform(561.7,368.7,1,1,-89.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_19.setTransform(561.7,338.7,1,1,-89.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_20.setTransform(561.7,308.7,1,1,-89.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_21.setTransform(561.7,278.7,1,1,-89.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_22.setTransform(561.7,249.2,1,1,-89.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_23.setTransform(561.7,219.2,1,1,-89.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_24.setTransform(595.6,200.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_25.setTransform(625.6,200.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_26.setTransform(655.6,200.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_27.setTransform(685.1,200.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_28.setTransform(715.1,200.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_29.setTransform(745.1,200.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_30.setTransform(775.1,200.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_31.setTransform(345.7,199.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_32.setTransform(375.7,199.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_33.setTransform(405.7,199.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_34.setTransform(435.2,199.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_35.setTransform(465.2,199.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_36.setTransform(495.2,199.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_37.setTransform(525.2,199.6);

	this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.shape_36.mask = this.shape_37.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]}).wait(54));

	// eixos
	this.text_27 = new cjs.Text("x", "italic 18px Verdana");
	this.text_27.lineHeight = 20;
	this.text_27.lineWidth = 144;
	this.text_27.setTransform(781,197.3+incremento);

	this.text_28 = new cjs.Text("y", "italic 18px Verdana");
	this.text_28.lineHeight = 20;
	this.text_28.lineWidth = 144;
	this.text_28.setTransform(566.4,-7.5+incremento);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#000000").ss(2,1,1).p("EAjoAAAMhHQAAA");
	this.shape_38.setTransform(554.3,200.1,1,1,0,0,0,-6.6,0);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(2,1,1).p("AAA9RMAAAA6j");
	this.shape_39.setTransform(561.7,190.5);

	this.text_27.mask = this.text_28.mask = this.shape_38.mask = this.shape_39.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.text_28},{t:this.text_27}]}).wait(54));

	// linia_verda
	this.instance_1 = new lib.Mapadebits1();
	this.instance_1.setTransform(521.7,4.5);

	this.instance_1.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(54));

	// pastilla_verda
	this.instance_2 = new lib.Mapadebits2();
	this.instance_2.setTransform(684.7,0.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,153,0,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_40.setTransform(740.2,189.8,0.569,1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(0,204,255,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_41.setTransform(604.8,190.4,0.856,1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(0,153,51,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_42.setTransform(429,190.4);

	this.instance_2.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.instance_2}]}).wait(54));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22,-7.5,907,389.1);


(lib.mc_pant_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// formula
	this.instance = new lib.primertram("synched",0);
	this.instance.setTransform(139.1,25.5,1,1,0,0,0,117.1,15.5);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AtmBgIAAAAQAMgJALgNQAMgMAKgQQALgSAGgSQAFgPABgUQAAgVgHgRQgGgSgLgMIAAgBIAVAAQAJAOAFARQAHAQAAATQgBASgEAQQgFARgIAQQgJARgLAOQgMAOgNAMgAwNBgQgKgOgFgRQgGgQABgTQgBgSAFgPQAEgRAJgRQAJgQALgOQAMgOAOgNIAWAAIAAABQgMAIgMANQgLANgKAPQgKAPgHATQgFAQAAAVQAAAVAFASQAHASAKAMIAAAAgAHIBCQgKgDgHgDIAAgVIAAAAQAKAGAKAEQALAEAKAAQALAAAIgEQAGgDAAgJQAAgGgDgEQgEgDgLgDIgKgCIgMgCQgOgEgFgHQgHgGAAgKQAAgHADgGQADgGAFgFQAGgEAJgDQAIgDALABQAJAAAKABQAKADAGAEIAAATIAAAAQgIgFgJgDQgLgEgJAAQgKAAgHAEQgHADAAAIQAAAHAEADQAEADAJABIAMACIALADQAMACAHAIQAHAGAAANQAAAOgNAKQgMAKgVAAQgMAAgKgDgAQiBCIAAgPIAeAAIAAhfIgeAAIAAgOIANgBQAHgBADgBQAFgDACgEQADgEABgGIAOAAIAACBIAfAAIAAAPgALgBCIgWgpIgpApIgWAAIA4g3Igfg0IAVAAIAWApIApgpIAWAAIg3A1IAeA2gAImBCIAAhrIASAAIAABrgAAiBCIAAgVIAVgRIAUgSQASgPAHgLQAHgLAAgNQAAgKgIgHQgHgHgNABQgJAAgKACQgLADgJAHIgBAAIAAgUQAGgEAMgDQALgCALAAQAXgBAMAMQANAKAAASQAAAJgCAHQgCAIgFAFQgDAHgFAFIgNALIgVAUIgVASIBOAAIAAARgAlDBCIgWgpIgpApIgWAAIA4g3Igfg0IAVAAIAWApIApgpIAWAAIg4A1IAfA2gAiLA/IAAg1Ig1AAIAAgOIA1AAIAAg1IAQAAIAAA1IA1AAIAAAOIg1AAIAAA1gAMhAJIAAgKIBxgzIAAASIhZAkIBZAnIAAARgAuFA4IgXgpIgoApIgXAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAxvA4IAVhcIgMAAIADgPIANAAIAAgDQAEgUAMgLQAMgKASAAIALAAIAJACIgEAQIAAAAIgIgCIgIAAQgNgBgFAHQgHAFgDANIAAAEIAgAAIgDAPIghAAIgVBcgAqsAzIAAgQIB0AAIAAAQgAO6ALIAAgQIA9AAIAAAQgAqsAJIAAgNIB0AAIAAANgAIlg8IAAgTIAVAAIAAATg");
	this.shape.setTransform(138.4,26.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.shape}]},6).wait(322));

	// valors
	this.instance_1 = new lib.valors_1("synched",0);
	this.instance_1.setTransform(144.8,238.5,1,1,0,0,0,46.8,73.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(112).to({startPosition:0,_off:false},0).to({alpha:1},8).wait(208));

	// mascara_funcio (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_299 = new cjs.Graphics().p("AhWKHIAA0NICtAAIAAUNg");
	var mask_graphics_300 = new cjs.Graphics().p("AhwKHIAA0NIDhAAIAAUNg");
	var mask_graphics_301 = new cjs.Graphics().p("AiKKHIAA0NIEVAAIAAUNg");
	var mask_graphics_302 = new cjs.Graphics().p("AikKHIAA0NIFJAAIAAUNg");
	var mask_graphics_303 = new cjs.Graphics().p("Ai+KHIAA0NIF9AAIAAUNg");
	var mask_graphics_304 = new cjs.Graphics().p("AjYKHIAA0NIGxAAIAAUNg");
	var mask_graphics_305 = new cjs.Graphics().p("AjyKHIAA0NIHlAAIAAUNg");
	var mask_graphics_306 = new cjs.Graphics().p("AkMKHIAA0NIIZAAIAAUNg");
	var mask_graphics_307 = new cjs.Graphics().p("AkmKHIAA0NIJNAAIAAUNg");
	var mask_graphics_308 = new cjs.Graphics().p("AlAKHIAA0NIKBAAIAAUNg");
	var mask_graphics_309 = new cjs.Graphics().p("AlZKHIAA0NIKzAAIAAUNg");
	var mask_graphics_310 = new cjs.Graphics().p("AlzKHIAA0NILnAAIAAUNg");
	var mask_graphics_311 = new cjs.Graphics().p("AmNKHIAA0NIMbAAIAAUNg");
	var mask_graphics_312 = new cjs.Graphics().p("AmnKHIAA0NINPAAIAAUNg");
	var mask_graphics_313 = new cjs.Graphics().p("AnBKHIAA0NIODAAIAAUNg");
	var mask_graphics_314 = new cjs.Graphics().p("AnbKHIAA0NIO3AAIAAUNg");
	var mask_graphics_315 = new cjs.Graphics().p("An1KHIAA0NIPrAAIAAUNg");
	var mask_graphics_316 = new cjs.Graphics().p("AoPKHIAA0NIQfAAIAAUNg");
	var mask_graphics_317 = new cjs.Graphics().p("AopKHIAA0NIRTAAIAAUNg");
	var mask_graphics_318 = new cjs.Graphics().p("ApDKHIAA0NISHAAIAAUNg");
	var mask_graphics_319 = new cjs.Graphics().p("ApdKHIAA0NIS7AAIAAUNg");
	var mask_graphics_320 = new cjs.Graphics().p("Ap3KHIAA0NITvAAIAAUNg");
	var mask_graphics_321 = new cjs.Graphics().p("AqRKHIAA0NIUjAAIAAUNg");
	var mask_graphics_322 = new cjs.Graphics().p("AqrKHIAA0NIVXAAIAAUNg");
	var mask_graphics_323 = new cjs.Graphics().p("ArFKHIAA0NIWLAAIAAUNg");
	var mask_graphics_324 = new cjs.Graphics().p("ArfKHIAA0NIW/AAIAAUNg");
	var mask_graphics_325 = new cjs.Graphics().p("Ar5KHIAA0NIXzAAIAAUNg");
	var mask_graphics_326 = new cjs.Graphics().p("AsTKHIAA0NIYnAAIAAUNg");
	var mask_graphics_327 = new cjs.Graphics().p("AQWW7IAA0PIZdAAIAAUPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(299).to({graphics:mask_graphics_299,x:380.9,y:228.7}).wait(1).to({graphics:mask_graphics_300,x:383.5,y:228.7}).wait(1).to({graphics:mask_graphics_301,x:386.1,y:228.7}).wait(1).to({graphics:mask_graphics_302,x:388.7,y:228.7}).wait(1).to({graphics:mask_graphics_303,x:391.3,y:228.7}).wait(1).to({graphics:mask_graphics_304,x:393.9,y:228.7}).wait(1).to({graphics:mask_graphics_305,x:396.5,y:228.7}).wait(1).to({graphics:mask_graphics_306,x:399.1,y:228.7}).wait(1).to({graphics:mask_graphics_307,x:401.7,y:228.7}).wait(1).to({graphics:mask_graphics_308,x:404.3,y:228.7}).wait(1).to({graphics:mask_graphics_309,x:406.9,y:228.7}).wait(1).to({graphics:mask_graphics_310,x:409.5,y:228.7}).wait(1).to({graphics:mask_graphics_311,x:412.1,y:228.7}).wait(1).to({graphics:mask_graphics_312,x:414.7,y:228.7}).wait(1).to({graphics:mask_graphics_313,x:417.3,y:228.7}).wait(1).to({graphics:mask_graphics_314,x:419.9,y:228.7}).wait(1).to({graphics:mask_graphics_315,x:422.5,y:228.7}).wait(1).to({graphics:mask_graphics_316,x:425.1,y:228.7}).wait(1).to({graphics:mask_graphics_317,x:427.7,y:228.7}).wait(1).to({graphics:mask_graphics_318,x:430.3,y:228.7}).wait(1).to({graphics:mask_graphics_319,x:432.9,y:228.7}).wait(1).to({graphics:mask_graphics_320,x:435.5,y:228.7}).wait(1).to({graphics:mask_graphics_321,x:438.1,y:228.7}).wait(1).to({graphics:mask_graphics_322,x:440.7,y:228.7}).wait(1).to({graphics:mask_graphics_323,x:443.3,y:228.7}).wait(1).to({graphics:mask_graphics_324,x:445.9,y:228.7}).wait(1).to({graphics:mask_graphics_325,x:448.5,y:228.7}).wait(1).to({graphics:mask_graphics_326,x:451.1,y:228.7}).wait(1).to({graphics:mask_graphics_327,x:267.5,y:146.7}).wait(1));

	// funcio
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("ApVGoISrtP");
	this.shape_1.setTransform(460.9,225.3);

	this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1}]},299).wait(29));

	// resaltats
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,153,51,0.498)").s().p("AjlCGIAAkMIHKAAIAAEMg");
	this.shape_2.setTransform(182,180.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,153,51,0.498)").s().p("AjlCGIAAkMIHKAAIAAEMg");
	this.shape_3.setTransform(113,180.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_4.setTransform(465.8,218.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_5.setTransform(465.8,218.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_6.setTransform(465.8,218.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(0,0,0,0.498)").s().p("AgsAzQgTgWAAgdQAAgdATgUQATgWAZAAQAaAAATAWQATAUAAAdQAAAdgTAWQgTAUgaAAQgZAAgTgUg");
	this.shape_7.setTransform(465.8,218.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AAtAzQgTAVgaAAQgZAAgTgVQgTgVAAgeQAAgcATgVQATgVAZAAQAaAAATAVQATAVAAAcQAAAegTAVg");
	this.shape_8.setTransform(465.8,218.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3,p:{y:180.6}},{t:this.shape_2,p:{y:180.6}}]},150).to({state:[{t:this.shape_3,p:{y:180.6}},{t:this.shape_2,p:{y:180.6}},{t:this.shape_5,p:{x:465.8,y:218.9}},{t:this.shape_4,p:{x:465.8,y:218.9}}]},25).to({state:[{t:this.shape_3,p:{y:238.3}},{t:this.shape_2,p:{y:238.3}},{t:this.shape_5,p:{x:465.8,y:218.9}},{t:this.shape_4,p:{x:465.8,y:218.9}}]},25).to({state:[{t:this.shape_3,p:{y:238.3}},{t:this.shape_2,p:{y:238.3}},{t:this.shape_7},{t:this.shape_6,p:{x:465.8,y:218.9}},{t:this.shape_5,p:{x:495.4,y:200.8}},{t:this.shape_4,p:{x:495.4,y:200.8}}]},25).to({state:[{t:this.shape_3,p:{y:296.8}},{t:this.shape_2,p:{y:296.8}},{t:this.shape_7},{t:this.shape_6,p:{x:465.8,y:218.9}},{t:this.shape_5,p:{x:495.4,y:200.8}},{t:this.shape_4,p:{x:495.4,y:200.8}}]},25).to({state:[{t:this.shape_3,p:{y:296.8}},{t:this.shape_2,p:{y:296.8}},{t:this.shape_7},{t:this.shape_8},{t:this.shape_5,p:{x:495.4,y:200.8}},{t:this.shape_6,p:{x:495.4,y:200.8}},{t:this.shape_4,p:{x:524.2,y:180.3}}]},25).wait(53));

	// taula
	this.instance_2 = new lib.taula_sense_valors("synched",0);
	this.instance_2.setTransform(145,221.6,1,1,0,0,0,75,105.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(92).to({startPosition:0,_off:false},0).to({alpha:1},6).wait(230));

	// text1
	/* Layers with classic tweens must contain only a single symbol instance. */

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_28 = new cjs.Graphics().p("EgluABVIAAioMBLdAAAIAACog");
	var mask_1_graphics_29 = new cjs.Graphics().p("EgluACoIAAlPMBLdAAAIAAFPg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EgluAD8IAAn3MBLdAAAIAAH3g");
	var mask_1_graphics_31 = new cjs.Graphics().p("EgluAFQIAAqfMBLdAAAIAAKfg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EgluAGjIAAtFMBLdAAAIAANFg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgluAH3IAAvtMBLdAAAIAAPtg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgluAJLIAAyVMBLdAAAIAASVg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgluAKfIAA09MBLdAAAIAAU9g");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgluALyIAA3jMBLdAAAIAAXjg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EgluANGIAA6LMBLdAAAIAAaLg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgluAOaIAA8zMBLdAAAIAAczg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgluAPtIAA/ZMBLdAAAIAAfZg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgluARBMAAAgiBMBLdAAAMAAAAiBg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgluASVMAAAgkpMBLdAAAMAAAAkpg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgluATpMAAAgnRMBLdAAAMAAAAnRg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgluAU8MAAAgp3MBLdAAAMAAAAp3g");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgluAWQMAAAgsfMBLdAAAMAAAAsfg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgluAXkMAAAgvHMBLdAAAMAAAAvHg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgluAY3MAAAgxtMBLdAAAMAAAAxtg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgluAaLMAAAg0VMBLdAAAMAAAA0Vg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EgluAbfMAAAg29MBLdAAAMAAAA29g");
	var mask_1_graphics_49 = new cjs.Graphics().p("EgluAczMAAAg5lMBLdAAAMAAAA5lg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AtMeGMAAAg8LMBLcAAAMAAAA8Lg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(28).to({graphics:mask_1_graphics_28,x:555.5,y:200.6}).wait(1).to({graphics:mask_1_graphics_29,x:555.5,y:200}).wait(1).to({graphics:mask_1_graphics_30,x:555.5,y:199.5}).wait(1).to({graphics:mask_1_graphics_31,x:555.5,y:199}).wait(1).to({graphics:mask_1_graphics_32,x:555.5,y:198.5}).wait(1).to({graphics:mask_1_graphics_33,x:555.5,y:198}).wait(1).to({graphics:mask_1_graphics_34,x:555.5,y:197.5}).wait(1).to({graphics:mask_1_graphics_35,x:555.5,y:197}).wait(1).to({graphics:mask_1_graphics_36,x:555.5,y:196.5}).wait(1).to({graphics:mask_1_graphics_37,x:555.5,y:196}).wait(1).to({graphics:mask_1_graphics_38,x:555.5,y:195.5}).wait(1).to({graphics:mask_1_graphics_39,x:555.5,y:195}).wait(1).to({graphics:mask_1_graphics_40,x:555.5,y:194.5}).wait(1).to({graphics:mask_1_graphics_41,x:555.5,y:194}).wait(1).to({graphics:mask_1_graphics_42,x:555.5,y:193.5}).wait(1).to({graphics:mask_1_graphics_43,x:555.5,y:193}).wait(1).to({graphics:mask_1_graphics_44,x:555.5,y:192.5}).wait(1).to({graphics:mask_1_graphics_45,x:555.5,y:192}).wait(1).to({graphics:mask_1_graphics_46,x:555.5,y:191.5}).wait(1).to({graphics:mask_1_graphics_47,x:555.5,y:191}).wait(1).to({graphics:mask_1_graphics_48,x:555.5,y:190.5}).wait(1).to({graphics:mask_1_graphics_49,x:555.5,y:190}).wait(1).to({graphics:mask_1_graphics_50,x:398.5,y:189.5}).wait(278));

	// numeros
	this.text = new cjs.Text("7", "14px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(768.1,207.8);

	this.text_1 = new cjs.Text("-2", "14px Verdana");
	this.text_1.lineHeight = 16;
	this.text_1.setTransform(482.8,207);

	this.text_2 = new cjs.Text("-3", "14px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(452.8,207);

	this.text_3 = new cjs.Text("-4", "14px Verdana");
	this.text_3.lineHeight = 16;
	this.text_3.setTransform(422.2,207);

	this.text_4 = new cjs.Text("-5", "14px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(392.8,207);

	this.text_5 = new cjs.Text("-6", "14px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(362.8,207);

	this.text_6 = new cjs.Text("-7", "14px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(332.2,207);

	this.text_7 = new cjs.Text("6", "14px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(738.9,207.8);

	this.text_8 = new cjs.Text("5", "14px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(708.9,207.8);

	this.text_9 = new cjs.Text("4", "14px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(678.3,207.8);

	this.text_10 = new cjs.Text("3", "14px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(648.9,207.8);

	this.text_11 = new cjs.Text("2", "14px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(618.9,207.8);

	this.text_12 = new cjs.Text("1", "14px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(587.1,206.6);

	this.text_13 = new cjs.Text("0", "14px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(561.3,205.6);

	this.text_14 = new cjs.Text("-1", "14px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(515.7,207.9);

	this.text_15 = new cjs.Text("-2", "14px Verdana");
	this.text_15.lineHeight = 16;
	this.text_15.setTransform(533.7,238);

	this.text_16 = new cjs.Text("-3", "14px Verdana");
	this.text_16.lineHeight = 16;
	this.text_16.setTransform(534.4,268.9);

	this.text_17 = new cjs.Text("-4", "14px Verdana");
	this.text_17.lineHeight = 16;
	this.text_17.setTransform(533.7,296.1);

	this.text_18 = new cjs.Text("-5", "14px Verdana");
	this.text_18.lineHeight = 16;
	this.text_18.setTransform(533.7,326.2);

	this.text_19 = new cjs.Text("-6", "14px Verdana");
	this.text_19.lineHeight = 16;
	this.text_19.setTransform(534.4,357.1);

	this.text_20 = new cjs.Text("6", "14px Verdana");
	this.text_20.lineHeight = 16;
	this.text_20.setTransform(538.5,15.6);

	this.text_21 = new cjs.Text("5", "14px Verdana");
	this.text_21.lineHeight = 16;
	this.text_21.setTransform(538.5,45.8);

	this.text_22 = new cjs.Text("4", "14px Verdana");
	this.text_22.lineHeight = 16;
	this.text_22.setTransform(539.2,76.6);

	this.text_23 = new cjs.Text("3", "14px Verdana");
	this.text_23.lineHeight = 16;
	this.text_23.setTransform(538.5,103.8);

	this.text_24 = new cjs.Text("2", "14px Verdana");
	this.text_24.lineHeight = 16;
	this.text_24.setTransform(538.5,134);

	this.text_25 = new cjs.Text("1", "14px Verdana");
	this.text_25.lineHeight = 16;
	this.text_25.setTransform(539.2,164.8);

	this.text_26 = new cjs.Text("0", "14px Verdana");
	this.text_26.lineHeight = 16;
	this.text_26.setTransform(548.7,182);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask = this.text_18.mask = this.text_19.mask = this.text_20.mask = this.text_21.mask = this.text_22.mask = this.text_23.mask = this.text_24.mask = this.text_25.mask = this.text_26.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},28).wait(300));

	// numeracio_eixos
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_9.setTransform(561.7,177.3,1,1,-89.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_10.setTransform(561.7,147.3,1,1,-89.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_11.setTransform(561.7,117.3,1,1,-89.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_12.setTransform(561.7,87.3,1,1,-89.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_13.setTransform(561.7,57.8,1,1,-89.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_14.setTransform(561.7,27.8,1,1,-89.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_15.setTransform(561.7,368.7,1,1,-89.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_16.setTransform(561.7,338.7,1,1,-89.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_17.setTransform(561.7,308.7,1,1,-89.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_18.setTransform(561.7,278.7,1,1,-89.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_19.setTransform(561.7,249.2,1,1,-89.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_20.setTransform(561.7,219.2,1,1,-89.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_21.setTransform(595.6,200.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_22.setTransform(625.6,200.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_23.setTransform(655.6,200.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_24.setTransform(685.1,200.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_25.setTransform(715.1,200.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_26.setTransform(745.1,200.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_27.setTransform(775.1,200.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_28.setTransform(345.7,199.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_29.setTransform(375.7,199.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_30.setTransform(405.7,199.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_31.setTransform(435.2,199.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_32.setTransform(465.2,199.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_33.setTransform(495.2,199.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("AAAhMIAACZ");
	this.shape_34.setTransform(525.2,199.6);

	this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]},28).wait(300));

	// eixos
	this.text_27 = new cjs.Text("x", "italic 18px Verdana");
	this.text_27.lineHeight = 20;
	this.text_27.lineWidth = 144;
	this.text_27.setTransform(781,197.3+incremento);

	this.text_28 = new cjs.Text("y", "italic 18px Verdana");
	this.text_28.lineHeight = 20;
	this.text_28.lineWidth = 144;
	this.text_28.setTransform(566.4,-7.5+incremento);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(2,1,1).p("EAjoAAAMhHQAAA");
	this.shape_35.setTransform(554.3,200.1,1,1,0,0,0,-6.6,0);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(2,1,1).p("AAA9RMAAAA6j");
	this.shape_36.setTransform(561.7,190.5);

	this.text_27.mask = this.text_28.mask = this.shape_35.mask = this.shape_36.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_36},{t:this.shape_35},{t:this.text_28},{t:this.text_27}]},28).wait(300));

	// linia_verda
	this.instance_3 = new lib.Mapadebits1();
	this.instance_3.setTransform(521.7,4.5);

	this.instance_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},28).wait(300));

	// pastilla_verda
	this.instance_4 = new lib.Mapadebits2();
	this.instance_4.setTransform(684.7,0.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,153,0,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_37.setTransform(740.2,189.8,0.569,1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(0,204,255,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_38.setTransform(604.8,190.4,0.856,1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(0,153,51,0.498)").s().p("AuodOMAAAg6bIdRAAMAAAA6bg");
	this.shape_39.setTransform(429,190.4);

	this.instance_4.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.instance_4}]},28).wait(300));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(22,10,234.4,31.3);
    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   /* function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

   
   //Simbolillos
   
   

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}

createjs.Graphics.prototype.dashedLineTo = function(x1, y1, x2, y2, dashLen) {
    this.moveTo(x1, y1);
    
    var dX = x2 - x1;
    var dY = y2 - y1;
    var dashes = Math.floor(Math.sqrt(dX * dX + dY * dY) / dashLen);
    var dashX = dX / dashes;
    var dashY = dY / dashes;
    
    var q = 0;
    while (q++ < dashes) {
        x1 += dashX;
        y1 += dashY;
        this[q % 2 == 0 ? 'moveTo' : 'lineTo'](x1, y1);
    }
    this[q % 2 == 0 ? 'moveTo' : 'lineTo'](x2, y2); 
}