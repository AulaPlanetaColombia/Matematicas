Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();

	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 235 ;
	//final
	this.PREG_FINAL_X_PADDING = 585 ;
	
	this.RESP_HEIGHT = 82;
	this.RESP_WIDTH = 322; 
	this.RESP_INNER_HEIGHT = 78;
	this.RESP_INNER_WIDTH = 320; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.IMG = "data/imagenes/";
	
	//GUINARDO
	this.lEnunciados=new Array();
	this.qEnunciados = 0;
	this.listAux= new Array();
	this.qOperaciones;
	this.lOperaciones = new Array();
	this.co_pizarra;
	this.lPreguntas = new Array();
	
	this.ponerContenedor = function(contenedorMotor) {

	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('qOperaciones').text();
				        
	        var seed = $(xml).find('seed');
	        Motor.datosXML.seed = seed.text();
	        
	        var curso = $(xml).find('curso');
            Motor.datosXML.curso = curso.text();
            
            var nivel = $(xml).find('nivel');
            Motor.datosXML.nivel = nivel.text();
            
			this.preg = new enunciado();
            this.preg.id = 0;
            this.preg.enunciado = $(xml).find('enunciado').text();
            Motor.datosXML.enunciados.push(this.preg);
			
            Motor.datosXML.variaciones = new Array();
            $(xml).find('variaciones').children().each(function(index){
                //debugger;
                this.preg = new variaciones();
                this.preg.id = index;
                this.preg.text = $(this).text();
                this.preg.tag = this.tagName;
                Motor.datosXML.variaciones.push(this.preg);
            });
            
	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
		});
	}
	this.inicializarEstructura = function(estado) {

		this.initGenerador();
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
		
		this.currentPag.getParam();
		
		for(key1 in Motor.pagines){
		    if(!Motor.pagines[key1].isCompletado()){
		        return false
		    }
		}
		return true;
	};
	
	this.getEstado = function(){
		var respuesta = "";
        for(var i=0;i<this.qOperaciones;i++){
            if( Motor.pagines[i].respuesta.length == 4){
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[0];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[1];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[2];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[3];
                respuesta+="AAA";
                respuesta+="AAA";
                respuesta+="AAA";
            }
            if(Motor.pagines[i].respuesta.length == 6){
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[0];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[1];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[2];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[3];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[4];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[5];
                respuesta+="AAA";

            }
            if( Motor.pagines[i].respuesta.length == 7 ){
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[0];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[1];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[2];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[3];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[4];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[5];
                respuesta+="AAA";
                respuesta+=Motor.pagines[i].respuesta[6];
            }
        }
        return respuesta;
	}
	
	this.revisar = function(){
		if(this.estado != "")
		{
			var lRespuestas=this.estado.split("AAA");
            lRespuestas.splice(0,1);
            for(var i=0;i<this.qOperaciones*7;i+=7){
                var aux = i/7;
                if( Motor.pagines[aux].respuesta.length == 4){
                    Motor.pagines[aux].respuesta[0]=lRespuestas[i];
                    Motor.pagines[aux].respuesta[1]=lRespuestas[i+1];
                    Motor.pagines[aux].respuesta[2]=lRespuestas[i+2];
                    Motor.pagines[aux].respuesta[3]=lRespuestas[i+3];
                }
                
                if(Motor.pagines[aux].respuesta.length == 6){
                    Motor.pagines[aux].respuesta[0]=lRespuestas[i];
                    Motor.pagines[aux].respuesta[1]=lRespuestas[i+1];
                    Motor.pagines[aux].respuesta[2]=lRespuestas[i+2];
                    Motor.pagines[aux].respuesta[3]=lRespuestas[i+3];
                    Motor.pagines[aux].respuesta[4]=lRespuestas[i+4];
                    Motor.pagines[aux].respuesta[5]=lRespuestas[i+5];
                }
                
                if( Motor.pagines[aux].respuesta.length == 7 ){
                    Motor.pagines[aux].respuesta[0]=lRespuestas[i];
                    Motor.pagines[aux].respuesta[1]=lRespuestas[i+1];
                    Motor.pagines[aux].respuesta[2]=lRespuestas[i+2];
                    Motor.pagines[aux].respuesta[3]=lRespuestas[i+3];
                    Motor.pagines[aux].respuesta[4]=lRespuestas[i+4];
                    Motor.pagines[aux].respuesta[5]=lRespuestas[i+5];
                    Motor.pagines[aux].respuesta[6]=lRespuestas[i+6];
                }
            }
            this.currentPag.setParam();
		}
	}
	
	this.validar = function() {
		
		this.currentPag.getParam();
				
		var total = 0;
	  	for(key1 in Motor.pagines){
	  	    var correcte = true;
	  	    if( !Motor.pagines[key1].isValidado() ){
	  	       correcte = false; 
	  	    }  		
	  		
	  		if( correcte ){
	  			total++;
	  			Motor.pagines[key1].validacio = true;
	  		}else{
	  			Motor.pagines[key1].validacio = false;
	  		}
	  		Motor.pagines[key1].corregidoPag = true;
	  		
		}
		this.currentPag.setParam();
		return total.toString() + "/" + Motor.pagines.length.toString();
		
	};
	
	this.hideDomObjects = function(){
        this.currentPag.getParam();
        $(this["inputDOM0"].htmlElement).css("display" , 'none');
        $(this["inputDOM1"].htmlElement).css("display" , 'none');
        $(this["inputDOM2"].htmlElement).css("display" , 'none');
        $(this["inputDOM3"].htmlElement).css("display" , 'none');
        $(this["inputDOM4"].htmlElement).css("display" , 'none');
        $(this["inputDOM5"].htmlElement).css("display" , 'none');
        $(this["inputDOM6"].htmlElement).css("display" , 'none');
        $(this["inputDOM7"].htmlElement).css("display" , 'none');

	}
	this.showDomObjects = function(){
        this.currentPag.setParam();
	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
        for(var i = 0; i < 8; i++){
            $(this["inputDOM"+i].htmlElement).prop("readonly", false);
        }
	}
	this.desactivar = function() {
        
        //marco en readonly los inputs
        //console.log(this.currentPag.respuesta.length);
        for(var i = 0; i < 8; i++){
            $(this["inputDOM"+i].htmlElement).prop("readonly", true);
        }
        
	};
	this.numPaginas = function(){
		return Motor.datosXML.cantidad;
	};
	this.ponerPagina = function(pag) {
		
		this.currentPag.getParam();

		this.contenedor.removeChild( this.currentPag.contenedor );
		this.currentNumPag = pag - 1;
	    this.currentPag = this.pagines[this.currentNumPag];
	    this.contenedor.addChild( this.currentPag.contenedor );
	    
	    var navegador = Main.navegador;
        var navegadorSplit = navegador.split(' ');
        var mobil = Main.mobil
        var index = navegadorSplit[0].indexOf("Safari");
        var version = navegadorSplit[1];
        
        if(index > -1 && mobil =="Android"){
            $(this["inputDOM0"].htmlElement).focus().blur();
            $(this["inputDOM1"].htmlElement).focus().blur();
            $(this["inputDOM2"].htmlElement).focus().blur();
            $(this["inputDOM3"].htmlElement).focus().blur();
            $(this["inputDOM4"].htmlElement).focus().blur();
            $(this["inputDOM5"].htmlElement).focus().blur();
            $(this["inputDOM6"].htmlElement).focus().blur();
            $(this["inputDOM7"].htmlElement).focus().blur();
        }
        
	    this.currentPag.setParam();
	    
	    if(  this.currentPag.validacio == "" ){ }
	    else if( this.currentPag.validacio == false)
			$(this["inputDOM0"].htmlElement).css("color","#E1001A");
		else if(this.currentPag.validacio == true)
			$(this["inputDOM0"].htmlElement).css("color","#41A62A");
	    
	};
	
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		
	};
	this.deseleccionar = function(){
		/*for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			Motor.pagines[key1].respostes[key2].desactivar();
	   			Motor.pagines[key1].respostes[key2].clear();
			}
		}*/
	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
	  	for(key1 in Motor.pagines){
            Motor.pagines[key1].verSolucion();
		}
	};
	this.obtenerTipoEjercicio = function(){

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		this.pagines = new Array();

	    for(var i=0; i < Motor.datosXML.cantidad; i++)
    	{
	    	var index = 0;
	    	//console.log(Motor.lOperaciones[i].enunciadoJ);
	    	var enunciado = Motor.datosXML.enunciados[0];	
			//var enunciado = Motor.lOperaciones[i].enunciadoJ;
	    	this.addPagina( enunciado, i , index);
	    }
	    
	    this.deleteInputs();
        this.initIntroTexto();
        
	    this.contenedor.addChild( this.pagines[0].contenedor );
        this.currentPag = this.pagines[0];
        this.currentNumPag = 0;
        this.currentPag.setParam();
	    
	    Main.stage.addChild( this.contenedor );
    }
    
    this.addPagina = function( enunciado, numpagina , idPregunta)
    {
        /*if( numpagina == 0 || numpagina == 3 || numpagina == 6 || numpagina == 9){
    	   var pagina = new Pagina( enunciado, numpagina, Motor.lOperaciones[numpagina]);
    	}else if( numpagina == 1 || numpagina == 4 || numpagina == 7 ){
    	    var pagina = new Pagina2( enunciado, numpagina, Motor.lOperaciones[numpagina]);
    	}else{
    	    var pagina = new Pagina3( enunciado, numpagina, Motor.lOperaciones[numpagina]);
    	}*/
    	
    	if( Motor.lOperaciones[numpagina].variacion == 1){
           var pagina = new Pagina( enunciado, numpagina, Motor.lOperaciones[numpagina]);
        }else if( Motor.lOperaciones[numpagina].variacion == 2 ){
            var pagina = new Pagina2( enunciado, numpagina, Motor.lOperaciones[numpagina]);
        }else{
            var pagina = new Pagina3( enunciado, numpagina, Motor.lOperaciones[numpagina]);
        }
    	
    	//console.log(pagina);
    	pagina.contenedor.y = this.INITIAL_Y;
    	this.pagines.push( pagina );
    	
    }
    
    this.initGenerador = function()
    {
    	var seed = Motor.datosXML.seed;

		this.lEnunciados = new Array();
		this.qEnunciados = 0;
		this.listAux= new Array();
		this.lOperaciones = new Array();
		this.lVariaciones = new Array();
		this.lTiposVariaciones = new Array();
        var indice;
        this.primaria;
		//for(var key in  Motor.datosXML.enunciados)
		//{
			var ss = Motor.datosXML.enunciados[0].enunciado.toString();
			ss = JL.reemplazar(ss, 'NNN', '\n');
			this.lEnunciados.push( ss );
		//}
		//console.log( this.lEnunciados);
		this.qEnunciados = this.lEnunciados.length;

		/////extrar qOperaciones
		this.qOperaciones = Motor.datosXML.cantidad;
		
		
		for(var i=1;i<4;i++){
            if(Motor.datosXML.variaciones[i-1].text == "1"){
                this.lTiposVariaciones.push(i);
            }
        }
        
        if(Motor.datosXML.curso == 0){
            this.primaria=true;
        }else{
            this.primaria=false;
        }
        		
        for (var op = 0; op < this.qOperaciones; op++) {
            indice = op % this.lTiposVariaciones.length;
            this.lVariaciones[op] = this.lTiposVariaciones[indice];
        }
		
		if(Scorm.modo == Scorm.MODO_EXPONER){
			Generador.generarSerie(JL.iRandom(1,100));
		}else{
			Generador.generarSerie(seed);
		}
		//console.log(Motor.lOperaciones);
    }
    
    this.initIntroTexto = function(){

        for(var i = 0; i < 8; i++)
        {
            var $input = $('<input type="text" id="input_'+ i +'" onkeyup="Motor.filterText(event);" tabindex="'+ (i+1) +'" class="input"/>');
            //$input.tabindex = i+1;
            
            $("#mediaHolder").append($input);

            this["inputDOM"+i] = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
            
            this["inputDOM"+i].element_x = 296 + i*120;
            //this["inputDOM"+i].element_x = 1000 + i*120;
            this["inputDOM"+i].element_y = 315;
            //this["inputDOM"+i].element_y = 1000;
            this["inputDOM"+i].element_width = 80;
            this["inputDOM"+i].element_height = 25;
            this["inputDOM"+i].fontsize = 20;
            
            this["inputDOM"+i].x = this["inputDOM"+i].element_x ;
            this["inputDOM"+i].y = this["inputDOM"+i].element_y ;
            $(this["inputDOM"+i].htmlElement).css("width", this["inputDOM"+i].element_width);
            $(this["inputDOM"+i].htmlElement).css("height", this["inputDOM"+i].element_height);
            $(this["inputDOM"+i].htmlElement).css("color", "#000");
            $(this["inputDOM"+i].htmlElement).css("display","none");
            
            this.contenedor.addChild(this["inputDOM"+i]);
            
            var navegador = Main.navegador;
	        var navegadorSplit = navegador.split(' ');
	        var mobil = Main.mobil
	        var index = navegadorSplit[0].indexOf("IE");
	        var version = navegadorSplit[1];
	        
	        if(index > -1 && mobil =="Tablet"){
	            $input.focusout(function(event){ $("body").focus(); });
	            $(this["inputDOM"+i].htmlElement).click(Motor.select);
	        }
            //$(this["inputDOM"+i].htmlElement).focus();
        }   
    };
    
    this.filterText = function(e){
        var id = e.target.id;
    	if( $("#" + id).val().length ){
    		Contenedor.checkPagina();
    	}
    };
    
    this.select = function(){
        $(this).blur().focus();
    };
        
    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}

}
