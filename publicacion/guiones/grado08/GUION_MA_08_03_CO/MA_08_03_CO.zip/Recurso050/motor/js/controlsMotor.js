function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(operacio);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 800;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.figura = new createjs.Container();
    this.figura.y = 60;
    this.figura.x = 80;
    this.figura.addChild( operacio.preguntaSprite );
    this.figura.scaleX = 0.75;
    this.figura.scaleY = 0.75;
    this.contenedor.addChild( this.figura );
    
    
    
    
    //es la respuesta en sprite
    this.respuestaSprite = new createjs.Container();
    this.respuestaSprite.y = 250;
    this.respuestaSprite.x = 370;
    this.respuestaSprite.alpha = 0;
    this.respuestaSprite.addChild( operacio.respuestaSprite );
    this.contenedor.addChild( this.respuestaSprite );
    
    this.corregidoPag = false;
    //this.subEnunciado(operacio);
    
    this.addLine( 0, 430, 170, "x", "y", "z",'w','t');
    
    this.respuesta = ["","","","","",""];
	this.valor = [operacio.respuesta[0][0], operacio.respuesta[0][1], operacio.respuesta[0][2], operacio.respuesta[0][3], operacio.respuesta[0][4], operacio.respuesta[0][5]]; 

	
}


Pagina.prototype.addLine = function(index, x, y, _text, _text2, _text3, _text4, _text5){
    
    this["caja0"+index] = new CajaTexto();
    this["caja0"+index] .contenedor.x = x - 110;
    this["caja0"+index] .contenedor.y = y - 10;

    this.posicion0X = x - 110;
    this.posicion0Y = y - 10;
    this.posicion0W = 70;
    this.posicion0H = 55;
    this.tamano0 = 20;
    
    this.contenedor.addChild( this["caja0"+index].contenedor  );
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text"+index].color = "#000";
    this["text"+index].x = x - 20;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja1"+index] = new CajaTexto2();
    this["caja1"+index] .contenedor.x = x + this["text"+index].getMeasuredWidth() - 20;
    this["caja1"+index] .contenedor.y = y - 20;

    this.posicion1X = x + this["text"+index].getMeasuredWidth() - 20;
    this.posicion1Y = y - 20;
    this.posicion1W = 45;
    this.posicion1H = 35;
    this.tamano1 = 15;
    
    this.contenedor.addChild( this["caja1"+index].contenedor  );
    
    
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = _text2.toString();
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text2"+index].color = "#000";
    this["text2"+index].x = 50 + this["caja1"+index] .contenedor.x;
    this["text2"+index].y = y + 8;
    this["text2"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text2"+index]  );
    
    this["caja2"+index] = new CajaTexto2();
    this["caja2"+index] .contenedor.x = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this["caja2"+index] .contenedor.y = y - 20;

    this.posicion2X = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this.posicion2Y = y - 20;
    this.posicion2W = 45;
    this.posicion2H = 35;
    this.tamano2 = 15;

    this.contenedor.addChild( this["caja2"+index].contenedor  );
    
    
    this["text3"+index] = new createjs.RichText();
    this["text3"+index].text = _text3.toString();
    this["text3"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text3"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text3"+index].color = "#000";
    this["text3"+index].x = 50 + this["caja2"+index] .contenedor.x;
    this["text3"+index].y = y + 8;
    this["text3"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text3"+index]  );
    
    this["caja3"+index] = new CajaTexto2();
    this["caja3"+index] .contenedor.x = this["text3"+index].x + this["text3"+index].getMeasuredWidth();
    this["caja3"+index] .contenedor.y = y - 20;

    this.posicion3X = this["text3"+index].x + this["text3"+index].getMeasuredWidth();
    this.posicion3Y = y - 20;
    this.posicion3W = 45;
    this.posicion3H = 35;
    this.tamano3 = 15;
    
    this.contenedor.addChild( this["caja3"+index].contenedor  );
    
    //agregadas las dos letras que faltan
    
    this["text4"+index] = new createjs.RichText();
    this["text4"+index].text = _text4.toString();
    this["text4"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text4"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text4"+index].color = "#000";
    this["text4"+index].x = 50 + this["caja3"+index] .contenedor.x;
    this["text4"+index].y = y + 8;
    this["text4"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text4"+index]  );
    
    this["caja4"+index] = new CajaTexto2();
    this["caja4"+index] .contenedor.x = this["text4"+index].x + this["text4"+index].getMeasuredWidth();
    this["caja4"+index] .contenedor.y = y - 20;

    this.posicion4X = this["text4"+index].x + this["text4"+index].getMeasuredWidth();
    this.posicion4Y = y - 20;
    this.posicion4W = 45;
    this.posicion4H = 35;
    this.tamano4 = 15;
    
    this.contenedor.addChild( this["caja4"+index].contenedor  );
    
    
    this["text5"+index] = new createjs.RichText();
    this["text5"+index].text = _text5.toString();
    this["text5"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text5"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text5"+index].color = "#000";
    this["text5"+index].x = 50 + this["caja4"+index] .contenedor.x;
    this["text5"+index].y = y + 8;
    this["text5"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text5"+index]  );
    
    this["caja5"+index] = new CajaTexto2();
    this["caja5"+index] .contenedor.x = this["text5"+index].x + this["text5"+index].getMeasuredWidth();
    this["caja5"+index] .contenedor.y = y - 20;

    this.posicion5X = this["text5"+index].x + this["text5"+index].getMeasuredWidth();
    this.posicion5Y = y - 20;
    this.posicion5W = 45;
    this.posicion5H = 35;
    this.tamano5 = 15;
    
    this.contenedor.addChild( this["caja5"+index].contenedor  );
    
    
    

}


Pagina.prototype.getParam = function(){
    this.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val(), $(Motor.inputDOM2.htmlElement).val(), $(Motor.inputDOM3.htmlElement).val(), $(Motor.inputDOM4.htmlElement).val(), $(Motor.inputDOM5.htmlElement).val()];
};

Pagina.prototype.setParam = function(){
    $(Motor.inputDOM0.htmlElement).val(this.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(this.respuesta[1]);
    $(Motor.inputDOM2.htmlElement).val(this.respuesta[2]);
    $(Motor.inputDOM3.htmlElement).val(this.respuesta[3]);
    $(Motor.inputDOM4.htmlElement).val(this.respuesta[4]);
    $(Motor.inputDOM5.htmlElement).val(this.respuesta[5]);
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("display","none");
    }
    
    for( var i = 0; i < this.respuesta.length; i++){
        Motor["inputDOM"+i].element_x = this["posicion" + i + "X"] + 5;
        Motor["inputDOM"+i].element_y = this["posicion" + i + "Y"] + 122;
        Motor["inputDOM"+i].element_width = this["posicion" + i + "W"] - 10;
        Motor["inputDOM"+i].element_height = this["posicion" + i + "H"] - 10;
        Motor["inputDOM"+i].fontsize = this["tamano" + i];
        $(Motor["inputDOM"+i].htmlElement).css("display","inline");
    }
    if( this.corregidoPag ){
        this.isValidado();
    }
        
};

Pagina.prototype.bloquea = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","true");
    } 
};

Pagina.prototype.activa = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","false");
    } 
};


Pagina.prototype.isCompletado = function(){
    var correcto = true;
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( this.respuesta[i] == "" ){
            correcto = false;
        }
    }
    return correcto;
};

Pagina.prototype.isValidado = function(){
    var correcto = true;
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this["caja" + i + "0"].error();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#E1001A");
            correcto = false;
        }else{
            this["caja" + i + "0"].correct();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#41A62A");
        }
    }
    return correcto;
};

Pagina.prototype.verSolucion = function(){
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this.respuestaSprite.alpha = 1;
        }
    }
};

//PAGINA 2 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
function Pagina2( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(operacio);
    this.idPregunta = _numpagina;
    //debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;

    this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.figura = new createjs.Container();
    this.figura.y = 60;
    this.figura.x = 80;
    this.figura.addChild( operacio.preguntaSprite );
    this.figura.scaleX = 0.75;
    this.figura.scaleY = 0.75;
    this.contenedor.addChild( this.figura );
    
    
    //es la respuesta en sprite
    this.respuestaSprite = new createjs.Container();
    this.respuestaSprite.y = 250;
    this.respuestaSprite.x = 370;
    this.respuestaSprite.alpha = 0;
    this.respuestaSprite.addChild( operacio.respuestaSprite );
    this.contenedor.addChild( this.respuestaSprite );
    
    this.addLine( 0, 330, 170);
    
    this.respuesta = ["","","","","",""];
    this.valor = [operacio.respuesta[0][5], operacio.respuesta[0][4], operacio.respuesta[0][3], operacio.respuesta[0][2], operacio.respuesta[0][1], operacio.respuesta[0][0]];
    //this.valor = operacio.respuesta[0];
    
}



Pagina2.prototype.addLine = function(index, x, y){
    
    this["caja0"+index] = new CajaTexto();
    this["caja0"+index] .contenedor.x = x - 110;
    this["caja0"+index] .contenedor.y = y - 10;
    this.posicion0X = x - 110;
    this.posicion0Y = y - 10;
    this.posicion0W = 70;
    this.posicion0H = 55;
    this.tamano0 = 20;
    this.contenedor.addChild( this["caja0"+index].contenedor  );
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = "x{{sup}}5{{normal}}".toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text"+index].color = "#000";
    this["text"+index].x = x - 30;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    this.contenedor.addChild( this["text"+index]  );
    
    
    this["caja1"+index] = new CajaTexto();
    this["caja1"+index] .contenedor.x = this["text"+index].x + this["text"+index].getMeasuredWidth();
    this["caja1"+index] .contenedor.y = y - 10;
    this.posicion1X = this["text"+index].x + this["text"+index].getMeasuredWidth();
    this.posicion1Y = y - 10;
    this.posicion1W = 70;
    this.posicion1H = 55;
    this.tamano1 = 20;
    this.contenedor.addChild( this["caja1"+index].contenedor  );
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = "x{{sup}}4{{normal}}".toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text1"+index].color = "#000";
    this["text1"+index].x = 80 + this["caja1"+index] .contenedor.x;;
    this["text1"+index].y = y + 8;
    this["text1"+index].textAlign = "left";
    this.contenedor.addChild( this["text1"+index]  );
    
    
    this["caja2"+index] = new CajaTexto();
    this["caja2"+index] .contenedor.x = this["text1"+index].x + this["text1"+index].getMeasuredWidth();
    this["caja2"+index] .contenedor.y = y - 10;
    this.posicion2X = this["text1"+index].x + this["text1"+index].getMeasuredWidth();
    this.posicion2Y = y - 10;
    this.posicion2W = 70;
    this.posicion2H = 55;
    this.tamano2 = 20;
    this.contenedor.addChild( this["caja2"+index].contenedor  );
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = "x{{sup}}3{{normal}}".toString();
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text2"+index].color = "#000";
    this["text2"+index].x = 80 + this["caja2"+index] .contenedor.x;
    this["text2"+index].y = y + 8;
    this["text2"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text2"+index]  );
    
    
    this["caja3"+index] = new CajaTexto();
    this["caja3"+index] .contenedor.x = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this["caja3"+index] .contenedor.y = y - 10;
    this.posicion3X = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this.posicion3Y = y - 10;
    this.posicion3W = 70;
    this.posicion3H = 55;
    this.tamano3 = 20;
    this.contenedor.addChild( this["caja3"+index].contenedor  );
    this["text3"+index] = new createjs.RichText();
    this["text3"+index].text = "x{{sup}}2{{normal}}".toString();
    this["text3"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text3"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text3"+index].color = "#000";
    this["text3"+index].x = 80 + this["caja3"+index] .contenedor.x;
    this["text3"+index].y = y + 8;
    this["text3"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text3"+index]  );
    
    
    this["caja4"+index] = new CajaTexto();
    this["caja4"+index] .contenedor.x = this["text3"+index].x + this["text3"+index].getMeasuredWidth();
    this["caja4"+index] .contenedor.y = y - 10;
    this.posicion4X = this["text3"+index].x + this["text3"+index].getMeasuredWidth();
    this.posicion4Y = y - 10;
    this.posicion4W = 70;
    this.posicion4H = 55;
    this.tamano4 = 20;
    this.contenedor.addChild( this["caja4"+index].contenedor  );
    this["text4"+index] = new createjs.RichText();
    this["text4"+index].text = "x".toString();
    this["text4"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text4"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text4"+index].color = "#000";
    this["text4"+index].x = 80 + this["caja4"+index].contenedor.x;
    this["text4"+index].y = y + 8;
    this["text4"+index].textAlign = "left";
    this.contenedor.addChild( this["text4"+index]  );
    
    this["caja5"+index] = new CajaTexto();
    this["caja5"+index] .contenedor.x = 10 + this["text4"+index].x + this["text4"+index].getMeasuredWidth();
    this["caja5"+index] .contenedor.y = y - 10;
    this.posicion5X = 10 + this["text4"+index].x + this["text4"+index].getMeasuredWidth();
    this.posicion5Y = y - 10;
    this.posicion5W = 70;
    this.posicion5H = 55;
    this.tamano5 = 20;
    this.contenedor.addChild( this["caja5"+index].contenedor  ); 
};

Pagina2.prototype.getParam = function(){
    this.respuesta[0] = $(Motor.inputDOM0.htmlElement).val();
    this.respuesta[1] = $(Motor.inputDOM1.htmlElement).val();
    this.respuesta[2] = $(Motor.inputDOM2.htmlElement).val();
    this.respuesta[3] = $(Motor.inputDOM3.htmlElement).val();
    this.respuesta[4] = $(Motor.inputDOM4.htmlElement).val();
    this.respuesta[5] = $(Motor.inputDOM5.htmlElement).val();
};

Pagina2.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(this.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(this.respuesta[1]);
    $(Motor.inputDOM2.htmlElement).val(this.respuesta[2]);
    $(Motor.inputDOM3.htmlElement).val(this.respuesta[3]);
    $(Motor.inputDOM4.htmlElement).val(this.respuesta[4]);
    $(Motor.inputDOM5.htmlElement).val(this.respuesta[5]);
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("display","none");
    }
    
    for( var i = 0; i < this.respuesta.length; i++){
        //console.log("numero " + i  + this["posicion" + i + "X"]);
        Motor["inputDOM"+i].element_x = this["posicion" + i + "X"] + 5;
        Motor["inputDOM"+i].element_y = this["posicion" + i + "Y"] + 122;
        Motor["inputDOM"+i].element_width = this["posicion" + i + "W"] - 10;
        Motor["inputDOM"+i].element_height = this["posicion" + i + "H"] - 10;
        Motor["inputDOM"+i].fontsize = this["tamano" + i];
        $(Motor["inputDOM"+i].htmlElement).css("display","inline");
    }
    
    if( this.corregidoPag ){
        this.isValidado();
    }
    
};

Pagina2.prototype.bloquea = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","true");
    } 
};

Pagina2.prototype.activa = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","false");
    } 
};

Pagina2.prototype.completado = function(){
    this.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    this.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    this.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina2.prototype.isCompletado = function(){
    var correcto = true;
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( this.respuesta[i] == "" ){
            correcto = false;
        }
    }
    return correcto;
};

Pagina2.prototype.isValidado = function(){
    var correcto = true;
    var resp = new Array();   
    for( var i = 0; i < this.respuesta.length; i++ ){
        //console.log("respuesta[ " + i + "] : " + JL.num2str(this.respuesta[i]) + " valor : " + JL.num2str(this.valor[i]));
        if( this.respuesta[i] == "-" || this.respuesta[i] == "-1"){
            resp[i] = this.respuesta[i];
            this.respuesta[i] = -1;
        }else if( this.respuesta[i] == "+" || this.respuesta[i] == "+1"){
            this.respuesta[i] = +1;
            resp[i] = this.respuesta[i];
        }
        
        if( this.respuesta[i] == "" || JL.num2str(this.respuesta[i]) != this.valor[i]){
            this["caja" + i + "0"].error();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#E1001A");
            correcto = false;
        }else{
            this["caja" + i + "0"].correct();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#41A62A");
        }
        
        if( this.respuesta[i] == "-1" ){
            this.respuesta[i] = resp[i];
        }else if( this.respuesta[i] == "+1" ){
            this.respuesta[i] = resp[i];
        }
    }
    return correcto;
    
};

Pagina2.prototype.verSolucion = function(){
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( this.respuesta[i] == "" || JL.str2num(this.respuesta[i]) != this.valor[i]){
            this.respuestaSprite.alpha = 1;
        }
    }
};


//PAGINA 3 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

function Pagina3( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(operacio);
    this.idPregunta = _numpagina;
    //debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;

    this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.figura = new createjs.Container();
    this.figura.y = 60;
    this.figura.x = 80;
    this.figura.addChild( operacio.preguntaSprite );
    this.figura.scaleX = 0.75;
    this.figura.scaleY = 0.75;
    this.contenedor.addChild( this.figura );
    
    
    //es la respuesta en sprite
    this.respuestaSprite = new createjs.Container();
    this.respuestaSprite.y = 250;
    this.respuestaSprite.x = 370;
    this.respuestaSprite.alpha = 0;
    this.respuestaSprite.addChild( operacio.respuestaSprite );
    this.contenedor.addChild( this.respuestaSprite );
    
    this.addLine( 0, 450, 170);
    
    this.respuesta = ["","","","","","",""];
    this.valor = [operacio.respuesta[0][0], operacio.respuesta[0][1], operacio.respuesta[0][2], operacio.respuesta[0][3], operacio.respuesta[0][4], operacio.respuesta[0][5], operacio.respuesta[0][6]]; 
    
}



Pagina3.prototype.addLine = function(index, x, y){
    
    this["caja0"+index] = new CajaTexto();
    this["caja0"+index] .contenedor.x = x - 110;
    this["caja0"+index] .contenedor.y = y - 10;
    this.posicion0X = x - 110;
    this.posicion0Y = y - 10;
    this.posicion0W = 70;
    this.posicion0H = 55;
    this.tamano0 = 20;
    this.contenedor.addChild( this["caja0"+index].contenedor  );
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = "a".toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text"+index].color = "#000";
    this["text"+index].x = x - 30;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja1"+index] = new CajaTexto2();
    this["caja1"+index] .contenedor.x = this["text"+index].x + this["text"+index].getMeasuredWidth();
    this["caja1"+index] .contenedor.y = y - 20;
    this.posicion1X = this["text"+index].x +  this["text"+index].getMeasuredWidth();
    this.posicion1Y = y - 20;
    this.posicion1W = 45;
    this.posicion1H = 35;
    this.tamano1 = 15;
    this.contenedor.addChild( this["caja1"+index].contenedor  );
    
    this["caja2"+index] = new CajaTexto();
    this["caja2"+index] .contenedor.x = 55 + this["text"+index].x + this["text"+index].getMeasuredWidth();
    this["caja2"+index] .contenedor.y = y - 10;
    this.posicion2X = 55 + this["text"+index].x + this["text"+index].getMeasuredWidth();
    this.posicion2Y = y - 10;
    this.posicion2W = 70;
    this.posicion2H = 55;
    this.tamano2 = 20;
    this.contenedor.addChild( this["caja2"+index].contenedor  );
    
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = "a".toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text1"+index].color = "#000";
    this["text1"+index].x = 155 + this["text"+index].x;
    this["text1"+index].y = y + 8;
    this["text1"+index].textAlign = "left";
    this.contenedor.addChild( this["text1"+index]  );
    
    this["caja3"+index] = new CajaTexto2();
    this["caja3"+index] .contenedor.x = this["text1"+index].x + this["text1"+index].getMeasuredWidth();
    this["caja3"+index] .contenedor.y = y - 20;
    this.posicion3X = this["text1"+index].x +  this["text1"+index].getMeasuredWidth();
    this.posicion3Y = y - 20;
    this.posicion3W = 45;
    this.posicion3H = 35;
    this.tamano3 = 15;
    this.contenedor.addChild( this["caja3"+index].contenedor  );
    
    
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = "b".toString();
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text2"+index].color = "#000";
    this["text2"+index].x = 70 + this["text1"+index].x;
    this["text2"+index].y = y + 8;
    this["text2"+index].textAlign = "left";
    this.contenedor.addChild( this["text2"+index]  );
    
    this["caja4"+index] = new CajaTexto2();
    this["caja4"+index] .contenedor.x = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this["caja4"+index] .contenedor.y = y - 20;
    this.posicion4X = this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this.posicion4Y = y - 20;
    this.posicion4W = 45;
    this.posicion4H = 35;
    this.tamano4 = 15;
    this.contenedor.addChild( this["caja4"+index].contenedor  );
    
    
    this["caja5"+index] = new CajaTexto();
    this["caja5"+index] .contenedor.x = 55 + this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this["caja5"+index] .contenedor.y = y - 10;
    this.posicion5X = 55 + this["text2"+index].x + this["text2"+index].getMeasuredWidth();
    this.posicion5Y = y - 10;
    this.posicion5W = 70;
    this.posicion5H = 55;
    this.tamano5 = 20;
    this.contenedor.addChild( this["caja5"+index].contenedor  );
    
    
    this["text3"+index] = new createjs.RichText();
    this["text3"+index].text = "b".toString();
    this["text3"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "26px Verdana" : "24px Verdana" ;
    this["text3"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 26 : 24 ;
    this["text3"+index].color = "#000";
    this["text3"+index].x = 155 + this["text2"+index].x;
    this["text3"+index].y = y + 8;
    this["text3"+index].textAlign = "left";
    this.contenedor.addChild( this["text3"+index]  );
    
    this["caja6"+index] = new CajaTexto2();
    this["caja6"+index] .contenedor.x = this["text3"+index].x + this["text3"+index].getMeasuredWidth();
    this["caja6"+index] .contenedor.y = y - 20;
    this.posicion6X = this["text3"+index].x +  this["text3"+index].getMeasuredWidth();
    this.posicion6Y = y - 20;
    this.posicion6W = 45;
    this.posicion6H = 35;
    this.tamano6 = 15;
    this.contenedor.addChild( this["caja6"+index].contenedor  );
       
};

Pagina3.prototype.getParam = function(){
    this.respuesta[0] = $(Motor.inputDOM0.htmlElement).val();
    this.respuesta[1] = $(Motor.inputDOM1.htmlElement).val();
    this.respuesta[2] = $(Motor.inputDOM2.htmlElement).val();
    this.respuesta[3] = $(Motor.inputDOM3.htmlElement).val();
    this.respuesta[4] = $(Motor.inputDOM4.htmlElement).val();
    this.respuesta[5] = $(Motor.inputDOM5.htmlElement).val();
    this.respuesta[6] = $(Motor.inputDOM6.htmlElement).val();
};

Pagina3.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(this.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(this.respuesta[1]);
    $(Motor.inputDOM2.htmlElement).val(this.respuesta[2]);
    $(Motor.inputDOM3.htmlElement).val(this.respuesta[3]);
    $(Motor.inputDOM4.htmlElement).val(this.respuesta[4]);
    $(Motor.inputDOM5.htmlElement).val(this.respuesta[5]);
    $(Motor.inputDOM6.htmlElement).val(this.respuesta[6]);
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("display","none");
    }
    
    for( var i = 0; i < this.respuesta.length; i++){
        //console.log("numero " + i  + this["posicion" + i + "X"]);
        Motor["inputDOM"+i].element_x = this["posicion" + i + "X"] + 5;
        Motor["inputDOM"+i].element_y = this["posicion" + i + "Y"] + 122;
        Motor["inputDOM"+i].element_width = this["posicion" + i + "W"] - 10;
        Motor["inputDOM"+i].element_height = this["posicion" + i + "H"] - 10;
        Motor["inputDOM"+i].fontsize = this["tamano" + i];
        $(Motor["inputDOM"+i].htmlElement).css("display","inline");
    }
    
    if( this.corregidoPag ){
        this.isValidado();
    }
    
};

Pagina3.prototype.completado = function(){
    this.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    this.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    this.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina3.prototype.isCompletado = function(){
    var correcto = true;
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( this.respuesta[i] == "" ){
            correcto = false;
        }
    }
    return correcto;
};

Pagina3.prototype.bloquea = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","true");
    } 
};

Pagina3.prototype.activa = function(){
    
    //oculto todos los campos
    for(var i = 0; i < 7; i++){
        $(Motor["inputDOM"+i].htmlElement).css("readonly","false");
    } 
};


Pagina3.prototype.isValidado = function(){
    var correcto = true;
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this["caja" + i + "0"].error();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#E1001A");
            correcto = false;
        }else{
            this["caja" + i + "0"].correct();
            $(Motor["inputDOM"+i].htmlElement).css("color", "#41A62A");
        }
    }
    return correcto;
    
};

Pagina3.prototype.verSolucion = function(){
    
    for( var i = 0; i < this.respuesta.length; i++ ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this.respuestaSprite.alpha = 1;
        }
    }
};



function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 70, 55, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 70, 55, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}

function CajaTexto2()
{
    this.contenedor = new createjs.Container();
    this.area = new createjs.Container();
    
    this.fons = new createjs.Shape();
    this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 45, 35, 10);
    
    this.marc = new createjs.Shape();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 45, 35, 10);

    this.area.addChild( this.fons );
    this.area.addChild( this.marc );
    
    this.contenedor.addChild( this.area );
}


CajaTexto2.prototype.clear = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 45, 35, 10);
}
CajaTexto2.prototype.error = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 45, 35, 10);
}

CajaTexto2.prototype.correct = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 45, 35, 10);
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 70, 55, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 70, 55, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 70, 55, 10);
}
