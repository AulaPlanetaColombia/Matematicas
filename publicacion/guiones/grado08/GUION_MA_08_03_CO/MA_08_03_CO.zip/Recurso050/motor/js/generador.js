Generador = new function()
{
	this.nOp;
	this.enun = "";
	this.lPregsSTR = new Array();
    this.lRespsNUM = new Array();
    this.lRespsSTR = new Array();
    //this.lTiposVarMagnitud = Motor.datosXML.variaciones;
    this.lVarMagnitud = new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	
	this.plano = "";
	this.co_pizarraPreg = new createjs.Container();
	this.co_pizarraResp = new createjs.Container();;
	this.base ="";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		Random.init(semilla,100);

		this.co_pizarra = "";

		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();
            //console.log(Motor.lOperaciones[this.nOp]);
		}
	
	}
	
	this.enunciar = function()
	{
	   //NÚCLEO PRINCIPAL: GENERACIÓN DE LOS ARRAYS DE PREGUNTAS Y RESPUESTAS:
        var lPregsSPR = new Array();
        var lRespsSPR = new Array();
        var llRespsNUM = new Array();
    
        var lRespsGradosRES = new Array();
        var lRespsCoefs = new Array();
        var tiraNUMER;
        var tiraDENOM;
        var tiraRESP;
        var longNUMER;
        var longDENOM;
        var coef;
        var lMonomios = new Array();
        var coefRESNUMER;
        var coefRESDENOM;
        var lCoefsNUMER;
        var lCoefsDENOM;
        var lGradosNUMER;
        var lGradosDENOM;
        var mon;
        var trin;
        var pol_P;
        var pol_Q;        
	   
	    var variacion = Motor.lVariaciones[this.nOp];
	    EA._formatoBase = ["Arial",30,"#000",false];
        this.co_pizarraPreg = EA.ini(' ');
        this.co_pizarraResp = EA.ini(' ');
                
        switch(variacion){
            case 1://producto/cociente de monomios
                lGradosNUMER=[0,0,0,0,0];
                lGradosDENOM=[0,0,0,0,0];
                
                //numerador (si es cociente):
                tiraNUMER=EA.ini(' ');
                longNUMER=Random.integer(2,3);
                while(true){
                    coefRESNUMER=1;
                    lCoefsNUMER=new Array();
                    for(var i = 0;i<longNUMER; i++){
                        coef=Random.integer(-4,4,[0]);
                        coefRESNUMER*=coef;
                        lCoefsNUMER.push(coef);
                    }
                    if(Math.abs(coefRESNUMER)<99){//sale con el coeficiente resultado ya calculado
                        break;
                    }
                }
                for(i=0;i<longNUMER;i++){
                    //recoge el coeficiente:
                    if(lCoefsNUMER[i]==1){
                        mon=EA.ini(' ');
                    }else if(lCoefsNUMER[i]==-1){
                        mon=EA.ini('− ');
                    }else{
                        var absCoef = String(Math.abs(lCoefsNUMER[i]));
                        if(lCoefsNUMER[i]<0){absCoef='− '+absCoef}
                        mon=EA.ini(absCoef);
                    }
                    //decide la parte literal y va calculando su resultante:
                    while(true){
                        var lGrados = new Array();
                        var gradoTotal = 0;

                        for(var k = 0; k<5; k++){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                            var grado = [0,0,0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,3,3,4][Random.integer(0,19)]; 
                            lGrados[k]=grado;
                            gradoTotal+=grado;
                        }
                        if(gradoTotal>0){
                            break;
                        }
                    }

                    for(var j = 0;j<5;j++){
                        var letra = ['x','y','z','w','t'][j];
                        grado=lGrados[j];
                        if(grado>1){
                            EA.adcStatic(EA.pot(letra,String(grado)),mon, 25);
                        }else if(grado==1){
                            EA.adcStatic(letra,mon, 25);
                        }
                        lGradosNUMER[j]+=grado;
                    }
                    //
                    if(lCoefsNUMER[i]<0){
                        //EA.adc(' ',mon);//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        mon=EA.par(mon, -5, 5);
                        //EA.adc(' ',mon);//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    }
                    //
                    if(i<longNUMER-1){
                        EA.adcStatic(' ·  ',mon, 25);
                    }
                    EA.adcStatic(mon,tiraNUMER);
                }
                //decide si es cociente o no:
                if(Random.boolean(0)){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //solo producto: lo hecho ya vale y lo guarda
                    lPregsSPR.push(tiraNUMER);
                    lRespsCoefs.push(coefRESNUMER);

                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    if(coefRESNUMER<0){
                        tiraRESP=EA.ini('- ');
                    }else{
                        tiraRESP=EA.ini(' ');
                    }
                    if(Math.abs(coefRESNUMER)!=1){
                        EA.adcStatic(String(Math.abs(coefRESNUMER)),tiraRESP, 25);
                    }
                    for(j=0;j<5;j++){
                        letra=['x','y','z','w','t'][j];
                        grado=lGradosNUMER[j];
                        if(grado>1){
                            EA.adcStatic(EA.pot(letra,String(grado)),tiraRESP, 25);
                        }else if(grado==1){
                            EA.adcStatic(letra,tiraRESP, 25);
                        }
                    }
                    lRespsSPR.push(tiraRESP);
                    var auxLista = lGradosNUMER.slice();
                    auxLista.unshift(coefRESNUMER);
                    llRespsNUM.push(auxLista.slice());
                }else{
                    //cociente: ha de montar el denominador
                    tiraDENOM=EA.ini(' ');
                    longDENOM=Random.integer(1,2);
                    while(true){
                        coefRESDENOM=1;
                        lCoefsDENOM=new Array();
                        for(i=0;i<longDENOM;i++){
                            coef=Random.integer(-3,3,[0]);
                            coefRESDENOM*=coef;
                            lCoefsDENOM.push(coef);
                        }
                        if(coefRESNUMER%coefRESDENOM==0){//sale con el coeficiente resultado ya calculado
                            var coefResp = coefRESNUMER/coefRESDENOM;
                            break;
                        }
                    }
                    for(i=0;i<longDENOM;i++){
                        //recoge el coeficiente:
                        if(lCoefsDENOM[i]==1){
                            mon=EA.ini(' ');
                        }else if(lCoefsDENOM[i]==-1){
                            mon=EA.ini('− ');
                        }else{
                            absCoef=String(Math.abs(lCoefsDENOM[i]));
                            if(lCoefsDENOM[i]<0){absCoef='− '+absCoef}
                            mon=EA.ini(absCoef);
                        }
                        //decide la parte literal y va calculando su resultante:
                        while(true){
                            lGrados=new Array();
                            gradoTotal=0;

                            for(k=0;k<5;k++){
                                grado=[0,0,0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,3,3,4][Random.integer(0,19)]; 
                                lGrados[k]=grado;
                                gradoTotal+=grado;
                            }
                            if(gradoTotal>0){
                                break;
                            }
                        }

                        for(j=0;j<5;j++){
                            letra=['x','y','z','w','t'][j];
                            grado=lGrados[j];
                            if(grado>1){
                                EA.adcStatic(EA.pot(letra,String(grado)),mon, 25);
                            }else if(grado==1){
                                EA.adcStatic(letra,mon, 25);
                            }
                            lGradosDENOM[j]+=grado;
                        }
                        //
                        if(lCoefsDENOM[i]<0){
                            mon=EA.par(mon, -5, 5);
                        }
                        //
                        if(i<longDENOM-1){
                            EA.adcStatic(' ·  ',mon, 25);
                        }
                        EA.adcStatic(mon,tiraDENOM, 25);
                    }
                    //monta la fracción pregunta...
                    //...calcula los resultados del coeficiente y los exponentes...
                    //...monta el sprite resultado...
                    //...y va guardando todo:
                    lPregsSPR.push(EA.fra(tiraNUMER,tiraDENOM));
                    lRespsCoefs.push(coefResp);
                    lRespsGradosRES=new Array();


                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    for(j=0;j<5;j++){
                        lRespsGradosRES[j]=lGradosNUMER[j]-lGradosDENOM[j];
                    }
                    if(coefResp==1){
                        mon=EA.ini(' ');
                    }else if(coefResp==-1){
                        mon=EA.ini('−');
                    }else{
                        mon=EA.ini(String(coefResp).replace('-','−'));
                    }
//                  for(j=0;j<5;j++){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    for(j=0;j<5;j++){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        letra=['x','y','z','w','t'][j];
                        grado=lRespsGradosRES[j];
                        if((grado!=0)&&(grado!=1)){
                            EA.adcStatic(EA.pot(letra,String(grado).replace('-','−')),mon, 20);
                        }else if(grado==1){
                            EA.adcStatic(letra,mon, 20);
                        }
                    }
                    lRespsSPR.push(mon);
                    auxLista=lRespsGradosRES.slice();
                    auxLista.unshift(coefResp);
                    llRespsNUM.push(auxLista.slice());  
                }
                this.co_pizarraPreg.addChild(lPregsSPR[0]);
                this.co_pizarraResp.addChild(lRespsSPR[0]);
            break;
                //==============================================================
            case 2://suma/resta/multiplicación de polinomios
                var lP_X = new Array();
                var lQ_X = new Array();
                var lR_X = new Array();
                var tiraPregSPR = EA.ini(' ');
                
                this.co_pizarraPreg.addChild(tiraPregSPR);
                
                //tiraRespSPR.y=200;
                //decide qué operación es:
                if(Random.boolean(0.5)){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    //suma/resta:
                    for(i=0;i<6;i++){
                        lP_X.push(Random.integer(-5,5));
                        lQ_X.push(Random.integer(-5,5));
                    }
                    //EA.co = new createjs.Container();
                    pol_P=EA.pol(lP_X,'x',true);
                    pol_Q=EA.pol(lQ_X,'x',true);
                   
                    EA.adcStatic(pol_P,tiraPregSPR);
                    //decide si suma o resta y calcula:
                    if(Random.boolean(0.5)){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        //suma:
                        EA.adcStatic(' +  ',tiraPregSPR);
                        for(var g=0;g<6;g++){
                            lR_X[g]=lP_X[g]+lQ_X[g];
                        }
                    }else{
                        //resta:
                        EA.adcStatic(' −  ',tiraPregSPR);
                        for(g=0;g<6;g++){
                            lR_X[g]=lP_X[g]-lQ_X[g];
                        }
                    }
                    EA.adcStatic(EA.par(pol_Q, -5 ,5),tiraPregSPR);
                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    var tiraRespSPR = EA.ini(' ');
                    this.co_pizarraResp.addChild(tiraRespSPR);
                    EA.adcStatic(EA.pol(lR_X,'x',true),tiraRespSPR);
                }else{
                    //multiplicación:
                    //decide los grados de ambos polinomios (suma<6):
                    while(true){
                        var grado_P = Random.integer(1,4);
                        var grado_Q = Random.integer(1,4);
                        if(grado_P + grado_Q < 6){
                            break;
                        }
                    }
                    //decide los coeficientes:
                    lP_X=new Array();
                    lP_X[grado_P]=Random.integer(-5,5,[0]);
                    for(g=0;g<grado_P;g++){
                        lP_X[g]=Random.integer(-5,5);
                    }
                    //console.log(lP_X);
                    lQ_X=new Array();
                    lQ_X[grado_Q]=Random.integer(-5,5,[0]);
                    for(g=0;g<grado_Q;g++){
                        lQ_X[g]=Random.integer(-5,5);
                    }
                    //console.log(lQ_X);
                    //calcula el polinomio producto:
                    lR_X=[0,0,0,0,0,0];
                    for(var gP = 0;gP<lP_X.length;gP++){
                        var A = lP_X[gP];
                        for(var gQ = 0;gQ<lQ_X.length;gQ++){
                            var B = lQ_X[gQ];
                            lR_X[gP+gQ]+=A*B;
                        }
                    }
                    //console.log(lR_X);
                    //monta los polinomios:
                    
                    //var polin = JL.crearPolinomio(cont, lP_X, [0,0], 30, "#000", true);
                    //EA.adcStatic(polin, tiraPregSPR);
                    
                    //EA.adcStatic(EA.pol(lP_X,'x',true), tiraPregSPR);
                    EA.adcStatic(EA.par(EA.pol(lP_X,'x',true), -5 , 5),tiraPregSPR);
                    EA.adcStatic(' ·  ',tiraPregSPR);
                    EA.adcStatic(EA.par(EA.pol(lQ_X,'x',true), -5 , 5),tiraPregSPR);
                    
                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    var tiraRespSPR = EA.ini(' ');
                    this.co_pizarraResp.addChild(tiraRespSPR);
                    EA.adcStatic(EA.pol(lR_X,'x',true),tiraRespSPR);
                }
                lPregsSPR.push(tiraPregSPR);
                lRespsSPR.push(tiraRespSPR);
                llRespsNUM.push(lR_X.slice());
                
                this.co_pizarraPreg.addChild(lPregsSPR[0]);
                this.co_pizarraResp.addChild(lRespsSPR[0]);
                break;
                //==============================================================
            case 3://productos notables
                var tipo = Random.integer(0,1);
                if(tipo<2){// (a+-b)^2
                    //decide los coefs del binomio:
                    var coef_A = Random.integer(1,9);
                    var coef_B = Random.integer(1,9);
                    var expo_A = Random.integer(1,4);
                    var expo_B = Random.integer(1,4);
                    //calcula los coefs y los expos del trinomio resultado:
                    var coef_A2 = coef_A*coef_A;
                    var coef_B2 = coef_B*coef_B;
                    var coef_AB = 2*coef_A*coef_B;
                    var expo_A2 = 2*expo_A;
                    var expo_B2 = 2*expo_B;
                    var expo_ABa = expo_A;
                    var expo_ABb = expo_B;
                    if(tipo==1){coef_AB=-coef_AB;}
                    llRespsNUM.push([coef_A2,expo_A2,coef_AB,expo_ABa,expo_ABb,coef_B2,expo_B2]);
                    
                    //monta los sprites:
                    if(coef_A>1){
                        trin=EA.ini(String(coef_A));
                    }else{
                        trin=EA.ini('');
                    }
                    EA.adcStatic('a',trin, 25);
                    if(expo_A>1){
                        trin=EA.ade(trin,String(expo_A), -30);
                    }
                    if(tipo==0){
                        EA.adcStatic(' + ',trin, 25);
                    }else{
                        EA.adcStatic(' − ',trin, 25);
                    }
                    if(coef_B>1){
                        EA.adcStatic(String(coef_B),trin, 25);
                    }
                    EA.adcStatic('b',trin, 25);
                    if(expo_B>1){
                        trin=EA.ade(trin,String(expo_B), -20);
                    }
                    trin=EA.par(trin, -5 ,3);
                    trin=EA.ade(trin,'2', -30);
                    lPregsSPR.push(trin);
                    //
                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    if(coef_A2>1){
                        trin=EA.ini(String(coef_A2));
                    }else{
                        trin=EA.ini(' ');
                    }
                    EA.adcStatic(EA.pot('a',String(expo_A2)),trin, 20);
                    if(tipo==0){
                        EA.adcStatic(' + ',trin, 20);
                    }else{
                        EA.adcStatic(' − ',trin, 20);
                    }
                    EA.adcStatic(String(Math.abs(coef_AB)),trin, 20);
                    EA.adcStatic('a',trin, 20);
                    if(expo_ABa>1){
                        trin=EA.ade(trin,String(expo_ABa), -15);
                    }
                    EA.adcStatic('b',trin, 20);
                    if(expo_ABb>1){
                        trin=EA.ade(trin,String(expo_ABb), -15);
                    }
                    EA.adcStatic(' + ',trin, 20);
                    if(coef_B2>1){
                        EA.adcStatic(String(coef_B2),trin, 20);
                    }
                    EA.adcStatic(EA.pot('b',String(expo_B2)),trin, 20);
                    lRespsSPR.push(trin);
                }else{// (a+b)·(a-b)
                    //decide los coefs de los binomios:
                    coef_A=Random.integer(1,9);
                    coef_B=Random.integer(1,9);
                    expo_A=Random.integer(1,4);
                    expo_B=Random.integer(1,4);
                    //calcula los coefs y los expos del trinomio resultado:
                    coef_A2=coef_A*coef_A;
                    coef_B2=coef_B*coef_B;
                    expo_A2=2*expo_A;
                    expo_B2=2*expo_B;
                    llRespsNUM.push([coef_A2,expo_A2,coef_B2,expo_B2]);
                    //monta los sprites:
                    //1º
                    if(coef_A>1){
                        trin=EA.ini(String(coef_A));
                    }else{
                        trin=EA.ini(' ');
                    }
                    EA.adcStatic('a',trin);
                    if(expo_A>1){
                        trin=EA.ade(trin,String(expo_A));
                    }
                    var flag = Random.boolean(0.5);
                    if(flag){
                        EA.adcStatic('+',trin, 25);
                    }else{
                        EA.adcStatic('-',trin, 25);
                    }
                    if(coef_B>1){
                        EA.adcStatic(String(coef_B),trin, 25);
                    }
                    EA.adcStatic('b',trin);
                    if(expo_B>1){
                        trin=EA.ade(trin,String(expo_B));
                    }
                    trin=EA.par(trin, -5 , 5);
                    EA.adcStatic('· ',trin, 25);
                    //2º
                    if(coef_A>1){
                        var trin2 = EA.ini(String(coef_A));
                    }else{
                        trin2=EA.ini(' ');
                    }
                    EA.adcStatic('a',trin2, 25);
                    if(expo_A>1){
                        trin2=EA.ade(trin2,String(expo_A));
                    }
                    if(flag){
                        EA.adcStatic('-',trin2, 25);
                    }else{
                        EA.adcStatic('+',trin2, 25);
                    }
                    if(coef_B>1){
                        EA.adcStatic(String(coef_B),trin2, 25);
                    }
                    EA.adcStatic('b',trin2);
                    if(expo_B>1){
                        trin2=EA.ade(trin2,String(expo_B));
                    }
                    trin2=EA.par(trin2);
                    EA.adcStatic(trin2,trin);
                    lPregsSPR.push(trin);
                    //res
                    EA._formatoBase = ["Arial",24,"#E1001A",false];
                    if(coef_A2>1){
                        trin=EA.ini(String(coef_A2));
                    }else{
                        trin=EA.ini(' ');
                    }
                    EA.adcStatic('a',trin);
                    if(expo_A2>1){
                        trin=EA.ade(trin,String(expo_A2));
                    }
                    EA.adcStatic('-',trin);
                    if(coef_B2>1){
                        EA.adcStatic(String(coef_B2),trin);
                    }
                    EA.adcStatic('b',trin);
                    if(expo_B2>1){
                        trin=EA.ade(trin,String(expo_B2));
                    }
                    lRespsSPR.push(trin); 
                }
                this.co_pizarraPreg.addChild(lPregsSPR[0]);
                this.co_pizarraResp.addChild(lRespsSPR[0]);
            break;
        }
        
        ///A PARTIR DE AQUI LLENO MI ARRAY DE OPERACIONES; CON LOS VALORES DE LAS ARRAYS DE PREGUNTAS, RESPUESTAS, TIPO DE RESPUESTA en cada paso de nPreg
        Motor.lOperaciones[this.nOp] = new Object();
        Motor.lOperaciones[this.nOp].pregunta = lPregsSPR;
        Motor.lOperaciones[this.nOp].respuesta = llRespsNUM;
        if(variacion==2){
            Motor.lOperaciones[this.nOp].respuesta=llRespsNUM.reverse();
        }
        Motor.lOperaciones[this.nOp].respuestaString = lRespsSPR;
        if(variacion<3){
            Motor.lOperaciones[this.nOp].respuesta.push("");
        }
        Motor.lOperaciones[this.nOp].entrada=["","","","","","",""];
        Motor.lOperaciones[this.nOp].estaListo = false;
        Motor.lOperaciones[this.nOp].correcto = false;
        Motor.lOperaciones[this.nOp].variacion = variacion;
        Motor.lOperaciones[this.nOp].enunciado = Motor.datosXML.enunciados[0].enunciado.toString();
        Motor.lOperaciones[this.nOp].preguntaSprite = this.co_pizarraPreg;
        Motor.lOperaciones[this.nOp].respuestaSprite = this.co_pizarraResp;
        Motor.lOperaciones[this.nOp].variacion = variacion;
   
	};
}