(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
        titulo1(this,txt['titulo']);
this.btn1 = new lib.IMG_01();
	this.btn1.setTransform(234.5,91);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.IMG_01(), 3);
   this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
       this.btn1.on("click", function (evt) {
            putStage(new lib.frame2());
        });
     
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.btn1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       	this.instance = new lib.textoAnimado_01();
	this.instance.setTransform(81,152.9);


        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        
this.instance = new lib.textoAnimado02();
	this.instance.setTransform(470.2,309.6,1,1,0,0,0,389.2,141.4);
 var html = createDiv(txt['txt_12'], "Verdana", "20px", '340px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 170-608);
    html = createDiv(txt['txt_12b'], "Verdana", "20px", '340px', '100px', "20px", "185px", "left");
    this.texto1b = new lib.fadeText(html, 80);
    this.texto1b.setTransform(90, 170-608);
    html = createDiv(txt['txt_12c'], "Verdana", "20px", '340px', '100px', "20px", "185px", "left");
    this.texto1c = new lib.fadeText(html, 220);
    this.texto1c.setTransform(90, 170-608);
    
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1,this.texto1b,this.texto1c);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance = new lib.textoAnimado_03();
	this.instance.setTransform(471.4,331.1,1,1,0,0,0,390.4,176.7);

 var html = createDiv(txt['txt_13'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 170-608);
    html = createDiv(txt['txt_13b'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1b = new lib.fadeText(html, 140);
    this.texto1b.setTransform(90, 170-608);
    html = createDiv(txt['txt_13c'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1c = new lib.fadeText(html, 260);
    this.texto1c.setTransform(90, 170-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1,this.texto1b,this.texto1c);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       this.instance = new lib.textoAnimado_04();
	this.instance.setTransform(475.9,264.3,1,1,0,0,0,394.9,111.4);
 var html = createDiv(txt['txt_14'], "Verdana", "20px", '790px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 170-608);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       	this.grafico = new lib.textoAnimado_05();
	this.grafico.setTransform(477,295.2,1,1,0,0,0,396,181.3);
var html = createDiv(txt['txt_15'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(90, 150-608);
    html = createDiv(txt['txt_15b'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1b = new lib.fadeText(html, 20);
    this.texto1b.setTransform(90, 150-608);
    html = createDiv(txt['txt_15c'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1c = new lib.fadeText(html, 90);
    this.texto1c.setTransform(90, 150-608);
    html = createDiv(txt['txt_15d'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1d = new lib.fadeText(html, 140);
    this.texto1d.setTransform(90, 150-608);
    html = createDiv(txt['txt_15e'], "Verdana", "20px", '430px', '100px', "20px", "185px", "left");
    this.texto1e = new lib.fadeText(html, 200);
    this.texto1e.setTransform(90, 150-608);

         this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame7());
    });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.practica, this.anterior,this.siguiente,this.grafico,this.texto1,this.texto1b,this.texto1c,this.texto1d,this.texto1e);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_practica']);
this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ArS1EID4AAAqMHCID4AAArNnBID4AAAi/1EID1AAAhRnBID1AAAhlHCID1AAAHlHCID3AAAF01EID3AAAHTnBID3AAAi1VGID1AAAFFVGID4AAArcVGID4AA");
	this.shape.setTransform(182.9,346.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AsRYHQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAD6YGIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAIQgCAHgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAjDYGIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAj7XOIA4AAIAAhBgAJEVcIAAgPIB0AAIAAAPgAAVVOIAAgcIAXAAIAAAcgAoUVHIAAgPIBhAAIAAAPgAJEUzIAAgQIB0AAIAAAQgAjtUTQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAEGUTIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgAsnUTIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAgOC3IgEgGIgYgjQAOARAMASIACADQC3EIi2EEQCRkYiSjxgAsWC0IACgDQAMgSAOgRIgYAjIgEAGQiUDxCTEYQi4kEC5kIgArBKDQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAGaKCIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAIQgCAHgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAhyKCIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAiqJKIA4AAIAAhBgALkHYIAAgPIB0AAIAAAPgAC1HKIAAgcIAXAAIAAAcgAnEHDIAAgPIBhAAIAAAPgALkGvIAAgQIB0AAIAAAQgAicGPQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAGmGPIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgArXGPIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAIqrLIgEgGIgYgjQAOARAMASIACADQC5EIi4EEQCTkYiUjxgAjcrOIACgDQAMgSAOgRIgYAjIgEAGQiUDxCTEYQi4kEC5kIgAGbkAQgLgCgIgDIAAgVIACAAQAIAFALAEQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAr5kAQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgDALAAQAJAAAHACQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAr3lLQgHACgIAFIAAAEIAAAFQAAAPADAJQADAJAGAFQAEAEAGADQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHABgAidkAIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAClmJIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAn0mSIAAgcIAXAAIAAAcgAMAm1IAAgQIB0AAIAAAQgAMAneIAAgPIB0AAIAAAPgAn0njIAAgcIAXAAIAAAcgAsCnyQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAHFnzIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAGNorIA4AAIAAhBgAiRnzIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgAE8yEQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAr+yEQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgDALAAQAJABAHABQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAr8zOQgHABgIAFIAAAEIAAAFQAAAPADAJQADAJAGAFQAEAFAGACQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHACgAkLyEIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAnj0LIAAgcIAXAAIAAAcgAA80NIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAKK0uIAAgPIB0AAIAAAPgAKK1XIAAgQIB0AAIAAAQgAnj1cIAAgcIAXAAIAAAcgAsH12QgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAFm13IAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAEu2vIA4AAIAAhBgAj/13IAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOg");
	this.shape_1.setTransform(197.9,347.8);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
   this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame8());
    });
        this.addChild(this.logo, this.titulo,  this.practica, this.cerrar, this.anterior, this.siguiente,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
  (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
  this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF6600").ss(1,1,1).p("AjwOEIDfAAAhsuDID1AAAgEAAID1AA");
	this.shape.setTransform(314,391.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("ArS1EID4AAAqMHCID4AAArNnBID4AAAi/1EID1AAAhRnBID1AAAhlHCID1AAAHlHCID3AAAHTnBID3AAAF01EID3AAAi1VGID1AAAFFVGID4AAArcVGID4AA");
	this.shape_1.setTransform(182.9,346.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AhUXMQgMgFgHgKQgHgJgDgOQgDgPAAgSQAAgTADgOQADgOAIgKQAHgJALgFQAMgFAQAAQARAAALAFQALAFAHAKQAIAKACAOQACAOAAASQAAASgCAPQgDAOgHAKQgHAJgLAFQgMAFgQAAQgQAAgMgFgAhJVfQgGAMAAAaQAAAaAGALQAFAMAMAAQAMAAAFgMQAFgLAAgaQAAgagFgMQgFgLgMAAQgMAAgFALgAi/XOIAAgiIhGAAIAAgbIBEhVIAmAAIAABWIAUAAIAAAaIgUAAIAAAigAjpWSIAqAAIAAg1gAisTbIAAgaIAeAAIAAhMIgeAAIAAgYIANgBQAHgBAEgCQAFgCADgEQACgEAAgGIAhAAIAAB4IAeAAIAAAagACuJIQgMgFgHgKQgHgJgDgOQgDgPAAgSQAAgTADgOQADgOAIgKQAHgJALgFQAMgFAQAAQARAAALAFQALAFAHAKQAIAKADAOQADAOAAASQAAASgDAPQgEAOgHAKQgHAJgLAFQgMAFgQAAQgQAAgMgFgAC5HbQgGAMAAAaQAAAaAGALQAFAMAMAAQAMAAAFgMQAFgLAAgaQAAgagFgMQgFgLgMAAQgMAAgFALgABDJKIAAgiIhEAAIAAgbIBChVIAmAAIAABWIAUAAIAAAaIgUAAIAAAigAAZIOIAqAAIAAg1gAitGLIAAgQIBhAAIAAAQgABRFXIBFh2IhLAAIAAgcIByAAIAAAdIhCB1gAAtk4IAAgaIAeAAIAAhMIgeAAIAAgYIANgBQAHgBAEgCQAFgCADgEQACgEAAgGIAhAAIAAB4IAeAAIAAAagAhfk4IAAgaIAeAAIAAhMIgeAAIAAgYIANgBQAHgBAEgCQAFgCADgEQACgEAAgGIAhAAIAAB4IAcAAIAAAagAgPorQgMgDgHgDIAAggIAEAAQAJAFAKAEQAKADAIAAIAOgBQAHgCAEgDIAFgHQACgDAAgGQAAgFgCgEQgDgEgDgCQgGgDgHgBIgOgBQgGAAgIABIgOADIgFAAIAAhSIBmAAIAAAcIhFAAIAAAYIAIAAIAIgBQAMAAAKADQAJACAHAEQAJAFAFAJQAFAJAAAOQAAALgEAKQgFAJgIAHQgJAIgLADQgMAEgPAAQgPAAgNgDgAif07QgNgDgIgDIAAggIAEAAQAIAFAMADQALAEAKAAIAMgBQAHgBAFgDQADgCACgEQADgDAAgHQAAgGgDgDQgDgEgFgBQgFgCgHAAIgMAAIgIAAIAAgaIAIAAIAOgBQAGAAAEgCQAEgCACgDQACgDAAgGQAAgEgCgDQgCgDgEgBQgDgCgGgBIgJAAQgJAAgKADQgLADgKAGIgEAAIAAggIAWgGQAOgDAOAAQAOAAAKADQAKACAHAEQAIAFAEAHQAEAHAAAJQAAAMgIAJQgHAKgMADIAAABIAKADQAGACAEAEQAFAEADAFQADAGAAAJQAAAKgEAJQgEAJgJAGQgIAGgLAEQgLADgQAAQgSAAgNgDg");
	this.shape_2.setTransform(313.5,353.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AsRYHQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAD6YGIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAIQgCAHgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAjDYGIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAj7XOIA4AAIAAhBgAJEVcIAAgPIB0AAIAAAPgAAVVOIAAgcIAXAAIAAAcgAoUVHIAAgPIBhAAIAAAPgAJEUzIAAgQIB0AAIAAAQgAjtUTQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAEGUTIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgAsnUTIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAgOC3IgEgGIgYgjQAOARAMASIACADQC3EIi2EEQCRkYiSjxgAsWC0IACgDQAMgSAOgRIgYAjIgEAGQiUDxCTEYQi4kEC5kIgArBKDQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAGaKCIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAIQgCAHgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAhyKCIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAiqJKIA4AAIAAhBgALkHYIAAgPIB0AAIAAAPgAC1HKIAAgcIAXAAIAAAcgAnEHDIAAgPIBhAAIAAAPgALkGvIAAgQIB0AAIAAAQgAicGPQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAGmGPIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgArXGPIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAIqrLIgEgGIgYgjQAOARAMASIACADQC5EIi4EEQCTkYiUjxgAjcrOIACgDQAMgSAOgRIgYAjIgEAGQiUDxCTEYQi4kEC5kIgAGbkAQgLgCgIgDIAAgVIACAAQAIAFALAEQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAr5kAQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgDALAAQAJAAAHACQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAr3lLQgHACgIAFIAAAEIAAAFQAAAPADAJQADAJAGAFQAEAEAGADQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHABgAidkAIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAClmJIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAn0mSIAAgcIAXAAIAAAcgAMAm1IAAgQIB0AAIAAAQgAMAneIAAgPIB0AAIAAAPgAn0njIAAgcIAXAAIAAAcgAsCnyQgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAHFnzIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAGNorIA4AAIAAhBgAiRnzIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgAE8yEQgLgCgIgDIAAgVIACAAQAIAGALADQALADALABQAGAAAHgCQAHgDAEgDQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgPIAGAAQAPgBAJgGQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAr+yEQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgDALAAQAJABAHABQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAr8zOQgHABgIAFIAAAEIAAAFQAAAPADAJQADAJAGAFQAEAFAGACQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHACgAkLyEIAAgUIAVgSIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAnj0LIAAgcIAXAAIAAAcgAA80NIAAg2Ig1AAIAAgPIA1AAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2gAKK0uIAAgPIB0AAIAAAPgAKK1XIAAgQIB0AAIAAAQgAnj1cIAAgcIAXAAIAAAcgAsH12QgLgDgIgDIAAgVIABAAQAIAGALADQALADAKABQAHAAAHgCQAGgDAFgEQAFgEACgGQACgGAAgIQAAgIgDgEQgCgFgFgEQgFgDgHgCQgHgBgJgBIgRABIgOADIAAhLIBYAAIAAARIhFAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAGAEAIQAFAIAAANQAAALgEAIQgEAKgGAGQgHAHgKAEQgKAEgMAAQgMAAgLgDgAFm13IAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAEu2vIA4AAIAAhBgAj/13IAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOg");
	this.shape_3.setTransform(197.9,347.8);
        this.addChild(this.logo, this.titulo,  this.practica, this.cerrar, this.anterior, this.siguiente,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,231);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,565,322);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,565,322);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,404,395);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_48700159_OPT = function() {
	this.initialize(img.shutterstock_48700159_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,850,409);


(lib.shutterstock_50808379_OPT = function() {
	this.initialize(img.shutterstock_50808379_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,331);


(lib.textoAnimado02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3 (mask)


	// Capa 6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_143 = new cjs.Graphics().p("Aa3Q7IAAwtIFeAAIAAQtg");
	var mask_1_graphics_144 = new cjs.Graphics().p("AjzIWIAAwrIHnAAIAAQrg");
	var mask_1_graphics_145 = new cjs.Graphics().p("Ak4IWIAAwrIJxAAIAAQrg");
	var mask_1_graphics_146 = new cjs.Graphics().p("Al9IWIAAwrIL7AAIAAQrg");
	var mask_1_graphics_147 = new cjs.Graphics().p("AnCIWIAAwrIOFAAIAAQrg");
	var mask_1_graphics_148 = new cjs.Graphics().p("AoHIWIAAwrIQPAAIAAQrg");
	var mask_1_graphics_149 = new cjs.Graphics().p("ApMIWIAAwrISZAAIAAQrg");
	var mask_1_graphics_150 = new cjs.Graphics().p("AqRIWIAAwrIUjAAIAAQrg");
	var mask_1_graphics_151 = new cjs.Graphics().p("ArWIWIAAwrIWtAAIAAQrg");
	var mask_1_graphics_152 = new cjs.Graphics().p("AsbIWIAAwrIY3AAIAAQrg");
	var mask_1_graphics_153 = new cjs.Graphics().p("AtgIWIAAwrIbBAAIAAQrg");
	var mask_1_graphics_154 = new cjs.Graphics().p("AulIWIAAwrIdLAAIAAQrg");
	var mask_1_graphics_155 = new cjs.Graphics().p("AvqIWIAAwrIfVAAIAAQrg");
	var mask_1_graphics_156 = new cjs.Graphics().p("AwvIWIAAwrMAhfAAAIAAQrg");
	var mask_1_graphics_157 = new cjs.Graphics().p("Ax1IWIAAwrMAjrAAAIAAQrg");
	var mask_1_graphics_158 = new cjs.Graphics().p("Ay6IWIAAwrMAl1AAAIAAQrg");
	var mask_1_graphics_159 = new cjs.Graphics().p("Az/IWIAAwrMAn/AAAIAAQrg");
	var mask_1_graphics_160 = new cjs.Graphics().p("A1EIWIAAwrMAqJAAAIAAQrg");
	var mask_1_graphics_161 = new cjs.Graphics().p("A2JIWIAAwrMAsTAAAIAAQrg");
	var mask_1_graphics_162 = new cjs.Graphics().p("A3OIWIAAwrMAudAAAIAAQrg");
	var mask_1_graphics_163 = new cjs.Graphics().p("A4TIWIAAwrMAwnAAAIAAQrg");
	var mask_1_graphics_164 = new cjs.Graphics().p("A5YIWIAAwrMAyxAAAIAAQrg");
	var mask_1_graphics_165 = new cjs.Graphics().p("A6dIWIAAwrMA07AAAIAAQrg");
	var mask_1_graphics_166 = new cjs.Graphics().p("A7iIWIAAwrMA3FAAAIAAQrg");
	var mask_1_graphics_167 = new cjs.Graphics().p("A8nIWIAAwrMA5PAAAIAAQrg");
	var mask_1_graphics_168 = new cjs.Graphics().p("A9sIWIAAwrMA7ZAAAIAAQrg");
	var mask_1_graphics_169 = new cjs.Graphics().p("A+xIWIAAwrMA9jAAAIAAQrg");
	var mask_1_graphics_170 = new cjs.Graphics().p("A/2IWIAAwrMA/uAAAIAAQrg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(143).to({graphics:mask_1_graphics_143,x:207,y:108.4}).wait(1).to({graphics:mask_1_graphics_144,x:403.4,y:163.3}).wait(1).to({graphics:mask_1_graphics_145,x:410.3,y:163.3}).wait(1).to({graphics:mask_1_graphics_146,x:417.2,y:163.3}).wait(1).to({graphics:mask_1_graphics_147,x:424.1,y:163.3}).wait(1).to({graphics:mask_1_graphics_148,x:431,y:163.3}).wait(1).to({graphics:mask_1_graphics_149,x:437.9,y:163.3}).wait(1).to({graphics:mask_1_graphics_150,x:444.8,y:163.3}).wait(1).to({graphics:mask_1_graphics_151,x:451.7,y:163.3}).wait(1).to({graphics:mask_1_graphics_152,x:458.6,y:163.3}).wait(1).to({graphics:mask_1_graphics_153,x:465.5,y:163.3}).wait(1).to({graphics:mask_1_graphics_154,x:472.4,y:163.3}).wait(1).to({graphics:mask_1_graphics_155,x:479.3,y:163.3}).wait(1).to({graphics:mask_1_graphics_156,x:486.2,y:163.3}).wait(1).to({graphics:mask_1_graphics_157,x:493.2,y:163.3}).wait(1).to({graphics:mask_1_graphics_158,x:500.1,y:163.3}).wait(1).to({graphics:mask_1_graphics_159,x:507,y:163.3}).wait(1).to({graphics:mask_1_graphics_160,x:513.9,y:163.3}).wait(1).to({graphics:mask_1_graphics_161,x:520.8,y:163.3}).wait(1).to({graphics:mask_1_graphics_162,x:527.7,y:163.3}).wait(1).to({graphics:mask_1_graphics_163,x:534.6,y:163.3}).wait(1).to({graphics:mask_1_graphics_164,x:541.5,y:163.3}).wait(1).to({graphics:mask_1_graphics_165,x:548.4,y:163.3}).wait(1).to({graphics:mask_1_graphics_166,x:555.3,y:163.3}).wait(1).to({graphics:mask_1_graphics_167,x:562.2,y:163.3}).wait(1).to({graphics:mask_1_graphics_168,x:569.1,y:163.3}).wait(1).to({graphics:mask_1_graphics_169,x:576,y:163.3}).wait(1).to({graphics:mask_1_graphics_170,x:583,y:163.3}).wait(77));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AIbAAIKHAAAYDAAID3AAApNAAID3AAAhAAAID1AAA74AAID3AAAzSAAID3AA");
	this.shape.setTransform(597.3,169.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AZODBQgJgDgHgGQgIgJgFgNQgEgNAAgTQAAgTADgPQAFgPAJgMQAJgLANgGQANgGATAAIAJAAIAIACIAAATIgBAAIgIgDQgFgCgHAAQgUAAgNAOQgNANgCAWQAJgFAIgCQAIgDAKAAQAJAAAIACQAGABAIAFQAJAGAEAKQAFAJgBANQAAAWgOAOQgPAOgVAAQgLAAgIgEgAZPB3QgHACgIAEIAAAEIAAAFQAAAQADAIQADAJAGAGQAFAEAFACQAFACAGAAQAPAAAHgJQAJgIgBgRQAAgJgCgGQgDgGgGgEQgEgDgGgBIgMgBQgHAAgIACgAMkDBQgJgDgHgGQgIgJgFgNQgEgNAAgTQAAgTADgPQAFgPAJgMQAJgLANgGQANgGATAAIAJAAIAIACIAAATIgBAAIgIgDQgFgCgHAAQgUAAgNAOQgNANgCAWQAJgFAIgCQAIgDAKAAQAJAAAIACQAGABAIAFQAJAGAEAKQAFAJgBANQAAAWgOAOQgPAOgVAAQgLAAgIgEgAMlB3QgHACgIAEIAAAEIAAAFQAAAQADAIQADAJAGAGQAFAEAFACQAFACAGAAQAPAAAHgJQAJgIgBgRQAAgJgCgGQgDgGgGgEQgEgDgGgBIgMgBQgHAAgIACgAAIDBQgIgDgFgGQgJgJgEgNQgFgNABgTQAAgTADgPQAEgPAKgMQAHgLANgGQANgGASAAIAKAAIAIACIAAATIgBAAIgIgDQgGgCgGAAQgUAAgNAOQgLANgBAWQAGgFAIgCQAIgDAKAAQAKAAAGACQAHABAIAFQAIAGAFAKQAEAJAAANQAAAWgOAOQgPAOgVAAQgLAAgJgEgAAKB3QgHACgFAEIgBAEIAAAFQAAAQADAIQABAJAGAGQAEAEAGACQAFACAGAAQAOAAAJgJQAHgIABgRQgBgJgCgGQgDgGgGgEQgFgDgFgBIgMgBQgIAAgHACgAoCDBQgKgDgGgGQgIgJgFgNQgFgNAAgTQAAgTAFgPQADgPAKgMQAIgLAOgGQAOgGARAAIAKAAIAIACIAAATIgBAAIgIgDQgGgCgFAAQgWAAgMAOQgMANgDAWQAJgFAIgCQAHgDALAAQAJAAAHACQAIABAHAFQAIAGAFAKQAFAJAAANQAAAWgPAOQgPAOgVAAQgLAAgIgEgAoBB3QgHACgIAEIAAAEIAAAFQAAAQAEAIQADAJAFAGQAFAEAFACQAFACAGAAQAPAAAIgJQAHgIAAgRQAAgJgCgGQgDgGgGgEQgFgDgFgBIgLgBQgJAAgHACgAyTDCQgMgDgHgDIAAgVIABAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAJgHAAgMQgBgFgCgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKADgKAGIgBAAIAAgVIATgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLACIAAABIAKAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgEAIQgDAIgGAGQgIAHgKAEQgKADgLAAQgMAAgMgDgA7NDCIAAgVIAVgRIASgSQATgSAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgLADQgKADgKAHIAAAAIAAgVQAHgDALgDQALgDAMAAQAVAAANALQANALAAASQAAAJgCAHQgCAHgEAGQgEAHgFAFIgMANIgXAUIgUASIBOAAIAAARgAT7ANIAAgNIB0AAIAAANgAEUANIAAgNIBzAAIAAANgAtzANIAAgNIB0AAIAAANgA27ADIAAgOIBiAAIAAAOgAkbgGIAAgQIBgAAIAAAQgAT7gaIAAgPIB0AAIAAAPgAEUgaIAAgPIBzAAIAAAPgAtzgaIAAgPIB0AAIAAAPgAaCgvQgMgDgHgDIAAgVIABAAQAIAGAMADQALAEALAAQAFAAAHgCQAIgCAEgEQAFgFABgFQADgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgHgBQgFgBgIAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgHAAgMQAAgFgDgEQgBgEgFgCIgJgEIgLgBQgJAAgKAEQgLADgJAGIgBAAIAAgVIATgGQALgDALAAQALAAAHACQAJACAGAFQAHAEAEAHQAEAGAAAJQAAAMgJAKQgJAJgLACIAAABIALAEQAFACAFAEQAFAEADAGQADAHAAAKQgBAKgDAIQgEAIgGAGQgIAHgKAEQgKADgLAAQgMAAgMgDgAKUgvQgLgCgHgEIAAgUIABAAQAHAFAMADQAKAEAKAAQAIAAAGgCQAHgCAFgFQAEgEACgGQACgGAAgIQAAgHgCgFQgDgFgEgEQgGgDgHgCQgHgBgJAAIgQABIgPACIAAhLIBYAAIAAARIhFAAIAAAnIAJAAIAHgBQANAAAIACQAJACAHAFQAIAGAFAIQAEAJAAANQAAAKgDAJQgFAJgGAHQgHAGgJAEQgKAEgNAAQgMAAgLgDgAnMgvQgLgCgIgEIAAgUIABAAQAIAFALADQAKAEALAAQAHAAAHgCQAGgCAFgFQAFgEACgGQABgGAAgIQAAgHgCgFQgDgFgEgEQgFgDgHgCQgHgBgJAAIgRABIgOACIAAhLIBXAAIAAARIhEAAIAAAnIAJAAIAHgBQAMAAAJACQAIACAIAFQAIAGAEAIQAFAJgBANQABAKgEAJQgEAJgGAHQgIAGgJAEQgKAEgNAAQgLAAgLgDgA64gvQgLgCgHgEIAAgUIABAAQAIAFAKADQALAEAKAAQAIAAAGgCQAHgCAEgFQAFgEACgGQACgGAAgIQAAgHgCgFQgDgFgFgEQgEgDgIgCQgHgBgJAAIgRABIgNACIAAhLIBXAAIAAARIhEAAIAAAnIAIAAIAHgBQAMAAAKACQAIACAIAFQAIAGAEAIQAEAJAAANQAAAKgDAJQgEAJgHAHQgHAGgKAEQgKAEgMAAQgMAAgLgDgAX6gvIAAgPIAfAAIAAhiIgfAAIAAgNIAOgBQAHgBAEgCQAEgCADgEQACgEAAgGIAQAAIAACDIAdAAIAAAPgAQJgvIAAgVIAVgRIAUgSQASgSAHgLQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgKADQgLADgJAHIgBAAIAAgVQAGgDAMgDQALgDALAAQAXAAAMALQANALAAASQAAAJgCAHQgCAHgFAGQgDAHgFAFIgNANIgVAUIgVASIBOAAIAAARgAILgvIAAgPIAfAAIAAhiIgfAAIAAgNIAOgBQAGgBAEgCQAEgCADgEQADgEAAgGIAPAAIAACDIAeAAIAAAPgAgUgvIAAgVIAUgRIARgSQATgSAHgLQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgKADQgJADgKAHIgBAAIAAgVQAIgDAJgDQAMgDALAAQAVAAAOALQAMALAAASQAAAJgCAHQgCAHgFAGQgDAHgFAFIgMANIgXAUIgSASIBMAAIAAARgApVgvIAAgPIAeAAIAAhiIgeAAIAAgNIANgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACDIAeAAIAAAPgAycgvIAAgPIAeAAIAAhiIgeAAIAAgNIANgBQAIgBADgCQAEgCADgEQACgEABgGIAPAAIAACDIAeAAIAAAPgANDhnIAAgQIBiAAIAAAQg");
	this.shape_1.setTransform(600.5,170.2);

	this.shape.mask = this.shape_1.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},143).wait(104));

	// Capa 4 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_30 = new cjs.Graphics().p("Egj1ACWIAAkrMBHsAAAIAAErg");
	var mask_2_graphics_31 = new cjs.Graphics().p("Egj1ACvIAAldMBHsAAAIAAFdg");
	var mask_2_graphics_32 = new cjs.Graphics().p("Egj1ADIIAAmPMBHsAAAIAAGPg");
	var mask_2_graphics_33 = new cjs.Graphics().p("Egj1ADhIAAnBMBHsAAAIAAHBg");
	var mask_2_graphics_34 = new cjs.Graphics().p("Egj1AD6IAAnzMBHsAAAIAAHzg");
	var mask_2_graphics_35 = new cjs.Graphics().p("Egj1AETIAAolMBHsAAAIAAIlg");
	var mask_2_graphics_36 = new cjs.Graphics().p("Egj1AEsIAApXMBHsAAAIAAJXg");
	var mask_2_graphics_37 = new cjs.Graphics().p("Egj1AFFIAAqJMBHsAAAIAAKJg");
	var mask_2_graphics_38 = new cjs.Graphics().p("Egj1AFeIAAq7MBHsAAAIAAK7g");
	var mask_2_graphics_39 = new cjs.Graphics().p("Egj1AF3IAArtMBHsAAAIAALtg");
	var mask_2_graphics_40 = new cjs.Graphics().p("Egj1AGQIAAsfMBHsAAAIAAMfg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Egj1AGpIAAtRMBHsAAAIAANRg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Egj1AHCIAAuDMBHsAAAIAAODg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Egj1AHbIAAu1MBHsAAAIAAO1g");
	var mask_2_graphics_44 = new cjs.Graphics().p("Egj1AH0IAAvnMBHsAAAIAAPng");
	var mask_2_graphics_45 = new cjs.Graphics().p("Egj1AINIAAwZMBHsAAAIAAQZg");
	var mask_2_graphics_46 = new cjs.Graphics().p("Egj1AImIAAxLMBHsAAAIAARLg");
	var mask_2_graphics_47 = new cjs.Graphics().p("Egj1AI/IAAx9MBHsAAAIAAR9g");
	var mask_2_graphics_48 = new cjs.Graphics().p("Egj1AJYIAAyvMBHsAAAIAASvg");
	var mask_2_graphics_49 = new cjs.Graphics().p("AmPJxIAAzhMBHsAAAIAAThg");
	var mask_2_graphics_123 = new cjs.Graphics().p("AmPJxIAAzhMBHsAAAIAAThg");
	var mask_2_graphics_124 = new cjs.Graphics().p("Egj1AKLIAA0VMBHsAAAIAAUVg");
	var mask_2_graphics_125 = new cjs.Graphics().p("Egj1AKlIAA1JMBHsAAAIAAVJg");
	var mask_2_graphics_126 = new cjs.Graphics().p("Egj1AK/IAA19MBHsAAAIAAV9g");
	var mask_2_graphics_127 = new cjs.Graphics().p("Egj1ALZIAA2xMBHsAAAIAAWxg");
	var mask_2_graphics_128 = new cjs.Graphics().p("Egj1ALzIAA3lMBHsAAAIAAXlg");
	var mask_2_graphics_129 = new cjs.Graphics().p("Egj1AMNIAA4ZMBHsAAAIAAYZg");
	var mask_2_graphics_130 = new cjs.Graphics().p("Egj1AMnIAA5NMBHsAAAIAAZNg");
	var mask_2_graphics_131 = new cjs.Graphics().p("Egj1ANBIAA6BMBHsAAAIAAaBg");
	var mask_2_graphics_132 = new cjs.Graphics().p("Egj1ANbIAA61MBHsAAAIAAa1g");
	var mask_2_graphics_133 = new cjs.Graphics().p("AmPN1IAA7pMBHsAAAIAAbpg");
	var mask_2_graphics_185 = new cjs.Graphics().p("AmPN1IAA7pMBHsAAAIAAbpg");
	var mask_2_graphics_186 = new cjs.Graphics().p("Egj1AOtIAA9ZMBHsAAAIAAdZg");
	var mask_2_graphics_187 = new cjs.Graphics().p("Egj1APlIAA/JMBHsAAAIAAfJg");
	var mask_2_graphics_188 = new cjs.Graphics().p("Egj1AQeMAAAgg7MBHsAAAMAAAAg7g");
	var mask_2_graphics_189 = new cjs.Graphics().p("Egj1ARWMAAAgirMBHsAAAMAAAAirg");
	var mask_2_graphics_190 = new cjs.Graphics().p("Egj1ASOMAAAgkbMBHsAAAMAAAAkbg");
	var mask_2_graphics_191 = new cjs.Graphics().p("Egj1ATGMAAAgmLMBHsAAAMAAAAmLg");
	var mask_2_graphics_192 = new cjs.Graphics().p("Egj1AT/MAAAgn9MBHsAAAMAAAAn9g");
	var mask_2_graphics_193 = new cjs.Graphics().p("Egj1AU3MAAAgptMBHsAAAMAAAAptg");
	var mask_2_graphics_194 = new cjs.Graphics().p("Egj1AVvMAAAgrdMBHsAAAMAAAArdg");
	var mask_2_graphics_195 = new cjs.Graphics().p("Egj1AWoMAAAgtPMBHsAAAMAAAAtPg");
	var mask_2_graphics_196 = new cjs.Graphics().p("Egj1AXgMAAAgu/MBHsAAAMAAAAu/g");
	var mask_2_graphics_197 = new cjs.Graphics().p("Egj1AYYMAAAgwvMBHsAAAMAAAAwvg");
	var mask_2_graphics_198 = new cjs.Graphics().p("Egj1AZQMAAAgyfMBHsAAAMAAAAyfg");
	var mask_2_graphics_199 = new cjs.Graphics().p("Egj1AaJMAAAg0RMBHsAAAMAAAA0Rg");
	var mask_2_graphics_200 = new cjs.Graphics().p("AmPbBMAAAg2BMBHsAAAMAAAA2Bg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(30).to({graphics:mask_2_graphics_30,x:608.5,y:-34.1}).wait(1).to({graphics:mask_2_graphics_31,x:608.5,y:-31.6}).wait(1).to({graphics:mask_2_graphics_32,x:608.5,y:-29.1}).wait(1).to({graphics:mask_2_graphics_33,x:608.5,y:-26.6}).wait(1).to({graphics:mask_2_graphics_34,x:608.5,y:-24.1}).wait(1).to({graphics:mask_2_graphics_35,x:608.5,y:-21.6}).wait(1).to({graphics:mask_2_graphics_36,x:608.5,y:-19.1}).wait(1).to({graphics:mask_2_graphics_37,x:608.5,y:-16.6}).wait(1).to({graphics:mask_2_graphics_38,x:608.5,y:-14.1}).wait(1).to({graphics:mask_2_graphics_39,x:608.5,y:-11.6}).wait(1).to({graphics:mask_2_graphics_40,x:608.5,y:-9.1}).wait(1).to({graphics:mask_2_graphics_41,x:608.5,y:-6.6}).wait(1).to({graphics:mask_2_graphics_42,x:608.5,y:-4.1}).wait(1).to({graphics:mask_2_graphics_43,x:608.5,y:-1.6}).wait(1).to({graphics:mask_2_graphics_44,x:608.5,y:0.8}).wait(1).to({graphics:mask_2_graphics_45,x:608.5,y:3.3}).wait(1).to({graphics:mask_2_graphics_46,x:608.5,y:5.8}).wait(1).to({graphics:mask_2_graphics_47,x:608.5,y:8.3}).wait(1).to({graphics:mask_2_graphics_48,x:608.5,y:10.8}).wait(1).to({graphics:mask_2_graphics_49,x:419,y:13.3}).wait(74).to({graphics:mask_2_graphics_123,x:419,y:13.3}).wait(1).to({graphics:mask_2_graphics_124,x:608.5,y:15.9}).wait(1).to({graphics:mask_2_graphics_125,x:608.5,y:18.5}).wait(1).to({graphics:mask_2_graphics_126,x:608.5,y:21.1}).wait(1).to({graphics:mask_2_graphics_127,x:608.5,y:23.7}).wait(1).to({graphics:mask_2_graphics_128,x:608.5,y:26.3}).wait(1).to({graphics:mask_2_graphics_129,x:608.5,y:28.8}).wait(1).to({graphics:mask_2_graphics_130,x:608.5,y:31.4}).wait(1).to({graphics:mask_2_graphics_131,x:608.5,y:34}).wait(1).to({graphics:mask_2_graphics_132,x:608.5,y:36.6}).wait(1).to({graphics:mask_2_graphics_133,x:419,y:39.2}).wait(52).to({graphics:mask_2_graphics_185,x:419,y:39.2}).wait(1).to({graphics:mask_2_graphics_186,x:608.5,y:44.9}).wait(1).to({graphics:mask_2_graphics_187,x:608.5,y:50.5}).wait(1).to({graphics:mask_2_graphics_188,x:608.5,y:56.1}).wait(1).to({graphics:mask_2_graphics_189,x:608.5,y:61.7}).wait(1).to({graphics:mask_2_graphics_190,x:608.5,y:67.4}).wait(1).to({graphics:mask_2_graphics_191,x:608.5,y:73}).wait(1).to({graphics:mask_2_graphics_192,x:608.5,y:78.6}).wait(1).to({graphics:mask_2_graphics_193,x:608.5,y:84.3}).wait(1).to({graphics:mask_2_graphics_194,x:608.5,y:89.9}).wait(1).to({graphics:mask_2_graphics_195,x:608.5,y:95.5}).wait(1).to({graphics:mask_2_graphics_196,x:608.5,y:101.1}).wait(1).to({graphics:mask_2_graphics_197,x:608.5,y:106.8}).wait(1).to({graphics:mask_2_graphics_198,x:608.5,y:112.4}).wait(1).to({graphics:mask_2_graphics_199,x:608.5,y:118}).wait(1).to({graphics:mask_2_graphics_200,x:419,y:123.6}).wait(47));

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AK9AAID3AAAuzAAID3AAAmNAAID3AAADOAAID3AA");
	this.shape_2.setTransform(603.6,48);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAyBVIgyB4Igxh4AAAjMIAAGZ");
	this.shape_3.setTransform(553,99.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AACjuIgDgHIgXgjQAOASAKARIACADQC4EHi4EEQCTkYiTjvgAsFjyIACgDQAMgRAOgSIgYAjIgEAHQiTDvCSEYQi4kEC5kHgAHPDbQgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgGAAgIQAAgHgDgFQgCgGgEgCQgEgDgHgCQgGgBgHAAIgJAAIAAgQIAGAAQAQAAAIgGQAKgGgBgMQAAgGgCgDQgCgFgEgCIgJgDIgLgBQgJAAgLADQgKADgJAGIgCAAIAAgUIATgHQALgCALAAQALAAAIACQAIACAHAEQAHAEAEAHQADAHAAAJQAAALgJAKQgIAJgMACIAAABIALAEQAGACAEAEQAFAEADAHQADAGAAAKQAAAKgEAIQgDAJgHAFQgHAHgKAEQgKADgLAAQgMAAgNgDgAiLDbQgMgDgHgDIAAgVIABAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgGAAgIQAAgHgCgFQgDgGgEgCQgFgDgGgCQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAJgGAAgMQgBgGgCgDQgCgFgEgCIgJgDIgLgBQgKAAgKADQgKADgKAGIgBAAIAAgUIATgHQAMgCALAAQAKAAAIACQAJACAGAEQAHAEAEAHQADAHAAAJQAAALgJAKQgIAJgLACIAAABIAKAEQAGACAEAEQAFAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAFQgIAHgKAEQgKADgLAAQgMAAgMgDgAO3DbIBGiAIhTAAIAAgSIBkAAIAAAWIhCB8gArFDbIAAgUIAVgSIATgSQASgRAHgLQAHgLAAgNQAAgLgHgGQgIgHgNABQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgEAMgDQALgCAMAAQAVAAANALQANAKAAASQAAAJgCAHQgCAIgEAFQgEAHgFAGIgMAMIgXAUIgUASIBOAAIAAARgAv8BKQgMgCgHgEIAAgUIABAAQAIAFALAEQALAEALAAQAGgBAHgCQAHgCAEgDQAFgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgBgHgBIgJAAIAAgOIAGAAQAPAAAKgFQAJgHAAgMQgBgFgCgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKACgKAHIgBAAIAAgVIATgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLABIAAACIAKADQAGABAEADQAFAFADAGQADAHAAAJQAAALgEAHQgDAJgHAGQgHAHgKADQgKADgLAAQgMAAgMgDgALfBJIAAgcIAYAAIAAAcgACyAcIAAgQIBhAAIAAAQgAm8AcIAAgQIBiAAIAAAQgALfgGIAAgcIAYAAIAAAcgAqwgWQgLgCgHgDIAAgVIAAAAQAJAFAKADQALAEAKAAQAIAAAGgCQAHgCAEgEQAFgFACgFQACgGAAgJQAAgHgCgFQgDgFgFgDQgEgEgIgCQgHgBgJAAIgRABIgNACIAAhLIBXAAIAAASIhEAAIAAAmIAIAAIAHgBQAMAAAKACQAIACAIAFQAIAGAEAJQAEAIAAANQAAAKgEAJQgDAJgHAHQgHAHgKADQgKAEgMAAQgMAAgLgDgAPogWIAAgpIhGAAIAAgXIBHhSIASAAIAABaIAVAAIAAAPIgVAAIAAApgAOwhOIA4AAIAAhCgAHHgWIAAgPIAfAAIAAhhIgfAAIAAgOIAOgBQAGgBAEgBQAFgDACgEQACgDABgHIAPAAIAACDIAeAAIAAAPgAiUgWIAAgPIAeAAIAAhhIgeAAIAAgOIANgBQAIgBADgBQAEgDADgEQACgDABgHIAPAAIAACDIAeAAIAAAPg");
	this.shape_4.setTransform(587.3,46.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#CC0000").ss(1,1,1).p("AmNAAID3AAACXAAID3AA");
	this.shape_5.setTransform(548.6,48);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AK9w5ID3AAACSQ6ID3AAAuzQ6ID3AAAmNQ6ID3AAADOw5ID3AA");
	this.shape_6.setTransform(603.6,156.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AGgT7QgKgEgGgGQgJgJgEgNQgEgNgBgTQAAgTAFgPQADgPAKgLQAIgLAOgHQAOgGASAAIAJAAIAIACIAAATIgBAAIgIgDQgGgBgFgBQgWAAgMAOQgMANgDAXQAJgGAIgCQAHgDALAAQAJAAAIACQAHABAHAFQAIAHAFAJQAFAJAAANQAAAWgPAOQgPAOgVAAQgLAAgIgDgAGhSwQgHACgIAEIAAAFIAAAEQAAAQAEAJQADAIAFAGQAEAEAGACQAFACAGAAQAOAAAIgJQAIgIAAgQQAAgKgCgFQgDgGgGgFQgFgDgFgBIgLgBQgJAAgHACgAiLT7QgMgCgHgEIAAgUIABAAQAIAFALAEQALADALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgHQAAgIgCgGQgDgEgEgEQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAJgHAAgMQgBgEgCgFQgCgEgEgCIgJgEIgLgBQgKABgKADQgKADgKAGIgBAAIAAgVIATgFQAMgEALAAQAKAAAIACQAJADAGAEQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLACIAAACIAKADQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgDAIQgEAIgGAHQgIAGgKAEQgKADgLAAQgMAAgMgDgArFT7IAAgVIAVgRIATgRQASgTAHgLQAHgKAAgMQAAgLgHgHQgIgGgNgBQgJAAgLADQgKAEgKAGIgBAAIAAgVQAHgDAMgCQALgEAMAAQAVABANAKQANALAAATQAAAIgCAHQgCAHgEAHQgEAGgFAFIgMAOIgXAUIgUASIBOAAIAAAQgABNRHIAAgQIB0AAIAAAQgAmzQ8IAAgPIBiAAIAAAPgABNQdIAAgPIB0AAIAAAPgAHUQIQgLgCgIgEIAAgUIACAAQAHAFAMAEQALADAKAAQAHAAAHgCQAGgCAFgEQAFgFACgFQACgFAAgHQgBgIgCgGQgDgEgDgEQgFgDgGAAQgHgCgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgHAAgMQAAgEgDgFQgCgEgDgCIgJgEIgMgBQgJABgLADQgKADgJAGIgBAAIAAgVIATgFQALgEALAAQALAAAIACQAIADAGAEQAIAEADAHQADAGABAJQAAAMgJAKQgIAJgMACIAAACIALADQAFACAFAEQAFAEADAGQACAHAAAKQAAAKgDAIQgDAIgHAHQgIAGgJAEQgKADgMAAQgMAAgMgDgAqwQJQgLgDgHgEIAAgUIAAAAQAJAFAKAEQALADAKAAQAIAAAGgCQAHgCAEgFQAFgEACgGQACgFAAgIQAAgIgCgFQgDgFgFgEQgEgDgIgBQgHgCgJAAIgRABIgNADIAAhLIBXAAIAAAQIhEAAIAAAoIAIgBIAHAAQAMAAAKACQAIABAIAGQAIAFAEAIQAEAJAAANQAAAKgEAJQgDAKgHAGQgHAGgKAFQgKADgMAAQgMAAgLgCgAFNQIIAAgPIAeAAIAAhiIgeAAIAAgMIANgBQAHgCADgCQAFgCADgDQACgFAAgGIAQAAIAACDIAdAAIAAAPgAiUQIIAAgPIAeAAIAAhiIgeAAIAAgMIANgBQAIgCADgCQAEgCADgDQACgFABgGIAPAAIAACDIAeAAIAAAPgAHPt4QgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgGAAgIQAAgHgDgFQgCgGgEgCQgEgDgHgCQgGgBgHAAIgJAAIAAgQIAGAAQAQAAAIgGQAKgGgBgMQAAgGgCgDQgCgFgEgCIgJgDIgLgBQgJAAgLADQgKADgJAGIgCAAIAAgUIATgHQALgCALAAQALAAAIACQAIACAHAEQAHAEAEAHQADAHAAAJQAAALgJAKQgIAJgMACIAAABIALAEQAGACAEAEQAFAEADAHQADAGAAAKQAAAKgEAIQgDAJgHAFQgHAHgKAEQgKADgLAAQgMAAgNgDgAO3t4IBGiAIhTAAIAAgSIBkAAIAAAWIhCB8gAv8wJQgMgCgHgEIAAgUIABAAQAIAFALAEQALAEALAAQAGgBAHgCQAHgCAEgDQAFgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgBgHgBIgJAAIAAgQIAGAAQAPAAAKgFQAJgHAAgMQgBgFgCgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKACgKAHIgBAAIAAgVIATgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLABIAAACIAKAEQAGACAEADQAFAFADAGQADAHAAAJQAAALgEAHQgDAJgHAGQgHAHgKADQgKADgLAAQgMAAgMgDgALfwKIAAgcIAYAAIAAAcgACow3IAAgQIBhAAIAAAQgALfxbIAAgcIAYAAIAAAcgAPoxrIAAgpIhGAAIAAgXIBHhRIASAAIAABZIAVAAIAAAPIgVAAIAAApgAOwyjIA4AAIAAhCgAHHxrIAAgPIAfAAIAAhhIgfAAIAAgOIAOgBQAGgBAEgBQAFgDACgEQACgDABgHIAPAAIAACDIAeAAIAAAPg");
	this.shape_7.setTransform(587.3,157.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0000").s().p("AGGEWQCQkWiSjuIgFgHIgXgjQAOASAMARIACADQC3EFi1EDIgCADIACgDgAmFEWQi1kDC3kFIACgDQAMgRAOgSIgXAjIgFAHQiSDuCQEWIACADIgCgDgAD1DbQgMgDgHgDIAAgVIABAAQAIAGAMADQALAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgCgFQgDgGgEgCQgEgDgHgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgGAAgMQAAgGgDgDQgCgFgEgCIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgHQAMgCALAAQAKAAAIACQAJACAGAEQAHAEAEAHQADAHAAAJQAAALgIAKQgJAJgLACIAAABIAKAEQAGACAFAEQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAFQgIAHgKAEQgKADgLAAQgMAAgMgDgAlDDbIAAgUIAVgSIATgSQASgRAHgLQAHgLAAgNQAAgLgHgGQgIgHgNABQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgDQAMgCALAAQAWAAANALQAMAKAAASQAAAJgCAHQgCAIgEAFQgEAHgFAGIgMAMIgWAUIgVASIBOAAIAAARgAgwAcIAAgQIBfAAIAAAQgAkugWQgLgCgHgDIAAgVIABAAQAIAFALADQAKAEALAAQAHAAAGgCQAHgCAFgEQAEgFACgFQACgGAAgJQAAgHgCgFQgDgFgEgDQgFgEgIgCQgHgBgJAAIgQABIgOACIAAhLIBXAAIAAASIhEAAIAAAmIAIAAIAIgBQAMAAAJACQAIACAIAFQAIAGAEAJQAEAIAAANQAAAKgDAJQgEAJgHAHQgHAHgJADQgKAEgNAAQgMAAgLgDgADsgWIAAgPIAfAAIAAhhIgfAAIAAgOIAOgBQAHgBADgBQAFgDACgEQADgDAAgHIAPAAIAACDIAeAAIAAAPg");
	this.shape_8.setTransform(548.7,46.2);

	this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},30).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_3},{t:this.shape_6},{t:this.shape_5}]},35).wait(182));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,14.7,340,271.3);


(lib.textoAnimado_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});


	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_62 = new cjs.Graphics().p("AJVBfIAAk7MA4TAAAIAAE7g");
	var mask_1_graphics_63 = new cjs.Graphics().p("A8IDaIAAmzMA4RAAAIAAGzg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A8IEWIAAorMA4RAAAIAAIrg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A8IFSIAAqjMA4RAAAIAAKjg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A8IGOIAAsbMA4RAAAIAAMbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A8IHJIAAuRMA4RAAAIAAORg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A8IIFIAAwJMA4RAAAIAAQJg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A8IJBIAAyBMA4RAAAIAASBg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A8IJ9IAAz5MA4RAAAIAAT5g");
	var mask_1_graphics_71 = new cjs.Graphics().p("A8IK5IAA1xMA4RAAAIAAVxg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A8IL1IAA3pMA4RAAAIAAXpg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A8IMxIAA5hMA4RAAAIAAZhg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A8INtIAA7ZMA4RAAAIAAbZg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A8IOpIAA9RMA4RAAAIAAdRg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A8IPlIAA/JMA4RAAAIAAfJg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A8IQgMAAAgg/MA4RAAAMAAAAg/g");
	var mask_1_graphics_78 = new cjs.Graphics().p("A8IRcMAAAgi3MA4RAAAMAAAAi3g");
	var mask_1_graphics_79 = new cjs.Graphics().p("AJVSYMAAAgkvMA4TAAAMAAAAkvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(62).to({graphics:mask_1_graphics_62,x:420,y:-22.1}).wait(1).to({graphics:mask_1_graphics_63,x:659.9,y:-22.4}).wait(1).to({graphics:mask_1_graphics_64,x:659.9,y:-16.4}).wait(1).to({graphics:mask_1_graphics_65,x:659.9,y:-10.4}).wait(1).to({graphics:mask_1_graphics_66,x:659.9,y:-4.4}).wait(1).to({graphics:mask_1_graphics_67,x:659.9,y:1.5}).wait(1).to({graphics:mask_1_graphics_68,x:659.9,y:7.5}).wait(1).to({graphics:mask_1_graphics_69,x:659.9,y:13.5}).wait(1).to({graphics:mask_1_graphics_70,x:659.9,y:19.5}).wait(1).to({graphics:mask_1_graphics_71,x:659.9,y:25.5}).wait(1).to({graphics:mask_1_graphics_72,x:659.9,y:31.4}).wait(1).to({graphics:mask_1_graphics_73,x:659.9,y:37.4}).wait(1).to({graphics:mask_1_graphics_74,x:659.9,y:43.4}).wait(1).to({graphics:mask_1_graphics_75,x:659.9,y:49.4}).wait(1).to({graphics:mask_1_graphics_76,x:659.9,y:55.4}).wait(1).to({graphics:mask_1_graphics_77,x:659.9,y:61.4}).wait(1).to({graphics:mask_1_graphics_78,x:659.9,y:67.4}).wait(1).to({graphics:mask_1_graphics_79,x:420,y:73.4}).wait(185));

	// Capa 1
	this.instance = new lib.shutterstock_50808379_OPT();
	this.instance.setTransform(515.6,0,0.546,0.546);

	this.instance.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},62).wait(202));

	// Capa 7 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_118 = new cjs.Graphics().p("APkeWIAAi4MAw8AAAIAAC4g");
	var mask_2_graphics_119 = new cjs.Graphics().p("A4cBvIAAjdMAw5AAAIAADdg");
	var mask_2_graphics_120 = new cjs.Graphics().p("A4cCDIAAkFMAw5AAAIAAEFg");
	var mask_2_graphics_121 = new cjs.Graphics().p("A4cCXIAAktMAw5AAAIAAEtg");
	var mask_2_graphics_122 = new cjs.Graphics().p("A4cCrIAAlVMAw5AAAIAAFVg");
	var mask_2_graphics_123 = new cjs.Graphics().p("A4cC/IAAl9MAw5AAAIAAF9g");
	var mask_2_graphics_124 = new cjs.Graphics().p("A4cDTIAAmlMAw5AAAIAAGlg");
	var mask_2_graphics_125 = new cjs.Graphics().p("A4cDmIAAnLMAw5AAAIAAHLg");
	var mask_2_graphics_126 = new cjs.Graphics().p("A4cD6IAAnzMAw5AAAIAAHzg");
	var mask_2_graphics_127 = new cjs.Graphics().p("A4cEOIAAobMAw5AAAIAAIbg");
	var mask_2_graphics_128 = new cjs.Graphics().p("A4cEiIAApDMAw5AAAIAAJDg");
	var mask_2_graphics_129 = new cjs.Graphics().p("A4cE2IAAprMAw5AAAIAAJrg");
	var mask_2_graphics_130 = new cjs.Graphics().p("A4cFKIAAqTMAw5AAAIAAKTg");
	var mask_2_graphics_131 = new cjs.Graphics().p("APkeWIAAq8MAw8AAAIAAK8g");
	var mask_2_graphics_178 = new cjs.Graphics().p("APkeWIAAq8MAw8AAAIAAK8g");
	var mask_2_graphics_179 = new cjs.Graphics().p("A4cFtIAArZMAw5AAAIAALZg");
	var mask_2_graphics_180 = new cjs.Graphics().p("A4cF9IAAr5MAw5AAAIAAL5g");
	var mask_2_graphics_181 = new cjs.Graphics().p("A4cGNIAAsZMAw5AAAIAAMZg");
	var mask_2_graphics_182 = new cjs.Graphics().p("A4cGcIAAs3MAw5AAAIAAM3g");
	var mask_2_graphics_183 = new cjs.Graphics().p("A4cGsIAAtXMAw5AAAIAANXg");
	var mask_2_graphics_184 = new cjs.Graphics().p("A4cG8IAAt3MAw5AAAIAAN3g");
	var mask_2_graphics_185 = new cjs.Graphics().p("A4cHLIAAuVMAw5AAAIAAOVg");
	var mask_2_graphics_186 = new cjs.Graphics().p("A4cHbIAAu1MAw5AAAIAAO1g");
	var mask_2_graphics_187 = new cjs.Graphics().p("A4cHrIAAvVMAw5AAAIAAPVg");
	var mask_2_graphics_188 = new cjs.Graphics().p("A4cH6IAAvzMAw5AAAIAAPzg");
	var mask_2_graphics_189 = new cjs.Graphics().p("A4cIKIAAwTMAw5AAAIAAQTg");
	var mask_2_graphics_190 = new cjs.Graphics().p("A4cIaIAAwzMAw5AAAIAAQzg");
	var mask_2_graphics_191 = new cjs.Graphics().p("A4cIqIAAxTMAw5AAAIAARTg");
	var mask_2_graphics_192 = new cjs.Graphics().p("APkeWIAAx0MAw8AAAIAAR0g");
	var mask_2_graphics_242 = new cjs.Graphics().p("APkeWIAAx0MAw8AAAIAAR0g");
	var mask_2_graphics_243 = new cjs.Graphics().p("A4cJPIAAydMAw5AAAIAASdg");
	var mask_2_graphics_244 = new cjs.Graphics().p("A4cJkIAAzHMAw5AAAIAATHg");
	var mask_2_graphics_245 = new cjs.Graphics().p("A4cJ6IAAzzMAw5AAAIAATzg");
	var mask_2_graphics_246 = new cjs.Graphics().p("A4cKPIAA0dMAw5AAAIAAUdg");
	var mask_2_graphics_247 = new cjs.Graphics().p("A4cKlIAA1JMAw5AAAIAAVJg");
	var mask_2_graphics_248 = new cjs.Graphics().p("A4cK6IAA1zMAw5AAAIAAVzg");
	var mask_2_graphics_249 = new cjs.Graphics().p("A4cLQIAA2fMAw5AAAIAAWfg");
	var mask_2_graphics_250 = new cjs.Graphics().p("A4cLlIAA3JMAw5AAAIAAXJg");
	var mask_2_graphics_251 = new cjs.Graphics().p("A4cL6IAA3zMAw5AAAIAAXzg");
	var mask_2_graphics_252 = new cjs.Graphics().p("A4cMQIAA4fMAw5AAAIAAYfg");
	var mask_2_graphics_253 = new cjs.Graphics().p("A4cMlIAA5JMAw5AAAIAAZJg");
	var mask_2_graphics_254 = new cjs.Graphics().p("A4cM7IAA51MAw5AAAIAAZ1g");
	var mask_2_graphics_255 = new cjs.Graphics().p("A4cNQIAA6fMAw5AAAIAAafg");
	var mask_2_graphics_256 = new cjs.Graphics().p("A4cNmIAA7LMAw5AAAIAAbLg");
	var mask_2_graphics_257 = new cjs.Graphics().p("A4cN7IAA71MAw5AAAIAAb1g");
	var mask_2_graphics_258 = new cjs.Graphics().p("APkeWIAA8jMAw8AAAIAAcjg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(118).to({graphics:mask_2_graphics_118,x:412.9,y:194.3}).wait(1).to({graphics:mask_2_graphics_119,x:669.1,y:377.4}).wait(1).to({graphics:mask_2_graphics_120,x:669.1,y:375.4}).wait(1).to({graphics:mask_2_graphics_121,x:669.1,y:373.4}).wait(1).to({graphics:mask_2_graphics_122,x:669.1,y:371.4}).wait(1).to({graphics:mask_2_graphics_123,x:669.1,y:369.4}).wait(1).to({graphics:mask_2_graphics_124,x:669.1,y:367.4}).wait(1).to({graphics:mask_2_graphics_125,x:669.1,y:365.5}).wait(1).to({graphics:mask_2_graphics_126,x:669.1,y:363.5}).wait(1).to({graphics:mask_2_graphics_127,x:669.1,y:361.5}).wait(1).to({graphics:mask_2_graphics_128,x:669.1,y:359.5}).wait(1).to({graphics:mask_2_graphics_129,x:669.1,y:357.5}).wait(1).to({graphics:mask_2_graphics_130,x:669.1,y:355.5}).wait(1).to({graphics:mask_2_graphics_131,x:412.9,y:194.3}).wait(47).to({graphics:mask_2_graphics_178,x:412.9,y:194.3}).wait(1).to({graphics:mask_2_graphics_179,x:669.1,y:352}).wait(1).to({graphics:mask_2_graphics_180,x:669.1,y:350.4}).wait(1).to({graphics:mask_2_graphics_181,x:669.1,y:348.8}).wait(1).to({graphics:mask_2_graphics_182,x:669.1,y:347.3}).wait(1).to({graphics:mask_2_graphics_183,x:669.1,y:345.7}).wait(1).to({graphics:mask_2_graphics_184,x:669.1,y:344.1}).wait(1).to({graphics:mask_2_graphics_185,x:669.1,y:342.5}).wait(1).to({graphics:mask_2_graphics_186,x:669.1,y:341}).wait(1).to({graphics:mask_2_graphics_187,x:669.1,y:339.4}).wait(1).to({graphics:mask_2_graphics_188,x:669.1,y:337.8}).wait(1).to({graphics:mask_2_graphics_189,x:669.1,y:336.2}).wait(1).to({graphics:mask_2_graphics_190,x:669.1,y:334.7}).wait(1).to({graphics:mask_2_graphics_191,x:669.1,y:333.1}).wait(1).to({graphics:mask_2_graphics_192,x:412.9,y:194.2}).wait(50).to({graphics:mask_2_graphics_242,x:412.9,y:194.2}).wait(1).to({graphics:mask_2_graphics_243,x:669.1,y:329.4}).wait(1).to({graphics:mask_2_graphics_244,x:669.1,y:327.2}).wait(1).to({graphics:mask_2_graphics_245,x:669.1,y:325.1}).wait(1).to({graphics:mask_2_graphics_246,x:669.1,y:322.9}).wait(1).to({graphics:mask_2_graphics_247,x:669.1,y:320.8}).wait(1).to({graphics:mask_2_graphics_248,x:669.1,y:318.6}).wait(1).to({graphics:mask_2_graphics_249,x:669.1,y:316.5}).wait(1).to({graphics:mask_2_graphics_250,x:669.1,y:314.4}).wait(1).to({graphics:mask_2_graphics_251,x:669.1,y:312.2}).wait(1).to({graphics:mask_2_graphics_252,x:669.1,y:310.1}).wait(1).to({graphics:mask_2_graphics_253,x:669.1,y:307.9}).wait(1).to({graphics:mask_2_graphics_254,x:669.1,y:305.8}).wait(1).to({graphics:mask_2_graphics_255,x:669.1,y:303.6}).wait(1).to({graphics:mask_2_graphics_256,x:669.1,y:301.5}).wait(1).to({graphics:mask_2_graphics_257,x:669.1,y:299.3}).wait(1).to({graphics:mask_2_graphics_258,x:412.9,y:194.3}).wait(6));

	// Capa 6
	this.text = new cjs.Text("+  –", "20px Verdana", "#CC0000");
	this.text.lineHeight = 20;
	this.text.setTransform(636.2,240.7);

	this.text_1 = new cjs.Text("x  :", "20px Verdana", "#CC0000");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(638.2,280.7);

	this.text_2 = new cjs.Text("{ } [ ] ( )", "20px Verdana", "#CC0000");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 100;
	this.text_2.setTransform(608,326.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AHgiiIn6okQjXDwjXDxQgeAigeAhgAuLESQmAGwAAAFMAoXAAAImVm1gAN3ESImXm0AoEiiQhHBQhIBQQiLCahtB6");
	this.shape.setTransform(662.2,291.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B6B6FF").s().p("AuBDaID5kUICOifIPlAAIGXGzg");
	this.shape_1.setTransform(661.2,296.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCFF").s().p("A0LDaQAAgFGAmuIcCAAIGVGzg");
	this.shape_2.setTransform(662.2,340.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A1A1FF").s().p("AnyESIA8hEIGuneIH7Iig");
	this.shape_3.setTransform(660.4,247.4);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_2},{t:this.text_1},{t:this.text}]},118).wait(146));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,39,428.7,295.6);


(lib.textoAnimado_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhHYABCIAAiDMCOxAAAIAACDg");
	var mask_graphics_1 = new cjs.Graphics().p("EhHYABeIAAi7MCOxAAAIAAC7g");
	var mask_graphics_2 = new cjs.Graphics().p("EhHYAB6IAAjzMCOxAAAIAADzg");
	var mask_graphics_3 = new cjs.Graphics().p("EhHYACWIAAkrMCOxAAAIAAErg");
	var mask_graphics_4 = new cjs.Graphics().p("EhHYACzIAAllMCOxAAAIAAFlg");
	var mask_graphics_5 = new cjs.Graphics().p("EhHYADPIAAmdMCOxAAAIAAGdg");
	var mask_graphics_6 = new cjs.Graphics().p("EhHYADrIAAnVMCOxAAAIAAHVg");
	var mask_graphics_7 = new cjs.Graphics().p("EhHYAEHIAAoNMCOxAAAIAAINg");
	var mask_graphics_8 = new cjs.Graphics().p("EhHYAEjIAApFMCOxAAAIAAJFg");
	var mask_graphics_9 = new cjs.Graphics().p("EhHYAE/IAAp9MCOxAAAIAAJ9g");
	var mask_graphics_10 = new cjs.Graphics().p("EhHYAFbIAAq1MCOxAAAIAAK1g");
	var mask_graphics_11 = new cjs.Graphics().p("EhHYAF4IAArvMCOxAAAIAALvg");
	var mask_graphics_12 = new cjs.Graphics().p("EhHYAGUIAAsnMCOxAAAIAAMng");
	var mask_graphics_13 = new cjs.Graphics().p("EhHYAGwIAAtfMCOxAAAIAANfg");
	var mask_graphics_14 = new cjs.Graphics().p("EhHYAHMIAAuXMCOxAAAIAAOXg");
	var mask_graphics_15 = new cjs.Graphics().p("EhHYAHoIAAvPMCOxAAAIAAPPg");
	var mask_graphics_16 = new cjs.Graphics().p("EhHYAIEIAAwHMCOxAAAIAAQHg");
	var mask_graphics_17 = new cjs.Graphics().p("EhHYAIgIAAw/MCOxAAAIAAQ/g");
	var mask_graphics_18 = new cjs.Graphics().p("EhHYAI9IAAx5MCOxAAAIAAR5g");
	var mask_graphics_32 = new cjs.Graphics().p("EhHYAI9IAAx5MCOxAAAIAAR5g");
	var mask_graphics_33 = new cjs.Graphics().p("EhHYAJUIAAynMCOxAAAIAASng");
	var mask_graphics_34 = new cjs.Graphics().p("EhHYAJrIAAzVMCOxAAAIAATVg");
	var mask_graphics_35 = new cjs.Graphics().p("EhHYAKDIAA0FMCOxAAAIAAUFg");
	var mask_graphics_36 = new cjs.Graphics().p("EhHYAKaIAA0zMCOxAAAIAAUzg");
	var mask_graphics_37 = new cjs.Graphics().p("EhHYAKxIAA1hMCOxAAAIAAVhg");
	var mask_graphics_38 = new cjs.Graphics().p("EhHYALJIAA2RMCOxAAAIAAWRg");
	var mask_graphics_39 = new cjs.Graphics().p("EhHYALgIAA2/MCOxAAAIAAW/g");
	var mask_graphics_40 = new cjs.Graphics().p("EhHYAL4IAA3uMCOxAAAIAAXug");
	var mask_graphics_41 = new cjs.Graphics().p("EhHYAMPIAA4dMCOxAAAIAAYdg");
	var mask_graphics_42 = new cjs.Graphics().p("EhHYAMmIAA5LMCOxAAAIAAZLg");
	var mask_graphics_43 = new cjs.Graphics().p("EhHYAM+IAA57MCOxAAAIAAZ7g");
	var mask_graphics_44 = new cjs.Graphics().p("EhHYANVIAA6pMCOxAAAIAAapg");
	var mask_graphics_45 = new cjs.Graphics().p("EhHYANsIAA7XMCOxAAAIAAbXg");
	var mask_graphics_46 = new cjs.Graphics().p("EhHYAOEIAA8HMCOxAAAIAAcHg");
	var mask_graphics_62 = new cjs.Graphics().p("EhHYAOEIAA8HMCOxAAAIAAcHg");
	var mask_graphics_63 = new cjs.Graphics().p("EhHYAOgIAA8/MCOxAAAIAAc/g");
	var mask_graphics_64 = new cjs.Graphics().p("EhHYAO8IAA93MCOxAAAIAAd3g");
	var mask_graphics_65 = new cjs.Graphics().p("EhHYAPYIAA+vMCOxAAAIAAevg");
	var mask_graphics_66 = new cjs.Graphics().p("EhHYAP1IAA/pMCOxAAAIAAfpg");
	var mask_graphics_67 = new cjs.Graphics().p("EhHYAQRMAAAgghMCOxAAAMAAAAghg");
	var mask_graphics_68 = new cjs.Graphics().p("EhHYAQtMAAAghZMCOxAAAMAAAAhZg");
	var mask_graphics_69 = new cjs.Graphics().p("EhHYARJMAAAgiRMCOxAAAMAAAAiRg");
	var mask_graphics_70 = new cjs.Graphics().p("EhHYARlMAAAgjJMCOxAAAMAAAAjJg");
	var mask_graphics_71 = new cjs.Graphics().p("EhHYASCMAAAgkDMCOxAAAMAAAAkDg");
	var mask_graphics_72 = new cjs.Graphics().p("EhHYASeMAAAgk7MCOxAAAMAAAAk7g");
	var mask_graphics_73 = new cjs.Graphics().p("EhHYAS6MAAAglzMCOxAAAMAAAAlzg");
	var mask_graphics_74 = new cjs.Graphics().p("EhHYATWMAAAgmrMCOxAAAMAAAAmrg");
	var mask_graphics_75 = new cjs.Graphics().p("EhHYATzMAAAgnlMCOxAAAMAAAAnlg");
	var mask_graphics_76 = new cjs.Graphics().p("EhHYAUPMAAAgodMCOxAAAMAAAAodg");
	var mask_graphics_77 = new cjs.Graphics().p("EhHYAUrMAAAgpVMCOxAAAMAAAApVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:424,y:-19.2}).wait(1).to({graphics:mask_graphics_1,x:424,y:-16.4}).wait(1).to({graphics:mask_graphics_2,x:424,y:-13.6}).wait(1).to({graphics:mask_graphics_3,x:424,y:-10.8}).wait(1).to({graphics:mask_graphics_4,x:424,y:-7.9}).wait(1).to({graphics:mask_graphics_5,x:424,y:-5.1}).wait(1).to({graphics:mask_graphics_6,x:424,y:-2.3}).wait(1).to({graphics:mask_graphics_7,x:424,y:0.4}).wait(1).to({graphics:mask_graphics_8,x:424,y:3.2}).wait(1).to({graphics:mask_graphics_9,x:424,y:6}).wait(1).to({graphics:mask_graphics_10,x:424,y:8.8}).wait(1).to({graphics:mask_graphics_11,x:424,y:11.7}).wait(1).to({graphics:mask_graphics_12,x:424,y:14.5}).wait(1).to({graphics:mask_graphics_13,x:424,y:17.3}).wait(1).to({graphics:mask_graphics_14,x:424,y:20.1}).wait(1).to({graphics:mask_graphics_15,x:424,y:22.9}).wait(1).to({graphics:mask_graphics_16,x:424,y:25.7}).wait(1).to({graphics:mask_graphics_17,x:424,y:28.5}).wait(1).to({graphics:mask_graphics_18,x:424,y:31.4}).wait(14).to({graphics:mask_graphics_32,x:424,y:31.4}).wait(1).to({graphics:mask_graphics_33,x:424,y:33.7}).wait(1).to({graphics:mask_graphics_34,x:424,y:36.1}).wait(1).to({graphics:mask_graphics_35,x:424,y:38.4}).wait(1).to({graphics:mask_graphics_36,x:424,y:40.8}).wait(1).to({graphics:mask_graphics_37,x:424,y:43.1}).wait(1).to({graphics:mask_graphics_38,x:424,y:45.5}).wait(1).to({graphics:mask_graphics_39,x:424,y:47.8}).wait(1).to({graphics:mask_graphics_40,x:424,y:50.2}).wait(1).to({graphics:mask_graphics_41,x:424,y:52.5}).wait(1).to({graphics:mask_graphics_42,x:424,y:54.9}).wait(1).to({graphics:mask_graphics_43,x:424,y:57.2}).wait(1).to({graphics:mask_graphics_44,x:424,y:59.6}).wait(1).to({graphics:mask_graphics_45,x:424,y:61.9}).wait(1).to({graphics:mask_graphics_46,x:424,y:64.3}).wait(16).to({graphics:mask_graphics_62,x:424,y:64.3}).wait(1).to({graphics:mask_graphics_63,x:424,y:67.1}).wait(1).to({graphics:mask_graphics_64,x:424,y:69.9}).wait(1).to({graphics:mask_graphics_65,x:424,y:72.8}).wait(1).to({graphics:mask_graphics_66,x:424,y:75.6}).wait(1).to({graphics:mask_graphics_67,x:424,y:78.4}).wait(1).to({graphics:mask_graphics_68,x:424,y:81.2}).wait(1).to({graphics:mask_graphics_69,x:424,y:84.1}).wait(1).to({graphics:mask_graphics_70,x:424,y:86.9}).wait(1).to({graphics:mask_graphics_71,x:424,y:89.7}).wait(1).to({graphics:mask_graphics_72,x:424,y:92.5}).wait(1).to({graphics:mask_graphics_73,x:424,y:95.4}).wait(1).to({graphics:mask_graphics_74,x:424,y:98.2}).wait(1).to({graphics:mask_graphics_75,x:424,y:101}).wait(1).to({graphics:mask_graphics_76,x:424,y:103.8}).wait(1).to({graphics:mask_graphics_77,x:424,y:106.7}).wait(54));

	// Capa 1
	this.txt_14 = new cjs.Text("", "20px Verdana");
	this.txt_14.lineHeight = 20;
	this.txt_14.lineWidth = 786;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Ar6FjIEZgBAr6lXIEZgBAiXliIDzAAAiXFYIDzAAAIFFYID2AA");
	this.shape.setTransform(104.8,161);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AKGIhIAAgUIAWgSIATgRQASgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAGgEAMgCQALgDALAAQAXAAAMALQANAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgNANIgVAUIgVASIBOAAIAAAQgAITIhIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgAgVIhIAAgUIAUgSIARgRQATgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgKADQgJADgKAGIgBAAIAAgUQAIgEAKgCQALgDALAAQAVAAAOALQAMAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgMANIgXAUIgSASIBMAAIAAAQgAiJIhIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQACgEABgHIAPAAIAACDIAeAAIAAAPgApoIhIAAgUIAUgSIATgRQATgSAHgLQAHgLAAgMQAAgLgHgHQgIgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAIgEALgCQAMgDALAAQAVAAAOALQAMAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgMANIgXAUIgUASIBOAAIAAAQgArcIhIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAIgBADgCQAFgDACgDQACgEABgHIAPAAIAACDIAeAAIAAAPgADvFsIAAgQIB0AAIAAAQgAlwFXIAAgPIBhAAIAAAPgADvFDIAAgQIB0AAIAAAQgApeElQgOgMAAgTQAAgMAHgKQAHgKANgFIAAgBQgMgGgGgIQgFgHAAgLQAAgRANgLQAOgKAUAAQAXAAANAKQAMAKAAARQABAJgHAKQgGAJgMAGIAAAAQAOAGAHAJQAHAIAAAOQAAATgPAMQgOANgXAAQgXAAgOgNgApTDyQgGAIAAALQABANAIAIQAKAJAOAAQAOAAAJgHQAIgIAAgMQAAgJgEgGQgEgFgMgGIgKgEIgOgFQgJAFgFAIgApMCuQgJAGABAKQAAAHADAFQAFAFAIAEIAKAEIANAFQAJgGAFgHQADgHAAgJQAAgLgIgGQgIgGgNAAQgMAAgHAGgAKSEuIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgAIUEuIBGiAIhTAAIAAgRIBjAAIAAAWIhBB7gAhJEuIBHiAIhTAAIAAgRIBhAAIAAAWIhAB7gArbEuIBGiAIhTAAIAAgRIBkAAIAAAWIhDB7gAqJiZQgGgCgFgEIgFgEQgIgIgEgNQgFgOAAgTQAAgTAEgPQAEgPAJgLQAJgLAOgHQANgGASAAIAJABIAIABIAAATIgBAAIgIgDQgFgBgGAAQgVAAgNANQgMANgCAXQAJgFAHgDQAIgDAKAAQAKAAAHACQAHACAIAFQAIAGAEAJQAFAJAAANQAAAWgPAOIgFAFQgNAJgSAAQgLAAgIgDgAqIjkQgGACgIAEIAAAFIAAAFQAAAPADAJQADAJAGAFQAEAEAFACQAFACAGAAQAPAAAIgIQAIgJAAgQQAAgJgDgGQgCgGgHgFQgEgDgGgBIgLgBQgIAAgIACgAgViZIAAgUIAUgSIARgRQATgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgKADQgJADgKAGIgBAAIAAgUQAIgEAKgCQALgDALAAQAVAAAOALQAMAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgMANIgXAUIgSASIBMAAIAAAQgAiJiZIAAgPIAeAAIAAhhIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQACgEABgHIAPAAIAACDIAeAAIAAAPgAlwljIAAgPIBhAAIAAAPgApXmJIgIgCIAAgTIABAAIAIADIALABQAXAAAMgNQAMgNACgWQgKAFgIACQgHADgKAAQgJAAgHgCQgHgCgIgFQgJgGgDgJQgFgJAAgNQAAgWAPgOQAOgOAWAAQAKAAAJADQAJADAHAHQAIAIAEANQAFANAAAUQAAATgFAPQgEAQgIALQgJALgOAGQgNAGgSAAIgKAAgApRoHQgIAIAAAQQAAAKADAFQACAGAHAFQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgQgDgJQgDgJgGgFQgEgEgGgCQgEgCgHAAQgOAAgIAJgArTmMQgMgCgHgEIAAgUIABAAQAIAFALAEQAMADAKAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgCgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAIgGABgMQgBgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKADgKAGIgBAAIAAgUIATgGQAMgDALAAQAKAAAIACQAIACAHAEQAHAFAEAGQADAHAAAJQAAAMgJAJQgIAJgLACIAAACIAKADQAGADAEADQAFAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAGQgIAHgKADQgKADgMAAQgLAAgMgDgAhJmMIBHiAIhTAAIAAgRIBhAAIAAAWIhAB7g");
	this.shape_1.setTransform(105.6,162.1);

	this.txt_14.mask = this.shape.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.txt_14}]}).wait(131));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,789.9,216.7);


(lib.textoAnimado_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	

	// Capa 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_70 = new cjs.Graphics().p("A8HBhIAAjBMA4QAAAIAADBg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A8HBrIAAjVMA4QAAAIAADVg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A8HB2IAAjrMA4QAAAIAADrg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A8HCAIAAj/MA4QAAAIAAD/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("A8HCKIAAkTMA4QAAAIAAETg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A8HCVIAAkpMA4QAAAIAAEpg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A8HCfIAAk9MA4QAAAIAAE9g");
	var mask_1_graphics_77 = new cjs.Graphics().p("A8HCqIAAlTMA4QAAAIAAFTg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A8HC0IAAlnMA4QAAAIAAFng");
	var mask_1_graphics_79 = new cjs.Graphics().p("A8HC+IAAl7MA4QAAAIAAF7g");
	var mask_1_graphics_80 = new cjs.Graphics().p("A8HDJIAAmRMA4QAAAIAAGRg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A8HDTIAAmlMA4QAAAIAAGlg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A8HDeIAAm7MA4QAAAIAAG7g");
	var mask_1_graphics_83 = new cjs.Graphics().p("A8HDoIAAnPMA4QAAAIAAHPg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A8HDyIAAnjMA4QAAAIAAHjg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A8HD9IAAn5MA4QAAAIAAH5g");
	var mask_1_graphics_86 = new cjs.Graphics().p("A8HEHIAAoNMA4QAAAIAAINg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A8HESIAAojMA4QAAAIAAIjg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A8HEcIAAo3MA4QAAAIAAI3g");
	var mask_1_graphics_89 = new cjs.Graphics().p("A8HEmIAApMMA4QAAAIAAJMg");
	var mask_1_graphics_119 = new cjs.Graphics().p("AKiEnIAApMMA4SAAAIAAJMg");
	var mask_1_graphics_120 = new cjs.Graphics().p("A8HFFIAAqJMA4QAAAIAAKJg");
	var mask_1_graphics_121 = new cjs.Graphics().p("A8HFkIAArHMA4QAAAIAALHg");
	var mask_1_graphics_122 = new cjs.Graphics().p("A8HGCIAAsDMA4QAAAIAAMDg");
	var mask_1_graphics_123 = new cjs.Graphics().p("A8HGhIAAtBMA4QAAAIAANBg");
	var mask_1_graphics_124 = new cjs.Graphics().p("A8HG/IAAt9MA4QAAAIAAN9g");
	var mask_1_graphics_125 = new cjs.Graphics().p("A8HHeIAAu7MA4QAAAIAAO7g");
	var mask_1_graphics_126 = new cjs.Graphics().p("A8HH8IAAv3MA4QAAAIAAP3g");
	var mask_1_graphics_127 = new cjs.Graphics().p("A8HIbIAAw1MA4QAAAIAAQ1g");
	var mask_1_graphics_128 = new cjs.Graphics().p("A8HI5IAAxxMA4QAAAIAARxg");
	var mask_1_graphics_129 = new cjs.Graphics().p("A8HJYIAAyvMA4QAAAIAASvg");
	var mask_1_graphics_130 = new cjs.Graphics().p("A8HJ2IAAzrMA4QAAAIAATrg");
	var mask_1_graphics_188 = new cjs.Graphics().p("A8HKyIAA1jMA4QAAAIAAVjg");
	var mask_1_graphics_189 = new cjs.Graphics().p("A8HLMIAA2XMA4QAAAIAAWXg");
	var mask_1_graphics_190 = new cjs.Graphics().p("A8HLmIAA3LMA4QAAAIAAXLg");
	var mask_1_graphics_191 = new cjs.Graphics().p("A8HMAIAA3/MA4QAAAIAAX/g");
	var mask_1_graphics_192 = new cjs.Graphics().p("A8HMaIAA4zMA4QAAAIAAYzg");
	var mask_1_graphics_193 = new cjs.Graphics().p("A8HM0IAA5nMA4QAAAIAAZng");
	var mask_1_graphics_194 = new cjs.Graphics().p("A8HNOIAA6bMA4QAAAIAAabg");
	var mask_1_graphics_195 = new cjs.Graphics().p("A8HNnIAA7NMA4QAAAIAAbNg");
	var mask_1_graphics_196 = new cjs.Graphics().p("A8HOBIAA8BMA4QAAAIAAcBg");
	var mask_1_graphics_197 = new cjs.Graphics().p("A8HObIAA81MA4QAAAIAAc1g");
	var mask_1_graphics_198 = new cjs.Graphics().p("A8HO1IAA9pMA4QAAAIAAdpg");
	var mask_1_graphics_199 = new cjs.Graphics().p("A8HPPIAA+dMA4QAAAIAAedg");
	var mask_1_graphics_200 = new cjs.Graphics().p("A8HPpIAA/RMA4QAAAIAAfRg");
	var mask_1_graphics_201 = new cjs.Graphics().p("A8HQDMAAAggFMA4QAAAMAAAAgFg");
	var mask_1_graphics_202 = new cjs.Graphics().p("A8HQdMAAAgg5MA4QAAAMAAAAg5g");
	var mask_1_graphics_203 = new cjs.Graphics().p("A8HQ2MAAAghrMA4QAAAMAAAAhrg");
	var mask_1_graphics_204 = new cjs.Graphics().p("A8HRQMAAAgifMA4QAAAMAAAAifg");
	var mask_1_graphics_205 = new cjs.Graphics().p("A8HRqMAAAgjTMA4QAAAMAAAAjTg");
	var mask_1_graphics_206 = new cjs.Graphics().p("A8HSEMAAAgkHMA4QAAAMAAAAkHg");
	var mask_1_graphics_207 = new cjs.Graphics().p("A8HSeMAAAgk7MA4QAAAMAAAAk7g");
	var mask_1_graphics_208 = new cjs.Graphics().p("A8HS4MAAAglvMA4QAAAMAAAAlvg");
	var mask_1_graphics_209 = new cjs.Graphics().p("AKiTSMAAAgmjMA4SAAAMAAAAmjg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A8HTSMAAAgmjMA4QAAAMAAAAmjg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A8HTjMAAAgnFMA4QAAAMAAAAnFg");
	var mask_1_graphics_295 = new cjs.Graphics().p("A8HT0MAAAgnnMA4QAAAMAAAAnng");
	var mask_1_graphics_296 = new cjs.Graphics().p("A8HUFMAAAgoJMA4QAAAMAAAAoJg");
	var mask_1_graphics_297 = new cjs.Graphics().p("A8HUWMAAAgorMA4QAAAMAAAAorg");
	var mask_1_graphics_298 = new cjs.Graphics().p("A8HUmMAAAgpLMA4QAAAMAAAApLg");
	var mask_1_graphics_299 = new cjs.Graphics().p("A8HU3MAAAgptMA4QAAAMAAAAptg");
	var mask_1_graphics_300 = new cjs.Graphics().p("A8HVIMAAAgqPMA4QAAAMAAAAqPg");
	var mask_1_graphics_301 = new cjs.Graphics().p("A8HVZMAAAgqxMA4QAAAMAAAAqxg");
	var mask_1_graphics_302 = new cjs.Graphics().p("A8HVqMAAAgrTMA4QAAAMAAAArTg");
	var mask_1_graphics_303 = new cjs.Graphics().p("A8HV7MAAAgr1MA4QAAAMAAAAr1g");
	var mask_1_graphics_304 = new cjs.Graphics().p("A8HWMMAAAgsXMA4QAAAMAAAAsXg");
	var mask_1_graphics_305 = new cjs.Graphics().p("A8HWdMAAAgs5MA4QAAAMAAAAs5g");
	var mask_1_graphics_306 = new cjs.Graphics().p("A8HWuMAAAgtbMA4QAAAMAAAAtbg");
	var mask_1_graphics_307 = new cjs.Graphics().p("A8HW/MAAAgt9MA4QAAAMAAAAt9g");
	var mask_1_graphics_308 = new cjs.Graphics().p("A8HXQMAAAgufMA4QAAAMAAAAufg");
	var mask_1_graphics_309 = new cjs.Graphics().p("A8HXhMAAAgvBMA4QAAAMAAAAvBg");
	var mask_1_graphics_310 = new cjs.Graphics().p("A8HXyMAAAgvjMA4QAAAMAAAAvjg");
	var mask_1_graphics_311 = new cjs.Graphics().p("A8HYDMAAAgwFMA4QAAAMAAAAwFg");
	var mask_1_graphics_363 = new cjs.Graphics().p("AKiYDMAAAgwFMA4SAAAMAAAAwFg");
	var mask_1_graphics_364 = new cjs.Graphics().p("A8HYhMAAAgxBMA4QAAAMAAAAxBg");
	var mask_1_graphics_365 = new cjs.Graphics().p("A8HY/MAAAgx9MA4QAAAMAAAAx9g");
	var mask_1_graphics_366 = new cjs.Graphics().p("A8HZdMAAAgy5MA4QAAAMAAAAy5g");
	var mask_1_graphics_367 = new cjs.Graphics().p("A8HZ8MAAAgz3MA4QAAAMAAAAz3g");
	var mask_1_graphics_368 = new cjs.Graphics().p("A8HaaMAAAg0zMA4QAAAMAAAA0zg");
	var mask_1_graphics_369 = new cjs.Graphics().p("A8Ha4MAAAg1vMA4QAAAMAAAA1vg");
	var mask_1_graphics_370 = new cjs.Graphics().p("A8HbWMAAAg2rMA4QAAAMAAAA2rg");
	var mask_1_graphics_371 = new cjs.Graphics().p("A8Hb0MAAAg3nMA4QAAAMAAAA3ng");
	var mask_1_graphics_372 = new cjs.Graphics().p("A8HcTMAAAg4lMA4QAAAMAAAA4lg");
	var mask_1_graphics_373 = new cjs.Graphics().p("A8HcxMAAAg5hMA4QAAAMAAAA5hg");
	var mask_1_graphics_374 = new cjs.Graphics().p("A8HdPMAAAg6dMA4QAAAMAAAA6dg");
	var mask_1_graphics_375 = new cjs.Graphics().p("A8HdtMAAAg7ZMA4QAAAMAAAA7Zg");
	var mask_1_graphics_376 = new cjs.Graphics().p("A8HeLMAAAg8VMA4QAAAMAAAA8Vg");
	var mask_1_graphics_377 = new cjs.Graphics().p("A8HepMAAAg9RMA4QAAAMAAAA9Rg");
	var mask_1_graphics_378 = new cjs.Graphics().p("A8HfIMAAAg+PMA4QAAAMAAAA+Pg");
	var mask_1_graphics_379 = new cjs.Graphics().p("A8HfmMAAAg/LMA4QAAAMAAAA/Lg");
	var mask_1_graphics_380 = new cjs.Graphics().p("EgcHAgEMAAAhAHMA4QAAAMAAABAHg");
	var mask_1_graphics_381 = new cjs.Graphics().p("EgcHAgiMAAAhBDMA4QAAAMAAABBDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(70).to({graphics:mask_1_graphics_70,x:675.3,y:-21.7}).wait(1).to({graphics:mask_1_graphics_71,x:675.3,y:-20.7}).wait(1).to({graphics:mask_1_graphics_72,x:675.3,y:-19.6}).wait(1).to({graphics:mask_1_graphics_73,x:675.3,y:-18.6}).wait(1).to({graphics:mask_1_graphics_74,x:675.3,y:-17.6}).wait(1).to({graphics:mask_1_graphics_75,x:675.3,y:-16.5}).wait(1).to({graphics:mask_1_graphics_76,x:675.3,y:-15.5}).wait(1).to({graphics:mask_1_graphics_77,x:675.3,y:-14.4}).wait(1).to({graphics:mask_1_graphics_78,x:675.3,y:-13.4}).wait(1).to({graphics:mask_1_graphics_79,x:675.3,y:-12.4}).wait(1).to({graphics:mask_1_graphics_80,x:675.3,y:-11.3}).wait(1).to({graphics:mask_1_graphics_81,x:675.3,y:-10.3}).wait(1).to({graphics:mask_1_graphics_82,x:675.3,y:-9.2}).wait(1).to({graphics:mask_1_graphics_83,x:675.3,y:-8.2}).wait(1).to({graphics:mask_1_graphics_84,x:675.3,y:-7.2}).wait(1).to({graphics:mask_1_graphics_85,x:675.3,y:-6.1}).wait(1).to({graphics:mask_1_graphics_86,x:675.3,y:-5.1}).wait(1).to({graphics:mask_1_graphics_87,x:675.3,y:-4}).wait(1).to({graphics:mask_1_graphics_88,x:675.3,y:-3}).wait(1).to({graphics:mask_1_graphics_89,x:675.3,y:-2}).wait(30).to({graphics:mask_1_graphics_119,x:427.7,y:-1.9}).wait(1).to({graphics:mask_1_graphics_120,x:675.3,y:1}).wait(1).to({graphics:mask_1_graphics_121,x:675.3,y:4.1}).wait(1).to({graphics:mask_1_graphics_122,x:675.3,y:7.1}).wait(1).to({graphics:mask_1_graphics_123,x:675.3,y:10.2}).wait(1).to({graphics:mask_1_graphics_124,x:675.3,y:13.2}).wait(1).to({graphics:mask_1_graphics_125,x:675.3,y:16.3}).wait(1).to({graphics:mask_1_graphics_126,x:675.3,y:19.3}).wait(1).to({graphics:mask_1_graphics_127,x:675.3,y:22.4}).wait(1).to({graphics:mask_1_graphics_128,x:675.3,y:25.4}).wait(1).to({graphics:mask_1_graphics_129,x:675.3,y:28.5}).wait(1).to({graphics:mask_1_graphics_130,x:675.3,y:31.5}).wait(58).to({graphics:mask_1_graphics_188,x:675.3,y:37.5}).wait(1).to({graphics:mask_1_graphics_189,x:675.3,y:40.1}).wait(1).to({graphics:mask_1_graphics_190,x:675.3,y:42.7}).wait(1).to({graphics:mask_1_graphics_191,x:675.3,y:45.3}).wait(1).to({graphics:mask_1_graphics_192,x:675.3,y:47.9}).wait(1).to({graphics:mask_1_graphics_193,x:675.3,y:50.5}).wait(1).to({graphics:mask_1_graphics_194,x:675.3,y:53.1}).wait(1).to({graphics:mask_1_graphics_195,x:675.3,y:55.6}).wait(1).to({graphics:mask_1_graphics_196,x:675.3,y:58.2}).wait(1).to({graphics:mask_1_graphics_197,x:675.3,y:60.8}).wait(1).to({graphics:mask_1_graphics_198,x:675.3,y:63.4}).wait(1).to({graphics:mask_1_graphics_199,x:675.3,y:66}).wait(1).to({graphics:mask_1_graphics_200,x:675.3,y:68.6}).wait(1).to({graphics:mask_1_graphics_201,x:675.3,y:71.2}).wait(1).to({graphics:mask_1_graphics_202,x:675.3,y:73.8}).wait(1).to({graphics:mask_1_graphics_203,x:675.3,y:76.3}).wait(1).to({graphics:mask_1_graphics_204,x:675.3,y:78.9}).wait(1).to({graphics:mask_1_graphics_205,x:675.3,y:81.5}).wait(1).to({graphics:mask_1_graphics_206,x:675.3,y:84.1}).wait(1).to({graphics:mask_1_graphics_207,x:675.3,y:86.7}).wait(1).to({graphics:mask_1_graphics_208,x:675.3,y:89.3}).wait(1).to({graphics:mask_1_graphics_209,x:427.7,y:91.9}).wait(84).to({graphics:mask_1_graphics_293,x:675.3,y:91.9}).wait(1).to({graphics:mask_1_graphics_294,x:675.3,y:93.6}).wait(1).to({graphics:mask_1_graphics_295,x:675.3,y:95.3}).wait(1).to({graphics:mask_1_graphics_296,x:675.3,y:97}).wait(1).to({graphics:mask_1_graphics_297,x:675.3,y:98.7}).wait(1).to({graphics:mask_1_graphics_298,x:675.3,y:100.3}).wait(1).to({graphics:mask_1_graphics_299,x:675.3,y:102}).wait(1).to({graphics:mask_1_graphics_300,x:675.3,y:103.7}).wait(1).to({graphics:mask_1_graphics_301,x:675.3,y:105.4}).wait(1).to({graphics:mask_1_graphics_302,x:675.3,y:107.1}).wait(1).to({graphics:mask_1_graphics_303,x:675.3,y:108.8}).wait(1).to({graphics:mask_1_graphics_304,x:675.3,y:110.5}).wait(1).to({graphics:mask_1_graphics_305,x:675.3,y:112.2}).wait(1).to({graphics:mask_1_graphics_306,x:675.3,y:113.9}).wait(1).to({graphics:mask_1_graphics_307,x:675.3,y:115.6}).wait(1).to({graphics:mask_1_graphics_308,x:675.3,y:117.3}).wait(1).to({graphics:mask_1_graphics_309,x:675.3,y:119}).wait(1).to({graphics:mask_1_graphics_310,x:675.3,y:120.7}).wait(1).to({graphics:mask_1_graphics_311,x:675.3,y:122.4}).wait(52).to({graphics:mask_1_graphics_363,x:427.7,y:122.4}).wait(1).to({graphics:mask_1_graphics_364,x:675.3,y:125.4}).wait(1).to({graphics:mask_1_graphics_365,x:675.3,y:128.4}).wait(1).to({graphics:mask_1_graphics_366,x:675.3,y:131.4}).wait(1).to({graphics:mask_1_graphics_367,x:675.3,y:134.5}).wait(1).to({graphics:mask_1_graphics_368,x:675.3,y:137.5}).wait(1).to({graphics:mask_1_graphics_369,x:675.3,y:140.5}).wait(1).to({graphics:mask_1_graphics_370,x:675.3,y:143.5}).wait(1).to({graphics:mask_1_graphics_371,x:675.3,y:146.5}).wait(1).to({graphics:mask_1_graphics_372,x:675.3,y:149.6}).wait(1).to({graphics:mask_1_graphics_373,x:675.3,y:152.6}).wait(1).to({graphics:mask_1_graphics_374,x:675.3,y:155.6}).wait(1).to({graphics:mask_1_graphics_375,x:675.3,y:158.6}).wait(1).to({graphics:mask_1_graphics_376,x:675.3,y:161.6}).wait(1).to({graphics:mask_1_graphics_377,x:675.3,y:164.6}).wait(1).to({graphics:mask_1_graphics_378,x:675.3,y:167.7}).wait(1).to({graphics:mask_1_graphics_379,x:675.3,y:170.7}).wait(1).to({graphics:mask_1_graphics_380,x:675.3,y:173.7}).wait(1).to({graphics:mask_1_graphics_381,x:675.3,y:176.7}).wait(64));

	// Capa 1
	this.text = new cjs.Text("7\n12", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(764.2,330.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape.setTransform(764.8,357);

	this.text_1 = new cjs.Text("=", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(725.7,340.4);

	this.text_2 = new cjs.Text("1 · 7\n3 · 4", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(666.4,330.7);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(635.7,340.4);

	this.text_4 = new cjs.Text("4\n7", "20px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(605.9,330.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_1.setTransform(614.3,357);

	this.text_5 = new cjs.Text(":", "20px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(583.7,340.4);

	this.text_6 = new cjs.Text("1\n3", "20px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(556.4,330.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_2.setTransform(564.8,357);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAAjMIAAGZIAyh4AAADNIgxh4");
	this.shape_3.setTransform(661.4,301.1);

	this.text_7 = new cjs.Text("4\n7", "20px Verdana");
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(677.9,223.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_4.setTransform(686.3,250);

	this.text_8 = new cjs.Text(":", "20px Verdana");
	this.text_8.lineHeight = 20;
	this.text_8.setTransform(655.7,233.4);

	this.text_9 = new cjs.Text("1\n3", "20px Verdana");
	this.text_9.lineHeight = 20;
	this.text_9.setTransform(628.4,223.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_5.setTransform(636.8,250);

	this.text_10 = new cjs.Text("=", "20px Verdana");
	this.text_10.lineHeight = 20;
	this.text_10.setTransform(599.9,234.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgfjuIgEgHIgYgjQAOASAMARIACADQC3EHi2EEQCRkYiSjvg");
	this.shape_6.setTransform(587.9,248.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAgjyIACgDQAMgRAOgSIgYAjIgEAHQiSDvCREYQi2kEC3kHg");
	this.shape_7.setTransform(543.8,248.2);

	this.text_11 = new cjs.Text("13\n6", "20px Verdana");
	this.text_11.lineHeight = 20;
	this.text_11.setTransform(549.9,223.7);

	this.text_12 = new cjs.Text("3        ", "20px Verdana");
	this.text_12.lineHeight = 20;
	this.text_12.lineWidth = 13;
	this.text_12.setTransform(516.8,233.6);

	this.text_13 = new cjs.Text("39\n6", "20px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 20;
	this.text_13.setTransform(748.7,153.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_8.setTransform(751.3,180);

	this.text_14 = new cjs.Text("=", "20px Verdana");
	this.text_14.lineHeight = 20;
	this.text_14.setTransform(709.9,164.5);

	this.text_15 = new cjs.Text("13\n6", "20px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 20;
	this.text_15.setTransform(686.7,153.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_9.setTransform(689.3,180);

	this.text_16 = new cjs.Text("·", "20px Verdana");
	this.text_16.lineHeight = 20;
	this.text_16.setTransform(655.7,163.4);

	this.text_17 = new cjs.Text("3\n1", "20px Verdana");
	this.text_17.lineHeight = 20;
	this.text_17.setTransform(628.4,153.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_10.setTransform(636.8,180);

	this.text_18 = new cjs.Text("=", "20px Verdana");
	this.text_18.lineHeight = 20;
	this.text_18.setTransform(599.9,164.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgfjuIgEgHIgYgjQAOARAMASIACADQC3EHi2EEQCRkYiSjvg");
	this.shape_11.setTransform(587.9,178.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAgjyIACgDQAMgSAOgRIgYAjIgEAHQiSDvCREYQi2kEC3kHg");
	this.shape_12.setTransform(543.8,178.2);

	this.text_19 = new cjs.Text("13\n6", "20px Verdana");
	this.text_19.lineHeight = 20;
	this.text_19.setTransform(549.9,153.7);

	this.text_20 = new cjs.Text("3        ", "20px Verdana");
	this.text_20.lineHeight = 20;
	this.text_20.lineWidth = 13;
	this.text_20.setTransform(516.8,163.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AAAjMIAAGZIAyh4AAADNIgxh4");
	this.shape_13.setTransform(565.4,121.1);

	this.text_21 = new cjs.Text("4\n7", "20px Verdana");
	this.text_21.lineHeight = 20;
	this.text_21.setTransform(677.9,43.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_14.setTransform(686.3,70);

	this.text_22 = new cjs.Text(":", "20px Verdana");
	this.text_22.lineHeight = 20;
	this.text_22.setTransform(655.7,53.4);

	this.text_23 = new cjs.Text("1\n3", "20px Verdana");
	this.text_23.lineHeight = 20;
	this.text_23.setTransform(628.4,43.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("Ah6AAID1AA");
	this.shape_15.setTransform(636.8,70);

	this.text_24 = new cjs.Text("=", "20px Verdana");
	this.text_24.lineHeight = 20;
	this.text_24.setTransform(599.9,54.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgfjuIgEgHIgYgjQAOASAMARIACADQC3EHi2EEQCRkYiSjvg");
	this.shape_16.setTransform(587.9,68.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAgjyIACgDQAMgRAOgSIgYAjIgEAHQiSDvCREYQi2kEC3kHg");
	this.shape_17.setTransform(543.8,68.2);

	this.text_25 = new cjs.Text("13\n6", "20px Verdana");
	this.text_25.lineHeight = 20;
	this.text_25.setTransform(549.9,43.7);

	this.text_26 = new cjs.Text("3        ", "20px Verdana");
	this.text_26.lineHeight = 20;
	this.text_26.lineWidth = 13;
	this.text_26.setTransform(516.8,53.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AEmWaIImABAtLlOIEwAAAtL2aIEwAAAtLFsIEwAA");
	this.shape_18.setTransform(634.9,213.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#CC0000").ss(1,1,1).p("AHtOEID3AAArjuCIEwAAAAAOEID1AA");
	this.shape_19.setTransform(624.5,160);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("ABl2aID3AAACDlOID3AAALvlOID3AAAAGWaIIlABAN2WaID3AAAxslOIEwAAAppWaID3AAAxYWaID3AAAxsFsIEwAAAmIlOID3AAAmI2aID3AA");
	this.shape_20.setTransform(663.8,213.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("ADlZcQgMgDgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgBAFgEQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKACgJAHIgBAAIAAgVIASgGQAMgDALAAQAKAAAIACQAJACAGAEQAHAFAEAHQADAGAAAJQAAAMgIAKQgJAIgLADIAAABIAKAEQAGACAFADQAEAFADAGQADAGAAAKQAAALgDAHQgEAJgGAGQgIAHgKAEQgKACgLAAQgMAAgMgCgAtlZcQgMgDgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgBAFgEQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKACgJAHIgBAAIAAgVIASgGQAMgDALAAQAKAAAIACQAJACAGAEQAHAFAEAHQADAGAAAJQAAAMgIAKQgJAIgLADIAAABIAKAEQAGACAFADQAEAFADAGQADAGAAAKQAAALgDAHQgEAJgGAGQgIAHgKAEQgKACgLAAQgMAAgMgCgASjZcIAAgVIAVgRIATgSQASgSAHgLQAHgLAAgMQAAgLgHgHQgIgGgNAAQgJAAgKADQgLADgJAHIgBAAIAAgVQAHgDALgDQAMgDALAAQAWAAANALQAMALAAASQAAAIgCAIQgCAHgEAGQgEAHgFAFIgMANIgWAUIgVASIBOAAIAAARgAQvZcIAAgQIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAQgAJjZcIAAgqIhFAAIAAgWIBGhSIASAAIAABZIAWAAIAAAPIgWAAIAAAqgAIrYjIA4AAIAAhCgAl+ZcIBGiBIhTAAIAAgRIBkAAIAAAWIhCB8gAGfYpIAAgbIAYAAIAAAbgApVXKIAAgcIAXAAIAAAcgAMrWmIAAgQIBzAAIAAAQgAhXWmIAAgQIBxAAIAAAQgAMrV9IAAgPIBzAAIAAAPgAhXV9IAAgPIBxAAIAAAPgApVV5IAAgcIAXAAIAAAcgARwVoIBGiAIhTAAIAAgRIBjAAIAAAWIhCB7gAIyVoIBGiAIhTAAIAAgRIBkAAIAAAWIhCB7gADcVoIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAPgAlNVoIAAgpIhFAAIAAgWIBGhSIASAAIAABZIAWAAIAAAPIgWAAIAAApgAmFUwIA4AAIAAhCgAtuVoIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAPgAGfU2IAAgbIAYAAIAAAbgAqBBiIgFgHIgXgjQAOASAMARIACAEQC4EIi4EEQCTkYiTjxgAv6BfIACgEQAMgRAOgSIgXAjIgFAHQiTDxCTEYQi4kEC4kIgAtbItQgJgDgGgGQgJgJgEgNQgFgOAAgTQAAgSAEgQQAEgOAKgMQAIgLAOgHQANgFASAAIAKAAIAIACIAAASIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNAOgCAWQAJgFAIgDQAHgCALAAQAJAAAHACQAHABAIAFQAIAGAFAJQAEAKAAANQAAAWgOAOQgPANgVAAQgLAAgJgDgAtZHjQgHACgIADIAAAFIAAAFQAAAPADAJQADAJAGAGQAEADAGACQAFADAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgCgFgBIgMgBQgIAAgHACgAzxGdQgMgDgHgDIAAgVIABAAQAIAGAMADQALAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgFAAgJQAAgHgCgFQgDgGgEgCQgEgDgHgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgGAAgMQAAgGgDgDQgCgEgEgDIgJgDIgLgCQgJAAgLAEQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAEQAHAEAEAHQADAHAAAIQAAANgIAJQgJAJgLACIAAABIAKAEQAGADAFADQAEAEADAGQADAHAAAKQAAAKgDAIQgEAIgGAHQgIAGgKAEQgKADgLAAQgMAAgMgDgAm9GDIAAgQIBzAAIAAAQgAm9FaIAAgPIBzAAIAAAPgAsnE6QgMgCgHgEIAAgUIABAAQAIAFAMAEQALAEAKAAQAGgBAHgCQAHgCAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLAEQgKACgJAHIgBAAIAAgVIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAJQAAAMgIAKQgJAJgLABIAAACIAKAEQAGACAFADQAEAFADAGQADAHAAAJQAAALgDAHQgEAJgGAGQgIAHgKADQgKADgLAAQgMAAgMgDgAuvE6IAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAPgAqBpYIgFgGIgXgjQAOARAMASIACADQC4EJi4EDQCTkYiTjxgAv6pbIACgDQAMgSAOgRIgXAjIgFAGQiTDxCTEYQi4kDC4kJgAPniNQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgCALAAQAJgBAHACQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAPpjYQgHACgIAFIAAAEIAAAFQAAAPADAJQADAJAGAGQAEAEAGACQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHABgAF7iNQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgCALAAQAJgBAHACQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAF9jYQgHACgIAFIAAAEIAAAFQAAAPADAJQADAJAGAGQAEAEAGACQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHABgAtbiNQgJgDgGgHQgJgIgEgNQgFgNAAgUQAAgSAEgQQAEgPAKgLQAIgLAOgGQANgHASABIAKAAIAIABIAAATIgBAAIgIgCQgGgCgGAAQgVAAgMANQgNANgCAXQAJgFAIgDQAHgCALAAQAJgBAHACQAHACAIAFQAIAGAFAKQAEAIAAANQAAAXgOANQgPAPgVAAQgLAAgJgEgAtZjYQgHACgIAFIAAAEIAAAFQAAAPADAJQADAJAGAGQAEAEAGACQAFACAGAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgDgFAAIgMgBQgIAAgHABgAieiNIAAgOIAfAAIAAhiIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACEIAeAAIAAAOgAzxkdQgMgDgHgDIAAgVIABAAQAIAGAMADQALAEAKAAQAGAAAHgCQAHgCAFgEQAEgFACgEQACgGAAgIQAAgHgCgFQgDgFgEgEQgEgCgHgBQgGgCgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJgBgLAEQgKADgJAGIgBAAIAAgUIASgHQAMgCALAAQAKAAAIACQAJACAGAEQAHAFAEAGQADAHAAAJQAAAMgIAJQgJAJgLACIAAABIAKAEQAGADAFADQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAFQgIAIgKADQgKADgLAAQgMAAgMgDgAKNk3IAAgPIBzAAIAAAPgAm9k3IAAgPIBzAAIAAAPgABvlQIAAgcIAYAAIAAAcgAKNlgIAAgQIBzAAIAAAQgAm9lgIAAgQIBzAAIAAAQgAQZl9IgIgCIAAgTIABAAIAIAEIAMABQAWgBAMgNQAMgMACgXQgJAFgIACQgIADgKAAQgJAAgHgCQgHgCgHgEQgJgGgEgJQgFgKAAgNQAAgWAPgOQAPgOAVAAQAKAAAJADQAJADAHAHQAIAIAFANQAEANAAAUQAAATgEAPQgEAQgJALQgJALgOAHQgNAFgSABIgKgBgAQfn7QgIAJAAAPQAAAKADAFQACAGAHAFQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgPgDgKQgDgJgFgEQgFgFgFgCQgFgCgHAAQgOAAgIAJgAOdmAQgMgCgHgDIAAgVIABAAQAIAGAMADQALADAKABQAGAAAHgCQAHgDAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgHAAIgJAAIAAgPIAHAAQAPgBAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKAEgJAFIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKAEQAGACAFAEQAEAEADAGQADAHAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAGwmAQgMgCgHgDIAAgVIABAAQAIAGAMADQALADAKABQAGAAAHgCQAHgDAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgHAAIgJAAIAAgPIAHAAQAPgBAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKAEgJAFIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKAEQAGACAFAEQAEAEADAGQADAHAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAiVmAQgMgCgHgDIAAgVIABAAQAIAGAMADQALADAKABQAGAAAHgCQAHgDAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgHAAIgJAAIAAgPIAHAAQAPgBAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKAEgJAFIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKAEQAGACAFAEQAEAEADAGQADAHAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAsnmAQgMgCgHgDIAAgVIABAAQAIAGAMADQALADAKABQAGAAAHgCQAHgDAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgHAAIgJAAIAAgPIAHAAQAPgBAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKAEgJAFIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKAEQAGACAFAEQAEAEADAGQADAHAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAEomAIAAgOIAfAAIAAhiIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACEIAeAAIAAAOgAuvmAIAAgOIAfAAIAAhiIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACEIAeAAIAAAOgAiVzZQgMgCgHgEIAAgUIABAAQAIAFAMAEQALAEAKAAQAGgBAHgCQAHgCAFgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAJgFQAJgHAAgMQAAgFgDgEQgCgEgEgCIgJgEIgLgBQgJAAgLAEQgKACgJAHIgBAAIAAgVIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAJQAAAMgIAKQgJAJgLABIAAACIAKAEQAGACAFADQAEAFADAGQADAHAAAJQAAALgDAHQgEAJgGAGQgIAHgKADQgKADgLAAQgMAAgMgDgAFQzZIBGiAIhTAAIAAgRIBkAAIAAAWIhCB7gAB51qIAAgcIAXAAIAAAcgAm92DIAAgQIBzAAIAAAQgAm92sIAAgPIBzAAIAAAPgAB527IAAgcIAXAAIAAAcgAGB3MIAAgoIhFAAIAAgXIBGhSIASAAIAABZIAWAAIAAAQIgWAAIAAAogAFJ4EIA4AAIAAhBgAie3MIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAPg");
	this.shape_21.setTransform(649,214.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0000").s().p("AEWR8QgLgCgIgEIAAgUIACAAQAIAFAMAEQAKAEALAAQAGgBAHgCQAHgCAFgDQAEgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAIgFQAJgHAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKAEQgKACgJAHIgBAAIAAgVIASgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgIAKQgJAJgMABIAAACIALAEQAGACAFADQAEAFADAGQADAHAAAJQAAALgEAHQgDAJgHAGQgHAHgKADQgKADgMAAQgMAAgMgDgAL+R8IBGiAIhTAAIAAgRIBjAAIAAAWIhBB7gAInPrIAAgcIAWAAIAAAcgAInOaIAAgcIAWAAIAAAcgAMvOJIAAgoIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAAogAL3NRIA4AAIAAhBgAEOOJIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAGgBAEgCQAEgCADgEQACgEABgGIAPAAIAACCIAeAAIAAAPgAjTxVIgFgHIgXgjQAOASALARIADAEQC4EIi4EEQCTkYiTjxgApMxYIACgEQAMgRAOgSIgYAjIgEAHQiUDxCUEYQi4kEC4kIgAmtqKQgJgDgGgHQgJgIgFgNQgEgOAAgTQAAgSAEgQQAEgOAKgMQAIgLANgHQAOgFASAAIAKAAIAIACIAAATIgBAAIgIgDQgGgCgGAAQgVAAgMANQgNAOgCAWQAIgFAJgDQAHgCALAAQAJAAAHACQAHABAHAFQAJAGAFAJQAEAKAAANQAAAWgOAOQgQANgUAAQgLAAgJgDgAmrrUQgIABgHAEIgBAFIAAAFQABAPADAJQADAJAFAGQAFADAFACQAFADAHAAQAOAAAIgJQAIgIAAgRQAAgJgCgGQgDgGgGgFQgFgCgFgBIgMgBQgIAAgHACgAtEsaQgLgDgIgDIAAgVIACAAQAIAGAMADQAKAEALAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgDgFQgCgGgEgCQgFgDgGgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAJgGAAgMQAAgGgCgDQgCgEgEgDIgJgDIgLgCQgKAAgKAEQgKADgJAGIgBAAIAAgUIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAEADAHQAEAHAAAIQAAANgIAJQgJAJgMACIAAABIALAEQAGADAFADQAEAEADAGQADAHAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgNAAgMgDgAl6t9QgLgCgIgEIAAgUIACAAQAIAFALAEQAMAEAKAAQAGgBAHgCQAHgCAFgDQAEgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgEgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAIgFQAJgHAAgMQABgFgDgEQgCgEgEgDIgJgDIgLgBQgKAAgKAEQgKACgJAHIgBAAIAAgVIASgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAKQgIAJgMABIAAACIALAEQAGACAFADQAEAFADAGQADAHAAAJQAAALgEAHQgDAJgHAGQgHAHgKADQgKADgLAAQgNAAgMgDgAoBt9IAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAGgBAEgCQAFgCACgEQACgEABgGIAPAAIAACCIAeAAIAAAPg");
	this.shape_22.setTransform(606,155.2);

	this.text.mask = this.shape.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.shape_1.mask = this.text_5.mask = this.text_6.mask = this.shape_2.mask = this.shape_3.mask = this.text_7.mask = this.shape_4.mask = this.text_8.mask = this.text_9.mask = this.shape_5.mask = this.text_10.mask = this.shape_6.mask = this.shape_7.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.shape_8.mask = this.text_14.mask = this.text_15.mask = this.shape_9.mask = this.text_16.mask = this.text_17.mask = this.shape_10.mask = this.text_18.mask = this.shape_11.mask = this.shape_12.mask = this.text_19.mask = this.text_20.mask = this.shape_13.mask = this.text_21.mask = this.shape_14.mask = this.text_22.mask = this.text_23.mask = this.shape_15.mask = this.text_24.mask = this.shape_16.mask = this.shape_17.mask = this.text_25.mask = this.text_26.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_18},{t:this.text_26},{t:this.text_25},{t:this.shape_17},{t:this.shape_16},{t:this.text_24},{t:this.shape_15},{t:this.text_23},{t:this.text_22},{t:this.shape_14},{t:this.text_21},{t:this.shape_13},{t:this.text_20},{t:this.text_19},{t:this.shape_12},{t:this.shape_11},{t:this.text_18},{t:this.shape_10},{t:this.text_17},{t:this.text_16},{t:this.shape_9},{t:this.text_15},{t:this.text_14},{t:this.shape_8},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.shape_7},{t:this.shape_6},{t:this.text_10},{t:this.shape_5},{t:this.text_9},{t:this.text_8},{t:this.shape_4},{t:this.text_7},{t:this.shape_3},{t:this.shape_2},{t:this.text_6},{t:this.text_5},{t:this.shape_1},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape},{t:this.text}]},70).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_13},{t:this.shape_3}]},35).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_13},{t:this.shape_3}]},234).wait(106));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,36.5,428.7,271.3);


(lib.textoAnimado_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg+ygANIAAh4MB9lAAAIAAB4g");
	var mask_graphics_1 = new cjs.Graphics().p("Eg+yABOIAAibMB9lAAAIAACbg");
	var mask_graphics_2 = new cjs.Graphics().p("Eg+yABhIAAjBMB9lAAAIAADBg");
	var mask_graphics_3 = new cjs.Graphics().p("Eg+yAB0IAAjnMB9lAAAIAADng");
	var mask_graphics_4 = new cjs.Graphics().p("Eg+yACHIAAkNMB9lAAAIAAENg");
	var mask_graphics_5 = new cjs.Graphics().p("Eg+yACaIAAkzMB9lAAAIAAEzg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg+yACtIAAlZMB9lAAAIAAFZg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg+yADAIAAl/MB9lAAAIAAF/g");
	var mask_graphics_8 = new cjs.Graphics().p("Eg+yADTIAAmlMB9lAAAIAAGlg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg+yADmIAAnLMB9lAAAIAAHLg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg+yAD5IAAnxMB9lAAAIAAHxg");
	var mask_graphics_11 = new cjs.Graphics().p("Eg+yAEMIAAoXMB9lAAAIAAIXg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg+yAEfIAAo9MB9lAAAIAAI9g");
	var mask_graphics_13 = new cjs.Graphics().p("Eg+yAEyIAApjMB9lAAAIAAJjg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg+yAFFIAAqJMB9lAAAIAAKJg");
	var mask_graphics_37 = new cjs.Graphics().p("Eg+yAFFIAAqJMB9lAAAIAAKJg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg+yAFeIAAq7MB9lAAAIAAK7g");
	var mask_graphics_39 = new cjs.Graphics().p("Eg+yAF4IAArvMB9lAAAIAALvg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg+yAGSIAAsjMB9lAAAIAAMjg");
	var mask_graphics_41 = new cjs.Graphics().p("Eg+yAGsIAAtWMB9lAAAIAANWg");
	var mask_graphics_42 = new cjs.Graphics().p("Eg+yAHFIAAuJMB9lAAAIAAOJg");
	var mask_graphics_43 = new cjs.Graphics().p("Eg+yAHfIAAu9MB9lAAAIAAO9g");
	var mask_graphics_44 = new cjs.Graphics().p("Eg+yAH5IAAvxMB9lAAAIAAPxg");
	var mask_graphics_45 = new cjs.Graphics().p("Eg+yAISIAAwkMB9lAAAIAAQkg");
	var mask_graphics_46 = new cjs.Graphics().p("Eg+yAIsIAAxXMB9lAAAIAARXg");
	var mask_graphics_47 = new cjs.Graphics().p("Eg+yAJGIAAyLMB9lAAAIAASLg");
	var mask_graphics_48 = new cjs.Graphics().p("Eg+yAJgIAAy/MB9lAAAIAAS/g");
	var mask_graphics_49 = new cjs.Graphics().p("Eg+yAJ6IAAzyMB9lAAAIAATyg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg+yAKTIAA0lMB9lAAAIAAUlg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg+yAKtIAA1ZMB9lAAAIAAVZg");
	var mask_graphics_52 = new cjs.Graphics().p("Eg+yALHIAA2NMB9lAAAIAAWNg");
	var mask_graphics_53 = new cjs.Graphics().p("Eg+yALhIAA3BMB9lAAAIAAXBg");
	var mask_graphics_54 = new cjs.Graphics().p("Eg+yAL6IAA3zMB9lAAAIAAXzg");
	var mask_graphics_55 = new cjs.Graphics().p("Eg+yAMUIAA4nMB9lAAAIAAYng");
	var mask_graphics_56 = new cjs.Graphics().p("Eg+yAMuIAA5bMB9lAAAIAAZbg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg+yAMuIAA5bMB9lAAAIAAZbg");
	var mask_graphics_80 = new cjs.Graphics().p("Eg+yANJIAA6RMB9lAAAIAAaRg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg+yANkIAA7HMB9lAAAIAAbHg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg+yAN/IAA79MB9lAAAIAAb9g");
	var mask_graphics_83 = new cjs.Graphics().p("Eg+yAOZIAA8xMB9lAAAIAAcxg");
	var mask_graphics_84 = new cjs.Graphics().p("Eg+yAO0IAA9nMB9lAAAIAAdng");
	var mask_graphics_85 = new cjs.Graphics().p("Eg+yAPPIAA+dMB9lAAAIAAedg");
	var mask_graphics_86 = new cjs.Graphics().p("Eg+yAPqIAA/TMB9lAAAIAAfTg");
	var mask_graphics_87 = new cjs.Graphics().p("Eg+yAQFMAAAggJMB9lAAAMAAAAgJg");
	var mask_graphics_88 = new cjs.Graphics().p("Eg+yAQgMAAAgg/MB9lAAAMAAAAg/g");
	var mask_graphics_89 = new cjs.Graphics().p("Eg+yAQ7MAAAgh1MB9lAAAMAAAAh1g");
	var mask_graphics_90 = new cjs.Graphics().p("Eg+yARWMAAAgirMB9lAAAMAAAAirg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg+yARxMAAAgjhMB9lAAAMAAAAjhg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg+yASMMAAAgkXMB9lAAAMAAAAkXg");
	var mask_graphics_93 = new cjs.Graphics().p("Eg+yASnMAAAglNMB9lAAAMAAAAlNg");
	var mask_graphics_94 = new cjs.Graphics().p("Eg+yATCMAAAgmDMB9lAAAMAAAAmDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:382,y:-13.3}).wait(1).to({graphics:mask_graphics_1,x:382,y:-18.8}).wait(1).to({graphics:mask_graphics_2,x:382,y:-16.9}).wait(1).to({graphics:mask_graphics_3,x:382,y:-15}).wait(1).to({graphics:mask_graphics_4,x:382,y:-13.1}).wait(1).to({graphics:mask_graphics_5,x:382,y:-11.2}).wait(1).to({graphics:mask_graphics_6,x:382,y:-9.3}).wait(1).to({graphics:mask_graphics_7,x:382,y:-7.4}).wait(1).to({graphics:mask_graphics_8,x:382,y:-5.5}).wait(1).to({graphics:mask_graphics_9,x:382,y:-3.6}).wait(1).to({graphics:mask_graphics_10,x:382,y:-1.6}).wait(1).to({graphics:mask_graphics_11,x:382,y:0.2}).wait(1).to({graphics:mask_graphics_12,x:382,y:2.1}).wait(1).to({graphics:mask_graphics_13,x:382,y:4}).wait(1).to({graphics:mask_graphics_14,x:382,y:5.9}).wait(23).to({graphics:mask_graphics_37,x:382,y:5.9}).wait(1).to({graphics:mask_graphics_38,x:382,y:8.5}).wait(1).to({graphics:mask_graphics_39,x:382,y:11.1}).wait(1).to({graphics:mask_graphics_40,x:382,y:13.6}).wait(1).to({graphics:mask_graphics_41,x:382,y:16.2}).wait(1).to({graphics:mask_graphics_42,x:382,y:18.8}).wait(1).to({graphics:mask_graphics_43,x:382,y:21.4}).wait(1).to({graphics:mask_graphics_44,x:382,y:24}).wait(1).to({graphics:mask_graphics_45,x:382,y:26.5}).wait(1).to({graphics:mask_graphics_46,x:382,y:29.1}).wait(1).to({graphics:mask_graphics_47,x:382,y:31.7}).wait(1).to({graphics:mask_graphics_48,x:382,y:34.3}).wait(1).to({graphics:mask_graphics_49,x:382,y:36.9}).wait(1).to({graphics:mask_graphics_50,x:382,y:39.4}).wait(1).to({graphics:mask_graphics_51,x:382,y:42}).wait(1).to({graphics:mask_graphics_52,x:382,y:44.6}).wait(1).to({graphics:mask_graphics_53,x:382,y:47.2}).wait(1).to({graphics:mask_graphics_54,x:382,y:49.8}).wait(1).to({graphics:mask_graphics_55,x:382,y:52.3}).wait(1).to({graphics:mask_graphics_56,x:382,y:54.9}).wait(23).to({graphics:mask_graphics_79,x:382,y:54.9}).wait(1).to({graphics:mask_graphics_80,x:382,y:57.6}).wait(1).to({graphics:mask_graphics_81,x:382,y:60.3}).wait(1).to({graphics:mask_graphics_82,x:382,y:63}).wait(1).to({graphics:mask_graphics_83,x:382,y:65.6}).wait(1).to({graphics:mask_graphics_84,x:382,y:68.3}).wait(1).to({graphics:mask_graphics_85,x:382,y:71}).wait(1).to({graphics:mask_graphics_86,x:382,y:73.7}).wait(1).to({graphics:mask_graphics_87,x:382,y:76.3}).wait(1).to({graphics:mask_graphics_88,x:382,y:79}).wait(1).to({graphics:mask_graphics_89,x:382,y:81.7}).wait(1).to({graphics:mask_graphics_90,x:382,y:84.4}).wait(1).to({graphics:mask_graphics_91,x:382,y:87}).wait(1).to({graphics:mask_graphics_92,x:382,y:89.7}).wait(1).to({graphics:mask_graphics_93,x:382,y:92.4}).wait(1).to({graphics:mask_graphics_94,x:382,y:95}).wait(4));

	// Capa 1
	this.txt_11 = new cjs.Text(txt['txt_11'], "20px Verdana");
	this.txt_11.lineHeight = 20;
	this.txt_11.lineWidth = 788;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADOAAID3AAAK9AAID3AAAmNAAID3AAAuzAAID3AA");
	this.shape.setTransform(152,89.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AACjuIgDgHIgYgjQAOARALASIACADQC4EHi4EEQCTkYiTjvgAsFjyIACgDQAMgSAOgRIgXAjIgFAHQiUDvCTEYQi3kEC4kHgAHQDbQgMgCgHgEIAAgUIABAAQAIAFALAEQALADALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgHQAAgIgCgGQgDgEgEgEQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAJgHAAgMQgBgEgCgFQgCgEgEgCIgJgEIgLgBQgJABgLADQgKADgKAGIgBAAIAAgVIATgFQAMgEALAAQAKAAAIACQAJADAGAEQAHAEAEAHQADAGAAAJQAAAMgJAKQgIAJgLACIAAACIAKADQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgEAIQgDAIgGAHQgIAGgKAEQgKADgLAAQgMAAgMgDgAiLDbQgMgCgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgHQAAgIgCgGQgDgEgEgEQgEgDgHgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAIgHABgMQAAgEgDgFQgCgEgEgCIgJgEIgLgBQgJABgLADQgKADgKAGIAAAAIAAgVIASgFQALgEAMAAQAKAAAIACQAIADAHAEQAHAEADAHQAEAGAAAJQAAAMgIAKQgJAJgLACIAAACIAKADQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgDAIQgEAIgGAHQgIAGgKAEQgKADgMAAQgMAAgLgDgAO3DbIBGiBIhTAAIAAgQIBkAAIAAAVIhDB8gArGDbIAAgVIAWgRIATgRQASgTAHgLQAHgKAAgMQAAgLgHgHQgIgGgNgBQgJAAgLADQgKAEgJAGIgBAAIAAgVQAGgDAMgCQAMgEAKAAQAWABANAKQANALAAATQAAAIgCAHQgCAHgEAHQgEAGgFAFIgNAOIgVAUIgVASIBOAAIAAAQgAv8BLQgMgDgHgDIAAgVIABAAQAIAGALADQAMADAKAAQAGAAAHgBQAHgCAEgFQAFgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgFgDgGgBQgGgCgIABIgIAAIAAgOIAGAAQAPAAAKgHQAIgGABgMQgBgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKADQgKAEgKAFIgBAAIAAgUIATgGQAMgDALAAQAKAAAIACQAIACAHAEQAHAFAEAGQADAHAAAJQAAAMgJAJQgIAKgLACIAAABIAKADQAGABAEAEQAFADADAHQADAGAAALQAAAJgDAJQgEAIgGAGQgIAHgKAEQgKADgMAAQgLAAgMgDgALfBJIAAgcIAYAAIAAAcgACyAcIAAgPIBhAAIAAAPgAm7AcIAAgPIBhAAIAAAPgALfgGIAAgcIAYAAIAAAcgAqwgVQgLgDgHgEIAAgUIABAAQAHAFAMAEQAKADAKAAQAIAAAGgCQAHgCAEgFQAFgEACgGQACgFAAgIQAAgIgCgFQgDgFgEgEQgFgDgIgBQgHgCgJAAIgQABIgPADIAAhLIBYAAIAAAQIhFAAIAAAoIAJgBIAHAAQAMAAAKACQAIABAHAGQAIAFAFAIQAEAJAAANQAAAKgDAJQgFAKgGAGQgHAGgJAFQgKADgNAAQgMAAgLgCgAPogWIAAgpIhFAAIAAgWIBGhSIASAAIAABYIAVAAIAAAQIgVAAIAAApgAOwhPIA4AAIAAhBgAHHgWIAAgPIAeAAIAAhiIgeAAIAAgMIANgBQAIgCADgCQAEgCADgDQACgFABgGIAPAAIAACDIAeAAIAAAPgAiUgWIAAgPIAeAAIAAhiIgeAAIAAgMIANgBQAIgCADgCQAEgCADgDQADgFAAgGIAPAAIAACDIAeAAIAAAPg");
	this.shape_1.setTransform(135.8,87.6);

	this.txt_11.mask = this.shape.mask = this.shape_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.txt_11}]}).wait(98));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,792,198.4);


(lib.mc_loader_barra = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#FFFFFF"],[0.894,1],21.4,17.1,-2.9,-25.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape.setTransform(9,27.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],21.5,16.9,-3.1,-24.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_1.setTransform(9,27.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],21.5,16.7,-3.3,-24.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_2.setTransform(9,27.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],21.6,16.4,-3.4,-24.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_3.setTransform(9,27.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],21.7,16.2,-3.6,-24.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_4.setTransform(9,27.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],21.8,15.9,-3.7,-24.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_5.setTransform(9,27.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],21.9,15.7,-3.9,-24).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_6.setTransform(9,27.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],21.9,15.4,-4.1,-23.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_7.setTransform(9,27.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],22.1,15.2,-4.2,-23.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_8.setTransform(9,27.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],22.1,14.9,-4.4,-23.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_9.setTransform(9,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],22.2,14.7,-4.5,-23.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_10.setTransform(9,27.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],22.3,14.5,-4.7,-23.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_11.setTransform(9,27.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],22.4,14.2,-4.8,-22.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_12.setTransform(9,27.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],22.5,13.9,-5,-22.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_13.setTransform(9,27.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],22.5,13.7,-5.2,-22.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_14.setTransform(9,27.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],22.6,13.5,-5.4,-22.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_15.setTransform(9,27.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],22.7,13.2,-5.5,-22.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_16.setTransform(9,27.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],22.8,12.9,-5.7,-22.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_17.setTransform(9,27.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],22.9,12.7,-5.8,-21.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_18.setTransform(9,27.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],23,12.5,-6,-21.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_19.setTransform(9,27.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],23.1,12.2,-6.1,-21.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_20.setTransform(9,27.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],23.2,11.9,-6.3,-21.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_21.setTransform(9,27.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],23.2,11.7,-6.5,-21.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_22.setTransform(9,27.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],23.3,11.5,-6.6,-21).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_23.setTransform(9,27.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],23.4,11.2,-6.8,-20.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_24.setTransform(9,27.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],23.5,10.9,-6.9,-20.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_25.setTransform(9,27.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],23.6,10.7,-7.1,-20.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_26.setTransform(9,27.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],23.6,10.5,-7.3,-20.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_27.setTransform(9,27.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],23.8,10.2,-7.4,-20.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_28.setTransform(9,27.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],23.8,10,-7.6,-19.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_29.setTransform(9,27.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],23.9,9.7,-7.7,-19.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_30.setTransform(9,27.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],24,9.5,-7.9,-19.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_31.setTransform(9,27.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],24.1,9.2,-8,-19.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_32.setTransform(9,27.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],24.2,9,-8.2,-19.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_33.setTransform(9,27.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],24.2,8.7,-8.4,-19.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_34.setTransform(9,27.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],24.3,8.5,-8.5,-18.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_35.setTransform(9,27.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],24.4,8.3,-8.7,-18.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_36.setTransform(9,27.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],24.5,8,-8.8,-18.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_37.setTransform(9,27.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],24.6,7.7,-9,-18.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_38.setTransform(9,27.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],24.7,7.5,-9.2,-18.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_39.setTransform(9,27.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],24.8,7.3,-9.3,-18).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_40.setTransform(9,27.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],24.8,7,-9.5,-17.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_41.setTransform(9,27.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],24.9,6.7,-9.7,-17.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_42.setTransform(9,27.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],25,6.5,-9.8,-17.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_43.setTransform(9,27.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],25.1,6.3,-9.9,-17.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_44.setTransform(9,27.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],25.2,6,-10.1,-17.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_45.setTransform(9,27.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],25.3,5.8,-10.3,-17).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_46.setTransform(9,27.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],25.3,5.5,-10.5,-16.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_47.setTransform(9,27.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],25.4,5.3,-10.6,-16.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_48.setTransform(9,27.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],25.5,5,-10.8,-16.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_49.setTransform(9,27.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],25.6,4.8,-10.9,-16.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_50.setTransform(9,27.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],25.7,4.5,-11.1,-16.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_51.setTransform(9,27.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],25.8,4.3,-11.2,-15.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_52.setTransform(9,27.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],25.9,4,-11.4,-15.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_53.setTransform(9,27.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],25.9,3.8,-11.6,-15.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_54.setTransform(9,27.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],26,3.5,-11.7,-15.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_55.setTransform(9,27.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],26.1,3.3,-11.9,-15.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_56.setTransform(9,27.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],26.2,3,-12,-15.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_57.setTransform(9,27.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],26.3,2.8,-12.2,-14.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_58.setTransform(9,27.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],26.3,2.6,-12.4,-14.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_59.setTransform(9,27.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],26.5,2.3,-12.5,-14.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_60.setTransform(9,27.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],26.5,2.1,-12.7,-14.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_61.setTransform(9,27.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],26.6,1.8,-12.8,-14.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_62.setTransform(9,27.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],26.7,1.6,-13,-14).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_63.setTransform(9,27.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],26.8,1.3,-13.1,-13.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_64.setTransform(9,27.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],26.9,1.1,-13.3,-13.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_65.setTransform(9,27.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],26.9,0.8,-13.5,-13.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_66.setTransform(9,27.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],27,0.6,-13.7,-13.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_67.setTransform(9,27.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],27.1,0.3,-13.8,-13.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_68.setTransform(9,27.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],27.2,0.1,-14,-12.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_69.setTransform(9,27.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],27.3,-0.1,-14.1,-12.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_70.setTransform(9,27.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],27.4,-0.3,-14.3,-12.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_71.setTransform(9,27.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],27.5,-0.5,-14.4,-12.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_72.setTransform(9,27.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],27.6,-0.8,-14.6,-12.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_73.setTransform(9,27.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],27.6,-1.1,-14.8,-12.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_74.setTransform(9,27.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],27.7,-1.3,-14.9,-11.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_75.setTransform(9,27.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],27.8,-1.5,-15.1,-11.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_76.setTransform(9,27.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],27.9,-1.8,-15.2,-11.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_77.setTransform(9,27.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],28,-2.1,-15.4,-11.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_78.setTransform(9,27.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],28,-2.3,-15.6,-11.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_79.setTransform(9,27.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],28.2,-2.5,-15.7,-11).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_80.setTransform(9,27.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],28.2,-2.8,-15.9,-10.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_81.setTransform(9,27.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],28.3,-3.1,-16,-10.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_82.setTransform(9,27.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],28.4,-3.3,-16.2,-10.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_83.setTransform(9,27.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],28.5,-3.5,-16.3,-10.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_84.setTransform(9,27.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],28.6,-3.8,-16.5,-10.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_85.setTransform(9,27.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],28.6,-4,-16.7,-9.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_86.setTransform(9,27.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],28.7,-4.3,-16.8,-9.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_87.setTransform(9,27.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],28.8,-4.5,-17,-9.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_88.setTransform(9,27.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],28.9,-4.8,-17.1,-9.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_89.setTransform(9,27.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],29,-5,-17.3,-9.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_90.setTransform(9,27.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],29.1,-5.3,-17.5,-9.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_91.setTransform(9,27.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],29.2,-5.5,-17.6,-8.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_92.setTransform(9,27.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],29.2,-5.7,-17.8,-8.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_93.setTransform(9,27.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],29.3,-6,-18,-8.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_94.setTransform(9,27.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],29.4,-6.3,-18.1,-8.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_95.setTransform(9,27.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],29.5,-6.5,-18.2,-8.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_96.setTransform(9,27.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],29.6,-6.7,-18.4,-8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_97.setTransform(9,27.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],29.7,-7,-18.6,-7.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_98.setTransform(9,27.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],29.7,-7.3,-18.8,-7.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_99.setTransform(9,27.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#000000","#FFFFFF"],[0,0.592],29.8,-7.5,-18.9,-7.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_100.setTransform(9,27.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).wait(101));

	// Capa 2
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["#000000","#FFFFFF"],[0.894,1],-21.2,-17,3.1,25.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_101.setTransform(18.2,18.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],-21.3,-16.8,3.3,25).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_102.setTransform(18.2,18.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],-21.4,-16.5,3.4,24.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_103.setTransform(18.2,18.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],-21.4,-16.2,3.6,24.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_104.setTransform(18.2,18.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],-21.6,-16,3.7,24.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_105.setTransform(18.2,18.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],-21.6,-15.8,3.9,24.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_106.setTransform(18.2,18.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],-21.7,-15.5,4.1,24.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_107.setTransform(18.2,18.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],-21.8,-15.2,4.2,24).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_108.setTransform(18.2,18.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],-21.9,-15,4.4,23.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_109.setTransform(18.2,18.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],-22,-14.8,4.5,23.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_110.setTransform(18.2,18.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],-22,-14.5,4.7,23.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_111.setTransform(18.2,18.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],-22.1,-14.3,4.9,23.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_112.setTransform(18.2,18.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],-22.2,-14,5,23.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_113.setTransform(18.2,18.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],-22.3,-13.8,5.2,22.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_114.setTransform(18.2,18.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],-22.4,-13.5,5.3,22.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_115.setTransform(18.2,18.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],-22.5,-13.3,5.5,22.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_116.setTransform(18.2,18.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],-22.6,-13,5.6,22.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_117.setTransform(18.2,18.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],-22.7,-12.8,5.8,22.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_118.setTransform(18.2,18.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],-22.7,-12.6,6,22).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_119.setTransform(18.2,18.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],-22.8,-12.3,6.2,21.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_120.setTransform(18.2,18.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],-22.9,-12,6.3,21.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_121.setTransform(18.2,18.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],-23,-11.8,6.5,21.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_122.setTransform(18.2,18.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],-23.1,-11.6,6.6,21.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_123.setTransform(18.2,18.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],-23.1,-11.3,6.8,21.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_124.setTransform(18.2,18.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],-23.3,-11,6.9,21).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_125.setTransform(18.2,18.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],-23.3,-10.8,7.1,20.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_126.setTransform(18.2,18.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],-23.4,-10.6,7.3,20.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_127.setTransform(18.2,18.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],-23.5,-10.3,7.4,20.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_128.setTransform(18.2,18.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],-23.6,-10,7.6,20.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_129.setTransform(18.2,18.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],-23.7,-9.8,7.7,20.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_130.setTransform(18.2,18.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],-23.7,-9.6,7.9,19.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_131.setTransform(18.2,18.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],-23.8,-9.3,8.1,19.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_132.setTransform(18.2,18.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],-23.9,-9.1,8.2,19.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_133.setTransform(18.2,18.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],-24,-8.8,8.4,19.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_134.setTransform(18.2,18.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],-24.1,-8.6,8.5,19.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_135.setTransform(18.2,18.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],-24.1,-8.3,8.7,19.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_136.setTransform(18.2,18.2);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],-24.3,-8.1,8.8,18.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_137.setTransform(18.2,18.2);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],-24.3,-7.8,9,18.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_138.setTransform(18.2,18.2);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],-24.4,-7.6,9.2,18.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_139.setTransform(18.2,18.2);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],-24.5,-7.3,9.4,18.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_140.setTransform(18.2,18.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],-24.6,-7.1,9.5,18.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_141.setTransform(18.2,18.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],-24.7,-6.8,9.6,18).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_142.setTransform(18.2,18.2);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],-24.8,-6.6,9.8,17.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_143.setTransform(18.2,18.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],-24.8,-6.4,10,17.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_144.setTransform(18.2,18.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],-24.9,-6.1,10.1,17.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_145.setTransform(18.2,18.2);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],-25,-5.9,10.3,17.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_146.setTransform(18.2,18.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],-25.1,-5.6,10.5,17.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_147.setTransform(18.2,18.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],-25.2,-5.4,10.6,16.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_148.setTransform(18.2,18.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],-25.3,-5.1,10.7,16.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_149.setTransform(18.2,18.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],-25.4,-4.9,10.9,16.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_150.setTransform(18.2,18.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],-25.4,-4.6,11.1,16.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_151.setTransform(18.2,18.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],-25.5,-4.4,11.3,16.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_152.setTransform(18.2,18.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],-25.6,-4.1,11.4,16.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_153.setTransform(18.2,18.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],-25.7,-3.9,11.6,15.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_154.setTransform(18.2,18.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],-25.8,-3.6,11.7,15.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_155.setTransform(18.2,18.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],-25.8,-3.4,11.9,15.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_156.setTransform(18.2,18.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],-26,-3.1,12,15.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_157.setTransform(18.2,18.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],-26,-2.9,12.2,15.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_158.setTransform(18.2,18.2);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],-26.1,-2.7,12.4,15).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_159.setTransform(18.2,18.2);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],-26.2,-2.4,12.5,14.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_160.setTransform(18.2,18.2);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],-26.3,-2.1,12.7,14.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_161.setTransform(18.2,18.2);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],-26.4,-1.9,12.8,14.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_162.setTransform(18.2,18.2);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],-26.4,-1.7,13,14.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_163.setTransform(18.2,18.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],-26.5,-1.4,13.2,14.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_164.setTransform(18.2,18.2);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],-26.6,-1.1,13.3,14).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_165.setTransform(18.2,18.2);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],-26.7,-0.9,13.5,13.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_166.setTransform(18.2,18.2);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],-26.8,-0.7,13.6,13.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_167.setTransform(18.2,18.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],-26.9,-0.4,13.8,13.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_168.setTransform(18.2,18.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],-27,-0.2,13.9,13.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_169.setTransform(18.2,18.2);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],-27.1,0,14.1,13.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_170.setTransform(18.2,18.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],-27.1,0.2,14.3,12.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_171.setTransform(18.2,18.2);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],-27.2,0.5,14.5,12.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_172.setTransform(18.2,18.2);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],-27.3,0.7,14.6,12.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_173.setTransform(18.2,18.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],-27.4,1,14.8,12.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_174.setTransform(18.2,18.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],-27.5,1.2,14.9,12.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_175.setTransform(18.2,18.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],-27.5,1.5,15.1,12.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_176.setTransform(18.2,18.2);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],-27.7,1.7,15.2,11.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_177.setTransform(18.2,18.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],-27.7,2,15.4,11.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_178.setTransform(18.2,18.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],-27.8,2.2,15.6,11.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_179.setTransform(18.2,18.2);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],-27.9,2.4,15.7,11.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_180.setTransform(18.2,18.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],-28,2.7,15.9,11.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_181.setTransform(18.2,18.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],-28.1,3,16,11).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_182.setTransform(18.2,18.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],-28.1,3.2,16.2,10.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_183.setTransform(18.2,18.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],-28.2,3.4,16.4,10.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_184.setTransform(18.2,18.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],-28.3,3.7,16.5,10.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_185.setTransform(18.2,18.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],-28.4,4,16.7,10.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_186.setTransform(18.2,18.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],-28.5,4.2,16.8,10.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_187.setTransform(18.2,18.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],-28.5,4.4,17,9.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_188.setTransform(18.2,18.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],-28.7,4.7,17.1,9.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_189.setTransform(18.2,18.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],-28.7,5,17.3,9.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_190.setTransform(18.2,18.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],-28.8,5.2,17.5,9.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_191.setTransform(18.2,18.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],-28.9,5.4,17.7,9.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_192.setTransform(18.2,18.2);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],-29,5.7,17.8,9.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_193.setTransform(18.2,18.2);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],-29.1,5.9,17.9,8.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_194.setTransform(18.2,18.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],-29.2,6.2,18.1,8.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_195.setTransform(18.2,18.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],-29.2,6.4,18.3,8.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_196.setTransform(18.2,18.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],-29.3,6.7,18.4,8.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_197.setTransform(18.2,18.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],-29.4,6.9,18.6,8.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_198.setTransform(18.2,18.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],-29.5,7.2,18.8,8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_199.setTransform(18.2,18.2);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],-29.6,7.4,18.9,7.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_200.setTransform(18.2,18.2);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.lf(["#000000","#FFFFFF"],[0,0.592],-29.7,7.7,19,7.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_201.setTransform(18.2,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101}]}).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[]},1).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,0,45.7,45.6);


(lib.fnd_loader = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhKNAu4MAAAhdvMCUbAAAMAAABdvg");
	this.shape.setTransform(475,304.1,1,1.014);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608.1);


(lib.IMG_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("Egm4AiNMAAAhEZMBNxAAAMAAABEZg");
	this.shape.setTransform(239,239,1.614,0.909);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).wait(2));

	// Capa 1
	this.instance = new lib.shutterstock_48700159_OPT();
	this.instance.setTransform(-140.6,57.6,0.899,0.899);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140.6,57.6,764,367.6);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);


      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}