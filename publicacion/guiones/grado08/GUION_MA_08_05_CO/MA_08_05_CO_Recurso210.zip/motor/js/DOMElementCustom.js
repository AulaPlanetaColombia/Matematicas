/*
* DOMElement
* Visit http://createjs.com/ for documentation, updates and examples.
*
* Copyright (c) 2010 gskinner.com, inc.
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use,
* copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following
* conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
* OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
* HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
* OTHER DEALINGS IN THE SOFTWARE.
*/
 
/**
 * @module EaselJS
 */
 
// namespace:
this.createjs = this.createjs||{};
 
(function() {
	"use strict";
// TODO: fix problems with rotation.
// TODO: exclude from getObjectsUnderPoint
 
/**
 * <b>This class is still experimental, and more advanced use is likely to be buggy. Please report bugs.</b>
 *
 * A DOMElement allows you to associate a HTMLElement with the display list. It will be transformed
 * within the DOM as though it is child of the {{#crossLink "Container"}}{{/crossLink}} it is added to. However, it is
 * not rendered to canvas, and as such will retain whatever z-index it has relative to the canvas (ie. it will be
 * drawn in front of or behind the canvas).
 *
 * The position of a DOMElement is relative to their parent node in the DOM. It is recommended that
 * the DOM Object be added to a div that also contains the canvas so that they share the same position
 * on the page.
 *
 * DOMElement is useful for positioning HTML elements over top of canvas content, and for elements
 * that you want to display outside the bounds of the canvas. For example, a tooltip with rich HTML
 * content.
 *
 * <h4>Mouse Interaction</h4>
 *
 * DOMElement instances are not full EaselJS display objects, and do not participate in EaselJS mouse
 * events or support methods like hitTest. To get mouse events from a DOMElement, you must instead add handlers to
 * the htmlElement (note, this does not support EventDispatcher)
 *
 *      var domElement = new createjs.DOMElement(htmlElement);
 *      domElement.htmlElement.onclick = function() {
 *          console.log("clicked");
 *      }
 *
 * @class DOMElement
 * @extends DisplayObject
 * @constructor
 * @param {HTMLElement} htmlElement A reference or id for the DOM element to manage.
 */
var DOMElementCustom = function(htmlElement, parent) {
  this.parent = parent;
  this.initialize(htmlElement);
};
var p = DOMElementCustom.prototype = new createjs.DisplayObject();
 
 	p.parent = false;
 	p.grandParent = false;
 	
 	p.element_x = 0;
 	p.element_x = 0;
 	p.element_width = 0;
 	p.element_height = 0;
 	p.fontsize = 0;
// public properties:
	/**
	 * The DOM object to manage.
	 * @property htmlElement
	 * @type HTMLElement
	 */
	p.htmlElement = null;
 
// private properties:
	/**
	 * @property _oldMtx
	 * @type Matrix2D
	 * @protected
	 */
	p._oldMtx = null;
	
	/**
	 * @property _visible
	 * @type Boolean
	 * @protected
	 */
	p._visible = false;
 
// constructor:
	/**
	 * @property DisplayObject_initialize
	 * @type Function
	 * @private
	 */
	p.DisplayObject_initialize = p.initialize;
	/**
	 * Initialization method.
	 * @method initialize
	 * @param {HTMLElement} htmlElement A reference or id for the DOM element to manage.
	 * @protected
	*/
	p.initialize = function(htmlElement) {
		if (typeof(htmlElement)=="string") { htmlElement = document.getElementById(htmlElement); }
		this.DisplayObject_initialize();
		this.mouseEnabled = false;
		this.htmlElement = htmlElement;
		var style = htmlElement.style;
		// this relies on the _tick method because draw isn't called if a parent is not visible.
		style.position = "absolute";
		style.transformOrigin = style.WebkitTransformOrigin = style.msTransformOrigin = style.MozTransformOrigin = style.OTransformOrigin = "0% 0%";
	};
 
// public methods:
	/**
	 * Returns true or false indicating whether the display object would be visible if drawn to a canvas.
	 * This does not account for whether it would be visible within the boundaries of the stage.
	 * NOTE: This method is mainly for internal use, though it may be useful for advanced uses.
	 * @method isVisible
	 * @return {Boolean} Boolean indicating whether the display object would be visible if drawn to a canvas
	 */
	p.isVisible = function() {
		return this.htmlElement != null;
	};
 
	/**
	 * Draws the display object into the specified context ignoring its visible, alpha, shadow, and transform.
	 * Returns true if the draw was handled (useful for overriding functionality).
	 * NOTE: This method is mainly for internal use, though it may be useful for advanced uses.
	 * @method draw
	 * @param {CanvasRenderingContext2D} ctx The canvas 2D context object to draw into.
	 * @param {Boolean} ignoreCache Indicates whether the draw operation should ignore any current cache.
	 * For example, used for drawing the cache (to prevent it from simply drawing an existing cache back
	 * into itself).
	 * @return {Boolean}
	 */
	p.draw = function(ctx, ignoreCache) {
		// this relies on the _tick method because draw isn't called if a parent is not visible.
		if (this.visible) { this._visible = true; }
		// the actual update happens in _handleDrawEnd
		
		//console.log(this);
		
		return true;
	};
 
	/**
	 * Not applicable to DOMElement.
	 * @method cache
	 */
	p.cache = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method uncache
	 */
	p.uncache = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method updateCache
	 */
	p.updateCache = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method hitTest
	 */
	p.hitTest = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method localToGlobal
	 */
	p.localToGlobal = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method globalToLocal
	 */
	p.globalToLocal = function() {};
 
	/**
	 * Not applicable to DOMElement.
	 * @method localToLocal
	 */
	p.localToLocal = function() {};
 
	/**
	 * DOMElement cannot be cloned. Throws an error.
	 * @method clone
	 */
	p.clone = function() {
		throw("DOMElementCustom cannot be cloned.")
	};
 
	/**
	 * Returns a string representation of this object.
	 * @method toString
	 * @return {String} a string representation of the instance.
	 */
	p.toString = function() {
		return "[DOMElementCustom (name="+  this.name +")]";
	};
 
	/**
     * Interaction events should be added to `htmlElement`, and not the DOMElement instance, since DOMElement instances
	 * are not full EaselJS display objects and do not participate in EaselJS mouse events.
	 * @event click
	 */
 
     /**
     * Interaction events should be added to `htmlElement`, and not the DOMElement instance, since DOMElement instances
 	 * are not full EaselJS display objects and do not participate in EaselJS mouse events.
	 * @event dblClick
	 */
 
     /**
      * Interaction events should be added to `htmlElement`, and not the DOMElement instance, since DOMElement instances
 	  * are not full EaselJS display objects and do not participate in EaselJS mouse events.
	  * @event mousedown
	  */
 
     /**
      * The HTMLElement can listen for the mouseover event, not the DOMElement instance.
      * Since DOMElement instances are not full EaselJS display objects and do not participate in EaselJS mouse events.
      * @event mouseover
	  */
 
     /**
      * Not applicable to DOMElement.
	  * @event tick
	  */
 
 
// private methods:
	/**
	 * @property DisplayObject__tick
	 * @type Function
	 * @protected
	 */
	p.DisplayObject__tick = p._tick;
 
	/**
	 * @method _tick
	 * @param {Array} params Parameters to pass onto the DisplayObject {{#crossLink "DisplayObject/tick"}}{{/crossLink}}
	 * function.
	 * @protected
	 */
	p._tick = function(params) {
		var stage = this.getStage();
		this._visible = false;
		stage&&stage.on("drawstart", this._reSizePosition, this, true);
		stage&&stage.on("drawend", this._handleDrawEnd, this, true);
		this.DisplayObject__tick(params);
		
		
	};
	
	/**
	 * @method _handleDrawEnd
	 * @param {Event} evt
	 * @protected
	 */
	p._handleDrawEnd = function(evt) {
		var o = this.htmlElement;
		if (!o) { return; }
		var style = o.style;
		
		var visibility = this._visible ? "visible" : "hidden";
		if (visibility != style.visibility) { style.visibility = visibility; }
		if (!this._visible) { return; }
		
		
		
		var mtx = this.getConcatenatedMatrix(this._matrix);
		var oMtx = this._oldMtx;
		var n = 10000; // precision
		if (!oMtx || oMtx.alpha != mtx.alpha) {
			style.opacity = ""+(mtx.alpha*n|0)/n;
			if (oMtx) { oMtx.alpha = mtx.alpha; }
		}
		if (!oMtx || oMtx.tx != mtx.tx || oMtx.ty != mtx.ty || oMtx.a != mtx.a || oMtx.b != mtx.b || oMtx.c != mtx.c || oMtx.d != mtx.d) {
			var str = "matrix(" + (mtx.a*n|0)/n +","+ (mtx.b*n|0)/n +","+ (mtx.c*n|0)/n +","+ (mtx.d*n|0)/n +","+ (mtx.tx+0.5|0);
			style.transform = style.WebkitTransform = style.OTransform = style.msTransform = str +","+ (mtx.ty+0.5|0) +")";
			style.MozTransform = str +"px,"+ (mtx.ty+0.5|0) +"px)";
			this._oldMtx = oMtx ? oMtx.copy(mtx) : mtx.clone();
		}
		
	};
	
	p._reSizePosition = function(){
		
		var canvas = $("#stage");
    	var height = canvas.attr('height');
    	var width = canvas.attr('width');

		//recuperem alçada total de la finestra
    	var lineH = $("#wrapper").css( 'line-height').substring(0, canvas.css('line-height').lastIndexOf('px') );

    	var relacio = 0;
    	if(lineH > height && this.htmlElement.id != "calculator")
    	{
    		//lineH - height = alçada en blanc
    		//(lineH-height) / 2 = posicio en y del canvas
    		relacio= ( (lineH-height) / 2 )/ Main.scale;
    	}
		
		//coloquem el DomElement dins el canvas
		if(this.grandParent){
			//console.log(this.grandParent.x );
			this.x = (this.grandParent.x + this.parent.x + this.element_x / Main.scale ) * Main.scale- this.parent.x*Main.scale - this.grandParent.x*Main.scale;
		   	this.y = (this.grandParent.y + this.parent.y + this.element_y / Main.scale ) * Main.scale+ relacio - this.parent.y*Main.scale - this.grandParent.y*Main.scale;
		}else
		{
	    	this.x = (this.parent.x + this.element_x/ Main.scale ) * Main.scale - this.parent.x*Main.scale;
		   	this.y = (this.parent.y +  this.element_y/ Main.scale) * Main.scale + relacio - this.parent.y*Main.scale;
	   	}
	    // redimensionem el domelement
	    $(this.htmlElement).css("height", this.element_height/ Main.scale * height/ Main.stage_height ); 
	    $(this.htmlElement).css("width", this.element_width/ Main.scale * width/ Main.stage_width );

		if(this.htmlElement.id != "calculator"){
		   	if( window.innerHeight> 1000 )	$(this.htmlElement).css("top",(window.innerHeight - height)/2)
	    	else	$(this.htmlElement).css("top",0);
	    }
				    
		$(this.htmlElement).css("font-size", Math.round(this.fontsize / Main.scale * width/ Main.stage_width) );
	}
 
createjs.DOMElementCustom = DOMElementCustom;
}());