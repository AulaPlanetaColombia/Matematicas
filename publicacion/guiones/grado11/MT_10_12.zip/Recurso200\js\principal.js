(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

        this.btn1 = new lib.IMG_01();
        this.btn1.setTransform(480, 320.3, 1, 1, 0, 0, 0, 250, 250);
        new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.IMG_01(), 3);

        this.btn1.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.btn1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['txt_11'], "19px");
        this.instance_1 = new lib.Diagrama_01MC();
        this.instance_1.setTransform(375, 339, 1, 1, 0, 0, 0, 215.1, 141.7);


        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['txt_12'], "19px");
        this.instance_1 = new lib.Diagrama_02MC();
        this.instance_1.setTransform(374, 339, 1, 1, 0, 0, 0, 215.1, 141.7);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['txt_13'], "19px");

        this.instance_1 = new lib.Diagrama_03MC();
        this.instance_1.setTransform(375, 339, 1, 1, 0, 0, 0, 215.1, 141.7);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['txt_14'], "19px");
        this.instance_1 = new lib.Diagrama_04MC();
        this.instance_1.setTransform(374, 339, 1, 1, 0, 0, 0, 215.1, 141.7);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.siguiente, this.home, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['txt_15'], "19px");
        this.grafico = new lib.diagrama_05MC();
        this.grafico.setTransform(309.9, 283.4, 1, 1, 0, 0, 0, 199.5, 38.5);

        this.practica = new lib.btn_practica(txt['txt_boto_actividad2']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
            putStage(new lib.frame10());
        });

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.informacion, this.home, this.anterior, this.grafico, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        titulo2(this, txt['txt_info_01'], "19px");
        this.instance_1 = new lib.diagrama_07MC();
        this.instance_1.setTransform(417.9, 339, 1, 1, 0, 0, 0, 273.4, 155.9);


        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.cerrar, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 0, 1);
        titulo2(this, txt['txt_info_02'], "19px");
        this.instance_1 = new lib.diagrama_08MC();
        this.instance_1.setTransform(516.3, 345.6, 0.885, 0.885, 0, 0, 0, 31.7, 147.7);


        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });


        this.addChild(this.logo, this.titulo, this.siguiente, this.cerrar, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        titulo2(this, txt['txt_info_03'], "19px");
        this.instance_1 = new lib.diagrama_09MC();
        this.instance_1.setTransform(459, 349.4, 1, 1, 0, 0, 0, 118.6, 115.9);


        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });



        this.addChild(this.logo, this.titulo, this.siguiente, this.cerrar, this.anterior, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_practica']);
        	this.instance_1 = new lib.shutterstock_13616383_OPT();
	this.instance_1.setTransform(47.8,151.8);


        this.practica = new lib.btn_practica(txt['txt_boto_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
            putStage(new lib.frame11());
        });

       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.titulo, this.informacion, this.cerrar, this.anterior, this.instance_1, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame11 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        texto(this, txt['txt_solucion'],0,-30);
        		this.instance_1 = new lib.diagrama_06MC();
	this.instance_1.setTransform(471.9,451.5,1,1,0,0,0,212.5,14.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });

       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame6());
        });

        this.addChild(this.logo, this.texto, this.cerrar, this.home, this.anterior, this.instance_1, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '800px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
     function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    //Simbolillos

    (lib.Mapadebits5 = function () {
        this.initialize(img.Mapadebits5);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 350, 231);


    (lib.Mapadebits6 = function () {
        this.initialize(img.Mapadebits6);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 565, 322);


    (lib.Mapadebits7 = function () {
        this.initialize(img.Mapadebits7);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 565, 322);


    (lib.Mapadebits8 = function () {
        this.initialize(img.Mapadebits8);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 404, 395);



    (lib.shutterstock_13616383_OPT = function () {
        this.initialize(img.shutterstock_13616383_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 850, 376);


    (lib.parpadeo4 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AiuBzIAAjlIFcAAIAADlg");
        this.shape.setTransform(119.1, 13.1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 4).wait(4));

        // Capa 1
        this.text = new cjs.Text("0,25 · 0,4 = 0,1", "16px Verdana", "#009900");
        this.text.lineHeight = 16;
        this.text.lineWidth = 141;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text}]}).wait(8));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 145, 23.5);


    (lib.parpadeo3 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AiKB4IAAjuIEWAAIAADug");
        this.shape.setTransform(119.6, 10.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 4).wait(4));

        // Capa 1
        this.text = new cjs.Text("0,25 · 0,4 = 0,1", "16px Verdana", "#0066CC");
        this.text.lineHeight = 16;
        this.text.lineWidth = 147;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text}]}).wait(8));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 151, 23.5);


    (lib.parpadeo2 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AirByIAAjjIFXAAIAADjg");
        this.shape.setTransform(111.8, 12);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 4).wait(4));

        // Capa 1
        this.text = new cjs.Text("0,5 · 0,4 = 0,2", "16px Verdana", "#CC0000");
        this.text.lineHeight = 16;
        this.text.lineWidth = 125;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text}]}).wait(8));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 129, 23.5);


    (lib.parpadeo1 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ai9CQIAAkfIF6AAIAAEfg");
        this.shape.setTransform(110.6, 13.1);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 4).wait(4));

        // Capa 1
        this.text = new cjs.Text("0,5 · 0,6 = 0,3", "16px Verdana", "#CC0000");
        this.text.lineHeight = 16;
        this.text.lineWidth = 125;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text}]}).wait(8));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 129, 23.5);


    (lib.diagrama_09MC = function () {
        this.initialize();

        // Capa 2
        this.text = new cjs.Text("B", "bold 16px Verdana");
        this.text.textAlign = "right";
        this.text.lineHeight = 16;
        this.text.setTransform(225.8, 73 + incremento + 2);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape.setTransform(166.4, 221.8);

        this.text_1 = new cjs.Text("1\n2", "14px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 18;
        this.text_1.lineWidth = 12;
        this.text_1.setTransform(165.4, 202.3 + incremento/2 + 2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_1.setTransform(166.4, 162.8);

        this.text_2 = new cjs.Text("1\n2", "14px Verdana");
        this.text_2.textAlign = "center";
        this.text_2.lineHeight = 18;
        this.text_2.lineWidth = 12;
        this.text_2.setTransform(166.4, 143.3 + incremento/2 + 2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_2.setTransform(191.9, 119.3);

        this.text_3 = new cjs.Text("1\n2", "14px Verdana");
        this.text_3.textAlign = "center";
        this.text_3.lineHeight = 18;
        this.text_3.lineWidth = 12;
        this.text_3.setTransform(192.9, 99 + incremento/2 + 2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_3.setTransform(162.4, 87.3);

        this.text_4 = new cjs.Text("1\n2", "14px Verdana");
        this.text_4.textAlign = "center";
        this.text_4.lineHeight = 18;
        this.text_4.lineWidth = 12;
        this.text_4.setTransform(163.4, 67.8 + incremento/2 + 2);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_4.setTransform(117.4, 140.8);

        this.text_5 = new cjs.Text("1\n3", "14px Verdana");
        this.text_5.textAlign = "center";
        this.text_5.lineHeight = 18;
        this.text_5.lineWidth = 12;
        this.text_5.setTransform(118.4, 121.3 + incremento/2 + 2);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_5.setTransform(79.4, 187.3);

        this.text_6 = new cjs.Text("1\n3", "14px Verdana");
        this.text_6.textAlign = "center";
        this.text_6.lineHeight = 18;
        this.text_6.lineWidth = 12;
        this.text_6.setTransform(78.4, 167.8 + incremento/2 + 2);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_6.setTransform(79.4, 67.3);

        this.text_7 = new cjs.Text("1\n3", "14px Verdana");
        this.text_7.textAlign = "center";
        this.text_7.lineHeight = 18;
        this.text_7.lineWidth = 12;
        this.text_7.setTransform(78.4, 47.8 + incremento/2 + 2);

        this.text_8 = new cjs.Text("B", "bold 16px Verdana");
        this.text_8.textAlign = "right";
        this.text_8.lineHeight = 16;
        this.text_8.setTransform(225.8, 206.5 + incremento + 2);

        this.text_9 = new cjs.Text("A", "bold 16px Verdana");
        this.text_9.textAlign = "right";
        this.text_9.lineHeight = 16;
        this.text_9.setTransform(225.8, 146.5 + incremento + 2);

        this.text_10 = new cjs.Text("A", "bold 16px Verdana");
        this.text_10.textAlign = "right";
        this.text_10.lineHeight = 16;
        this.text_10.setTransform(225.8, 128.5 + incremento + 2);

        this.text_11 = new cjs.Text("B", "bold 16px Verdana");
        this.text_11.textAlign = "right";
        this.text_11.lineHeight = 16;
        this.text_11.setTransform(225.8, 3 + incremento + 2);

        this.salida = new cjs.Text("Salida", "16px Verdana");
        this.salida.textAlign = "right";
        this.salida.lineHeight = 16;
        this.salida.lineWidth = 100;
        this.salida.setTransform(39.4, 107.2 + incremento + 2);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#009900").ss(2, 1, 1).p("AsAnLIQHLWIH6lTAEHELIH6DB");
        this.shape_7.setTransform(128.8, 167.9);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#003399").ss(2, 1, 1).p("ADlBSIIcDOADLBSIvLAAALykfIonFx");
        this.shape_8.setTransform(128.8, 113.6);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#CC0000").ss(2, 1, 1).p("AsAICIYBwD");
        this.shape_9.setTransform(128.8, 70.4);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(2, 1, 1).p("AgLAAIAXAA");
        this.shape_10.setTransform(150.4, 121.9);



        this.addChild(this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.salida, this.text_11, this.text_10, this.text_9, this.text_8, this.text_7, this.shape_6, this.text_6, this.shape_5, this.text_5, this.shape_4, this.text_4, this.shape_3, this.text_3, this.shape_2, this.text_2, this.shape_1, this.text_1, this.shape, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-60.5, 0, 297.9, 240.4);


    (lib.diagrama_07MC = function () {
        this.initialize();

        // Capa 4
        this.shape = new cjs.Shape();
      //  this.shape.graphics.f("#000000").s().p("AAdA7IAAhEIgBgQQgCgFgDgFQgEgEgGgDQgFgDgIABQgHgBgFADQgGADgEAEQgDAFgCAGIgBAOIAABFIgPAAIAAhEQAAgMADgKQACgKAHgFQAGgHAHgCQAJgDAJAAQAKAAAJADQAHADAGAGQAGAGADAJQADAJAAANIAABEg");
        this.shape.setTransform(490, 288.9);

        this.text = new cjs.Text("p (I ∩ N) =", "16px Verdana");
        this.text.lineHeight = 20;
        this.text.setTransform(449, 275.9 +incremento +2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_1.setTransform(639, 288.4);

        this.text_1 = new cjs.Text("1\n6", "16px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 20;
        this.text_1.lineWidth = 22;
        this.text_1.setTransform(636+2, 266.9 +incremento/2 +2);

        this.text_2 = new cjs.Text("=", "16px Verdana");
        this.text_2.lineHeight = 20;
        this.text_2.setTransform(605, 276.9+incremento);

        this.text_3 = new cjs.Text("·", "16px Verdana");
        this.text_3.lineHeight = 20;
        this.text_3.setTransform(565, 276.9 +incremento/2 +2);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_2.setTransform(589, 288.4);

        this.text_4 = new cjs.Text("1\n3", "16px Verdana");
        this.text_4.lineHeight = 20;
        this.text_4.lineWidth = 12;
        this.text_4.setTransform(581+2, 266.9 +incremento/2 +2);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_3.setTransform(551, 288.4);

        this.text_5 = new cjs.Text("1\n2", "16px Verdana");
        this.text_5.lineHeight = 20;
        this.text_5.lineWidth = 12;
        this.text_5.setTransform(543+2, 266.9 +incremento/2 +2);

        this.shape_4 = new cjs.Shape();
    //    this.shape_4.graphics.f("#000000").s().p("AAdA7IAAhFIgBgOQgCgGgDgFQgEgFgGgCQgFgDgIAAQgHAAgFADQgGACgEAFQgDAFgCAGIgBAOIAABFIgPAAIAAhEQAAgMADgKQACgJAHgHQAGgFAHgDQAJgDAJAAQAKAAAJADQAHADAGAFQAGAHADAJQADAJAAANIAABEg");
        this.shape_4.setTransform(490, 193.9);

        this.text_6 = new cjs.Text("p (I ∩ R) =", "16px Verdana");
        this.text_6.lineHeight = 20;
        this.text_6.setTransform(449, 180.9 +incremento +2);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_5.setTransform(639, 193.4);

        this.text_7 = new cjs.Text("1\n3", "16px Verdana");
        this.text_7.textAlign = "center";
        this.text_7.lineHeight = 20;
        this.text_7.lineWidth = 22;
        this.text_7.setTransform(636+2, 171.9 +incremento/2 +2);

        this.text_8 = new cjs.Text("=", "16px Verdana");
        this.text_8.lineHeight = 20;
        this.text_8.setTransform(605, 181.9 +incremento/2 +2);

        this.text_9 = new cjs.Text("·", "16px Verdana");
        this.text_9.lineHeight = 20;
        this.text_9.setTransform(565, 182.9);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_6.setTransform(589, 193.4);

        this.text_10 = new cjs.Text("2\n3", "16px Verdana");
        this.text_10.lineHeight = 20;
        this.text_10.lineWidth = 12;
        this.text_10.setTransform(581+2, 171.9 +incremento/2 +2);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_7.setTransform(551, 193.4);

        this.text_11 = new cjs.Text("1\n2", "16px Verdana");
        this.text_11.lineHeight = 20;
        this.text_11.lineWidth = 12;
        this.text_11.setTransform(543+2, 171.9 +incremento/2 +2);

        this.shape_8 = new cjs.Shape();
      //  this.shape_8.graphics.f("#FF0000").s().p("AAdA7IAAhFIgBgOQgCgGgDgEQgEgGgGgCQgFgDgIAAQgHAAgFADQgGACgEAGQgDAEgCAGIgBAOIAABFIgPAAIAAhEQAAgNADgJQACgJAHgHQAGgFAHgDQAJgDAJAAQAKAAAJADQAHADAGAFQAGAHADAJQADAJAAANIAABEg");
        this.shape_8.setTransform(490, 131.9);

        this.text_12 = new cjs.Text("p (I ∩ V) =", "16px Verdana");
        this.text_12.lineHeight = 20;
        this.text_12.setTransform(449, 118.9 +incremento +2);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#00FF00").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_9.setTransform(639, 131.4);

        this.text_13 = new cjs.Text("1\n5", "16px Verdana");
        this.text_13.textAlign = "center";
        this.text_13.lineHeight = 20;
        this.text_13.lineWidth = 22;
        this.text_13.setTransform(636+2, 109.9 +incremento/2 +2);

        this.text_14 = new cjs.Text("=", "16px Verdana");
        this.text_14.lineHeight = 20;
        this.text_14.setTransform(605, 119.9 +incremento/2 +2);

        this.text_15 = new cjs.Text("·", "16px Verdana");
        this.text_15.lineHeight = 20;
        this.text_15.setTransform(565, 119.9 +incremento/2 +2);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_10.setTransform(589, 131.4);

        this.text_16 = new cjs.Text("2\n5", "16px Verdana");
        this.text_16.lineHeight = 20;
        this.text_16.lineWidth = 12;
        this.text_16.setTransform(581+2, 109.9 +incremento/2 +2);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_11.setTransform(551, 131.4);

        this.text_17 = new cjs.Text("1\n2", "16px Verdana");
        this.text_17.lineHeight = 20;
        this.text_17.lineWidth = 12;
        this.text_17.setTransform(543+2, 109.9 +incremento/2 +2);

        this.shape_12 = new cjs.Shape();
     //   this.shape_12.graphics.f("#000000").s().p("AAdA7IAAhEIgBgQQgCgFgDgFQgEgEgGgDQgFgCgIgBQgHABgFACQgGADgEAEQgDAFgCAGIgBAOIAABFIgPAAIAAhEQAAgMADgKQACgKAHgFQAGgGAHgDQAJgDAJAAQAKAAAJADQAHADAGAGQAGAGADAJQADAJAAANIAABEg");
        this.shape_12.setTransform(490, 28.9);

        this.text_18 = new cjs.Text("p (I ∩ R) =", "16px Verdana");
        this.text_18.lineHeight = 20;
        this.text_18.setTransform(449, 15.9 +incremento +2);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#FF9900").s().p("AgsgrIBZArIhZAsg");
        this.shape_13.setTransform(418.9, 289.2);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#FF9900").s().p("AgsgrIBZArIhZAsg");
        this.shape_14.setTransform(418.9, 193.2);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#FF9900").s().p("AgsgrIBZArIhZAsg");
        this.shape_15.setTransform(418.9, 131.2);

        this.text_19 = new cjs.Text("N", "16px Verdana", "#FFFFFF");
        this.text_19.lineHeight = 20;
        this.text_19.setTransform(289, 275.9 +incremento/2 +2);

        this.text_20 = new cjs.Text("R", "16px Verdana");
        this.text_20.lineHeight = 20;
        this.text_20.setTransform(289, 178.9 +incremento/2 +2);

        this.text_21 = new cjs.Text("V", "16px Verdana");
        this.text_21.lineHeight = 20;
        this.text_21.setTransform(289, 120.9 +incremento/2 +2);

        this.text_22 = new cjs.Text("R", "16px Verdana");
        this.text_22.lineHeight = 20;
        this.text_22.setTransform(290, 17.9 +incremento/2 +2);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#FF9900").ss(2, 1, 1).p("AmF0YIMLAAAmFkSIMLAAAmFFZIMLAAAmFUZIMLAA");
        this.shape_16.setTransform(376, 158.5);

        // Capa 3
        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#000000").s().p("AivCwQhKhJABhnQgBhmBKhJQBJhKBmABQBngBBJBKQBJBJAABmQAABnhJBJQhJBKhngBQhmABhJhKg");
        this.shape_17.setTransform(297, 287);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#66CC00").s().p("AivCwQhKhJABhnQgBhmBKhJQBJhKBmAAQBnAABJBKQBJBJAABmQAABnhJBJQhJBKhngBQhmABhJhKg");
        this.shape_18.setTransform(297, 133);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#CC0000").s().p("AivPQQhKhJABhnQgBhoBKhJQBJhJBmAAQBnAABJBJQBJBJAABoQAABnhJBJQhJBJhnAAQhmAAhJhJgAivpuQhKhJABhnQgBhoBKhKQBJhIBmgBQBnABBJBIQBJBKAABoQAABnhJBJQhJBJhnABQhmgBhJhJg");
        this.shape_19.setTransform(297, 111);

        // Capa 2
        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_20.setTransform(639, 28.4);

        this.text_23 = new cjs.Text("3\n10", "16px Verdana");
        this.text_23.textAlign = "center";
        this.text_23.lineHeight = 20;
        this.text_23.lineWidth = 22;
        this.text_23.setTransform(636+2, 6.9 +incremento/2 +2);

        this.text_24 = new cjs.Text("=", "16px Verdana");
        this.text_24.lineHeight = 20;
        this.text_24.setTransform(605, 16.9 +incremento/2 +2);

        this.text_25 = new cjs.Text("·", "16px Verdana");
        this.text_25.lineHeight = 20;
        this.text_25.setTransform(565, 16.9 +incremento/2 +2);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_21.setTransform(589, 28.4);

        this.text_26 = new cjs.Text("3\n5", "16px Verdana");
        this.text_26.lineHeight = 20;
        this.text_26.lineWidth = 12;
        this.text_26.setTransform(581+2, 6.9 +incremento/2 +2);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_22.setTransform(551, 28.4);

        this.text_27 = new cjs.Text("1\n2", "16px Verdana");
        this.text_27.lineHeight = 20;
        this.text_27.lineWidth = 12;
        this.text_27.setTransform(543+2, 6.9 +incremento/2 +2);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#FF9900").s().p("AgsgrIBZArIhZAsg");
        this.shape_23.setTransform(418.9, 28.2);

        this.text_28 = new cjs.Text("I", "16px Verdana");
        this.text_28.lineHeight = 20;
        this.text_28.setTransform(133, 91.9 +incremento/2 +2);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_24.setTransform(211, 281.4);

        this.text_29 = new cjs.Text("1\n3", "16px Verdana");
        this.text_29.lineHeight = 20;
        this.text_29.lineWidth = 12;
        this.text_29.setTransform(203+2, 259.9 +incremento/2 +2);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_25.setTransform(211, 181.4);

        this.text_30 = new cjs.Text("2\n3", "16px Verdana");
        this.text_30.lineHeight = 20;
        this.text_30.lineWidth = 12;
        this.text_30.setTransform(203+2, 159.9 +incremento/2 +2);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_26.setTransform(211, 131.4);

        this.text_31 = new cjs.Text("2\n5", "16px Verdana");
        this.text_31.lineHeight = 20;
        this.text_31.lineWidth = 12;
        this.text_31.setTransform(203+2, 109.9 +incremento/2 +2);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_27.setTransform(211, 28.4);

        this.text_32 = new cjs.Text("3\n5", "16px Verdana");
        this.text_32.lineHeight = 20;
        this.text_32.lineWidth = 12;
        this.text_32.setTransform(203+2, 6.9 +incremento/2 +2);

        this.text_33 = new cjs.Text("D", "16px Verdana");
        this.text_33.lineHeight = 20;
        this.text_33.setTransform(133, 201.9 +incremento/2 +2);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_28.setTransform(53, 217.4);

        this.text_34 = new cjs.Text("1\n2", "16px Verdana");
        this.text_34.lineHeight = 20;
        this.text_34.lineWidth = 12;
        this.text_34.setTransform(45+2, 195.9 +incremento/2 +2);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f().s("#000000").ss(1, 1, 1).p("AhPAAICfAA");
        this.shape_29.setTransform(53, 107.4);

        this.text_35 = new cjs.Text("1\n2", "16px Verdana");
        this.text_35.lineHeight = 20;
        this.text_35.lineWidth = 12;
        this.text_35.setTransform(45+2, 85.9 +incremento/2 +2);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f().s("#FF9900").ss(2, 1, 1).p("ASckIIs0nZIM+nwAlwHbIs1naIM/nuAScTTIs0naIM+nw");
        this.shape_30.setTransform(142, 158.5);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f().s("#993366").ss(1, 1, 1).p("ADqlDInTAAIAAnCIHTAAgAjpMHIAAnCIHTAAIAAHCg");
        this.shape_31.setTransform(140.5, 158.5);



        this.addChild(this.shape_31, this.shape_30, this.text_35, this.shape_29, this.text_34, this.shape_28, this.text_33, this.text_32, this.shape_27, this.text_31, this.shape_26, this.text_30, this.shape_25, this.text_29, this.shape_24, this.text_28, this.shape_23, this.text_27, this.shape_22, this.text_26, this.shape_21, this.text_25, this.text_24, this.text_23, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.text_22, this.text_21, this.text_20, this.text_19, this.shape_15, this.shape_14, this.shape_13, this.text_18, this.shape_12, this.text_17, this.shape_11, this.text_16, this.shape_10, this.text_15, this.text_14, this.text_13, this.shape_9, this.text_12, this.shape_8, this.text_11, this.shape_7, this.text_10, this.shape_6, this.text_9, this.text_8, this.text_7, this.shape_5, this.text_6, this.shape_4, this.text_5, this.shape_3, this.text_4, this.shape_2, this.text_3, this.text_2, this.text_1, this.shape_1, this.text, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(20, 0, 631, 312);


    (lib.diagrama_06MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_9 = new cjs.Graphics().p("AjGD1IAAnpIGNAAIAAHpg");
        var mask_graphics_10 = new cjs.Graphics().p("AjbD1IAAnpIG3AAIAAHpg");
        var mask_graphics_11 = new cjs.Graphics().p("AjwD1IAAnpIHhAAIAAHpg");
        var mask_graphics_12 = new cjs.Graphics().p("AkFD1IAAnpIILAAIAAHpg");
        var mask_graphics_13 = new cjs.Graphics().p("AkaD1IAAnpII1AAIAAHpg");
        var mask_graphics_14 = new cjs.Graphics().p("AkvD1IAAnpIJfAAIAAHpg");
        var mask_graphics_15 = new cjs.Graphics().p("AlED1IAAnpIKJAAIAAHpg");
        var mask_graphics_16 = new cjs.Graphics().p("AlZD1IAAnpIKzAAIAAHpg");
        var mask_graphics_17 = new cjs.Graphics().p("AluD1IAAnpILdAAIAAHpg");
        var mask_graphics_18 = new cjs.Graphics().p("AmDD1IAAnpIMHAAIAAHpg");
        var mask_graphics_19 = new cjs.Graphics().p("Aj9D1IAAnpIMxAAIAAHpg");
        var mask_graphics_29 = new cjs.Graphics().p("Aj9D1IAAnpIMxAAIAAHpg");
        var mask_graphics_30 = new cjs.Graphics().p("AnBD1IAAnpIODAAIAAHpg");
        var mask_graphics_31 = new cjs.Graphics().p("AnpD1IAAnpIPTAAIAAHpg");
        var mask_graphics_32 = new cjs.Graphics().p("AoSD1IAAnpIQlAAIAAHpg");
        var mask_graphics_33 = new cjs.Graphics().p("Ao6D1IAAnpIR1AAIAAHpg");
        var mask_graphics_34 = new cjs.Graphics().p("ApiD1IAAnpITFAAIAAHpg");
        var mask_graphics_35 = new cjs.Graphics().p("AqLD1IAAnpIUXAAIAAHpg");
        var mask_graphics_36 = new cjs.Graphics().p("AqzD1IAAnpIVnAAIAAHpg");
        var mask_graphics_37 = new cjs.Graphics().p("ArcD1IAAnpIW5AAIAAHpg");
        var mask_graphics_38 = new cjs.Graphics().p("AsED1IAAnpIYJAAIAAHpg");
        var mask_graphics_39 = new cjs.Graphics().p("AstD1IAAnpIZbAAIAAHpg");
        var mask_graphics_40 = new cjs.Graphics().p("Aq6D1IAAnpIarAAIAAHpg");
        var mask_graphics_50 = new cjs.Graphics().p("Aq6D1IAAnpIarAAIAAHpg");
        var mask_graphics_51 = new cjs.Graphics().p("At0D1IAAnpIbqAAIAAHpg");
        var mask_graphics_52 = new cjs.Graphics().p("AuUD1IAAnpIcpAAIAAHpg");
        var mask_graphics_53 = new cjs.Graphics().p("AuzD1IAAnpIdoAAIAAHpg");
        var mask_graphics_54 = new cjs.Graphics().p("AvTD1IAAnpIenAAIAAHpg");
        var mask_graphics_55 = new cjs.Graphics().p("AvyD1IAAnpIfmAAIAAHpg");
        var mask_graphics_56 = new cjs.Graphics().p("AwSD1IAAnpMAglAAAIAAHpg");
        var mask_graphics_57 = new cjs.Graphics().p("AwxD1IAAnpMAhjAAAIAAHpg");
        var mask_graphics_58 = new cjs.Graphics().p("AxRD1IAAnpMAijAAAIAAHpg");
        var mask_graphics_59 = new cjs.Graphics().p("AxwD1IAAnpMAjhAAAIAAHpg");
        var mask_graphics_60 = new cjs.Graphics().p("AyQD1IAAnpMAkhAAAIAAHpg");
        var mask_graphics_61 = new cjs.Graphics().p("AywD1IAAnpMAlgAAAIAAHpg");
        var mask_graphics_62 = new cjs.Graphics().p("AzPD1IAAnpMAmfAAAIAAHpg");
        var mask_graphics_63 = new cjs.Graphics().p("AxUD1IAAnpMAneAAAIAAHpg");
        var mask_graphics_75 = new cjs.Graphics().p("AxUD1IAAnpMAneAAAIAAHpg");
        var mask_graphics_76 = new cjs.Graphics().p("A0KD1IAAnpMAoVAAAIAAHpg");
        var mask_graphics_77 = new cjs.Graphics().p("A0mD1IAAnpMApNAAAIAAHpg");
        var mask_graphics_78 = new cjs.Graphics().p("A1CD1IAAnpMAqFAAAIAAHpg");
        var mask_graphics_79 = new cjs.Graphics().p("A1eD1IAAnpMAq9AAAIAAHpg");
        var mask_graphics_80 = new cjs.Graphics().p("A16D1IAAnpMAr1AAAIAAHpg");
        var mask_graphics_81 = new cjs.Graphics().p("A2WD1IAAnpMAstAAAIAAHpg");
        var mask_graphics_82 = new cjs.Graphics().p("A2yD1IAAnpMAtlAAAIAAHpg");
        var mask_graphics_83 = new cjs.Graphics().p("A3OD1IAAnpMAudAAAIAAHpg");
        var mask_graphics_84 = new cjs.Graphics().p("A3qD1IAAnpMAvVAAAIAAHpg");
        var mask_graphics_85 = new cjs.Graphics().p("A4GD1IAAnpMAwNAAAIAAHpg");
        var mask_graphics_86 = new cjs.Graphics().p("A4iD1IAAnpMAxFAAAIAAHpg");
        var mask_graphics_87 = new cjs.Graphics().p("A4+D1IAAnpMAx9AAAIAAHpg");
        var mask_graphics_88 = new cjs.Graphics().p("A3AD1IAAnpMAy1AAAIAAHpg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: null, x: 0, y: 0}).wait(9).to({graphics: mask_graphics_9, x: 51, y: 12.7}).wait(1).to({graphics: mask_graphics_10, x: 53.1, y: 12.7}).wait(1).to({graphics: mask_graphics_11, x: 55.2, y: 12.7}).wait(1).to({graphics: mask_graphics_12, x: 57.3, y: 12.7}).wait(1).to({graphics: mask_graphics_13, x: 59.4, y: 12.7}).wait(1).to({graphics: mask_graphics_14, x: 61.5, y: 12.7}).wait(1).to({graphics: mask_graphics_15, x: 63.6, y: 12.7}).wait(1).to({graphics: mask_graphics_16, x: 65.7, y: 12.7}).wait(1).to({graphics: mask_graphics_17, x: 67.8, y: 12.7}).wait(1).to({graphics: mask_graphics_18, x: 69.9, y: 12.7}).wait(1).to({graphics: mask_graphics_19, x: 56.5, y: 12.7}).wait(10).to({graphics: mask_graphics_29, x: 56.5, y: 12.7}).wait(1).to({graphics: mask_graphics_30, x: 76.1, y: 12.7}).wait(1).to({graphics: mask_graphics_31, x: 80.1, y: 12.7}).wait(1).to({graphics: mask_graphics_32, x: 84.1, y: 12.7}).wait(1).to({graphics: mask_graphics_33, x: 88.2, y: 12.7}).wait(1).to({graphics: mask_graphics_34, x: 92.2, y: 12.7}).wait(1).to({graphics: mask_graphics_35, x: 96.3, y: 12.7}).wait(1).to({graphics: mask_graphics_36, x: 100.3, y: 12.7}).wait(1).to({graphics: mask_graphics_37, x: 104.3, y: 12.7}).wait(1).to({graphics: mask_graphics_38, x: 108.4, y: 12.7}).wait(1).to({graphics: mask_graphics_39, x: 112.4, y: 12.7}).wait(1).to({graphics: mask_graphics_40, x: 100.9, y: 12.7}).wait(10).to({graphics: mask_graphics_50, x: 100.9, y: 12.7}).wait(1).to({graphics: mask_graphics_51, x: 119.6, y: 12.7}).wait(1).to({graphics: mask_graphics_52, x: 122.7, y: 12.7}).wait(1).to({graphics: mask_graphics_53, x: 125.9, y: 12.7}).wait(1).to({graphics: mask_graphics_54, x: 129, y: 12.7}).wait(1).to({graphics: mask_graphics_55, x: 132.2, y: 12.7}).wait(1).to({graphics: mask_graphics_56, x: 135.3, y: 12.7}).wait(1).to({graphics: mask_graphics_57, x: 138.4, y: 12.7}).wait(1).to({graphics: mask_graphics_58, x: 141.6, y: 12.7}).wait(1).to({graphics: mask_graphics_59, x: 144.7, y: 12.7}).wait(1).to({graphics: mask_graphics_60, x: 147.9, y: 12.7}).wait(1).to({graphics: mask_graphics_61, x: 151, y: 12.7}).wait(1).to({graphics: mask_graphics_62, x: 154.2, y: 12.7}).wait(1).to({graphics: mask_graphics_63, x: 141.9, y: 12.7}).wait(12).to({graphics: mask_graphics_75, x: 141.9, y: 12.7}).wait(1).to({graphics: mask_graphics_76, x: 160.1, y: 12.7}).wait(1).to({graphics: mask_graphics_77, x: 162.9, y: 12.7}).wait(1).to({graphics: mask_graphics_78, x: 165.7, y: 12.7}).wait(1).to({graphics: mask_graphics_79, x: 168.5, y: 12.7}).wait(1).to({graphics: mask_graphics_80, x: 171.3, y: 12.7}).wait(1).to({graphics: mask_graphics_81, x: 174, y: 12.7}).wait(1).to({graphics: mask_graphics_82, x: 176.8, y: 12.7}).wait(1).to({graphics: mask_graphics_83, x: 179.6, y: 12.7}).wait(1).to({graphics: mask_graphics_84, x: 182.4, y: 12.7}).wait(1).to({graphics: mask_graphics_85, x: 185.2, y: 12.7}).wait(1).to({graphics: mask_graphics_86, x: 188, y: 12.7}).wait(1).to({graphics: mask_graphics_87, x: 190.8, y: 12.7}).wait(1).to({graphics: mask_graphics_88, x: 178.2, y: 12.7}).wait(9));

        // Capa 1
        this.text = new cjs.Text("P = 100 % – 40 % =             ", "20px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 21;
        this.text.lineWidth = 421;
        this.text.setTransform(210.5, 0);
  this.textb = new cjs.Text("                               60 %", "bold 20px Verdana");
        this.textb.textAlign = "center";
        this.textb.lineHeight = 21;
        this.textb.lineWidth = 421;
        this.textb.setTransform(210.5, 0);

        this.text.mask =this.textb.mask= mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.text},{t: this.textb}]}, 9).wait(88));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.diagrama_05MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 3 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_4 = new cjs.Graphics().p("Ah2EIIAAoQIDaAAIAAIQg");
        var mask_graphics_5 = new cjs.Graphics().p("AiLEIIAAoQIEXAAIAAIQg");
        var mask_graphics_6 = new cjs.Graphics().p("AiqEIIAAoQIFVAAIAAIQg");
        var mask_graphics_7 = new cjs.Graphics().p("AjJEIIAAoQIGTAAIAAIQg");
        var mask_graphics_8 = new cjs.Graphics().p("AjoEIIAAoQIHRAAIAAIQg");
        var mask_graphics_9 = new cjs.Graphics().p("AkHEIIAAoQIIPAAIAAIQg");
        var mask_graphics_10 = new cjs.Graphics().p("AkmEIIAAoQIJNAAIAAIQg");
        var mask_graphics_11 = new cjs.Graphics().p("AlFEIIAAoQIKLAAIAAIQg");
        var mask_graphics_12 = new cjs.Graphics().p("AlkEIIAAoQILJAAIAAIQg");
        var mask_graphics_13 = new cjs.Graphics().p("AmDEIIAAoQIMHAAIAAIQg");
        var mask_graphics_14 = new cjs.Graphics().p("AmiEIIAAoQINFAAIAAIQg");
        var mask_graphics_23 = new cjs.Graphics().p("AmiEIIAAoQINFAAIAAIQg");
        var mask_graphics_24 = new cjs.Graphics().p("AnFEIIAAoQIOLAAIAAIQg");
        var mask_graphics_25 = new cjs.Graphics().p("AnnEIIAAoQIPPAAIAAIQg");
        var mask_graphics_26 = new cjs.Graphics().p("AoJEIIAAoQIQTAAIAAIQg");
        var mask_graphics_27 = new cjs.Graphics().p("AosEIIAAoQIRZAAIAAIQg");
        var mask_graphics_28 = new cjs.Graphics().p("ApOEIIAAoQISdAAIAAIQg");
        var mask_graphics_29 = new cjs.Graphics().p("ApxEIIAAoQITjAAIAAIQg");
        var mask_graphics_30 = new cjs.Graphics().p("AqTEIIAAoQIUnAAIAAIQg");
        var mask_graphics_31 = new cjs.Graphics().p("Aq2EIIAAoQIVtAAIAAIQg");
        var mask_graphics_32 = new cjs.Graphics().p("ArYEIIAAoQIWxAAIAAIQg");
        var mask_graphics_41 = new cjs.Graphics().p("ArYEIIAAoQIWxAAIAAIQg");
        var mask_graphics_42 = new cjs.Graphics().p("Ar7EIIAAoQIX3AAIAAIQg");
        var mask_graphics_43 = new cjs.Graphics().p("AsfEIIAAoQIY/AAIAAIQg");
        var mask_graphics_44 = new cjs.Graphics().p("AtCEIIAAoQIaFAAIAAIQg");
        var mask_graphics_45 = new cjs.Graphics().p("AtmEIIAAoQIbNAAIAAIQg");
        var mask_graphics_46 = new cjs.Graphics().p("AuJEIIAAoQIcTAAIAAIQg");
        var mask_graphics_47 = new cjs.Graphics().p("AutEIIAAoQIdbAAIAAIQg");
        var mask_graphics_48 = new cjs.Graphics().p("AvQEIIAAoQIehAAIAAIQg");
        var mask_graphics_49 = new cjs.Graphics().p("Av0EIIAAoQIfpAAIAAIQg");
        var mask_graphics_50 = new cjs.Graphics().p("AwXEIIAAoQMAgvAAAIAAIQg");
        var mask_graphics_60 = new cjs.Graphics().p("AwXEIIAAoQMAgvAAAIAAIQg");
        var mask_graphics_61 = new cjs.Graphics().p("AwrEIIAAoQMAhXAAAIAAIQg");
        var mask_graphics_62 = new cjs.Graphics().p("AxAEIIAAoQMAiBAAAIAAIQg");
        var mask_graphics_63 = new cjs.Graphics().p("AxUEIIAAoQMAipAAAIAAIQg");
        var mask_graphics_64 = new cjs.Graphics().p("AxoEIIAAoQMAjRAAAIAAIQg");
        var mask_graphics_65 = new cjs.Graphics().p("Ax8EIIAAoQMAj5AAAIAAIQg");
        var mask_graphics_66 = new cjs.Graphics().p("AyREIIAAoQMAkjAAAIAAIQg");
        var mask_graphics_67 = new cjs.Graphics().p("AylEIIAAoQMAlLAAAIAAIQg");
        var mask_graphics_68 = new cjs.Graphics().p("Ay5EIIAAoQMAlzAAAIAAIQg");
        var mask_graphics_69 = new cjs.Graphics().p("AzNEIIAAoQMAmbAAAIAAIQg");
        var mask_graphics_70 = new cjs.Graphics().p("AziEIIAAoQMAnFAAAIAAIQg");
        var mask_graphics_71 = new cjs.Graphics().p("Az2EIIAAoQMAntAAAIAAIQg");
        var mask_graphics_72 = new cjs.Graphics().p("A0KEIIAAoQMAoVAAAIAAIQg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: null, x: 0, y: 0}).wait(4).to({graphics: mask_graphics_4, x: -11.9, y: 11.6}).wait(1).to({graphics: mask_graphics_5, x: -9.8, y: 11.6}).wait(1).to({graphics: mask_graphics_6, x: -6.7, y: 11.6}).wait(1).to({graphics: mask_graphics_7, x: -3.6, y: 11.6}).wait(1).to({graphics: mask_graphics_8, x: -0.5, y: 11.6}).wait(1).to({graphics: mask_graphics_9, x: 2.5, y: 11.6}).wait(1).to({graphics: mask_graphics_10, x: 5.6, y: 11.6}).wait(1).to({graphics: mask_graphics_11, x: 8.7, y: 11.6}).wait(1).to({graphics: mask_graphics_12, x: 11.8, y: 11.6}).wait(1).to({graphics: mask_graphics_13, x: 14.8, y: 11.6}).wait(1).to({graphics: mask_graphics_14, x: 17.9, y: 11.6}).wait(9).to({graphics: mask_graphics_23, x: 17.9, y: 11.6}).wait(1).to({graphics: mask_graphics_24, x: 21.4, y: 11.6}).wait(1).to({graphics: mask_graphics_25, x: 24.8, y: 11.6}).wait(1).to({graphics: mask_graphics_26, x: 28.3, y: 11.6}).wait(1).to({graphics: mask_graphics_27, x: 31.7, y: 11.6}).wait(1).to({graphics: mask_graphics_28, x: 35.1, y: 11.6}).wait(1).to({graphics: mask_graphics_29, x: 38.6, y: 11.6}).wait(1).to({graphics: mask_graphics_30, x: 42, y: 11.6}).wait(1).to({graphics: mask_graphics_31, x: 45.5, y: 11.6}).wait(1).to({graphics: mask_graphics_32, x: 48.9, y: 11.6}).wait(9).to({graphics: mask_graphics_41, x: 48.9, y: 11.6}).wait(1).to({graphics: mask_graphics_42, x: 52.5, y: 11.6}).wait(1).to({graphics: mask_graphics_43, x: 56, y: 11.6}).wait(1).to({graphics: mask_graphics_44, x: 59.6, y: 11.6}).wait(1).to({graphics: mask_graphics_45, x: 63.1, y: 11.6}).wait(1).to({graphics: mask_graphics_46, x: 66.7, y: 11.6}).wait(1).to({graphics: mask_graphics_47, x: 70.2, y: 11.6}).wait(1).to({graphics: mask_graphics_48, x: 73.8, y: 11.6}).wait(1).to({graphics: mask_graphics_49, x: 77.3, y: 11.6}).wait(1).to({graphics: mask_graphics_50, x: 80.9, y: 11.6}).wait(10).to({graphics: mask_graphics_60, x: 80.9, y: 11.6}).wait(1).to({graphics: mask_graphics_61, x: 82.9, y: 11.6}).wait(1).to({graphics: mask_graphics_62, x: 84.9, y: 11.6}).wait(1).to({graphics: mask_graphics_63, x: 86.9, y: 11.6}).wait(1).to({graphics: mask_graphics_64, x: 88.9, y: 11.6}).wait(1).to({graphics: mask_graphics_65, x: 90.9, y: 11.6}).wait(1).to({graphics: mask_graphics_66, x: 92.9, y: 11.6}).wait(1).to({graphics: mask_graphics_67, x: 94.9, y: 11.6}).wait(1).to({graphics: mask_graphics_68, x: 96.9, y: 11.6}).wait(1).to({graphics: mask_graphics_69, x: 99, y: 11.6}).wait(1).to({graphics: mask_graphics_70, x: 101, y: 11.6}).wait(1).to({graphics: mask_graphics_71, x: 103, y: 11.6}).wait(1).to({graphics: mask_graphics_72, x: 105, y: 11.6}).wait(89));

        // Capa 2
        this.text = new cjs.Text("0,2 + 0,1 + 0,1 = ", "20px Verdana");
        this.text.lineHeight = 20;
        this.text.lineWidth = 395;
        if (isbq)
        this.text2 = new cjs.Text("                               0,4", "bold 20px Verdana");
    else
        this.text2 = new cjs.Text("                           0,4", "bold 20px Verdana");

        this.text2.lineHeight = 20;
        this.text2.lineWidth = 395;


        this.text.mask = this.text2.mask=mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.text},{t: this.text2}]}, 4).wait(157));

        // Capa 4 (mask)
        var mask_1 = new cjs.Shape();
        mask_1._off = true;
        var mask_1_graphics_81 = new cjs.Graphics().p("AhJHvIAAoGICTAAIAAIGg");
        var mask_1_graphics_82 = new cjs.Graphics().p("AhgEDIAAoGIDBAAIAAIGg");
        var mask_1_graphics_83 = new cjs.Graphics().p("Ah2EDIAAoGIDtAAIAAIGg");
        var mask_1_graphics_84 = new cjs.Graphics().p("AiNEDIAAoGIEbAAIAAIGg");
        var mask_1_graphics_85 = new cjs.Graphics().p("AijEDIAAoGIFHAAIAAIGg");
        var mask_1_graphics_86 = new cjs.Graphics().p("Ai6EDIAAoGIF1AAIAAIGg");
        var mask_1_graphics_87 = new cjs.Graphics().p("AjQEDIAAoGIGhAAIAAIGg");
        var mask_1_graphics_88 = new cjs.Graphics().p("AjnEDIAAoGIHPAAIAAIGg");
        var mask_1_graphics_89 = new cjs.Graphics().p("Aj9EDIAAoGIH7AAIAAIGg");
        var mask_1_graphics_90 = new cjs.Graphics().p("AkUEDIAAoGIIpAAIAAIGg");
        var mask_1_graphics_91 = new cjs.Graphics().p("AkqEDIAAoGIJVAAIAAIGg");
        var mask_1_graphics_92 = new cjs.Graphics().p("AlBEDIAAoGIKDAAIAAIGg");
        var mask_1_graphics_93 = new cjs.Graphics().p("AlXHvIAAoGIKvAAIAAIGg");
        var mask_1_graphics_102 = new cjs.Graphics().p("AlXHvIAAoGIKvAAIAAIGg");
        var mask_1_graphics_103 = new cjs.Graphics().p("Al2EDIAAoGILtAAIAAIGg");
        var mask_1_graphics_104 = new cjs.Graphics().p("AmVEDIAAoGIMrAAIAAIGg");
        var mask_1_graphics_105 = new cjs.Graphics().p("AmzEDIAAoGINnAAIAAIGg");
        var mask_1_graphics_106 = new cjs.Graphics().p("AnSEDIAAoGIOkAAIAAIGg");
        var mask_1_graphics_107 = new cjs.Graphics().p("AnwEDIAAoGIPhAAIAAIGg");
        var mask_1_graphics_108 = new cjs.Graphics().p("AoPEDIAAoGIQfAAIAAIGg");
        var mask_1_graphics_109 = new cjs.Graphics().p("AotEDIAAoGIRbAAIAAIGg");
        var mask_1_graphics_110 = new cjs.Graphics().p("ApMEDIAAoGISYAAIAAIGg");
        var mask_1_graphics_111 = new cjs.Graphics().p("ApqEDIAAoGITVAAIAAIGg");
        var mask_1_graphics_112 = new cjs.Graphics().p("AqJEDIAAoGIUTAAIAAIGg");
        var mask_1_graphics_113 = new cjs.Graphics().p("AqnHvIAAoGIVPAAIAAIGg");
        var mask_1_graphics_123 = new cjs.Graphics().p("AqnHvIAAoGIVPAAIAAIGg");
        var mask_1_graphics_124 = new cjs.Graphics().p("Aq+EDIAAoGIV9AAIAAIGg");
        var mask_1_graphics_125 = new cjs.Graphics().p("ArWEDIAAoGIWtAAIAAIGg");
        var mask_1_graphics_126 = new cjs.Graphics().p("ArtEDIAAoGIXbAAIAAIGg");
        var mask_1_graphics_127 = new cjs.Graphics().p("AsFEDIAAoGIYLAAIAAIGg");
        var mask_1_graphics_128 = new cjs.Graphics().p("AscEDIAAoGIY5AAIAAIGg");
        var mask_1_graphics_129 = new cjs.Graphics().p("As0EDIAAoGIZpAAIAAIGg");
        var mask_1_graphics_130 = new cjs.Graphics().p("AtLEDIAAoGIaXAAIAAIGg");
        var mask_1_graphics_131 = new cjs.Graphics().p("AtjEDIAAoGIbHAAIAAIGg");
        var mask_1_graphics_132 = new cjs.Graphics().p("At6EDIAAoGIb1AAIAAIGg");
        var mask_1_graphics_133 = new cjs.Graphics().p("AuSEDIAAoGIclAAIAAIGg");
        var mask_1_graphics_134 = new cjs.Graphics().p("AupEDIAAoGIdTAAIAAIGg");
        var mask_1_graphics_135 = new cjs.Graphics().p("AvBEDIAAoGIeDAAIAAIGg");
        var mask_1_graphics_136 = new cjs.Graphics().p("AvYEDIAAoGIexAAIAAIGg");
        var mask_1_graphics_137 = new cjs.Graphics().p("AvwHvIAAoGIfhAAIAAIGg");

        this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics: null, x: 0, y: 0}).wait(81).to({graphics: mask_1_graphics_81, x: -7.4, y: 49.6}).wait(1).to({graphics: mask_1_graphics_82, x: -5.1, y: 73.1}).wait(1).to({graphics: mask_1_graphics_83, x: -2.9, y: 73.1}).wait(1).to({graphics: mask_1_graphics_84, x: -0.6, y: 73.1}).wait(1).to({graphics: mask_1_graphics_85, x: 1.5, y: 73.1}).wait(1).to({graphics: mask_1_graphics_86, x: 3.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_87, x: 6, y: 73.1}).wait(1).to({graphics: mask_1_graphics_88, x: 8.3, y: 73.1}).wait(1).to({graphics: mask_1_graphics_89, x: 10.5, y: 73.1}).wait(1).to({graphics: mask_1_graphics_90, x: 12.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_91, x: 15, y: 73.1}).wait(1).to({graphics: mask_1_graphics_92, x: 17.3, y: 73.1}).wait(1).to({graphics: mask_1_graphics_93, x: 19.5, y: 49.6}).wait(9).to({graphics: mask_1_graphics_102, x: 19.5, y: 49.6}).wait(1).to({graphics: mask_1_graphics_103, x: 22.6, y: 73.1}).wait(1).to({graphics: mask_1_graphics_104, x: 25.6, y: 73.1}).wait(1).to({graphics: mask_1_graphics_105, x: 28.7, y: 73.1}).wait(1).to({graphics: mask_1_graphics_106, x: 31.7, y: 73.1}).wait(1).to({graphics: mask_1_graphics_107, x: 34.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_108, x: 37.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_109, x: 40.9, y: 73.1}).wait(1).to({graphics: mask_1_graphics_110, x: 43.9, y: 73.1}).wait(1).to({graphics: mask_1_graphics_111, x: 47, y: 73.1}).wait(1).to({graphics: mask_1_graphics_112, x: 50, y: 73.1}).wait(1).to({graphics: mask_1_graphics_113, x: 53.1, y: 49.6}).wait(10).to({graphics: mask_1_graphics_123, x: 53.1, y: 49.6}).wait(1).to({graphics: mask_1_graphics_124, x: 55.4, y: 73.1}).wait(1).to({graphics: mask_1_graphics_125, x: 57.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_126, x: 60.1, y: 73.1}).wait(1).to({graphics: mask_1_graphics_127, x: 62.5, y: 73.1}).wait(1).to({graphics: mask_1_graphics_128, x: 64.9, y: 73.1}).wait(1).to({graphics: mask_1_graphics_129, x: 67.2, y: 73.1}).wait(1).to({graphics: mask_1_graphics_130, x: 69.6, y: 73.1}).wait(1).to({graphics: mask_1_graphics_131, x: 72, y: 73.1}).wait(1).to({graphics: mask_1_graphics_132, x: 74.3, y: 73.1}).wait(1).to({graphics: mask_1_graphics_133, x: 76.7, y: 73.1}).wait(1).to({graphics: mask_1_graphics_134, x: 79.1, y: 73.1}).wait(1).to({graphics: mask_1_graphics_135, x: 81.4, y: 73.1}).wait(1).to({graphics: mask_1_graphics_136, x: 83.8, y: 73.1}).wait(1).to({graphics: mask_1_graphics_137, x: 86.2, y: 49.6}).wait(24));

        // Capa 1
        this.text_1 = new cjs.Text("0,4 · 100 = ", "20px Verdana");
        this.text_1.lineHeight = 20;
        this.text_1.lineWidth = 395;
        this.text_1.setTransform(0, 60);
        if (isbq)
 this.text_1b = new cjs.Text("                     40 %", "bold 20px Verdana");
 else
      this.text_1b = new cjs.Text("                  40 %", "bold 20px Verdana");

        this.text_1b.lineHeight = 20;
        this.text_1b.lineWidth = 395;
        this.text_1b.setTransform(0, 60);

        this.text_1.mask =this.text_1b.mask= mask_1;

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.text_1},{t: this.text_1b}]}, 81).wait(80));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib.Diagrama_02MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 3 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_8 = new cjs.Graphics().p("AxyBkIAAjGMAjlAAAIAADGg");
        var mask_graphics_9 = new cjs.Graphics().p("AxyCDIAAkFMAjlAAAIAAEFg");
        var mask_graphics_10 = new cjs.Graphics().p("AxyCjIAAlFMAjlAAAIAAFFg");
        var mask_graphics_11 = new cjs.Graphics().p("AxyDDIAAmFMAjlAAAIAAGFg");
        var mask_graphics_12 = new cjs.Graphics().p("AxyDjIAAnFMAjlAAAIAAHFg");
        var mask_graphics_13 = new cjs.Graphics().p("AxyEDIAAoFMAjlAAAIAAIFg");
        var mask_graphics_14 = new cjs.Graphics().p("AxyEjIAApFMAjlAAAIAAJFg");
        var mask_graphics_15 = new cjs.Graphics().p("AxyFDIAAqFMAjlAAAIAAKFg");
        var mask_graphics_16 = new cjs.Graphics().p("AxyFiIAArEMAjlAAAIAALEg");
        var mask_graphics_17 = new cjs.Graphics().p("AxyGCIAAsDMAjlAAAIAAMDg");
        var mask_graphics_18 = new cjs.Graphics().p("AxyGiIAAtDMAjlAAAIAANDg");
        var mask_graphics_19 = new cjs.Graphics().p("AxyHCIAAuDMAjlAAAIAAODg");
        var mask_graphics_20 = new cjs.Graphics().p("AxyHiIAAvDMAjlAAAIAAPDg");
        var mask_graphics_21 = new cjs.Graphics().p("AxyICIAAwDMAjlAAAIAAQDg");
        var mask_graphics_22 = new cjs.Graphics().p("AxyIiIAAxDMAjlAAAIAARDg");
        var mask_graphics_23 = new cjs.Graphics().p("AxyJCIAAyDMAjlAAAIAASDg");
        var mask_graphics_24 = new cjs.Graphics().p("AAWJhIAAzBMAjoAAAIAATBg");
        var mask_graphics_44 = new cjs.Graphics().p("AAWJhIAAzBMAjoAAAIAATBg");
        var mask_graphics_45 = new cjs.Graphics().p("AxyJ7IAAz1MAjlAAAIAAT1g");
        var mask_graphics_46 = new cjs.Graphics().p("AxyKVIAA0pMAjlAAAIAAUpg");
        var mask_graphics_47 = new cjs.Graphics().p("AxyKvIAA1dMAjlAAAIAAVdg");
        var mask_graphics_48 = new cjs.Graphics().p("AxyLJIAA2RMAjlAAAIAAWRg");
        var mask_graphics_49 = new cjs.Graphics().p("AxyLjIAA3FMAjlAAAIAAXFg");
        var mask_graphics_50 = new cjs.Graphics().p("AxyL9IAA35MAjlAAAIAAX5g");
        var mask_graphics_51 = new cjs.Graphics().p("AxyMWIAA4rMAjlAAAIAAYrg");
        var mask_graphics_52 = new cjs.Graphics().p("AxyMwIAA5fMAjlAAAIAAZfg");
        var mask_graphics_53 = new cjs.Graphics().p("AxyNKIAA6TMAjlAAAIAAaTg");
        var mask_graphics_54 = new cjs.Graphics().p("AxyNkIAA7HMAjlAAAIAAbHg");
        var mask_graphics_55 = new cjs.Graphics().p("AxyN+IAA77MAjlAAAIAAb7g");
        var mask_graphics_56 = new cjs.Graphics().p("AxyOYIAA8vMAjlAAAIAAcvg");
        var mask_graphics_57 = new cjs.Graphics().p("AxyOxIAA9hMAjlAAAIAAdhg");
        var mask_graphics_58 = new cjs.Graphics().p("AxyPLIAA+VMAjlAAAIAAeVg");
        var mask_graphics_59 = new cjs.Graphics().p("AxyPlIAA/JMAjlAAAIAAfJg");
        var mask_graphics_60 = new cjs.Graphics().p("AxyP/IAA/9MAjlAAAIAAf9g");
        var mask_graphics_61 = new cjs.Graphics().p("AxyQZMAAAggxMAjlAAAMAAAAgxg");
        var mask_graphics_62 = new cjs.Graphics().p("AxyQzMAAAghlMAjlAAAMAAAAhlg");
        var mask_graphics_63 = new cjs.Graphics().p("AAWRNMAAAgiZMAjoAAAMAAAAiZg");
        var mask_graphics_80 = new cjs.Graphics().p("AAWRNMAAAgiZMAjoAAAMAAAAiZg");
        var mask_graphics_81 = new cjs.Graphics().p("AxyRxMAAAgjhMAjlAAAMAAAAjhg");
        var mask_graphics_82 = new cjs.Graphics().p("AxySVMAAAgkpMAjlAAAMAAAAkpg");
        var mask_graphics_83 = new cjs.Graphics().p("AxyS5MAAAglxMAjlAAAMAAAAlxg");
        var mask_graphics_84 = new cjs.Graphics().p("AxyTdMAAAgm5MAjlAAAMAAAAm5g");
        var mask_graphics_85 = new cjs.Graphics().p("AxyUBMAAAgoBMAjlAAAMAAAAoBg");
        var mask_graphics_86 = new cjs.Graphics().p("AxyUlMAAAgpJMAjlAAAMAAAApJg");
        var mask_graphics_87 = new cjs.Graphics().p("AxyVJMAAAgqRMAjlAAAMAAAAqRg");
        var mask_graphics_88 = new cjs.Graphics().p("AxyVtMAAAgrZMAjlAAAMAAAArZg");
        var mask_graphics_89 = new cjs.Graphics().p("AxyWRMAAAgshMAjlAAAMAAAAshg");
        var mask_graphics_90 = new cjs.Graphics().p("AxyW1MAAAgtpMAjlAAAMAAAAtpg");
        var mask_graphics_91 = new cjs.Graphics().p("AxyXZMAAAguxMAjlAAAMAAAAuxg");
        var mask_graphics_92 = new cjs.Graphics().p("AxyX9MAAAgv5MAjlAAAMAAAAv5g");
        var mask_graphics_93 = new cjs.Graphics().p("AxyYiMAAAgxDMAjlAAAMAAAAxDg");
        var mask_graphics_94 = new cjs.Graphics().p("AxyZGMAAAgyLMAjlAAAMAAAAyLg");
        var mask_graphics_95 = new cjs.Graphics().p("AxyZqMAAAgzTMAjlAAAMAAAAzTg");
        var mask_graphics_96 = new cjs.Graphics().p("AxyaOMAAAg0bMAjlAAAMAAAA0bg");
        var mask_graphics_97 = new cjs.Graphics().p("AxyayMAAAg1jMAjlAAAMAAAA1jg");
        var mask_graphics_98 = new cjs.Graphics().p("AxybWMAAAg2rMAjlAAAMAAAA2rg");
        var mask_graphics_99 = new cjs.Graphics().p("AAWb6MAAAg3zMAjoAAAMAAAA3zg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: null, x: 0, y: 0}).wait(8).to({graphics: mask_graphics_8, x: 346.6, y: -22.2}).wait(1).to({graphics: mask_graphics_9, x: 346.6, y: -19}).wait(1).to({graphics: mask_graphics_10, x: 346.6, y: -15.8}).wait(1).to({graphics: mask_graphics_11, x: 346.6, y: -12.6}).wait(1).to({graphics: mask_graphics_12, x: 346.6, y: -9.4}).wait(1).to({graphics: mask_graphics_13, x: 346.6, y: -6.2}).wait(1).to({graphics: mask_graphics_14, x: 346.6, y: -3}).wait(1).to({graphics: mask_graphics_15, x: 346.6, y: 0.1}).wait(1).to({graphics: mask_graphics_16, x: 346.6, y: 3.3}).wait(1).to({graphics: mask_graphics_17, x: 346.6, y: 6.5}).wait(1).to({graphics: mask_graphics_18, x: 346.6, y: 9.7}).wait(1).to({graphics: mask_graphics_19, x: 346.6, y: 12.8}).wait(1).to({graphics: mask_graphics_20, x: 346.6, y: 16}).wait(1).to({graphics: mask_graphics_21, x: 346.6, y: 19.2}).wait(1).to({graphics: mask_graphics_22, x: 346.6, y: 22.4}).wait(1).to({graphics: mask_graphics_23, x: 346.6, y: 25.6}).wait(1).to({graphics: mask_graphics_24, x: 230.3, y: 28.8}).wait(20).to({graphics: mask_graphics_44, x: 230.3, y: 28.8}).wait(1).to({graphics: mask_graphics_45, x: 346.6, y: 31.4}).wait(1).to({graphics: mask_graphics_46, x: 346.6, y: 34}).wait(1).to({graphics: mask_graphics_47, x: 346.6, y: 36.5}).wait(1).to({graphics: mask_graphics_48, x: 346.6, y: 39.1}).wait(1).to({graphics: mask_graphics_49, x: 346.6, y: 41.7}).wait(1).to({graphics: mask_graphics_50, x: 346.6, y: 44.3}).wait(1).to({graphics: mask_graphics_51, x: 346.6, y: 46.9}).wait(1).to({graphics: mask_graphics_52, x: 346.6, y: 49.4}).wait(1).to({graphics: mask_graphics_53, x: 346.6, y: 52}).wait(1).to({graphics: mask_graphics_54, x: 346.6, y: 54.6}).wait(1).to({graphics: mask_graphics_55, x: 346.6, y: 57.2}).wait(1).to({graphics: mask_graphics_56, x: 346.6, y: 59.7}).wait(1).to({graphics: mask_graphics_57, x: 346.6, y: 62.3}).wait(1).to({graphics: mask_graphics_58, x: 346.6, y: 64.9}).wait(1).to({graphics: mask_graphics_59, x: 346.6, y: 67.5}).wait(1).to({graphics: mask_graphics_60, x: 346.6, y: 70.1}).wait(1).to({graphics: mask_graphics_61, x: 346.6, y: 72.6}).wait(1).to({graphics: mask_graphics_62, x: 346.6, y: 75.2}).wait(1).to({graphics: mask_graphics_63, x: 230.3, y: 77.8}).wait(17).to({graphics: mask_graphics_80, x: 230.3, y: 77.8}).wait(1).to({graphics: mask_graphics_81, x: 346.6, y: 81.4}).wait(1).to({graphics: mask_graphics_82, x: 346.6, y: 85}).wait(1).to({graphics: mask_graphics_83, x: 346.6, y: 88.7}).wait(1).to({graphics: mask_graphics_84, x: 346.6, y: 92.3}).wait(1).to({graphics: mask_graphics_85, x: 346.6, y: 95.9}).wait(1).to({graphics: mask_graphics_86, x: 346.6, y: 99.5}).wait(1).to({graphics: mask_graphics_87, x: 346.6, y: 103.1}).wait(1).to({graphics: mask_graphics_88, x: 346.6, y: 106.8}).wait(1).to({graphics: mask_graphics_89, x: 346.6, y: 110.4}).wait(1).to({graphics: mask_graphics_90, x: 346.6, y: 114}).wait(1).to({graphics: mask_graphics_91, x: 346.6, y: 117.6}).wait(1).to({graphics: mask_graphics_92, x: 346.6, y: 121.3}).wait(1).to({graphics: mask_graphics_93, x: 346.6, y: 124.9}).wait(1).to({graphics: mask_graphics_94, x: 346.6, y: 128.5}).wait(1).to({graphics: mask_graphics_95, x: 346.6, y: 132.1}).wait(1).to({graphics: mask_graphics_96, x: 346.6, y: 135.7}).wait(1).to({graphics: mask_graphics_97, x: 346.6, y: 139.4}).wait(1).to({graphics: mask_graphics_98, x: 346.6, y: 143}).wait(1).to({graphics: mask_graphics_99, x: 230.3, y: 146.6}).wait(21));

        // Capa 2
        this.hombre = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre.lineHeight = 16;
        this.hombre.lineWidth = 100;
        this.hombre.setTransform(343.9, 260.2);

        this.mujer = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer.lineHeight = 16;
        this.mujer.lineWidth = 100;
        this.mujer.setTransform(343.9, 200.2);

        this.hombre_1 = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre_1.lineHeight = 16;
        this.hombre_1.lineWidth = 100;
        this.hombre_1.setTransform(343.9, 158.2);

        this.mujer_1 = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer_1.lineHeight = 16;
        this.mujer_1.lineWidth = 100;
        this.mujer_1.setTransform(343.9, 98.2);

        this.hombre_2 = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre_2.lineHeight = 16;
        this.hombre_2.lineWidth = 100;
        this.hombre_2.setTransform(343.9, 62.2);

        this.mujer_2 = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer_2.lineHeight = 16;
        this.mujer_2.lineWidth = 100;
        this.mujer_2.setTransform(343.9, 2.2);

        this.text = new cjs.Text("0,4", "16px Verdana");
        this.text.lineHeight = 16;
        this.text.lineWidth = 44;
        this.text.setTransform(260.1, 258.8);

        this.text_1 = new cjs.Text("0,6", "16px Verdana");
        this.text_1.lineHeight = 16;
        this.text_1.lineWidth = 44;
        this.text_1.setTransform(260.1, 200.6);

        this.text_2 = new cjs.Text("0,4", "16px Verdana");
        this.text_2.lineHeight = 16;
        this.text_2.lineWidth = 44;
        this.text_2.setTransform(260.1, 158.6);

        this.text_3 = new cjs.Text("0,6", "16px Verdana");
        this.text_3.lineHeight = 16;
        this.text_3.lineWidth = 44;
        this.text_3.setTransform(260.1, 100.4);

        this.text_4 = new cjs.Text("0,4", "16px Verdana");
        this.text_4.lineHeight = 16;
        this.text_4.lineWidth = 44;
        this.text_4.setTransform(260.1, 62);

        this.text_5 = new cjs.Text("0,6", "16px Verdana");
        this.text_5.lineHeight = 16;
        this.text_5.lineWidth = 44;
        this.text_5.setTransform(260.1, 3.8);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#66CC00").ss(2, 1, 1).p("AHcERIu9kRIPDkQ");
        this.shape.setTransform(289.1, 237.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#0066CC").ss(2, 1, 1).p("AHcERIu9kRIPDkQ");
        this.shape_1.setTransform(289.1, 139.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#CC0000").ss(2, 1, 1).p("AHikQIvDEQIO9ER");
        this.shape_2.setTransform(289.1, 41.9);

        this.hombre.mask = this.mujer.mask = this.hombre_1.mask = this.mujer_1.mask = this.hombre_2.mask = this.mujer_2.mask = this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape_2}, {t: this.shape_1}, {t: this.shape}, {t: this.text_5}, {t: this.text_4}, {t: this.text_3}, {t: this.text_2}, {t: this.text_1}, {t: this.text}, {t: this.mujer_2}, {t: this.hombre_2}, {t: this.mujer_1}, {t: this.hombre_1}, {t: this.mujer}, {t: this.hombre}]}, 8).wait(112));

        // Capa 4
        this.facultad3 = new cjs.Text(txt['facultad3'], "18px Verdana");
        this.facultad3.lineHeight = 18;
        this.facultad3.lineWidth = 107;
        this.facultad3.setTransform(120.7, 227.1);

        this.facultad2 = new cjs.Text(txt['facultad2'], "18px Verdana");
        this.facultad2.lineHeight = 18;
        this.facultad2.lineWidth = 107;
        this.facultad2.setTransform(120.7, 124.5);

        this.facultad1 = new cjs.Text(txt['facultad1'], "18px Verdana");
        this.facultad1.lineHeight = 18;
        this.facultad1.lineWidth = 107;
        this.facultad1.setTransform(120.7, 28.5);

        this.text_6 = new cjs.Text("0,25", "18px Verdana");
        this.text_6.textAlign = "right";
        this.text_6.lineHeight = 18;
        this.text_6.lineWidth = 100;
        this.text_6.setTransform(91.6, 114.3);

        this.text_7 = new cjs.Text("0,25", "18px Verdana");
        this.text_7.textAlign = "right";
        this.text_7.lineHeight = 18;
        this.text_7.lineWidth = 100;
        this.text_7.setTransform(49.6, 186.3);

        this.text_8 = new cjs.Text("0,5", "18px Verdana");
        this.text_8.textAlign = "right";
        this.text_8.lineHeight = 18;
        this.text_8.lineWidth = 100;
        this.text_8.setTransform(53.8, 60.3);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#003399").ss(2, 1, 1).p("AnkAAIPJAA");
        this.shape_3.setTransform(63.8, 140.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#009900").ss(2, 1, 1).p("AnhnhIPDPD");
        this.shape_4.setTransform(63.5, 189);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#CC0000").ss(2, 1, 1).p("AHrnqIvVPV");
        this.shape_5.setTransform(64.4, 91.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5}, {t: this.shape_4}, {t: this.shape_3}, {t: this.text_8}, {t: this.text_7}, {t: this.text_6}, {t: this.facultad1}, {t: this.facultad2}, {t: this.facultad3}]}).wait(120));

        // Capa 1


    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-50.3, 0, 480.5, 283.5);


    (lib.Diagrama_01MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 4 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_0 = new cjs.Graphics().p("AiqXLMAAAguEIEpAAMAAAAuEg");
        var mask_graphics_1 = new cjs.Graphics().p("AjQXCMAAAguDIGhAAMAAAAuDg");
        var mask_graphics_2 = new cjs.Graphics().p("AkMXCMAAAguDIIZAAMAAAAuDg");
        var mask_graphics_3 = new cjs.Graphics().p("AlIXCMAAAguDIKRAAMAAAAuDg");
        var mask_graphics_4 = new cjs.Graphics().p("AmEXCMAAAguDIMJAAMAAAAuDg");
        var mask_graphics_5 = new cjs.Graphics().p("AnAXCMAAAguDIOBAAMAAAAuDg");
        var mask_graphics_6 = new cjs.Graphics().p("An8XCMAAAguDIP5AAMAAAAuDg");
        var mask_graphics_7 = new cjs.Graphics().p("Ao4XCMAAAguDIRxAAMAAAAuDg");
        var mask_graphics_8 = new cjs.Graphics().p("Ap0XCMAAAguDITpAAMAAAAuDg");
        var mask_graphics_9 = new cjs.Graphics().p("AqwXCMAAAguDIVhAAMAAAAuDg");
        var mask_graphics_10 = new cjs.Graphics().p("ArsXCMAAAguDIXZAAMAAAAuDg");
        var mask_graphics_11 = new cjs.Graphics().p("AsoXCMAAAguDIZRAAMAAAAuDg");
        var mask_graphics_12 = new cjs.Graphics().p("AtkXCMAAAguDIbJAAMAAAAuDg");
        var mask_graphics_13 = new cjs.Graphics().p("AugXCMAAAguDIdBAAMAAAAuDg");
        var mask_graphics_14 = new cjs.Graphics().p("AvcXCMAAAguDIe5AAMAAAAuDg");
        var mask_graphics_15 = new cjs.Graphics().p("AwYXCMAAAguDMAgxAAAMAAAAuDg");
        var mask_graphics_16 = new cjs.Graphics().p("AxUXCMAAAguDMAipAAAMAAAAuDg");
        var mask_graphics_17 = new cjs.Graphics().p("AyQXCMAAAguDMAkhAAAMAAAAuDg");
        var mask_graphics_18 = new cjs.Graphics().p("AzMXCMAAAguDMAmZAAAMAAAAuDg");
        var mask_graphics_19 = new cjs.Graphics().p("A0IXCMAAAguDMAoRAAAMAAAAuDg");
        var mask_graphics_20 = new cjs.Graphics().p("A1EXCMAAAguDMAqJAAAMAAAAuDg");
        var mask_graphics_21 = new cjs.Graphics().p("A2AXCMAAAguDMAsBAAAMAAAAuDg");
        var mask_graphics_22 = new cjs.Graphics().p("A28XLMAAAguEMAt5AAAMAAAAuEg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: mask_graphics_0, x: -17.1, y: 148.4}).wait(1).to({graphics: mask_graphics_1, x: -13.3, y: 149.2}).wait(1).to({graphics: mask_graphics_2, x: -7.3, y: 149.2}).wait(1).to({graphics: mask_graphics_3, x: -1.3, y: 149.2}).wait(1).to({graphics: mask_graphics_4, x: 4.6, y: 149.2}).wait(1).to({graphics: mask_graphics_5, x: 10.6, y: 149.2}).wait(1).to({graphics: mask_graphics_6, x: 16.6, y: 149.2}).wait(1).to({graphics: mask_graphics_7, x: 22.6, y: 149.2}).wait(1).to({graphics: mask_graphics_8, x: 28.6, y: 149.2}).wait(1).to({graphics: mask_graphics_9, x: 34.6, y: 149.2}).wait(1).to({graphics: mask_graphics_10, x: 40.6, y: 149.2}).wait(1).to({graphics: mask_graphics_11, x: 46.6, y: 149.2}).wait(1).to({graphics: mask_graphics_12, x: 52.6, y: 149.2}).wait(1).to({graphics: mask_graphics_13, x: 58.6, y: 149.2}).wait(1).to({graphics: mask_graphics_14, x: 64.6, y: 149.2}).wait(1).to({graphics: mask_graphics_15, x: 70.6, y: 149.2}).wait(1).to({graphics: mask_graphics_16, x: 76.6, y: 149.2}).wait(1).to({graphics: mask_graphics_17, x: 82.6, y: 149.2}).wait(1).to({graphics: mask_graphics_18, x: 88.6, y: 149.2}).wait(1).to({graphics: mask_graphics_19, x: 94.6, y: 149.2}).wait(1).to({graphics: mask_graphics_20, x: 100.6, y: 149.2}).wait(1).to({graphics: mask_graphics_21, x: 106.6, y: 149.2}).wait(1).to({graphics: mask_graphics_22, x: 112.6, y: 148.4}).wait(24));

        // Capa 2
        this.facultad3 = new cjs.Text(txt['facultad3'], "18px Verdana");
        this.facultad3.lineHeight = 18;
        this.facultad3.lineWidth = 107;
        this.facultad3.setTransform(120.7, 227.1);

        this.facultad2 = new cjs.Text(txt['facultad2'], "18px Verdana");
        this.facultad2.lineHeight = 18;
        this.facultad2.lineWidth = 107;
        this.facultad2.setTransform(120.7, 124.5);

        this.facultad1 = new cjs.Text(txt['facultad1'], "18px Verdana");
        this.facultad1.lineHeight = 18;
        this.facultad1.lineWidth = 107;
        this.facultad1.setTransform(120.7, 28.5);

        this.text = new cjs.Text("0,25", "18px Verdana");
        this.text.textAlign = "right";
        this.text.lineHeight = 18;
        this.text.lineWidth = 100;
        this.text.setTransform(91.6, 114.3);

        this.text_1 = new cjs.Text("0,25", "18px Verdana");
        this.text_1.textAlign = "right";
        this.text_1.lineHeight = 18;
        this.text_1.lineWidth = 100;
        this.text_1.setTransform(49.6, 186.3);

        this.text_2 = new cjs.Text("0,5", "18px Verdana");
        this.text_2.textAlign = "right";
        this.text_2.lineHeight = 18;
        this.text_2.lineWidth = 100;
        this.text_2.setTransform(53.8, 60.3);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#009900").ss(2, 1, 1).p("AnhnhIPDPD");
        this.shape.setTransform(63.5, 189);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#003399").ss(2, 1, 1).p("AnkAAIPJAA");
        this.shape_1.setTransform(63.8, 140.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#CC0000").ss(2, 1, 1).p("AHrnqIvVPV");
        this.shape_2.setTransform(64.4, 91.6);

        this.facultad3.mask = this.facultad2.mask = this.facultad1.mask = this.text.mask = this.text_1.mask = this.text_2.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2}, {t: this.shape_1}, {t: this.shape}, {t: this.text_2}, {t: this.text_1}, {t: this.text}, {t: this.facultad1}, {t: this.facultad2}, {t: this.facultad3}]}).wait(46));



    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-50.3, 0, 480.5, 283.5);


    (lib.Cruz_MC = function () {
        this.initialize();

        // penny_back
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#671203").s().p("AxRAiQgDAAgEgDQgDgDAAgEIAAgvQAAgEADgDQAEgDADAAMAiiAAAQAFAAADADQACADAAAEIAAAvQAAAEgCADQgDADgFAAg");
        this.shape.setTransform(1.7, -36.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#671203").s().p("AttAUQgIAAAAgGIAAgbQAAgGAIAAIbbAAQAIAAAAAGIAAAbQAAAGgIAAg");
        this.shape_1.setTransform(1.4, -71);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#671203").s().p("AtiAKQgHAAAAgDIAAgNQAAgDAHAAIbEAAQAIAAAAADIAAANQAAADgIAAg");
        this.shape_2.setTransform(1.4, -58.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#671203").s().p("AxRAZQgKAAAAgHIAAgjQAAgHAKAAMAiiAAAQALAAgBAHIAAAjQABAHgLAAg");
        this.shape_3.setTransform(1.7, -48.5);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#671203").s().p("AgRAPQgHgHAAgIQAAgHAHgHQAIgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgIgGg");
        this.shape_4.setTransform(104.2, -42.8);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_5.setTransform(108.4, -42.8);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_6.setTransform(106.1, -43);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgHgGg");
        this.shape_7.setTransform(86.9, -42.8);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_8.setTransform(91.1, -42.8);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_9.setTransform(88.7, -43);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#671203").s().p("AgRAPQgHgHAAgIQAAgHAHgHQAIgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgIgGg");
        this.shape_10.setTransform(68.6, -42.8);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_11.setTransform(72.8, -42.8);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAGAAAGAEQAFAFAAAFQAAAGgFAFQgGAEgGAAQgGAAgFgEg");
        this.shape_12.setTransform(70.5, -43);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#671203").s().p("AgRAPQgHgHAAgIQAAgHAHgHQAIgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgIgGg");
        this.shape_13.setTransform(48.6, -42.8);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_14.setTransform(52.8, -42.8);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAGAAAGAEQAFAFAAAFQAAAGgFAFQgGAEgGAAQgGAAgFgEg");
        this.shape_15.setTransform(50.5, -43);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#671203").s().p("AgRAPQgHgHAAgIQAAgHAHgHQAIgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgIgGg");
        this.shape_16.setTransform(29.6, -42.8);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_17.setTransform(33.8, -42.8);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAGAAAGAEQAFAFAAAFQAAAGgFAFQgGAEgGAAQgGAAgFgEg");
        this.shape_18.setTransform(31.5, -43);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_19.setTransform(10.1, -42.8);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_20.setTransform(14.3, -42.8);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAGgEAFAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgFAAgGgEg");
        this.shape_21.setTransform(11.9, -43);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f("#671203").s().p("AgRAPQgHgHAAgIQAAgHAHgHQAIgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgIgGg");
        this.shape_22.setTransform(-12.1, -42.8);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_23.setTransform(-7.9, -42.8);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_24.setTransform(-10.2, -43);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_25.setTransform(-30.8, -42.8);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_26.setTransform(-26.6, -42.8);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_27.setTransform(-28.9, -43);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_28.setTransform(-49.6, -42.8);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_29.setTransform(-45.4, -42.8);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_30.setTransform(-47.7, -43);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_31.setTransform(-69.7, -42.8);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgHgGg");
        this.shape_32.setTransform(-65.5, -42.8);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_33.setTransform(-67.9, -43);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_34.setTransform(-88.4, -42.8);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_35.setTransform(-84.2, -42.8);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAGgEAFAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgFAAgGgEg");
        this.shape_36.setTransform(-86.6, -43);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAIAGQAHAHAAAHQAAAIgHAHQgIAGgKAAQgJAAgHgGg");
        this.shape_37.setTransform(-104.9, -42.8);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f("#671203").s().p("AgQAPQgIgHAAgIQAAgHAIgHQAHgGAJAAQAKAAAHAGQAIAHAAAHQAAAIgIAHQgHAGgKAAQgJAAgHgGg");
        this.shape_38.setTransform(-100.7, -42.8);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f("#671203").s().p("AgLALQgFgFAAgGQAAgFAFgFQAFgEAGAAQAHAAAFAEQAFAFAAAFQAAAGgFAFQgFAEgHAAQgGAAgFgEg");
        this.shape_39.setTransform(-103.1, -43);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#531002").s().p("AxbAuIAAhbMAi2AAAIAABbg");
        this.shape_40.setTransform(1.7, -41.9);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ANtBwI7ZAAIAAjfIbZAAg");
        this.shape_41.setTransform(1.4, -62.1);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#531002").s().p("AtsBwIAAjfIbZAAIAADfg");
        this.shape_42.setTransform(1.4, -62.1);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#671203").s().p("AAKBqIgDgbIgBgMQgBgJgDgCIgBAZQgBAOgBAKQgEATgIAAQgFAAgEgFQgCgFgBgGQgBgOABglQAAgogDgSQgDAYgMgJQgIgGADgSIAEgYQABgGAJgQIAPgQQAKgJgBgKQgBgQABgGQADgMAKAAIAJAEQAIAHgFAXIAAAEIACAHQADAGAIAGQAJAHAGANQALAXgHAZQgGATgCABQgEACgBgJQgCgLgBgBIgBAdIADAXIgBAaQAAAPgCAKQgEAUgFACIgBAAQgGAAgEgUg");
        this.shape_43.setTransform(1.1, -5.1);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AgQh+IgDADQgDAGACANIAABMIgDAGQgEAIABAJIAACFIA1AAIAAiHQAAgQgHgHIAAhLQAFgQgHgFg");
        this.shape_44.setTransform(-62.4, 30);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#531002").s().p("AgaCAIAAiFQgBgJAEgIIADgHIAAhLQgCgNADgGIADgDIAigBQAHAGgFAQIAABLQAHAGAAARIAACHg");
        this.shape_45.setTransform(-62.4, 30);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AgQh+IgDADQgDAGADANIAABMIgEAGQgDAIAAAJIAACFIA2AAIAAiHQAAgQgHgHIAAhLQAFgQgHgFg");
        this.shape_46.setTransform(66.1, 30);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f("#531002").s().p("AgaCAIAAiFQAAgJADgIIADgHIAAhLQgCgNACgGIAEgDIAjgBQAGAGgEAQIAABLQAHAGAAARIAACHg");
        this.shape_47.setTransform(66.1, 30);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#671203").s().p("AgyCWIAAicQgBgKAHgKIAGgIIAAhZQgFgQAGgGQACgDAEgBIBDAAQAIADgCAMQgBAFgCAFIAABYQANAIAAAUIAACeg");
        this.shape_48.setTransform(65.8, 30);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f("#671203").s().p("AgyCWIAAicQgBgKAHgKIAGgIIAAhZQgFgQAFgGIAGgEIBDAAQAIADgCAMQAAAFgDAFIAABYQANAIAAAUIAACeg");
        this.shape_49.setTransform(-62.6, 30);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f("#671203").s().p("AjXAMIgBgQQABgFAFgCIAGAAIGlABIAAAWg");
        this.shape_50.setTransform(-88.2, 23.2);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f("#671203").s().p("AjVAMQgBgEABgKIACgLIGmACQAFAEgDAVg");
        this.shape_51.setTransform(90.3, 24.6);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#671203").s().p("AjkAMQgGgDgBgKIgBgLIHIACQALAAAEALQACAGAAAGg");
        this.shape_52.setTransform(92.9, 27.9);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f("#671203").s().p("AjvAMIAAgNQAAgHAIgCIAIAAIHPABIAAAVg");
        this.shape_53.setTransform(-90.5, 26.6);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#671203").s().p("AgsACQgBAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQAAAAAAAAQABAAAAAAQABgBAAAAQABAAABAAIBZAAQABAAABAAQAAAAABABQAAAAABAAQAAAAAAAAQAAAAAAAAQgBABAAAAQgBAAAAABQgBAAgBAAg");
        this.shape_54.setTransform(1.3, 7.4);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f("#671203").s().p("AgqACQgBAAAAAAQgBgBAAAAQgBAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAgBABAAQAAAAABAAIBVAAQAAAAABAAQABAAAAABQABAAAAAAQAAAAAAAAQAAAAAAAAQAAABgBAAQAAAAgBABQgBAAAAAAg");
        this.shape_55.setTransform(1.4, 17.1);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f("#671203").s().p("AgBAeIAAg7QAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAABABAAQAAAAAAABIAAA7QAAABAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQAAAAAAgBg");
        this.shape_56.setTransform(5.5, 11.9);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f("#671203").s().p("AgBAeIAAg7QAAgBAAAAQABAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABIAAA7QAAABAAAAQAAAAgBABQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAQAAAAAAgBg");
        this.shape_57.setTransform(-2.5, 11.9);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#671203").s().p("AwwAJIAAgRMAhhAAAIAAARg");
        this.shape_58.setTransform(3.5, 50.4);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f("#671203").s().p("AsjAGIAAgLIZHAAIAAALg");
        this.shape_59.setTransform(1.3, 45.9);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#671203").s().p("Ao7AFIAIgJIRkAAIALAJg");
        this.shape_60.setTransform(1.6, 41.9);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f("#671203").s().p("AonAFIAHgJIQ9AAIAMAJg");
        this.shape_61.setTransform(1.5, 38);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f("#671203").s().p("AoWAEIAIgIIQaAAIALAIg");
        this.shape_62.setTransform(1.3, 34.2);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f("#671203").s().p("AoCAFIAHgJIPzAAIALAJg");
        this.shape_63.setTransform(1.2, 30.3);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#671203").s().p("AnsAFIAGgJIPJAAIAKAJg");
        this.shape_64.setTransform(1.3, 26.4);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f("#671203").s().p("AneAFIAHgJIOsAAIAKAJg");
        this.shape_65.setTransform(1.2, 23.2);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#671203").s().p("AkEAIIAAgKIAAgEQACgEAJgBIAHAAIH3AGQgGAFgFAMg");
        this.shape_66.setTransform(-92.8, 30);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f("#671203").s().p("Aj3AIQgBgEgGgHIgHgIIH4ABQAOAAAFAXg");
        this.shape_67.setTransform(96.2, 31.5);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f("#671203").s().p("ACKAtQghgdgagCQgHgBgKADQgUAGgLAXQgOgTgSgSQgpgigdACQgPACgPAHQggAOgCAWQgDACgGgCQgLgBgKgKQgQgUgVgOQgqgdgYAeQgWgigFAAIAAgQIIzAFIAOABQAOAFAAAOIAABLIgBAKQgJAcgUgCQgIgKgMgKQgXgTgRACQgLgBgLAFQgUAMADAgQgMgPgRgOg");
        this.shape_68.setTransform(100.7, 41.3);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f("#671203").s().p("AhPBBQgGgJgOgIQgbgOgnAKIg5AUQgEACgFAAQgJAAgBgLQgDgNgHgMQgQgXgbAGIAAhCQgBgEACgEQAEgHAOAAII6ADIAAA3IgWABQgXADgGAGQgDABgFAAQgKAAgIgJQgEgJgHgIQgOgQgSABIgKABQgMADgHAFIgIAFQgaALABAMQAEAPgMAAQgPgKgXgDQgsgIgiAfIgzAsQgDADgDAAQgFAAgGgEg");
        this.shape_69.setTransform(-97.4, 39.4);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#BB5932").s().p("At0AhQgIAAgGgFQgFgGAAgIIAAgbQAAgIAFgGQAGgFAIAAIbpAAQAIAAAGAFQAFAGAAAIIAAAbQAAAIgFAGQgGAFgIAAg");
        this.shape_70.setTransform(1.3, -71.6);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f("#671203").s().p("AgSAsQgKgGgFgMQgGgNAAgNQAAgNAGgMQAFgMALgHQAJgFAJAAQAQAAAJAHQAKAJACAMIgRAEQgCgHgFgEQgFgEgIAAQgJAAgGAIQgHAIAAAQQAAAQAHAJQAHAIAJAAQAFAAAGgDQAGgCADgDIAAgNIgUAAIAAgOIAlgBIABAmQgHAGgJAEQgLAFgKAAQgMAAgJgGg");
        this.shape_71.setTransform(146.5, 46.3);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#671203").s().p("AgSAsQgKgGgFgMQgGgNAAgNQAAgNAGgMQAFgMALgHQAJgFAJAAQAQAAAJAHQAKAJACAMIgRAEQgCgHgFgEQgFgEgIAAQgJAAgGAIQgHAIAAAQQAAAQAHAJQAHAIAJAAQAFAAAGgDQAGgCADgDIAAgNIgUAAIAAgOIAlgBIABAmQgHAGgJAEQgLAFgKAAQgMAAgJgGg");
        this.shape_72.setTransform(146.5, 46.3);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f("#671203").s().p("AgbAxIgBhgIA5gBIAAARIgoAAIAAAYIAigBIAAAOIghABIAAAqg");
        this.shape_73.setTransform(141.6, 40.7);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#671203").s().p("AgbAxIgBhgIA5gBIAAARIgoAAIAAAYIAigBIAAAOIghABIAAAqg");
        this.shape_74.setTransform(141.6, 40.7);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAvhFIABCJIgYAAIgxhZIABBaIgXAAIgBiJIAYAAIAxBbIgBhcg");
        this.shape_75.setTransform(-4.6, -91);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#671203").s().p("AgwhDIAYgBIAxBbIgBhbIAXAAIACCIIgZAAIgwhZIABBaIgYAAg");
        this.shape_76.setTransform(-4.7, -91.1);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAvhFIABCJIgYAAIgxhZIABBaIgXAAIgBiJIAYAAIAxBbIgBhcg");
        this.shape_77.setTransform(-4.6, -91);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.f("#671203").s().p("AgwhDIAYgBIAxBbIgBhbIAXAAIACCIIgZAAIgwhZIABBaIgYAAg");
        this.shape_78.setTransform(-4.7, -91.1);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag4BFIgCiJIAlAAIAVBcIAVhdIAlAAIABCJIgXAAIgBhrIgXBsIgWAAIgZhrIABBrg");
        this.shape_79.setTransform(26, -91);

        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.f("#671203").s().p("Ag6hDIAlgBIAVBcIAVhcIAlAAIABCIIgXAAIgBhrIgXBsIgWAAIgZhrIABBrIgWAAg");
        this.shape_80.setTransform(26, -91.1);

        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag4BFIgCiJIAlAAIAVBcIAVhdIAlAAIABCJIgXAAIgBhrIgXBsIgWAAIgZhrIABBrg");
        this.shape_81.setTransform(26, -91);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.f("#671203").s().p("Ag6hDIAlgBIAVBcIAVhcIAlAAIABCIIgXAAIgBhrIgXBsIgWAAIgZhrIABBrIgWAAg");
        this.shape_82.setTransform(26, -91.1);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgXhFIABBJQAAARABAHQACAJAGAEQAGAGAIgBQALAAAFgFQAFgEABgIIAAhjIAZAAIAABHQABAagCAKQgCAKgFAHQgGAIgJAEQgIAEgPAAQgPABgJgFQgKgEgFgIQgEgGgDgJQgCgOAAgVIgBhJg");
        this.shape_83.setTransform(10.2, -90.9);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.f("#671203").s().p("AgWBCQgKgEgFgIQgEgGgDgJQgCgOAAgVIgBhJIAYAAIABBJIABAYQACAJAGAEQAGAGAIgBQALAAAFgFQAFgEABgIIAAhjIAZAAIAABHQABAagCAKQgCAKgFAHQgGAIgJAEQgIAEgPAAIgDABQgNAAgIgFg");
        this.shape_84.setTransform(10.2, -90.9);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgXhFIABBJQAAARABAHQACAJAGAEQAGAGAIgBQALAAAFgFQAFgEABgIIAAhjIAZAAIAABHQABAagCAKQgCAKgFAHQgGAIgJAEQgIAEgPAAQgPABgJgFQgKgEgFgIQgEgGgDgJQgCgOAAgVIgBhJg");
        this.shape_85.setTransform(10.2, -90.9);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.f("#671203").s().p("AgWBCQgKgEgFgIQgEgGgDgJQgCgOAAgVIgBhJIAYAAIABBJIABAYQACAJAGAEQAGAGAIgBQALAAAFgFQAFgEABgIIAAhjIAZAAIAABHQABAagCAKQgCAKgFAHQgGAIgJAEQgIAEgPAAIgDABQgNAAgIgFg");
        this.shape_86.setTransform(10.2, -90.9);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAnA2QgFAIgJAEQgJAEgOAAQgPABgKgFQgIgEgGgIQgFgIgCgHQgDgMAAgXIAAhJIAYAAIABBJQABAWAAACQACAJAGAEQAGAGAIgBQALAAAEgFQAGgFABgHIAAhjIAYAAIABBHQAAAbgCAJQgBAKgGAHg");
        this.shape_87.setTransform(-20.2, -90.9);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.f("#671203").s().p("AgXBCQgIgEgGgIQgFgIgCgHQgDgMAAgXIAAhJIAYAAIABBJIABAYQACAJAGAEQAGAGAIgBQALAAAEgFQAGgFABgHIAAhjIAYAAIABBHQAAAbgCAJQgBAKgGAHQgFAIgJAEQgJAEgOAAIgEABQgNAAgIgFg");
        this.shape_88.setTransform(-20.2, -90.9);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAnA2QgFAIgJAEQgJAEgOAAQgPABgKgFQgIgEgGgIQgFgIgCgHQgDgMAAgXIAAhJIAYAAIABBJQABAWAAACQACAJAGAEQAGAGAIgBQALAAAEgFQAGgFABgHIAAhjIAYAAIABBHQAAAbgCAJQgBAKgGAHg");
        this.shape_89.setTransform(-20.2, -90.9);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.f("#671203").s().p("AgXBCQgIgEgGgIQgFgIgCgHQgDgMAAgXIAAhJIAYAAIABBJIABAYQACAJAGAEQAGAGAIgBQALAAAEgFQAGgFABgHIAAhjIAYAAIABBHQAAAbgCAJQgBAKgGAHQgFAIgJAEQgJAEgOAAIgEABQgNAAgIgFg");
        this.shape_90.setTransform(-20.2, -90.9);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAbAAQAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKg");
        this.shape_91.setTransform(44.3, -91);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.f("#671203").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_92.setTransform(44.3, -91);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAbAAQAAALgIAIQgIAIgLAAQgJAAgJgIQgIgIAAgLQAAgJAIgJQAJgIAJAAQALAAAIAIQAIAJAAAJg");
        this.shape_93.setTransform(-37.2, -91);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.f("#671203").s().p("AgSATQgIgIAAgLQAAgJAIgJQAJgIAJAAQALAAAIAIQAIAJAAAJQAAALgIAIQgIAIgLAAQgJAAgJgIg");
        this.shape_94.setTransform(-37.2, -91);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAbAAQAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKg");
        this.shape_95.setTransform(-37.2, -110.4);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.f("#671203").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_96.setTransform(-37.2, -110.4);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAngyQAEAIAAAJQAAAKgFAIQgEAIgHAEQAKADAGAIQAGAIAAAMQAAAKgEAJQgCAIgHAGQgGAFgKACQgIABgTAAIgnAAIgBiJIAuAAQAMAAAHABQAGABAGAFQAFAFAEAGgAARgSQADgEAAgHQAAgGgDgEQgDgEgGgBIggAAIABAgIAegBQAGgBAEgEgAgXAtIAWAAQAJAAAFgBQAGgCACgDQAEgEAAgIQAAgFgDgFQgDgEgEgCQgIgCgLAAIgTAAg");
        this.shape_97.setTransform(29.3, -110.2);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.f("#671203").s().p("AgwhEIAvAAQAMAAAHABQAGABAFAFQAGAFADAGQAEAIABAJQAAAKgFAIQgFAIgGAEQAKADAGAIQAGAIgBAMQABAKgEAJQgDAIgGAGQgHAFgKACIgaABIgoAAgAgXAtIAWAAIAOgBQAFgCADgDQAEgEAAgIQAAgFgDgFQgDgEgFgCQgHgCgMAAIgSAAgAgYgMIAfgBQAGgBAEgEQACgEAAgHQAAgGgCgEQgEgEgFgBIggAAg");
        this.shape_98.setTransform(29.3, -110.2);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAngyQAEAIAAAJQAAAKgFAIQgEAIgHAEQAKADAGAIQAGAIAAAMQAAAKgEAJQgCAIgHAGQgGAFgKACQgIABgTAAIgnAAIgBiJIAuAAQAMAAAHABQAGABAGAFQAFAFAEAGgAARgSQADgEAAgHQAAgGgDgEQgDgEgGgBIggAAIABAgIAegBQAGgBAEgEgAgXAtIAWAAQAJAAAFgBQAGgCACgDQAEgEAAgIQAAgFgDgFQgDgEgEgCQgIgCgLAAIgTAAg");
        this.shape_99.setTransform(29.3, -110.2);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.f("#671203").s().p("AgwhEIAvAAQAMAAAHABQAGABAFAFQAGAFADAGQAEAIABAJQAAAKgFAIQgFAIgGAEQAKADAGAIQAGAIgBAMQABAKgEAJQgDAIgGAGQgHAFgKACIgaABIgoAAgAgXAtIAWAAIAOgBQAFgCADgDQAEgEAAgIQAAgFgDgFQgDgEgFgCQgHgCgMAAIgSAAgAgYgMIAfgBQAGgBAEgEQACgEAAgHQAAgGgCgEQgEgEgFgBIggAAg");
        this.shape_100.setTransform(29.3, -110.2);

        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAHgLQAFgCACgEQACgFAAgGQAAgGgDgFQgDgEgGgBQgGgBgJABIgSAAIAAAjIARAAQAPAAAEgCgAAVhBQAJAEAFAJQAFAKAAAMQAAAQgHAKQgHAIgQADQAHAFAGAHQAFAHAIAPIAPAbIgcABIgcgzQgDgEgEgCQgFgBgHAAIgFAAIABA6IgYAAIgBiJIAxAAQASAAAHADg");
        this.shape_101.setTransform(10.4, -110.2);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.f("#671203").s().p("AgyBFIgCiJIAyAAQASAAAHADQAJAEAEAJQAGAKAAAMQAAAQgIAKQgHAIgPADQAGAFAHAHQAFAHAIAPIAOAbIgbABIgcgzQgDgEgEgCQgFgBgHAAIgFAAIABA6gAgbgJIARAAQAPAAAEgCQAFgCACgEQACgFgBgGQAAgGgCgFQgDgEgGgBIgPAAIgSAAg");
        this.shape_102.setTransform(10.3, -110.2);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAHgLQAFgCACgEQACgFAAgGQAAgGgDgFQgDgEgGgBQgGgBgJABIgSAAIAAAjIARAAQAPAAAEgCgAAVhBQAJAEAFAJQAFAKAAAMQAAAQgHAKQgHAIgQADQAHAFAGAHQAFAHAIAPIAPAbIgcABIgcgzQgDgEgEgCQgFgBgHAAIgFAAIABA6IgYAAIgBiJIAxAAQASAAAHADg");
        this.shape_103.setTransform(10.4, -110.2);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.f("#671203").s().p("AgyBFIgCiJIAyAAQASAAAHADQAJAEAEAJQAGAKAAAMQAAAQgIAKQgHAIgPADQAGAFAHAHQAFAHAIAPIAOAbIgbABIgcgzQgDgEgEgCQgFgBgHAAIgFAAIABA6gAgbgJIARAAQAPAAAEgCQAFgCACgEQACgFgBgGQAAgGgCgFQgDgEgGgBIgPAAIgSAAg");
        this.shape_104.setTransform(10.3, -110.2);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgKBFIgBiJIAVAAIACCJg");
        this.shape_105.setTransform(20, -110.2);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.f("#671203").s().p("AgKBFIgBiJIAVAAIACCJg");
        this.shape_106.setTransform(20, -110.2);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgKBFIgBiJIAVAAIACCJg");
        this.shape_107.setTransform(20, -110.2);

        this.shape_108 = new cjs.Shape();
        this.shape_108.graphics.f("#671203").s().p("AgKBFIgBiJIAVAAIACCJg");
        this.shape_108.setTransform(20, -110.2);

        this.shape_109 = new cjs.Shape();
        this.shape_109.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgQgZQAEAEAQAFQAQAEAJAGQAIAFAFAHQAFAJAAANQAAALgFAMQgGAKgKAFQgJAFgQABQgUAAgMgMQgMgMgDgYIAXgDQACAOAHAGQAGAHAJAAQALAAAGgGQAFgHAAgHQAAgEgCgEQgCgDgHgDIgRgGQgSgFgIgHQgKgLgBgRQAAgKAFgKQAFgJAJgFQAJgFAOAAQAUAAALALQAMAMAAATIgYABQgBgKgFgFQgFgFgIABQgLAAgFAFQgEADAAAFQAAAEAEAFg");
        this.shape_109.setTransform(54.9, -110.2);

        this.shape_110 = new cjs.Shape();
        this.shape_110.graphics.f("#671203").s().p("AgfA8QgMgMgDgYIAXgDQACAOAHAGQAGAHAJAAQALAAAGgGQAFgHAAgHQAAgEgCgEQgCgDgHgDIgRgGQgSgFgIgHQgKgLgBgRQAAgKAFgKQAFgJAJgFQAJgFAOAAQAUAAALALQAMAMAAATIgYABQgBgKgFgFQgFgFgIABQgLAAgFAFQgEADAAAFQAAAEAEAFQAEAEAQAFQAQAEAJAGQAIAFAFAHQAFAJAAANQAAALgFAMQgGAKgKAFQgJAFgQABQgUAAgMgMg");
        this.shape_110.setTransform(54.9, -110.2);

        this.shape_111 = new cjs.Shape();
        this.shape_111.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgQgZQAEAEAQAFQAQAEAJAGQAIAFAFAHQAFAJAAANQAAALgFAMQgGAKgKAFQgJAFgQABQgUAAgMgMQgMgMgDgYIAXgDQACAOAHAGQAGAHAJAAQALAAAGgGQAFgHAAgHQAAgEgCgEQgCgDgHgDIgRgGQgSgFgIgHQgKgLgBgRQAAgKAFgKQAFgJAJgFQAJgFAOAAQAUAAALALQAMAMAAATIgYABQgBgKgFgFQgFgFgIABQgLAAgFAFQgEADAAAFQAAAEAEAFg");
        this.shape_111.setTransform(54.9, -110.2);

        this.shape_112 = new cjs.Shape();
        this.shape_112.graphics.f("#671203").s().p("AgfA8QgMgMgDgYIAXgDQACAOAHAGQAGAHAJAAQALAAAGgGQAFgHAAgHQAAgEgCgEQgCgDgHgDIgRgGQgSgFgIgHQgKgLgBgRQAAgKAFgKQAFgJAJgFQAJgFAOAAQAUAAALALQAMAMAAATIgYABQgBgKgFgFQgFgFgIABQgLAAgFAFQgEADAAAFQAAAEAEAFQAEAEAQAFQAQAEAJAGQAIAFAFAHQAFAJAAANQAAALgFAMQgGAKgKAFQgJAFgQABQgUAAgMgMg");
        this.shape_112.setTransform(54.9, -110.2);

        this.shape_113 = new cjs.Shape();
        this.shape_113.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAtAlQgCAKgFAIQgFAHgJAEQgIAEgOABQgOAAgJgFQgJgEgFgIQgFgIgCgHQgCgOAAgVIgBhJIAYAAIABBhQADAJAFAFQAGAFAHAAQALgBAEgEQAFgGABgHQABgEAAgTIgBhLIAYgBIAABIQAAAZgBAKg");
        this.shape_113.setTransform(42.6, -110.1);

        this.shape_114 = new cjs.Shape();
        this.shape_114.graphics.f("#671203").s().p("AgVBCQgKgEgEgIQgGgIgBgHQgCgOgBgVIAAhJIAYAAIABBhQACAJAGAFQAGAFAHAAQALgBAEgEQAFgGABgHQABgEAAgTIgBhLIAXgBIABBIQAAAZgCAKQgBAKgGAIQgEAHgJAEQgIAEgOABQgPAAgIgFg");
        this.shape_114.setTransform(42.7, -110.1);

        this.shape_115 = new cjs.Shape();
        this.shape_115.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAtAlQgCAKgFAIQgFAHgJAEQgIAEgOABQgOAAgJgFQgJgEgFgIQgFgIgCgHQgCgOAAgVIgBhJIAYAAIABBhQADAJAFAFQAGAFAHAAQALgBAEgEQAFgGABgHQABgEAAgTIgBhLIAYgBIAABIQAAAZgBAKg");
        this.shape_115.setTransform(42.6, -110.1);

        this.shape_116 = new cjs.Shape();
        this.shape_116.graphics.f("#671203").s().p("AgVBCQgKgEgEgIQgGgIgBgHQgCgOgBgVIAAhJIAYAAIABBhQACAJAGAFQAGAFAHAAQALgBAEgEQAFgGABgHQABgEAAgTIgBhLIAXgBIABBIQAAAZgCAKQgBAKgGAIQgEAHgJAEQgIAEgOABQgPAAgIgFg");
        this.shape_116.setTransform(42.7, -110.1);

        this.shape_117 = new cjs.Shape();
        this.shape_117.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgthFIAXAAIABBKQAAAQABAHQACAIAFAGQAHAFAHAAQAKgBAFgEQAEgGACgHIAAhiIAXgBIABBIQABAZgDAKQgBAJgFAJQgGAHgIAEQgJAEgNABQgPAAgJgFQgIgEgFgIQgFgHgCgIQgCgJgBgag");
        this.shape_117.setTransform(-3.1, -110.1);

        this.shape_118 = new cjs.Shape();
        this.shape_118.graphics.f("#671203").s().p("AgWBCQgIgEgFgIQgFgHgCgIQgCgJgBgaIAAhJIAXAAIABBKIABAXQACAIAFAGQAHAFAHAAQAKgBAFgEQAEgGACgHIAAhiIAXgBIABBIQABAZgDAKQgBAJgFAJQgGAHgIAEQgJAEgNABQgPAAgJgFg");
        this.shape_118.setTransform(-3.1, -110.1);

        this.shape_119 = new cjs.Shape();
        this.shape_119.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgthFIAXAAIABBKQAAAQABAHQACAIAFAGQAHAFAHAAQAKgBAFgEQAEgGACgHIAAhiIAXgBIABBIQABAZgDAKQgBAJgFAJQgGAHgIAEQgJAEgNABQgPAAgJgFQgIgEgFgIQgFgHgCgIQgCgJgBgag");
        this.shape_119.setTransform(-3.1, -110.1);

        this.shape_120 = new cjs.Shape();
        this.shape_120.graphics.f("#671203").s().p("AgWBCQgIgEgFgIQgFgHgCgIQgCgJgBgaIAAhJIAXAAIABBKIABAXQACAIAFAGQAHAFAHAAQAKgBAFgEQAEgGACgHIAAhiIAXgBIABBIQABAZgDAKQgBAJgFAJQgGAHgIAEQgJAEgNABQgPAAgJgFg");
        this.shape_120.setTransform(-3.1, -110.1);

        this.shape_121 = new cjs.Shape();
        this.shape_121.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AApBDIhQABIgBiIIAYAAIABBwIA4AAg");
        this.shape_121.setTransform(-14.6, -110.1);

        this.shape_122 = new cjs.Shape();
        this.shape_122.graphics.f("#671203").s().p("AgohDIAYAAIABBvIA4AAIAAAYIhQAAg");
        this.shape_122.setTransform(-14.6, -110.2);

        this.shape_123 = new cjs.Shape();
        this.shape_123.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AApBDIhQABIgBiIIAYAAIABBwIA4AAg");
        this.shape_123.setTransform(-14.6, -110.1);

        this.shape_124 = new cjs.Shape();
        this.shape_124.graphics.f("#671203").s().p("AgohDIAYAAIABBvIA4AAIAAAYIhQAAg");
        this.shape_124.setTransform(-14.6, -110.2);

        this.shape_125 = new cjs.Shape();
        this.shape_125.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgUgsIABAnIANAAQAMAAAEgCQAEgCAEgFQACgFAAgGQAAgHgEgFQgEgGgFAAQgDgBgMAAgAgGhEQASAAAIACQAKADAIAKQAGAKABARQAAANgEAJQgEAGgGAGQgGAFgGABQgGACgRABIgPAAIAAA0IgXAAIgCiJg");
        this.shape_125.setTransform(-27, -110.4);

        this.shape_126 = new cjs.Shape();
        this.shape_126.graphics.f("#671203").s().p("AgqBFIgCiJIAmAAQASAAAIACQAKADAIAKQAGAKABARQAAANgEAJQgEAGgGAGQgGAFgGABQgGACgRABIgPAAIAAA0gAgTgFIANAAQAMAAAEgCQAEgCAEgFQACgFAAgGQAAgHgEgFQgEgGgFAAQgDgBgMAAIgMAAg");
        this.shape_126.setTransform(-27, -110.4);

        this.shape_127 = new cjs.Shape();
        this.shape_127.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgUgsIABAnIANAAQAMAAAEgCQAEgCAEgFQACgFAAgGQAAgHgEgFQgEgGgFAAQgDgBgMAAgAgGhEQASAAAIACQAKADAIAKQAGAKABARQAAANgEAJQgEAGgGAGQgGAFgGABQgGACgRABIgPAAIAAA0IgXAAIgCiJg");
        this.shape_127.setTransform(-27, -110.4);

        this.shape_128 = new cjs.Shape();
        this.shape_128.graphics.f("#671203").s().p("AgqBFIgCiJIAmAAQASAAAIACQAKADAIAKQAGAKABARQAAANgEAJQgEAGgGAGQgGAFgGABQgGACgRABIgPAAIAAA0gAgTgFIANAAQAMAAAEgCQAEgCAEgFQACgFAAgGQAAgHgEgFQgEgGgFAAQgDgBgMAAIgMAAg");
        this.shape_128.setTransform(-27, -110.4);

        this.shape_129 = new cjs.Shape();
        this.shape_129.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgUgNIA5gBIAAAWIg4ABIAAAlIA/gBIAAAYIhWABIgCiJIBVgBIAAAYIg9AAg");
        this.shape_129.setTransform(-47.2, -110.3);

        this.shape_130 = new cjs.Shape();
        this.shape_130.graphics.f("#671203").s().p("AgshDIBVgCIAAAYIg8ABIAAAfIA4gBIAAAVIg4ABIABAlIA+AAIAAAYIhWAAg");
        this.shape_130.setTransform(-47.3, -110.3);

        this.shape_131 = new cjs.Shape();
        this.shape_131.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgUgNIA5gBIAAAWIg4ABIAAAlIA/gBIAAAYIhWABIgCiJIBVgBIAAAYIg9AAg");
        this.shape_131.setTransform(-47.2, -110.3);

        this.shape_132 = new cjs.Shape();
        this.shape_132.graphics.f("#671203").s().p("AgshDIBVgCIAAAYIg8ABIAAAfIA4gBIAAAVIg4ABIABAlIA+AAIAAAYIhWAAg");
        this.shape_132.setTransform(-47.3, -110.3);

        this.shape_133 = new cjs.Shape();
        this.shape_133.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgTAUIBfgpIhlgWgACNgBIkCB4IgFg0IA7gbIgJheIg/gNIgFg0IEUBCg");
        this.shape_133.setTransform(152.6, -11.7);

        this.shape_134 = new cjs.Shape();
        this.shape_134.graphics.f("#671203").s().p("Ah6BEIA7gbIgJheIg/gNIgFg0IEUBBIAFA1IkCB3gAgTAVIBfgpIhlgXg");
        this.shape_134.setTransform(152.6, -11.8);

        this.shape_135 = new cjs.Shape();
        this.shape_135.graphics.f("#BB5932").s().p("Ah6BEIA7gbIgJheIg/gNIgFg0IEUBBIAFA1IkCB3gAgTAVIBfgpIhlgXg");
        this.shape_135.setTransform(152.6, -11.8);

        this.shape_136 = new cjs.Shape();
        this.shape_136.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgPg2QgxAQgQAWQgPAUAIAZQAFARASAKQARAJAegEIgCAxQgsAEgdgSQgcgQgLglQgPgrAagoQAZgoA9gTQA+gVAsASQAtASAPAvQANAogTAiQgLAUgdATIgagqQATgLAHgPQAHgQgGgRQgIgZgZgJQgagJgrAOg");
        this.shape_136.setTransform(149.9, -37.8);

        this.shape_137 = new cjs.Shape();
        this.shape_137.graphics.f("#671203").s().p("AhcBgQgcgQgLglQgPgrAagoQAZgoA9gTQA+gVAsASQAtASAPAvQANAogTAiQgLAUgdATIgagqQATgLAHgPQAHgQgGgRQgIgZgZgJQgagJgrAOQgxAQgQAWQgPAUAIAZQAFARASAKQARAJAegEIgCAxIgOABQgjAAgYgPg");
        this.shape_137.setTransform(149.9, -37.8);

        this.shape_138 = new cjs.Shape();
        this.shape_138.graphics.f("#BB5932").s().p("AhcBgQgcgQgLglQgPgrAagoQAZgoA9gTQA+gVAsASQAtASAPAvQANAogTAiQgLAUgdATIgagqQATgLAHgPQAHgQgGgRQgIgZgZgJQgagJgrAOQgxAQgQAWQgPAUAIAZQAFARASAKQARAJAegEIgCAxIgOABQgjAAgYgPg");
        this.shape_138.setTransform(149.9, -37.8);

        this.shape_139 = new cjs.Shape();
        this.shape_139.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ACCgUIjuBeIgVg2IDthdg");
        this.shape_139.setTransform(143.9, -54);

        this.shape_140 = new cjs.Shape();
        this.shape_140.graphics.f("#671203").s().p("AiBAUIDthdIAWA1IjuBeg");
        this.shape_140.setTransform(143.9, -54.1);

        this.shape_141 = new cjs.Shape();
        this.shape_141.graphics.f("#BB5932").s().p("AiBAUIDthdIAWA1IjuBeg");
        this.shape_141.setTransform(143.9, -54.1);

        this.shape_142 = new cjs.Shape();
        this.shape_142.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ACKASQgKAQgUAMQgZAOgYgEQgYgFgTgZQgCATgFAOQgEAMgRAgIgdAxIgcgyIAgg5QARgdAEgLQADgIgBgHQgBgIgIgOIgFgJIhdAyIgXgoIDdh7IAxBXQASAhACASQACAQgKASgABQg8IgRggIg5AgIARAeQARAeAGAEQAHAGAJAAQAJABAKgGQAMgFADgJQAEgJgEgLQgBgEgPgbg");
        this.shape_142.setTransform(133.8, -71.2);

        this.shape_143 = new cjs.Shape();
        this.shape_143.graphics.f("#671203").s().p("AhGBoIAgg5QARgeAEgKQADgIgBgHQgBgJgIgOIgFgIIhdAxIgXgnIDdh7IAxBXQASAgACATQACAQgKARQgKARgUAMQgZAOgYgFQgYgEgTgZQgCATgFAOQgEAMgRAgIgdAwgAAFg7IARAfQARAcAGAGQAHAFAJAAQAJABAKgFQAMgHADgHQAEgJgEgLQgBgFgPgaIgRggg");
        this.shape_143.setTransform(133.9, -71.4);

        this.shape_144 = new cjs.Shape();
        this.shape_144.graphics.f("#BB5932").s().p("AhGBoIAgg5QARgeAEgKQADgIgBgHQgBgJgIgOIgFgIIhdAxIgXgnIDdh7IAxBXQASAgACATQACAQgKARQgKARgUAMQgZAOgYgFQgYgEgTgZQgCATgFAOQgEAMgRAgIgdAwgAAFg7IARAfQARAcAGAGQAHAFAJAAQAJABAKgFQAMgHADgHQAEgJgEgLQgBgFgPgaIgRggg");
        this.shape_144.setTransform(133.9, -71.4);

        this.shape_145 = new cjs.Shape();
        this.shape_145.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AhXATIBFBfIgjAZIheiAIDLiUIBbB9IgjAXIhChYIgtAhIA+BSIgjAZIg8hSg");
        this.shape_145.setTransform(123.2, -90.9);

        this.shape_146 = new cjs.Shape();
        this.shape_146.graphics.f("#671203").s().p("AiTAKIDLiUIBbB9IgjAYIhBhZIgtAiIA9BSIgjAZIg7hSIg4AmIBFBeIgjAZg");
        this.shape_146.setTransform(123.2, -90.9);

        this.shape_147 = new cjs.Shape();
        this.shape_147.graphics.f("#BB5932").s().p("AiTAKIDLiUIBbB9IgjAYIhBhZIgtAiIA9BSIgjAZIg7hSIg4AmIBFBeIgjAZg");
        this.shape_147.setTransform(123.2, -90.9);

        this.shape_148 = new cjs.Shape();
        this.shape_148.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AiwAMICwi8IA3AzIhWCfICYhhIA4A0IixC8IgiggICKiUIiuByIgkghIBpi2IiNCUg");
        this.shape_148.setTransform(106.3, -109.1);

        this.shape_149 = new cjs.Shape();
        this.shape_149.graphics.f("#671203").s().p("AgiCRICKiUIiuByIgkghIBpi2IiNCUIgiggICxi8IA2AzIhWCfICYhhIA4A0IixC8g");
        this.shape_149.setTransform(106.3, -109.1);

        this.shape_150 = new cjs.Shape();
        this.shape_150.graphics.f("#BB5932").s().p("AgiCRICKiUIiuByIgkghIBpi2IiNCUIgiggICxi8IA2AzIhWCfICYhhIA4A0IixC8g");
        this.shape_150.setTransform(106.3, -109.1);

        this.shape_151 = new cjs.Shape();
        this.shape_151.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ACIh8IhFEUIgsgcIARg/IhOg1IgzAoIgrgdIDgisgAA0APIAbhlIhQBCg");
        this.shape_151.setTransform(81.1, -123.6);

        this.shape_152 = new cjs.Shape();
        this.shape_152.graphics.f("#671203").s().p("AAWB8IAQg+IhOg2IgyApIgsgdIDgisIAtAdIhGEUgAgCgUIA1AjIAbhkg");
        this.shape_152.setTransform(81.3, -123.7);

        this.shape_153 = new cjs.Shape();
        this.shape_153.graphics.f("#BB5932").s().p("AAWB8IAQg+IhOg2IgyApIgsgdIDgisIAtAdIhGEUgAgCgUIA1AjIAbhkg");
        this.shape_153.setTransform(81.3, -123.7);

        this.shape_154 = new cjs.Shape();
        this.shape_154.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA1A7IhYgiIgjBcIgsgRIBUjXICRA4IgOAlIhmgoIgTA0IBXAgg");
        this.shape_154.setTransform(62.3, -139.9);

        this.shape_155 = new cjs.Shape();
        this.shape_155.graphics.f("#671203").s().p("AhyBkIBUjYICRA5IgOAlIhmgoIgUAzIBYAhIgPAlIhXgjIgkBcg");
        this.shape_155.setTransform(62.3, -139.9);

        this.shape_156 = new cjs.Shape();
        this.shape_156.graphics.f("#BB5932").s().p("AhyBkIBUjYICRA5IgOAlIhmgoIgUAzIBYAhIgPAlIhXgjIgkBcg");
        this.shape_156.setTransform(62.3, -139.9);

        this.shape_157 = new cjs.Shape();
        this.shape_157.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgmAoQAKASATADQAQADAPgNQAQgNAFgfQAFgdgJgRQgJgRgTgEQgSgDgOANQgPANgGAfQgFAbAJATgAhKgLQAEgbALgRQAIgNALgJQALgJAMgDQAQgFARAEQAiAGARAcQAQAcgIApQgHArgZAVQgZAVghgGQgigGgRgcQgQgcAIgpg");
        this.shape_157.setTransform(43.8, -141.3);

        this.shape_158 = new cjs.Shape();
        this.shape_158.graphics.f("#671203").s().p("AgPBcQgigGgRgcQgQgcAIgpQAEgbALgRQAIgNALgJQALgJAMgDQAQgFARAEQAiAGARAcQAQAcgIApQgHArgZAVQgUAQgXAAIgPgBgAgVgyQgPANgGAfQgFAbAJATQAKASATADQAQADAPgNQAQgNAFgfQAFgdgJgRQgJgRgTgEIgIAAQgNAAgLAKg");
        this.shape_158.setTransform(43.8, -141.3);

        this.shape_159 = new cjs.Shape();
        this.shape_159.graphics.f("#BB5932").s().p("AgPBcQgigGgRgcQgQgcAIgpQAEgbALgRQAIgNALgJQALgJAMgDQAQgFARAEQAiAGARAcQAQAcgIApQgHArgZAVQgUAQgXAAIgPgBgAgVgyQgPANgGAfQgFAbAJATQAKASATADQAQADAPgNQAQgNAFgfQAFgdgJgRQgJgRgTgEIgIAAQgNAAgLAKg");
        this.shape_159.setTransform(43.8, -141.3);

        this.shape_160 = new cjs.Shape();
        this.shape_160.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAqgyQAAgTgIgLQgJgKgQgBQgQgCgLAJQgGAFgCAKQAAAKAFAHQAHAJAaAMQAeANAMAKQANAKAGARQAHARgDAaQgCAXgLASQgMATgSAIQgTAIgYgDQgmgEgSgYQgSgaABgsIAngBQACAaAJANQAKANASACQASACALgKQAKgJACgPQABgKgEgGQgDgHgKgGIgdgPQgggNgLgPQgRgXADggQADgUAKgQQAKgRARgHQASgIAVACQAmAEAQAYQARAWgCAlg");
        this.shape_160.setTransform(21.1, -150.3);

        this.shape_161 = new cjs.Shape();
        this.shape_161.graphics.f("#671203").s().p("AgJCHQgmgEgSgYQgSgaABgsIAngBQACAaAJANQAKANASACQASACALgKQAKgJACgPQABgKgEgGQgDgHgKgGIgdgPQgggNgLgPQgRgXADggQADgUAKgQQAKgRARgHQASgIAVACQAmAEAQAYQARAWgCAlIgpgCQAAgTgIgLQgJgKgQgBQgQgCgLAJQgGAFgCAKQAAAKAFAHQAHAJAaAMQAeANAMAKQANAKAGARQAHARgDAaQgCAXgLASQgMATgSAIQgOAGgSAAIgLgBg");
        this.shape_161.setTransform(21.1, -150.3);

        this.shape_162 = new cjs.Shape();
        this.shape_162.graphics.f("#BB5932").s().p("AgJCHQgmgEgSgYQgSgaABgsIAngBQACAaAJANQAKANASACQASACALgKQAKgJACgPQABgKgEgGQgDgHgKgGIgdgPQgggNgLgPQgRgXADggQADgUAKgQQAKgRARgHQASgIAVACQAmAEAQAYQARAWgCAlIgpgCQAAgTgIgLQgJgKgQgBQgQgCgLAJQgGAFgCAKQAAAKAFAHQAHAJAaAMQAeANAMAKQANAKAGARQAHARgDAaQgCAXgLASQgMATgSAIQgOAGgSAAIgLgBg");
        this.shape_162.setTransform(21.1, -150.3);

        this.shape_163 = new cjs.Shape();
        this.shape_163.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABKhRIhuABIAAA3IBngBIAAApIhmABIAABCIBzgBIAAArIidABIgCj3ICZgCg");
        this.shape_163.setTransform(1.8, -151.9);

        this.shape_164 = new cjs.Shape();
        this.shape_164.graphics.f("#671203").s().p("AhPh6ICZgCIAAAqIhuABIAAA4IBngBIAAAoIhmABIAABDIBzgBIAAAqIidACg");
        this.shape_164.setTransform(1.8, -151.9);

        this.shape_165 = new cjs.Shape();
        this.shape_165.graphics.f("#BB5932").s().p("AhPh6ICZgCIAAAqIhuABIAAA4IBngBIAAAoIhmABIAABDIBzgBIAAAqIidACg");
        this.shape_165.setTransform(1.8, -151.9);

        this.shape_166 = new cjs.Shape();
        this.shape_166.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA5B+Ig5AIIgZjPIhUALIgFgrIDfgcIAFAqIhUALg");
        this.shape_166.setTransform(-19, -150.9);

        this.shape_167 = new cjs.Shape();
        this.shape_167.graphics.f("#671203").s().p("AgZhIIhTAKIgGgrIDfgcIAGArIhVAKIAbDOIg5AIg");
        this.shape_167.setTransform(-19, -151);

        this.shape_168 = new cjs.Shape();
        this.shape_168.graphics.f("#BB5932").s().p("AgZhIIhTAKIgGgrIDfgcIAGArIhVAKIAbDOIg5AIg");
        this.shape_168.setTransform(-19, -151);

        this.shape_169 = new cjs.Shape();
        this.shape_169.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag1iVICnDmIgzAPIglg1IhaAbIgCBAIgyAPIANkbgAg/AWIA/gSIg8hVg");
        this.shape_169.setTransform(-34.1, -144.7);

        this.shape_170 = new cjs.Shape();
        this.shape_170.graphics.f("#671203").s().p("AhmiGIAzgOICmDmIgyAPIglg2IhbAbIgBBBIgyAOgAg9AXIA9gTIg6hVg");
        this.shape_170.setTransform(-34.2, -144.8);

        this.shape_171 = new cjs.Shape();
        this.shape_171.graphics.f("#BB5932").s().p("AhmiGIAzgOICmDmIgyAPIglg2IhbAbIgBBBIgyAOgAg9AXIA9gTIg6hVg");
        this.shape_171.setTransform(-34.2, -144.8);

        this.shape_172 = new cjs.Shape();
        this.shape_172.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABmhpIhMAlIBeC6Ig0AaIhbi6IhMAmIgTgnIDIhlg");
        this.shape_172.setTransform(-62, -139.8);

        this.shape_173 = new cjs.Shape();
        this.shape_173.graphics.f("#671203").s().p("AgYgpIhLAlIgTgnIDIhlIAUAnIhMAmIBeC6Ig0AZg");
        this.shape_173.setTransform(-62, -139.9);

        this.shape_174 = new cjs.Shape();
        this.shape_174.graphics.f("#BB5932").s().p("AgYgpIhLAlIgTgnIDIhlIAUAnIhMAmIBeC6Ig0AZg");
        this.shape_174.setTransform(-62, -139.9);

        this.shape_175 = new cjs.Shape();
        this.shape_175.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AhxhMQAIgSASgOQAdgXAdAGQAdAFAWAdIgdAbQgPgPgMgCQgNgBgNAKQgNAKgDAPQgBAJAHAIQAGAHAJACQALACAdgLQAcgLAQgBQAQgBATAJQARAJAQAUQAOAQAFAWQAFAVgHATQgJAUgUAPQgeAYgegGQgegGgfgiIAcgcQASATAQADQAQADAPgMQAPgMABgPQABgOgJgMQgGgIgIgCQgHgDgLACIghALQgfAMgTgEQgdgGgUgXQgMgPgFgVQgEgTAHgSg");
        this.shape_175.setTransform(-76.9, -127.9);

        this.shape_176 = new cjs.Shape();
        this.shape_176.graphics.f("#671203").s().p("AAZB+QgegGgfghIAcgdQASATAQADQAQADAPgMQAPgMABgPQABgNgJgNQgGgIgIgCQgHgDgLADIghAKQgfAMgTgEQgdgGgUgXQgMgPgFgUQgEgUAHgRQAIgTASgOQAdgXAdAGQAdAFAWAdIgdAbQgPgPgMgBQgNgCgNAKQgNALgDAOQgBAKAHAHQAGAIAJABQALACAdgLQAcgLAQgBQAQgBATAJQARAJAQAUQAOAQAFAWQAFAWgHASQgJAUgUAPQgYATgYAAIgMgBg");
        this.shape_176.setTransform(-76.9, -127.9);

        this.shape_177 = new cjs.Shape();
        this.shape_177.graphics.f("#BB5932").s().p("AAZB+QgegGgfghIAcgdQASATAQADQAQADAPgMQAPgMABgPQABgNgJgNQgGgIgIgCQgHgDgLADIghAKQgfAMgTgEQgdgGgUgXQgMgPgFgUQgEgUAHgRQAIgTASgOQAdgXAdAGQAdAFAWAdIgdAbQgPgPgMgBQgNgCgNAKQgNALgDAOQgBAKAHAHQAGAIAJABQALACAdgLQAcgLAQgBQAQgBATAJQARAJAQAUQAOAQAFAWQAFAWgHASQgJAUgUAPQgYATgYAAIgMgBg");
        this.shape_177.setTransform(-76.9, -127.9);

        this.shape_178 = new cjs.Shape();
        this.shape_178.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA7g9QgUgUgRgIQgPgHgLABQgNABgNAIQgJAGgWAXIgQARIB7B0IAbgcQAQgRAEgIQAGgLAAgMQAAgJgJgQQgKgRgVgTgABuBIIhEBIIi6iwIBBhFQAXgZAOgHQAVgMAVAAQAWgBAaALQAYALAaAZQAYAWALAWQAOAaAAAZQABAQgLAXQgHAPgUAWg");
        this.shape_178.setTransform(-103.2, -108.2);

        this.shape_179 = new cjs.Shape();
        this.shape_179.graphics.f("#671203").s().p("AiRgeIBBhGQAXgYAOgIQAVgMAWAAQAVAAAaALQAYAKAaAaQAYAWALAVQAOAbAAAZQABAQgLAXQgHAPgUAWIhEBHgAgFheQgNABgNAIQgJAGgWAYIgQARIB7B0IAbgdQAQgQAEgJQAGgLAAgLQAAgJgJgQQgKgSgVgTQgUgTgRgJQgOgGgKAAIgCAAg");
        this.shape_179.setTransform(-103.1, -108.4);

        this.shape_180 = new cjs.Shape();
        this.shape_180.graphics.f("#BB5932").s().p("AiRgeIBBhGQAXgYAOgIQAVgMAWAAQAVAAAaALQAYAKAaAaQAYAWALAVQAOAbAAAZQABAQgLAXQgHAPgUAWIhEBHgAgFheQgNABgNAIQgJAGgWAYIgQARIB7B0IAbgdQAQgQAEgJQAGgLAAgLQAAgJgJgQQgKgSgVgTQgUgTgRgJQgOgGgKAAIgCAAg");
        this.shape_180.setTransform(-103.1, -108.4);

        this.shape_181 = new cjs.Shape();
        this.shape_181.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgqANIA6hUIAjAZIg6BTIA0AmIBDhdIAjAWIhbCDIjKiOIBZh/IAiAZIhABcg");
        this.shape_181.setTransform(-115.3, -93.2);

        this.shape_182 = new cjs.Shape();
        this.shape_182.graphics.f("#671203").s().p("AiSgHIBZh/IAiAZIhABcIAtAeIA6hUIAjAZIg6BTIA0AmIBDhdIAjAWIhbCDg");
        this.shape_182.setTransform(-115.3, -93.2);

        this.shape_183 = new cjs.Shape();
        this.shape_183.graphics.f("#BB5932").s().p("AiSgHIBZh/IAiAZIhABcIAtAeIA6hUIAjAZIg6BTIA0AmIBDhdIAjAWIhbCDg");
        this.shape_183.setTransform(-115.3, -93.2);

        this.shape_184 = new cjs.Shape();
        this.shape_184.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgmgbIC2BkIgcAyIi1hlIgpBJIgmgUIBtjFIAkAVg");
        this.shape_184.setTransform(-129.1, -79.5);

        this.shape_185 = new cjs.Shape();
        this.shape_185.graphics.f("#671203").s().p("AhBAWIgpBJIgmgUIBtjFIAkAVIgmBKIC1BkIgcAyg");
        this.shape_185.setTransform(-129.2, -79.5);

        this.shape_186 = new cjs.Shape();
        this.shape_186.graphics.f("#BB5932").s().p("AhBAWIgpBJIgmgUIBtjFIAkAVIgmBKIC1BkIgcAyg");
        this.shape_186.setTransform(-129.2, -79.5);

        this.shape_187 = new cjs.Shape();
        this.shape_187.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABqBNIjqhlIAXg1IDqBlg");
        this.shape_187.setTransform(-135.4, -60);

        this.shape_188 = new cjs.Shape();
        this.shape_188.graphics.f("#671203").s().p("AiAgYIAXg0IDqBkIgXA1g");
        this.shape_188.setTransform(-135.4, -60);

        this.shape_189 = new cjs.Shape();
        this.shape_189.graphics.f("#BB5932").s().p("AiAgYIAXg0IDqBkIgXA1g");
        this.shape_189.setTransform(-135.4, -60);

        this.shape_190 = new cjs.Shape();
        this.shape_190.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ACGgVIi6BFICbAqIgOA0IjthBIAPg2IC+hFIifgrIAOg0IDtBBg");
        this.shape_190.setTransform(-141.6, -41.6);

        this.shape_191 = new cjs.Shape();
        this.shape_191.graphics.f("#671203").s().p("AiUBNIAPg2IC+hFIifgrIAOg0IDtBBIgPA3Ii6BFICbAqIgOA0g");
        this.shape_191.setTransform(-141.6, -41.6);

        this.shape_192 = new cjs.Shape();
        this.shape_192.graphics.f("#BB5932").s().p("AiUBNIAPg2IC+hFIifgrIAOg0IDtBBIgPA3Ii6BFICbAqIgOA0g");
        this.shape_192.setTransform(-141.6, -41.6);

        this.shape_193 = new cjs.Shape();
        this.shape_193.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAZgoIiOgUIAHg1ICHATQAvAHASAHQATAHALANQAMANAFAUQAGAUgFAdQgEAlgMARQgLASgPAKQgQAJgPABQgWACgrgGIiKgTIAHg0ICLATQAjAFAJgBQAQgBALgLQAMgLADgWQADgUgIgMQgHgNgNgEQgRgFgbgDg");
        this.shape_193.setTransform(-146.2, -17.3);

        this.shape_194 = new cjs.Shape();
        this.shape_194.graphics.f("#671203").s().p("AAABuIiLgTIAIg1ICKAUQAjAEAJAAQARgBALgLQALgMADgVQADgVgHgMQgHgMgOgFQgRgEgbgEIiNgUIAHg0ICGATQAvAHATAGQATAHALANQAMANAFAVQAFAUgEAcQgFAlgLASQgLARgQAKQgQAJgPACIgMAAQgVAAgfgEg");
        this.shape_194.setTransform(-146.1, -17.3);

        this.shape_195 = new cjs.Shape();
        this.shape_195.graphics.f("#BB5932").s().p("AAABuIiLgTIAIg1ICKAUQAjAEAJAAQARgBALgLQALgMADgVQADgVgHgMQgHgMgOgFQgRgEgbgEIiNgUIAHg0ICGATQAvAHATAGQATAHALANQAMANAFAVQAFAUgEAcQgFAlgLASQgLARgQAKQgQAJgPACIgMAAQgVAAgfgEg");
        this.shape_195.setTransform(-146.1, -17.3);

        this.shape_196 = new cjs.Shape();
        this.shape_196.graphics.f("#531002").s().p("Ag3EXIAGoCQgIgLgDgRIAAgQIB4AAQAFATgNAZIAEIDg");
        this.shape_196.setTransform(106.2, -5.3);

        this.shape_197 = new cjs.Shape();
        this.shape_197.graphics.f("#531002").s().p("Ag3EXIAGoCQgJgLgCgRIgBgQIB5AAQAFATgNAZIAEIDg");
        this.shape_197.setTransform(89.1, -5.3);

        this.shape_198 = new cjs.Shape();
        this.shape_198.graphics.f("#531002").s().p("Ag3EWIAGoBQgJgKgCgSIgBgQIB5AAQAFATgNAZIAEICg");
        this.shape_198.setTransform(70.6, -5.3);

        this.shape_199 = new cjs.Shape();
        this.shape_199.graphics.f("#531002").s().p("Ag3EVIAGn+QgIgLgDgSIgBgPIB5AAQAFASgNAaIAEH/g");
        this.shape_199.setTransform(50.9, -5.4);

        this.shape_200 = new cjs.Shape();
        this.shape_200.graphics.f("#531002").s().p("Ag3EVIAGn+QgIgLgDgSIgBgPIB5AAQAFASgNAaIAEH/g");
        this.shape_200.setTransform(31.8, -5.4);

        this.shape_201 = new cjs.Shape();
        this.shape_201.graphics.f("#531002").s().p("Ag3EVIAGn+QgIgLgDgSIgBgPIB5AAQAFASgNAaIAEH/g");
        this.shape_201.setTransform(12, -5.4);

        this.shape_202 = new cjs.Shape();
        this.shape_202.graphics.f("#531002").s().p("Ag3EVIAGn+QgJgLgCgSIgBgPIB5AAQAFASgNAaIAEH/g");
        this.shape_202.setTransform(-9.9, -5.4);

        this.shape_203 = new cjs.Shape();
        this.shape_203.graphics.f("#531002").s().p("Ag3EVIAGn+QgIgLgDgSIAAgPIB4AAQAGASgOAaIAEH/g");
        this.shape_203.setTransform(-28.7, -5.4);

        this.shape_204 = new cjs.Shape();
        this.shape_204.graphics.f("#531002").s().p("Ag3EVIAGn+QgJgLgCgSIgBgPIB5AAQAFASgNAaIAEH/g");
        this.shape_204.setTransform(-47.4, -5.4);

        this.shape_205 = new cjs.Shape();
        this.shape_205.graphics.f("#531002").s().p("Ag3EVIAGn+QgIgLgDgSIAAgPIB4AAQAGASgOAaIAEH/g");
        this.shape_205.setTransform(-67.5, -5.4);

        this.shape_206 = new cjs.Shape();
        this.shape_206.graphics.f("#531002").s().p("Ag3EVIAGn+QgJgKgCgSIgBgQIB5AAQAFASgNAaIAEH/g");
        this.shape_206.setTransform(-86.3, -5.5);

        this.shape_207 = new cjs.Shape();
        this.shape_207.graphics.f("#531002").s().p("Ag3EUIAGn8QgJgLgCgSIgBgPIB5AAQAFASgNAaIAEH9g");
        this.shape_207.setTransform(-102.8, -5.5);

        this.shape_208 = new cjs.Shape();
        this.shape_208.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgphPID2DkIguAyIj2jlIhDBHIgygtICzjCIAwAvg");
        this.shape_208.setTransform(102, 89);

        this.shape_209 = new cjs.Shape();
        this.shape_209.graphics.f("#671203").s().p("AhXgeIhDBHIgygtICzjCIAwAvIhABIID2DkIguAyg");
        this.shape_209.setTransform(102, 89);

        this.shape_210 = new cjs.Shape();
        this.shape_210.graphics.f("#BB5932").s().p("AhXgeIhDBHIgygtICzjCIAwAvIhABIID2DkIguAyg");
        this.shape_210.setTransform(102, 89);

        this.shape_211 = new cjs.Shape();
        this.shape_211.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAQjtIDFFYIg6AhIj1ieIB/DhIg0AfIjFlYIA5ggID5ChIiCjlg");
        this.shape_211.setTransform(73.2, 116.3);

        this.shape_212 = new cjs.Shape();
        this.shape_212.graphics.f("#671203").s().p("AjUhqIA5ggID5ChIiCjlIA0gfIDFFYIg6AhIj1ieIB/DhIg0Afg");
        this.shape_212.setTransform(73.2, 116.3);

        this.shape_213 = new cjs.Shape();
        this.shape_213.graphics.f("#BB5932").s().p("AjUhqIA5ggID5ChIiCjlIA0gfIDFFYIg6AhIj1ieIB/DhIg0Afg");
        this.shape_213.setTransform(73.2, 116.3);

        this.shape_214 = new cjs.Shape();
        this.shape_214.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABJiWIiaAnIAVBTICQgkIAPBAIiPAiIAZBmICggoIAPBBIjZA2Ihel4IDVg1g");
        this.shape_214.setTransform(40.9, 130.9);

        this.shape_215 = new cjs.Shape();
        this.shape_215.graphics.f("#671203").s().p("AibihIDUg1IAQBAIiaAnIAVBTICPgkIAQBAIiPAiIAZBmICfgoIAQBBIjZA2g");
        this.shape_215.setTransform(40.9, 130.9);

        this.shape_216 = new cjs.Shape();
        this.shape_216.graphics.f("#BB5932").s().p("AibihIDUg1IAQBAIiaAnIAVBTICPgkIAQBAIiPAiIAZBmICfgoIAQBBIjZA2g");
        this.shape_216.setTransform(40.9, 130.9);

        this.shape_217 = new cjs.Shape();
        this.shape_217.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgPiOQglAGgSAkQgTAjAKBKQAMBPAbAeQAbAfAigGQAbgEARgXQAQgZACguIBEAQQgGBIgeAkQgdAmg2AIQhAAJgygzQgzgzgNhiQgOhlAihAQAjg/BGgKQA7gIAsAoQAaAXASAwIg/AdQgKgfgWgQQgUgRgaAEg");
        this.shape_217.setTransform(7.1, 136.5);

        this.shape_218 = new cjs.Shape();
        this.shape_218.graphics.f("#671203").s().p("AhSCtQgygzgOhiQgOhlAjhAQAjg/BFgKQA7gIAtAoQAZAXATAwIg/AdQgLgfgVgQQgVgRgZAEQglAGgTAkQgSAjAKBKQALBPAbAeQAbAfAjgGQAbgEAQgXQARgZACguIBDAQQgFBIgeAkQgeAmg2AIIgUABQg0AAgqgrg");
        this.shape_218.setTransform(7.1, 136.5);

        this.shape_219 = new cjs.Shape();
        this.shape_219.graphics.f("#BB5932").s().p("AhSCtQgygzgOhiQgOhlAjhAQAjg/BFgKQA7gIAtAoQAZAXATAwIg/AdQgLgfgVgQQgVgRgZAEQglAGgTAkQgSAjAKBKQALBPAbAeQAbAfAjgGQAbgEAQgXQARgZACguIBDAQQgFBIgeAkQgeAmg2AIIgUABQg0AAgqgrg");
        this.shape_219.setTransform(7.1, 136.5);

        this.shape_220 = new cjs.Shape();
        this.shape_220.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AC1iHIgaA9IiZhBIggBQICNA7IgaA8IiNg8IgpBgICdBEIgaA9IjWhcICYllg");
        this.shape_220.setTransform(-41.6, 129.1);

        this.shape_221 = new cjs.Shape();
        this.shape_221.graphics.f("#671203").s().p("Ai0CFICYllIDRBZIgaA9IiZhBIggBQICNA7IgaA8IiMg8IgqBgICdBEIgZA9g");
        this.shape_221.setTransform(-41.6, 129.1);

        this.shape_222 = new cjs.Shape();
        this.shape_222.graphics.f("#BB5932").s().p("Ai0CFICYllIDRBZIgaA9IiZhBIggBQICNA7IgaA8IiMg8IgqBgICdBEIgZA9g");
        this.shape_222.setTransform(-41.6, 129.1);

        this.shape_223 = new cjs.Shape();
        this.shape_223.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA0jKIgfEpICSjeIA0AiIjZFMIg3glIAekjIiPDZIg0giIDZlMg");
        this.shape_223.setTransform(-76.6, 109.8);

        this.shape_224 = new cjs.Shape();
        this.shape_224.graphics.f("#671203").s().p("Ag1DKIAekjIiPDZIg0giIDZlMIA1AkIgfEpICSjeIA0AiIjZFMg");
        this.shape_224.setTransform(-76.6, 109.8);

        this.shape_225 = new cjs.Shape();
        this.shape_225.graphics.f("#BB5932").s().p("Ag1DKIAekjIiPDZIg0giIDZlMIA1AkIgfEpICSjeIA0AiIjZFMg");
        this.shape_225.setTransform(-76.6, 109.8);

        this.shape_226 = new cjs.Shape();
        this.shape_226.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABvhiQgcgegsAGQgqAGg4AyQg2AxgLArQgLAsAbAeQAbAdAsgGQArgGA4gzQA3gxALgpQAKgrgbgfgABqB3QhNBFhHAIQhIAHgxg2Qgyg2APhIQAOhFBNhFQAxgsArgTQAdgOAhgDQAggDAaAJQAgALAcAeQAxA2gPBIQgPBGhOBHg");
        this.shape_226.setTransform(-106.3, 84);

        this.shape_227 = new cjs.Shape();
        this.shape_227.graphics.f("#671203").s().p("AijCVQgyg2APhIQAOhFBNhFQAxgsArgTQAdgOAhgDQAggDAaAJQAgALAcAeQAxA2gPBIQgPBGhOBHQhNBFhHAIIgRABQg9AAgrgwgAAnh6QgqAGg4AyQg2AxgLArQgLAsAbAeQAbAdAsgGQArgGA4gzQA3gxALgpQAKgrgbgfQgYgZgiAAIgOABg");
        this.shape_227.setTransform(-106.3, 84);

        this.shape_228 = new cjs.Shape();
        this.shape_228.graphics.f("#BB5932").s().p("AijCVQgyg2APhIQAOhFBNhFQAxgsArgTQAdgOAhgDQAggDAaAJQAgALAcAeQAxA2gPBIQgPBGhOBHQhNBFhHAIIgRABQg9AAgrgwgAAnh6QgqAGg4AyQg2AxgLArQgLAsAbAeQAbAdAsgGQArgGA4gzQA3gxALgpQAKgrgbgfQgYgZgiAAIgOABg");
        this.shape_228.setTransform(-106.3, 84);

        this.shape_229 = new cjs.Shape();
        this.shape_229.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AxWi3MAifAAOQAVAAAFAPQADAJgCAIIAVAAQAcAAAFAQQACAHgDAIIARAAQAbAAAGATQADAIgCAKIA1AAQAUAAAEAPQADAIgCAIIAABgIAWAFQAXAJAGAUIANAVQAPAWAPAJIAPAAIAIABQAJAEAAAIIAAAVQAAAGgPAAMgsRgAdQgEABgDgBQgIgDAAgIIAAgSQABgCAEgDQAGgEALAAIAMAAQgCgOAOgLIAngcQgCgDgBgFQgBgJAJgFIAhgbIADgIIAAhKQAAgGADgGQAGgLASAAIA6AAIAAgOQAAgEACgEQAEgJAOAAIAYAAIAAgOQgCgFACgEQADgKAQAAIAZAAIAAgNQAAgEADgEQAHgIAMAAg");
        this.shape_229.setTransform(1.6, 39.3);

        this.shape_230 = new cjs.Shape();
        this.shape_230.graphics.f("#531002").s().p("A2ICbIgHgBQgIgCAAgJIAAgRIAFgFQAGgEALgBIAMAAQgCgNAOgMIAngbQgCgEgBgEQgBgJAJgFIAhgbIADgIIAAhLQAAgFADgGQAGgLASAAIA6AAIAAgOQAAgEACgFQAEgIAOgBIAYAAIAAgNQgCgFACgEQADgKAQABIAZAAIAAgOQAAgEADgEQAHgIAMAAMAifAANQAVABAFAQQADAHgCAJIAVAAQAcAAAFAPQACAIgDAIIARAAQAbAAAGASQADAJgCAJIA1AAQAUABAEAQQADAHgCAIIAABfIAWAGQAXAJAGATIANAWQAPAWAPAIIAPAAIAIACQAJADAAAJIAAAVQAAAGgPAAg");
        this.shape_230.setTransform(1.6, 39.3);

        this.shape_231 = new cjs.Shape();
        this.shape_231.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AbCAAQAAFgiIFBQiEE3jvDvQjvDvk3CEQlBCIlgAAQleAAlCiIQk3iEjvjvQjvjviEk3QiIlBAAlgQAAleCIlCQCEk2DvjwQDwjvE2iEQFCiIFeAAQFgAAFBCIQE3CEDvDvQDvDwCEE2QCIFCAAFeg");
        this.shape_231.setTransform(0.5, 0);

        this.shape_232 = new cjs.Shape();
        this.shape_232.graphics.f("#BB5932").s().p("AqgY6Qk3iEjvjvQjvjviEk3QiIlBAAlgQAAleCIlCQCEk2DvjwQDwjvE2iEQFCiIFeAAQFgAAFBCIQE3CEDvDvQDvDwCEE2QCIFCAAFeQAAFgiIFBQiEE3jvDvQjvDvk3CEQlBCIlgAAQleAAlCiIg");
        this.shape_232.setTransform(0.5, 0);

        this.shape_233 = new cjs.Shape();
        this.shape_233.graphics.f().s("#671203").ss(2, 0, 0, 4).p("Ab3AAQAAFriMFLQiHFAj3D3Qj3D3lACHQlLCMlrAAQlpAAlMiMQlAiHj3j3Qj3j3iHlAQiMlLAAlrQAAlpCMlMQCHlAD3j3QD3j3FAiHQFMiMFpAAQFrAAFLCMQFACHD3D3QD3D3CHFAQCMFMAAFpg");
        this.shape_233.setTransform(0.5, 0);

        this.shape_234 = new cjs.Shape();
        this.shape_234.graphics.f("#531002").s().p("Aq1ZrQlAiHj3j3Qj3j3iHlAQiMlLAAlrQAAlpCMlMQCHlAD3j3QD3j3FAiHQFMiMFpAAQFrAAFLCMQFACHD3D3QD3D3CHFAQCMFMAAFpQAAFriMFLQiHFAj3D3Qj3D3lACHQlLCMlrAAQlpAAlMiMg");
        this.shape_234.setTransform(0.5, 0);

        this.addChild(this.shape_234, this.shape_233, this.shape_232, this.shape_231, this.shape_230, this.shape_229, this.shape_228, this.shape_227, this.shape_226, this.shape_225, this.shape_224, this.shape_223, this.shape_222, this.shape_221, this.shape_220, this.shape_219, this.shape_218, this.shape_217, this.shape_216, this.shape_215, this.shape_214, this.shape_213, this.shape_212, this.shape_211, this.shape_210, this.shape_209, this.shape_208, this.shape_207, this.shape_206, this.shape_205, this.shape_204, this.shape_203, this.shape_202, this.shape_201, this.shape_200, this.shape_199, this.shape_198, this.shape_197, this.shape_196, this.shape_195, this.shape_194, this.shape_193, this.shape_192, this.shape_191, this.shape_190, this.shape_189, this.shape_188, this.shape_187, this.shape_186, this.shape_185, this.shape_184, this.shape_183, this.shape_182, this.shape_181, this.shape_180, this.shape_179, this.shape_178, this.shape_177, this.shape_176, this.shape_175, this.shape_174, this.shape_173, this.shape_172, this.shape_171, this.shape_170, this.shape_169, this.shape_168, this.shape_167, this.shape_166, this.shape_165, this.shape_164, this.shape_163, this.shape_162, this.shape_161, this.shape_160, this.shape_159, this.shape_158, this.shape_157, this.shape_156, this.shape_155, this.shape_154, this.shape_153, this.shape_152, this.shape_151, this.shape_150, this.shape_149, this.shape_148, this.shape_147, this.shape_146, this.shape_145, this.shape_144, this.shape_143, this.shape_142, this.shape_141, this.shape_140, this.shape_139, this.shape_138, this.shape_137, this.shape_136, this.shape_135, this.shape_134, this.shape_133, this.shape_132, this.shape_131, this.shape_130, this.shape_129, this.shape_128, this.shape_127, this.shape_126, this.shape_125, this.shape_124, this.shape_123, this.shape_122, this.shape_121, this.shape_120, this.shape_119, this.shape_118, this.shape_117, this.shape_116, this.shape_115, this.shape_114, this.shape_113, this.shape_112, this.shape_111, this.shape_110, this.shape_109, this.shape_108, this.shape_107, this.shape_106, this.shape_105, this.shape_104, this.shape_103, this.shape_102, this.shape_101, this.shape_100, this.shape_99, this.shape_98, this.shape_97, this.shape_96, this.shape_95, this.shape_94, this.shape_93, this.shape_92, this.shape_91, this.shape_90, this.shape_89, this.shape_88, this.shape_87, this.shape_86, this.shape_85, this.shape_84, this.shape_83, this.shape_82, this.shape_81, this.shape_80, this.shape_79, this.shape_78, this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-177.8, -178.3, 356.8, 356.8);


    (lib.Cara_MC = function () {
        this.initialize();

        // penny_front
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#531002").ss(1, 0, 0, 4, true).p("AodrAIgBALQAEAPASAUQA6BCC6BjIA5AiQBFArBAAvQDLCUBLB+IBQCGQBUCRARAsIBCCtQBIDDAZBsQAHACAAgQQgch2g3ieQhtk8iEjDQgHgPgFgVQgIgsARghIgPAWQgPAYgBAOQhQhOh5hlQj1jJjWhzQg3gngLgUg");
        this.shape.setTransform(8, 72.9);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#BB5932").s().p("AIYLAQgZhshIjDIhCitQgRgshUiRIhQiGQhLh+jLiUQhAgvhFgrIg5giQi6hjg6hCQgSgUgEgPIABgLQALAUA3AnQDWBzD1DJQB5BlBQBOQABgOAPgYIAPgWQgRAhAIAsQAFAVAHAPQCEDDBtE8QA3CeAcB2QAAAPgGAAIgBgBg");
        this.shape_1.setTransform(8, 72.9);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#671203").ss(0.5, 0, 0, 4).p("AgygPIAigSQAkgNAaAWQgOAFgNABIAMATQAGAYgZAJQAEgHACgLQAFgTgKgPQg2AGgJgDg");
        this.shape_2.setTransform(40.9, -59.6);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#BB5932").s().p("AAVATQAEgUgKgPQg2AGgIgCIAhgSQAlgOAZAWQgNAFgOABIAMAUQAHAXgaAKQAFgIACgKg");
        this.shape_3.setTransform(40.7, -59.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AATgdQgFgJgLAHQgFAFgHAKQgNARADAYIAMgTQANgUANgLQACgCgCgCg");
        this.shape_4.setTransform(-41.1, -107.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#BB5932").s().p("AgJgLQAHgKAFgFQALgHAFAJQABAAAAABQAAAAAAABQAAABAAAAQgBABAAAAQgNALgNAUIgMATQgDgYANgRg");
        this.shape_5.setTransform(-41.1, -108);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AAEgqIAHAqQAAArgeAGIAUgBQAXgIALggIAAgFQACgjgNgLQgFgEgFgCQgKgDAAAKg");
        this.shape_6.setTransform(-31, -113.3);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#BB5932").s().p("AADAAIgFgqQAAgJAIADIAKAFQANALgCAjIAAAFQgLAggVAIIgWACQAegGAAgsg");
        this.shape_7.setTransform(-30.2, -113.3);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AAIgxQgngCgNANIAjAUQAjAZAGAmQALgKAEgRQAGgggoghg");
        this.shape_8.setTransform(41.7, -110.4);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#BB5932").s().p("AgKgQIgjgTQANgOAnACIAFACQAoAhgHAgQgDARgMALQgGgngigZg");
        this.shape_9.setTransform(41.8, -110.7);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AAxglQgDgDgDgBQgGgBgGAKQgHARgMAQQgXAjgbABIAGADQAIADAJgCQAdgHAlg4QADgKgFgFg");
        this.shape_10.setTransform(7.1, -119);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("#BB5932").s().p("AgnAoIgGgDQAbgBAXgjQANgQAHgRQAGgKAFABQADABAEADQAFAFgDAKQglA4gdAHIgIABQgFAAgFgCg");
        this.shape_11.setTransform(7.8, -119);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#671203").ss(1, 0, 0, 4).p("ABBABQgWgEgcgEQg1gHgZALQgBAAAAACQgCALAWAAIAsABQAvgBASgJg");
        this.shape_12.setTransform(49.4, -18.8);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#BB5932").s().p("AgsAKQgWAAACgLQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAZgLA1AHQAcAEAWAEQgSAJgvABg");
        this.shape_13.setTransform(49.4, -18.8);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AAchPIgPA1QgTA7gbAkIAagLQAbgVASgrQAFgJABgNQACgbgSgYg");
        this.shape_14.setTransform(43.6, -32.6);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#BB5932").s().p("AAIgUIAPg2QASAZgCAaQgBAOgFAIQgSAsgbAUIgaAMQAbgkATg7g");
        this.shape_15.setTransform(44.1, -33.2);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#531002").s().p("AgCgIIgIgXQAhAigPASIgUALQAOgQgEgYg");
        this.shape_16.setTransform(43, -59.5);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#531002").s().p("AAZgIQASADAKAGIhpAKQArgZAiAGg");
        this.shape_17.setTransform(40.7, -62.2);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#531002").ss(1, 0, 0, 4, true).p("AgPhJQBnBHA/A/QgBgBgCgBQiGiXjvhpIBAAiQBOArBEAvgACXA9IAAAAACXA9QBCBFASA9QgTg3hBhLg");
        this.shape_18.setTransform(-28.2, 53);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#BB5932").s().p("ACSBBQBCBFASA8QgSg2hChLgAgUhFQhEgvhNgrIhAgjQDuBpCHCYIACACQg/hBhnhFg");
        this.shape_19.setTransform(-27.8, 52.6);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#531002").ss(1, 0, 0, 4, true).p("ACUBKIn1j4IFACoQFKCpA6APQiihTgtgVg");
        this.shape_20.setTransform(-7.2, 16.1);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f("#BB5932").s().p("AghgIIlBioIH2D4QAtAVChBUQg5gQlKipg");
        this.shape_21.setTransform(-7.2, 16.3);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#531002").ss(1, 0, 0, 4, true).p("AnGlgIAmgRQAvgTA1gKQCnghCVBJIAlAdQAvAlApArQCHCJAqCLQABAGAEADQBBBEAHBGIAFArQAIAvAUATIATAfQATAnADAqQgRgdgSgmQglhMgIgwQAAgTgIgdQgRg5goguQgGgHgBgFQgchKgzhPQhbiMiAhaQgygbhQgPQiggeiPA6QgGAEgEACQgKAEgEgGg");
        this.shape_22.setTransform(-40.9, 116.7);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#BB5932").s().p("AGiFQQglhNgIgvQABgUgJgcQgQg5gogvQgGgHgCgFQgchJgzhPQhaiNiBhaQgxgahRgPQiggfiOA6IgKAGQgKAFgEgGIAlgSQAwgTA0gKQCoggCVBIIAlAdQAvAmApAqQCGCKAqCLQACAFAEAEQBBBDAHBGIAEAsQAJAvATATIAUAfQATAnADApQgRgcgTgmg");
        this.shape_23.setTransform(-41, 116);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#531002").ss(1, 0, 0, 4, true).p("AiqmBQgxgFgHACIgGAJQgEANAHAPIAqBUQA0BoA4BiQCvE3CKCKQABgSgIgMQhVhqhiiQQjBkeg7i5QgBgCgBgCQgBgEAFgDQAOgIA6AEQgSgBgSgCgAh6l8IgMgC");
        this.shape_24.setTransform(14, 112.3);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f("#BB5932").s().p("AhPg+Qg4hig0hoIgqhUQgHgPAEgNIAGgJQAHgCAxAFIAkAEQg6gFgOAIQgFADABAEIACAEQA7C5DBEeQBiCQBVBqQAIAMgBASQiKiKivk3g");
        this.shape_25.setTransform(14, 112);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AgKhLQATARAHANQAMAUgIAUQgDAFgJALQgIAKAAAJQgCAJACAPQADAWAAABQgUgJgEgTQgDgOAFgbQAIglgIgpQgBgEABgDQABgFAIAHg");
        this.shape_26.setTransform(-50.4, -37.9);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f("#BB5932").s().p("AgVAyQgDgNAFgcQAIglgIgpIAAgGQABgGAIAHQATASAHANQAMATgIAVQgDAFgJALQgIAJAAAJQgCAKACAPIADAXQgUgJgEgUg");
        this.shape_27.setTransform(-50.4, -38);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AgMiBQAMgGAGAIQAIANgHAQQgLAaABAOQADgFAJADQgIAIgCADQgHAHgCAHQgDAKAAAMQABANAFAEQAFgEAGgTQAJgQANADQgLAagGASQgJAjAGAVQADgKAHgJQAGgGAOgHQgKAbgDAVQgDAQABAMQABAGADAFQACADAFAGQgOAAgPgMQgMgLgFgOQgRgqgGgqQgEggACgRQAAgHAGgPQAGgNAAgIQgCgNAAgHQAAgMAEgIg");
        this.shape_28.setTransform(-25.9, -54.6);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f("#BB5932").s().p("AAFB4QgMgLgFgOQgRgqgGgqQgEggACgRQAAgHAGgPQAGgNAAgIIgCgUQAAgMAEgIIANgIQAMgGAGAIQAIANgHAQQgLAaABAOQADgFAJADIgLALQgGAHgCAHQgDAKAAAMQABANAFAEQAFgEAGgTQAJgQANADQgLAagGASQgJAjAGAVQADgKAHgJQAGgGAOgHQgKAbgDAVQgDAQABAMQABAGADAFIAHAJQgOAAgPgMg");
        this.shape_29.setTransform(-26.1, -54.6);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f().s("#BB5932").ss(1, 0, 0, 4, true).p("AiX27QhTAKhNAqQgHADgFAFQi5CMghAOQgeANgmAdQhLA6glBRIgIAUQgNAtgHAtQgMBKAJAwQAEAUABAGQAGA8gFAtQgCAZACAKQAMBVAZAqIAFA0QAMA6ApAaIALAuQARAvAeAEIgDAWQgDAcADAYQAKBNBAAOIAdAIQAbANgHAaIgDAFIgHAIIgYATQgOANgBANIgBAKQgRAzgVAqIjvGsIiADJQgqBQgNBHIgEANQgSA8gDA+QgHBsAtA/QAGAJAvAjQA9AtBIArQDaCDDZAtQACABCBANQCgALCigPQIIgvFukVQAPgMAEgRQAEgTgMgSQhahzhmh9QjNj5g/gxQiih+gWgNIAeABQAfgDADgWQABgCgEgOIgnhTQgEgIgHgIQgOgPgQADQgKACgFAAQgYgBgNgLQgWgTAKgpIAFgMIAqhRIAugDQAxgEAMgMIAfgDQAggIAIgWIAUgCQAWgGAKgSQAIgIAGgOQANgbgEgRQAFgKAEgMQAJgYgFgLIgHgLQgFgJgIgDQgMgBgFgBQhNgTALgkQACgFAFgCQAegJAGgXQABgCgCgLQgEgLACgIQACgMAMgDQAEgCADgFQAEgJgIgQQgHgNgDgSQgHgiASgUIAIgDIA4gGIArgPQAogWgSgjIhoidIgHgIQgTgSgJgTQgPgfAPgYQADgFABgFQAIgegGgaIhFjOQgEgKgCgEQgTglAVguQABgDAFgGQApgmgFgoIgDgSQgFgagNgZQgWgmgmgUIgPgKQgWgPgbgLQgogRgkAAQgOgHgSgIQglgOgWAAQgOgQgVgPQgpgdgiAIQhWAGgrgNQgLgDgFgBQgpgFgyAGg");
        this.shape_30.setTransform(3.3, 9.2);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f("#671203").s().p("AjaW7IiDgOQjZgtjaiDQhIgrg9gtQgvgjgGgJQgtg/AHhsQADg+ASg8IAEgNQANhHAqhQICAjJIDvmsQAVgqARgzIABgKQABgNAOgNIAYgTIAHgIIADgFQAHgagbgNIgdgIQhAgOgKhNQgDgYADgcIADgWQgegEgRgvIgLguQgpgagMg6IgFg0QgZgqgMhVQgCgKACgZQAFgtgGg8IgFgaQgJgwAMhKQAHgtANgtIAIgUQAlhRBLg6QAmgdAegNQAhgOC5iMQAFgFAHgDQBNgqBTgKQAygGApAFQAFABALADQArANBWgGQAigIApAdQAVAPAOAQQAWAAAlAOQASAIAOAHQAkAAAoARQAbALAWAPIAPAKQAmAUAWAmQANAZAFAaIADASQAFAogpAmQgFAGgBADQgVAuATAlIAGAOIBFDOQAGAagIAeQgBAFgDAFQgPAYAPAfQAJATATASIAHAIIBoCdQASAjgoAWIgrAPIg4AGIgIADQgSAUAHAiQADASAHANQAIAQgEAJQgDAFgEACQgMADgCAMQgCAIAEALQACALgBACQgGAXgeAJQgFACgCAFQgLAkBNATIARACQAIADAFAJIAHALQAFALgJAYQgEAMgFAKQAEARgNAbQgGAOgIAIQgKASgWAGIgUACQgIAWggAIIgfADQgMAMgxAEIguADIgqBRIgFAMQgKApAWATQANALAYABQAFAAAKgCQAQgDAOAPQAHAIAEAIIAnBTQAEAOgBACQgDAWgfADIgegBQAWANCiB+QA/AxDND5QBmB9BaBzQAMASgEATQgEARgPAMQluEVoIAvQhfAJhcAAQhEAAhDgFg");
        this.shape_31.setTransform(3.3, 9.2);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AhQA5IBZhWIgdggIASgSIBTBVIgTASIgfgfIhaBXg");
        this.shape_32.setTransform(118.4, -102.5);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f("#671203").s().p("AhQA5IBahWIgeggIASgSIBTBWIgSARIgggeIhaBWg");
        this.shape_33.setTransform(118.4, -102.6);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#BB5932").s().p("AhQA5IBahWIgeggIASgSIBTBWIgSARIgggeIhaBWg");
        this.shape_34.setTransform(118.4, -102.6);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AACglQABAIAOASQAOATAEAJQAFALgCAMQgCAMgJALQgJAKgNAEQgLAEgNgEQgPgFgPgNQgWgTgDgUQgDgTAOgVIAZARQgHAMABALQACAKALAJQALAKAKAAQAKAAADgGQAEgEAAgFQAAgFgEgIIgNgVQgOgRgDgPQgCgSALgOQAIgJAKgDQALgEANAEQANAEANALQAWATADATQADAUgNAOIgYgRQAGgLgCgIQgBgIgKgIQgKgJgKgBQgGAAgEAEQgDAEABAGg");
        this.shape_35.setTransform(102, -114.8);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#671203").s().p("AgTBNQgPgFgPgNQgWgTgDgUQgDgTAOgVIAZARQgHAMABALQACAKALAJQALAKAKAAQAKAAADgGQAEgEAAgFQAAgFgEgIIgNgVQgOgRgDgPQgCgSALgOQAIgJAKgDQALgEANAEQANAEANALQAWATADATQADAUgNAOIgYgRQAGgLgCgIQgBgIgKgIQgKgJgKgBQgGAAgEAEQgDAEABAGQABAIAOASQAOATAEAJQAFALgCAMQgCAMgJALQgJAKgNAEQgFACgGAAQgHAAgGgCg");
        this.shape_36.setTransform(102, -114.8);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f("#BB5932").s().p("AgTBNQgPgFgPgNQgWgTgDgUQgDgTAOgVIAZARQgHAMABALQACAKALAJQALAKAKAAQAKAAADgGQAEgEAAgFQAAgFgEgIIgNgVQgOgRgDgPQgCgSALgOQAIgJAKgDQALgEANAEQANAEANALQAWATADATQADAUgNAOIgYgRQAGgLgCgIQgBgIgKgIQgKgJgKgBQgGAAgEAEQgDAEABAGQABAIAOASQAOATAEAJQAFALgCAMQgCAMgJALQgJAKgNAEQgFACgGAAQgHAAgGgCg");
        this.shape_37.setTransform(102, -114.8);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgUhXIAZARIg4BaQgDAJADAJQAEAJALAHQALAHAJgBQAIAAAGgGQAFgJAIgNIAuhFIAbARIgsBCQgOAXgJAIQgJAJgIADQgLACgLgCQgMgDgQgJQgSgNgIgKQgHgMgBgJQgBgLADgIQAFgOANgTg");
        this.shape_38.setTransform(84.7, -128);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f("#671203").s().p("AgVBYQgNgDgPgJQgSgNgIgKQgHgMgBgJQgBgLACgIQAFgNAOgUIAshEIAZARIg4BaQgDAJADAJQADAJALAHQAMAHAIgBQAIAAAHgGQAFgJAIgNIAuhFIAbARIgsBCQgPAXgIAIQgJAJgJADIgKABIgLgBg");
        this.shape_39.setTransform(84.6, -127.9);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#BB5932").s().p("AgVBYQgNgDgPgJQgSgNgIgKQgHgMgBgJQgBgLACgIQAFgNAOgUIAshEIAZARIg4BaQgDAJADAJQADAJALAHQAMAHAIgBQAIAAAHgGQAFgJAIgNIAuhFIAbARIgsBCQgPAXgIAIQgJAJgJADIgKABIgLgBg");
        this.shape_40.setTransform(84.6, -127.9);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABDg4QAJAHADANQACAMgFANQgGAPgNAGQgNAHgUgEQAHAJAEAJQAEAJADAUIAHAiIgigMIgPhCQgCgGgEgDQgEgDgKgEIgFgBIgXA6IgdgLIA2iNIA6AXQAXAJAJAHgAAcgHQAHAAAEgEQAFgDACgGQADgIgDgFQgCgHgGgDIgpgRIgOAlIATAIQATAHAHABg");
        this.shape_41.setTransform(64.3, -138.3);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#671203").s().p("AAOBSIgOhBQgDgHgEgCQgEgEgKgEIgFAAIgXA6IgdgLIA2iNIA6AXQAXAJAJAHQAJAHADANQACALgFAOQgGAOgNAHQgNAHgUgEQAHAIAEAKQAEAJADAUIAHAigAgSgXIATAIQATAIAHAAQAHAAAEgDQAFgEACgFQADgIgDgGQgCgGgGgEIgpgQg");
        this.shape_42.setTransform(64.4, -138.4);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#BB5932").s().p("AAOBSIgOhBQgDgHgEgCQgEgEgKgEIgFAAIgXA6IgdgLIA2iNIA6AXQAXAJAJAHQAJAHADANQACALgFAOQgGAOgNAHQgNAHgUgEQAHAIAEAKQAEAJADAUIAHAigAgSgXIATAIQATAIAHAAQAHAAAEgDQAFgEACgFQADgIgDgGQgCgGgGgEIgpgQg");
        this.shape_43.setTransform(64.4, -138.4);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag3BKIAmh3IgrgNIAHgZIByAkIgHAZIgsgOIgjB4g");
        this.shape_44.setTransform(45.5, -147);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#671203").s().p("Ag3BLIAmh4IgrgNIAHgZIByAkIgHAZIgsgOIgjB4g");
        this.shape_45.setTransform(45.5, -147.1);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#BB5932").s().p("Ag3BLIAmh4IgrgNIAHgZIByAkIgHAZIgsgOIgjB4g");
        this.shape_46.setTransform(45.5, -147.1);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA7guIhQgEIgCAiIBKAEIgBAYIhKgFIgCAqIBTAFIgCAZIhygGIAIiXIBvAGg");
        this.shape_47.setTransform(6.2, -152.9);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#671203").s().p("Ag7BJIAIiXIBvAGIgBAaIhQgEIgCAhIBKAFIgBAYIhLgFIgCAqIBTAEIgBAag");
        this.shape_48.setTransform(6.2, -152.9);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f("#BB5932").s().p("Ag7BJIAIiXIBvAGIgBAaIhQgEIgCAhIBKAFIgBAYIhLgFIgCAqIBTAEIgBAag");
        this.shape_49.setTransform(6.2, -152.9);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgKBRIgiAEIg2iRIAggEIAjBkIAPhqIAjgEIAnBlIALhrIAfgEIgTCaIghAEIgrhsg");
        this.shape_50.setTransform(-15.5, -152.4);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f("#671203").s().p("Ahig8IAggEIAiBkIAQhqIAjgEIAnBlIAKhrIAfgEIgSCaIgiAEIgrhsIgPBzIghAEg");
        this.shape_51.setTransform(-15.5, -152.4);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#BB5932").s().p("Ahig8IAggEIAiBkIAQhqIAjgEIAnBlIAKhrIAfgEIgSCaIgiAEIgrhsIgPBzIghAEg");
        this.shape_52.setTransform(-15.5, -152.4);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABWgBQABAQgGAQQgFALgMALQgKAIgQAGIg4AZIhBiXIA4gYQAUgJAJgBQAPgCAOAGQAOAGALANQAKALALAXQAHATACAQgAgbg1IgOAGIApBkIAXgKQALgEAHgFQAGgEAEgIQADgGgBgMQgBgJgIgTQgHgRgIgJQgGgHgJgEQgIgDgHACQgFABgVAIg");
        this.shape_53.setTransform(-53.8, -142.1);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#671203").s().p("AhUg6IA4gYQAUgJAJgBQAPgCAOAGQAOAGALANQAKALALAXQAHATACAQQABAQgGAQQgFALgMALQgKAIgQAGIg4AZgAgCg9QgFABgVAIIgOAGIAqBkIAWgKQALgEAHgFQAGgEAEgIQADgGgBgMQgBgJgIgTQgHgRgIgJQgGgHgJgEQgFgCgFAAIgFABg");
        this.shape_54.setTransform(-53.7, -142.2);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f("#BB5932").s().p("AhUg6IA4gYQAUgJAJgBQAPgCAOAGQAOAGALANQAKALALAXQAHATACAQQABAQgGAQQgFALgMALQgKAIgQAGIg4AZgAgCg9QgFABgVAIIgOAGIAqBkIAWgKQALgEAHgFQAGgEAEgIQADgGgBgMQgBgJgIgTQgHgRgIgJQgGgHgJgEQgFgCgFAAIgFABg");
        this.shape_55.setTransform(-53.7, -142.2);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AhJgtQAIgNASgMQAfgVAdAHQAfAHAXAhQAWAigFAdQgFAfgfAVQgfAVgdgHQgfgHgWghQgOgUgEgTQgCgMACgOQACgNAIgMgAAlgZQgPgXgTgGQgQgEgSALQgRAMgDATQgCARAQAYQAQAYATAFQASAEAQgLQAQgLADgUQADgRgRgYg");
        this.shape_56.setTransform(-72.8, -133.7);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f("#671203").s().p("AgMBVQgfgHgWghQgOgUgEgTQgCgMACgOQACgNAIgMQAIgNASgMQAfgVAdAHQAfAHAXAhQAWAigFAdQgFAfgfAVQgYAQgXAAQgGAAgHgCgAgfgvQgRAMgDATQgCARAQAYQAQAYATAFQASAEAQgLQAQgLADgUQADgRgRgYQgPgXgTgGIgIgBQgNAAgNAIg");
        this.shape_57.setTransform(-72.8, -133.7);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#BB5932").s().p("AgMBVQgfgHgWghQgOgUgEgTQgCgMACgOQACgNAIgMQAIgNASgMQAfgVAdAHQAfAHAXAhQAWAigFAdQgFAfgfAVQgYAQgXAAQgGAAgHgCgAgfgvQgRAMgDATQgCARAQAYQAQAYATAFQASAEAQgLQAQgLADgUQADgRgRgYQgPgXgTgGIgIgBQgNAAgNAIg");
        this.shape_58.setTransform(-72.8, -133.7);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAogGIgeAWIgQgUIA2guIAqAyQgBAPgLASQgKATgQANQgUARgWAEQgUADgUgJQgVgJgPgTQgRgTgFgYQgEgUAJgWQAHgRASgPQAYgUAWgBQATgBATAOIgWAbQgIgIgMABQgMABgLAJQgRAPgBASQgBASARAVQAUAXATADQASADAQgOQAJgHAFgKQAFgJADgKg");
        this.shape_59.setTransform(-90.4, -122.2);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#671203").s().p("AgeBQQgVgJgPgTQgRgTgFgYQgEgUAJgWQAHgRASgPQAYgUAWgBQATgBATAOIgWAbQgIgIgMABQgMABgLAJQgRAPgBASQgBASARAVQAUAXATADQASADAQgOQAJgHAFgKQAFgJADgKIgOgOIgeAWIgQgUIA2guIAqAyQgBAPgLASQgKATgQANQgUARgWAEIgKABQgPAAgPgHg");
        this.shape_60.setTransform(-90.4, -122.2);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f("#BB5932").s().p("AgeBQQgVgJgPgTQgRgTgFgYQgEgUAJgWQAHgRASgPQAYgUAWgBQATgBATAOIgWAbQgIgIgMABQgMABgLAJQgRAPgBASQgBASARAVQAUAXATADQASADAQgOQAJgHAFgKQAFgJADgKIgOgOIgeAWIgQgUIA2guIAqAyQgBAPgLASQgKATgQANQgUARgWAEIgKABQgPAAgPgHg");
        this.shape_61.setTransform(-90.4, -122.2);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgXhnICBBnIgVAaIh+gQIBTBFIgTAYIiAhnIAUgZICAARIhVhGg");
        this.shape_62.setTransform(-112.9, -101.6);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f("#671203").s().p("AhpAAIAUgYICBAQIhWhGIAUgZICABnIgVAaIh+gQIBTBFIgTAYg");
        this.shape_63.setTransform(-112.9, -101.7);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#BB5932").s().p("AhpAAIAUgYICBAQIhWhGIAUgZICABnIgVAaIh+gQIBTBFIgTAYg");
        this.shape_64.setTransform(-112.9, -101.7);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AA6A+IiGhfIATgcICGBfg");
        this.shape_65.setTransform(-123.9, -88.1);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#671203").s().p("AhMghIATgcICGBfIgTAcg");
        this.shape_66.setTransform(-123.9, -88.1);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f("#BB5932").s().p("AhMghIATgcICGBfIgTAcg");
        this.shape_67.setTransform(-123.9, -88.1);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag5hEIA0AAQAOAAAKADQALADAKAJQAIAKAFANQAFANAAASQAAAQgFANQgFAPgKAKQgIAIgLADQgJADgOAAIg1AAgAgdgtIAABaIAVAAQALAAAFgBQAFgBAFgFQAFgEADgJQACgIAAgRQAAgQgCgHQgDgKgFgEQgGgFgHgBQgFgCgQAAg");
        this.shape_68.setTransform(108.5, 90.2);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f("#671203").s().p("Ag4BFIAAiJIAyAAQAPAAAKADQAMADAJAJQAIAKAFANQAFANAAASQAAAQgFANQgFAPgJAKQgJAHgLAEQgKADgNAAgAgcAtIAUAAQALABAEgCQAHgBAEgFQAFgEADgJQACgIAAgRQAAgQgCgHQgDgKgFgDQgGgGgHgBQgFgCgQABIgMAAg");
        this.shape_69.setTransform(108.5, 90.2);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#BB5932").s().p("Ag4BFIAAiJIAyAAQAPAAAKADQAMADAJAJQAIAKAFANQAFANAAASQAAAQgFANQgFAPgJAKQgJAHgLAEQgKADgNAAgAgcAtIAUAAQALABAEgCQAHgBAEgFQAFgEADgJQACgIAAgRQAAgQgCgHQgDgKgFgDQgGgGgHgBQgFgCgQABIgMAAg");
        this.shape_70.setTransform(108.5, 90.2);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("Ag9APQAIgPASgHQgPgFgJgMQgHgKgBgOQgBgYAQgQQAQgQAdgBQAcgCARAPQARAPACAXQABAPgIALQgGALgOAHQARAGAKALQAKAOABARQABAdgRATQgSATgfABQgaACgUgPQgXgQgBgfQgBgRAHgOgAgdgvQABALAHAHQAHAGALAAQAKgBAGgHQAHgGgBgNQgBgLgGgGQgIgHgJABQgLABgHAGQgGAIAAALgAgSBCQAIAJALgBQANgBAHgJQAIgIgBgSQgBgPgIgIQgJgJgLABQgOABgHAKQgHAKABAMQABARAJAJg");
        this.shape_71.setTransform(129.5, 60.3);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#671203").s().p("AgqBdQgXgQgCgfQgBgRAIgOQAHgPASgHQgOgFgJgMQgIgKgBgOQgBgYAQgQQAQgQAegBQAbgCASAPQAQAPACAXQABAPgIALQgGALgOAHQARAGAKALQALAOAAARQABAdgRATQgSATgfABIgDAAQgYAAgSgNgAgBAHQgOABgHAKQgGAKAAAMQABARAJAJQAIAJAMgBQAMgBAHgJQAJgIgBgSQgBgPgJgIQgIgIgLAAIgBAAgAgEhJQgMABgGAGQgHAIAAALQABALAHAHQAHAGALAAQAKgBAGgHQAIgGgBgNQgBgLgHgGQgHgGgIAAIgBAAg");
        this.shape_72.setTransform(129.5, 60.3);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgChIQgIABgEAEQgGAFgCAMQgEAPACAkQACAlAEANQAEAOAGAEQAGAFAFgBQAGAAAHgFQAFgFADgMQADgPgCgkQgBghgFgRQgEgOgGgEQgGgEgFAAgAgDhpQAcgBASAUQAVAZADA8QADA5gTAbQgQAWgeABQgdACgUgXQgTgWgDg9QgDg5ATgaQAQgXAfgBg");
        this.shape_73.setTransform(113, 61.1);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#671203").s().p("AgsBVQgTgWgDg9QgDg5ATgaQAQgXAfgBQAcgBASAUQAVAZADA8QADA5gTAbQgQAWgeABIgEAAQgaAAgTgVgAgOhDQgGAFgCAMQgEAPACAkQACAlAEANQAEAOAGAEQAGAFAFgBQAGAAAHgFQAFgFADgMQADgPgCgkQgBghgFgRQgEgOgGgEQgGgEgFAAQgIABgEAEg");
        this.shape_74.setTransform(113, 61.1);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgChIQgGAAgGAFQgGAGgCALQgEAQACAjQACAkAEAPQAEANAGAEQAHAFAEgBQAHAAAGgFQAFgFADgMQADgPgCgkQgBgkgFgOQgEgOgGgEQgGgEgFAAgAArhWQAWAaACA7QADA5gTAbQgQAXgeAAQgdACgUgXQgTgWgDg8QgCg5ASgbQARgXAegBQAcgBASAUg");
        this.shape_75.setTransform(96.8, 61.8);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#671203").s().p("AgsBVQgTgWgDg8QgCg5ASgbQARgXAegBQAcgBASAUQAWAaACA7QADA5gTAbQgQAXgeAAIgEAAQgaAAgTgVgAgChIQgGAAgGAFQgGAGgCALQgEAPACAkQACAkAEAPQAEANAGAEQAHAFAEgBQAHAAAGgFQAFgFADgMQADgPgCgkQgBgkgFgOQgEgOgGgEQgFgEgEAAIgCAAg");
        this.shape_76.setTransform(96.8, 61.8);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgDhpQAdgBASAPQASARACAYQAAAQgEALQgFANgKANQgHAKgSARIgVAZQgFAHgDAEIBOgEIACAlIiKAHQAAgVALgUQAKgRAhgjQAXgXAHgKQAHgMAAgNQgBgOgIgHQgHgGgLAAQgNABgHAIQgHAIAAARIgogCQADghARgPQASgQAdgBg");
        this.shape_77.setTransform(80.8, 62.6);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.f("#671203").s().p("Ag4BBQAKgRAhgjQAXgXAHgKQAHgMAAgNQgBgOgIgHQgHgGgLAAQgNABgHAIQgHAIAAARIgogCQADghARgPQASgQAdgBQAdgBASAPQASARACAYQAAAQgEALQgFANgKANQgHAKgSARIgVAZIgIALIBOgEIACAlIiKAHQAAgVALgUg");
        this.shape_78.setTransform(80.8, 62.6);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.f("#BB5932").s().p("AgqBdQgXgQgCgfQgBgRAIgOQAHgPASgHQgOgFgJgMQgIgKgBgOQgBgYAQgQQAQgQAegBQAbgCASAPQAQAPACAXQABAPgIALQgGALgOAHQARAGAKALQALAOAAARQABAdgRATQgSATgfABIgDAAQgYAAgSgNgAgBAHQgOABgHAKQgGAKAAAMQABARAJAJQAIAJAMgBQAMgBAHgJQAJgIgBgSQgBgPgJgIQgIgIgLAAIgBAAgAgEhJQgMABgGAGQgHAIAAALQABALAHAHQAHAGALAAQAKgBAGgHQAIgGgBgNQgBgLgHgGQgHgGgIAAIgBAAg");
        this.shape_79.setTransform(129.5, 60.3);

        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.f("#BB5932").s().p("AgsBVQgTgWgDg9QgDg5ATgaQAQgXAfgBQAcgBASAUQAVAZADA8QADA5gTAbQgQAWgeABIgEAAQgaAAgTgVgAgOhDQgGAFgCAMQgEAPACAkQACAlAEANQAEAOAGAEQAGAFAFgBQAGAAAHgFQAFgFADgMQADgPgCgkQgBghgFgRQgEgOgGgEQgGgEgFAAQgIABgEAEg");
        this.shape_80.setTransform(113, 61.1);

        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.f("#BB5932").s().p("AgsBVQgTgWgDg8QgCg5ASgbQARgXAegBQAcgBASAUQAWAaACA7QADA5gTAbQgQAXgeAAIgEAAQgaAAgTgVgAgChIQgGAAgGAFQgGAGgCALQgEAPACAkQACAkAEAPQAEANAGAEQAHAFAEgBQAHAAAGgFQAFgFADgMQADgPgCgkQgBgkgFgOQgEgOgGgEQgFgEgEAAIgCAAg");
        this.shape_81.setTransform(96.8, 61.8);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.f("#BB5932").s().p("Ag4BBQAKgRAhgjQAXgXAHgKQAHgMAAgNQgBgOgIgHQgHgGgLAAQgNABgHAIQgHAIAAARIgogCQADghARgPQASgQAdgBQAdgBASAPQASARACAYQAAAQgEALQgFANgKANQgHAKgSARIgVAZIgIALIBOgEIACAlIiKAHQAAgVALgUg");
        this.shape_82.setTransform(80.8, 62.6);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("ABHhLIg4BXIAABAIgdAAIAAhAIg4hXIAlAAIAhA9IAjg9g");
        this.shape_83.setTransform(-73.7, 22.5);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.f("#671203").s().p("AgOBMIAAhBIg4hWIAlAAIAhA9IAjg9IAkAAIg4BXIAABAg");
        this.shape_84.setTransform(-73.7, 22.5);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAPgxIAAB9IgdAAIAAh9IgtAAIAAgaIB3AAIAAAag");
        this.shape_85.setTransform(-87.3, 22.5);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.f("#671203").s().p("AgOBMIAAh9IgtAAIAAgaIB3AAIAAAaIgtAAIAAB9g");
        this.shape_86.setTransform(-87.3, 22.5);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgEhLQAWAAALAEQAMAFAGAKQAHAKAAAOQAAARgKALQgKAJgUAEQAKAFAGAIQAFAEANAUIASAeIgkAAIgWghQgIgPgHgIQgEgFgFgBQgHgCgIAAIgHAAIAABAIgfAAIAAiXgAgmgxIAAAnIAXAAQAVAAAEgCQAFgCAEgFQADgEAAgHQAAgJgEgEQgEgFgIgBg");
        this.shape_87.setTransform(-100.7, 22.5);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.f("#671203").s().p("AAgBMIgXghQgJgPgFgIQgFgFgEgBQgHgCgIAAIgHAAIAABAIgfAAIAAiXIBBAAQAWAAALAEQAMAFAGAKQAGAKAAAOQABARgLALQgJAKgUADQAKAFAGAHQAEAFAOAUIASAegAgkgKIAWAAQAWAAAEgCQAFgBADgFQAEgFAAgHQAAgJgFgDQgDgFgIgCIgsAAg");
        this.shape_88.setTransform(-100.9, 22.5);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgagxIAAAiIBLAAIAAAYIhLAAIAAApIBUAAIAAAaIhzAAIAAiXIBwAAIAAAag");
        this.shape_89.setTransform(-116.2, 22.5);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.f("#671203").s().p("Ag5BMIAAiXIBwAAIAAAaIhRAAIAAAiIBLAAIAAAYIhLAAIAAApIBUAAIAAAag");
        this.shape_90.setTransform(-116.2, 22.5);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAzg2QAFAIAAAKQAAAKgGAJQgFAIgLAFQAOAEAIAJQAHAKAAANQAAALgFAJQgEAJgJAHQgIAGgMABQgLABgZAAIgzAAIAAiXIA8AAQAQAAAJABQAKACAGAFQAGADAGAKgAgggxIAAAjIApgBQAHAAAFgFQAFgFAAgHQAAgHgEgFQgEgEgIgBgAATAMQgIgDgSAAIgZAAIAAApIAdAAQAQAAADgBQAHAAAEgGQAEgFAAgIQAAgHgDgEQgDgFgGgCg");
        this.shape_91.setTransform(-131, 22.5);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.f("#671203").s().p("Ag+BMIAAiXIA8AAQAQAAAJABQAKACAGAFQAGADAGAKQAFAIAAAKQAAAKgGAJQgFAJgLAEQAOAEAIAJQAHAKAAAMQAAALgFAKQgEAJgJAGQgIAHgMABIgkABgAggAyIAdAAQAQAAADgBQAHAAAEgGQAEgFAAgIQAAgHgDgEQgDgFgGgDQgIgCgSAAIgZAAgAgggOIApgBQAHAAAFgGQAFgEAAgHQAAgHgEgEQgEgFgIgBIgqgBg");
        this.shape_92.setTransform(-131, 22.5);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AAPhLIAACXIgdAAIAAiXg");
        this.shape_93.setTransform(-142, 22.5);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.f("#671203").s().p("AgOBMIAAiXIAdAAIAACXg");
        this.shape_94.setTransform(-142, 22.5);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.f().s("#BB5932").ss(0.5, 0, 0, 4).p("AgVhKIAAB8IBKAAIAAAZIhpAAIAAiVg");
        this.shape_95.setTransform(-151, 22.5);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.f("#671203").s().p("Ag0BMIAAiWIAfAAIAAB8IBKAAIAAAag");
        this.shape_96.setTransform(-151, 22.5);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.f("#BB5932").s().p("AgOBMIAAhBIg4hWIAlAAIAhA9IAjg9IAkAAIg4BXIAABAg");
        this.shape_97.setTransform(-73.7, 22.5);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.f("#BB5932").s().p("AgOBMIAAh9IgtAAIAAgaIB3AAIAAAaIgtAAIAAB9g");
        this.shape_98.setTransform(-87.3, 22.5);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.f("#BB5932").s().p("AAgBMIgXghQgJgPgFgIQgFgFgEgBQgHgCgIAAIgHAAIAABAIgfAAIAAiXIBBAAQAWAAALAEQAMAFAGAKQAGAKAAAOQABARgLALQgJAKgUADQAKAFAGAHQAEAFAOAUIASAegAgkgKIAWAAQAWAAAEgCQAFgBADgFQAEgFAAgHQAAgJgFgDQgDgFgIgCIgsAAg");
        this.shape_99.setTransform(-100.9, 22.5);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.f("#BB5932").s().p("Ag5BMIAAiXIBwAAIAAAaIhRAAIAAAiIBLAAIAAAYIhLAAIAAApIBUAAIAAAag");
        this.shape_100.setTransform(-116.2, 22.5);

        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.f("#BB5932").s().p("Ag+BMIAAiXIA8AAQAQAAAJABQAKACAGAFQAGADAGAKQAFAIAAAKQAAAKgGAJQgFAJgLAEQAOAEAIAJQAHAKAAAMQAAALgFAKQgEAJgJAGQgIAHgMABIgkABgAggAyIAdAAQAQAAADgBQAHAAAEgGQAEgFAAgIQAAgHgDgEQgDgFgGgDQgIgCgSAAIgZAAgAgggOIApgBQAHAAAFgGQAFgEAAgHQAAgHgEgEQgEgFgIgBIgqgBg");
        this.shape_101.setTransform(-131, 22.5);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.f("#BB5932").s().p("AgOBMIAAiXIAdAAIAACXg");
        this.shape_102.setTransform(-142, 22.5);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.f("#BB5932").s().p("Ag0BMIAAiWIAfAAIAAB8IBKAAIAAAag");
        this.shape_103.setTransform(-151, 22.5);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.f().s("#671203").ss(1, 0, 0, 4).p("AbCAAQAAFgiIFBQiEE3jvDvQjvDvk3CEQlBCIlgAAQleAAlCiIQk2iEjwjvQjvjviEk3QiIlBAAlgQAAleCIlCQCEk2DvjwQDwjvE2iEQFCiIFeAAQFgAAFBCIQE3CEDvDvQDvDwCEE2QCIFCAAFeg");
        this.shape_104.setTransform(0.5, 0);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.f("#BB5932").s().p("AqgY6Qk2iEjwjvQjvjviEk3QiIlBAAlgQAAleCIlCQCEk2DvjwQDwjvE2iEQFCiIFeAAQFgAAFBCIQE3CEDvDvQDvDwCEE2QCIFCAAFeQAAFgiIFBQiEE3jvDvQjvDvk3CEQlBCIlgAAQleAAlCiIg");
        this.shape_105.setTransform(0.5, 0);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.f().s("#671203").ss(2, 0, 0, 4).p("Ab3AAQAAFriMFLQiHFAj3D3Qj3D3lACHQlLCMlrAAQlpAAlMiMQlAiHj3j3Qj3j3iHlAQiMlLAAlrQAAlpCMlMQCHlAD3j3QD3j3FAiHQFMiMFpAAQFrAAFLCMQFACHD3D3QD3D3CHFAQCMFMAAFpg");
        this.shape_106.setTransform(0.5, 0);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.f("#531002").s().p("Aq1ZrQlAiHj3j3Qj3j3iHlAQiMlLAAlrQAAlpCMlMQCHlAD3j3QD3j3FAiHQFMiMFpAAQFrAAFLCMQFACHD3D3QD3D3CHFAQCMFMAAFpQAAFriMFLQiHFAj3D3Qj3D3lACHQlLCMlrAAQlpAAlMiMg");
        this.shape_107.setTransform(0.5, 0);

        this.addChild(this.shape_107, this.shape_106, this.shape_105, this.shape_104, this.shape_103, this.shape_102, this.shape_101, this.shape_100, this.shape_99, this.shape_98, this.shape_97, this.shape_96, this.shape_95, this.shape_94, this.shape_93, this.shape_92, this.shape_91, this.shape_90, this.shape_89, this.shape_88, this.shape_87, this.shape_86, this.shape_85, this.shape_84, this.shape_83, this.shape_82, this.shape_81, this.shape_80, this.shape_79, this.shape_78, this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-177.8, -178.3, 356.8, 356.8);


    (lib.CdP_Practica = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape.setTransform(65, 15);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_1.setTransform(65, 15);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#666666").s("#666666").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_2.setTransform(65, 15);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape}]}).to({state: [{t: this.shape_1}]}, 1).to({state: [{t: this.shape_2}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 130, 30);



    (lib.arbol_IMG = function () {
        this.initialize();

        // Layer 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AgjA4Qg0gRgtgkQgsghghgKQAtACBCgUQA5gSAxAKQA5ALA4AqQBBAuAYAJQhZAUgiAGQgSADgTAAQgpAAgsgPg");
        this.shape.setTransform(-70.2, 72);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgrAfQACgWAXgcQAKgOAOgIQAYgNAPgMQgJAPgCAVQgBAWgOAWQgMAWgUALQgYAMgHAIQAAgXABgNg");
        this.shape_1.setTransform(74.4, -42.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AgZAgQgJgcADgNQAGgdATgQQAVgTADgGIAOAjQAEAUgKAaQgDAJgQAVQgOATgJAdQABgSgKgeg");
        this.shape_2.setTransform(-41, 154.5);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AAHAuQgQgNgNgZQgLgUADgYQADgagDgLQAKAJATALQAQAOANAjQAFAOgBATQgDAZACAUQgHgPgRgNg");
        this.shape_3.setTransform(86, -15.6);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s().p("AgeAtQgFgSAKgbQADgKAPgUQANgVAJgdQgBASALAeQAKAcgDAMQgFAegSAQQgVAUgDAGQgMgXgDgMg");
        this.shape_4.setTransform(44.8, -27.5);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#FFFFFF").s().p("AgTArQgLgYAAgUQAAgSANgaQAPgeACgNQAAAFAFAKIALARQAZApgPAkQgJAWgYAuQAAgUgMgag");
        this.shape_5.setTransform(-95.9, 92.3);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#FFFFFF").s().p("AAjAhQgcACgRgHQgRgHgTgVQgXgYgMgHQAEACANgCIATgFQAugJAeAdQARAQAiAnQgTgIgcACg");
        this.shape_6.setTransform(159.5, -67.9);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f("#FFFFFF").s().p("AgGAuQgSgWgFgUQgFgPAHgcQAHghgBgOQABAEAJAJIANANQAjAigGAmQgDAYgOAzQgEgUgQgVg");
        this.shape_7.setTransform(165, 5.9);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#FFFFFF").s().p("AgGAuQgRgXgCgVQgEgeAMgXQANgbAAgDQAEAKAOAcQANAVAAAUQABAQgJAbQgIAcgBANQgBgNgPgXg");
        this.shape_8.setTransform(-146.7, -4.8);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f("#FFFFFF").s().p("AgsAeQACgTAUgVQAHgIAUgNQAWgNATgXQgIAQgBAgQgCAbgIANQgQAZgVAHQgdAKgGAFQgBgaACgMg");
        this.shape_9.setTransform(67.7, -176.8);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f("#FFFFFF").s().p("AAWAsQgWgIgPgSQgTgVgFgVQgEgVgMgMQASAKAZAHQAPAGAMALQAcAYAGAXQADALAEAXQgIgHgagHg");
        this.shape_10.setTransform(42.4, -71.3);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f("#FFFFFF").s().p("AAYAjQgSgBgNgHQghgRgMgRQgJgVgIgLQAKAFAbAAQAYAAATAOQAXAQALARQAKASAPAJQgTgEgbgBg");
        this.shape_11.setTransform(1.6, 69.6);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f("#FFFFFF").s().p("AhIAiQAagvAdgSQAqgaApgMQAigKAYgTQgOAbgNA6QgRAygrAgQglAdgpAAQhMAAgGABQAYgPAbgyg");
        this.shape_12.setTransform(-7.4, 87.7);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f("#FFFFFF").s().p("AgYAaQgGgZABgIQADgeAMgQQAHgJARgRQABAHANAbQALAWgHAbQgEAPgUAWQgTAXgHAQQAEgdgGgZg");
        this.shape_13.setTransform(114.9, 103.9);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f("#FFFFFF").s().p("AgUAwQgNgVAFgcQADgPASgWQASgZAFgRQgBAeAHAYQAIAZAAAIQgBAegLAQIgXAcQAAgHgPgag");
        this.shape_14.setTransform(-35.3, -203);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f("#FFFFFF").s().p("AASAzQgSgHgPgZQgGgIgIgXQgGgYgTgYQAPALAeAKQAZAIALALQAVAUABAYQACAeAEAHQgagFgLgFg");
        this.shape_15.setTransform(-73.4, -150.9);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f("#FFFFFF").s().p("AhoAoQAZgyAgggQAigjA+gNQAlgJBEgIQgXAQggA9QggA9gtAeQgmAbg1AIIhUAMQAZgVAYgvg");
        this.shape_16.setTransform(157.8, -26.8);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f("#FFFFFF").s().p("AALA1QgPgJgOgcQgFgIgEgYQgDgZgPgaQAMAMAdAOQAZAMAJANQARAWgCAZQgCAeADAHQgZgIgKgHg");
        this.shape_17.setTransform(-136.6, 58.3);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f("#FFFFFF").s().p("AgNBKQgYgigEgtQgDghAUgkQAWgpACgRQA3BQgRA9QgSBBAIA7Igpg7g");
        this.shape_18.setTransform(-76.7, 111.8);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f("#FFFFFF").s().p("Ag7AaQgOgHgngaQAQgCAhgNQAegMAWAAQAkgBAlAMQAoANALABQgTAGglATQgeARgZACIgMAAQgbAAgWgJg");
        this.shape_19.setTransform(-57.9, 97.4);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f("#FFFFFF").s().p("AAYAjQgSgBgNgIQgigQgMgSQgIgUgIgLQAKAEAbAAQAYABATAOQAXAPALASQALASAOAJQgTgEgbgBg");
        this.shape_20.setTransform(141.2, 26);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f("#FFFFFF").s().p("AgWA3QgPglgBgLQgFgqAPgeQAWggAJgYQgBAPAUAgQAUAggCAqQgBAcgRAeQgWAngHAZQgBghgOgig");
        this.shape_21.setTransform(129.1, 33.1);

        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f("#FFFFFF").s().p("AgHAoQgSgXgDgQQgEgbANgVQAPgaABgHIAWAcQALARAAAeQAAAIgIAZQgIAXABAeQgFgQgRgZg");
        this.shape_22.setTransform(116.7, 47.6);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f("#FFFFFF").s().p("AAPBdQgngggRgcQgZgpgIg0QgFg+gFgjIBOAwQAcATARAgQAOAbAJAoQACAQAEA9QABApAQAfQgXgbgvgmg");
        this.shape_23.setTransform(141.2, 4.6);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f("#FFFFFF").s().p("AgyASQAHgSAZgQQAIgFAXgHQAYgHAYgSQgLANgJAfQgJAagLAKQgVAUgXACQgfACgGADQAFgZAFgLg");
        this.shape_24.setTransform(122.5, -32.2);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f("#FFFFFF").s().p("AgfAdQgFgdAEgMQAJgcAVgOQAXgQAEgGIAKAkQACAUgOAZQgEAJgSASQgQASgMAbQADgRgHgfg");
        this.shape_25.setTransform(75.6, 67.6);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f("#FFFFFF").s().p("AgbAlQgDgcAEgQQAEgUAQgSQAUgYAFgJQAAADAIAdQAGAZgKAdQgGATgTAUQgUATgDANQABgMgDgeg");
        this.shape_26.setTransform(100.6, -126.3);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f("#FFFFFF").s().p("AhBAjQAJgfAYgVQAQgQAlgNQApgOAbgXQgRAXgHAlQgJAlgJANQgVAigoAJQgxAGgYAIQAMgPAKgig");
        this.shape_27.setTransform(126.1, -114.8);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f("#FFFFFF").s().p("AgoAXQAHgZANgQQAUgYAZgGIAggKQgGAJgKAeQgHAWgPANQgOANgXALQgcANgKAGQAJgJAHgbg");
        this.shape_28.setTransform(121, -76.7);

        this.shape_29 = new cjs.Shape();
        this.shape_29.graphics.f("#FFFFFF").s().p("AgKAtQgPgUgBgTQgCgRAGgbQAHgdAAgNQACANAQAWQASAWAEAUQAGAdgJAYQgLAcAAADQgEgKgRgag");
        this.shape_29.setTransform(17.2, 93.1);

        this.shape_30 = new cjs.Shape();
        this.shape_30.graphics.f("#FFFFFF").s().p("AhDgTQAWiDBdg7QA+B+gvBpQgfBGhyB2QACicANhJg");
        this.shape_30.setTransform(91.8, 102.4);

        this.shape_31 = new cjs.Shape();
        this.shape_31.graphics.f("#FFFFFF").s().p("Ag/A0QAUgxAHgJQAVglArgdQA8glAOgOQgGAggIAzQgIAngSAXQgQAWguAYQhWAvgPAJQATgcATgsg");
        this.shape_31.setTransform(-117, -101);

        this.shape_32 = new cjs.Shape();
        this.shape_32.graphics.f("#FFFFFF").s().p("AhJAhQAAgdAVgfQAPgYApgRIBJgcQgRARgJAfQgLAmgPAXQgNAUgiAYQgpAbgNAOQAFgTgCgug");
        this.shape_32.setTransform(126.8, -157.7);

        this.shape_33 = new cjs.Shape();
        this.shape_33.graphics.f("#FFFFFF").s().p("ABACNIgpgaQgxgjgYg/QgFgNgMhCQgMg/gTgvQAOAQA+AjQAzAdAWAlQAWAkAGBAQAHBUANAsQgNgSgWgOg");
        this.shape_33.setTransform(-144.6, -116.4);

        this.shape_34 = new cjs.Shape();
        this.shape_34.graphics.f("#FFFFFF").s().p("AhOAEQAVghAqgXQAbgQApADQAuAEARgFQgzBShAAKQhBAJgzAgIAlg/g");
        this.shape_34.setTransform(-163.4, -28.4);

        this.shape_35 = new cjs.Shape();
        this.shape_35.graphics.f("#FFFFFF").s().p("AhOAaQgPhIAeikQAIAQA1BSQAkA9ATApQA3B2gsBnQh4hGgWhzg");
        this.shape_35.setTransform(-148.2, -62.4);

        this.shape_36 = new cjs.Shape();
        this.shape_36.graphics.f("#FFFFFF").s().p("AgxAfQgvgMgYADQAJgDA5ggQAqgZAfABQARAAAgAPIA1AXQgTACghAOQgoAQgIACQgLADgKAAQgVAAgcgHg");
        this.shape_36.setTransform(76.8, -63.3);

        this.shape_37 = new cjs.Shape();
        this.shape_37.graphics.f("#FFFFFF").s().p("AA0AwQg0gBgOgGQgbgJgggdQgfgbgRgFIBJgZQApgJAZAQQAVANAdAiQAhApAVARQgTgIgzgCg");
        this.shape_37.setTransform(146.7, -54.5);

        this.shape_38 = new cjs.Shape();
        this.shape_38.graphics.f("#FFFFFF").s().p("AAeB2QgogpgagpQgegtgDg+QgDg8ghgxQAVATAdAPIAyAXQA6AfAoBIQAWAmgPA/QgUBPADAVQgNgXgogog");
        this.shape_38.setTransform(94.8, -78.3);

        this.shape_39 = new cjs.Shape();
        this.shape_39.graphics.f("#FFFFFF").s().p("AhWA8QAAgpASgiQAZgwA0gfQBIgrALgKQgVAjgKAwQgLA2gQAeQgbA0gkAYQgtAdgSAXQAGgcAAg8g");
        this.shape_39.setTransform(2.4, -167);

        this.shape_40 = new cjs.Shape();
        this.shape_40.graphics.f("#FFFFFF").s().p("AgRA2QgXgsADgfQACgRAQgfIAbgzQAAATAMAiQAPAoABAIQAGAagOAsQgQAuADAYQgDgJgdg6g");
        this.shape_40.setTransform(8, -78.7);

        this.shape_41 = new cjs.Shape();
        this.shape_41.graphics.f("#FFFFFF").s().p("AgfAZIg2gTQARgCAagNQAcgQAXgEQAOgCAZAFQAYAEAOgDIghAhQgSASgTAEIgOABQgPAAgSgGg");
        this.shape_41.setTransform(-5.9, -64.7);

        this.shape_42 = new cjs.Shape();
        this.shape_42.graphics.f("#FFFFFF").s().p("AhYA4QABgpAUghQAbgvA1gdQBKgnALgKQgXAhgLAxQgNA1gSAdQgdAzgkAXQgvAbgSAWQAGgbADg9g");
        this.shape_42.setTransform(30, -42.8);

        this.shape_43 = new cjs.Shape();
        this.shape_43.graphics.f("#FFFFFF").s().p("AgyAbQgogNgUgDQALgDAlgSQAhgSAjgGQAXgEAfAGQAjAHAQgBQghAggNAKQgZARgjADIgGABQgVAAgcgKg");
        this.shape_43.setTransform(-38.5, -0.6);

        this.shape_44 = new cjs.Shape();
        this.shape_44.graphics.f("#FFFFFF").s().p("AgrAjQgCgfAGgRQAEgOATgYQAUgcAJgRQAGAWARAoQANAigIAUQgIAWghAXQghAYgEAIIgGg+g");
        this.shape_44.setTransform(78.6, 21.1);

        this.shape_45 = new cjs.Shape();
        this.shape_45.graphics.f("#FFFFFF").s().p("Ag1AgQgPgEgrgWQAQgEAfgQQAbgQAXgDQAkgGAlAHQAqAIALgBQgSAIgjAYQgbAVgYAFQgOAEgQAAQgQAAgPgFg");
        this.shape_45.setTransform(95, 4.3);

        this.shape_46 = new cjs.Shape();
        this.shape_46.graphics.f("#FFFFFF").s().p("AhPAVQAQgsAYgUQALgLAYgGIAogMQAMgEAWgLQAVgKAJgDQgIAKgSAtQgRAtgQASQgPATg3AWQg4AYgOASQANg9AHgTg");
        this.shape_46.setTransform(-50.3, -165.9);

        this.shape_47 = new cjs.Shape();
        this.shape_47.graphics.f("#FFFFFF").s().p("AAOAyQgYgPgJgMQgMgPgKgbIgRg8QAFAGAqAJQAmAJAPARQAPAQABAkIABBCQgNgMgggSg");
        this.shape_47.setTransform(-11, -105.7);

        this.shape_48 = new cjs.Shape();
        this.shape_48.graphics.f("#FFFFFF").s().p("AhMBaQADg5Akg6QA4hhAehGQAAATALAZIAWAvQAZA+ggA+QgdA7gwAoIhaBHQAMggAEhHg");
        this.shape_48.setTransform(8.1, -119.1);

        this.shape_49 = new cjs.Shape();
        this.shape_49.graphics.f("#FFFFFF").s().p("AA7C/QgLgigigrQgwg8gHgLQgXgkgKglQgMgtAJgjIAYhYQAMASAcAZIAqAsQAqArAJA2QAIAvgUAxQgGAPgDATQgCAUACAPQADARABASQABANgCAAQgBAAgCgIg");
        this.shape_49.setTransform(96, 39.5);

        this.shape_50 = new cjs.Shape();
        this.shape_50.graphics.f("#FFFFFF").s().p("Ag2ArQgmgLgagFQAPgDAZgaQAagcApgLQAagHAhAIQAtALAaAAQggALgdAWQgfAYgKAEQgbANgaAAQgJAAgJgCg");
        this.shape_50.setTransform(-50.4, 55.3);

        this.shape_51 = new cjs.Shape();
        this.shape_51.graphics.f("#FFFFFF").s().p("AgaBgQgagfgEgwQgEg0AdguQAhgxAMgcQABAfAPAgQASAnAIAzQAGAggVAzQgUA1ADAcQgDgGgvg5g");
        this.shape_51.setTransform(-10.9, 12.8);

        this.shape_52 = new cjs.Shape();
        this.shape_52.graphics.f("#FFFFFF").s().p("AhiAWQAqhIAngcQAqgfA7ABQBFABAcgMQgUAQgqBEQgjA1g+AdQgaANg+ATQg/ARgyAYQApgZAohJg");
        this.shape_52.setTransform(-2, 45.6);

        this.shape_53 = new cjs.Shape();
        this.shape_53.graphics.f("#FFFFFF").s().p("AgrA4QgGgiAEgRQAHgfAjghQAuguAFgIQgJAWAAAxQAAArgPAZQgEAIgYAhQgWAdgGASIgLg6g");
        this.shape_53.setTransform(-108.9, -66.6);

        this.shape_54 = new cjs.Shape();
        this.shape_54.graphics.f("#FFFFFF").s().p("AAgBPQgjgLgdgcQgWgXgNgxQgPg3gTgaQATASA7AbQAyAYAeAkQASARAEAqQAFApASAWQgcgYgqgLg");
        this.shape_54.setTransform(-49.4, -117.7);

        this.shape_55 = new cjs.Shape();
        this.shape_55.graphics.f("#FFFFFF").s().p("AhABrQgOhBAMgzQALguA2hEQA5hKAQgtQgRA4AGBSQAIBggIAsQgJA8gjA2QgiA3gGAmQgihngHghg");
        this.shape_55.setTransform(-34.3, -143.3);

        this.shape_56 = new cjs.Shape();
        this.shape_56.graphics.f("#FFFFFF").s().p("AAhBOQgjgJgdgcQgXgXgOgwQgPg4gUgZQAUARA7AbQAzAXAeAjQASARAFApQAFAqATAVQgdgXgqgLg");
        this.shape_56.setTransform(-112.2, -14.1);

        this.shape_57 = new cjs.Shape();
        this.shape_57.graphics.f("#FFFFFF").s().p("Ah7AOQAhgmBJgoQA4geA2gCIBpgCQgZARgSAXQgJAMgRAYQghAqhPAgQglARhJAEQhCAEgmAWQAQgPA6hGg");
        this.shape_57.setTransform(-122.9, 9.3);

        this.shape_58 = new cjs.Shape();
        this.shape_58.graphics.f("#FFFFFF").s().p("AgNA0QgwgUgigaQgcgTgegJQAegFA3gXQA1gRAwAPQAvAPAYAgQAsA6AGAFQgbgKg4AJQgVADgRAAQgdAAgRgIg");
        this.shape_58.setTransform(-76.6, -61);

        this.shape_59 = new cjs.Shape();
        this.shape_59.graphics.f("#FFFFFF").s().p("AgrANQAIgWANgSQANgUAWgIQAhgLATgNQgGANgHAkQgFAegMARQgSAbgfALQgmALgMAPIAVhEg");
        this.shape_59.setTransform(-51.2, -68.6);

        this.shape_60 = new cjs.Shape();
        this.shape_60.graphics.f("#FFFFFF").s().p("AAoCEQgigOgbgkQgZgggPgnQgFgLgThLQgOg1gVgdQgMgPASAPQAPAMALALQALAMARAJQARAKAQAEQAxANAjAjQAmAnAKA5IAJA+QAEAmAHAUIhVghg");
        this.shape_60.setTransform(-71.3, -85.2);

        this.shape_61 = new cjs.Shape();
        this.shape_61.graphics.f("#FFFFFF").s().p("AgXAyQgKgZAHgdQAEgVAQgSQAUgaAIgRQgDAYAGAbQAGAcgBAHQgCAegOAUQgSAVgLAQQACgMgKgZg");
        this.shape_61.setTransform(33.1, -92.1);

        this.shape_62 = new cjs.Shape();
        this.shape_62.graphics.f("#FFFFFF").s().p("AgzALQANggAQgKQAcgVAaACQAcAAAPgIQgOAQgKAbQgLAWgQAQQgXAWgdADQgkADgKAHQALgLAMgkg");
        this.shape_62.setTransform(58.9, -81.5);

        this.shape_63 = new cjs.Shape();
        this.shape_63.graphics.f("#FFFFFF").s().p("Ah6ABQArgoAsgTQBAgcA+AIIA3ALQAjAHAcABQghAKg6AxQg4AuhCARQgRAEhLAAQhGgBgqAPQAZgTA9g9g");
        this.shape_63.setTransform(61.4, -96.3);

        this.shape_64 = new cjs.Shape();
        this.shape_64.graphics.f("#FFFFFF").s().p("AgjAYQANgbAUgSQAIgJAXgLQAWgJAKgMQgEASgDAeQgEAYgOAOQgQAPgZAIQgxANgGACQANgKAMgcg");
        this.shape_64.setTransform(-62.6, 29.2);

        this.shape_65 = new cjs.Shape();
        this.shape_65.graphics.f("#FFFFFF").s().p("AAfBDQgjgVgRgXQgKgNgSgvQgSgwgNgQQAXAOAxATQApARATAQQAYAVAEAnQACAZgDA0QgLgOglgVg");
        this.shape_65.setTransform(-64.7, 7.1);

        this.shape_66 = new cjs.Shape();
        this.shape_66.graphics.f("#FFFFFF").s().p("AhCBKQhugFgNABQAWgKA7g9QA1g5AwgLQAtgLBBAOQBNARAJAAQgTAjgvAeQgkAZgoARQgnAQg1AAIgVAAg");
        this.shape_66.setTransform(-81.7, 23.1);

        this.shape_67 = new cjs.Shape();
        this.shape_67.graphics.f("#FFFFFF").s().p("AAhAtQgdgMgQgPQgOgMgPgeQgRgigKgMQAPAFAjAEQAWADAYAUQARAOAJAiIAPA9QgMgQgYgKg");
        this.shape_67.setTransform(29.6, -143.1);

        this.shape_68 = new cjs.Shape();
        this.shape_68.graphics.f("#FFFFFF").s().p("AAzA2QgfgBgbgQQgVgMgWgfQgZgjgdgVQAbAKAlgCQAogDANAFQAmALAVAmQALAUAWAtQgSgHgkgBg");
        this.shape_68.setTransform(1.6, -195.7);

        this.shape_69 = new cjs.Shape();
        this.shape_69.graphics.f("#FFFFFF").s().p("AgCBQQgngngIghQgMgwAAgrQABgjgLgdQAWAVAyAeQAsAgASAyQAQAsgMAnQgWBIgBAHQgIgcgmgog");
        this.shape_69.setTransform(-17.3, -220.2);

        this.shape_70 = new cjs.Shape();
        this.shape_70.graphics.f("#FFFFFF").s().p("AhdAmQAehPAhghQAlglA7gJQBEgKAZgQQgQASggBLQgZA5g5AoQgZAQg4AcQg9AcgtAfQAlggAchNg");
        this.shape_70.setTransform(7.3, -221.2);

        this.shape_71 = new cjs.Shape();
        this.shape_71.graphics.f("#FFFFFF").s().p("EgFbAiWQAuiNB1jLIDclvQCHjjBHihQBejYAWi7QAekIg3jfQg4AEgbBAQgSAqgRBxQgUCGgRA+QgfByg6BLQgVA5gqBKQgyBbgJAUQg3B2BBBkQgpgvgNgrQgoA6ivAVIiRASQhSAOgyAYQAvgfBPgRICOgZQBVgPAsgUQA+gbAagyQACgnAag+QAkhSAVg2QhfBCiRARQDBguBbiJQBEhkAaiyQAVjBARhOQAgiBBXgeQhXjhi0iJQhMAMhSBgQgOAQg1BFQgpA1gcAaQhCCRAJBgQAHBEA0BHQBFBcAMAcQAjBQgcBsQAKhvgqhJQgPgbhIhOQAIBMghA1QgoA/hYAIQBOgTAdgvQAjg4gThzQgkgygEg/QgGhOAoh3QgzAdg5gGQhAgHhMgzQBzAyBMgeQA5gYA2hQQA4hmAigwQA6hUBHgcQiohfjegRIhbgFQiNBOhkBYQhpBehLB4IgrBEQgaApgRAaQgWBoAHBaQAUA1A8ATQAfAJBkAIQBjAIA8AUQBbAeBCBHQhshbi/gFQhvgDgQgCQg9gIgdgfQAeCCBiB2QBABOB/BrQCJBxAkApQBJBRgGBKQgIhThrhfQgjgghGg1QhZhEgegXQAKA0gjA9QgNAXhDBXQg2BFgQAvQgXBDAfBBQgog9AShFQAMgvA1hLQBChcANgbQAihDgOg3QhjhTg5hPQgMAbgtgBQgjgBhKgSQhdAPgOBZQgEAWAAA1QAAAtgGASQAEgXgCgwQgCgzADgXQAJhTBLgVQiYglhJgBQh/gBg8BQQAxhQBjgNQBHgKB0AZICkAiQBJAIAMgqQhjiiAfjKQhQBchcARQhwAViYhQQDgBnCSiaQAxg1A3hhQA4hrAagrQBMh4A6g+QBAhEBXgsQjmgGhEgDQipgIh7gVQhDASg4BOQghAug9BtQg9BhhAAsQhXA8h/gGQCVgMBchgQgjAGgigaQgXgSgkgtQgpg2gQgQQgigjgigGQAhAAAlAhQAMALA0A6QAoAsAbAPQAmAVAngSQAegmBNiVQA3hqA7gcQiMgehng0Qh1g7hMhbQCgCND3AoQCsAbEvgQQibgnhzhsQh7hzgTiSQgzhRhTghQhOgehzAIQCAgXBWAbQBCAWAsA0QAChvBChtQBwi8hVkMQA2B4ABBxQACBzg2B2Qh/EZC8C4QCjCfFFAnQB6gGBUAAQg/gvgahOQgahOAYhLQgPBuA/BLQA2BBBqAgQBNAEBDAMQhBh1gkhrQgghbgNhiQgshqhxg7Qg6gfiegtQiLgog6gqQhXg/gJh3QAZB5BxA0QArAUBFAQQAoAJBTARQgbg2AIhyQATiOAIhNQAPiKgOhXQgTh1hLhEQBYA/AbB6QASBYgMCUIgTDkQgDBzAmAtQBPATA2AdQBCAjAsA2IAGgoQAThXA6hkQA/hrBchgQAdhVgYhuQgWhthAhkQhEhphghDQhphJh4gLQB6gCBqA+QBfA2BIBhQgBg/AXg7QAehSBIg7Qg5BBgYA9QggBaAbBnQAzBTAaBbQAZBYgDBHQCliVDOhKQBZhHAvhFQBIhrgXhuQAaBugtBhQggBHg/A4QDzhFEIAuQkagOj3BWQjoBRicCbQicCagvDAQgxDHBRDHQgKjnCyhnQBthAD/ggQBHgjATg0QAPgngLg9QgRhHgFgiQgHg8AXgpQgQAsAKA9QAHAjASBEQAPA8gIAkQgLAxg1AiQCEgQAzgRQBNgaAFgzQABBDhgAgQguAPiyAcQimAahYAjQiDA2g0BkQhTDUBhCbQBIB3CuBSQgWhAAAhFQAAg7AQhGQgCheg2g9QgRgTgUgNIgRgKQA3ARAjAqQAbAhALAuQAjhfBEhXQA/hPBPg4QiFCDg3CGQhgDmB/DfQAwAsArA4QBShmB/hUQAbg0gFg+QgDgngVhOQgYhTgGgsQgJhMAShHQgHBIAKA+QAIAsAWA3QAKguAlgsIBMhMQBqhnALiDQAABXgkBDQgYAtg1A3Qg8A9gQAYQghAyADA8QATAwAHAjQAKAxgIA2QBVgxBygzQBDgdCJg4QBHhhAeiSQAWhoAGirQgQgvgpgqQgXgYg4gsQg1gqgWgZQglgngKgsQAUA+BtBSQBuBTAUA0QAHjEAFgzQALiCAkhNQgcBNgFCIQgBAbAADoQABClgOBkQgTCOgzBdQDThWBhhBQCNhdAlh4QgQCLjsCVQhHAtiaBTQilBahHAsQCCAACNArQBiAdCSBCQC8BUAvATQCFAzBtAOQiBgBjfhTQh8gwhCgXQhxgohcgVQAoAtAOBEQAJA0gCBYQARAlBQA6QBKAzAUA9QgghChFgkIgygdQgagTgPgYQgFBvABAqQACBcASBKQgbhGgIhlIgFiqQgEhjgRg5QgYhNg4gtQiSgYiIANQiGBfhDBdQBFgSBIAjQAzAZBIBBIBzBmQBAAwAzAFQgzAChIgtIiAhdQhPg6g4gSQhNgYhEAjQgnBQAABSIAKAUQAkBUAfBTQBpgTBqBgQBAA7B1CjQCWA5BwhkQAagYA+hIQA1g+AkgaQgoAjg0BFQg+BUgUAVQhiBriCglQBgCGBCA4QBeBRBfgIQhyATh2hcQhOg9h0iUQiBikgqgoQhahUhEAdQBYEYgQD6QgNDQhdDrQgnBjihFPQiMEhhHDVQgzgChDALIhwAWQhBALg6AAQhJAAg/gSg");
        this.shape_71.setTransform(-2.6, 16.3);

        this.shape_72 = new cjs.Shape();
        this.shape_72.graphics.f("#FFFFFF").s().p("AhNA+Qg6gNgcgBQAagMAmgkQAfgfA5gPQAhgJA3ABQAyACAlgOQgMAJg5A7QgrAug0ANQgTAGgUAAQgTAAgTgFg");
        this.shape_72.setTransform(175.1, -86.1);

        this.shape_73 = new cjs.Shape();
        this.shape_73.graphics.f("#FFFFFF").s().p("AAlBFQglgIgcgeQgUgVgKgfQgNgsgMgWQAZAVAiAOQAkAPAHAGQAjAaAMAeQAHAUAMArQgLgLglgIg");
        this.shape_73.setTransform(141.9, -91.9);

        this.shape_74 = new cjs.Shape();
        this.shape_74.graphics.f("#FFFFFF").s().p("AgTCnIgVgpQgZgwAGhUQADgqAchEQAag8gDgtQAFAXAkBSQAWAvADBRQADBBgXAyIgrBfQgFgfgMgYg");
        this.shape_74.setTransform(155.2, -109.5);

        this.shape_75 = new cjs.Shape();
        this.shape_75.graphics.f("#FFFFFF").s().p("AhVAkQglgTgdADQAkgLAhgaQAdgZAngIQAegGAxASQA2ATAhgCQgaAHg3AfQgyAegsAFIgHAAQgYAAgfgQg");
        this.shape_75.setTransform(55.8, -142.9);

        this.shape_76 = new cjs.Shape();
        this.shape_76.graphics.f("#FFFFFF").s().p("AgsAbQAAggAMgRQAWgcAWgIQAcgJAMgMQgJATgBAdQgCAbgKASQgNAcgcANQggAOgIAMQAHgPAAgng");
        this.shape_76.setTransform(45.2, -152.6);

        this.shape_77 = new cjs.Shape();
        this.shape_77.graphics.f("#FFFFFF").s().p("AgDA5QgkgIgvgbQhGgngngTQAiADBOgQQBLgQAjAFQAxAGArAeQAvAhAeAIQhBAYggAKQggALggAAQgUAAgSgFg");
        this.shape_77.setTransform(69.3, -123.1);

        this.shape_78 = new cjs.Shape();
        this.shape_78.graphics.f("#FFFFFF").s().p("AgHBKQgagegFgqQgBgHADgrQADgpgFgfQAHAMAfAfQAbAaAIAaQAHAZgGAoQgJA0ACAdQgEgLgggkg");
        this.shape_78.setTransform(83.2, -143.3);

        this.shape_79 = new cjs.Shape();
        this.shape_79.graphics.f("#FFFFFF").s().p("AAVBIQgagPgSgbQgOgVgFglQgGgrgRgfQATAVAjAOQAiAQAMALQAdAbACAoIgBBLQgMgOgggQg");
        this.shape_79.setTransform(184.5, 12.5);

        this.shape_80 = new cjs.Shape();
        this.shape_80.graphics.f("#FFFFFF").s().p("Ag5BCQgCg4ARgbQAZgtAcgfQAYgZALgdQACAeARA6QALA2gVAuQgTAtgjAUQg/AlgGAFQANgZgCg5g");
        this.shape_80.setTransform(187.3, -19.5);

        this.shape_81 = new cjs.Shape();
        this.shape_81.graphics.f("#FFFFFF").s().p("AgKA8QgegHg8gXQg9gZg2gKQAwAFBLggQBPgiAuABQA1ACAvAlQA2ApAdAHQgYABhLAcQgmAPgoAAQgZAAgYgGg");
        this.shape_81.setTransform(207, 0.5);

        this.shape_82 = new cjs.Shape();
        this.shape_82.graphics.f("#FFFFFF").s().p("AAqBAQgvgBgqgeQgXgRgOgpQgPgqgSgMQANAEAxAFQApAFAUANQAxAdAWApQAZAyAQANQgYgPg0gCg");
        this.shape_82.setTransform(149.9, 53.7);

        this.shape_83 = new cjs.Shape();
        this.shape_83.graphics.f("#FFFFFF").s().p("AhyBEQg4gLgiAHQApgTAwgvQAqgrAygPQA1gSBGAKQBQALAZgDQhGA8gbATQgtAkhEANQgbAFgbAAQgcAAgbgFg");
        this.shape_83.setTransform(159, 35.3);

        this.shape_84 = new cjs.Shape();
        this.shape_84.graphics.f("#FFFFFF").s().p("AAWBUQgvgWgYgmQgNgVgDgyQgEg2gRgdQA6AYAcAUQAkAZARAhQARAfADAuQAEA2AKAcQgRgZgwgWg");
        this.shape_84.setTransform(138.1, 112.9);

        this.shape_85 = new cjs.Shape();
        this.shape_85.graphics.f("#FFFFFF").s().p("AgkA6QgKgqAEgWQAFgcASgkQAPgcAAgZQAHAYAZAvQAUApgFAaQgHAngVAUQgeAigJAQQAAgTgMgvg");
        this.shape_85.setTransform(132.7, 81.8);

        this.shape_86 = new cjs.Shape();
        this.shape_86.graphics.f("#FFFFFF").s().p("AhaA+QhXgSgsAFQA2gJBCgnQBMgsAngNQA2gSA7AHQA8AGAjgKQhIBHgYARQgwAngxAMQgQAEgUAAQgjAAgwgKg");
        this.shape_86.setTransform(155.5, 91.1);

        this.shape_87 = new cjs.Shape();
        this.shape_87.graphics.f("#FFFFFF").s().p("AgkAzQAAglANghQAJgXAUgaQASgWAEgTQABARAKAsQAHAigDAaQgEAngiAXQgsAfgEAFQAIgVgBgmg");
        this.shape_87.setTransform(-27.1, 126.2);

        this.shape_88 = new cjs.Shape();
        this.shape_88.graphics.f("#FFFFFF").s().p("ABBB+IgagNQgcgRgLgKQgcgZgOggQgPgfgIg2QgJg6gKgbQAVATAwAlQAcAXATAaQAgAnAHA4QAIBDAGAQQgDgIgRgIg");
        this.shape_88.setTransform(-34.7, 97.2);

        this.shape_89 = new cjs.Shape();
        this.shape_89.graphics.f("#FFFFFF").s().p("AgjAVQgZgKgTgEQARgDARgKQARgNAcgFQAXgEAWAJQAYALALAAQgLAHgQANQgTANgkACIgEAAQgPAAgOgGg");
        this.shape_89.setTransform(-35.5, 115.7);

        this.shape_90 = new cjs.Shape();
        this.shape_90.graphics.f("#FFFFFF").s().p("AgGAWQgIgFgSgRQgRgTgagOQASAEAfgEQAbgFAOAGQAcALAMAVQAPAYAFAFQgZAGgMABIgCAAQgTAAgXgOg");
        this.shape_90.setTransform(-42.9, 124.6);

        this.shape_91 = new cjs.Shape();
        this.shape_91.graphics.f("#FFFFFF").s().p("AgyAiQAJgjAOgSQAUgaAggLQAigMAMgNQgOAZgIAnQgGAhgQAUQgRAXgcAHQgpAJgLAHQAKgMAKgkg");
        this.shape_91.setTransform(-60.9, 129.1);

        this.shape_92 = new cjs.Shape();
        this.shape_92.graphics.f("#FFFFFF").s().p("AgKAtQgPgTgBgVQgCgQAGgbQAHgeAAgNQACAPAQAUQASAWAEAVQAGAdgJAYQgLAcAAAEQgEgKgRgbg");
        this.shape_92.setTransform(-49.9, 133.9);

        this.shape_93 = new cjs.Shape();
        this.shape_93.graphics.f("#FFFFFF").s().p("AgnAcQAIgZAPgSQAKgNAagRQAagRAMgRQAGAigFAZQgEARgMAQQgQAZgbAPIg8AbQAMgVAJgfg");
        this.shape_93.setTransform(-14.4, 149.6);

        this.shape_94 = new cjs.Shape();
        this.shape_94.graphics.f("#FFFFFF").s().p("AAAAlQgKgMgCgKQgEgPgCgaQgBgZgGgOIAZAXQANANAGALQALAUgHAYQgHAdACALQgHgLgLgSg");
        this.shape_94.setTransform(-1.8, 151.6);

        this.shape_95 = new cjs.Shape();
        this.shape_95.graphics.f("#FFFFFF").s().p("AgHAiQgRgDgagOQgagOgfgEQAUgFAjgQQAZgLAYgBQAggBAaAQQAeASAXABQgLAAgoAUQgeAPgYAAIgKgBg");
        this.shape_95.setTransform(-71.1, 147.4);

        this.shape_96 = new cjs.Shape();
        this.shape_96.graphics.f("#FFFFFF").s().p("AhBAjQgCgxAVgbQASgXAigNQAogPAZgYQgHAVgNAwQgLAsgIAOQgQAlgeAWQgqAegOARQAHgVgCg9g");
        this.shape_96.setTransform(-66.6, 161.1);

        this.shape_97 = new cjs.Shape();
        this.shape_97.graphics.f("#FFFFFF").s().p("AgOAsQgSgEgqgUQgmgTgfgBQASAAAogVQArgWAigDQAlgEAnAeQA0AmAYAJQgVgCguAOQgbAJgcAAQgSAAgSgEg");
        this.shape_97.setTransform(-87.8, 132.5);

        this.shape_98 = new cjs.Shape();
        this.shape_98.graphics.f("#FFFFFF").s().p("AgYAkQgGgmADgOQAGgZATgRQAQgRABgKQABAMAIAlQAHAegCARQgEAdgSAQQgbAagDAEQAFgNgGglg");
        this.shape_98.setTransform(-106.7, 143.7);

        this.shape_99 = new cjs.Shape();
        this.shape_99.graphics.f("#FFFFFF").s().p("AAABwQgiglgTgxQgNgfADhCQADhFgMgjQAUAaAuAmQAqAlASAbQAdAogQBHQgSBYAFAYQgMgWgqgqg");
        this.shape_99.setTransform(-93.7, 155.9);

        this.shape_100 = new cjs.Shape();
        this.shape_100.graphics.f("#FFFFFF").s().p("AhbAWQATgFAWgRQAYgWAKgFQAQgIAqAJQAnAJALgIQgyA4guAAQg2gLghACg");
        this.shape_100.setTransform(-143.1, 95.7);

        this.shape_101 = new cjs.Shape();
        this.shape_101.graphics.f("#FFFFFF").s().p("AA1A7Qg1gJgbgTQgcgTgVgpQgUgogXgOQAcAMA3ACQArAAAfAVQAXAQAVApQAeA+AIANQgSgRgxgIg");
        this.shape_101.setTransform(-118.4, 102);

        this.shape_102 = new cjs.Shape();
        this.shape_102.graphics.f("#FFFFFF").s().p("AgtCGIgOgwQgRhBAThJQALgqAcgkQAZgjAFgTQAEAWAfA/QAYAxgDAsQgCAvgpAzQg1BEgMAZQACgYgHgbg");
        this.shape_102.setTransform(-133.5, 115.1);

        this.shape_103 = new cjs.Shape();
        this.shape_103.graphics.f("#FFFFFF").s().p("AgDAsQgsgMggggQgkgjgPgGQAqAGAmgIQAlgJAfAGQApAIAdAdQAdAbAOABQgFABg7AWQgSAHgTAAQgRAAgQgFg");
        this.shape_103.setTransform(-178.4, 69.5);

        this.shape_104 = new cjs.Shape();
        this.shape_104.graphics.f("#FFFFFF").s().p("AAZAsQgfgMgLgLQgTgSgHgZQgJgfgKgPQALAHAgAIQAaAIAQANQAUAQAJAhQAFASAGAiQgJgNgdgMg");
        this.shape_104.setTransform(-155.3, 82.2);

        this.shape_105 = new cjs.Shape();
        this.shape_105.graphics.f("#FFFFFF").s().p("AgHCVQgVgegJgQQgkg7AEhPQACguAuguQA3g4AJgUQAAAaANA3QAOA5ABAwQABA3geA2QgdA0ADA8QgIgbgPgcg");
        this.shape_105.setTransform(-169.1, 96.2);

        this.shape_106 = new cjs.Shape();
        this.shape_106.graphics.f("#FFFFFF").s().p("AhDBKQhggMgiAAQAygSA1gqQA4grAmgRQA2gXAwAJQA+AMAjgGQgTAOg0A7QgjAogyARQglAMgmAAQgRAAgSgCg");
        this.shape_106.setTransform(-174.5, 47.1);

        this.shape_107 = new cjs.Shape();
        this.shape_107.graphics.f("#FFFFFF").s().p("AgaApQgHgcAEgQQAEgUARgWQAPgWADgUQAEAcARAuQAHAmgiAjIgMAOQgJAJAAAFQAAgOgJghg");
        this.shape_107.setTransform(-152.2, 26.3);

        this.shape_108 = new cjs.Shape();
        this.shape_108.graphics.f("#FFFFFF").s().p("AAuBGQgjgKgagcQgPgPgVgpQgVgqgXgXQASALAyAKQAqAJAVAUQAeAdAKAlQALAwAJAPQgMgJgmgLg");
        this.shape_108.setTransform(-167.8, 26.5);

        this.shape_109 = new cjs.Shape();
        this.shape_109.graphics.f("#FFFFFF").s().p("AgxAqQAWgvAXgWQATgUAkgRQAfgOAIgPQAAAsgFAWQgIAegZAbQgZAcgqAQQgOAFg8APQAUgKAUgqg");
        this.shape_109.setTransform(-195.6, 23.2);

        this.shape_110 = new cjs.Shape();
        this.shape_110.graphics.f("#FFFFFF").s().p("AgsBLQhFgRgfg6IgWgtQgNgZgOgMQBJAVBwASQBDAMAuAfQA5ArAgALIhxAXQgcAGgdAAQggAAgkgIg");
        this.shape_110.setTransform(-207.9, 6.2);

        this.shape_111 = new cjs.Shape();
        this.shape_111.graphics.f("#FFFFFF").s().p("AgnAXQAOgcANgNQAMgMAagJQAbgLAKgHQgEAKgGAdQgHAZgOASQgPASgbAGQgjAEgRAGQAKgIANgcg");
        this.shape_111.setTransform(-194.4, -10.4);

        this.shape_112 = new cjs.Shape();
        this.shape_112.graphics.f("#FFFFFF").s().p("AgPBCQgPgcgDgYQgFgjAHglQAIgqAAgLQAIATAXAiQAUAcAFAXQAIAggJAdQgFAQgWAqQgEgQgQgeg");
        this.shape_112.setTransform(-185.6, -30.4);

        this.shape_113 = new cjs.Shape();
        this.shape_113.graphics.f("#FFFFFF").s().p("AgJA9QgpgHg0gmQhBgugYgLQAZACBNgPQBGgOA3AJQA4AIAgAcIBEA4QgfADhNASQgmAKgeAAQgOAAgLgDg");
        this.shape_113.setTransform(-208.4, -21.8);

        this.shape_114 = new cjs.Shape();
        this.shape_114.graphics.f("#FFFFFF").s().p("AgiAbIg2gLQAVgDAcgPQAegUAPgEQAYgGAWAEQAaAEALgCIgfAfQgQAOgYAIQgLADgLAAQgOAAgQgDg");
        this.shape_114.setTransform(-191.6, -51.9);

        this.shape_115 = new cjs.Shape();
        this.shape_115.graphics.f("#FFFFFF").s().p("AApBIQgVgHgIgFQgUgOgMgOQgPgTgHgZIgLgoQgGgVgGgKQADACAsAQQAbALAXAdQAWAaADAfQADAnAGANQgHgGgSgGg");
        this.shape_115.setTransform(-189.4, -66.2);

        this.shape_116 = new cjs.Shape();
        this.shape_116.graphics.f("#FFFFFF").s().p("AgeAhQAEgfAOgVQAHgMARgQQASgQAGgNQABARAGAeQAEAZgKAQQgKAUgYAPIguAeQAJgOAEgeg");
        this.shape_116.setTransform(-169, -81.6);

        this.shape_117 = new cjs.Shape();
        this.shape_117.graphics.f("#FFFFFF").s().p("AgKBTQgkgWgHgfQgGgYAFgrQAFg1gCgaQAIATAjAlQAiAnAHAOQAMAYACAqQACArAIAQQgwgWgTgNg");
        this.shape_117.setTransform(-165, -106.5);

        this.shape_118 = new cjs.Shape();
        this.shape_118.graphics.f("#FFFFFF").s().p("AAgBHQgwgHhJgwIh4hKQATACBogNQBZgMAwAPQAuAPAvAtQA6A0AIAFQgjAUg5AEIgYAAQgfAAgfgEg");
        this.shape_118.setTransform(-189.9, -97.5);

        this.shape_119 = new cjs.Shape();
        this.shape_119.graphics.f("#FFFFFF").s().p("Ag+AwQgLgFgVgPQgTgOgKgDQgTgFACgBQAJgCAFgDQAFgCAQgHQANgFAHgGQBCg2BSAgIAlAPQAaAJAPgEQgKAQgEAEQgOANgHACQgMADgOAJIgZAPQgXAMgiACIgPABQgaAAgTgHg");
        this.shape_119.setTransform(-142.4, -148);

        this.shape_120 = new cjs.Shape();
        this.shape_120.graphics.f("#FFFFFF").s().p("AgECAQgqgpgLg2QgOhBAJg5QAKhDgDgkQAVAeApAwQAkAsAMAwQAPA5gEAuQgJBWAAAbQgGgKg3g4g");
        this.shape_120.setTransform(-132.2, -172.3);

        this.shape_121 = new cjs.Shape();
        this.shape_121.graphics.f("#FFFFFF").s().p("Ag1AbQAPgjASgWQAUgaAcgHQAkgLAPgKQgCASgCAkQgHAegjAhQgdAbgQAHIhCATQAJgPAQgsg");
        this.shape_121.setTransform(-95, -136.3);

        this.shape_122 = new cjs.Shape();
        this.shape_122.graphics.f("#FFFFFF").s().p("AgXBlQgmg2gBgvQgCgtAQg3QAPgzgDghIAzBDQAgApALAvQANAzgTBEQgSBDAGAbQgqg1gVgeg");
        this.shape_122.setTransform(-108.9, -148.4);

        this.shape_123 = new cjs.Shape();
        this.shape_123.graphics.f("#FFFFFF").s().p("AhGBCQhEgRgogBQAfgOAvgmQAogiAzgQQAqgNA7ABQBCACAVgEQgkAvgUAVQgjAoglAOQgoAPgoAAQgUAAgVgDg");
        this.shape_123.setTransform(-95.3, -178.1);

        this.shape_124 = new cjs.Shape();
        this.shape_124.graphics.f("#FFFFFF").s().p("AgigKQAYg+gDg9QALAaAYAlQAVAkAAAtQgBAhgWAjQgYAmgEARQgxhVAXg7g");
        this.shape_124.setTransform(-58.6, -215.2);

        this.shape_125 = new cjs.Shape();
        this.shape_125.graphics.f("#FFFFFF").s().p("AgbA+QgNgDhIgeQgygVgkAAQgTAAAXgGIAigEQAQgCASgIQARgIANgKQApgiAxgGQA0gHA2AbIA2AeQAgATAWAFIhOAwQgfATgvACIgGAAQglAAgkgLg");
        this.shape_125.setTransform(-83.5, -200.9);

        this.shape_126 = new cjs.Shape();
        this.shape_126.graphics.f("#FFFFFF").s().p("AhfBBQhVgPgggCQArgLA6gmQA+gsARgGQA+gYBKAIQBLAIAigLQgXARgZAaIgnAlQguArhIAOQgTAEgYAAQgcAAgggGg");
        this.shape_126.setTransform(139.4, -147.5);

        this.shape_127 = new cjs.Shape();
        this.shape_127.graphics.f("#FFFFFF").s().p("AhGBnQAVhWAUgjQAcgxAtgxQAqgqAXg2QgFAdgFB2QgDBXgXAsQgZAwgwAgQhBAjgrAgQAUgdAShRg");
        this.shape_127.setTransform(93.6, -192.3);

        this.shape_128 = new cjs.Shape();
        this.shape_128.graphics.f("#FFFFFF").s().p("AAkAtQgggDgUgIQgYgIgXgaQglgmgMgKIA/AFQAoADAVAIQAfAKAaAcQAcAiAQAJIhNgEg");
        this.shape_128.setTransform(35, -193.9);

        this.shape_129 = new cjs.Shape();
        this.shape_129.graphics.f("#FFFFFF").s().p("Ag/A1QAVgyAGgKQAVgkArgdQA8glAOgOQgGAggHAzQgIAngSAXQgRAVguAaQhUAsgRALQAUgdASgqg");
        this.shape_129.setTransform(60.5, -202.5);

        this.shape_130 = new cjs.Shape();
        this.shape_130.graphics.f("#FFFFFF").s().p("AgXAwQgigEgkgRQgpgUgcgFQAVgDA3gZQAtgVAiAAQAigBAwAaQAyAaAmABIhfAeQgsANggAAIgPAAg");
        this.shape_130.setTransform(106, -167.2);

        this.shape_131 = new cjs.Shape();
        this.shape_131.graphics.f("#FFFFFF").s().p("AhAAWQgJgqgFhIQgHhggCgTQB2ByAhBFQAzBng6CBQheg5gbiBg");
        this.shape_131.setTransform(41.9, -217.2);

        this.shape_132 = new cjs.Shape();
        this.shape_132.graphics.f("#468309").s().p("EgizArpQjoAAinicQimiaAAjaMAAAhGxQAAjaCmibQCmibDpAAMBFmAAAQDqAACmCbQCmCbAADaMAAABGxQAADaimCaQinCcjpAAg");
        this.shape_132.setTransform(0.5, 0);

        this.shape_133 = new cjs.Shape();
        this.shape_133.graphics.f("#FFFFFF").s().p("EgufAugMAAAhc/MBc/AAAMAAABc/g");
        this.shape_133.setTransform(0.5, 0);

        this.addChild(this.shape_133, this.shape_132, this.shape_131, this.shape_130, this.shape_129, this.shape_128, this.shape_127, this.shape_126, this.shape_125, this.shape_124, this.shape_123, this.shape_122, this.shape_121, this.shape_120, this.shape_119, this.shape_118, this.shape_117, this.shape_116, this.shape_115, this.shape_114, this.shape_113, this.shape_112, this.shape_111, this.shape_110, this.shape_109, this.shape_108, this.shape_107, this.shape_106, this.shape_105, this.shape_104, this.shape_103, this.shape_102, this.shape_101, this.shape_100, this.shape_99, this.shape_98, this.shape_97, this.shape_96, this.shape_95, this.shape_94, this.shape_93, this.shape_92, this.shape_91, this.shape_90, this.shape_89, this.shape_88, this.shape_87, this.shape_86, this.shape_85, this.shape_84, this.shape_83, this.shape_82, this.shape_81, this.shape_80, this.shape_79, this.shape_78, this.shape_77, this.shape_76, this.shape_75, this.shape_74, this.shape_73, this.shape_72, this.shape_71, this.shape_70, this.shape_69, this.shape_68, this.shape_67, this.shape_66, this.shape_65, this.shape_64, this.shape_63, this.shape_62, this.shape_61, this.shape_60, this.shape_59, this.shape_58, this.shape_57, this.shape_56, this.shape_55, this.shape_54, this.shape_53, this.shape_52, this.shape_51, this.shape_50, this.shape_49, this.shape_48, this.shape_47, this.shape_46, this.shape_45, this.shape_44, this.shape_43, this.shape_42, this.shape_41, this.shape_40, this.shape_39, this.shape_38, this.shape_37, this.shape_36, this.shape_35, this.shape_34, this.shape_33, this.shape_32, this.shape_31, this.shape_30, this.shape_29, this.shape_28, this.shape_27, this.shape_26, this.shape_25, this.shape_24, this.shape_23, this.shape_22, this.shape_21, this.shape_20, this.shape_19, this.shape_18, this.shape_17, this.shape_16, this.shape_15, this.shape_14, this.shape_13, this.shape_12, this.shape_11, this.shape_10, this.shape_9, this.shape_8, this.shape_7, this.shape_6, this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.shape_1, this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-297, -297.6, 595.3, 595.3);


    (lib.IMG_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 2
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("Egm4AiNMAAAhEZMBNxAAAMAAABEZg");
        this.shape.setTransform(249, 239, 0.867, 0.909);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).wait(2));

        // Capa 1
        this.instance = new lib.arbol_IMG();
        this.instance.setTransform(241, 240.1, 0.681, 0.681, 0, 0, 0, 0.5, 0);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).wait(4));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(38.4, 37.4, 405.2, 405.3);


    (lib.diagrama_08MC = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, false, {});

        // Capa 36
        this.instance = new lib.Cara_MC();
        this.instance.setTransform(449.7, 279.7, 0.38, 0.38, 0, 0, 0, 0.4, 0);
        this.instance._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(17));

        // Capa 35
        this.instance_1 = new lib.Cruz_MC();
        this.instance_1.setTransform(399.7, 279.7, 0.335, 0.335, 0, 0, 0, 0.5, 0);
        this.instance_1._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(181).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(21));

        // Capa 34
        this.instance_2 = new lib.Cara_MC();
        this.instance_2.setTransform(349.7, 279.7, 0.391, 0.391, 0, 0, 0, 0.5, 0);
        this.instance_2._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(177).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(25));

        // Capa 33
        this.instance_3 = new lib.Cruz_MC();
        this.instance_3.setTransform(299.7, 279.7, 0.346, 0.346, 0, 0, 0, 0.5, 0);
        this.instance_3._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(173).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(29));

        // Capa 32
        this.instance_4 = new lib.Cara_MC();
        this.instance_4.setTransform(409.8, 209.7, 0.295, 0.295, 0, 0, 0, 0.6, 0);
        this.instance_4._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(169).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11, x: 409.7}, 3).wait(33));

        // Capa 31
        this.instance_5 = new lib.Cruz_MC();
        this.instance_5.setTransform(339.7, 209.7, 0.441, 0.441, 0, 0, 0, 0.5, 0);
        this.instance_5._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(165).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(37));

        // Capa 30
        this.instance_6 = new lib.Cara_MC();
        this.instance_6.setTransform(369.7, 139.7, 0.413, 0.413, 0, 0, 0, 0.4, 0);
        this.instance_6._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(161).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(41));

        // Capa 29
        this.instance_7 = new lib.Cara_MC();
        this.instance_7.setTransform(209.7, 279.7, 0.335, 0.335, 0, 0, 0, 0.5, 0);
        this.instance_7._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(157).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(45));

        // Capa 28
        this.instance_8 = new lib.Cruz_MC();
        this.instance_8.setTransform(159.7, 279.7, 0.385, 0.385, 0, 0, 0, 0.4, 0);
        this.instance_8._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(153).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(49));

        // Capa 27
        this.instance_9 = new lib.Cara_MC();
        this.instance_9.setTransform(109.7, 279.7, 0.357, 0.357, 0, 0, 0, 0.4, 0);
        this.instance_9._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(149).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(53));

        // Capa 26
        this.instance_10 = new lib.Cruz_MC();
        this.instance_10.setTransform(59.7, 279.7, 0.402, 0.402, 0, 0, 0, 0.5, 0);
        this.instance_10._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(145).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(57));

        // Capa 25
        this.instance_11 = new lib.Cara_MC();
        this.instance_11.setTransform(169.7, 209.7, 0.525, 0.525, 0, 0, 0, 0.5, 0);
        this.instance_11._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(141).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(61));

        // Capa 24
        this.instance_12 = new lib.Cruz_MC();
        this.instance_12.setTransform(89.7, 209.7, 0.413, 0.413, 0, 0, 0, 0.5, 0);
        this.instance_12._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(137).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(65));

        // Capa 23
        this.instance_13 = new lib.Cruz_MC();
        this.instance_13.setTransform(139.7, 139.7, 0.357, 0.357, 0, 0, 0, 0.4, 0);
        this.instance_13._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(133).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(69));

        // Capa 22
        this.instance_14 = new lib.Cara_MC();
        this.instance_14.setTransform(259.7, 69.7, 0.391, 0.391, 0, 0, 0, 0.5, 0);
        this.instance_14._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(129).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(73));

        // Capa 21
        this.instance_15 = new lib.Cara_MC();
        this.instance_15.setTransform(-10.2, 279.7, 0.374, 0.374, 0, 0, 0, 0.4, 0);
        this.instance_15._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(125).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(77));

        // Capa 20
        this.instance_16 = new lib.Cruz_MC();
        this.instance_16.setTransform(-60.1, 279.7, 0.397, 0.397, 0, 0, 0, 0.6, 0);
        this.instance_16._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(121).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11, x: -60.1}, 3).wait(81));

        // Capa 19
        this.instance_17 = new lib.Cara_MC();
        this.instance_17.setTransform(-110.2, 279.7, 0.346, 0.346, 0, 0, 0, 0.5, 0);
        this.instance_17._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(117).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(85));

        // Capa 18
        this.instance_18 = new lib.Cruz_MC();
        this.instance_18.setTransform(-160.1, 279.7, 0.391, 0.391, 0, 0, 0, 0.6, 0);
        this.instance_18._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(113).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11, x: -160.1}, 3).wait(89));

        // Capa 17
        this.instance_19 = new lib.Cara_MC();
        this.instance_19.setTransform(-50.2, 209.7, 0.447, 0.447, 0, 0, 0, 0.5, 0);
        this.instance_19._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(109).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(93));

        // Capa 16
        this.instance_20 = new lib.Cruz_MC();
        this.instance_20.setTransform(-120.2, 209.7, 0.492, 0.492, 0, 0, 0, 0.4, 0);
        this.instance_20._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(104).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 3).wait(98));

        // Capa 15
        this.instance_21 = new lib.Cara_MC();
        this.instance_21.setTransform(-250.2, 279.7, 0.436, 0.436, 0, 0, 0, 0.5, 0);
        this.instance_21._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(98).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 3).wait(104));

        // Capa 14
        this.instance_22 = new lib.Cruz_MC();
        this.instance_22.setTransform(-300.2, 279.7, 0.733, 0.733, 0, 0, 0, 0.5, 0);
        this.instance_22._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(92).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 4).wait(109));

        // Capa 10
        this.instance_23 = new lib.Cara_MC();
        this.instance_23.setTransform(-350.2, 279.7, 0.61, 0.61, 0, 0, 0, 0.4, 0);
        this.instance_23._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(84).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 5).wait(116));

        // Capa 9
        this.instance_24 = new lib.Cruz_MC();
        this.instance_24.setTransform(-400.2, 279.7, 0.548, 0.548, 0, 0, 0, 0.5, 0);
        this.instance_24._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(74).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 6).wait(125));

        // Capa 8
        this.instance_25 = new lib.Cara_MC();
        this.instance_25.setTransform(-290.2, 209.7, 0.514, 0.514, 0, 0, 0, 0.5, 0);
        this.instance_25._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(63).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 6).wait(136));

        // Capa 6
        this.instance_26 = new lib.Cruz_MC();
        this.instance_26.setTransform(-370.2, 209.7, 0.531, 0.531, 0, 0, 0, 0.5, 0);
        this.instance_26._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(51).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 7).wait(147));

        // Capa 5
        this.instance_27 = new lib.Cara_MC();
        this.instance_27.setTransform(29.7, 19.7, 0.643, 0.643, 0, 0, 0, 0.5, 0);
        this.instance_27._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(1).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 8).wait(196));

        // Capa 4
        this.instance_28 = new lib.Cruz_MC();
        this.instance_28.setTransform(-200.2, 69.7, 0.486, 0.486, 0, 0, 0, 0.4, 0);
        this.instance_28._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(12).to({_off: false}, 0).to({regX: 0.5, scaleX: 0.11, scaleY: 0.11}, 8).wait(185));

        // Capa 3
        this.instance_29 = new lib.Cruz_MC();
        this.instance_29.setTransform(-320.2, 139.7, 0.503, 0.503, 0, 0, 0, 0.5, 0);
        this.instance_29._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(25).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 8).wait(172));

        // Capa 7
        this.instance_30 = new lib.Cara_MC();
        this.instance_30.setTransform(-90.2, 139.7, 0.525, 0.525, 0, 0, 0, 0.5, 0);
        this.instance_30._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(39).to({_off: false}, 0).to({scaleX: 0.11, scaleY: 0.11}, 7).wait(159));

        // Capa 37
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AAFiBIC+DaAikhtIgeDv");
        this.shape.setTransform(-277.5, 243.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("APTnaIhkD6AsKDWIC+DcAu0DqIgeDx");
        this.shape_1.setTransform(-199, 209.1);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#000000").ss(1, 1, 1).p("AMGnQIhkD6APYnkIDIEEAvXDgIC+DcAyBD0IgeDx");
        this.shape_2.setTransform(-178.5, 208.1);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#000000").ss(1, 1, 1).p("AMGnQIhkD6APYnkIDIEEAvXDgIC+DcAyBD0IgeDxAGyC4IjSEt");
        this.shape_3.setTransform(-178.5, 208.1);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#000000").ss(1, 1, 1).p("AMGnhIhkD6APYn1IDIEEAvXDPIC+DcAyBDjIgeDxAJ6DPIAxEmAGyCnIjSEt");
        this.shape_4.setTransform(-178.5, 209.8);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(1, 1, 1).p("AL3nhIhkD6APJn1IDIEEAvmDPIC+DcAyQDjIgeDxASvDtIgyDSAJrDPIAxEmAGjCnIjSEt");
        this.shape_5.setTransform(-177, 209.8);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f().s("#000000").ss(1, 1, 1).p("AIvnhIhkD6AMBn1IDIEEAyuDPIC+DcA1YDjIgeDxASlC7IDSD6APnDtIgyDSAGjDPIAxEmADbCnIjSEt");
        this.shape_6.setTransform(-157, 209.8);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#000000").ss(1, 1, 1).p("AMQxmIdOEYAq2COIhkD6AnkB6IDIEEEgmVANAIC+DcEgo/ANUIgeDxAhAMsIDQD6Aj+NeIgyDSAtCNAIAxEnAwKMYIjSEt");
        this.shape_7.setTransform(-31.5, 147.3);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+ALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgm0ANAIC+DcEgpeANUIgeDxAheMsIDQD6AkcNeIgyDSAthNAIAxEnAwpMYIjSEt");
        this.shape_8.setTransform(-28.5, 147.3);

        this.shape_9 = new cjs.Shape();
        this.shape_9.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgpeANUIgeDxEgm0ANAIC+DcAkcNeIgyDSAheMsIDQD6AwpMYIjSEtAthNAIAxEn");
        this.shape_9.setTransform(-28.5, 147.3);

        this.shape_10 = new cjs.Shape();
        this.shape_10.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQALyxmIdOEYAb4BwICgEEArVCOIhkD6AoDB6IDJEEEgpeANUIgeDxEgm0ANAIC+DcAkcNeIgyDSAheMsIDQD6AwpMYIjSEtAthNAIAxEn");
        this.shape_10.setTransform(-28.5, 147.3);

        this.shape_11 = new cjs.Shape();
        this.shape_11.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQAQyM2Ih4EPAb4BwICgEEALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgm0ANAIC+DcEgpeANUIgeDxAheMsIDQD6AkcNeIgyDSAthNAIAxEnAwpMYIjSEt");
        this.shape_11.setTransform(-28.5, 147.3);

        this.shape_12 = new cjs.Shape();
        this.shape_12.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQATmNKIBQDwAQyM2Ih4EPAb4BwICgEEALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgm0ANAIC+DcEgpeANUIgeDxAheMsIDQD6AkcNeIgyDSAthNAIAxEnAwpMYIjSEt");
        this.shape_12.setTransform(-28.5, 147.3);

        this.shape_13 = new cjs.Shape();
        this.shape_13.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQATmNKIBQDwAQyM2Ih4EPAeYNUIgeDSAb4BwICgEEALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgm0ANAIC+DcEgpeANUIgeDxAheMsIDQD6AkcNeIgyDSAthNAIAxEnAwpMYIjSEt");
        this.shape_13.setTransform(-28.5, 147.3);

        this.shape_14 = new cjs.Shape();
        this.shape_14.graphics.f().s("#000000").ss(1, 1, 1).p("EAp9gJCIrvF+AXNB4Ii1EQATmNKIBQDwAQyM2Ih4EPEAhMAMsIDIDmAeYNUIgeDSAb4BwICgEEALyxmIdOEYArVCOIhkD6AoDB6IDJEEEgm0ANAIC+DcEgpeANUIgeDxAheMsIDQD6AkcNeIgyDSAthNAIAxEnAwpMYIjSEt");
        this.shape_14.setTransform(-28.5, 147.3);

        this.shape_15 = new cjs.Shape();
        this.shape_15.graphics.f().s("#000000").ss(1, 1, 1).p("EAhXgJCIrvF+AOnB4Ii1EQALANKIBQDwAIMM2Ih4EPAYmMsIDIDmAVyNUIgeDSATSBwICgEEADMxmIdOEYEAnhgJCILCEyAz7COIhkD6AwpB6IDIEEEgvaANAIC+DcEgyEANUIgeDxAqFMsIDTD6AtDNeIgyDSA2HNAIAxEnA5PMYIjSEt");
        this.shape_15.setTransform(26.5, 147.3);

        this.shape_16 = new cjs.Shape();
        this.shape_16.graphics.f().s("#000000").ss(1, 1, 1).p("EAzKAB6IiCD6EAgwgJCIrwF+AOAB4Ii2EQAKYNKIBQDwAHkM2Ih4EPAX+MsIDIDmAVKNUIgeDSASqBwICgEEACkxmIdOEYEAm6gJCILCEyA0iCOIhkD6AxQB6IDIEEEgwBANAIC+DcEgyrANUIgeDxAqsMsIDSD6AtqNeIgyDSA2uNAIAxEnA52MYIjSEt");
        this.shape_16.setTransform(30.4, 147.3);

        this.shape_17 = new cjs.Shape();
        this.shape_17.graphics.f().s("#000000").ss(1, 1, 1).p("EAvuAB6IiCD6EAzyABSIC0EiAdUpCIrwF+AKkB4Ii2EQAG8NKIBQDwAEIM2Ih4EPAUiMsIDIDmARuNUIgeDSAPOBwICgEEAg2xmIdMEYEAjegJCILCEyA3+COIhkD6A0sB6IDIEEEgzdANAIC+DcEg2HANUIgeDxAuIMsIDSD6AxGNeIgyDSA6KNAIAxEnA9SMYIjSEt");
        this.shape_17.setTransform(52.4, 147.3);

        this.shape_18 = new cjs.Shape();
        this.shape_18.graphics.f().s("#000000").ss(1, 1, 1).p("EAvuAB6IiCD6EAzyABSIC0EiAdUpCIrwF+AKkB4Ii2EQAG8NKIBQDwAEIM2Ih4EPARuNUIgeDSAUiMsIDIDmAg2xmIdMEYAPOBwICgEEEAjegJCILCEyEAquAMsIiqD6A3+COIhkD6A0sB6IDIEEEg2HANUIgeDxEgzdANAIC+DcAxGNeIgyDSAuIMsIDSD6A9SMYIjSEtA6KNAIAxEn");
        this.shape_18.setTransform(52.4, 147.3);

        this.shape_19 = new cjs.Shape();
        this.shape_19.graphics.f().s("#000000").ss(1, 1, 1).p("EAvuAB6IiCD6EAzyABSIC0EiEAtsANUIAoDcAdUpCIrwF+AKkB4Ii2EQAG8NKIBQDwAEIM2Ih4EPAUiMsIDIDmARuNUIgeDSAPOBwICgEEAg2xmIdMEYEAquAMsIiqD6EAjegJCILCEyA3+COIhkD6A0sB6IDIEEEgzdANAIC+DcEg2HANUIgeDxAuIMsIDSD6AxGNeIgyDSA6KNAIAxEnA9SMYIjSEt");
        this.shape_19.setTransform(52.4, 147.3);

        this.shape_20 = new cjs.Shape();
        this.shape_20.graphics.f().s("#000000").ss(1, 1, 1).p("EAvpAB6IiCD6EAztABSIC0EiEAtnANUIAoDcEA2rAM2Ig9ETAdPpCIrwF+AKfB4Ii2EQAG3NKIBQDwAEDM2Ih4EPAUdMsIDIDmARpNUIgeDSAPJBwICgEEAg7xmIdMEYEAqpAMsIiqD6EAjZgJCILCEyA4DCOIhkD6A0xB6IDIEEEgziANAIC+DcEg2MANUIgeDxAuNMsIDSD6AxLNeIgyDSA6PNAIAxEnA9XMYIjSEt");
        this.shape_20.setTransform(52.9, 147.3);

        this.shape_21 = new cjs.Shape();
        this.shape_21.graphics.f().s("#000000").ss(1, 1, 1).p("EAscAB6IiCD6EAwgABSIC0EiEA2mAM2IDSD6EAqaANUIAoDcEAzeAM2Ig9ETAaCpCIrwF+AHSB4Ii2EQADqNKIBQDwAA2M2Ih2EPARQMsIDIDmAOcNUIgeDSAL8BwICgEEAkIxmIdMEYEAncAMsIiqD6EAgMgJCILCEyA7QCOIhkD6A3+B6IDIEEEg2vANAIC+DcEg5ZANUIgeDxAxaMsIDSD6A0YNeIgyDSA9cNAIAxEnEggkAMYIjSEt");
        this.shape_21.setTransform(73.4, 147.3);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 96).to({state: [{t: this.shape}]}, 5).to({state: [{t: this.shape_1}]}, 6).to({state: [{t: this.shape_2}]}, 5).to({state: [{t: this.shape_3}]}, 4).to({state: [{t: this.shape_4}]}, 4).to({state: [{t: this.shape_5}]}, 4).to({state: [{t: this.shape_6}]}, 4).to({state: [{t: this.shape_7}]}, 4).to({state: [{t: this.shape_8}]}, 4).to({state: [{t: this.shape_9}]}, 4).to({state: [{t: this.shape_10}]}, 4).to({state: [{t: this.shape_11}]}, 4).to({state: [{t: this.shape_12}]}, 4).to({state: [{t: this.shape_13}]}, 4).to({state: [{t: this.shape_14}]}, 4).to({state: [{t: this.shape_15}]}, 4).to({state: [{t: this.shape_16}]}, 4).to({state: [{t: this.shape_17}]}, 4).to({state: [{t: this.shape_18}]}, 4).to({state: [{t: this.shape_19}]}, 4).to({state: [{t: this.shape_20}]}, 4).to({state: [{t: this.shape_21}]}, 4).wait(17));

        // Capa 40
        this.text = new cjs.Text("0,5", "16px Verdana");
        this.text.lineHeight = 16;
        this.text.setTransform(-43.3, 47.4);

        this.text_1 = new cjs.Text("0,5", "16px Verdana");
        this.text_1.lineHeight = 16;
        this.text_1.setTransform(-43.3, 47.4);

        this.text_2 = new cjs.Text("0,5", "16px Verdana");
        this.text_2.lineHeight = 16;
        this.text_2.setTransform(-43.3, 47.4);

        this.text_3 = new cjs.Text("0,5", "16px Verdana");
        this.text_3.lineHeight = 16;
        this.text_3.setTransform(-43.3, 47.4);

        this.text_4 = new cjs.Text("0,5", "16px Verdana");
        this.text_4.lineHeight = 16;
        this.text_4.setTransform(-43.3, 47.4);

        this.text_5 = new cjs.Text("0,5", "16px Verdana");
        this.text_5.lineHeight = 16;
        this.text_5.setTransform(-43.3, 47.4);

        this.text_6 = new cjs.Text("0,5", "16px Verdana");
        this.text_6.lineHeight = 16;
        this.text_6.setTransform(-43.3, 47.4);

        this.text_7 = new cjs.Text("0,5", "16px Verdana");
        this.text_7.lineHeight = 16;
        this.text_7.setTransform(-43.3, 47.4);

        this.text_8 = new cjs.Text("0,5", "16px Verdana");
        this.text_8.lineHeight = 16;
        this.text_8.setTransform(-43.3, 47.4);

        this.text_9 = new cjs.Text("0,5", "16px Verdana");
        this.text_9.lineHeight = 16;
        this.text_9.setTransform(-43.3, 47.4);

        this.text_10 = new cjs.Text("0,5", "16px Verdana");
        this.text_10.lineHeight = 16;
        this.text_10.setTransform(-43.3, 47.4);

        this.text_11 = new cjs.Text("0,5", "16px Verdana");
        this.text_11.lineHeight = 16;
        this.text_11.setTransform(-43.3, 47.4);

        this.text_12 = new cjs.Text("0,5", "16px Verdana");
        this.text_12.lineHeight = 16;
        this.text_12.setTransform(-43.3, 47.4);

        this.text_13 = new cjs.Text("0,5", "16px Verdana");
        this.text_13.lineHeight = 16;
        this.text_13.setTransform(-43.3, 47.4);

        this.text_14 = new cjs.Text("0,5", "16px Verdana");
        this.text_14.lineHeight = 16;
        this.text_14.setTransform(-43.3, 47.4);

        this.text_15 = new cjs.Text("0,5", "16px Verdana");
        this.text_15.lineHeight = 16;
        this.text_15.setTransform(-43.3, 47.4);

        this.text_16 = new cjs.Text("0,5", "16px Verdana");
        this.text_16.lineHeight = 16;
        this.text_16.setTransform(-43.3, 47.4);

        this.text_17 = new cjs.Text("0,5", "16px Verdana");
        this.text_17.lineHeight = 16;
        this.text_17.setTransform(-43.3, 47.4);

        this.text_18 = new cjs.Text("0,5", "16px Verdana");
        this.text_18.lineHeight = 16;
        this.text_18.setTransform(-43.3, 47.4);

        this.text_19 = new cjs.Text("0,5", "16px Verdana");
        this.text_19.lineHeight = 16;
        this.text_19.setTransform(-43.3, 47.4);

        this.text_20 = new cjs.Text("0,5", "16px Verdana");
        this.text_20.lineHeight = 16;
        this.text_20.setTransform(-43.3, 47.4);

        this.text_21 = new cjs.Text("0,5", "16px Verdana");
        this.text_21.lineHeight = 16;
        this.text_21.setTransform(-43.3, 47.4);

        this.text_22 = new cjs.Text("0,5", "16px Verdana");
        this.text_22.lineHeight = 16;
        this.text_22.setTransform(-43.3, 47.4);

        this.text_23 = new cjs.Text("0,5", "16px Verdana");
        this.text_23.lineHeight = 16;
        this.text_23.setTransform(-43.3, 47.4);

        this.text_24 = new cjs.Text("0,5", "16px Verdana");
        this.text_24.lineHeight = 16;
        this.text_24.setTransform(-43.3, 47.4);

        this.text_25 = new cjs.Text("0,5", "16px Verdana");
        this.text_25.lineHeight = 16;
        this.text_25.setTransform(-43.3, 47.4);

        this.text_26 = new cjs.Text("0,5", "16px Verdana");
        this.text_26.lineHeight = 16;
        this.text_26.setTransform(-43.3, 47.4);

        this.text_27 = new cjs.Text("0,5", "16px Verdana");
        this.text_27.lineHeight = 16;
        this.text_27.setTransform(-43.3, 47.4);

        this.text_28 = new cjs.Text("0,5", "16px Verdana");
        this.text_28.lineHeight = 16;
        this.text_28.setTransform(-43.3, 47.4);

        this.text_29 = new cjs.Text("0,5", "16px Verdana");
        this.text_29.lineHeight = 16;
        this.text_29.setTransform(-43.3, 47.4);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.text, p: {x: -43.3, y: 47.4}}]}, 20).to({state: [{t: this.text_1, p: {x: -43.3, y: 47.4}}, {t: this.text, p: {x: -250.2, y: 97.8}}]}, 13).to({state: [{t: this.text_2, p: {x: -43.3, y: 47.4}}, {t: this.text_1, p: {x: -250.2, y: 97.8}}, {t: this.text, p: {x: -185.2, y: 100.4}}]}, 13).to({state: [{t: this.text_3, p: {x: -43.3, y: 47.4}}, {t: this.text_2, p: {x: -250.2, y: 97.8}}, {t: this.text_1, p: {x: -185.2, y: 100.4}}, {t: this.text, p: {x: -380.2, y: 144.3}}]}, 12).to({state: [{t: this.text_4, p: {x: -43.3, y: 47.4}}, {t: this.text_3, p: {x: -250.2, y: 97.8}}, {t: this.text_2, p: {x: -185.2, y: 100.4}}, {t: this.text_1, p: {x: -380.2, y: 144.3}}, {t: this.text, p: {x: -293.1, y: 144.3}}]}, 11).to({state: [{t: this.text_5, p: {x: -43.3, y: 47.4}}, {t: this.text_4, p: {x: -250.2, y: 97.8}}, {t: this.text_3, p: {x: -185.2, y: 100.4}}, {t: this.text_2, p: {x: -380.2, y: 144.3}}, {t: this.text_1, p: {x: -293.1, y: 144.3}}, {t: this.text, p: {x: -421.8, y: 221}}]}, 11).to({state: [{t: this.text_6, p: {x: -43.3, y: 47.4}}, {t: this.text_5, p: {x: -250.2, y: 97.8}}, {t: this.text_4, p: {x: -185.2, y: 100.4}}, {t: this.text_3, p: {x: -380.2, y: 144.3}}, {t: this.text_2, p: {x: -293.1, y: 144.3}}, {t: this.text_1, p: {x: -421.8, y: 221}}, {t: this.text, p: {x: -356.8, y: 223.6}}]}, 9).to({state: [{t: this.text_7, p: {x: -43.3, y: 47.4}}, {t: this.text_6, p: {x: -250.2, y: 97.8}}, {t: this.text_5, p: {x: -185.2, y: 100.4}}, {t: this.text_4, p: {x: -380.2, y: 144.3}}, {t: this.text_3, p: {x: -293.1, y: 144.3}}, {t: this.text_2, p: {x: -421.8, y: 221}}, {t: this.text_1, p: {x: -356.8, y: 224.9}}, {t: this.text, p: {x: -325.6, y: 224.9}}]}, 7).to({state: [{t: this.text_8, p: {x: -43.3, y: 47.4}}, {t: this.text_7, p: {x: -250.2, y: 97.8}}, {t: this.text_6, p: {x: -185.2, y: 100.4}}, {t: this.text_5, p: {x: -380.2, y: 144.3}}, {t: this.text_4, p: {x: -293.1, y: 144.3}}, {t: this.text_3, p: {x: -421.8, y: 221}}, {t: this.text_2, p: {x: -356.8, y: 224.9}}, {t: this.text_1, p: {x: -325.6, y: 224.9}}, {t: this.text, p: {x: -264.5, y: 224.9}}]}, 5).to({state: [{t: this.text_9, p: {x: -43.3, y: 47.4}}, {t: this.text_8, p: {x: -250.2, y: 97.8}}, {t: this.text_7, p: {x: -185.2, y: 100.4}}, {t: this.text_6, p: {x: -380.2, y: 144.3}}, {t: this.text_5, p: {x: -293.1, y: 144.3}}, {t: this.text_4, p: {x: -421.8, y: 221}}, {t: this.text_3, p: {x: -356.8, y: 224.9}}, {t: this.text_2, p: {x: -325.6, y: 224.9}}, {t: this.text_1, p: {x: -264.5, y: 224.9}}, {t: this.text, p: {x: -146.2, y: 152.4}}]}, 6).to({state: [{t: this.text_10, p: {x: -43.3, y: 47.4}}, {t: this.text_9, p: {x: -250.2, y: 97.8}}, {t: this.text_8, p: {x: -185.2, y: 100.4}}, {t: this.text_7, p: {x: -380.2, y: 144.3}}, {t: this.text_6, p: {x: -293.1, y: 144.3}}, {t: this.text_5, p: {x: -421.8, y: 221}}, {t: this.text_4, p: {x: -356.8, y: 224.9}}, {t: this.text_3, p: {x: -325.6, y: 224.9}}, {t: this.text_2, p: {x: -264.5, y: 224.9}}, {t: this.text_1, p: {x: -146.2, y: 152.4}}, {t: this.text, p: {x: -68.2, y: 152.4}}]}, 5).to({state: [{t: this.text_11, p: {x: -43.3, y: 47.4}}, {t: this.text_10, p: {x: -250.2, y: 97.8}}, {t: this.text_9, p: {x: -185.2, y: 100.4}}, {t: this.text_8, p: {x: -380.2, y: 144.3}}, {t: this.text_7, p: {x: -293.1, y: 144.3}}, {t: this.text_6, p: {x: -421.8, y: 221}}, {t: this.text_5, p: {x: -356.8, y: 224.9}}, {t: this.text_4, p: {x: -325.6, y: 224.9}}, {t: this.text_3, p: {x: -264.5, y: 224.9}}, {t: this.text_2, p: {x: -146.2, y: 152.4}}, {t: this.text_1, p: {x: -68.2, y: 152.4}}, {t: this.text, p: {x: -183.9, y: 225.2}}]}, 4).to({state: [{t: this.text_12, p: {x: -43.3, y: 47.4}}, {t: this.text_11, p: {x: -250.2, y: 97.8}}, {t: this.text_10, p: {x: -185.2, y: 100.4}}, {t: this.text_9, p: {x: -380.2, y: 144.3}}, {t: this.text_8, p: {x: -293.1, y: 144.3}}, {t: this.text_7, p: {x: -421.8, y: 221}}, {t: this.text_6, p: {x: -356.8, y: 224.9}}, {t: this.text_5, p: {x: -325.6, y: 224.9}}, {t: this.text_4, p: {x: -264.5, y: 224.9}}, {t: this.text_3, p: {x: -146.2, y: 152.4}}, {t: this.text_2, p: {x: -68.2, y: 152.4}}, {t: this.text_1, p: {x: -183.9, y: 225.2}}, {t: this.text, p: {x: -112.4, y: 225.2}}]}, 4).to({state: [{t: this.text_13, p: {x: -43.3, y: 47.4}}, {t: this.text_12, p: {x: -250.2, y: 97.8}}, {t: this.text_11, p: {x: -185.2, y: 100.4}}, {t: this.text_10, p: {x: -380.2, y: 144.3}}, {t: this.text_9, p: {x: -293.1, y: 144.3}}, {t: this.text_8, p: {x: -421.8, y: 221}}, {t: this.text_7, p: {x: -356.8, y: 224.9}}, {t: this.text_6, p: {x: -325.6, y: 224.9}}, {t: this.text_5, p: {x: -264.5, y: 224.9}}, {t: this.text_4, p: {x: -146.2, y: 152.4}}, {t: this.text_3, p: {x: -68.2, y: 152.4}}, {t: this.text_2, p: {x: -183.9, y: 225.2}}, {t: this.text_1, p: {x: -116.3, y: 225.2}}, {t: this.text, p: {x: -87.7, y: 225.2}}]}, 4).to({state: [{t: this.text_14, p: {x: -43.3, y: 47.4}}, {t: this.text_13, p: {x: -250.2, y: 97.8}}, {t: this.text_12, p: {x: -185.2, y: 100.4}}, {t: this.text_11, p: {x: -380.2, y: 144.3}}, {t: this.text_10, p: {x: -293.1, y: 144.3}}, {t: this.text_9, p: {x: -421.8, y: 221}}, {t: this.text_8, p: {x: -356.8, y: 224.9}}, {t: this.text_7, p: {x: -325.6, y: 224.9}}, {t: this.text_6, p: {x: -264.5, y: 224.9}}, {t: this.text_5, p: {x: -146.2, y: 152.4}}, {t: this.text_4, p: {x: -68.2, y: 152.4}}, {t: this.text_3, p: {x: -183.9, y: 225.2}}, {t: this.text_2, p: {x: -116.3, y: 225.2}}, {t: this.text_1, p: {x: -87.7, y: 225.2}}, {t: this.text, p: {x: -27.9, y: 225.2}}]}, 4).to({state: [{t: this.text_15, p: {x: -43.3, y: 47.4}}, {t: this.text_14, p: {x: -250.2, y: 97.8}}, {t: this.text_13, p: {x: -185.2, y: 100.4}}, {t: this.text_12, p: {x: -380.2, y: 144.3}}, {t: this.text_11, p: {x: -293.1, y: 144.3}}, {t: this.text_10, p: {x: -421.8, y: 221}}, {t: this.text_9, p: {x: -356.8, y: 224.9}}, {t: this.text_8, p: {x: -325.6, y: 224.9}}, {t: this.text_7, p: {x: -264.5, y: 224.9}}, {t: this.text_6, p: {x: -146.2, y: 152.4}}, {t: this.text_5, p: {x: -68.2, y: 152.4}}, {t: this.text_4, p: {x: -183.9, y: 225.2}}, {t: this.text_3, p: {x: -116.3, y: 225.2}}, {t: this.text_2, p: {x: -87.7, y: 225.2}}, {t: this.text_1, p: {x: -27.9, y: 225.2}}, {t: this.text, p: {x: 60.6, y: 47.4}}]}, 4).to({state: [{t: this.text_16, p: {x: -43.3, y: 47.4}}, {t: this.text_15, p: {x: -250.2, y: 97.8}}, {t: this.text_14, p: {x: -185.2, y: 100.4}}, {t: this.text_13, p: {x: -380.2, y: 144.3}}, {t: this.text_12, p: {x: -293.1, y: 144.3}}, {t: this.text_11, p: {x: -421.8, y: 221}}, {t: this.text_10, p: {x: -356.8, y: 224.9}}, {t: this.text_9, p: {x: -325.6, y: 224.9}}, {t: this.text_8, p: {x: -264.5, y: 224.9}}, {t: this.text_7, p: {x: -146.2, y: 152.4}}, {t: this.text_6, p: {x: -68.2, y: 152.4}}, {t: this.text_5, p: {x: -183.9, y: 225.2}}, {t: this.text_4, p: {x: -116.3, y: 225.2}}, {t: this.text_3, p: {x: -87.7, y: 225.2}}, {t: this.text_2, p: {x: -27.9, y: 225.2}}, {t: this.text_1, p: {x: 60.6, y: 47.4}}, {t: this.text, p: {x: 216.6, y: 99.4}}]}, 4).to({state: [{t: this.text_17, p: {x: -43.3, y: 47.4}}, {t: this.text_16, p: {x: -250.2, y: 97.8}}, {t: this.text_15, p: {x: -185.2, y: 100.4}}, {t: this.text_14, p: {x: -380.2, y: 144.3}}, {t: this.text_13, p: {x: -293.1, y: 144.3}}, {t: this.text_12, p: {x: -421.8, y: 221}}, {t: this.text_11, p: {x: -356.8, y: 224.9}}, {t: this.text_10, p: {x: -325.6, y: 224.9}}, {t: this.text_9, p: {x: -264.5, y: 224.9}}, {t: this.text_8, p: {x: -146.2, y: 152.4}}, {t: this.text_7, p: {x: -68.2, y: 152.4}}, {t: this.text_6, p: {x: -183.9, y: 225.2}}, {t: this.text_5, p: {x: -116.3, y: 225.2}}, {t: this.text_4, p: {x: -87.7, y: 225.2}}, {t: this.text_3, p: {x: -27.9, y: 225.2}}, {t: this.text_2, p: {x: 60.6, y: 47.4}}, {t: this.text_1, p: {x: 216.6, y: 99.4}}, {t: this.text, p: {x: 77.5, y: 148.8}}]}, 4).to({state: [{t: this.text_18, p: {x: -43.3, y: 47.4}}, {t: this.text_17, p: {x: -250.2, y: 97.8}}, {t: this.text_16, p: {x: -185.2, y: 100.4}}, {t: this.text_15, p: {x: -380.2, y: 144.3}}, {t: this.text_14, p: {x: -293.1, y: 144.3}}, {t: this.text_13, p: {x: -421.8, y: 221}}, {t: this.text_12, p: {x: -356.8, y: 224.9}}, {t: this.text_11, p: {x: -325.6, y: 224.9}}, {t: this.text_10, p: {x: -264.5, y: 224.9}}, {t: this.text_9, p: {x: -146.2, y: 152.4}}, {t: this.text_8, p: {x: -68.2, y: 152.4}}, {t: this.text_7, p: {x: -183.9, y: 225.2}}, {t: this.text_6, p: {x: -116.3, y: 225.2}}, {t: this.text_5, p: {x: -87.7, y: 225.2}}, {t: this.text_4, p: {x: -27.9, y: 225.2}}, {t: this.text_3, p: {x: 60.6, y: 47.4}}, {t: this.text_2, p: {x: 216.6, y: 99.4}}, {t: this.text_1, p: {x: 77.5, y: 148.8}}, {t: this.text, p: {x: 155.5, y: 148.8}}]}, 4).to({state: [{t: this.text_19, p: {x: -43.3, y: 47.4}}, {t: this.text_18, p: {x: -250.2, y: 97.8}}, {t: this.text_17, p: {x: -185.2, y: 100.4}}, {t: this.text_16, p: {x: -380.2, y: 144.3}}, {t: this.text_15, p: {x: -293.1, y: 144.3}}, {t: this.text_14, p: {x: -421.8, y: 221}}, {t: this.text_13, p: {x: -356.8, y: 224.9}}, {t: this.text_12, p: {x: -325.6, y: 224.9}}, {t: this.text_11, p: {x: -264.5, y: 224.9}}, {t: this.text_10, p: {x: -146.2, y: 152.4}}, {t: this.text_9, p: {x: -68.2, y: 152.4}}, {t: this.text_8, p: {x: -183.9, y: 225.2}}, {t: this.text_7, p: {x: -116.3, y: 225.2}}, {t: this.text_6, p: {x: -87.7, y: 225.2}}, {t: this.text_5, p: {x: -27.9, y: 225.2}}, {t: this.text_4, p: {x: 60.6, y: 47.4}}, {t: this.text_3, p: {x: 216.6, y: 99.4}}, {t: this.text_2, p: {x: 77.5, y: 148.8}}, {t: this.text_1, p: {x: 155.5, y: 148.8}}, {t: this.text, p: {x: 38.5, y: 226.8}}]}, 4).to({state: [{t: this.text_20, p: {x: -43.3, y: 47.4}}, {t: this.text_19, p: {x: -250.2, y: 97.8}}, {t: this.text_18, p: {x: -185.2, y: 100.4}}, {t: this.text_17, p: {x: -380.2, y: 144.3}}, {t: this.text_16, p: {x: -293.1, y: 144.3}}, {t: this.text_15, p: {x: -421.8, y: 221}}, {t: this.text_14, p: {x: -356.8, y: 224.9}}, {t: this.text_13, p: {x: -325.6, y: 224.9}}, {t: this.text_12, p: {x: -264.5, y: 224.9}}, {t: this.text_11, p: {x: -146.2, y: 152.4}}, {t: this.text_10, p: {x: -68.2, y: 152.4}}, {t: this.text_9, p: {x: -183.9, y: 225.2}}, {t: this.text_8, p: {x: -116.3, y: 225.2}}, {t: this.text_7, p: {x: -87.7, y: 225.2}}, {t: this.text_6, p: {x: -27.9, y: 225.2}}, {t: this.text_5, p: {x: 60.6, y: 47.4}}, {t: this.text_4, p: {x: 216.6, y: 99.4}}, {t: this.text_3, p: {x: 77.5, y: 148.8}}, {t: this.text_2, p: {x: 155.5, y: 148.8}}, {t: this.text_1, p: {x: 38.5, y: 226.8}}, {t: this.text, p: {x: 98.3, y: 226.8}}]}, 4).to({state: [{t: this.text_21, p: {x: -43.3, y: 47.4}}, {t: this.text_20, p: {x: -250.2, y: 97.8}}, {t: this.text_19, p: {x: -185.2, y: 100.4}}, {t: this.text_18, p: {x: -380.2, y: 144.3}}, {t: this.text_17, p: {x: -293.1, y: 144.3}}, {t: this.text_16, p: {x: -421.8, y: 221}}, {t: this.text_15, p: {x: -356.8, y: 224.9}}, {t: this.text_14, p: {x: -325.6, y: 224.9}}, {t: this.text_13, p: {x: -264.5, y: 224.9}}, {t: this.text_12, p: {x: -146.2, y: 152.4}}, {t: this.text_11, p: {x: -68.2, y: 152.4}}, {t: this.text_10, p: {x: -183.9, y: 225.2}}, {t: this.text_9, p: {x: -116.3, y: 225.2}}, {t: this.text_8, p: {x: -87.7, y: 225.2}}, {t: this.text_7, p: {x: -27.9, y: 225.2}}, {t: this.text_6, p: {x: 60.6, y: 47.4}}, {t: this.text_5, p: {x: 216.6, y: 99.4}}, {t: this.text_4, p: {x: 77.5, y: 148.8}}, {t: this.text_3, p: {x: 155.5, y: 148.8}}, {t: this.text_2, p: {x: 38.5, y: 226.8}}, {t: this.text_1, p: {x: 98.3, y: 226.8}}, {t: this.text, p: {x: 133.4, y: 226.8}}]}, 4).to({state: [{t: this.text_22, p: {x: -43.3, y: 47.4}}, {t: this.text_21, p: {x: -250.2, y: 97.8}}, {t: this.text_20, p: {x: -185.2, y: 100.4}}, {t: this.text_19, p: {x: -380.2, y: 144.3}}, {t: this.text_18, p: {x: -293.1, y: 144.3}}, {t: this.text_17, p: {x: -421.8, y: 221}}, {t: this.text_16, p: {x: -356.8, y: 224.9}}, {t: this.text_15, p: {x: -325.6, y: 224.9}}, {t: this.text_14, p: {x: -264.5, y: 224.9}}, {t: this.text_13, p: {x: -146.2, y: 152.4}}, {t: this.text_12, p: {x: -68.2, y: 152.4}}, {t: this.text_11, p: {x: -183.9, y: 225.2}}, {t: this.text_10, p: {x: -116.3, y: 225.2}}, {t: this.text_9, p: {x: -87.7, y: 225.2}}, {t: this.text_8, p: {x: -27.9, y: 225.2}}, {t: this.text_7, p: {x: 60.6, y: 47.4}}, {t: this.text_6, p: {x: 216.6, y: 99.4}}, {t: this.text_5, p: {x: 77.5, y: 148.8}}, {t: this.text_4, p: {x: 155.5, y: 148.8}}, {t: this.text_3, p: {x: 38.5, y: 226.8}}, {t: this.text_2, p: {x: 98.3, y: 226.8}}, {t: this.text_1, p: {x: 133.4, y: 226.8}}, {t: this.text, p: {x: 193.2, y: 226.8}}]}, 4).to({state: [{t: this.text_23, p: {x: -43.3, y: 47.4}}, {t: this.text_22, p: {x: -250.2, y: 97.8}}, {t: this.text_21, p: {x: -185.2, y: 100.4}}, {t: this.text_20, p: {x: -380.2, y: 144.3}}, {t: this.text_19, p: {x: -293.1, y: 144.3}}, {t: this.text_18, p: {x: -421.8, y: 221}}, {t: this.text_17, p: {x: -356.8, y: 224.9}}, {t: this.text_16, p: {x: -325.6, y: 224.9}}, {t: this.text_15, p: {x: -264.5, y: 224.9}}, {t: this.text_14, p: {x: -146.2, y: 152.4}}, {t: this.text_13, p: {x: -68.2, y: 152.4}}, {t: this.text_12, p: {x: -183.9, y: 225.2}}, {t: this.text_11, p: {x: -116.3, y: 225.2}}, {t: this.text_10, p: {x: -87.7, y: 225.2}}, {t: this.text_9, p: {x: -27.9, y: 225.2}}, {t: this.text_8, p: {x: 60.6, y: 47.4}}, {t: this.text_7, p: {x: 216.6, y: 99.4}}, {t: this.text_6, p: {x: 77.5, y: 148.8}}, {t: this.text_5, p: {x: 155.5, y: 148.8}}, {t: this.text_4, p: {x: 38.5, y: 226.8}}, {t: this.text_3, p: {x: 98.3, y: 226.8}}, {t: this.text_2, p: {x: 133.4, y: 226.8}}, {t: this.text_1, p: {x: 193.2, y: 226.8}}, {t: this.text, p: {x: 271.2, y: 99.4}}]}, 4).to({state: [{t: this.text_24, p: {x: -43.3, y: 47.4}}, {t: this.text_23, p: {x: -250.2, y: 97.8}}, {t: this.text_22, p: {x: -185.2, y: 100.4}}, {t: this.text_21, p: {x: -380.2, y: 144.3}}, {t: this.text_20, p: {x: -293.1, y: 144.3}}, {t: this.text_19, p: {x: -421.8, y: 221}}, {t: this.text_18, p: {x: -356.8, y: 224.9}}, {t: this.text_17, p: {x: -325.6, y: 224.9}}, {t: this.text_16, p: {x: -264.5, y: 224.9}}, {t: this.text_15, p: {x: -146.2, y: 152.4}}, {t: this.text_14, p: {x: -68.2, y: 152.4}}, {t: this.text_13, p: {x: -183.9, y: 225.2}}, {t: this.text_12, p: {x: -116.3, y: 225.2}}, {t: this.text_11, p: {x: -87.7, y: 225.2}}, {t: this.text_10, p: {x: -27.9, y: 225.2}}, {t: this.text_9, p: {x: 60.6, y: 47.4}}, {t: this.text_8, p: {x: 216.6, y: 99.4}}, {t: this.text_7, p: {x: 77.5, y: 148.8}}, {t: this.text_6, p: {x: 155.5, y: 148.8}}, {t: this.text_5, p: {x: 38.5, y: 226.8}}, {t: this.text_4, p: {x: 98.3, y: 226.8}}, {t: this.text_3, p: {x: 133.4, y: 226.8}}, {t: this.text_2, p: {x: 193.2, y: 226.8}}, {t: this.text_1, p: {x: 271.2, y: 99.4}}, {t: this.text, p: {x: 324.5, y: 148.8}}]}, 4).to({state: [{t: this.text_25, p: {x: -43.3, y: 47.4}}, {t: this.text_24, p: {x: -250.2, y: 97.8}}, {t: this.text_23, p: {x: -185.2, y: 100.4}}, {t: this.text_22, p: {x: -380.2, y: 144.3}}, {t: this.text_21, p: {x: -293.1, y: 144.3}}, {t: this.text_20, p: {x: -421.8, y: 221}}, {t: this.text_19, p: {x: -356.8, y: 224.9}}, {t: this.text_18, p: {x: -325.6, y: 224.9}}, {t: this.text_17, p: {x: -264.5, y: 224.9}}, {t: this.text_16, p: {x: -146.2, y: 152.4}}, {t: this.text_15, p: {x: -68.2, y: 152.4}}, {t: this.text_14, p: {x: -183.9, y: 225.2}}, {t: this.text_13, p: {x: -116.3, y: 225.2}}, {t: this.text_12, p: {x: -87.7, y: 225.2}}, {t: this.text_11, p: {x: -27.9, y: 225.2}}, {t: this.text_10, p: {x: 60.6, y: 47.4}}, {t: this.text_9, p: {x: 216.6, y: 99.4}}, {t: this.text_8, p: {x: 77.5, y: 148.8}}, {t: this.text_7, p: {x: 155.5, y: 148.8}}, {t: this.text_6, p: {x: 38.5, y: 226.8}}, {t: this.text_5, p: {x: 98.3, y: 226.8}}, {t: this.text_4, p: {x: 133.4, y: 226.8}}, {t: this.text_3, p: {x: 193.2, y: 226.8}}, {t: this.text_2, p: {x: 271.2, y: 99.4}}, {t: this.text_1, p: {x: 324.5, y: 148.8}}, {t: this.text, p: {x: 389.5, y: 148.8}}]}, 4).to({state: [{t: this.text_26, p: {x: -43.3, y: 47.4}}, {t: this.text_25, p: {x: -250.2, y: 97.8}}, {t: this.text_24, p: {x: -185.2, y: 100.4}}, {t: this.text_23, p: {x: -380.2, y: 144.3}}, {t: this.text_22, p: {x: -293.1, y: 144.3}}, {t: this.text_21, p: {x: -421.8, y: 221}}, {t: this.text_20, p: {x: -356.8, y: 224.9}}, {t: this.text_19, p: {x: -325.6, y: 224.9}}, {t: this.text_18, p: {x: -264.5, y: 224.9}}, {t: this.text_17, p: {x: -146.2, y: 152.4}}, {t: this.text_16, p: {x: -68.2, y: 152.4}}, {t: this.text_15, p: {x: -183.9, y: 225.2}}, {t: this.text_14, p: {x: -116.3, y: 225.2}}, {t: this.text_13, p: {x: -87.7, y: 225.2}}, {t: this.text_12, p: {x: -27.9, y: 225.2}}, {t: this.text_11, p: {x: 60.6, y: 47.4}}, {t: this.text_10, p: {x: 216.6, y: 99.4}}, {t: this.text_9, p: {x: 77.5, y: 148.8}}, {t: this.text_8, p: {x: 155.5, y: 148.8}}, {t: this.text_7, p: {x: 38.5, y: 226.8}}, {t: this.text_6, p: {x: 98.3, y: 226.8}}, {t: this.text_5, p: {x: 133.4, y: 226.8}}, {t: this.text_4, p: {x: 193.2, y: 226.8}}, {t: this.text_3, p: {x: 271.2, y: 99.4}}, {t: this.text_2, p: {x: 324.5, y: 148.8}}, {t: this.text_1, p: {x: 389.5, y: 148.8}}, {t: this.text, p: {x: 284.2, y: 226.8}}]}, 4).to({state: [{t: this.text_27, p: {x: -43.3, y: 47.4}}, {t: this.text_26, p: {x: -250.2, y: 97.8}}, {t: this.text_25, p: {x: -185.2, y: 100.4}}, {t: this.text_24, p: {x: -380.2, y: 144.3}}, {t: this.text_23, p: {x: -293.1, y: 144.3}}, {t: this.text_22, p: {x: -421.8, y: 221}}, {t: this.text_21, p: {x: -356.8, y: 224.9}}, {t: this.text_20, p: {x: -325.6, y: 224.9}}, {t: this.text_19, p: {x: -264.5, y: 224.9}}, {t: this.text_18, p: {x: -146.2, y: 152.4}}, {t: this.text_17, p: {x: -68.2, y: 152.4}}, {t: this.text_16, p: {x: -183.9, y: 225.2}}, {t: this.text_15, p: {x: -116.3, y: 225.2}}, {t: this.text_14, p: {x: -87.7, y: 225.2}}, {t: this.text_13, p: {x: -27.9, y: 225.2}}, {t: this.text_12, p: {x: 60.6, y: 47.4}}, {t: this.text_11, p: {x: 216.6, y: 99.4}}, {t: this.text_10, p: {x: 77.5, y: 148.8}}, {t: this.text_9, p: {x: 155.5, y: 148.8}}, {t: this.text_8, p: {x: 38.5, y: 226.8}}, {t: this.text_7, p: {x: 98.3, y: 226.8}}, {t: this.text_6, p: {x: 133.4, y: 226.8}}, {t: this.text_5, p: {x: 193.2, y: 226.8}}, {t: this.text_4, p: {x: 271.2, y: 99.4}}, {t: this.text_3, p: {x: 324.5, y: 148.8}}, {t: this.text_2, p: {x: 389.5, y: 148.8}}, {t: this.text_1, p: {x: 284.2, y: 226.8}}, {t: this.text, p: {x: 345.3, y: 226.8}}]}, 4).to({state: [{t: this.text_28, p: {x: -43.3, y: 47.4}}, {t: this.text_27, p: {x: -250.2, y: 97.8}}, {t: this.text_26, p: {x: -185.2, y: 100.4}}, {t: this.text_25, p: {x: -380.2, y: 144.3}}, {t: this.text_24, p: {x: -293.1, y: 144.3}}, {t: this.text_23, p: {x: -421.8, y: 221}}, {t: this.text_22, p: {x: -356.8, y: 224.9}}, {t: this.text_21, p: {x: -325.6, y: 224.9}}, {t: this.text_20, p: {x: -264.5, y: 224.9}}, {t: this.text_19, p: {x: -146.2, y: 152.4}}, {t: this.text_18, p: {x: -68.2, y: 152.4}}, {t: this.text_17, p: {x: -183.9, y: 225.2}}, {t: this.text_16, p: {x: -116.3, y: 225.2}}, {t: this.text_15, p: {x: -87.7, y: 225.2}}, {t: this.text_14, p: {x: -27.9, y: 225.2}}, {t: this.text_13, p: {x: 60.6, y: 47.4}}, {t: this.text_12, p: {x: 216.6, y: 99.4}}, {t: this.text_11, p: {x: 77.5, y: 148.8}}, {t: this.text_10, p: {x: 155.5, y: 148.8}}, {t: this.text_9, p: {x: 38.5, y: 226.8}}, {t: this.text_8, p: {x: 98.3, y: 226.8}}, {t: this.text_7, p: {x: 133.4, y: 226.8}}, {t: this.text_6, p: {x: 193.2, y: 226.8}}, {t: this.text_5, p: {x: 271.2, y: 99.4}}, {t: this.text_4, p: {x: 324.5, y: 148.8}}, {t: this.text_3, p: {x: 389.5, y: 148.8}}, {t: this.text_2, p: {x: 284.2, y: 226.8}}, {t: this.text_1, p: {x: 345.3, y: 226.8}}, {t: this.text, p: {x: 372.6, y: 226.8}}]}, 4).to({state: [{t: this.text_29}, {t: this.text_28, p: {x: -250.2, y: 97.8}}, {t: this.text_27, p: {x: -185.2, y: 100.4}}, {t: this.text_26, p: {x: -380.2, y: 144.3}}, {t: this.text_25, p: {x: -293.1, y: 144.3}}, {t: this.text_24, p: {x: -421.8, y: 221}}, {t: this.text_23, p: {x: -356.8, y: 224.9}}, {t: this.text_22, p: {x: -325.6, y: 224.9}}, {t: this.text_21, p: {x: -264.5, y: 224.9}}, {t: this.text_20, p: {x: -146.2, y: 152.4}}, {t: this.text_19, p: {x: -68.2, y: 152.4}}, {t: this.text_18, p: {x: -183.9, y: 225.2}}, {t: this.text_17, p: {x: -116.3, y: 225.2}}, {t: this.text_16, p: {x: -87.7, y: 225.2}}, {t: this.text_15, p: {x: -27.9, y: 225.2}}, {t: this.text_14, p: {x: 60.6, y: 47.4}}, {t: this.text_13, p: {x: 216.6, y: 99.4}}, {t: this.text_12, p: {x: 77.5, y: 148.8}}, {t: this.text_11, p: {x: 155.5, y: 148.8}}, {t: this.text_10, p: {x: 38.5, y: 226.8}}, {t: this.text_9, p: {x: 98.3, y: 226.8}}, {t: this.text_8, p: {x: 133.4, y: 226.8}}, {t: this.text_7, p: {x: 193.2, y: 226.8}}, {t: this.text_6, p: {x: 271.2, y: 99.4}}, {t: this.text_5, p: {x: 324.5, y: 148.8}}, {t: this.text_4, p: {x: 389.5, y: 148.8}}, {t: this.text_3, p: {x: 284.2, y: 226.8}}, {t: this.text_2, p: {x: 345.3, y: 226.8}}, {t: this.text_1, p: {x: 372.6, y: 226.8}}, {t: this.text, p: {x: 440.2, y: 226.8}}]}, 4).wait(17));

        // Capa 12
        this.shape_22 = new cjs.Shape();
        this.shape_22.graphics.f().s("#000000").ss(1, 1, 1).p("AM0iPI5nEg");
        this.shape_22.setTransform(-82.1, 49.1);

        this.shape_23 = new cjs.Shape();
        this.shape_23.graphics.f().s("#000000").ss(1, 1, 1).p("AtBA8IpiGGAWknAI5mEi");
        this.shape_23.setTransform(-144.5, 79.6);

        this.shape_24 = new cjs.Shape();
        this.shape_24.graphics.f().s("#000000").ss(1, 1, 1).p("AtBA8IpiGGAlOAoIJ0FoAWknAI5mEi");
        this.shape_24.setTransform(-144.5, 79.6);

        this.shape_25 = new cjs.Shape();
        this.shape_25.graphics.f().s("#000000").ss(1, 1, 1).p("Antj0IpiGFAAEkIIJ2FnAb4ryI5oEjA5MHtIirEG");
        this.shape_25.setTransform(-178.5, 110.1);

        this.shape_26 = new cjs.Shape();
        this.shape_26.graphics.f().s("#000000").ss(1, 1, 1).p("Az5HRIB4EYAntj0IpiGFAAEkIIJ2FnAb4ryI5oEjA5MHtIirEG");
        this.shape_26.setTransform(-178.5, 110.1);

        this.shape_27 = new cjs.Shape();
        this.shape_27.graphics.f().s("#000000").ss(1, 1, 1).p("AwxB4IB4EYAklpNIpiGGADMphIJ2FoAfAxLI5oEiA2ECUIirEGA9RNmIhuDm");
        this.shape_27.setTransform(-198.5, 144.6);

        this.shape_28 = new cjs.Shape();
        this.shape_28.graphics.f().s("#000000").ss(1, 1, 1).p("AwxB4IB4EYAklpNIpiGGADMphIJ2FoAfAxLI5oEiA2ECUIirEGA5DNcIBQDmA9RNmIhuDm");
        this.shape_28.setTransform(-198.5, 144.6);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape_22}]}, 20).to({state: [{t: this.shape_23}]}, 13).to({state: [{t: this.shape_24}]}, 13).to({state: [{t: this.shape_25}]}, 12).to({state: [{t: this.shape_26}]}, 11).to({state: [{t: this.shape_27}]}, 11).to({state: [{t: this.shape_28}]}, 9).wait(116));

        // Capa 38
        this.tirada5 = new cjs.Text("5ª tirada", "16px Verdana");
        this.tirada5.lineHeight = 16;
        this.tirada5.lineWidth = 97;
        this.tirada5.setTransform(-525.4, 270);

        this.tirada4 = new cjs.Text("4ª tirada", "16px Verdana");
        this.tirada4.lineHeight = 16;
        this.tirada4.lineWidth = 92;
        this.tirada4.setTransform(-525.4, 192);

        this.tirada3 = new cjs.Text("3ª tirada", "16px Verdana");
        this.tirada3.lineHeight = 16;
        this.tirada3.lineWidth = 92;
        this.tirada3.setTransform(-525.4, 120.5);

        this.tirada2 = new cjs.Text("2ª tirada", "16px Verdana");
        this.tirada2.lineHeight = 16;
        this.tirada2.lineWidth = 94;
        this.tirada2.setTransform(-525.4, 51.6);

        this.tirada1 = new cjs.Text("1ª tirada", "16px Verdana");
        this.tirada1.lineHeight = 16;
        this.tirada1.lineWidth = 92;
        this.tirada1.setTransform(-525.4, 3.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.tirada1}, {t: this.tirada2}, {t: this.tirada3}, {t: this.tirada4}, {t: this.tirada5}]}).wait(205));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-525.4, 3.5, 100.6, 290);


    (lib.Diagrama_04MC = function () {
        this.initialize();

        // Capa 2
        this.instance = new lib.parpadeo4();
        this.instance.setTransform(540.5, 267.9, 1, 1, 0, 0, 0, 75.5, 11.7);

        this.hombre = new cjs.Text(txt['hombre'], "16px Verdana", "#009900");
        this.hombre.lineHeight = 16;
        this.hombre.lineWidth = 100;
        this.hombre.setTransform(343.9, 260.2);

        this.mujer = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer.lineHeight = 16;
        this.mujer.lineWidth = 100;
        this.mujer.setTransform(343.9, 200.2);

        this.hombre_1 = new cjs.Text(txt['hombre'], "16px Verdana", "#0066CC");
        this.hombre_1.lineHeight = 16;
        this.hombre_1.lineWidth = 100;
        this.hombre_1.setTransform(343.9, 158.2);

        this.mujer_1 = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer_1.lineHeight = 16;
        this.mujer_1.lineWidth = 100;
        this.mujer_1.setTransform(343.9, 98.2);

        this.hombre_2 = new cjs.Text(txt['hombre'], "16px Verdana", "#CC0000");
        this.hombre_2.lineHeight = 16;
        this.hombre_2.lineWidth = 100;
        this.hombre_2.setTransform(343.9, 62.2);

        this.mujer_2 = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer_2.lineHeight = 16;
        this.mujer_2.lineWidth = 100;
        this.mujer_2.setTransform(343.9, 2.2);

        this.instance_1 = new lib.parpadeo3();
        this.instance_1.setTransform(540.5, 168.9, 1, 1, 0, 0, 0, 75.5, 11.7);

        this.instance_2 = new lib.parpadeo2();
        this.instance_2.setTransform(529.5, 73.9, 1, 1, 0, 0, 0, 64.5, 11.7);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#CC0000").ss(2, 1, 1).p("AheAAIC9AAIgygyABfAAIgyAz");
        this.shape.setTransform(444.1, 74.8-incremento);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#CC0000").ss(2, 1, 1).p("AheAAIC9AAIgygyABfAAIgyAz");
        this.shape_1.setTransform(444.1, 74.8-incremento);

        this.text = new cjs.Text("0,4", "16px Verdana", "#009900");
        this.text.lineHeight = 16;
        this.text.lineWidth = 44;
        this.text.setTransform(260.1, 258.8);

        this.text_1 = new cjs.Text("0,6", "16px Verdana");
        this.text_1.lineHeight = 16;
        this.text_1.lineWidth = 44;
        this.text_1.setTransform(260.1, 200.6);

        this.text_2 = new cjs.Text("0,4", "16px Verdana", "#0066CC");
        this.text_2.lineHeight = 16;
        this.text_2.lineWidth = 44;
        this.text_2.setTransform(260.1, 158.6);

        this.text_3 = new cjs.Text("0,6", "16px Verdana");
        this.text_3.lineHeight = 16;
        this.text_3.lineWidth = 44;
        this.text_3.setTransform(260.1, 100.4);

        this.text_4 = new cjs.Text("0,4", "16px Verdana", "#CC0000");
        this.text_4.lineHeight = 16;
        this.text_4.lineWidth = 44;
        this.text_4.setTransform(260.1, 62);

        this.text_5 = new cjs.Text("0,6", "16px Verdana");
        this.text_5.lineHeight = 16;
        this.text_5.lineWidth = 44;
        this.text_5.setTransform(260.1, 3.8);

        this.facultad3 = new cjs.Text(txt['facultad3'], "18px Verdana", "#009900");
        this.facultad3.lineHeight = 18;
        this.facultad3.lineWidth = 107;
        this.facultad3.setTransform(120.7, 227.1);

        this.facultad2 = new cjs.Text(txt['facultad2'], "18px Verdana", "#0066CC");
        this.facultad2.lineHeight = 18;
        this.facultad2.lineWidth = 107;
        this.facultad2.setTransform(120.7, 124.5);

        this.facultad1 = new cjs.Text(txt['facultad1'], "18px Verdana", "#CC0000");
        this.facultad1.lineHeight = 18;
        this.facultad1.lineWidth = 107;
        this.facultad1.setTransform(120.7, 28.5);

        this.text_6 = new cjs.Text("0,25", "18px Verdana", "#0066CC");
        this.text_6.textAlign = "right";
        this.text_6.lineHeight = 18;
        this.text_6.lineWidth = 100;
        this.text_6.setTransform(91.6, 110.3);

        this.text_7 = new cjs.Text("0,25", "18px Verdana", "#009900");
        this.text_7.textAlign = "right";
        this.text_7.lineHeight = 18;
        this.text_7.lineWidth = 100;
        this.text_7.setTransform(49.6, 186.3);

        this.text_8 = new cjs.Text("0,5", "18px Verdana", "#CC0000");
        this.text_8.textAlign = "right";
        this.text_8.lineHeight = 18;
        this.text_8.lineWidth = 100;
        this.text_8.setTransform(53.8, 60.3);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#009900").ss(2, 1, 1).p("EAhdAIuIAyAzIgyA0AfRJhIC+AAEgiOgKUIPFPEAQAJEIvAkS");
        this.shape_2.setTransform(234.4, 206.8-incremento);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#0066CC").ss(2, 1, 1).p("EAhdABJIAyAzIgyA0AfRB8IC+AAEgiOgCkIPLAAAQABhIvAkQ");
        this.shape_3.setTransform(234.4, 157.3-incremento);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#CC0000").ss(2, 1, 1).p("ApwnnIvWPVAKIntIO/ES");
        this.shape_4.setTransform(176, 91.3-incremento);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#000000").ss(2, 1, 1).p("AnhRaIPDkRAnhCIIPDkPAHixZIvDER");
        this.shape_5.setTransform(289.1, 126-incremento);

        // Capa 1


        this.addChild(this.shape_5, this.shape_4, this.shape_3, this.shape_2, this.text_8, this.text_7, this.text_6, this.facultad1, this.facultad2, this.facultad3, this.text_5, this.text_4, this.text_3, this.text_2, this.text_1, this.text, this.shape_1, this.shape, this.instance_2, this.instance_1, this.mujer_2, this.hombre_2, this.mujer_1, this.hombre_1, this.mujer, this.hombre, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-50.3, 0, 666.4, 283.7);


    (lib.Diagrama_03MC = function () {
        this.initialize();

        // Capa 4
        this.hombre = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre.lineHeight = 16;
        this.hombre.lineWidth = 100;
        this.hombre.setTransform(343.9, 260.2);

        this.mujer = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer.lineHeight = 16;
        this.mujer.lineWidth = 100;
        this.mujer.setTransform(343.9, 200.2);

        this.hombre_1 = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre_1.lineHeight = 16;
        this.hombre_1.lineWidth = 100;
        this.hombre_1.setTransform(343.9, 158.2);

        this.mujer_1 = new cjs.Text(txt['mujer'], "16px Verdana");
        this.mujer_1.lineHeight = 16;
        this.mujer_1.lineWidth = 100;
        this.mujer_1.setTransform(343.9, 98.2);

        this.hombre_2 = new cjs.Text(txt['hombre'], "16px Verdana");
        this.hombre_2.lineHeight = 16;
        this.hombre_2.lineWidth = 100;
        this.hombre_2.setTransform(343.9, 62.2);

        this.mujer_2 = new cjs.Text(txt['mujer'], "16px Verdana", "#CC0000");
        this.mujer_2.lineHeight = 16;
        this.mujer_2.lineWidth = 100;
        this.mujer_2.setTransform(343.9, 2.2);

        // Capa 2
        this.instance = new lib.parpadeo1();
        this.instance.setTransform(548.5, 13.9, 1, 1, 0, 0, 0, 64.5, 11.7);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#CC0000").ss(2, 1, 1).p("AheAAIC9AAIgygyABfAAIgyAz");
        this.shape.setTransform(434.1, 14.8-incremento);

        this.text = new cjs.Text("0,4", "16px Verdana");
        this.text.lineHeight = 16;
        this.text.lineWidth = 44;
        this.text.setTransform(260.1, 258.8);

        this.text_1 = new cjs.Text("0,6", "16px Verdana");
        this.text_1.lineHeight = 16;
        this.text_1.lineWidth = 44;
        this.text_1.setTransform(260.1, 200.6);

        this.text_2 = new cjs.Text("0,4", "16px Verdana");
        this.text_2.lineHeight = 16;
        this.text_2.lineWidth = 44;
        this.text_2.setTransform(260.1, 158.6);

        this.text_3 = new cjs.Text("0,6", "16px Verdana");
        this.text_3.lineHeight = 16;
        this.text_3.lineWidth = 44;
        this.text_3.setTransform(260.1, 100.4);

        this.text_4 = new cjs.Text("0,4", "16px Verdana");
        this.text_4.lineHeight = 16;
        this.text_4.lineWidth = 44;
        this.text_4.setTransform(260.1, 62);

        this.text_5 = new cjs.Text("0,6", "16px Verdana", "#CC0000");
        this.text_5.lineHeight = 16;
        this.text_5.lineWidth = 44;
        this.text_5.setTransform(260.1, 3.8);

        this.facultad3 = new cjs.Text(txt['facultad3'], "18px Verdana");
        this.facultad3.lineHeight = 18;
        this.facultad3.lineWidth = 107;
        this.facultad3.setTransform(120.7, 227.1);

        this.facultad2 = new cjs.Text(txt['facultad2'], "18px Verdana");
        this.facultad2.lineHeight = 18;
        this.facultad2.lineWidth = 107;
        this.facultad2.setTransform(120.7, 124.5);

        this.facultad1 = new cjs.Text(txt['facultad1'], "18px Verdana", "#CC0000");
        this.facultad1.lineHeight = 18;
        this.facultad1.lineWidth = 107;
        this.facultad1.setTransform(120.7, 28.5);

        this.text_6 = new cjs.Text("0,25", "18px Verdana");
        this.text_6.textAlign = "right";
        this.text_6.lineHeight = 18;
        this.text_6.lineWidth = 100;
        this.text_6.setTransform(91.6, 114.3);

        this.text_7 = new cjs.Text("0,25", "18px Verdana");
        this.text_7.textAlign = "right";
        this.text_7.lineHeight = 18;
        this.text_7.lineWidth = 100;
        this.text_7.setTransform(49.6, 186.3);

        this.text_8 = new cjs.Text("0,5", "18px Verdana", "#CC0000");
        this.text_8.textAlign = "right";
        this.text_8.lineHeight = 18;
        this.text_8.lineWidth = 100;
        this.text_8.setTransform(53.8, 60.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(2, 1, 1).p("A5Jh9IPLAAA5Jh9IPFPDAKFxZIO/ERAZECIIu/kPIPFkSAZERaIu/kRIPFkS");
        this.shape_1.setTransform(176.3, 153.3);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#CC0000").ss(2, 1, 1).p("ApzleIvWPVAZKp2IvFES");
        this.shape_2.setTransform(176.3, 77.6);

        // Capa 1


        this.addChild(this.shape_2, this.shape_1, this.text_8, this.text_7, this.text_6, this.facultad1, this.facultad2, this.facultad3, this.text_5, this.text_4, this.text_3, this.text_2, this.text_1, this.text, this.shape, this.instance, this.mujer_2, this.hombre_2, this.mujer_1, this.hombre_1, this.mujer, this.hombre);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-50.3, 0, 663.4, 283.7);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '400px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);

    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
    this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
    new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}