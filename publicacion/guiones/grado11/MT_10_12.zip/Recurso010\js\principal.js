(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titulo']);

        this.b1 = new lib.buttonFalse();
        this.b1.setTransform(485.2, 309, 0.589, 1.345, 0, 0, -0.1, 355.4, 150.5);
        new cjs.ButtonHelper(this.b1, 0, 1, 2, false, new lib.buttonFalse(), 3);

        this.instance_1 = new lib._1_shutterstock_57736897_OPT();
        this.instance_1.setTransform(280.3, 109.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.b1.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.instance_1, this.b1, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['text_01'], "20px");


        this.instance_1 = new lib._2_shutterstock_56850_OPT();
        this.instance_1.setTransform(280.3, 109.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.instance_1, this.home, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['text_02'], "20px");


        this.text = new cjs.Text(txt['text_02b'], "20px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 20;
        this.text.setTransform(466.2, 497.9);
  var html = createDiv(txt['text_02b'], "Verdana", "20px", '500px', '40px', "20px", "185px", "center");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(220, 498-608);
        this.instance_1 = new lib._3_shutterstock_61791661_OPT();
        this.instance_1.setTransform(237.5, 162.3, 0.799, 0.799);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1, this.home, this.siguiente, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['text_03'], "20px");


       var html = createDiv(txt['text_03b'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto1 = new lib.fadeText(html, 20);
        this.texto1.setTransform(100, -450);

        this.instance_1 = new lib._4_shutterstock_60573571_OPT();
        this.instance_1.setTransform(237.5, 192.3, 0.799, 0.799);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1,this.texto1, this.home, this.siguiente, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['text_04'], "20px");

        this.instance_1 = new lib.Animacion_02();
        this.instance_1.setTransform(483.1, 344.2, 1, 1, 0, 0, 0, 245.6, 181.9);

        var html = createDiv(txt['text_04b'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto1 = new lib.fadeText(html, 20);
        this.texto1.setTransform(100, -120);
        var html = createDiv(txt['text_04c'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");

        this.texto2 = new lib.fadeText(html, 40, 1);
        this.texto2.setTransform(100, -120);
        var html = createDiv(txt['text_04d'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto3 = new lib.fadeText(html, 60, 1);
        this.texto3.setTransform(100, -120);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1, this.home, this.siguiente, this.texto1, this.texto2, this.texto3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['text_05'], "20px");

        this.instance_1 = new lib.Animacion_03();
        this.instance_1.setTransform(483.1, 344.2, 1, 1, 0, 0, 0, 245.6, 181.9);

        var html = createDiv(txt['text_05b'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto1 = new lib.fadeText(html, 20);
        this.texto1.setTransform(100, -120);
        var html = createDiv(txt['text_05c'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");

        this.texto2 = new lib.fadeText(html, 40, 1);
        this.texto2.setTransform(100, -120);
        var html = createDiv(txt['text_05d'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto3 = new lib.fadeText(html, 60, 1);
        this.texto3.setTransform(100, -120);
        var html = createDiv(txt['text_05e'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto4 = new lib.fadeText(html, 80, 1);
        this.texto4.setTransform(100, -120);
        var html = createDiv(txt['text_05f'], "Verdana", "20px", '750px', '30px', "20px", "185px", "center");
        this.texto5 = new lib.fadeText(html, 100, 1);
        this.texto5.setTransform(100, -120);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1, this.home, this.siguiente, this.texto1, this.texto2, this.texto3, this.texto4, this.texto5);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['text_06'], "20px");

        this.instance_1 = new lib.Animacion_04();
        this.instance_1.setTransform(470, 314, 1, 1, 0, 0, 0, 246.7, 44.1);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1, this.home, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['text_07'], "20px");

        this.instance_1 = new lib.Animacion_05();
        this.instance_1.setTransform(468.5, 314, 1, 1, 0, 0, 0, 246.7, 44.1);

        this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.instance_1, this.home, this.informacion, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['text_08'], "20px");

        this.instance_1 = new lib.Animacion_06();
        this.instance_1.setTransform(370, 164, 1, 1, 0, 0, 0, 246.7, 44.1);



        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.titulo, this.instance_1, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['text_09'], "20px");
        texto(this, txt['text_09b'], 0);

        this.instance_1 = new lib._7_shutterstock_7279075_OPT();
        this.instance_1.setTransform(226.5, 267, 0.827, 0.827);

        this.practica = new lib.btn_practica(txt['textbtnsolucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.texto, this.instance_1, this.cerrar, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        
        texto(this, txt['text_10'], 0);
 var html = createDiv(txt['text_10'], "Verdana", "20px",  '810px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        
        this.texto.setTransform(90, -532);
        this.instance_1 = new lib._8_shutterstock_68852842_OPT();
        this.instance_1.setTransform(354.9,287.1,0.587,0.587);

      

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.anterior, this.texto, this.instance_1, this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '780px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '100px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -402);
        else
            escena.texto.setTransform(130 + ancho, -402);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      
    function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }



    (lib.buttonFalse = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("Eg3hAXiMAAAgvDMBvDAAAMAAAAvDg");
        this.shape.setTransform(355.5, 150.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#000000").ss(1, 1, 1).p("EA3iAXiMhvDAAAMAAAgvDMBvDAAAg");
        this.shape_1.setTransform(355.5, 150.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#000000").s().p("Eg3hAXiMAAAgvDMBvDAAAMAAAAvDg");
        this.shape_2.setTransform(355.5, 150.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_2}, {t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib._1_shutterstock_57736897_OPT = function () {
        this.initialize(img._1_shutterstock_57736897_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 400, 400);


    (lib._10_shutterstock_63242116_OPT = function () {
        this.initialize(img._10_shutterstock_63242116_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib._2_shutterstock_56850_OPT = function () {
        this.initialize(img._2_shutterstock_56850_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 560, 400);


    (lib._3_shutterstock_61791661_OPT = function () {
        this.initialize(img._3_shutterstock_61791661_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 596, 400);


    (lib._4_shutterstock_60573571_OPT = function () {
        this.initialize(img._4_shutterstock_60573571_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 615, 400);


    (lib._5_shutterstock_6435841_OPT = function () {
        this.initialize(img._5_shutterstock_6435841_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib._6_shutterstock_75074116_OPT = function () {
        this.initialize(img._6_shutterstock_75074116_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 533, 400);


    (lib._7_shutterstock_7279075_OPT = function () {
        this.initialize(img._7_shutterstock_7279075_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib._8_shutterstock_68852842_OPT = function () {
        this.initialize(img._8_shutterstock_68852842_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 387, 400);


    (lib._9_shutterstock_7279075copia_OPT = function () {
        this.initialize(img._9_shutterstock_7279075copia_OPT);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib.pautas950x608nuevosarreglos = function () {
        this.initialize(img.pautas950x608nuevosarreglos);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);


    (lib.text_01 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text(txt['text_08b'], "18px Verdana", "#CC0000");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 426;
        this.text.setTransform(-223.9, 33);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-436.9, 33, 430, 25.9);


    (lib.numeros_02 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text(txt['text_08c'], "18px Verdana", "#CC0000");
        this.text.lineHeight = 18;

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 351.4, 25.9);


    (lib.numeros_01 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text(txt['text_03b'], "italic 20px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 20;
        this.text.setTransform(177.6, -313.9);

        this.addChild(this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-17.3, -313.9, 394, 28.3);


    (lib.IMG_07 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text(txt['text_08d'], "italic 18px Verdana");
        this.text.lineHeight = 18;
        this.text.setTransform(0, 157.6);
  var html = createDiv(txt['text_08d'], "Verdana", "20px", '96px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, 147-608);
        this.instance = new lib._10_shutterstock_63242116_OPT();
        this.instance.setTransform(2, 0, 0.39, 0.39);

        this.addChild(this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 236, 183.5);


    (lib.IMG_05 = function () {
        this.initialize();

        // Capa 1
        this.text = new cjs.Text(txt['text_08e'], "italic 18px Verdana");
        this.text.lineHeight = 18;
        this.text.setTransform(8, 173.6);
  var html = createDiv(txt['text_08e'], "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(8, 163-608);
        this.instance = new lib._9_shutterstock_7279075copia_OPT();
        this.instance.setTransform(0, 0, 0.47, 0.47);

        this.addChild(this.instance, this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 676.4, 199.5);


    (lib.IMG_04 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._6_shutterstock_75074116_OPT();
        this.instance.setTransform(0, 0, 0.799, 0.799);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 425.7, 319.5);


    (lib.IMG_03 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._5_shutterstock_6435841_OPT();
        this.instance.setTransform(0, 0, 0.799, 0.799);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 479.2, 319.5);


    (lib.IMG_02 = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._4_shutterstock_60573571_OPT();
        this.instance.setTransform(0, 0, 0.799, 0.799);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 491.2, 319.5);


    (lib.IMG_01 = function () {
        this.initialize();

        // Capa 2 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        mask.graphics.p("EgiLAfSMAAAg+kMBEXAAAMAAAA+kg");
        mask.setTransform(218.8, 200.3);

        // Capa 1
        this.instance = new lib._2_shutterstock_56850_OPT();

        this.instance.mask = mask;

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 560, 400);


    (lib.Animacion_05 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 4 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_0 = new cjs.Graphics().p("AhdDwIAAnfIC8AAIAAHfg");
        var mask_graphics_9 = new cjs.Graphics().p("AhdDwIAAnfIC8AAIAAHfg");
        var mask_graphics_10 = new cjs.Graphics().p("AiBDwIAAnfIEDAAIAAHfg");
        var mask_graphics_11 = new cjs.Graphics().p("AikDwIAAnfIFJAAIAAHfg");
        var mask_graphics_12 = new cjs.Graphics().p("AjHDwIAAnfIGPAAIAAHfg");
        var mask_graphics_13 = new cjs.Graphics().p("AjrDwIAAnfIHXAAIAAHfg");
        var mask_graphics_14 = new cjs.Graphics().p("AkODwIAAnfIIdAAIAAHfg");
        var mask_graphics_15 = new cjs.Graphics().p("AkxDwIAAnfIJjAAIAAHfg");
        var mask_graphics_16 = new cjs.Graphics().p("AlVDwIAAnfIKrAAIAAHfg");
        var mask_graphics_17 = new cjs.Graphics().p("Al4DwIAAnfILxAAIAAHfg");
        var mask_graphics_18 = new cjs.Graphics().p("AmbDwIAAnfIM3AAIAAHfg");
        var mask_graphics_19 = new cjs.Graphics().p("Am+DwIAAnfIN9AAIAAHfg");
        var mask_graphics_20 = new cjs.Graphics().p("AniDwIAAnfIPFAAIAAHfg");
        var mask_graphics_21 = new cjs.Graphics().p("AoFDwIAAnfIQLAAIAAHfg");
        var mask_graphics_22 = new cjs.Graphics().p("AooDwIAAnfIRRAAIAAHfg");
        var mask_graphics_23 = new cjs.Graphics().p("ApMDwIAAnfISZAAIAAHfg");
        var mask_graphics_24 = new cjs.Graphics().p("ApvDwIAAnfITfAAIAAHfg");
        var mask_graphics_25 = new cjs.Graphics().p("AqSDwIAAnfIUlAAIAAHfg");
        var mask_graphics_26 = new cjs.Graphics().p("AnUDwIAAnfIVsAAIAAHfg");
        var mask_graphics_42 = new cjs.Graphics().p("AnUDwIAAnfIVsAAIAAHfg");
        var mask_graphics_43 = new cjs.Graphics().p("ArcDwIAAnfIW5AAIAAHfg");
        var mask_graphics_44 = new cjs.Graphics().p("AsDDwIAAnfIYHAAIAAHfg");
        var mask_graphics_45 = new cjs.Graphics().p("AspDwIAAnfIZTAAIAAHfg");
        var mask_graphics_46 = new cjs.Graphics().p("AtQDwIAAnfIahAAIAAHfg");
        var mask_graphics_47 = new cjs.Graphics().p("At3DwIAAnfIbvAAIAAHfg");
        var mask_graphics_48 = new cjs.Graphics().p("AudDwIAAnfIc7AAIAAHfg");
        var mask_graphics_49 = new cjs.Graphics().p("AvEDwIAAnfIeJAAIAAHfg");
        var mask_graphics_50 = new cjs.Graphics().p("AvqDwIAAnfIfVAAIAAHfg");
        var mask_graphics_51 = new cjs.Graphics().p("AwRDwIAAnfMAgjAAAIAAHfg");
        var mask_graphics_52 = new cjs.Graphics().p("Aw4DwIAAnfMAhxAAAIAAHfg");
        var mask_graphics_53 = new cjs.Graphics().p("AxeDwIAAnfMAi9AAAIAAHfg");
        var mask_graphics_54 = new cjs.Graphics().p("AyFDwIAAnfMAkLAAAIAAHfg");
        var mask_graphics_55 = new cjs.Graphics().p("AyrDwIAAnfMAlXAAAIAAHfg");
        var mask_graphics_56 = new cjs.Graphics().p("AvvDwIAAnfMAmlAAAIAAHfg");
        var mask_graphics_72 = new cjs.Graphics().p("AvvDwIAAnfMAmlAAAIAAHfg");
        var mask_graphics_73 = new cjs.Graphics().p("A0dDwIAAnfMAo7AAAIAAHfg");
        var mask_graphics_74 = new cjs.Graphics().p("A1nDwIAAnfMArPAAAIAAHfg");
        var mask_graphics_75 = new cjs.Graphics().p("A2yDwIAAnfMAtlAAAIAAHfg");
        var mask_graphics_76 = new cjs.Graphics().p("A38DwIAAnfMAv5AAAIAAHfg");
        var mask_graphics_77 = new cjs.Graphics().p("A5HDwIAAnfMAyPAAAIAAHfg");
        var mask_graphics_78 = new cjs.Graphics().p("A6RDwIAAnfMA0jAAAIAAHfg");
        var mask_graphics_79 = new cjs.Graphics().p("A7cDwIAAnfMA25AAAIAAHfg");
        var mask_graphics_80 = new cjs.Graphics().p("A8nDwIAAnfMA5PAAAIAAHfg");
        var mask_graphics_81 = new cjs.Graphics().p("A9xDwIAAnfMA7jAAAIAAHfg");
        var mask_graphics_82 = new cjs.Graphics().p("A+8DwIAAnfMA95AAAIAAHfg");
        var mask_graphics_83 = new cjs.Graphics().p("EggGADwIAAnfMBANAAAIAAHfg");
        var mask_graphics_84 = new cjs.Graphics().p("EghRADwIAAnfMBCjAAAIAAHfg");
        var mask_graphics_85 = new cjs.Graphics().p("EgibADwIAAnfMBE3AAAIAAHfg");
        var mask_graphics_86 = new cjs.Graphics().p("EgjmADwIAAnfMBHNAAAIAAHfg");
        var mask_graphics_87 = new cjs.Graphics().p("EghMADwIAAnfMBJhAAAIAAHfg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: mask_graphics_0, x: 54.7, y: 12.2}).wait(9).to({graphics: mask_graphics_9, x: 54.7, y: 12.2}).wait(1).to({graphics: mask_graphics_10, x: 58.2, y: 12.2}).wait(1).to({graphics: mask_graphics_11, x: 61.7, y: 12.2}).wait(1).to({graphics: mask_graphics_12, x: 65.2, y: 12.2}).wait(1).to({graphics: mask_graphics_13, x: 68.8, y: 12.2}).wait(1).to({graphics: mask_graphics_14, x: 72.3, y: 12.2}).wait(1).to({graphics: mask_graphics_15, x: 75.8, y: 12.2}).wait(1).to({graphics: mask_graphics_16, x: 79.4, y: 12.2}).wait(1).to({graphics: mask_graphics_17, x: 82.9, y: 12.2}).wait(1).to({graphics: mask_graphics_18, x: 86.4, y: 12.2}).wait(1).to({graphics: mask_graphics_19, x: 89.9, y: 12.2}).wait(1).to({graphics: mask_graphics_20, x: 93.5, y: 12.2}).wait(1).to({graphics: mask_graphics_21, x: 97, y: 12.2}).wait(1).to({graphics: mask_graphics_22, x: 100.5, y: 12.2}).wait(1).to({graphics: mask_graphics_23, x: 104.1, y: 12.2}).wait(1).to({graphics: mask_graphics_24, x: 107.6, y: 12.2}).wait(1).to({graphics: mask_graphics_25, x: 111.1, y: 12.2}).wait(1).to({graphics: mask_graphics_26, x: 92.1, y: 12.2}).wait(16).to({graphics: mask_graphics_42, x: 92.1, y: 12.2}).wait(1).to({graphics: mask_graphics_43, x: 118.5, y: 12.2}).wait(1).to({graphics: mask_graphics_44, x: 122.4, y: 12.2}).wait(1).to({graphics: mask_graphics_45, x: 126.3, y: 12.2}).wait(1).to({graphics: mask_graphics_46, x: 130.2, y: 12.2}).wait(1).to({graphics: mask_graphics_47, x: 134, y: 12.2}).wait(1).to({graphics: mask_graphics_48, x: 137.9, y: 12.2}).wait(1).to({graphics: mask_graphics_49, x: 141.8, y: 12.2}).wait(1).to({graphics: mask_graphics_50, x: 145.7, y: 12.2}).wait(1).to({graphics: mask_graphics_51, x: 149.5, y: 12.2}).wait(1).to({graphics: mask_graphics_52, x: 153.4, y: 12.2}).wait(1).to({graphics: mask_graphics_53, x: 157.3, y: 12.2}).wait(1).to({graphics: mask_graphics_54, x: 161.2, y: 12.2}).wait(1).to({graphics: mask_graphics_55, x: 165, y: 12.2}).wait(1).to({graphics: mask_graphics_56, x: 146.2, y: 12.2}).wait(16).to({graphics: mask_graphics_72, x: 146.2, y: 12.2}).wait(1).to({graphics: mask_graphics_73, x: 176.4, y: 12.2}).wait(1).to({graphics: mask_graphics_74, x: 183.8, y: 12.2}).wait(1).to({graphics: mask_graphics_75, x: 191.3, y: 12.2}).wait(1).to({graphics: mask_graphics_76, x: 198.8, y: 12.2}).wait(1).to({graphics: mask_graphics_77, x: 206.3, y: 12.2}).wait(1).to({graphics: mask_graphics_78, x: 213.7, y: 12.2}).wait(1).to({graphics: mask_graphics_79, x: 221.2, y: 12.2}).wait(1).to({graphics: mask_graphics_80, x: 228.7, y: 12.2}).wait(1).to({graphics: mask_graphics_81, x: 236.2, y: 12.2}).wait(1).to({graphics: mask_graphics_82, x: 243.6, y: 12.2}).wait(1).to({graphics: mask_graphics_83, x: 251.1, y: 12.2}).wait(1).to({graphics: mask_graphics_84, x: 258.6, y: 12.2}).wait(1).to({graphics: mask_graphics_85, x: 266.1, y: 12.2}).wait(1).to({graphics: mask_graphics_86, x: 273.5, y: 12.2}).wait(1).to({graphics: mask_graphics_87, x: 258.2, y: 12.2}).wait(21));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CC0000").s().p("AgggkIBBAkIhBAlg");
        this.shape.setTransform(277.8, 17.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#CC0000").ss(1, 1, 1).p("AmDAAIMGAA");
        this.shape_1.setTransform(236.1, 17.8);

        this.text = new cjs.Text(txt['text_07b'], "20px Verdana");
        this.text.lineHeight = 20;
        this.text.setTransform(298.8, 0 + incremento);

        this.text_1 = new cjs.Text(txt['text_07c'], "italic 20px Verdana");
        this.text_1.lineHeight = 20;
        this.text_1.setTransform(72.7, 0 + incremento);
 this.text_1b = new cjs.Text(txt['text_07c1'], " 20px Verdana");
        this.text_1b.lineHeight = 20;
        this.text_1b.setTransform(72.7, 0 + incremento);

        this.shape.mask = this.shape_1.mask = this.text.mask = this.text_1.mask= this.text_1b.mask  = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_1},{t: this.text_1b}, {t: this.text}, {t: this.shape_1}, {t: this.shape}]}).wait(108000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(72.7, 0, 430.1, 28.3);


    (lib.Animacion_04 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 4 (mask)
        var mask = new cjs.Shape();
        mask._off = true;
        var mask_graphics_0 = new cjs.Graphics().p("AAeDwIAAnfIC+AAIAAHfg");
        var mask_graphics_9 = new cjs.Graphics().p("AAeDwIAAnfIC+AAIAAHfg");
        var mask_graphics_10 = new cjs.Graphics().p("AiBDwIAAnfIEDAAIAAHfg");
        var mask_graphics_11 = new cjs.Graphics().p("AikDwIAAnfIFJAAIAAHfg");
        var mask_graphics_12 = new cjs.Graphics().p("AjHDwIAAnfIGPAAIAAHfg");
        var mask_graphics_13 = new cjs.Graphics().p("AjrDwIAAnfIHXAAIAAHfg");
        var mask_graphics_14 = new cjs.Graphics().p("AkODwIAAnfIIdAAIAAHfg");
        var mask_graphics_15 = new cjs.Graphics().p("AkxDwIAAnfIJjAAIAAHfg");
        var mask_graphics_16 = new cjs.Graphics().p("AlVDwIAAnfIKrAAIAAHfg");
        var mask_graphics_17 = new cjs.Graphics().p("Al4DwIAAnfILxAAIAAHfg");
        var mask_graphics_18 = new cjs.Graphics().p("AmbDwIAAnfIM3AAIAAHfg");
        var mask_graphics_19 = new cjs.Graphics().p("Am+DwIAAnfIN9AAIAAHfg");
        var mask_graphics_20 = new cjs.Graphics().p("AniDwIAAnfIPFAAIAAHfg");
        var mask_graphics_21 = new cjs.Graphics().p("AoFDwIAAnfIQLAAIAAHfg");
        var mask_graphics_22 = new cjs.Graphics().p("AooDwIAAnfIRRAAIAAHfg");
        var mask_graphics_23 = new cjs.Graphics().p("ApMDwIAAnfISZAAIAAHfg");
        var mask_graphics_24 = new cjs.Graphics().p("ApvDwIAAnfITfAAIAAHfg");
        var mask_graphics_25 = new cjs.Graphics().p("AqSDwIAAnfIUlAAIAAHfg");
        var mask_graphics_26 = new cjs.Graphics().p("AnUDwIAAnfIVsAAIAAHfg");
        var mask_graphics_42 = new cjs.Graphics().p("AnUDwIAAnfIVsAAIAAHfg");
        var mask_graphics_43 = new cjs.Graphics().p("ArcDwIAAnfIW5AAIAAHfg");
        var mask_graphics_44 = new cjs.Graphics().p("AsDDwIAAnfIYHAAIAAHfg");
        var mask_graphics_45 = new cjs.Graphics().p("AspDwIAAnfIZTAAIAAHfg");
        var mask_graphics_46 = new cjs.Graphics().p("AtQDwIAAnfIahAAIAAHfg");
        var mask_graphics_47 = new cjs.Graphics().p("At3DwIAAnfIbvAAIAAHfg");
        var mask_graphics_48 = new cjs.Graphics().p("AudDwIAAnfIc7AAIAAHfg");
        var mask_graphics_49 = new cjs.Graphics().p("AvEDwIAAnfIeJAAIAAHfg");
        var mask_graphics_50 = new cjs.Graphics().p("AvqDwIAAnfIfVAAIAAHfg");
        var mask_graphics_51 = new cjs.Graphics().p("AwRDwIAAnfMAgjAAAIAAHfg");
        var mask_graphics_52 = new cjs.Graphics().p("Aw4DwIAAnfMAhxAAAIAAHfg");
        var mask_graphics_53 = new cjs.Graphics().p("AxeDwIAAnfMAi9AAAIAAHfg");
        var mask_graphics_54 = new cjs.Graphics().p("AyFDwIAAnfMAkLAAAIAAHfg");
        var mask_graphics_55 = new cjs.Graphics().p("AyrDwIAAnfMAlXAAAIAAHfg");
        var mask_graphics_56 = new cjs.Graphics().p("AvvDwIAAnfMAmlAAAIAAHfg");
        var mask_graphics_72 = new cjs.Graphics().p("AvvDwIAAnfMAmlAAAIAAHfg");
        var mask_graphics_73 = new cjs.Graphics().p("A0TDwIAAnfMAonAAAIAAHfg");
        var mask_graphics_74 = new cjs.Graphics().p("A1UDwIAAnfMAqpAAAIAAHfg");
        var mask_graphics_75 = new cjs.Graphics().p("A2WDwIAAnfMAstAAAIAAHfg");
        var mask_graphics_76 = new cjs.Graphics().p("A3XDwIAAnfMAuvAAAIAAHfg");
        var mask_graphics_77 = new cjs.Graphics().p("A4YDwIAAnfMAwxAAAIAAHfg");
        var mask_graphics_78 = new cjs.Graphics().p("A5ZDwIAAnfMAyzAAAIAAHfg");
        var mask_graphics_79 = new cjs.Graphics().p("A6bDwIAAnfMA03AAAIAAHfg");
        var mask_graphics_80 = new cjs.Graphics().p("A7cDwIAAnfMA25AAAIAAHfg");
        var mask_graphics_81 = new cjs.Graphics().p("A8dDwIAAnfMA47AAAIAAHfg");
        var mask_graphics_82 = new cjs.Graphics().p("A9fDwIAAnfMA6/AAAIAAHfg");
        var mask_graphics_83 = new cjs.Graphics().p("A+gDwIAAnfMA9BAAAIAAHfg");
        var mask_graphics_84 = new cjs.Graphics().p("A/hDwIAAnfMA/DAAAIAAHfg");
        var mask_graphics_85 = new cjs.Graphics().p("EggiADwIAAnfMBBFAAAIAAHfg");
        var mask_graphics_86 = new cjs.Graphics().p("EghkADwIAAnfMBDJAAAIAAHfg");
        var mask_graphics_87 = new cjs.Graphics().p("A/BDwIAAnfMBFKAAAIAAHfg");

        this.timeline.addTween(cjs.Tween.get(mask).to({graphics: mask_graphics_0, x: 22.1, y: 12.2}).wait(9).to({graphics: mask_graphics_9, x: 22.1, y: 12.2}).wait(1).to({graphics: mask_graphics_10, x: 39.4, y: 12.2}).wait(1).to({graphics: mask_graphics_11, x: 44.1, y: 12.2}).wait(1).to({graphics: mask_graphics_12, x: 48.8, y: 12.2}).wait(1).to({graphics: mask_graphics_13, x: 53.5, y: 12.2}).wait(1).to({graphics: mask_graphics_14, x: 58.2, y: 12.2}).wait(1).to({graphics: mask_graphics_15, x: 62.9, y: 12.2}).wait(1).to({graphics: mask_graphics_16, x: 67.6, y: 12.2}).wait(1).to({graphics: mask_graphics_17, x: 72.3, y: 12.2}).wait(1).to({graphics: mask_graphics_18, x: 77, y: 12.2}).wait(1).to({graphics: mask_graphics_19, x: 81.7, y: 12.2}).wait(1).to({graphics: mask_graphics_20, x: 86.4, y: 12.2}).wait(1).to({graphics: mask_graphics_21, x: 91.1, y: 12.2}).wait(1).to({graphics: mask_graphics_22, x: 95.8, y: 12.2}).wait(1).to({graphics: mask_graphics_23, x: 100.5, y: 12.2}).wait(1).to({graphics: mask_graphics_24, x: 105.2, y: 12.2}).wait(1).to({graphics: mask_graphics_25, x: 109.9, y: 12.2}).wait(1).to({graphics: mask_graphics_26, x: 92.1, y: 12.2}).wait(16).to({graphics: mask_graphics_42, x: 92.1, y: 12.2}).wait(1).to({graphics: mask_graphics_43, x: 118.5, y: 12.2}).wait(1).to({graphics: mask_graphics_44, x: 122.4, y: 12.2}).wait(1).to({graphics: mask_graphics_45, x: 126.3, y: 12.2}).wait(1).to({graphics: mask_graphics_46, x: 130.2, y: 12.2}).wait(1).to({graphics: mask_graphics_47, x: 134, y: 12.2}).wait(1).to({graphics: mask_graphics_48, x: 137.9, y: 12.2}).wait(1).to({graphics: mask_graphics_49, x: 141.8, y: 12.2}).wait(1).to({graphics: mask_graphics_50, x: 145.7, y: 12.2}).wait(1).to({graphics: mask_graphics_51, x: 149.5, y: 12.2}).wait(1).to({graphics: mask_graphics_52, x: 153.4, y: 12.2}).wait(1).to({graphics: mask_graphics_53, x: 157.3, y: 12.2}).wait(1).to({graphics: mask_graphics_54, x: 161.2, y: 12.2}).wait(1).to({graphics: mask_graphics_55, x: 165, y: 12.2}).wait(1).to({graphics: mask_graphics_56, x: 146.2, y: 12.2}).wait(16).to({graphics: mask_graphics_72, x: 146.2, y: 12.2}).wait(1).to({graphics: mask_graphics_73, x: 175.4, y: 12.2}).wait(1).to({graphics: mask_graphics_74, x: 182, y: 12.2}).wait(1).to({graphics: mask_graphics_75, x: 188.5, y: 12.2}).wait(1).to({graphics: mask_graphics_76, x: 195.1, y: 12.2}).wait(1).to({graphics: mask_graphics_77, x: 201.6, y: 12.2}).wait(1).to({graphics: mask_graphics_78, x: 208.1, y: 12.2}).wait(1).to({graphics: mask_graphics_79, x: 214.7, y: 12.2}).wait(1).to({graphics: mask_graphics_80, x: 221.2, y: 12.2}).wait(1).to({graphics: mask_graphics_81, x: 227.7, y: 12.2}).wait(1).to({graphics: mask_graphics_82, x: 234.3, y: 12.2}).wait(1).to({graphics: mask_graphics_83, x: 240.8, y: 12.2}).wait(1).to({graphics: mask_graphics_84, x: 247.4, y: 12.2}).wait(1).to({graphics: mask_graphics_85, x: 253.9, y: 12.2}).wait(1).to({graphics: mask_graphics_86, x: 260.4, y: 12.2}).wait(1).to({graphics: mask_graphics_87, x: 244.2, y: 12.2}).wait(104));

        // Capa 3
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CC0000").s().p("AgggkIBBAkIhBAlg");
        this.shape.setTransform(277.8, 17.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#CC0000").ss(1, 1, 1).p("AmDAAIMGAA");
        this.shape_1.setTransform(236.1, 17.8);

        this.text = new cjs.Text(txt['text_06b'], "20px Verdana");
        this.text.lineHeight = 20;
        this.text.setTransform(298.8, 0 + incremento);

        this.text_1 = new cjs.Text(txt['text_06d'], "italic 20px Verdana");
        this.text_1.textAlign = "left";
        this.text_1.lineHeight = 20;
        this.text_1.setTransform(50, 0 + incremento);
   this.text_1b = new cjs.Text(txt['text_06d1'], "20px Verdana");
        this.text_1b.textAlign = "right";
        this.text_1b.lineHeight = 20;
        this.text_1b.setTransform(175.1, 0 + incremento);
 
        this.shape.mask = this.text_1b.mask=this.shape_1.mask = this.text.mask = this.text_1.mask = mask;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_1}, {t: this.text_1b}, {t: this.text}, {t: this.shape_1}, {t: this.shape}]}).wait(191));

        // Capa 2 (mask)
        var mask_1 = new cjs.Shape();
        mask_1._off = true;
        var mask_1_graphics_0 = new cjs.Graphics().p("AkbH0IAAouIEOAAIAAIug");
        var mask_1_graphics_107 = new cjs.Graphics().p("AkbH0IAAouIEOAAIAAIug");
        var mask_1_graphics_108 = new cjs.Graphics().p("AjCEYIAAouIGFAAIAAIug");
        var mask_1_graphics_109 = new cjs.Graphics().p("Aj/EYIAAouIH/AAIAAIug");
        var mask_1_graphics_110 = new cjs.Graphics().p("Ak7EYIAAouIJ3AAIAAIug");
        var mask_1_graphics_111 = new cjs.Graphics().p("Al4EYIAAouILxAAIAAIug");
        var mask_1_graphics_112 = new cjs.Graphics().p("Am1EYIAAouINrAAIAAIug");
        var mask_1_graphics_113 = new cjs.Graphics().p("AnxEYIAAouIPjAAIAAIug");
        var mask_1_graphics_114 = new cjs.Graphics().p("AouEYIAAouIRdAAIAAIug");
        var mask_1_graphics_115 = new cjs.Graphics().p("AprEYIAAouITXAAIAAIug");
        var mask_1_graphics_116 = new cjs.Graphics().p("AqnEYIAAouIVPAAIAAIug");
        var mask_1_graphics_117 = new cjs.Graphics().p("ArkEYIAAouIXJAAIAAIug");
        var mask_1_graphics_118 = new cjs.Graphics().p("AsgEYIAAouIZBAAIAAIug");
        var mask_1_graphics_119 = new cjs.Graphics().p("AtdEYIAAouIa7AAIAAIug");
        var mask_1_graphics_120 = new cjs.Graphics().p("AuaEYIAAouIc1AAIAAIug");
        var mask_1_graphics_121 = new cjs.Graphics().p("AvWEYIAAouIetAAIAAIug");
        var mask_1_graphics_122 = new cjs.Graphics().p("AwTEYIAAouMAgnAAAIAAIug");
        var mask_1_graphics_123 = new cjs.Graphics().p("AxQH0IAAouMAihAAAIAAIug");
        var mask_1_graphics_141 = new cjs.Graphics().p("AxQH0IAAouMAihAAAIAAIug");
        var mask_1_graphics_142 = new cjs.Graphics().p("Ax1EYIAAouMAjrAAAIAAIug");
        var mask_1_graphics_143 = new cjs.Graphics().p("AybEYIAAouMAk3AAAIAAIug");
        var mask_1_graphics_144 = new cjs.Graphics().p("AzBEYIAAouMAmDAAAIAAIug");
        var mask_1_graphics_145 = new cjs.Graphics().p("AznEYIAAouMAnPAAAIAAIug");
        var mask_1_graphics_146 = new cjs.Graphics().p("A0NEYIAAouMAobAAAIAAIug");
        var mask_1_graphics_147 = new cjs.Graphics().p("A0zEYIAAouMApnAAAIAAIug");
        var mask_1_graphics_148 = new cjs.Graphics().p("A1YEYIAAouMAqxAAAIAAIug");
        var mask_1_graphics_149 = new cjs.Graphics().p("A1+EYIAAouMAr9AAAIAAIug");
        var mask_1_graphics_150 = new cjs.Graphics().p("A2kEYIAAouMAtJAAAIAAIug");
        var mask_1_graphics_151 = new cjs.Graphics().p("A3KEYIAAouMAuVAAAIAAIug");
        var mask_1_graphics_152 = new cjs.Graphics().p("A3wEYIAAouMAvhAAAIAAIug");
        var mask_1_graphics_153 = new cjs.Graphics().p("A4WEYIAAouMAwtAAAIAAIug");
        var mask_1_graphics_154 = new cjs.Graphics().p("A48EYIAAouMAx5AAAIAAIug");
        var mask_1_graphics_155 = new cjs.Graphics().p("A5iH0IAAouMAzFAAAIAAIug");
        var mask_1_graphics_171 = new cjs.Graphics().p("A5iH0IAAouMAzFAAAIAAIug");
        var mask_1_graphics_172 = new cjs.Graphics().p("A6oEYIAAouMA1RAAAIAAIug");
        var mask_1_graphics_173 = new cjs.Graphics().p("A7vEYIAAouMA3fAAAIAAIug");
        var mask_1_graphics_174 = new cjs.Graphics().p("A82EYIAAouMA5tAAAIAAIug");
        var mask_1_graphics_175 = new cjs.Graphics().p("A98EYIAAouMA75AAAIAAIug");
        var mask_1_graphics_176 = new cjs.Graphics().p("A/DEYIAAouMA+HAAAIAAIug");
        var mask_1_graphics_177 = new cjs.Graphics().p("EggKAEYIAAouMBAVAAAIAAIug");
        var mask_1_graphics_178 = new cjs.Graphics().p("EghQAEYIAAouMBChAAAIAAIug");
        var mask_1_graphics_179 = new cjs.Graphics().p("EgiXAEYIAAouMBEvAAAIAAIug");
        var mask_1_graphics_180 = new cjs.Graphics().p("EgjeAEYIAAouMBG9AAAIAAIug");
        var mask_1_graphics_181 = new cjs.Graphics().p("EgkkAEYIAAouMBJJAAAIAAIug");
        var mask_1_graphics_182 = new cjs.Graphics().p("EglrAEYIAAouMBLXAAAIAAIug");
        var mask_1_graphics_183 = new cjs.Graphics().p("EgmyAEYIAAouMBNlAAAIAAIug");
        var mask_1_graphics_184 = new cjs.Graphics().p("Egn4AEYIAAouMBPxAAAIAAIug");
        var mask_1_graphics_185 = new cjs.Graphics().p("Ego/AEYIAAouMBR/AAAIAAIug");
        var mask_1_graphics_186 = new cjs.Graphics().p("EgqGAEYIAAouMBUNAAAIAAIug");
        var mask_1_graphics_187 = new cjs.Graphics().p("EgrMAH0IAAouMBWZAAAIAAIug");

        this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics: mask_1_graphics_0, x: -28.3, y: 50.1}).wait(107).to({graphics: mask_1_graphics_107, x: -28.3, y: 50.1}).wait(1).to({graphics: mask_1_graphics_108, x: -35.8, y: 72.2}).wait(1).to({graphics: mask_1_graphics_109, x: -28.3, y: 72.2}).wait(1).to({graphics: mask_1_graphics_110, x: -20.8, y: 72.2}).wait(1).to({graphics: mask_1_graphics_111, x: -13.3, y: 72.2}).wait(1).to({graphics: mask_1_graphics_112, x: -5.8, y: 72.2}).wait(1).to({graphics: mask_1_graphics_113, x: 1.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_114, x: 9.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_115, x: 16.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_116, x: 24.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_117, x: 31.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_118, x: 39.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_119, x: 46.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_120, x: 54.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_121, x: 61.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_122, x: 69.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_123, x: 76.6, y: 50.1}).wait(18).to({graphics: mask_1_graphics_141, x: 76.6, y: 50.1}).wait(1).to({graphics: mask_1_graphics_142, x: 80.4, y: 72.2}).wait(1).to({graphics: mask_1_graphics_143, x: 84.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_144, x: 88, y: 72.2}).wait(1).to({graphics: mask_1_graphics_145, x: 91.8, y: 72.2}).wait(1).to({graphics: mask_1_graphics_146, x: 95.6, y: 72.2}).wait(1).to({graphics: mask_1_graphics_147, x: 99.4, y: 72.2}).wait(1).to({graphics: mask_1_graphics_148, x: 103.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_149, x: 106.9, y: 72.2}).wait(1).to({graphics: mask_1_graphics_150, x: 110.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_151, x: 114.5, y: 72.2}).wait(1).to({graphics: mask_1_graphics_152, x: 118.3, y: 72.2}).wait(1).to({graphics: mask_1_graphics_153, x: 122.1, y: 72.2}).wait(1).to({graphics: mask_1_graphics_154, x: 125.9, y: 72.2}).wait(1).to({graphics: mask_1_graphics_155, x: 129.7, y: 50.1}).wait(16).to({graphics: mask_1_graphics_171, x: 129.7, y: 50.1}).wait(1).to({graphics: mask_1_graphics_172, x: 136.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_173, x: 143.8, y: 72.2}).wait(1).to({graphics: mask_1_graphics_174, x: 150.9, y: 72.2}).wait(1).to({graphics: mask_1_graphics_175, x: 157.9, y: 72.2}).wait(1).to({graphics: mask_1_graphics_176, x: 165, y: 72.2}).wait(1).to({graphics: mask_1_graphics_177, x: 172.1, y: 72.2}).wait(1).to({graphics: mask_1_graphics_178, x: 179.1, y: 72.2}).wait(1).to({graphics: mask_1_graphics_179, x: 186.2, y: 72.2}).wait(1).to({graphics: mask_1_graphics_180, x: 193.3, y: 72.2}).wait(1).to({graphics: mask_1_graphics_181, x: 200.3, y: 72.2}).wait(1).to({graphics: mask_1_graphics_182, x: 207.4, y: 72.2}).wait(1).to({graphics: mask_1_graphics_183, x: 214.5, y: 72.2}).wait(1).to({graphics: mask_1_graphics_184, x: 221.5, y: 72.2}).wait(1).to({graphics: mask_1_graphics_185, x: 228.6, y: 72.2}).wait(1).to({graphics: mask_1_graphics_186, x: 235.7, y: 72.2}).wait(1).to({graphics: mask_1_graphics_187, x: 242.8, y: 50.1}).wait(4));

        // Capa 1
        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CC0000").s().p("AgggkIBBAkIhBAlg");
        this.shape_2.setTransform(277.8, 74.9);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#CC0000").ss(1, 1, 1).p("AmDAAIMGAA");
        this.shape_3.setTransform(236.1, 75);

        this.text_2 = new cjs.Text("Cuatro posibilidades", "20px Verdana");
        this.text_2.lineHeight = 20;
        this.text_2.setTransform(298.8, 60 + incremento);

        this.text_3 = new cjs.Text(txt['text_06e'], "italic 20px Verdana");
        this.text_3.textAlign = "left";
        this.text_3.lineHeight = 20;
        this.text_3.setTransform(0, 60 + incremento);
  this.text_3b = new cjs.Text(txt['text_06e1'], " 20px Verdana");
        this.text_3b.textAlign = "right";
        this.text_3b.lineHeight = 20;
        this.text_3b.setTransform(175.1, 60 + incremento);

        this.shape_2.mask = this.shape_3.mask= this.text_3b.mask = this.text_2.mask = this.text_3.mask = mask_1;

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.text_3},{t: this.text_3b}, {t: this.text_2}, {t: this.shape_3}, {t: this.shape_2}]}).wait(191000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-1.1, 0, 507.1, 88.3);


    (lib.Animacion_06 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 4
        this.instance = new lib.numeros_02();
        this.instance.setTransform(284.8, 427.9, 1, 1, 0, 0, 0, 179.8, 13);
        this.instance.alpha = 0;
        this.instance._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance).wait(101).to({_off: false}, 0).to({alpha: 1}, 13).wait(37));

        // Capa 3
        this.instance_1 = new lib.IMG_07();
        this.instance_1.setTransform(126, 347.7, 1, 1, 0, 0, 0, 118, 91.7);
        this.instance_1.alpha = 0;
        this.instance_1._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(66).to({_off: false}, 0).to({alpha: 1}, 21).wait(64));

        // Capa 2
        this.instance_2 = new lib.text_01();
        this.instance_2.setTransform(681.5, 196.8, 1, 1, 0, 0, 0, 108.5, 23.9);
        this.instance_2.alpha = 0;
        this.instance_2._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(40).to({_off: false}, 0).to({alpha: 1}, 12).wait(99));

        // Capa 1
        this.instance_3 = new lib.IMG_05();
        this.instance_3.setTransform(277.9, 99.7, 1, 1, 0, 0, 0, 277.9, 99.7);
        this.instance_3.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance_3).to({alpha: 1}, 24).wait(127000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 676.4, 199.5);


    (lib.Animacion_03 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 1
        this.instance = new lib.IMG_04();
        this.instance.setTransform(239.6, 159.7, 1, 1, 0, 0, 0, 239.6, 159.7);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha: 1}, 24).wait(153000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 425.7, 319.5);


    (lib.Animacion_02 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});



        // Capa 1
        this.instance = new lib.IMG_03();
        this.instance.setTransform(239.6, 159.7, 1, 1, 0, 0, 0, 239.6, 159.7);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha: 1}, 24).wait(98000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 479.2, 319.5);


    (lib.Animacion_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 2
        this.instance = new lib.numeros_01();
        this.instance.setTransform(230.7, 349.8, 1, 1, 0, 0, 0, 171.6, 14.2);
        this.instance.alpha = 0;

        this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha: 1}, 24).wait(77));

        // Capa 1
        this.instance_1 = new lib.IMG_02();
        this.instance_1.setTransform(245.6, 159.7, 1, 1, 0, 0, 0, 245.6, 159.7);
        this.instance_1.alpha = 0;
        this.instance_1._off = true;

        this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(43).to({_off: false}, 0).to({alpha: 1}, 22).wait(36000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(41.7, 21.6, 394, 28.3);



    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);
    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "#FFFFFF";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}