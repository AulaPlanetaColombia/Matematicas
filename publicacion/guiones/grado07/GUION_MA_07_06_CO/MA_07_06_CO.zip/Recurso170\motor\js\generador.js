Generador = new function()
{
	this.nOp;
	
	//var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
	//var this.lTiposVariaciones:Array=[3];
		
	this.lVariaciones = new Array();

	this.lPreguntas=new Array();
	this.lRespuestas=new Array();
	this.lRespuestasString=new Array();
	this.lFiguras=new Array();

	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	this.lTiposVariaciones=new Array();
	
	this.plano = "";
	this.co_pizarra = "";
	this.base ="";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase = ["Arial",36,"#0D3158",false];
		Random.init(semilla,100);
		
		this.lVariaciones = new Array();
		this.lPregsSprite = new Array();
		this.lRespsNumber = new Array();
		this.lRespsString = new Array();
		this.lFiguras = new Array();
		this.formula = "";
		this.co_pizarra = "";
				
		/*for ( var numOp = 0 ; numOp < Motor.qOperaciones; numOp++ ) {
			var indice = numOp % Motor.datosXML.variaciones.length;
			this.lVariaciones[numOp] = Motor.datosXML.variaciones[indice];
		}*/

		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();

			Motor.lOperaciones[this.nOp] = new Object();
			Motor.lOperaciones[this.nOp].respuestaNum = this.lRespsNumber[ this.nOp ];
			Motor.lOperaciones[this.nOp].base = this.base;
			Motor.lOperaciones[this.nOp].respuestaString = this.lRespsString[ this.nOp ];
			Motor.lOperaciones[this.nOp].in_exp = "";
			Motor.lOperaciones[this.nOp].estaListo = false;
			Motor.lOperaciones[this.nOp].correcto = false;
			Motor.lOperaciones[this.nOp].formula = this.co_pizarra;
			Motor.lOperaciones[this.nOp].enunciadoJ = Motor.lEnunciados[0];

			//console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
		}
		
	}
	
	this.enunciar = function()
	{

		//hace todos los cálculos:
		this.co_pizarra = new createjs.Container();
		this.base = Random.integer(2,9);
		var tiraNum = this.getTira();
		var tiraDen = this.getTira();
		//trace(tiraNum[1],tiraDen[1],tiraNum[1]-tiraDen[1]);
		var eaP = EA.fra(tiraNum[0],tiraDen[0]);
		eaP.x = 180;
		eaP.y = 150;
		this.lPregsSprite.push( eaP );
		this.lRespsNumber.push( tiraNum[1] - tiraDen[1] );
		this.lRespsString.push( ( tiraNum[1] - tiraDen[1] ).toString() );
		var figura = this.lPregsSprite[ this.nOp ];
		
		this.co_pizarra.addChild(figura);
		this.lFiguras.push(figura);
	
	}
	
	this.getTira = function()
	{
		var tiraReturn = new Array();
		var ea = EA.ini('');
		var expR;
		var long = Random.integer(1,3);
		//long=3;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		var dado = Random.integer(100);
		//dado=90;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		switch(long){
			case 1://un solo monomio
				if(dado<60){// N^n
					var exp = Random.integer(1,6);
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					expR = exp;
				}else{// (N^n)^m
					exp = Random.integer(2,6);
					var exp2 = Random.integer(0,6,[1]);
					ea = EA.par( EA.pot( this.base.toString() , exp.toString() ) );
					ea = EA.ade( ea, exp2.toString() );
					expR = exp * exp2;
				}
				break;
			case 2://dos monomios
				exp = Random.integer(1,6);
				exp2 = Random.integer(2,4);
				var exp3 = Random.integer(2,4);
				if(dado<30){// N^n·N^n
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp2.toString()),ea);
					expR=exp+exp2;
				}else if(dado<50){// (N^n·N^n)^m
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp2.toString()),ea);
					ea = EA.par(ea);
					ea = EA.ade(ea, exp3.toString());
					expR = (exp + exp2) * exp3;
				}else if(dado<75){// (N^n)^m·N^n
					ea = EA.par( EA.pot( this.base.toString(),exp.toString()));
					ea = EA.ade( ea, exp2.toString());
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp3.toString()),ea);
					expR = exp * exp2 + exp3;
				}else{//   N^n·(N^n)^m
					if( exp != 1 ){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.par(EA.pot(this.base.toString(), exp2.toString())),ea);
					ea = EA.ade(ea, exp3.toString());
					expR = exp + exp2 * exp3;
				}
				break;
			case 3://tres monomios
				exp = Random.integer(2,6);
				exp2 = Random.integer(2,4);
				exp3 = Random.integer(2,4);
				var exp4 =Random.integer(2,4);
				if( dado < 20 ){// N^n·N^n·N^n
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.pot( this.base.toString(),exp2.toString()),ea);
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.pot( this.base.toString(),exp3.toString()),ea);
					expR = exp + exp2 + exp3;
				}else if( dado < 33 ){// N^n·N^n·(N^n)^m
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.pot( this.base.toString(),exp2.toString()),ea);
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.par(EA.pot( this.base.toString(),exp3.toString())),ea);
					ea = EA.ade( ea, exp4.toString());
					expR = exp + exp2 + exp3 * exp4;
				}else if(dado<46){// N^n·(N^n)^m·N^n
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.par(EA.pot( this.base.toString(), exp2.toString())),ea);
					ea = EA.ade(ea, exp3.toString());
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp4.toString()),ea);
					expR = exp + exp2 * exp3 + exp4;
				}else if(dado<59){// (N^n)^m·N^n·N^n
					EA.adcStatic(EA.par(EA.pot( this.base.toString(), exp.toString())),ea);
					ea=EA.ade(ea, exp2.toString());
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp3.toString()),ea);
					EA.adcStatic('· ',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp4.toString()),ea);
					expR = exp * exp2 + exp3 + exp4;
				}else if(dado<74){// (N^n·N^n)^m·N^n
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp2.toString()),ea);
					ea = EA.par(ea);
					ea = EA.ade(ea, exp3.toString());
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp4.toString()),ea);
					expR = ( exp + exp2 ) * exp3 + exp4;
				}else if(dado<89){// N^n·(N^n·N^n)^m
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('· ',ea);
					var ea2 = EA.ini('');
					ea2=EA.pot( this.base.toString(), exp2.toString());
					EA.adcStatic('·',ea2);
					EA.adcStatic(EA.pot( this.base.toString(), exp3.toString()),ea2);
					ea2 = EA.par(ea2);
					EA.adcStatic(ea2,ea);
					ea = EA.ade(ea, exp4.toString());
					expR = exp + (exp2 + exp3) * exp4;
				}else{// (N^n·N^n·N^n)^m
					if(exp != 1){
						ea = EA.pot( this.base.toString() , exp.toString() );
					}else{
						ea = EA.pot( this.base.toString() , null);
					}
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp2.toString()),ea);
					EA.adcStatic('·',ea);
					EA.adcStatic(EA.pot( this.base.toString(), exp3.toString()),ea);
					ea = EA.par(ea);
					ea = EA.ade(ea, exp4.toString());
					expR = ( exp + exp2 + exp3 ) * exp4;
				}
				break;
		}
		return [ea,expR];
	}
}