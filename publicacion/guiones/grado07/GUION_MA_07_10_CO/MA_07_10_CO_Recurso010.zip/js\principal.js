(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
        titulo1(this,txt['titulo']);
        this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(479.1,338.5,1,1,0,0,0,182.9,184.1);

    this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
   
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       	this.text = new cjs.Text(txt['tit1'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 793;
	this.text.setTransform(475.6,70.6);
	this.instance_1 = new lib.shutterstock_96717475();
	this.instance_1.setTransform(323,132.4,0.421,0.421);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.text, this.home, this.siguiente,this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       this.instance = new lib.mc_pantalla_2();
	this.instance.setTransform(654,340.6,1,1,0,0,0,182.9,184.1);
this.instance.on("tick", function (evt) {
    
      if (this.parent.instance.currentFrame>95){
          this.parent.instance.stop();
          this.parent.instance.removeAllEventListeners();
      }
      }); 

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        this.instance = new lib.mc_pantalla_2("single",125);
       // this.instance.gotoAndPlay(95);
	this.instance.setTransform(654,340.6,1,1,0,0,0,182.9,184.1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        this.instance = new lib.mc_pantalla_2("single",135);
	this.instance.setTransform(654,340.6,1,1,0,0,0,182.9,184.1);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        this.instance = new lib.mc_pantalla_2("single",165);
	this.instance.setTransform(654,340.6,1,1,0,0,0,182.9,184.1);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       titulo2(this,txt['tit2'],"23px");
        this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(479.1,338.5,1,1,0,0,0,182.9,184.1);
   this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pantalla_4();
	this.instance.setTransform(473.8,341.8,1,1,0,0,0,182.9,183.2);

   this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       titulo2(this,txt['tit3'],"23px");
        this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(479.1,338.5,1,1,0,0,0,182.9,184.1);
   this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pantalla_6();
	this.instance.setTransform(473.8,341.8,1,1,0,0,0,182.9,183.2);

   this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame11());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame11 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.text = new cjs.Text("¿Cuáles son las coordenadas del punto C ?", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 783;
	this.text.setTransform(471.3,70.6);
  var html = createDiv(txt['tit4'], "Verdana", "20px", '790px', '40px', "20px", "185px", "center");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 71-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape.setTransform(425.4,214.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape_1.setTransform(487.6,327.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_2.setTransform(487.5,298.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_3.setTransform(487.4,269.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_4.setTransform(487.4,240.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_5.setTransform(487.5,212.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_6.setTransform(487.5,183.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_7.setTransform(488.5,513.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_8.setTransform(480.8,513.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_9.setTransform(488.5,484.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_10.setTransform(480.8,484.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_11.setTransform(488.3,455.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_12.setTransform(480.8,456);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_13.setTransform(488.4,426.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_14.setTransform(480.8,427.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_15.setTransform(488.5,397.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_16.setTransform(480.8,398.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_17.setTransform(488.6,369);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_18.setTransform(480.8,369.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_19.setTransform(628.8,358.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_20.setTransform(600.1,358.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_21.setTransform(575.4,358.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_22.setTransform(546.8,358.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_23.setTransform(522.3,358.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(497.9,358.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_25.setTransform(455,358.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_26.setTransform(447.2,359.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_27.setTransform(427,358.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_28.setTransform(419.3,359.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_29.setTransform(399.1,358.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_30.setTransform(391.4,359.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_31.setTransform(371.1,358.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_32.setTransform(363.5,359.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_33.setTransform(343.3,358.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_34.setTransform(335.6,359.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_35.setTransform(315.4,358.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_36.setTransform(307.7,359.1);

	this.text_1 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(477.1,161.7);

	this.text_2 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(642.8,350.7);

	this.text_3 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(458.4,331.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_37.setTransform(641.6,346.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_38.setTransform(473.3,174.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_39.setTransform(469.5,346.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_40.setTransform(473.5,345.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(474,188.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(474,215.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(474,241.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(474,269.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(474,296.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(474,322.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(474,371.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(474,396.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(474,422.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(474,449.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(474,476.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_52.setTransform(474,502.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(628.6,342);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(601.6,342);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(575.6,342);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(547.6,342);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(520.6,342);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(494.6,342);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(452.6,342);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(425.6,342);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(399.6,342);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(372.6,342);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(345.6,342);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_64.setTransform(319.6,342);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_65.setTransform(473.8,341.8);

   this.anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame12());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.text_3,this.text_2,this.text_1,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame12 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.mc_pantalla_8 = new lib.mc_pantalla_8();
	this.mc_pantalla_8.setTransform(473.8,341.8,1,1,0,0,0,182.9,183.2);

  this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame13());
    });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame11());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.cerrar, this.anterior,this.mc_pantalla_8, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame13 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 1);
         titulo2(this,txt['tit5'],"23px");
    // Capa 1
	this.text = new cjs.Text("D", "italic bold 18px Verdana", "#EF542E");
	this.text.lineHeight = 20;
	this.text.setTransform(422.1,398.9);

	this.text_1 = new cjs.Text("E", "italic bold 18px Verdana", "#EF542E");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(552.1,423.9);

	this.text_2 = new cjs.Text("C", "italic bold 18px Verdana", "#EF542E");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(502.1,313);

	this.text_3 = new cjs.Text("B", "italic bold 18px Verdana", "#EF542E");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(348.1,293);

	this.text_4 = new cjs.Text("A", "italic bold 18px Verdana", "#EF542E");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(402,240);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape.setTransform(546,422.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_1.setTransform(451,398);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_2.setTransform(498,347);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_3.setTransform(373,322);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_4.setTransform(425,270);

	this.instance = new lib.mc_pantalla_9("single",0);
	this.instance.setTransform(473.8,341.8,1,1,0,0,0,182.9,183.2);
  this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame14());
    });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame12());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.cerrar,this.anterior, this.practica,this.instance,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame14 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 1);
    this.text = new cjs.Text("D", "italic bold 18px Verdana", "#EF542E");
	this.text.lineHeight = 20;
	this.text.setTransform(504.1,398.9);

	this.text_1 = new cjs.Text("E", "italic bold 18px Verdana", "#EF542E");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(634.1,423.9);

	this.text_2 = new cjs.Text("C", "italic bold 18px Verdana", "#EF542E");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(584.1,313);

	this.text_3 = new cjs.Text("B", "italic bold 18px Verdana", "#EF542E");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(430.1,293);

	this.text_4 = new cjs.Text("A", "italic bold 18px Verdana", "#EF542E");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(484,240);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape.setTransform(628,422.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_1.setTransform(533,398);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_2.setTransform(580,347);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_3.setTransform(455,322);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EF542E").s().p("AgqArQgTgSABgZQgBgYATgSQASgSAYAAQAZAAASASQASASABAYQgBAZgSASQgSASgZABQgYgBgSgSg");
	this.shape_4.setTransform(507,270);

	this.instance = new lib.mc_pantalla_9("single",0);
	this.instance.setTransform(555.8,341.8,1,1,0,0,0,182.9,183.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AGsKaIAAgBQAIgHAHgKQAIgKAGgLQAGgNADgOQAEgOAAgRQAAgQgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQASATAJAYQAKAXAAAdQAAAegKAXQgJAYgSAUgAiSKaQgRgUgKgYQgJgXAAgeQAAgdAJgXQAKgYARgTIAXAAIAAABQgIAGgHAKQgIAKgGAMQgGAMgDAOQgEAOAAAQQAAARAEAOQADAOAGANQAGALAIAKQAHAKAIAHIAAABgAAfKVIARhAIAYAAIgbBAgAFCJxQgLgCgIgDIAAgVIACAAQAIAFALAEQALADALABQAGAAAHgCQAHgCAEgFQAFgEACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgHQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKADgKAGIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAhJJxQgMgCgHgDIAAgVIABAAQAIAFAMAEQALADAKABQAGAAAHgCQAHgCAFgFQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgHQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKAEQAGACAFAEQAEAEADAGQABAHAAAKQAAAJgBAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgApwJxIAiiRIBfAAIgDAQIhNAAIgJAqIBMAAIgEAQIhMAAIgNA3IBNAAIgEAQgAmaJOIAAgPIB0AAIAAAPgACvI5IAAgPIBhAAIAAAPgAmaIlIAAgQIB0AAIAAAQgAJGGMIAAgBQAHgHAIgKQAHgKAGgLQAGgNAEgOQADgOAAgRQAAgQgDgOQgEgOgGgMQgGgMgHgKQgHgKgIgGIAAgBIAWAAQARATAKAYQAJAXAAAdQAAAegJAXQgKAYgRAUgAh3GMQgRgUgKgYQgKgXAAgeQAAgdAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAQQAAARADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgAC4GHIARhAIAZAAIgcBAgAHIFjIAAgUIAVgSIATgRQASgSAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAJgCAGQgCAIgEAGQgEAHgFAFIgMANIgWAUIgVASIBOAAIAAAQgABGFjIAAgOIAeAAIAAhiIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACEIAeAAIAAAOgApwFjIAiiRIAiAAQAPAAANADQANABALAIQALAGAFAMQAGALAAAPQAAAXgNAWQgMAWgVALQgNAHgNACQgNACgSAAgApZFUIAUAAQAOAAALgDQALgCAKgFQAQgKAIgQQAIgSAAgSQAAgMgEgHQgEgJgIgFQgIgGgJgBQgJgCgNAAIgRAAgAl/FAIAAgPIBzAAIAAAPgAFIErIAAgPIBhAAIAAAPgAhDErIAAgPIBfAAIAAAPgAl/EXIAAgQIBzAAIAAAQgAE6BqIAAgBQAIgHAHgJQAIgLAGgMQAGgMADgOQAEgOAAgQQAAgOgEgPQgEgOgFgMQgHgNgHgJQgHgJgIgIIAAgBIAWAAQASAVAJAXQAKAXAAAcQAAAdgKAYQgJAXgSAUgAiFBqQgRgUgKgXQgJgYAAgdQAAgcAJgXQAKgXARgVIAXAAIAAABQgIAIgHAJQgIAJgGANQgGAMgDAOQgEAPAAAOQAAAQAEAOQADAOAGAMQAGAMAIALQAHAJAIAHIAAABgAAsBlIARhAIAYAAIgbBAgADGAyQgMgTAAgkQAAgnAMgSQANgTAZAAQAbAAAMATQAMATAAAlQAAAmgMATQgNASgaAAQgagBgMgSgADdg9QgGAEgDAHQgEAIgBALQgBAMAAAOQAAANABAKQABALAEAIQADAHAGAEQAGAFAJAAQAKAAAGgFQAGgDADgIQADgIACgLIABgYIgBgZQgCgLgDgIQgDgHgGgEQgGgDgKAAQgJAAgGADgApaA2QgQgPAAgaQAAgSAGgRQAGgSAMgMQALgNAQgIQARgHAUAAQANAAALACQALADAMAHIgFAWIgBAAIgGgGIgKgGQgGgDgHgBQgIgCgJAAQgNgBgMAGQgLAGgIAKQgJAKgEAPQgFAOAAAOQAAAUAKALQALALAUAAQAJAAAIgCQAJgCAGgDIAMgHIAIgGIACAAIgFAXQgKAFgNAEQgOAEgPAAQgbAAgQgOgAhFBBIAAgOIAfAAIAAhgIgfAAIAAgNIAOgBQAHgBADgCQAFgDACgDQADgEAAgHIAPAAIAACCIAcAAIAAAOgAmNAeIAAgPIB0AAIAAAPgAmNgJIAAgQIB0AAIAAAQgAG3i3IAAAAQAHgHAIgJQAHgKAGgNQAGgMAEgOQADgNAAgRQAAgQgDgPQgEgPgGgMQgGgLgHgKQgHgJgIgIIAAgBIAWAAQARAVAKAXQAJAXAAAeQAAAdgJAYQgKAXgRATgAiHi3QgRgTgKgXQgKgYAAgdQAAgeAKgXQAKgXARgVIAWAAIAAABQgIAIgHAJQgHAKgGALQgGAMgEAPQgDAPAAAQQAAARADANQAEAOAGAMQAGANAHAKQAIAJAHAHIAAAAgACoi7IARg/IAZAAIgcA/gAFEjeIAAgQIAfAAIAAhhIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACCIAeAAIAAAQgABojeIAAgqIhGAAIAAgWIBHhSIASAAIAABZIAVAAIAAAPIgVAAIAAAqgAAwkXIA4AAIAAhCgApwjeIAiiSIApAAIAYABQAIABAGAEQAGADACAFQADAGAAAGQAAAMgHAKQgHAKgNAFIAAABQAMADAGAHQAGAHAAALQAAANgGALQgGALgKAHQgKAGgKADQgKACgPABgApZjvIAbAAQANABAIgCQAIgBAGgEQAIgEAEgJQAEgHAAgKQAAgFgCgDQgCgEgFgCQgEgDgGgBIgRgBIgdAAgApIk1IAZAAIAPgBIALgEQAGgDADgHQADgGAAgHQAAgDgBgDIgEgFQgEgDgHAAIgPgBIgWAAgAmPkCIAAgQIBzAAIAAAQgAhTkWIAAgQIBfAAIAAAQgAmPkrIAAgPIBzAAIAAAPgAG2nZIAAAAQAIgHAHgKQAIgJAGgMQAGgNADgOQAEgOAAgQQAAgRgEgOQgEgOgFgNQgHgMgHgJQgHgJgIgIIAAAAIAWAAQASATAJAYQAKAXAAAeQAAAdgKAXQgJAYgSATgAiInZQgRgTgKgYQgJgXAAgdQAAgeAJgXQAKgYARgTIAXAAIAAAAQgIAIgHAJQgIAJgGAMQgGANgDAOQgEAOAAARQAAAQAEAOQADAOAGANQAGAMAIAJQAHAKAIAHIAAAAgAConcIARhAIAYAAIgbBAgAFMoAQgLgDgIgEIAAgUIACAAQAIAGALADQALAEALgBQAGAAAHgCQAHgBAEgFQAFgEACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgCgIABIgIAAIAAgRIAGAAQAPABAJgHQAJgGAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKACgKAHIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAJQAAAMgJAKQgIAIgMADIAAABIALADQAGADAEAEQAFADADAHQADAGAAAKQAAAKgEAJQgDAIgHAGQgHAHgKAEQgKACgMAAQgMAAgMgCgAAqoAIAAgVIAVgRIATgSQASgSAHgLQAHgLAAgMQAAgLgHgGQgIgHgNAAQgJAAgKADQgLADgJAHIgBAAIAAgVQAHgDALgDQAMgDALAAQAWAAANALQAMALAAASQAAAJgCAGQgCAIgEAGQgEAGgFAGIgMANIgWAUIgVASIBOAAIAAARgAoPoAIgFgqIg/AAIgYAqIgUAAIBWiSIAaAAIATCSgApKo5IA0AAIgJhIgAmQokIAAgQIB0AAIAAAQgAhUo4IAAgQIBfAAIAAAQgAmQpNIAAgPIB0AAIAAAPg");
	this.shape_5.setTransform(257.2,318.5);
        this.anterior.on("click", function (evt) {
        putStage(new lib.frame13());
    });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame12());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.cerrar, this.anterior,this.shape_5,this.instance,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,53,83);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,28,112);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,53,134);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,53,134);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.shutterstock_96717475 = function() {
	this.initialize(img.shutterstock_96717475);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,750,1000);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.mc_pantalla_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_19 = new cjs.Graphics().p("Ao2BFIAAiIIRtAAIAACIg");
	var mask_graphics_20 = new cjs.Graphics().p("Ao2BjIAAjFIRtAAIAADFg");
	var mask_graphics_21 = new cjs.Graphics().p("Ao2CBIAAkBIRtAAIAAEBg");
	var mask_graphics_22 = new cjs.Graphics().p("Ao2CfIAAk9IRtAAIAAE9g");
	var mask_graphics_23 = new cjs.Graphics().p("Ao2C9IAAl5IRtAAIAAF5g");
	var mask_graphics_24 = new cjs.Graphics().p("Ao2DbIAAm1IRtAAIAAG1g");
	var mask_graphics_25 = new cjs.Graphics().p("Ao2D5IAAnxIRtAAIAAHxg");
	var mask_graphics_26 = new cjs.Graphics().p("Ao2EYIAAovIRtAAIAAIvg");
	var mask_graphics_27 = new cjs.Graphics().p("Ao2E2IAAprIRtAAIAAJrg");
	var mask_graphics_28 = new cjs.Graphics().p("Ao2FUIAAqnIRtAAIAAKng");
	var mask_graphics_29 = new cjs.Graphics().p("Ao2FyIAArjIRtAAIAALjg");
	var mask_graphics_30 = new cjs.Graphics().p("Ao2GQIAAsfIRtAAIAAMfg");
	var mask_graphics_31 = new cjs.Graphics().p("Ao2GuIAAtbIRtAAIAANbg");
	var mask_graphics_32 = new cjs.Graphics().p("Ao2HNIAAuZIRtAAIAAOZg");
	var mask_graphics_33 = new cjs.Graphics().p("Ao2HrIAAvVIRtAAIAAPVg");
	var mask_graphics_34 = new cjs.Graphics().p("Ao2IJIAAwRIRtAAIAAQRg");
	var mask_graphics_35 = new cjs.Graphics().p("Ao2InIAAxNIRtAAIAARNg");
	var mask_graphics_36 = new cjs.Graphics().p("Ao2JFIAAyJIRtAAIAASJg");
	var mask_graphics_37 = new cjs.Graphics().p("Ao2JjIAAzFIRtAAIAATFg");
	var mask_graphics_38 = new cjs.Graphics().p("Ao2KCIAA0DIRtAAIAAUDg");
	var mask_graphics_39 = new cjs.Graphics().p("Ao2KgIAA0/IRtAAIAAU/g");
	var mask_graphics_40 = new cjs.Graphics().p("Ao2K+IAA17IRtAAIAAV7g");
	var mask_graphics_41 = new cjs.Graphics().p("Ao2LcIAA23IRtAAIAAW3g");
	var mask_graphics_42 = new cjs.Graphics().p("Ao2L6IAA3zIRtAAIAAXzg");
	var mask_graphics_43 = new cjs.Graphics().p("Ao2MYIAA4vIRtAAIAAYvg");
	var mask_graphics_44 = new cjs.Graphics().p("Ao2M2IAA5rIRtAAIAAZrg");
	var mask_graphics_45 = new cjs.Graphics().p("Ao2NVIAA6pIRtAAIAAapg");
	var mask_graphics_46 = new cjs.Graphics().p("Ao2NzIAA7lIRtAAIAAblg");
	var mask_graphics_47 = new cjs.Graphics().p("Ao2ORIAA8hIRtAAIAAchg");
	var mask_graphics_48 = new cjs.Graphics().p("Ao2OvIAA9dIRtAAIAAddg");
	var mask_graphics_49 = new cjs.Graphics().p("AgtROIAA+aIRuAAIAAeag");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_graphics_19,x:161.1,y:213.5}).wait(1).to({graphics:mask_graphics_20,x:161.1,y:210.5}).wait(1).to({graphics:mask_graphics_21,x:161.1,y:207.5}).wait(1).to({graphics:mask_graphics_22,x:161.1,y:204.5}).wait(1).to({graphics:mask_graphics_23,x:161.1,y:201.4}).wait(1).to({graphics:mask_graphics_24,x:161.1,y:198.4}).wait(1).to({graphics:mask_graphics_25,x:161.1,y:195.4}).wait(1).to({graphics:mask_graphics_26,x:161.1,y:192.4}).wait(1).to({graphics:mask_graphics_27,x:161.1,y:189.4}).wait(1).to({graphics:mask_graphics_28,x:161.1,y:186.4}).wait(1).to({graphics:mask_graphics_29,x:161.1,y:183.3}).wait(1).to({graphics:mask_graphics_30,x:161.1,y:180.3}).wait(1).to({graphics:mask_graphics_31,x:161.1,y:177.3}).wait(1).to({graphics:mask_graphics_32,x:161.1,y:174.3}).wait(1).to({graphics:mask_graphics_33,x:161.1,y:171.3}).wait(1).to({graphics:mask_graphics_34,x:161.1,y:168.3}).wait(1).to({graphics:mask_graphics_35,x:161.1,y:165.2}).wait(1).to({graphics:mask_graphics_36,x:161.1,y:162.2}).wait(1).to({graphics:mask_graphics_37,x:161.1,y:159.2}).wait(1).to({graphics:mask_graphics_38,x:161.1,y:156.2}).wait(1).to({graphics:mask_graphics_39,x:161.1,y:153.2}).wait(1).to({graphics:mask_graphics_40,x:161.1,y:150.2}).wait(1).to({graphics:mask_graphics_41,x:161.1,y:147.2}).wait(1).to({graphics:mask_graphics_42,x:161.1,y:144.1}).wait(1).to({graphics:mask_graphics_43,x:161.1,y:141.1}).wait(1).to({graphics:mask_graphics_44,x:161.1,y:138.1}).wait(1).to({graphics:mask_graphics_45,x:161.1,y:135.1}).wait(1).to({graphics:mask_graphics_46,x:161.1,y:132.1}).wait(1).to({graphics:mask_graphics_47,x:161.1,y:129.1}).wait(1).to({graphics:mask_graphics_48,x:161.1,y:126}).wait(1).to({graphics:mask_graphics_49,x:109,y:110.2}).wait(17));

	// grafica
	this.instance = new lib.Mapadebits4();
	this.instance.setTransform(130.7,52.9);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).wait(47));

	// text1
	this.text = new cjs.Text("C", "italic 20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(113.3,25.9);

	this.text_1 = new cjs.Text("C = (–2 , 5)", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(-205.8,-0.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1},{t:this.text}]},61).wait(5));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,168.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,139.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,111.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,82.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,53.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,24.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,354.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,325.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,326.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,296.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,297.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,268.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,268.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,239.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,239.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,210.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,200.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,199.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,200.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,199.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,200.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,200.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,200.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,200.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,200.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,200.5);

	this.text_2 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(186.2,3.1);

	this.text_3 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(351.9,192.1);

	this.text_4 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(167.5,172.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,188.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,15.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,188.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,187.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,29.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,56.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,82.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,110.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,137.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,163.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,212.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,237.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,263.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,290.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,317.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,343.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,183.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,183.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,183.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,183.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,183.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,183.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,183.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,183.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,183.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,183.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,183.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,183.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,183.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(66));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,366.2,366.5);


(lib.mc_pantalla_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_19 = new cjs.Graphics().p("Ao2BFIAAiIIRtAAIAACIg");
	var mask_graphics_20 = new cjs.Graphics().p("Ao2BTIAAilIRtAAIAAClg");
	var mask_graphics_21 = new cjs.Graphics().p("Ao2BiIAAjDIRtAAIAADDg");
	var mask_graphics_22 = new cjs.Graphics().p("Ao2BwIAAjfIRtAAIAADfg");
	var mask_graphics_23 = new cjs.Graphics().p("Ao2B/IAAj9IRtAAIAAD9g");
	var mask_graphics_24 = new cjs.Graphics().p("Ao2CNIAAkZIRtAAIAAEZg");
	var mask_graphics_25 = new cjs.Graphics().p("Ao2CcIAAk3IRtAAIAAE3g");
	var mask_graphics_26 = new cjs.Graphics().p("Ao2CrIAAlVIRtAAIAAFVg");
	var mask_graphics_27 = new cjs.Graphics().p("Ao2C5IAAlxIRtAAIAAFxg");
	var mask_graphics_28 = new cjs.Graphics().p("Ao2DIIAAmPIRtAAIAAGPg");
	var mask_graphics_29 = new cjs.Graphics().p("Ao2DWIAAmrIRtAAIAAGrg");
	var mask_graphics_30 = new cjs.Graphics().p("Ao2DlIAAnJIRtAAIAAHJg");
	var mask_graphics_31 = new cjs.Graphics().p("Ao2D0IAAnnIRtAAIAAHng");
	var mask_graphics_32 = new cjs.Graphics().p("Ao2ECIAAoDIRtAAIAAIDg");
	var mask_graphics_33 = new cjs.Graphics().p("Ao2ERIAAohIRtAAIAAIhg");
	var mask_graphics_34 = new cjs.Graphics().p("Ao2EfIAAo9IRtAAIAAI9g");
	var mask_graphics_35 = new cjs.Graphics().p("Ao2EuIAApbIRtAAIAAJbg");
	var mask_graphics_36 = new cjs.Graphics().p("Ao2E9IAAp5IRtAAIAAJ5g");
	var mask_graphics_37 = new cjs.Graphics().p("Ao2FLIAAqVIRtAAIAAKVg");
	var mask_graphics_38 = new cjs.Graphics().p("Ao2FaIAAqzIRtAAIAAKzg");
	var mask_graphics_39 = new cjs.Graphics().p("Ao2FoIAArPIRtAAIAALPg");
	var mask_graphics_40 = new cjs.Graphics().p("Ao2F3IAArtIRtAAIAALtg");
	var mask_graphics_41 = new cjs.Graphics().p("Ao2GGIAAsLIRtAAIAAMLg");
	var mask_graphics_42 = new cjs.Graphics().p("Ao2GUIAAsnIRtAAIAAMng");
	var mask_graphics_43 = new cjs.Graphics().p("Ao2GjIAAtFIRtAAIAANFg");
	var mask_graphics_44 = new cjs.Graphics().p("Ao2GxIAAthIRtAAIAANhg");
	var mask_graphics_45 = new cjs.Graphics().p("Ao2HAIAAt/IRtAAIAAN/g");
	var mask_graphics_46 = new cjs.Graphics().p("Ao2HPIAAudIRtAAIAAOdg");
	var mask_graphics_47 = new cjs.Graphics().p("Ao2HdIAAu5IRtAAIAAO5g");
	var mask_graphics_48 = new cjs.Graphics().p("Ao2HsIAAvXIRtAAIAAPXg");
	var mask_graphics_49 = new cjs.Graphics().p("Ao2H6IAAvzIRtAAIAAPzg");
	var mask_graphics_50 = new cjs.Graphics().p("Ao2IJIAAwRIRtAAIAAQRg");
	var mask_graphics_51 = new cjs.Graphics().p("Ao2IXIAAwtIRtAAIAAQtg");
	var mask_graphics_52 = new cjs.Graphics().p("Ao2ImIAAxLIRtAAIAARLg");
	var mask_graphics_53 = new cjs.Graphics().p("Ao2I1IAAxpIRtAAIAARpg");
	var mask_graphics_54 = new cjs.Graphics().p("Ao2JDIAAyFIRtAAIAASFg");
	var mask_graphics_55 = new cjs.Graphics().p("Ao2JSIAAyjIRtAAIAASjg");
	var mask_graphics_56 = new cjs.Graphics().p("Ao2JgIAAy/IRtAAIAAS/g");
	var mask_graphics_57 = new cjs.Graphics().p("Ao2JvIAAzdIRtAAIAATdg");
	var mask_graphics_58 = new cjs.Graphics().p("Ao2J+IAAz7IRtAAIAAT7g");
	var mask_graphics_59 = new cjs.Graphics().p("Ao2KMIAA0XIRtAAIAAUXg");
	var mask_graphics_60 = new cjs.Graphics().p("Ao2KbIAA01IRtAAIAAU1g");
	var mask_graphics_61 = new cjs.Graphics().p("Ao2KpIAA1RIRtAAIAAVRg");
	var mask_graphics_62 = new cjs.Graphics().p("Ao2K4IAA1vIRtAAIAAVvg");
	var mask_graphics_63 = new cjs.Graphics().p("Ao2LHIAA2NIRtAAIAAWNg");
	var mask_graphics_64 = new cjs.Graphics().p("Ao2LVIAA2pIRtAAIAAWpg");
	var mask_graphics_65 = new cjs.Graphics().p("Ao2LkIAA3HIRtAAIAAXHg");
	var mask_graphics_66 = new cjs.Graphics().p("Ao2LyIAA3jIRtAAIAAXjg");
	var mask_graphics_67 = new cjs.Graphics().p("Ao2MBIAA4BIRtAAIAAYBg");
	var mask_graphics_68 = new cjs.Graphics().p("Ao2MQIAA4fIRtAAIAAYfg");
	var mask_graphics_69 = new cjs.Graphics().p("Ao2MeIAA47IRtAAIAAY7g");
	var mask_graphics_70 = new cjs.Graphics().p("Ao2MtIAA5ZIRtAAIAAZZg");
	var mask_graphics_71 = new cjs.Graphics().p("Ao2M7IAA51IRtAAIAAZ1g");
	var mask_graphics_72 = new cjs.Graphics().p("Ao2NKIAA6TIRtAAIAAaTg");
	var mask_graphics_73 = new cjs.Graphics().p("Ao2NZIAA6xIRtAAIAAaxg");
	var mask_graphics_74 = new cjs.Graphics().p("Ao2NnIAA7NIRtAAIAAbNg");
	var mask_graphics_75 = new cjs.Graphics().p("Ao2N2IAA7rIRtAAIAAbrg");
	var mask_graphics_76 = new cjs.Graphics().p("Ao2OEIAA8HIRtAAIAAcHg");
	var mask_graphics_77 = new cjs.Graphics().p("Ao2OTIAA8lIRtAAIAAclg");
	var mask_graphics_78 = new cjs.Graphics().p("Ao2OhIAA9BIRtAAIAAdBg");
	var mask_graphics_79 = new cjs.Graphics().p("Ao2OwIAA9fIRtAAIAAdfg");
	var mask_graphics_80 = new cjs.Graphics().p("Ao2O/IAA99IRtAAIAAd9g");
	var mask_graphics_81 = new cjs.Graphics().p("AgtROIAA+aIRuAAIAAeag");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_graphics_19,x:161.1,y:213.5}).wait(1).to({graphics:mask_graphics_20,x:161.1,y:212}).wait(1).to({graphics:mask_graphics_21,x:161.1,y:210.6}).wait(1).to({graphics:mask_graphics_22,x:161.1,y:209.1}).wait(1).to({graphics:mask_graphics_23,x:161.1,y:207.7}).wait(1).to({graphics:mask_graphics_24,x:161.1,y:206.2}).wait(1).to({graphics:mask_graphics_25,x:161.1,y:204.7}).wait(1).to({graphics:mask_graphics_26,x:161.1,y:203.3}).wait(1).to({graphics:mask_graphics_27,x:161.1,y:201.8}).wait(1).to({graphics:mask_graphics_28,x:161.1,y:200.4}).wait(1).to({graphics:mask_graphics_29,x:161.1,y:198.9}).wait(1).to({graphics:mask_graphics_30,x:161.1,y:197.4}).wait(1).to({graphics:mask_graphics_31,x:161.1,y:196}).wait(1).to({graphics:mask_graphics_32,x:161.1,y:194.5}).wait(1).to({graphics:mask_graphics_33,x:161.1,y:193.1}).wait(1).to({graphics:mask_graphics_34,x:161.1,y:191.6}).wait(1).to({graphics:mask_graphics_35,x:161.1,y:190.2}).wait(1).to({graphics:mask_graphics_36,x:161.1,y:188.7}).wait(1).to({graphics:mask_graphics_37,x:161.1,y:187.2}).wait(1).to({graphics:mask_graphics_38,x:161.1,y:185.8}).wait(1).to({graphics:mask_graphics_39,x:161.1,y:184.3}).wait(1).to({graphics:mask_graphics_40,x:161.1,y:182.9}).wait(1).to({graphics:mask_graphics_41,x:161.1,y:181.4}).wait(1).to({graphics:mask_graphics_42,x:161.1,y:179.9}).wait(1).to({graphics:mask_graphics_43,x:161.1,y:178.5}).wait(1).to({graphics:mask_graphics_44,x:161.1,y:177}).wait(1).to({graphics:mask_graphics_45,x:161.1,y:175.6}).wait(1).to({graphics:mask_graphics_46,x:161.1,y:174.1}).wait(1).to({graphics:mask_graphics_47,x:161.1,y:172.6}).wait(1).to({graphics:mask_graphics_48,x:161.1,y:171.2}).wait(1).to({graphics:mask_graphics_49,x:161.1,y:169.7}).wait(1).to({graphics:mask_graphics_50,x:161.1,y:168.3}).wait(1).to({graphics:mask_graphics_51,x:161.1,y:166.8}).wait(1).to({graphics:mask_graphics_52,x:161.1,y:165.3}).wait(1).to({graphics:mask_graphics_53,x:161.1,y:163.9}).wait(1).to({graphics:mask_graphics_54,x:161.1,y:162.4}).wait(1).to({graphics:mask_graphics_55,x:161.1,y:161}).wait(1).to({graphics:mask_graphics_56,x:161.1,y:159.5}).wait(1).to({graphics:mask_graphics_57,x:161.1,y:158}).wait(1).to({graphics:mask_graphics_58,x:161.1,y:156.6}).wait(1).to({graphics:mask_graphics_59,x:161.1,y:155.1}).wait(1).to({graphics:mask_graphics_60,x:161.1,y:153.7}).wait(1).to({graphics:mask_graphics_61,x:161.1,y:152.2}).wait(1).to({graphics:mask_graphics_62,x:161.1,y:150.8}).wait(1).to({graphics:mask_graphics_63,x:161.1,y:149.3}).wait(1).to({graphics:mask_graphics_64,x:161.1,y:147.8}).wait(1).to({graphics:mask_graphics_65,x:161.1,y:146.4}).wait(1).to({graphics:mask_graphics_66,x:161.1,y:144.9}).wait(1).to({graphics:mask_graphics_67,x:161.1,y:143.5}).wait(1).to({graphics:mask_graphics_68,x:161.1,y:142}).wait(1).to({graphics:mask_graphics_69,x:161.1,y:140.5}).wait(1).to({graphics:mask_graphics_70,x:161.1,y:139.1}).wait(1).to({graphics:mask_graphics_71,x:161.1,y:137.6}).wait(1).to({graphics:mask_graphics_72,x:161.1,y:136.2}).wait(1).to({graphics:mask_graphics_73,x:161.1,y:134.7}).wait(1).to({graphics:mask_graphics_74,x:161.1,y:133.2}).wait(1).to({graphics:mask_graphics_75,x:161.1,y:131.8}).wait(1).to({graphics:mask_graphics_76,x:161.1,y:130.3}).wait(1).to({graphics:mask_graphics_77,x:161.1,y:128.9}).wait(1).to({graphics:mask_graphics_78,x:161.1,y:127.4}).wait(1).to({graphics:mask_graphics_79,x:161.1,y:125.9}).wait(1).to({graphics:mask_graphics_80,x:161.1,y:124.5}).wait(1).to({graphics:mask_graphics_81,x:109,y:110.2}).wait(79));

	// grafica
	this.instance = new lib.Mapadebits3();
	this.instance.setTransform(130.7,52.9);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},19).wait(141));

	// text1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AIYBgIAAgBQAIgHAHgKQAHgKAHgLQAFgNAEgOQAEgOgBgQQABgPgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQARATAKAYQAJAXAAAcQAAAdgJAXQgKAYgRAUgAhsBgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgHAMQgFAMgEAOQgEAOABAPQgBAQAEAOQAEAOAFANQAHALAHAKQAIAKAHAHIAAABgAEKBbIAQhAIAZAAIgcBAgAGvA4QgLgCgHgEIAAgUIABAAQAIAFALADQAKADALABQAHAAAGgCQAHgCAFgFQAEgEACgGQACgGAAgIQABgIgDgCQgDgFgEgEQgFgEgHgBQgIgBgJgBIgQABIgOADIAAhLIBXAAIAAARIhEAAIAAAnIAJgBIAHAAQAMAAAJACQAJACAHAFQAIAFAEAJQAFAIgBALQAAALgDAIQgEAKgGAGQgIAHgJAEQgKADgMABQgMgBgMgCgApBAsQgRgOABgaQgBgTAHgRQAFgRAMgOQALgMARgIQAQgHAUgBQANAAALADQALAEAMAGIgFAWIgBAAIgGgGIgKgGQgGgDgHgCQgHgBgKAAQgNgBgMAGQgKAGgJAKQgIAKgFAPQgEAOgBAOQABAUAJALQALALAUAAQAJAAAJgCQAIgCAGgDIAMgHIAJgGIABAAIgFAWQgKAGgNAEQgNAEgQAAQgbAAgPgOgABFA3IAAgUIAVgSIATgRQASgQAHgLQAIgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgLADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAJgBAGQgCAIgFAGQgEAHgFAFIgMALIgWAUIgVASIBPAAIAAAQgAl1AUIAAgPIB0AAIAAAPgAg4AAIAAgOIBeAAIAAAOgAl1gTIAAgQIB0AAIAAAQg");
	this.shape.setTransform(-143,15.5);

	this.text = new cjs.Text("C", "italic 20px Verdana", "#EF542E");
	this.text.lineHeight = 22;
	this.text.setTransform(113.3,25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape},{t:this.text}]},102).wait(58));

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape_1.setTransform(196.7,168.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_2.setTransform(196.6,139.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_3.setTransform(196.5,111.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_4.setTransform(196.5,82.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_5.setTransform(196.6,53.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_6.setTransform(196.6,24.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_7.setTransform(197.6,354.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_8.setTransform(189.9,355);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_9.setTransform(197.6,325.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_10.setTransform(189.9,326.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_11.setTransform(197.4,296.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_12.setTransform(189.9,297.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_13.setTransform(197.5,268.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_14.setTransform(189.9,268.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_15.setTransform(197.6,239.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_16.setTransform(189.9,239.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_17.setTransform(197.7,210.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_18.setTransform(189.9,211);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_19.setTransform(337.9,200);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_20.setTransform(309.2,200.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_21.setTransform(284.5,200);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_22.setTransform(255.9,200);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_23.setTransform(231.4,199.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(207,200);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_25.setTransform(164.1,200);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_26.setTransform(156.3,200.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_27.setTransform(136.1,199.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_28.setTransform(128.4,200.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_29.setTransform(108.2,200);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_30.setTransform(100.5,200.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_31.setTransform(80.2,200);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_32.setTransform(72.6,200.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_33.setTransform(52.4,200.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_34.setTransform(44.7,200.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_35.setTransform(24.5,200);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_36.setTransform(16.8,200.5);

	this.text_1 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(186.2,3.1);

	this.text_2 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(351.9,192.1);

	this.text_3 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(167.5,172.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_37.setTransform(350.7,188.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_38.setTransform(182.4,15.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_39.setTransform(178.6,188.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_40.setTransform(182.6,187.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,29.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,56.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,82.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,110.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,137.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,163.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,212.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,237.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,263.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,290.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,317.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_52.setTransform(183.1,343.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(337.7,183.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(310.7,183.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(284.7,183.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(256.7,183.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(229.7,183.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(203.7,183.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(161.7,183.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(134.7,183.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(108.7,183.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(81.7,183.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(54.7,183.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_64.setTransform(28.7,183.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_65.setTransform(182.9,183.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#EF542E").ss(1,1,1).p("AAbghIgnAAIAAAYIAKgBIAKABQAGACAEADQAFADACADQADAGAAAHQAAAHgCAEQgCAGgEAEQgEAEgHACQgEACgHAAQgHAAgHgBQgHgCgEgCIAAgMIABAAQAHAEAEABQAIACAFAAQACAAAEgBQAEgBADgDQACgDACgDQABgCAAgGQAAgFgCgDQgBgDgDgCQgCgCgFAAQgDAAgFAAQgHAAgDAAIgIAAIAAgrIAyAAg");
	this.shape_66.setTransform(196.6,53.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#EF542E").ss(1,1,1).p("AgBgrQAMAAAHAGQAHAHAAALQAAAFgBAEQgBAEgDAEIgFAFIgfAfIAtAAIAAAKIg5AAIAAgMIAYgVQAJgLAFgFQADgHAAgHQAAgGgEgEQgFgEgGAAQgDAAgIACQgIADgEADIAAAAIAAgMQACgCAIgDQAHgBAHAAg");
	this.shape_67.setTransform(136.1,199.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#EF542E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_68.setTransform(136.1,199.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#EF542E").ss(1,1,1).p("AAcAEIg4AAIAAgHIA4AAg");
	this.shape_69.setTransform(128.4,200.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#EF542E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_70.setTransform(128.4,200.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_66},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},102).wait(58));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-202.5,0,568.8,366.5);


(lib.mc_pant_2 = function() {
	this.initialize();

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.grafica_inici2 = function() {
	this.initialize();

}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.grafica_inici1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text.lineHeight = 17;
	this.text.setTransform(186.2,4);

	this.text_1 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(351.9,193);

	this.text_2 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.addChild(this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.text_2,this.text_1,this.text,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);


(lib.grafica_pant_6 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgoAoQgQgRAAgXQAAgXAQgRQASgQAWgBQAXABASAQQAQARAAAXQAAAXgQARQgSARgXAAQgWAAgSgRg");
	this.shape.setTransform(47.2,-25.4,0.776,0.776,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,1,1).p("AAAF9IAAr5");
	this.shape_1.setTransform(47.4,32.6,1,1.279,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("ADyAAInjAA");
	this.shape_2.setTransform(36.7,-25.4,0.507,1,0,0,180);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(42.7,-29.9,9,9);


(lib.grafica_pant_4 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgoAoQgQgRAAgXQAAgXAQgRQASgQAWgBQAXABASAQQAQARAAAXQAAAXgQARQgSARgXAAQgWAAgSgRg");
	this.shape.setTransform(47.2,4.5,0.776,0.776,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(2,1,1).p("AAAF9IAAr5");
	this.shape_1.setTransform(47.4,43.5,1,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(2,1,1).p("ADyAAInjAA");
	this.shape_2.setTransform(24.2,3.8,1,1,0,0,180);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(42.7,0,9,9);


(lib.btn_solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("SOLUCIÓN", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-14.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape.setTransform(9.3,-3,1.096,1.262);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_1.setTransform(9.3,-3,1.096,1.262);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-59.3,-11.9,118.6,23.8,6);
	this.shape_2.setTransform(9.3,-3,1.096,1.262);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.6,-18.1,130,30);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("PRACTICA", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.setTransform(7.5,-15.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_1.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-50.85,-14.4,101.7,28.8,6);
	this.shape_2.setTransform(9.4,-2.9,1.278,1.043,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.5,-18.1,130.1,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text_1 = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 27;
	this.text_1.setTransform(-6,-16.6,1.247,1.197);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape_2.setTransform(0,5.2,1.247,1.197);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_3.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape_2,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text_1,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape_2,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text_1,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_3,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape_2,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text_1,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape_2,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text_1,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.Animar1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Mapadebits2();
	this.instance.setTransform(-13.9,-55.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-13.9,-55.9,28,112);


(lib.popup_info6 = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("La fibra óptica es un dispositivo que conduce señales luminosas. Los cables de fibra óptica permiten transmitir gran cantidad de información a altas velocidades, lo que los convierte en un elemento indispensable en el avance de las telecomunicaciones.\n\n\n\n\n", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 745;
	this.text.setTransform(99.6,61.7);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRUAqWQgoAAAAglMAAAgq4QAAgkAoAAMBHiAAAQAoAAAAAkMAAAAq4QAAAlgoAAg");
	mask.setTransform(351.1,271);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.popup_info5 = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("El disco duro es un dispositivo en el que se almacena información digital. Puede formar parte de un ordenador o ser externo a él. Para guardar la información utiliza un sistema de grabación magnética. Su capacidad de almacenamiento cada vez es mayor, por lo que ha contribuido a mejorar el campo de la informática.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 745;
	this.text.setTransform(99.6,61.7);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgNoArwQgmAAAAgnMAAAgtKQAAgnAmAAMBD4AAAQAmAAAAAnMAAAAtKQAAAngmAAg");
	mask.setTransform(351.1,280);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.popup_info4 = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("La videocámara es un objeto portátil capaz de grabar imágenes y sonidos. Las primeras cámaras eran muy rudimentarias, pero el desarrollo de las videocámaras ha permitido captar imágenes con mayor nitidez y mejor resolución.\n\n", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 745;
	this.text.setTransform(99.6,61.7);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRUAqWQgoAAAAgiMAAAgnaQAAgiAoAAMBHiAAAQAoAAAAAiMAAAAnaQAAAigoAAg");
	mask.setTransform(351.1,271);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.popup_info3 = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("La pantalla plana ha mejorado el mundo de la imagen al sustituir las antiguas pantallas de tubos de vacío. Este desarrollo ha permitido que la imagen pueda llegar a muchos más lugares.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 745;
	this.text.setTransform(99.6,61.7);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.popup_info2 = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("Los satélites son objetos que orbitan alrededor de la Tierra. Estos objetos han supuesto un gran avance en el campo de las telecomunicaciones al permitir que cualquier persona pueda enviar señales a cualquier parte del mundo. También existen satélites en órbita que cumplen otras funciones no relacionadas con las telecomunicaciones.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 752;
	this.text.setTransform(99.6,61.7);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgWuAujQgsAAAAgvMAAAg3hQAAgvAsAAMBPYAAAQAsAAAAAvMAAAA3hQAAAvgsAAg");
	mask.setTransform(367.1,298);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.popup_info = function() {
	this.initialize();

	// btn_cerrar
	this.btn_salir = new lib.btn_cerrar_1();
	this.btn_salir.setTransform(890.6,54.4,0.853,0.852);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar_1(), 3);

	// mrca_aigua
	this.instance = new lib.gris();
	this.instance.setTransform(50,50,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// text
	this.text = new cjs.Text("El microchip es una pequeña placa con circuitos integrados que realizan funciones determinadas en aparatos electrónicos. El desarrollo de los microchips hizo posible que ordenadores que antes ocupaban grandes salas ahora se puedan llevar en el bolsillo.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 745;
	this.text.setTransform(99.6,61.7);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRUAqVQgoAAAAgnMAAAgu2QAAgoAoAAMBHiAAAQAoAAAAAoMAAAAu2QAAAngoAAg");
	mask.setTransform(351.1,271);

	// fons_blanc
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EBJTAxfIgBAAMiSjAAAIgBAAIgBAAIgNgCQgsgGAAg3MAAAhhBQABg9A6AAMCSjAAAQA6AAABA9MAAABhBQAAA3gsAGIgNACIgBAAg");
	this.shape.setTransform(474.4,316.7);

	this.addChild(this.shape,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.6,0,950,633.6);


(lib.mc_pantalla_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// grafica
	this.instance = new lib.grafica_pant_6("synched",0);
	this.instance.setTransform(183.7,229.9,1,1,180,0,0,25.4,41.3);
	this.instance.alpha = 0;

	this.instance_1 = new lib.Animar1("synched",0);
	this.instance_1.setTransform(171.4,244.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},36).to({state:[]},46).to({state:[{t:this.instance,p:{regX:25.4,regY:41.3,rotation:180,x:183.7,y:229.9}}]},43).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance,p:{regX:37.8,regY:26.3,rotation:-179.9,x:171.3,y:244.9}}]},1).to({state:[{t:this.instance_1}]},1).wait(22));

	// text1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AJZBgIAAgBQAIgHAHgKQAIgKAGgLQAGgNADgOQAEgOAAgQQAAgPgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQASATAJAYQAKAXAAAcQAAAdgKAXQgJAYgSAUgAiqBgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAPQAAAQADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgADMBbIARhAIAYAAIgbBAgAIZA3IAAgoIhGAAIAAgVIBHhSIASAAIAABYIAVAAIAAAPIgVAAIAAAogAHhAAIA4AAIAAhAgAATA3IAAgOIAeAAIAAhgIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACCIAeAAIAAAOgAqTA3IAiiPIApAAIAYABQAIABAGAEQAGAEACAFQADAEAAAHQAAAMgHAKQgHAKgNAFIAAABQAMACAGAIQAGAHAAAKQAAAMgGALQgGALgKAHQgKAGgKADQgKACgPAAgAp8AoIAbAAQANAAAIgCQAIgBAGgEQAIgFAEgHQAEgJAAgIQAAgEgCgDQgCgEgFgDQgEgCgGAAIgRgBIgdAAgAprgdIAZAAIAPgBIALgEQAGgDADgHQADgHAAgFQAAgFgBgDIgEgEQgEgCgHgCIgPAAIgWAAgAmyAUIAAgPIBzAAIAAAPgAFcAAIAAgOIBhAAIAAAOgAh2AAIAAgOIBhAAIAAAOgAmygTIAAgQIBzAAIAAAQg");
	this.shape.setTransform(-137.1,15.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EF542E").s().p("AAcBIIAAgZIAeAAIAAhLIgeAAIAAgYIANgBQAGAAAEgCQAGgDACgEQADgDAAgHIAgAAIAAB3IAfAAIAAAZgAh7AVIAAgYIBvAAIAAAYg");
	this.shape_1.setTransform(-136.6,13.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AJoBgIAAgBQAIgHAHgKQAIgKAGgLQAGgNADgOQAEgOAAgQQAAgPgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQASATAJAYQAKAXAAAcQAAAdgKAXQgJAYgSAUgAi5BgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAPQAAAQADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgADbBbIARhAIAYAAIgbBAgAIoA3IAAgoIhGAAIAAgVIBHhSIASAAIAABYIAVAAIAAAPIgVAAIAAAogAHwAAIA4AAIAAhAgAqiA3IAiiPIApAAIAYABQAIABAGAEQAGAEACAFQADAEAAAHQAAAMgHAKQgHAKgNAFIAAABQAMACAGAIQAGAHAAAKQAAAMgGALQgGALgKAHQgKAGgKADQgKACgPAAgAqLAoIAbAAQANAAAIgCQAIgBAGgEQAIgFAEgHQAEgJAAgIQAAgEgCgDQgCgEgFgDQgEgCgGAAIgRgBIgdAAgAp6gdIAZAAIAPgBIALgEQAGgDADgHQADgHAAgFQAAgFgBgDIgEgEQgEgCgHgCIgPAAIgWAAgAnBAUIAAgPIBzAAIAAAPgAFrAAIAAgOIBhAAIAAAOgAnBgTIAAgQIBzAAIAAAQg");
	this.shape_2.setTransform(-135.6,15.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("ABKBIIAAgiIhGAAIAAgbIBEhSIAmAAIAABTIAUAAIAAAaIgUAAIAAAigAAgAMIAqAAIAAgzgAiBAUIAAgYIBwAAIAAAYg");
	this.shape_3.setTransform(-89.2,13.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AJoBgIAAgBQAIgHAHgKQAIgKAGgLQAGgNADgOQAEgOAAgQQAAgPgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQASATAJAYQAKAXAAAcQAAAdgKAXQgJAYgSAUgAi5BgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAPQAAAQADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgAC9BbIARhAIAYAAIgbBAgAAEA3IAAgOIAeAAIAAhgIgeAAIAAgNIANgBQAHgBAEgCQAEgDADgDQACgEABgHIAPAAIAACCIAeAAIAAAOgAqiA3IAiiPIApAAIAYABQAIABAGAEQAGAEACAFQADAEAAAHQAAAMgHAKQgHAKgNAFIAAABQAMACAGAIQAGAHAAAKQAAAMgGALQgGALgKAHQgKAGgKADQgKACgPAAgAqLAoIAbAAQANAAAIgCQAIgBAGgEQAIgFAEgHQAEgJAAgIQAAgEgCgDQgCgEgFgDQgEgCgGAAIgRgBIgdAAgAp6gdIAZAAIAPgBIALgEQAGgDADgHQADgHAAgFQAAgFgBgDIgEgEQgEgCgHgCIgPAAIgWAAgAnBAUIAAgPIBzAAIAAAPgAiFAAIAAgOIBhAAIAAAOgAnBgTIAAgQIBzAAIAAAQg");
	this.shape_4.setTransform(-135.6,15.5);

	this.text = new cjs.Text("B", "italic 20px Verdana", "#EF542E");
	this.text.lineHeight = 22;
	this.text.setTransform(135,292);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},36).to({state:[{t:this.shape_4},{t:this.shape_3}]},46).to({state:[{t:this.shape}]},43).to({state:[{t:this.shape},{t:this.text}]},33).wait(10));

	// Capa 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape_5.setTransform(196.7,168.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_6.setTransform(196.6,139.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_7.setTransform(196.5,111.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_8.setTransform(196.5,82.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_9.setTransform(196.6,53.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_10.setTransform(196.6,24.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_11.setTransform(197.6,354.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_12.setTransform(189.9,355);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_13.setTransform(197.6,325.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_14.setTransform(189.9,326.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_15.setTransform(197.4,296.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_16.setTransform(189.9,297.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_17.setTransform(197.5,268.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_18.setTransform(189.9,268.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_19.setTransform(197.6,239.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_20.setTransform(189.9,239.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_21.setTransform(197.7,210.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_22.setTransform(189.9,211);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_23.setTransform(337.9,200);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_24.setTransform(309.2,200.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_25.setTransform(284.5,200);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_26.setTransform(255.9,200);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_27.setTransform(231.4,199.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_28.setTransform(207,200);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_29.setTransform(164.1,200);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_30.setTransform(156.3,200.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_31.setTransform(136.1,199.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_32.setTransform(128.4,200.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_33.setTransform(108.2,200);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_34.setTransform(100.5,200.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_35.setTransform(80.2,200);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_36.setTransform(72.6,200.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_37.setTransform(52.4,200.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_38.setTransform(44.7,200.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_39.setTransform(24.5,200);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_40.setTransform(16.8,200.5);

	this.text_1 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(186.2,3.1);

	this.text_2 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(351.9,192.1);

	this.text_3 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(167.5,172.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_41.setTransform(350.7,188.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_42.setTransform(182.4,15.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_43.setTransform(178.6,188.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_44.setTransform(182.6,187.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,29.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,56.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,82.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,110.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,137.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,163.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,212.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_52.setTransform(183.1,237.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_53.setTransform(183.1,263.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_54.setTransform(183.1,290.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_55.setTransform(183.1,317.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_56.setTransform(183.1,343.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(337.7,183.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(310.7,183.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(284.7,183.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(256.7,183.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(229.7,183.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(203.7,183.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(161.7,183.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_64.setTransform(134.7,183.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_65.setTransform(108.7,183.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_66.setTransform(81.7,183.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_67.setTransform(54.7,183.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_68.setTransform(28.7,183.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_69.setTransform(182.9,183.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgcAsIAAgMIAXgVQALgLADgFQAFgGAAgHQAAgHgFgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgMIALgFIAOgBQAMAAAGAHQAIAHAAAKIgBAKIgEAIIgFAFIgfAeIAtAAIAAAKg");
	this.shape_70.setTransform(231.4,199.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#EF542E").ss(1,1,1).p("AAFgqIAABMIASAAIAAAJIgtAAIAAgJIASAAIAAg4IgSAAIAAgIQAFAAADgBIAGgBIAEgEQACgDAAgDg");
	this.shape_71.setTransform(164.1,200);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#EF542E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_72.setTransform(164.1,200);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#EF542E").ss(1,1,1).p("AAdAEIg5AAIAAgHIA5AAg");
	this.shape_73.setTransform(156.3,200.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#EF542E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_74.setTransform(156.3,200.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgQArIgLgDIAAgMIABAAQAHADAEABQAIADAFAAQADAAADgCQADAAAEgDIAEgGIABgIIgBgIQgCgDgCgBIgHgCIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgGQAAgDgCgDIgDgEIgGgCIgEAAQgHAAgFACQgGABgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAHgGAGQgGAGgGABIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAFQgCAFgEADQgEAEgGACQgGACgFAAIgPgCg");
	this.shape_75.setTransform(196.5,111.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#EF542E").ss(1,1,1).p("AAUgqIAAAzIANAAIAAAKIgNAAIAAAYIgLAAIAAgYIgoAAIAAgOIAogvgAAJAJIAAglIggAlg");
	this.shape_76.setTransform(197.4,296.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#EF542E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_77.setTransform(197.4,296.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#EF542E").ss(1,1,1).p("AAdAEIg4AAIAAgHIA4AAg");
	this.shape_78.setTransform(189.9,297.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#EF542E").ss(1,1,1).p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_79.setTransform(156.3,200.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#EF542E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_80.setTransform(156.3,200.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgFQAFgHAAgGQgBgHgEgEQgFgEgFAAIgMACQgIADgEADIgBAAIAAgMIALgFIAOgBQAMAAAHAHQAHAHAAAKQABAFgCAFQgBADgCAFIgGAFIgfAeIAtAAIAAAKg");
	this.shape_81.setTransform(136.1,199.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36,p:{x:72.6}},{t:this.shape_35},{t:this.shape_34,p:{x:100.5}},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{x:156.3}},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22,p:{x:189.9,y:211}},{t:this.shape_21},{t:this.shape_20,p:{y:239.8}},{t:this.shape_19},{t:this.shape_18,p:{y:268.6}},{t:this.shape_17},{t:this.shape_16,p:{y:297.4}},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_36,p:{x:44.7}},{t:this.shape_37},{t:this.shape_34,p:{x:72.6}},{t:this.shape_35},{t:this.shape_30,p:{x:100.5}},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_74,p:{x:156.3,y:200.5}},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_28},{t:this.shape_70},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22,p:{x:189.9,y:211}},{t:this.shape_21},{t:this.shape_20,p:{y:239.8}},{t:this.shape_19},{t:this.shape_18,p:{y:268.6}},{t:this.shape_17},{t:this.shape_16,p:{y:297.4}},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},36).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_34,p:{x:44.7}},{t:this.shape_37},{t:this.shape_30,p:{x:72.6}},{t:this.shape_35},{t:this.shape_22,p:{x:100.5,y:200.5}},{t:this.shape_33},{t:this.shape_32},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_72},{t:this.shape_71},{t:this.shape_28},{t:this.shape_70},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_20,p:{y:211}},{t:this.shape_21},{t:this.shape_18,p:{y:239.8}},{t:this.shape_19},{t:this.shape_16,p:{y:268.6}},{t:this.shape_17},{t:this.shape_74,p:{x:189.9,y:297.4}},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_75},{t:this.shape_6},{t:this.shape_5}]},46).wait(86));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-203.1,0,569.3,366.5);


(lib.mc_pantalla_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// grafica
	this.instance = new lib.grafica_pant_4("synched",0);
	this.instance.setTransform(209.4,147.8,1,1,0,0,0,25.4,41.3);
	this.instance.alpha = 0;

	this.instance_1 = new lib.Mapadebits1();
	this.instance_1.setTransform(183,106.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},36).to({state:[]},46).to({state:[{t:this.instance}]},47).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).wait(45));

	// text1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AGbBgIAAgBQAIgHAHgKQAIgKAGgLQAGgNADgOQAEgOAAgQQAAgPgEgOQgEgOgFgMQgHgMgHgKQgHgKgIgGIAAgBIAWAAQASATAJAYQAKAXAAAcQAAAdgKAXQgJAYgSAUgAgkBgQgRgUgKgYQgJgXAAgdQAAgcAJgXQAKgYARgTIAXAAIAAABQgIAGgHAKQgIAKgGAMQgGAMgDAOQgEAOAAAPQAAAQAEAOQADAOAGANQAGALAIAKQAHAKAIAHIAAABgACNBbIARhAIAYAAIgbBAgAExA3QgLgCgIgDIAAgVIACAAQAIAFALAEQALADALABQAGAAAHgCQAHgCAEgFQAFgEACgFQACgFAAgIQAAgIgDgDQgCgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgHQAJgGAAgMQAAgFgCgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKADgKAGIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAGQAEAHAAAJQAAAMgJAJQgIAKgMABIAAACIALADQAGADAEAEQAFAEADAGQADAFAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgMAAQgMAAgMgEgAAPA3IAAgUIAVgSIATgRQASgQAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAJgCAGQgCAIgEAGQgEAHgFAFIgMALIgWAUIgVASIBOAAIAAAQgAllA3IgFgoIg+AAIgYAoIgVAAIBXiPIAaAAIATCPgAmfAAIAzAAIgJhHgAjlAUIAAgPIBzAAIAAAPgAjlgTIAAgQIBzAAIAAAQg");
	this.shape.setTransform(-157.6,15.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EF542E").s().p("Ag4BJIAAgXIAbgUIAVgTQAKgLAEgHQAGgJAAgIQAAgJgHgGQgFgFgLgBQgJABgKADQgKAEgJAGIgCAAIAAghQAGgCAOgEQANgDAOAAQAZAAAPAMQAOALAAAVQAAAOgHANQgHAKgOANIgSAPIgKAJIA/AAIAAAcg");
	this.shape_1.setTransform(-150.2,13.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AGjBgIAAgBQAHgHAIgKQAHgKAGgLQAGgNAEgOQADgOAAgQQAAgPgDgOQgEgOgGgMQgGgMgHgKQgHgKgIgGIAAgBIAWAAQARATAKAYQAJAXAAAcQAAAdgJAXQgKAYgRAUgAgrBgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAPQAAAQADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgACUBbIARhAIAZAAIgcBAgAE5A3QgMgCgHgDIAAgVIABAAQAIAFAMAEQALADAKABQAGAAAHgCQAHgCAFgFQAEgEACgFQACgFAAgIQAAgIgCgDQgDgFgEgDQgEgDgHgBQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAJgHQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAGQADAHAAAJQAAAMgIAJQgJAKgLABIAAACIAKADQAGADAFAEQAEAEADAGQADAFAAAKQAAAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgAlsA3IgFgoIg/AAIgYAoIgUAAIBWiPIAaAAIATCPgAmnAAIA0AAIgJhHgAjtAUIAAgPIB0AAIAAAPgAjtgTIAAgQIB0AAIAAAQg");
	this.shape_2.setTransform(-156.9,15.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgiBIQgOgCgIgEIAAggIAEAAQAJAFALAEQAMAEAJAAIALgBQAGgBAFgDQADgDADgDQACgEAAgGQAAgHgDgDQgDgEgFgBQgEgCgGAAIgMAAIgIAAIAAgYIAIAAIAOAAQAEgBAEgCQAEgBACgDQACgEABgGQAAgEgDgDQgCgCgDgCQgEgCgFAAIgHgBQgJAAgLADQgLAEgKAGIgDAAIAAggIAVgGQAOgDAOAAQAMAAAKACQAKADAIAEQAHAEAEAHQAEAHAAAJQAAAMgHAKQgIAJgMADIAAABIALADQAFAAAFAEQAEAEADAGQADAFAAAJQAAAKgEAJQgEAJgJAHQgIAGgLADQgLADgOAAQgSAAgMgDg");
	this.shape_3.setTransform(-123.5,13.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AGjBgIAAgBQAHgHAIgKQAHgKAGgLQAGgNAEgOQADgOAAgQQAAgPgDgOQgEgOgGgMQgGgMgHgKQgHgKgIgGIAAgBIAWAAQARATAKAYQAJAXAAAcQAAAdgJAXQgKAYgRAUgAgrBgQgRgUgKgYQgKgXAAgdQAAgcAKgXQAKgYARgTIAWAAIAAABQgIAGgHAKQgHAKgGAMQgGAMgEAOQgDAOAAAPQAAAQADAOQAEAOAGANQAGALAHAKQAIAKAHAHIAAABgACFBbIARhAIAZAAIgcBAgAAHA3IAAgUIAVgSIATgRQATgQAHgLQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAWAAANALQANAKAAATQAAAJgCAGQgCAIgFAGQgDAHgFAFIgNALIgWAUIgUASIBOAAIAAAQgAlsA3IgFgoIg/AAIgYAoIgUAAIBWiPIAaAAIATCPgAmnAAIA0AAIgJhHgAjtAUIAAgPIB0AAIAAAPgAjtgTIAAgQIB0AAIAAAQg");
	this.shape_4.setTransform(-156.9,15.5);

	this.text = new cjs.Text("A", "italic 20px Verdana", "#EF542E");
	this.text.lineHeight = 22;
	this.text.setTransform(232.3,82.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},36).to({state:[{t:this.shape_4},{t:this.shape_3}]},46).to({state:[{t:this.shape}]},47).to({state:[{t:this.shape},{t:this.text}]},22).wait(38));

	// Capa 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape_5.setTransform(196.7,168.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_6.setTransform(196.6,139.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_7.setTransform(196.5,111.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_8.setTransform(196.5,82.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_9.setTransform(196.6,53.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_10.setTransform(196.6,24.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_11.setTransform(197.6,354.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_12.setTransform(189.9,355);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_13.setTransform(197.6,325.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_14.setTransform(189.9,326.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_15.setTransform(197.4,296.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_16.setTransform(189.9,297.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_17.setTransform(197.5,268.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_18.setTransform(189.9,268.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_19.setTransform(197.6,239.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_20.setTransform(189.9,239.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_21.setTransform(197.7,210.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_22.setTransform(189.9,211);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_23.setTransform(337.9,200);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_24.setTransform(309.2,200.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_25.setTransform(284.5,200);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_26.setTransform(255.9,200);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_27.setTransform(231.4,199.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_28.setTransform(207,200);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_29.setTransform(164.1,200);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_30.setTransform(156.3,200.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_31.setTransform(136.1,199.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_32.setTransform(128.4,200.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_33.setTransform(108.2,200);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_34.setTransform(100.5,200.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_35.setTransform(80.2,200);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_36.setTransform(72.6,200.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_37.setTransform(52.4,200.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_38.setTransform(44.7,200.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_39.setTransform(24.5,200);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_40.setTransform(16.8,200.5);

	this.text_1 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(186.2,3.1);

	this.text_2 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(351.9,192.1);

	this.text_3 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(167.5,172.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_41.setTransform(350.7,188.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_42.setTransform(182.4,15.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_43.setTransform(178.6,188.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_44.setTransform(182.6,187.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,29.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,56.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,82.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,110.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,137.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,163.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,212.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_52.setTransform(183.1,237.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_53.setTransform(183.1,263.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_54.setTransform(183.1,290.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_55.setTransform(183.1,317.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_56.setTransform(183.1,343.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(337.7,183.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(310.7,183.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(284.7,183.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(256.7,183.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(229.7,183.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(203.7,183.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(161.7,183.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_64.setTransform(134.7,183.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_65.setTransform(108.7,183.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_66.setTransform(81.7,183.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_67.setTransform(54.7,183.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_68.setTransform(28.7,183.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_69.setTransform(182.9,183.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#EF542E").ss(1,1,1).p("AgBghQgEAAgIACQgIADgEADIgBAAIAAgMIALgEQAIgCAGAAQAMAAAHAHQAHAHAAAKQAAAHgBADIgDAIIgGAFIgfAeIAtAAIAAAKIg5AAIAAgMIAYgVQALgLACgEQAFgHAAgHQAAgHgFgEQgFgEgFAAg");
	this.shape_70.setTransform(231.4,199.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#EF542E").s().p("AgcAsIAAgMIAXgVQALgLADgFQAFgGAAgHQAAgHgFgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgMIALgFIAOgBQAMAAAGAHQAIAHAAAKIgBAKIgEAIIgFAFIgfAeIAtAAIAAAKg");
	this.shape_71.setTransform(231.4,199.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#EF542E").ss(1,1,1).p("AAAgiQgHAAgFADQgGABgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAACIAHACQAEAAACABIAFAHQABAEAAAGQAAAGgCAFQgCAFgEADQgEAFgGABQgGACgFAAQgHAAgIgBIgLgEIAAgMIABAAQAHAEAEABQAIACAFAAQADAAADgBQADgBAEgDIAEgFIABgIQAAgEgBgEQgCgEgCgBQgCgBgFgBQgCgBgEAAIgFAAIAAgIIAEAAQAHAAAFgDQAGgEAAgHQAAgDgCgDIgDgEIgGgCg");
	this.shape_72.setTransform(196.5,111.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#EF542E").s().p("AgQArIgLgDIAAgMIABAAQAHADAEABQAIADAFAAQADAAADgCQADAAAEgDIAEgGIABgIIgBgIQgCgDgCgBIgHgCIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgGQAAgDgCgDIgDgEIgGgCIgEAAQgHAAgFACQgGABgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAHgGAGQgGAGgGABIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAFQgCAFgEADQgEAEgGACQgGACgFAAIgPgCg");
	this.shape_73.setTransform(196.5,111.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#EF542E").ss(1,1,1).p("AAJgdQgFgEgFAAQgEAAgIACQgIADgEADIgBAAIAAgMIALgEQAIgCAGAAQAMAAAHAHQAHAHAAAKQAAAHgBADIgDAIIgGAFIgfAeIAtAAIAAAKIg5AAIAAgMIAYgVQALgLACgEQAFgHAAgHQAAgHgFgEg");
	this.shape_74.setTransform(231.4,199.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_71},{t:this.shape_70},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},36).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_71},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_73},{t:this.shape_72},{t:this.shape_6},{t:this.shape_5}]},46).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_71},{t:this.shape_74},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_73},{t:this.shape_72},{t:this.shape_6},{t:this.shape_5}]},47).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-204.7,0,570.9,366.5);

(lib.mc_pantalla_2d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textes
	this.text = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(-303,2.6);

	this.text_1 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(-303,2.6);

	this.text_2 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(-303,2.6);

	this.text_3 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-303,2.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}}]},41).to({state:[{t:this.text_1,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}},{t:this.text,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}}]},59).to({state:[{t:this.text_2,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}},{t:this.text_1,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}},{t:this.text,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}}]},29).to({state:[{t:this.text_3},{t:this.text_2,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}},{t:this.text_1,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}},{t:this.text,p:{x:-389.4,y:99.5,text:"Cuadrantes",color:"#EF542E",lineWidth:128,textAlign:""}}]},31).wait(9));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EghQAPZIAAhaMBChAAAIAABag");
	var mask_graphics_1 = new cjs.Graphics().p("EghQABtIAAjZMBChAAAIAADZg");
	var mask_graphics_2 = new cjs.Graphics().p("EghQACuIAAlbMBChAAAIAAFbg");
	var mask_graphics_3 = new cjs.Graphics().p("EghQADuIAAnbMBChAAAIAAHbg");
	var mask_graphics_4 = new cjs.Graphics().p("EghQAEvIAApdMBChAAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("EghQAFvIAArdMBChAAAIAALdg");
	var mask_graphics_6 = new cjs.Graphics().p("EghQAGwIAAtfMBChAAAIAANfg");
	var mask_graphics_7 = new cjs.Graphics().p("EghQAHwIAAvfMBChAAAIAAPfg");
	var mask_graphics_8 = new cjs.Graphics().p("EghQAIxIAAxhMBChAAAIAARhg");
	var mask_graphics_9 = new cjs.Graphics().p("EghQAJxIAAzhMBChAAAIAAThg");
	var mask_graphics_10 = new cjs.Graphics().p("EghQAKyIAA1jMBChAAAIAAVjg");
	var mask_graphics_11 = new cjs.Graphics().p("EghQALyIAA3jMBChAAAIAAXjg");
	var mask_graphics_12 = new cjs.Graphics().p("EghQAMzIAA5lMBChAAAIAAZlg");
	var mask_graphics_13 = new cjs.Graphics().p("EghQANzIAA7lMBChAAAIAAblg");
	var mask_graphics_14 = new cjs.Graphics().p("EghQAO0IAA9nMBChAAAIAAdng");
	var mask_graphics_15 = new cjs.Graphics().p("EghQAP0IAA/nMBChAAAIAAfng");
	var mask_graphics_16 = new cjs.Graphics().p("EghQAQ1MAAAghpMBChAAAMAAAAhpg");
	var mask_graphics_17 = new cjs.Graphics().p("EghQAR1MAAAgjpMBChAAAMAAAAjpg");
	var mask_graphics_18 = new cjs.Graphics().p("EghQAS2MAAAglrMBChAAAMAAAAlrg");
	var mask_graphics_19 = new cjs.Graphics().p("EghQAT2MAAAgnrMBChAAAMAAAAnrg");
	var mask_graphics_20 = new cjs.Graphics().p("EghQAU3MAAAgptMBChAAAMAAAAptg");
	var mask_graphics_21 = new cjs.Graphics().p("EghQAV3MAAAgrtMBChAAAMAAAArtg");
	var mask_graphics_22 = new cjs.Graphics().p("EghQAW4MAAAgtvMBChAAAMAAAAtvg");
	var mask_graphics_23 = new cjs.Graphics().p("EghQAX4MAAAgvvMBChAAAMAAAAvvg");
	var mask_graphics_24 = new cjs.Graphics().p("EghQAY5MAAAgxxMBChAAAMAAAAxxg");
	var mask_graphics_25 = new cjs.Graphics().p("EghQAZ5MAAAgzxMBChAAAMAAAAzxg");
	var mask_graphics_26 = new cjs.Graphics().p("EghQAa6MAAAg1zMBChAAAMAAAA1zg");
	var mask_graphics_27 = new cjs.Graphics().p("EghQAb6MAAAg3zMBChAAAMAAAA3zg");
	var mask_graphics_28 = new cjs.Graphics().p("EghQAc7MAAAg51MBChAAAMAAAA51g");
	var mask_graphics_29 = new cjs.Graphics().p("EghQAd7MAAAg71MBChAAAMAAAA71g");
	var mask_graphics_30 = new cjs.Graphics().p("EghQAe8MAAAg93MBChAAAMAAAA93g");
	var mask_graphics_31 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");
	var mask_graphics_41 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:184,y:98.5}).wait(1).to({graphics:mask_graphics_1,x:184,y:192.1}).wait(1).to({graphics:mask_graphics_2,x:184,y:191.6}).wait(1).to({graphics:mask_graphics_3,x:184,y:191.2}).wait(1).to({graphics:mask_graphics_4,x:184,y:190.7}).wait(1).to({graphics:mask_graphics_5,x:184,y:190.3}).wait(1).to({graphics:mask_graphics_6,x:184,y:189.9}).wait(1).to({graphics:mask_graphics_7,x:184,y:189.4}).wait(1).to({graphics:mask_graphics_8,x:184,y:189}).wait(1).to({graphics:mask_graphics_9,x:184,y:188.5}).wait(1).to({graphics:mask_graphics_10,x:184,y:188.1}).wait(1).to({graphics:mask_graphics_11,x:184,y:187.7}).wait(1).to({graphics:mask_graphics_12,x:184,y:187.2}).wait(1).to({graphics:mask_graphics_13,x:184,y:186.8}).wait(1).to({graphics:mask_graphics_14,x:184,y:186.3}).wait(1).to({graphics:mask_graphics_15,x:184,y:185.9}).wait(1).to({graphics:mask_graphics_16,x:184,y:185.5}).wait(1).to({graphics:mask_graphics_17,x:184,y:185}).wait(1).to({graphics:mask_graphics_18,x:184,y:184.6}).wait(1).to({graphics:mask_graphics_19,x:184,y:184.1}).wait(1).to({graphics:mask_graphics_20,x:184,y:183.7}).wait(1).to({graphics:mask_graphics_21,x:184,y:183.3}).wait(1).to({graphics:mask_graphics_22,x:184,y:182.8}).wait(1).to({graphics:mask_graphics_23,x:184,y:182.4}).wait(1).to({graphics:mask_graphics_24,x:184,y:181.9}).wait(1).to({graphics:mask_graphics_25,x:184,y:181.5}).wait(1).to({graphics:mask_graphics_26,x:184,y:181.1}).wait(1).to({graphics:mask_graphics_27,x:184,y:180.6}).wait(1).to({graphics:mask_graphics_28,x:184,y:180.2}).wait(1).to({graphics:mask_graphics_29,x:184,y:179.7}).wait(1).to({graphics:mask_graphics_30,x:184,y:179.3}).wait(1).to({graphics:mask_graphics_31,x:184,y:178.9}).wait(10).to({graphics:mask_graphics_41,x:184,y:178.9}).wait(128));

	// Cuadrantes
	this.text_4 = new cjs.Text("3º", "bold 20px Verdana", "#EF542E");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(95.7,273.4);

	this.text_5 = new cjs.Text("4º", "bold 20px Verdana", "#EF542E");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(283.8,272.9);

	this.text_6 = new cjs.Text("2º", "bold 20px Verdana", "#EF542E");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(94.8,81.3);

	this.text_7 = new cjs.Text("1º", "bold 20px Verdana", "#EF542E");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(282.8,80.8);

	this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},41).to({state:[{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4}]},119).wait(9));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text_8 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(185.3,3.9);

	this.text_9 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(352.1,193.1);

	this.text_10 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.instance = new lib.grafica_inici2("synched",0);
	this.instance.setTransform(182.9,184.1,1,1,0,0,0,182.9,184.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#7E117D").ss(3).p("AakAAMg1HAAA");
	this.shape_65.setTransform(178.6,189.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#7E117D").ss(2).p("AakAAMg1HAAA");
	this.shape_66.setTransform(178.6,189.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#449C76").ss(3).p("AAA6jMAAAA1H");
	this.shape_67.setTransform(182.6,188.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#449C76").ss(2).p("AAA6jMAAAA1H");
	this.shape_68.setTransform(182.6,188.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = this.shape_64.mask = this.instance.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.text_9},{t:this.text_8},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_65},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},41).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_67},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},59).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 16px Verdana",color:"#B30218",lineHeight:19.2,lineWidth:14}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},29).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#B30218",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},31).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);


(lib.mc_pantalla_2c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textes
	this.text = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(-303,2.6);

	this.text_1 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(-303,2.6);

	this.text_2 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(-303,2.6);

	this.text_3 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-303,2.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}}]},41).to({state:[{t:this.text_1,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}},{t:this.text,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}}]},59).to({state:[{t:this.text_2,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}},{t:this.text_1,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}},{t:this.text,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}}]},29).to({state:[{t:this.text_3},{t:this.text_2,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}},{t:this.text_1,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}},{t:this.text,p:{x:-389.4,y:99.5,text:"Cuadrantes",color:"#EF542E",lineWidth:128,textAlign:""}}]},31).wait(9));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EghQAPZIAAhaMBChAAAIAABag");
	var mask_graphics_1 = new cjs.Graphics().p("EghQABtIAAjZMBChAAAIAADZg");
	var mask_graphics_2 = new cjs.Graphics().p("EghQACuIAAlbMBChAAAIAAFbg");
	var mask_graphics_3 = new cjs.Graphics().p("EghQADuIAAnbMBChAAAIAAHbg");
	var mask_graphics_4 = new cjs.Graphics().p("EghQAEvIAApdMBChAAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("EghQAFvIAArdMBChAAAIAALdg");
	var mask_graphics_6 = new cjs.Graphics().p("EghQAGwIAAtfMBChAAAIAANfg");
	var mask_graphics_7 = new cjs.Graphics().p("EghQAHwIAAvfMBChAAAIAAPfg");
	var mask_graphics_8 = new cjs.Graphics().p("EghQAIxIAAxhMBChAAAIAARhg");
	var mask_graphics_9 = new cjs.Graphics().p("EghQAJxIAAzhMBChAAAIAAThg");
	var mask_graphics_10 = new cjs.Graphics().p("EghQAKyIAA1jMBChAAAIAAVjg");
	var mask_graphics_11 = new cjs.Graphics().p("EghQALyIAA3jMBChAAAIAAXjg");
	var mask_graphics_12 = new cjs.Graphics().p("EghQAMzIAA5lMBChAAAIAAZlg");
	var mask_graphics_13 = new cjs.Graphics().p("EghQANzIAA7lMBChAAAIAAblg");
	var mask_graphics_14 = new cjs.Graphics().p("EghQAO0IAA9nMBChAAAIAAdng");
	var mask_graphics_15 = new cjs.Graphics().p("EghQAP0IAA/nMBChAAAIAAfng");
	var mask_graphics_16 = new cjs.Graphics().p("EghQAQ1MAAAghpMBChAAAMAAAAhpg");
	var mask_graphics_17 = new cjs.Graphics().p("EghQAR1MAAAgjpMBChAAAMAAAAjpg");
	var mask_graphics_18 = new cjs.Graphics().p("EghQAS2MAAAglrMBChAAAMAAAAlrg");
	var mask_graphics_19 = new cjs.Graphics().p("EghQAT2MAAAgnrMBChAAAMAAAAnrg");
	var mask_graphics_20 = new cjs.Graphics().p("EghQAU3MAAAgptMBChAAAMAAAAptg");
	var mask_graphics_21 = new cjs.Graphics().p("EghQAV3MAAAgrtMBChAAAMAAAArtg");
	var mask_graphics_22 = new cjs.Graphics().p("EghQAW4MAAAgtvMBChAAAMAAAAtvg");
	var mask_graphics_23 = new cjs.Graphics().p("EghQAX4MAAAgvvMBChAAAMAAAAvvg");
	var mask_graphics_24 = new cjs.Graphics().p("EghQAY5MAAAgxxMBChAAAMAAAAxxg");
	var mask_graphics_25 = new cjs.Graphics().p("EghQAZ5MAAAgzxMBChAAAMAAAAzxg");
	var mask_graphics_26 = new cjs.Graphics().p("EghQAa6MAAAg1zMBChAAAMAAAA1zg");
	var mask_graphics_27 = new cjs.Graphics().p("EghQAb6MAAAg3zMBChAAAMAAAA3zg");
	var mask_graphics_28 = new cjs.Graphics().p("EghQAc7MAAAg51MBChAAAMAAAA51g");
	var mask_graphics_29 = new cjs.Graphics().p("EghQAd7MAAAg71MBChAAAMAAAA71g");
	var mask_graphics_30 = new cjs.Graphics().p("EghQAe8MAAAg93MBChAAAMAAAA93g");
	var mask_graphics_31 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");
	var mask_graphics_41 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:184,y:98.5}).wait(1).to({graphics:mask_graphics_1,x:184,y:192.1}).wait(1).to({graphics:mask_graphics_2,x:184,y:191.6}).wait(1).to({graphics:mask_graphics_3,x:184,y:191.2}).wait(1).to({graphics:mask_graphics_4,x:184,y:190.7}).wait(1).to({graphics:mask_graphics_5,x:184,y:190.3}).wait(1).to({graphics:mask_graphics_6,x:184,y:189.9}).wait(1).to({graphics:mask_graphics_7,x:184,y:189.4}).wait(1).to({graphics:mask_graphics_8,x:184,y:189}).wait(1).to({graphics:mask_graphics_9,x:184,y:188.5}).wait(1).to({graphics:mask_graphics_10,x:184,y:188.1}).wait(1).to({graphics:mask_graphics_11,x:184,y:187.7}).wait(1).to({graphics:mask_graphics_12,x:184,y:187.2}).wait(1).to({graphics:mask_graphics_13,x:184,y:186.8}).wait(1).to({graphics:mask_graphics_14,x:184,y:186.3}).wait(1).to({graphics:mask_graphics_15,x:184,y:185.9}).wait(1).to({graphics:mask_graphics_16,x:184,y:185.5}).wait(1).to({graphics:mask_graphics_17,x:184,y:185}).wait(1).to({graphics:mask_graphics_18,x:184,y:184.6}).wait(1).to({graphics:mask_graphics_19,x:184,y:184.1}).wait(1).to({graphics:mask_graphics_20,x:184,y:183.7}).wait(1).to({graphics:mask_graphics_21,x:184,y:183.3}).wait(1).to({graphics:mask_graphics_22,x:184,y:182.8}).wait(1).to({graphics:mask_graphics_23,x:184,y:182.4}).wait(1).to({graphics:mask_graphics_24,x:184,y:181.9}).wait(1).to({graphics:mask_graphics_25,x:184,y:181.5}).wait(1).to({graphics:mask_graphics_26,x:184,y:181.1}).wait(1).to({graphics:mask_graphics_27,x:184,y:180.6}).wait(1).to({graphics:mask_graphics_28,x:184,y:180.2}).wait(1).to({graphics:mask_graphics_29,x:184,y:179.7}).wait(1).to({graphics:mask_graphics_30,x:184,y:179.3}).wait(1).to({graphics:mask_graphics_31,x:184,y:178.9}).wait(10).to({graphics:mask_graphics_41,x:184,y:178.9}).wait(128));

	// Cuadrantes
	this.text_4 = new cjs.Text("3º", "bold 20px Verdana", "#EF542E");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(95.7,273.4);

	this.text_5 = new cjs.Text("4º", "bold 20px Verdana", "#EF542E");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(283.8,272.9);

	this.text_6 = new cjs.Text("2º", "bold 20px Verdana", "#EF542E");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(94.8,81.3);

	this.text_7 = new cjs.Text("1º", "bold 20px Verdana", "#EF542E");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(282.8,80.8);

	this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},41).to({state:[{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4}]},119).wait(9));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text_8 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(185.3,3.9);

	this.text_9 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(352.1,193.1);

	this.text_10 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.instance = new lib.grafica_inici2("synched",0);
	this.instance.setTransform(182.9,184.1,1,1,0,0,0,182.9,184.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#7E117D").ss(3).p("AakAAMg1HAAA");
	this.shape_65.setTransform(178.6,189.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#7E117D").ss(2).p("AakAAMg1HAAA");
	this.shape_66.setTransform(178.6,189.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#449C76").ss(3).p("AAA6jMAAAA1H");
	this.shape_67.setTransform(182.6,188.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#449C76").ss(2).p("AAA6jMAAAA1H");
	this.shape_68.setTransform(182.6,188.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = this.shape_64.mask = this.instance.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.text_9},{t:this.text_8},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_65},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},41).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_67},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},59).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 16px Verdana",color:"#B30218",lineHeight:19.2,lineWidth:14}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},29).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#B30218",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},31).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);


(lib.mc_pantalla_2b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textes
	this.text = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(-303,2.6);

	this.text_1 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(-303,2.6);

	this.text_2 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(-303,2.6);

	this.text_3 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-303,2.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}}]},41).to({state:[{t:this.text_1,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171,textAlign:"center"}},{t:this.text,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}}]},59).to({state:[{t:this.text_2,p:{x:-303,y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}},{t:this.text_1,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194,textAlign:"center"}},{t:this.text,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}}]},29).to({state:[{t:this.text_3},{t:this.text_2,p:{x:-292.3,y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}},{t:this.text_1,p:{x:-389.4,y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:259,textAlign:""}},{t:this.text,p:{x:-389.4,y:99.5,text:"Cuadrantes",color:"#EF542E",lineWidth:128,textAlign:""}}]},31).wait(9));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EghQAPZIAAhaMBChAAAIAABag");
	var mask_graphics_1 = new cjs.Graphics().p("EghQABtIAAjZMBChAAAIAADZg");
	var mask_graphics_2 = new cjs.Graphics().p("EghQACuIAAlbMBChAAAIAAFbg");
	var mask_graphics_3 = new cjs.Graphics().p("EghQADuIAAnbMBChAAAIAAHbg");
	var mask_graphics_4 = new cjs.Graphics().p("EghQAEvIAApdMBChAAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("EghQAFvIAArdMBChAAAIAALdg");
	var mask_graphics_6 = new cjs.Graphics().p("EghQAGwIAAtfMBChAAAIAANfg");
	var mask_graphics_7 = new cjs.Graphics().p("EghQAHwIAAvfMBChAAAIAAPfg");
	var mask_graphics_8 = new cjs.Graphics().p("EghQAIxIAAxhMBChAAAIAARhg");
	var mask_graphics_9 = new cjs.Graphics().p("EghQAJxIAAzhMBChAAAIAAThg");
	var mask_graphics_10 = new cjs.Graphics().p("EghQAKyIAA1jMBChAAAIAAVjg");
	var mask_graphics_11 = new cjs.Graphics().p("EghQALyIAA3jMBChAAAIAAXjg");
	var mask_graphics_12 = new cjs.Graphics().p("EghQAMzIAA5lMBChAAAIAAZlg");
	var mask_graphics_13 = new cjs.Graphics().p("EghQANzIAA7lMBChAAAIAAblg");
	var mask_graphics_14 = new cjs.Graphics().p("EghQAO0IAA9nMBChAAAIAAdng");
	var mask_graphics_15 = new cjs.Graphics().p("EghQAP0IAA/nMBChAAAIAAfng");
	var mask_graphics_16 = new cjs.Graphics().p("EghQAQ1MAAAghpMBChAAAMAAAAhpg");
	var mask_graphics_17 = new cjs.Graphics().p("EghQAR1MAAAgjpMBChAAAMAAAAjpg");
	var mask_graphics_18 = new cjs.Graphics().p("EghQAS2MAAAglrMBChAAAMAAAAlrg");
	var mask_graphics_19 = new cjs.Graphics().p("EghQAT2MAAAgnrMBChAAAMAAAAnrg");
	var mask_graphics_20 = new cjs.Graphics().p("EghQAU3MAAAgptMBChAAAMAAAAptg");
	var mask_graphics_21 = new cjs.Graphics().p("EghQAV3MAAAgrtMBChAAAMAAAArtg");
	var mask_graphics_22 = new cjs.Graphics().p("EghQAW4MAAAgtvMBChAAAMAAAAtvg");
	var mask_graphics_23 = new cjs.Graphics().p("EghQAX4MAAAgvvMBChAAAMAAAAvvg");
	var mask_graphics_24 = new cjs.Graphics().p("EghQAY5MAAAgxxMBChAAAMAAAAxxg");
	var mask_graphics_25 = new cjs.Graphics().p("EghQAZ5MAAAgzxMBChAAAMAAAAzxg");
	var mask_graphics_26 = new cjs.Graphics().p("EghQAa6MAAAg1zMBChAAAMAAAA1zg");
	var mask_graphics_27 = new cjs.Graphics().p("EghQAb6MAAAg3zMBChAAAMAAAA3zg");
	var mask_graphics_28 = new cjs.Graphics().p("EghQAc7MAAAg51MBChAAAMAAAA51g");
	var mask_graphics_29 = new cjs.Graphics().p("EghQAd7MAAAg71MBChAAAMAAAA71g");
	var mask_graphics_30 = new cjs.Graphics().p("EghQAe8MAAAg93MBChAAAMAAAA93g");
	var mask_graphics_31 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");
	var mask_graphics_41 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:184,y:98.5}).wait(1).to({graphics:mask_graphics_1,x:184,y:192.1}).wait(1).to({graphics:mask_graphics_2,x:184,y:191.6}).wait(1).to({graphics:mask_graphics_3,x:184,y:191.2}).wait(1).to({graphics:mask_graphics_4,x:184,y:190.7}).wait(1).to({graphics:mask_graphics_5,x:184,y:190.3}).wait(1).to({graphics:mask_graphics_6,x:184,y:189.9}).wait(1).to({graphics:mask_graphics_7,x:184,y:189.4}).wait(1).to({graphics:mask_graphics_8,x:184,y:189}).wait(1).to({graphics:mask_graphics_9,x:184,y:188.5}).wait(1).to({graphics:mask_graphics_10,x:184,y:188.1}).wait(1).to({graphics:mask_graphics_11,x:184,y:187.7}).wait(1).to({graphics:mask_graphics_12,x:184,y:187.2}).wait(1).to({graphics:mask_graphics_13,x:184,y:186.8}).wait(1).to({graphics:mask_graphics_14,x:184,y:186.3}).wait(1).to({graphics:mask_graphics_15,x:184,y:185.9}).wait(1).to({graphics:mask_graphics_16,x:184,y:185.5}).wait(1).to({graphics:mask_graphics_17,x:184,y:185}).wait(1).to({graphics:mask_graphics_18,x:184,y:184.6}).wait(1).to({graphics:mask_graphics_19,x:184,y:184.1}).wait(1).to({graphics:mask_graphics_20,x:184,y:183.7}).wait(1).to({graphics:mask_graphics_21,x:184,y:183.3}).wait(1).to({graphics:mask_graphics_22,x:184,y:182.8}).wait(1).to({graphics:mask_graphics_23,x:184,y:182.4}).wait(1).to({graphics:mask_graphics_24,x:184,y:181.9}).wait(1).to({graphics:mask_graphics_25,x:184,y:181.5}).wait(1).to({graphics:mask_graphics_26,x:184,y:181.1}).wait(1).to({graphics:mask_graphics_27,x:184,y:180.6}).wait(1).to({graphics:mask_graphics_28,x:184,y:180.2}).wait(1).to({graphics:mask_graphics_29,x:184,y:179.7}).wait(1).to({graphics:mask_graphics_30,x:184,y:179.3}).wait(1).to({graphics:mask_graphics_31,x:184,y:178.9}).wait(10).to({graphics:mask_graphics_41,x:184,y:178.9}).wait(128));

	// Cuadrantes
	this.text_4 = new cjs.Text("3º", "bold 20px Verdana", "#EF542E");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(95.7,273.4);

	this.text_5 = new cjs.Text("4º", "bold 20px Verdana", "#EF542E");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(283.8,272.9);

	this.text_6 = new cjs.Text("2º", "bold 20px Verdana", "#EF542E");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(94.8,81.3);

	this.text_7 = new cjs.Text("1º", "bold 20px Verdana", "#EF542E");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(282.8,80.8);

	this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},41).to({state:[{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4}]},119).wait(9));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text_8 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(185.3,3.9);

	this.text_9 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(352.1,193.1);

	this.text_10 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.instance = new lib.grafica_inici2("synched",0);
	this.instance.setTransform(182.9,184.1,1,1,0,0,0,182.9,184.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#7E117D").ss(3).p("AakAAMg1HAAA");
	this.shape_65.setTransform(178.6,189.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#7E117D").ss(2).p("AakAAMg1HAAA");
	this.shape_66.setTransform(178.6,189.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#449C76").ss(3).p("AAA6jMAAAA1H");
	this.shape_67.setTransform(182.6,188.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#449C76").ss(2).p("AAA6jMAAAA1H");
	this.shape_68.setTransform(182.6,188.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = this.shape_64.mask = this.instance.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.text_9},{t:this.text_8},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_65},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},41).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_67},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},59).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 16px Verdana",color:"#B30218",lineHeight:19.2,lineWidth:14}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},29).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#B30218",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},31).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);


(lib.mc_pantalla_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// textes
	this.text = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text.lineHeight = 20;
	this.text.setTransform(-363,2.6);

	this.text_1 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(-363,2.6);

	this.text_2 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(-363,2.6);

	this.text_3 = new cjs.Text("Eje de abscisas", "bold 20px Verdana", "#7E117D");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(-363,2.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text,p:{y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}}]},41).to({state:[{t:this.text_1,p:{y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}},{t:this.text,p:{y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}}]},59).to({state:[{t:this.text_2,p:{y:2.6,text:"Eje de abscisas",color:"#7E117D",lineWidth:171}},{t:this.text_1,p:{y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}},{t:this.text,p:{y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:359,textAlign:""}}]},29).to({state:[{t:this.text_3},{t:this.text_2,p:{y:34.6,text:"Eje de ordenadas",color:"#449C76",lineWidth:194}},{t:this.text_1,p:{y:66.2,text:"Origen de coordenadas",color:"#B30218",lineWidth:359,textAlign:""}},{t:this.text,p:{y:99.5,text:"Cuadrantes",color:"#EF542E",lineWidth:128,textAlign:""}}]},31).wait(9));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EghQAPZIAAhaMBChAAAIAABag");
	var mask_graphics_1 = new cjs.Graphics().p("EghQABtIAAjZMBChAAAIAADZg");
	var mask_graphics_2 = new cjs.Graphics().p("EghQACuIAAlbMBChAAAIAAFbg");
	var mask_graphics_3 = new cjs.Graphics().p("EghQADuIAAnbMBChAAAIAAHbg");
	var mask_graphics_4 = new cjs.Graphics().p("EghQAEvIAApdMBChAAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("EghQAFvIAArdMBChAAAIAALdg");
	var mask_graphics_6 = new cjs.Graphics().p("EghQAGwIAAtfMBChAAAIAANfg");
	var mask_graphics_7 = new cjs.Graphics().p("EghQAHwIAAvfMBChAAAIAAPfg");
	var mask_graphics_8 = new cjs.Graphics().p("EghQAIxIAAxhMBChAAAIAARhg");
	var mask_graphics_9 = new cjs.Graphics().p("EghQAJxIAAzhMBChAAAIAAThg");
	var mask_graphics_10 = new cjs.Graphics().p("EghQAKyIAA1jMBChAAAIAAVjg");
	var mask_graphics_11 = new cjs.Graphics().p("EghQALyIAA3jMBChAAAIAAXjg");
	var mask_graphics_12 = new cjs.Graphics().p("EghQAMzIAA5lMBChAAAIAAZlg");
	var mask_graphics_13 = new cjs.Graphics().p("EghQANzIAA7lMBChAAAIAAblg");
	var mask_graphics_14 = new cjs.Graphics().p("EghQAO0IAA9nMBChAAAIAAdng");
	var mask_graphics_15 = new cjs.Graphics().p("EghQAP0IAA/nMBChAAAIAAfng");
	var mask_graphics_16 = new cjs.Graphics().p("EghQAQ1MAAAghpMBChAAAMAAAAhpg");
	var mask_graphics_17 = new cjs.Graphics().p("EghQAR1MAAAgjpMBChAAAMAAAAjpg");
	var mask_graphics_18 = new cjs.Graphics().p("EghQAS2MAAAglrMBChAAAMAAAAlrg");
	var mask_graphics_19 = new cjs.Graphics().p("EghQAT2MAAAgnrMBChAAAMAAAAnrg");
	var mask_graphics_20 = new cjs.Graphics().p("EghQAU3MAAAgptMBChAAAMAAAAptg");
	var mask_graphics_21 = new cjs.Graphics().p("EghQAV3MAAAgrtMBChAAAMAAAArtg");
	var mask_graphics_22 = new cjs.Graphics().p("EghQAW4MAAAgtvMBChAAAMAAAAtvg");
	var mask_graphics_23 = new cjs.Graphics().p("EghQAX4MAAAgvvMBChAAAMAAAAvvg");
	var mask_graphics_24 = new cjs.Graphics().p("EghQAY5MAAAgxxMBChAAAMAAAAxxg");
	var mask_graphics_25 = new cjs.Graphics().p("EghQAZ5MAAAgzxMBChAAAMAAAAzxg");
	var mask_graphics_26 = new cjs.Graphics().p("EghQAa6MAAAg1zMBChAAAMAAAA1zg");
	var mask_graphics_27 = new cjs.Graphics().p("EghQAb6MAAAg3zMBChAAAMAAAA3zg");
	var mask_graphics_28 = new cjs.Graphics().p("EghQAc7MAAAg51MBChAAAMAAAA51g");
	var mask_graphics_29 = new cjs.Graphics().p("EghQAd7MAAAg71MBChAAAMAAAA71g");
	var mask_graphics_30 = new cjs.Graphics().p("EghQAe8MAAAg93MBChAAAMAAAA93g");
	var mask_graphics_31 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");
	var mask_graphics_41 = new cjs.Graphics().p("EghQAf9MAAAg/5MBChAAAMAAAA/5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:184,y:98.5}).wait(1).to({graphics:mask_graphics_1,x:184,y:192.1}).wait(1).to({graphics:mask_graphics_2,x:184,y:191.6}).wait(1).to({graphics:mask_graphics_3,x:184,y:191.2}).wait(1).to({graphics:mask_graphics_4,x:184,y:190.7}).wait(1).to({graphics:mask_graphics_5,x:184,y:190.3}).wait(1).to({graphics:mask_graphics_6,x:184,y:189.9}).wait(1).to({graphics:mask_graphics_7,x:184,y:189.4}).wait(1).to({graphics:mask_graphics_8,x:184,y:189}).wait(1).to({graphics:mask_graphics_9,x:184,y:188.5}).wait(1).to({graphics:mask_graphics_10,x:184,y:188.1}).wait(1).to({graphics:mask_graphics_11,x:184,y:187.7}).wait(1).to({graphics:mask_graphics_12,x:184,y:187.2}).wait(1).to({graphics:mask_graphics_13,x:184,y:186.8}).wait(1).to({graphics:mask_graphics_14,x:184,y:186.3}).wait(1).to({graphics:mask_graphics_15,x:184,y:185.9}).wait(1).to({graphics:mask_graphics_16,x:184,y:185.5}).wait(1).to({graphics:mask_graphics_17,x:184,y:185}).wait(1).to({graphics:mask_graphics_18,x:184,y:184.6}).wait(1).to({graphics:mask_graphics_19,x:184,y:184.1}).wait(1).to({graphics:mask_graphics_20,x:184,y:183.7}).wait(1).to({graphics:mask_graphics_21,x:184,y:183.3}).wait(1).to({graphics:mask_graphics_22,x:184,y:182.8}).wait(1).to({graphics:mask_graphics_23,x:184,y:182.4}).wait(1).to({graphics:mask_graphics_24,x:184,y:181.9}).wait(1).to({graphics:mask_graphics_25,x:184,y:181.5}).wait(1).to({graphics:mask_graphics_26,x:184,y:181.1}).wait(1).to({graphics:mask_graphics_27,x:184,y:180.6}).wait(1).to({graphics:mask_graphics_28,x:184,y:180.2}).wait(1).to({graphics:mask_graphics_29,x:184,y:179.7}).wait(1).to({graphics:mask_graphics_30,x:184,y:179.3}).wait(1).to({graphics:mask_graphics_31,x:184,y:178.9}).wait(10).to({graphics:mask_graphics_41,x:184,y:178.9}).wait(128));

	// Cuadrantes
	this.text_4 = new cjs.Text("3º", "bold 20px Verdana", "#EF542E");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(95.7,273.4);

	this.text_5 = new cjs.Text("4º", "bold 20px Verdana", "#EF542E");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(283.8,272.9);

	this.text_6 = new cjs.Text("2º", "bold 20px Verdana", "#EF542E");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(94.8,81.3);

	this.text_7 = new cjs.Text("1º", "bold 20px Verdana", "#EF542E");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(282.8,80.8);

	this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},41).to({state:[{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4}]},119).wait(9));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text_8 = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(185.3,3.9);

	this.text_9 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(352.1,193.1);

	this.text_10 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.instance = new lib.grafica_inici2("synched",0);
	this.instance.setTransform(182.9,184.1,1,1,0,0,0,182.9,184.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#7E117D").ss(3).p("AakAAMg1HAAA");
	this.shape_65.setTransform(178.6,189.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#7E117D").ss(2).p("AakAAMg1HAAA");
	this.shape_66.setTransform(178.6,189.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#449C76").ss(3).p("AAA6jMAAAA1H");
	this.shape_67.setTransform(182.6,188.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#449C76").ss(2).p("AAA6jMAAAA1H");
	this.shape_68.setTransform(182.6,188.1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.shape_20.mask = this.shape_21.mask = this.shape_22.mask = this.shape_23.mask = this.shape_24.mask = this.shape_25.mask = this.shape_26.mask = this.shape_27.mask = this.shape_28.mask = this.shape_29.mask = this.shape_30.mask = this.shape_31.mask = this.shape_32.mask = this.shape_33.mask = this.shape_34.mask = this.shape_35.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.shape_36.mask = this.shape_37.mask = this.shape_38.mask = this.shape_39.mask = this.shape_40.mask = this.shape_41.mask = this.shape_42.mask = this.shape_43.mask = this.shape_44.mask = this.shape_45.mask = this.shape_46.mask = this.shape_47.mask = this.shape_48.mask = this.shape_49.mask = this.shape_50.mask = this.shape_51.mask = this.shape_52.mask = this.shape_53.mask = this.shape_54.mask = this.shape_55.mask = this.shape_56.mask = this.shape_57.mask = this.shape_58.mask = this.shape_59.mask = this.shape_60.mask = this.shape_61.mask = this.shape_62.mask = this.shape_63.mask = this.shape_64.mask = this.instance.mask = this.shape_65.mask = this.shape_66.mask = this.shape_67.mask = this.shape_68.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.text_9},{t:this.text_8},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_65},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},41).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_67},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#2D2B2E",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},59).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 16px Verdana",color:"#B30218",lineHeight:19.2,lineWidth:14}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},29).to({state:[{t:this.instance},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_68},{t:this.shape_66},{t:this.shape_37},{t:this.shape_36},{t:this.text_10,p:{font:"bold 14px Verdana",color:"#B30218",lineHeight:16.8,lineWidth:12}},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.text_9},{t:this.text_8}]},31).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}