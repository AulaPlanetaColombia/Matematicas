(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
        titulo1(this,txt['titulo']);
this.btn_imatge = new lib.btn_siguiente0();
	this.btn_imatge.setTransform(477.5,338,1,1,0,0,0,252.5,178);
	new cjs.ButtonHelper(this.btn_imatge, 0, 1, 2, false, new lib.btn_siguiente0(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#89623E").s().p("EgngAaeQgUAAAAgUMAAAg0TQAAgUAUAAMBPBAAAQAUAAAAAUMAAAA0TQAAAUgUAAg");
	this.shape.setTransform(476,342.5);

	this.instance = new lib.shutterstock_46394836();
	this.instance.setTransform(201.6,156.1,0.547,0.547);
this.instance.mask=this.shape;
   this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
      this.btn_imatge.on("click", function (evt) {
            putStage(new lib.frame2());
        });
     
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance,this.btn_imatge);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit1'],"23px");
this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AirBgIAAAAQAIgIAHgJQAHgKAHgMQAFgNAEgNQAEgOgBgRQABgOgEgPQgEgOgFgMQgHgMgHgJQgHgKgIgHIAAgBIAWAAQARAUAKAYQAJAWAAAcQAAAdgJAYQgKAYgRATgAlVBgQgRgTgKgYQgJgYAAgdQAAgcAJgWQAKgYARgUIAWAAIAAABQgHAHgHAKQgIAJgGAMQgGAMgDAOQgEAPAAAOQAAARAEAOQADANAGANQAGAMAIAKQAHAJAHAIIAAAAgAD0A4QgMgCgHgEIAAgUIABAAQAIAFALAEQALADALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgHQAAgIgCgEQgDgEgEgEQgFgDgGAAQgGgCgIAAIgIAAIAAgQIAGAAQAPAAAKgGQAJgHAAgMQgBgEgCgFQgCgEgEgCIgJgEIgLgBQgJABgLADQgKADgKAGIgBAAIAAgVIATgGQAMgDALAAQAKAAAIACQAJACAGAFQAHAEAEAHQADAGAAAKQAAALgJAKQgIAJgLACIAAACIAKADQAGADAEADQAFAEADAGQADAFAAAKQAAAKgEAIQgDAJgGAFQgIAIgKADQgKADgLAAQgMAAgMgDgAGeA4IgXgqIgoAqIgXAAIA5g3Igfg0IAUAAIAXApIAogpIAXAAIg3A1IAeA2gAjhA4IgXgqIgoAqIgXAAIA4g3Igeg0IAUAAIAXApIAogpIAXAAIg3A1IAeA2gAnLA4IAVhdIgMAAIAEgOIAMAAIAAgEQAFgTALgKQAMgLATAAIALABIAJABIgFAQIAAAAIgIgCIgIgBQgMABgGAFQgGAGgEANIAAAEIAhAAIgDAOIghAAIgVBdgAAAAVIAAgQIBxAAIAAAQgAAAgTIAAgPIBxAAIAAAPg");
	this.shape.setTransform(135.7,174.5);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.shape );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit2'],"23px");
	this.instance = new lib.mc_pant2();
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit3'],"23px");
	this.instance = new lib.mc_pant3();
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pant4();
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);
this.instance.on("tick", function (evt) {
    
      if (this.parent.instance.currentFrame>65){
          this.parent.instance.stop();
          this.parent.instance.removeAllEventListeners();
      }
      }); 

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pant4("single",85);
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pant4("single",105);
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
    	this.instance = new lib.mc_pant4("single",125);
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
      this.instance = new lib.mc_pant5();
	this.instance.setTransform(135.1,173,1,1,0,0,0,48.1,14);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
(lib.shutterstock_46394836 = function() {
	this.initialize(img.shutterstock_46394836);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,669);


(lib.gris = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.nombres_taula3 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("6", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(80.9,117.6);

	this.text_1 = new cjs.Text("3", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(80.9,78.8);

	this.text_2 = new cjs.Text("0", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(80.9,36.8);

	this.text_3 = new cjs.Text("–3", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(68.3,0);

	this.text_4 = new cjs.Text("2", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(12.6,117.6);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(12.6,78.8);

	this.text_6 = new cjs.Text("0", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(12.6,36.8);

	this.text_7 = new cjs.Text("–1", "20px Verdana");
	this.text_7.lineHeight = 22;

	this.addChild(this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,97.9,145.9);


(lib.nombres_taula2 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("3 ·", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(56.5,116.7);

	this.text_1 = new cjs.Text("3 ·", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(56.5,79.9);

	this.text_2 = new cjs.Text("3 ·", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(56.5,37.9);

	this.text_3 = new cjs.Text("3 ·", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(56.5,1.2);

	this.text_4 = new cjs.Text("2", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(98.7,117.6);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(98.7,78.8);

	this.text_6 = new cjs.Text("0", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(98.7,36.8);

	this.text_7 = new cjs.Text("(–1)", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(86.1,0);

	this.text_8 = new cjs.Text("2", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(12.6,117.6);

	this.text_9 = new cjs.Text("1", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(12.6,78.8);

	this.text_10 = new cjs.Text("0", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(12.6,36.8);

	this.text_11 = new cjs.Text("–1", "20px Verdana");
	this.text_11.lineHeight = 22;

	this.addChild(this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,133.9,145.9);


(lib.mc_loader_barra = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#FFFFFF"],[0.894,1],21.4,17.1,-2.9,-25.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape.setTransform(9,27.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],21.5,16.9,-3.1,-24.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_1.setTransform(9,27.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],21.5,16.7,-3.3,-24.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_2.setTransform(9,27.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],21.6,16.4,-3.4,-24.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_3.setTransform(9,27.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],21.7,16.2,-3.6,-24.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_4.setTransform(9,27.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],21.8,15.9,-3.7,-24.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_5.setTransform(9,27.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],21.9,15.7,-3.9,-24).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_6.setTransform(9,27.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],21.9,15.4,-4.1,-23.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_7.setTransform(9,27.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],22.1,15.2,-4.2,-23.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_8.setTransform(9,27.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],22.1,14.9,-4.4,-23.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_9.setTransform(9,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],22.2,14.7,-4.5,-23.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_10.setTransform(9,27.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],22.3,14.5,-4.7,-23.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_11.setTransform(9,27.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],22.4,14.2,-4.8,-22.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_12.setTransform(9,27.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],22.5,13.9,-5,-22.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_13.setTransform(9,27.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],22.5,13.7,-5.2,-22.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_14.setTransform(9,27.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],22.6,13.5,-5.4,-22.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_15.setTransform(9,27.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],22.7,13.2,-5.5,-22.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_16.setTransform(9,27.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],22.8,12.9,-5.7,-22.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_17.setTransform(9,27.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],22.9,12.7,-5.8,-21.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_18.setTransform(9,27.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],23,12.5,-6,-21.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_19.setTransform(9,27.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],23.1,12.2,-6.1,-21.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_20.setTransform(9,27.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],23.2,11.9,-6.3,-21.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_21.setTransform(9,27.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],23.2,11.7,-6.5,-21.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_22.setTransform(9,27.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],23.3,11.5,-6.6,-21).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_23.setTransform(9,27.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],23.4,11.2,-6.8,-20.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_24.setTransform(9,27.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],23.5,10.9,-6.9,-20.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_25.setTransform(9,27.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],23.6,10.7,-7.1,-20.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_26.setTransform(9,27.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],23.6,10.5,-7.3,-20.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_27.setTransform(9,27.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],23.8,10.2,-7.4,-20.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_28.setTransform(9,27.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],23.8,10,-7.6,-19.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_29.setTransform(9,27.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],23.9,9.7,-7.7,-19.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_30.setTransform(9,27.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],24,9.5,-7.9,-19.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_31.setTransform(9,27.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],24.1,9.2,-8,-19.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_32.setTransform(9,27.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],24.2,9,-8.2,-19.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_33.setTransform(9,27.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],24.2,8.7,-8.4,-19.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_34.setTransform(9,27.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],24.3,8.5,-8.5,-18.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_35.setTransform(9,27.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],24.4,8.3,-8.7,-18.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_36.setTransform(9,27.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],24.5,8,-8.8,-18.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_37.setTransform(9,27.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],24.6,7.7,-9,-18.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_38.setTransform(9,27.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],24.7,7.5,-9.2,-18.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_39.setTransform(9,27.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],24.8,7.3,-9.3,-18).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_40.setTransform(9,27.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],24.8,7,-9.5,-17.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_41.setTransform(9,27.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],24.9,6.7,-9.7,-17.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_42.setTransform(9,27.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],25,6.5,-9.8,-17.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_43.setTransform(9,27.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],25.1,6.3,-9.9,-17.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_44.setTransform(9,27.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],25.2,6,-10.1,-17.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_45.setTransform(9,27.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],25.3,5.8,-10.3,-17).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_46.setTransform(9,27.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],25.3,5.5,-10.5,-16.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_47.setTransform(9,27.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],25.4,5.3,-10.6,-16.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_48.setTransform(9,27.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],25.5,5,-10.8,-16.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_49.setTransform(9,27.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],25.6,4.8,-10.9,-16.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_50.setTransform(9,27.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],25.7,4.5,-11.1,-16.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_51.setTransform(9,27.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],25.8,4.3,-11.2,-15.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_52.setTransform(9,27.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],25.9,4,-11.4,-15.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_53.setTransform(9,27.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],25.9,3.8,-11.6,-15.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_54.setTransform(9,27.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],26,3.5,-11.7,-15.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_55.setTransform(9,27.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],26.1,3.3,-11.9,-15.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_56.setTransform(9,27.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],26.2,3,-12,-15.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_57.setTransform(9,27.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],26.3,2.8,-12.2,-14.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_58.setTransform(9,27.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],26.3,2.6,-12.4,-14.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_59.setTransform(9,27.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],26.5,2.3,-12.5,-14.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_60.setTransform(9,27.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],26.5,2.1,-12.7,-14.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_61.setTransform(9,27.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],26.6,1.8,-12.8,-14.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_62.setTransform(9,27.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],26.7,1.6,-13,-14).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_63.setTransform(9,27.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],26.8,1.3,-13.1,-13.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_64.setTransform(9,27.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],26.9,1.1,-13.3,-13.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_65.setTransform(9,27.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],26.9,0.8,-13.5,-13.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_66.setTransform(9,27.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],27,0.6,-13.7,-13.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_67.setTransform(9,27.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],27.1,0.3,-13.8,-13.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_68.setTransform(9,27.4);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],27.2,0.1,-14,-12.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_69.setTransform(9,27.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],27.3,-0.1,-14.1,-12.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_70.setTransform(9,27.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],27.4,-0.3,-14.3,-12.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_71.setTransform(9,27.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],27.5,-0.5,-14.4,-12.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_72.setTransform(9,27.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],27.6,-0.8,-14.6,-12.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_73.setTransform(9,27.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],27.6,-1.1,-14.8,-12.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_74.setTransform(9,27.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],27.7,-1.3,-14.9,-11.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_75.setTransform(9,27.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],27.8,-1.5,-15.1,-11.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_76.setTransform(9,27.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],27.9,-1.8,-15.2,-11.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_77.setTransform(9,27.4);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],28,-2.1,-15.4,-11.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_78.setTransform(9,27.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],28,-2.3,-15.6,-11.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_79.setTransform(9,27.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],28.2,-2.5,-15.7,-11).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_80.setTransform(9,27.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],28.2,-2.8,-15.9,-10.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_81.setTransform(9,27.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],28.3,-3.1,-16,-10.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_82.setTransform(9,27.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],28.4,-3.3,-16.2,-10.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_83.setTransform(9,27.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],28.5,-3.5,-16.3,-10.3).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_84.setTransform(9,27.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],28.6,-3.8,-16.5,-10.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_85.setTransform(9,27.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],28.6,-4,-16.7,-9.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_86.setTransform(9,27.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],28.7,-4.3,-16.8,-9.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_87.setTransform(9,27.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],28.8,-4.5,-17,-9.6).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_88.setTransform(9,27.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],28.9,-4.8,-17.1,-9.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_89.setTransform(9,27.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],29,-5,-17.3,-9.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_90.setTransform(9,27.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],29.1,-5.3,-17.5,-9.1).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_91.setTransform(9,27.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],29.2,-5.5,-17.6,-8.9).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_92.setTransform(9,27.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],29.2,-5.7,-17.8,-8.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_93.setTransform(9,27.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],29.3,-6,-18,-8.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_94.setTransform(9,27.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],29.4,-6.3,-18.1,-8.4).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_95.setTransform(9,27.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],29.5,-6.5,-18.2,-8.2).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_96.setTransform(9,27.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],29.6,-6.7,-18.4,-8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_97.setTransform(9,27.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],29.7,-7,-18.6,-7.8).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_98.setTransform(9,27.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],29.7,-7.3,-18.8,-7.7).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_99.setTransform(9,27.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#000000","#FFFFFF"],[0,0.592],29.8,-7.5,-18.9,-7.5).s().p("AhwBxQhEhEgBhdQAAhIAqg9IAjAjQgcAtAAA1QAABJA2A2QA1A2BKgBQA1AAAtgcIAjAkQg9AqhIAAQheAAhDhFg");
	this.shape_100.setTransform(9,27.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).wait(101));

	// Capa 2
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["#000000","#FFFFFF"],[0.894,1],-21.2,-17,3.1,25.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_101.setTransform(18.2,18.2);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["#000000","#FFFFFF"],[0.885,0.996],-21.3,-16.8,3.3,25).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_102.setTransform(18.2,18.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["#000000","#FFFFFF"],[0.876,0.992],-21.4,-16.5,3.4,24.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_103.setTransform(18.2,18.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["#000000","#FFFFFF"],[0.867,0.988],-21.4,-16.2,3.6,24.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_104.setTransform(18.2,18.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["#000000","#FFFFFF"],[0.858,0.984],-21.6,-16,3.7,24.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_105.setTransform(18.2,18.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["#000000","#FFFFFF"],[0.849,0.98],-21.6,-15.8,3.9,24.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_106.setTransform(18.2,18.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["#000000","#FFFFFF"],[0.84,0.976],-21.7,-15.5,4.1,24.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_107.setTransform(18.2,18.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["#000000","#FFFFFF"],[0.832,0.971],-21.8,-15.2,4.2,24).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_108.setTransform(18.2,18.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["#000000","#FFFFFF"],[0.823,0.967],-21.9,-15,4.4,23.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_109.setTransform(18.2,18.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["#000000","#FFFFFF"],[0.814,0.963],-22,-14.8,4.5,23.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_110.setTransform(18.2,18.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["#000000","#FFFFFF"],[0.805,0.959],-22,-14.5,4.7,23.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_111.setTransform(18.2,18.2);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#000000","#FFFFFF"],[0.796,0.955],-22.1,-14.3,4.9,23.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_112.setTransform(18.2,18.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#000000","#FFFFFF"],[0.787,0.951],-22.2,-14,5,23.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_113.setTransform(18.2,18.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#000000","#FFFFFF"],[0.778,0.947],-22.3,-13.8,5.2,22.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_114.setTransform(18.2,18.2);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#000000","#FFFFFF"],[0.769,0.943],-22.4,-13.5,5.3,22.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_115.setTransform(18.2,18.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#000000","#FFFFFF"],[0.76,0.939],-22.5,-13.3,5.5,22.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_116.setTransform(18.2,18.2);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["#000000","#FFFFFF"],[0.751,0.935],-22.6,-13,5.6,22.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_117.setTransform(18.2,18.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#000000","#FFFFFF"],[0.742,0.931],-22.7,-12.8,5.8,22.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_118.setTransform(18.2,18.2);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["#000000","#FFFFFF"],[0.733,0.927],-22.7,-12.6,6,22).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_119.setTransform(18.2,18.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["#000000","#FFFFFF"],[0.724,0.923],-22.8,-12.3,6.2,21.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_120.setTransform(18.2,18.2);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["#000000","#FFFFFF"],[0.715,0.918],-22.9,-12,6.3,21.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_121.setTransform(18.2,18.2);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["#000000","#FFFFFF"],[0.706,0.914],-23,-11.8,6.5,21.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_122.setTransform(18.2,18.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["#000000","#FFFFFF"],[0.697,0.91],-23.1,-11.6,6.6,21.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_123.setTransform(18.2,18.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["#000000","#FFFFFF"],[0.688,0.906],-23.1,-11.3,6.8,21.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_124.setTransform(18.2,18.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["#000000","#FFFFFF"],[0.68,0.902],-23.3,-11,6.9,21).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_125.setTransform(18.2,18.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["#000000","#FFFFFF"],[0.671,0.898],-23.3,-10.8,7.1,20.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_126.setTransform(18.2,18.2);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["#000000","#FFFFFF"],[0.662,0.894],-23.4,-10.6,7.3,20.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_127.setTransform(18.2,18.2);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["#000000","#FFFFFF"],[0.653,0.89],-23.5,-10.3,7.4,20.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_128.setTransform(18.2,18.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["#000000","#FFFFFF"],[0.644,0.886],-23.6,-10,7.6,20.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_129.setTransform(18.2,18.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["#000000","#FFFFFF"],[0.635,0.882],-23.7,-9.8,7.7,20.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_130.setTransform(18.2,18.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["#000000","#FFFFFF"],[0.626,0.878],-23.7,-9.6,7.9,19.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_131.setTransform(18.2,18.2);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#000000","#FFFFFF"],[0.617,0.874],-23.8,-9.3,8.1,19.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_132.setTransform(18.2,18.2);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["#000000","#FFFFFF"],[0.608,0.869],-23.9,-9.1,8.2,19.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_133.setTransform(18.2,18.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["#000000","#FFFFFF"],[0.599,0.865],-24,-8.8,8.4,19.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_134.setTransform(18.2,18.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#000000","#FFFFFF"],[0.59,0.861],-24.1,-8.6,8.5,19.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_135.setTransform(18.2,18.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["#000000","#FFFFFF"],[0.581,0.857],-24.1,-8.3,8.7,19.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_136.setTransform(18.2,18.2);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["#000000","#FFFFFF"],[0.572,0.853],-24.3,-8.1,8.8,18.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_137.setTransform(18.2,18.2);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#000000","#FFFFFF"],[0.563,0.849],-24.3,-7.8,9,18.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_138.setTransform(18.2,18.2);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["#000000","#FFFFFF"],[0.554,0.845],-24.4,-7.6,9.2,18.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_139.setTransform(18.2,18.2);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["#000000","#FFFFFF"],[0.545,0.841],-24.5,-7.3,9.4,18.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_140.setTransform(18.2,18.2);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#000000","#FFFFFF"],[0.536,0.837],-24.6,-7.1,9.5,18.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_141.setTransform(18.2,18.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["#000000","#FFFFFF"],[0.528,0.833],-24.7,-6.8,9.6,18).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_142.setTransform(18.2,18.2);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["#000000","#FFFFFF"],[0.519,0.829],-24.8,-6.6,9.8,17.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_143.setTransform(18.2,18.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#000000","#FFFFFF"],[0.51,0.825],-24.8,-6.4,10,17.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_144.setTransform(18.2,18.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["#000000","#FFFFFF"],[0.501,0.821],-24.9,-6.1,10.1,17.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_145.setTransform(18.2,18.2);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["#000000","#FFFFFF"],[0.492,0.816],-25,-5.9,10.3,17.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_146.setTransform(18.2,18.2);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#000000","#FFFFFF"],[0.483,0.812],-25.1,-5.6,10.5,17.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_147.setTransform(18.2,18.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["#000000","#FFFFFF"],[0.474,0.808],-25.2,-5.4,10.6,16.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_148.setTransform(18.2,18.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["#000000","#FFFFFF"],[0.465,0.804],-25.3,-5.1,10.7,16.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_149.setTransform(18.2,18.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#000000","#FFFFFF"],[0.456,0.8],-25.4,-4.9,10.9,16.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_150.setTransform(18.2,18.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["#000000","#FFFFFF"],[0.447,0.796],-25.4,-4.6,11.1,16.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_151.setTransform(18.2,18.2);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#000000","#FFFFFF"],[0.438,0.792],-25.5,-4.4,11.3,16.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_152.setTransform(18.2,18.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["#000000","#FFFFFF"],[0.429,0.788],-25.6,-4.1,11.4,16.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_153.setTransform(18.2,18.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["#000000","#FFFFFF"],[0.42,0.784],-25.7,-3.9,11.6,15.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_154.setTransform(18.2,18.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#000000","#FFFFFF"],[0.411,0.78],-25.8,-3.6,11.7,15.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_155.setTransform(18.2,18.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["#000000","#FFFFFF"],[0.402,0.776],-25.8,-3.4,11.9,15.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_156.setTransform(18.2,18.2);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["#000000","#FFFFFF"],[0.393,0.772],-26,-3.1,12,15.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_157.setTransform(18.2,18.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#000000","#FFFFFF"],[0.384,0.768],-26,-2.9,12.2,15.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_158.setTransform(18.2,18.2);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["#000000","#FFFFFF"],[0.376,0.763],-26.1,-2.7,12.4,15).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_159.setTransform(18.2,18.2);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["#000000","#FFFFFF"],[0.367,0.759],-26.2,-2.4,12.5,14.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_160.setTransform(18.2,18.2);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#000000","#FFFFFF"],[0.358,0.755],-26.3,-2.1,12.7,14.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_161.setTransform(18.2,18.2);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["#000000","#FFFFFF"],[0.349,0.751],-26.4,-1.9,12.8,14.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_162.setTransform(18.2,18.2);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["#000000","#FFFFFF"],[0.34,0.747],-26.4,-1.7,13,14.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_163.setTransform(18.2,18.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["#000000","#FFFFFF"],[0.331,0.743],-26.5,-1.4,13.2,14.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_164.setTransform(18.2,18.2);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["#000000","#FFFFFF"],[0.322,0.739],-26.6,-1.1,13.3,14).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_165.setTransform(18.2,18.2);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#000000","#FFFFFF"],[0.313,0.735],-26.7,-0.9,13.5,13.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_166.setTransform(18.2,18.2);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["#000000","#FFFFFF"],[0.304,0.731],-26.8,-0.7,13.6,13.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_167.setTransform(18.2,18.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["#000000","#FFFFFF"],[0.295,0.727],-26.9,-0.4,13.8,13.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_168.setTransform(18.2,18.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["#000000","#FFFFFF"],[0.286,0.723],-27,-0.2,13.9,13.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_169.setTransform(18.2,18.2);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#000000","#FFFFFF"],[0.277,0.719],-27.1,0,14.1,13.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_170.setTransform(18.2,18.2);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#000000","#FFFFFF"],[0.268,0.715],-27.1,0.2,14.3,12.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_171.setTransform(18.2,18.2);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#000000","#FFFFFF"],[0.259,0.71],-27.2,0.5,14.5,12.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_172.setTransform(18.2,18.2);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["#000000","#FFFFFF"],[0.25,0.706],-27.3,0.7,14.6,12.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_173.setTransform(18.2,18.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["#000000","#FFFFFF"],[0.241,0.702],-27.4,1,14.8,12.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_174.setTransform(18.2,18.2);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["#000000","#FFFFFF"],[0.232,0.698],-27.5,1.2,14.9,12.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_175.setTransform(18.2,18.2);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#000000","#FFFFFF"],[0.224,0.694],-27.5,1.5,15.1,12.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_176.setTransform(18.2,18.2);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["#000000","#FFFFFF"],[0.215,0.69],-27.7,1.7,15.2,11.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_177.setTransform(18.2,18.2);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["#000000","#FFFFFF"],[0.206,0.686],-27.7,2,15.4,11.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_178.setTransform(18.2,18.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["#000000","#FFFFFF"],[0.197,0.682],-27.8,2.2,15.6,11.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_179.setTransform(18.2,18.2);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["#000000","#FFFFFF"],[0.188,0.678],-27.9,2.4,15.7,11.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_180.setTransform(18.2,18.2);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#000000","#FFFFFF"],[0.179,0.674],-28,2.7,15.9,11.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_181.setTransform(18.2,18.2);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#000000","#FFFFFF"],[0.17,0.67],-28.1,3,16,11).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_182.setTransform(18.2,18.2);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#000000","#FFFFFF"],[0.161,0.666],-28.1,3.2,16.2,10.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_183.setTransform(18.2,18.2);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.lf(["#000000","#FFFFFF"],[0.152,0.661],-28.2,3.4,16.4,10.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_184.setTransform(18.2,18.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.lf(["#000000","#FFFFFF"],[0.143,0.657],-28.3,3.7,16.5,10.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_185.setTransform(18.2,18.2);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.lf(["#000000","#FFFFFF"],[0.134,0.653],-28.4,4,16.7,10.3).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_186.setTransform(18.2,18.2);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.lf(["#000000","#FFFFFF"],[0.125,0.649],-28.5,4.2,16.8,10.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_187.setTransform(18.2,18.2);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.lf(["#000000","#FFFFFF"],[0.116,0.645],-28.5,4.4,17,9.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_188.setTransform(18.2,18.2);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.lf(["#000000","#FFFFFF"],[0.107,0.641],-28.7,4.7,17.1,9.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_189.setTransform(18.2,18.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.lf(["#000000","#FFFFFF"],[0.098,0.637],-28.7,5,17.3,9.6).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_190.setTransform(18.2,18.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.lf(["#000000","#FFFFFF"],[0.089,0.633],-28.8,5.2,17.5,9.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_191.setTransform(18.2,18.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.lf(["#000000","#FFFFFF"],[0.08,0.629],-28.9,5.4,17.7,9.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_192.setTransform(18.2,18.2);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.lf(["#000000","#FFFFFF"],[0.072,0.625],-29,5.7,17.8,9.1).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_193.setTransform(18.2,18.2);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.lf(["#000000","#FFFFFF"],[0.063,0.621],-29.1,5.9,17.9,8.9).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_194.setTransform(18.2,18.2);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.lf(["#000000","#FFFFFF"],[0.054,0.617],-29.2,6.2,18.1,8.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_195.setTransform(18.2,18.2);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.lf(["#000000","#FFFFFF"],[0.045,0.613],-29.2,6.4,18.3,8.5).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_196.setTransform(18.2,18.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.lf(["#000000","#FFFFFF"],[0.036,0.608],-29.3,6.7,18.4,8.4).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_197.setTransform(18.2,18.2);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.lf(["#000000","#FFFFFF"],[0.027,0.604],-29.4,6.9,18.6,8.2).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_198.setTransform(18.2,18.2);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.lf(["#000000","#FFFFFF"],[0.018,0.6],-29.5,7.2,18.8,8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_199.setTransform(18.2,18.2);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.lf(["#000000","#FFFFFF"],[0.009,0.596],-29.6,7.4,18.9,7.8).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_200.setTransform(18.2,18.2);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.lf(["#000000","#FFFFFF"],[0,0.592],-29.7,7.7,19,7.7).s().p("ABpCTQAcguAAgzQAAhKg2g2Qg1g2hKAAQg1AAgsAdIgkgkQA8gqBJAAQBdABBFBEQBDBEAABeQAABHgpA8g");
	this.shape_201.setTransform(18.2,18.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_101}]}).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[]},1).wait(100));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,0,45.7,45.6);


(lib.fnd_loader = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhKNAu4MAAAhdvMCUbAAAMAAABdvg");
	this.shape.setTransform(475,304.5,1,1.015);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,609);


(lib.grafica_inici1 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D2B2E").s().p("AgWArIAAgIIASAAIAAg5IgSAAIAAgIIAIAAIAGgCIAEgEIACgGIAHAAIAABNIASAAIAAAIg");
	this.shape.setTransform(196.7,169.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAJgLAEgFQAEgFAAgIQAAgHgEgEQgEgDgHAAIgLABIgMAGIgBAAIAAgNIALgDQAGgCAIAAQALAAAIAGQAHAIAAAKIgBAJQgBAGgDACIgFAGIgfAeIAtAAIAAAKg");
	this.shape_1.setTransform(196.6,140.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2D2B2E").s().p("AgQAsIgLgFIAAgLIABAAQAHADAEABQAIADAFAAQADAAADgBQADgBAEgDIAEgFIABgIIgBgIQgCgEgCgBIgHgDIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAGgDAAgIQAAgDgCgCIgDgEIgGgCIgEAAQgHAAgFABQgGACgGAEIgBAAIAAgNIALgDQAHgCAHAAQAEAAAFACQAEAAAFADQAEADACAEQADAEAAAFQAAAIgGAFQgGAGgGAAIAAABIAHADIAGABIAFAHQABADAAAHQAAAGgCAEQgCAFgEAEQgEAFgGABQgGACgFAAIgPgBg");
	this.shape_2.setTransform(196.5,112);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIAKAAIAAA0IAOAAIAAAJIgOAAIAAAYgAgYAKIAgAAIAAgmg");
	this.shape_3.setTransform(196.5,83.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAIALAFIANACQACAAAEgBQAEgBADgEIAEgGIABgHQAAgFgCgDQgBgDgDgCQgCgCgFAAIgIAAIgKAAIgIAAIAAgrIAyAAIAAAKIgnAAIAAAYIAKgBIAKABQAGABAEADQAFADACADQADAHAAAHQAAAGgCAFQgCAGgEAEQgEADgHADQgEACgHAAIgOgBg");
	this.shape_4.setTransform(196.6,54.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2D2B2E").s().p("AgKArQgGgDgDgDQgEgEgEgJQgCgGAAgNQAAgLACgIQADgJAFgHQAFgGAIgEQAGgEALAAIAGAAIAFABIAAAMIgBAAIgFgCIgGgBQgLAAgIAIQgHAHgBAOIAJgEIAJgCIAKABQAFABAEADQAGAFACACQACAHAAAHQAAANgIAIQgKAJgMAAQgFAAgFgCgAgJAAIgIACIgBACIAAADQAAAIACAHQADAGADACIAFAEIAFABQAJAAAFgFQAEgFAAgKQAAgFgBgEQgCgDgDgDIgGgBIgGAAQgEAAgFABg");
	this.shape_5.setTransform(196.6,25.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgCgGQgCgIAAgMQAAgIACgKQADgIAFgIQAFgGAIgEQAIgEAJAAIALACIAAAKIAAAAIgGgBIgHgBQgJAAgJAIQgIAJAAAMIAJgEQAHgCACAAQAGAAAEABQAEABAFAEQAFADADAEQADAFAAAHQgBAOgIAJQgJAIgNAAQgDAAgGgCgAgJAAIgIACIAAAFQgBAJACAGQABAEAFAEIAFAEIAFABQAJAAAFgFQAEgFAAgKQABgFgCgEQgCgDgEgDQgBAAgEgBIgGAAIgJABg");
	this.shape_6.setTransform(197.6,355.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_7.setTransform(189.9,355.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2D2B2E").s().p("AgPArIgMgEIAAgMIABAAIALAFQAGACAHAAIAGgBIAHgEIADgGQACgEAAgFQAAgEgCgDIgEgFIgHgCIgIAAIgSAAIAAgrIAzAAIAAAKIgoAAIAAAXIAKAAQAEAAAHABQAEABAFADQAFAEADADQACAGAAAHQAAAFgCAGQgDAGgDAEQgEADgGADQgHACgFAAQgIAAgFgBg");
	this.shape_8.setTransform(197.6,326.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_9.setTransform(189.9,327.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgnAAIAAgOIAogvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_10.setTransform(197.4,297.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_11.setTransform(189.9,298.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D2B2E").s().p("AgQArIgLgEIAAgMIABAAQAFADAGACQAGACAHABIAGgCIAHgDIAEgGQABgDAAgEQAAgGgBgCIgEgGIgHgCIgGAAIgFAAIAAgIIAEAAQAHAAAFgEQAFgEAAgHIgBgGIgEgDQgBgCgEAAIgFgBQgGAAgFACIgMAGIgBAAIAAgNIALgDIAOgCIAJABIAJAEQADACADAFQACADAAAGQAAAIgFAEQgFAGgHABIAAABIAHACIAGACQACACACAFQACADAAAGQAAAGgCAFQgBAEgFAFQgEAEgGACQgIACgEAAIgOgCg");
	this.shape_12.setTransform(197.5,269);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_13.setTransform(189.9,269.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2B2E").s().p("AgcAsIAAgNIAYgUQAHgJAGgGQAFgIAAgHQAAgGgFgEQgFgEgFAAQgHAAgFACQgGACgGAEIgBAAIAAgNQAGgCAFgBIAOgCQALAAAIAGQAHAHABALQgBAGgBADQAAAEgEAEIgNAOIgXAWIAtAAIAAAKg");
	this.shape_14.setTransform(197.6,240.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_15.setTransform(189.9,240.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgCQAEgBABgCQABgCAAgEIAIAAIAABMIARAAIAAAJg");
	this.shape_16.setTransform(197.7,211.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_17.setTransform(189.9,211.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#2D2B2E").s().p("AgJArQgHgDgDgDQgFgFgDgIQgCgJAAgKQAAgJACgKQACgHAGgJQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgFgCIgHAAQgKgBgHAIQgIAJgBANIAJgFQAFgBAEgBIAKABQAEABAFAEQAFADACAEQADAFAAAIQAAANgJAJQgJAIgMAAQgDAAgGgCgAgIAAIgJACIAAAFQgBAKACAFQACAGAEACIAFAEQAEACABAAQAJAAAFgGQAEgGAAgJQAAgFgBgEQgCgDgEgDIgFgBIgGAAg");
	this.shape_18.setTransform(337.9,200.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQAEACAHACQAHADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgFgEIgHgCIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAFACADAEQACAFAAAHQAAAIgCAEQgDAGgEAEQgDADgHACQgFADgGAAIgOgCg");
	this.shape_19.setTransform(309.2,201);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#2D2B2E").s().p("AAJArIAAgYIgpAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAgAAIAAglg");
	this.shape_20.setTransform(284.5,200.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIABAAQAEADAHACQAIADAGAAIAFgCIAHgDIAEgGQABgDABgFQgBgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAHAAAFgEQAGgEAAgHQAAgCgCgDQgBgCgDgCIgFgCIgEgBIgNACQgGACgFAEIAAAAIAAgNQADgCAHgBQAHgCAHAAIAJABIAJAEIAHAHIACAJQAAAHgGAFQgEAGgIACIAAAAIAHACIAGACIAFAGQABAFAAAFQAAAHgCAEQgCAGgEADQgFAEgGACQgIACgCAAQgJAAgGgCg");
	this.shape_21.setTransform(255.9,200.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAEgHABgIQgBgGgEgEQgFgEgFAAIgMACQgIACgFAEIAAAAIAAgNIALgDIAOgCQAMAAAGAGQAIAIAAAKIgBAJIgDAIIgGAGIgfAeIAtAAIAAAKg");
	this.shape_22.setTransform(231.4,200.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgCAAgEIAHAAIAABMIASAAIAAAJg");
	this.shape_23.setTransform(207,200.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#2D2B2E").s().p("AgWArIAAgJIASAAIAAg4IgSAAIAAgIIAIgBIAGgBIAEgEQACgDAAgDIAHAAIAABMIASAAIAAAJg");
	this.shape_24.setTransform(164.1,200.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_25.setTransform(156.3,201.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#2D2B2E").s().p("AgcAsIAAgMIAYgVQAKgLADgEQAFgIAAgHQgBgGgEgEQgFgEgGAAIgLACQgIADgEADIgBAAIAAgNIAMgDIANgCQAMAAAHAGQAHAIAAAKQABAFgCAEQAAAEgDAEIgGAGIgfAeIAtAAIAAAKg");
	this.shape_26.setTransform(136.1,200.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#2D2B2E").s().p("AgbAEIAAgHIA3AAIAAAHg");
	this.shape_27.setTransform(128.4,201.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#2D2B2E").s().p("AgQArQgHgBgEgCIAAgNIAAAAQAEADAIACQAIADAFAAIAGgCIAHgDIAEgGQABgDAAgFQAAgEgBgDQgCgEgDgBQgCgDgEABIgGgBIgFAAIAAgIIAEAAQAGAAAGgEQAFgEAAgHQAAgCgBgDQgBgCgDgCIgFgCIgFgBIgMACQgGACgFAEIgBAAIAAgNIALgDQAGgCAIAAIAJABIAJAEIAGAHIACAJQAAAIgFAEQgFAGgHACIAAAAIAGACIAHACIAEAGQACAGAAAEQAAAGgCAFQgCAGgEADQgFAEgGACQgIACgDAAQgIAAgGgCg");
	this.shape_28.setTransform(108.2,200.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_29.setTransform(100.5,201.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#2D2B2E").s().p("AAIArIAAgYIgoAAIAAgOIApgvIALAAIAAAzIAMAAIAAAKIgMAAIAAAYgAgXAJIAfAAIAAglg");
	this.shape_30.setTransform(80.2,200.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_31.setTransform(72.6,201.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#2D2B2E").s().p("AgQAqIgLgDIAAgMIABAAQADACAJACQAGADAGAAQADAAADgCQAEAAADgDIAEgHIABgIIgBgIIgEgEQgFgCgDAAIgIgBIgSABIAAgrIAyAAIAAAKIgmAAIAAAXIAJAAIAKABQAHACADADQAEACADAEQADAFAAAHQAAAIgCAEQgCAGgEAEQgEADgHACQgFADgGAAIgOgCg");
	this.shape_32.setTransform(52.4,201);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA5AAIAAAHg");
	this.shape_33.setTransform(44.7,201.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#2D2B2E").s().p("AgJArIgKgGQgGgHgBgGQgEgIAAgLQAAgJADgKQADgJAFgHQAFgGAIgEQAHgEAKAAIALACIAAALIgBAAIgEgCIgHAAQgLgBgHAIQgJAJAAANIAKgFIAJgCIAJABQAEABAFAEQAFADADAEQADAFgBAIQABANgKAJQgIAIgNAAQgDAAgGgCgAgIAAIgJACIAAAFQAAAKACAFQABAFADADIAGAEQAEACACAAQAIAAAEgGQAGgFAAgKQgBgFgBgEIgGgGIgGgBIgFAAg");
	this.shape_34.setTransform(24.5,200.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#2D2B2E").s().p("AgcAEIAAgHIA4AAIAAAHg");
	this.shape_35.setTransform(16.8,201.4);

	this.text = new cjs.Text("Y", "bold 14px Verdana", "#2D2B2E");
	this.text.lineHeight = 17;
	this.text.setTransform(186.2,4);

	this.text_1 = new cjs.Text("X", "bold 14px Verdana", "#2D2B2E");
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(351.9,193);

	this.text_2 = new cjs.Text("O", "bold 14px Verdana", "#2D2B2E");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(167.5,173.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#2D2B2E").s().p("Agyg3IBlA4IhlA3g");
	this.shape_36.setTransform(350.7,189.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#2D2B2E").s().p("Ag3AzIA4hlIA3Blg");
	this.shape_37.setTransform(182.4,16.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#2D2B2E").ss(2).p("AakAAMg1HAAA");
	this.shape_38.setTransform(178.6,189.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#2D2B2E").ss(2).p("AAA6jMAAAA1H");
	this.shape_39.setTransform(182.6,188.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_40.setTransform(183.1,30.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_41.setTransform(183.1,57.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_42.setTransform(183.1,83.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_43.setTransform(183.1,111.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_44.setTransform(183.1,138.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_45.setTransform(183.1,164.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_46.setTransform(183.1,213.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_47.setTransform(183.1,238.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_48.setTransform(183.1,264.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_49.setTransform(183.1,291.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_50.setTransform(183.1,318.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#6CC3DB").ss(0.5).p("A8lAAMA5LAAA");
	this.shape_51.setTransform(183.1,344.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_52.setTransform(337.7,184.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_53.setTransform(310.7,184.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_54.setTransform(284.7,184.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_55.setTransform(256.7,184.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_56.setTransform(229.7,184.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_57.setTransform(203.7,184.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_58.setTransform(161.7,184.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_59.setTransform(134.7,184.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_60.setTransform(108.7,184.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_61.setTransform(81.7,184.3);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_62.setTransform(54.7,184.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#6CC3DB").ss(0.5).p("AAA8lMAAAA5L");
	this.shape_63.setTransform(28.7,184.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#6CC3DB").ss(2.1).p("Acj8nMg5FAAAMAAAA5PMA5FAAAg");
	this.shape_64.setTransform(182.9,184.1);

	this.addChild(this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.text_2,this.text_1,this.text,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0.9,366.2,366.5);


(lib.btn_siguiente0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("EgndAaUQgUAAAAgUMAAAgz/QAAgUAUAAMBO7AAAQAUAAAAAUMAAAAz/QAAAUgUAAg");
	this.shape.setTransform(251.3,180.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("EgnHAbzQgUAAAAgUMAAAg29QAAgUAUAAMBOPAAAQAUAAAAAUMAAAA29QAAAUgUAAg");
	this.shape_1.setTransform(252.5,178);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.btn_siguiente_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape_2.setTransform(3.6,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_3.setTransform(-6.4,0,0.673,0.673);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_4.setTransform(0,0,0.673,0.673);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_5.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_4,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_5,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_4,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_5,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_4,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_5,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_4,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.mc_pant5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape.setTransform(615,30.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_1.setTransform(590,112.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_2.setTransform(566.9,190.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_3.setTransform(546,268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(39));

	// mascara_ratlla (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("At0BzQgTAAgBgUIAAi9QABgUATAAIbpAAQATAAAAAUIAAC9QAAAUgTAAg");
	var mask_graphics_5 = new cjs.Graphics().p("At0CoQgTAAgBgdIAAkVQABgdATAAIbpAAQATAAAAAdIAAEVQAAAdgTAAg");
	var mask_graphics_6 = new cjs.Graphics().p("At0DeQgTAAgBgnIAAltQABgnATAAIbpAAQATAAAAAnIAAFtQAAAngTAAg");
	var mask_graphics_7 = new cjs.Graphics().p("At0ETQgTAAgBgwIAAnFQABgwATAAIbpAAQATAAAAAwIAAHFQAAAwgTAAg");
	var mask_graphics_8 = new cjs.Graphics().p("At0FIQgTAAgBg5IAAodQABg5ATAAIbpAAQATAAAAA5IAAIdQAAA5gTAAg");
	var mask_graphics_9 = new cjs.Graphics().p("At0F+QgTAAgBhDIAAp1QABhDATAAIbpAAQATAAAABDIAAJ1QAABDgTAAg");
	var mask_graphics_10 = new cjs.Graphics().p("At0GzQgTAAgBhLIAArOQABhMATAAIbpAAQATAAAABMIAALOQAABLgTAAg");
	var mask_graphics_11 = new cjs.Graphics().p("At0HoQgTAAgBhUIAAsnQABhUATAAIbpAAQATAAAABUIAAMnQAABUgTAAg");
	var mask_graphics_12 = new cjs.Graphics().p("At0IeQgTAAgBheIAAt/QABheATAAIbpAAQATAAAABeIAAN/QAABegTAAg");
	var mask_graphics_13 = new cjs.Graphics().p("At0JTQgTAAgBhnIAAvXQABhnATAAIbpAAQATAAAABnIAAPXQAABngTAAg");
	var mask_graphics_14 = new cjs.Graphics().p("At0KJQgTAAgBhxIAAwvQABhxATAAIbpAAQATAAAABxIAAQvQAABxgTAAg");
	var mask_graphics_15 = new cjs.Graphics().p("At0K+QgTAAgBh6IAAyHQABh6ATAAIbpAAQATAAAAB6IAASHQAAB6gTAAg");
	var mask_graphics_16 = new cjs.Graphics().p("At0LzQgTAAgBiDIAAzfQABiDATAAIbpAAQATAAAACDIAATfQAACDgTAAg");
	var mask_graphics_17 = new cjs.Graphics().p("At0MpQgTAAgBiNIAA03QABiNATAAIbpAAQATAAAACNIAAU3QAACNgTAAg");
	var mask_graphics_18 = new cjs.Graphics().p("At0NeQgTAAgBiVIAA2RQABiVATAAIbpAAQATAAAACVIAAWRQAACVgTAAg");
	var mask_graphics_19 = new cjs.Graphics().p("At0OUQgTAAgBifIAA3pQABifATAAIbpAAQATAAAACfIAAXpQAACfgTAAg");
	var mask_graphics_20 = new cjs.Graphics().p("At0PJQgTAAgBioIAA5BQABioATAAIbpAAQATAAAACoIAAZBQAACogTAAg");
	var mask_graphics_21 = new cjs.Graphics().p("At0P+QgTAAgBixIAA6ZQABixATAAIbpAAQATAAAACxIAAaZQAACxgTAAg");
	var mask_graphics_22 = new cjs.Graphics().p("At0Q0QgTAAgBi7IAA7xQABi7ATAAIbpAAQATAAAAC7IAAbxQAAC7gTAAg");
	var mask_graphics_23 = new cjs.Graphics().p("At0RpQgTAAgBjEIAA9JQABjEATAAIbpAAQATAAAADEIAAdJQAADEgTAAg");
	var mask_graphics_24 = new cjs.Graphics().p("At0SfQgTAAgBjOIAA+hQABjOATAAIbpAAQATAAAADOIAAehQAADOgTAAg");
	var mask_graphics_25 = new cjs.Graphics().p("At0TUQgTAAgBjXIAA/5QABjXATAAIbpAAQATAAAADXIAAf5QAADXgTAAg");
	var mask_graphics_26 = new cjs.Graphics().p("At0UJQgTAAgBjfMAAAghSQABjgATAAIbpAAQATAAAADgMAAAAhSQAADfgTAAg");
	var mask_graphics_27 = new cjs.Graphics().p("At0U/QgTAAgBjpMAAAgirQABjpATAAIbpAAQATAAAADpMAAAAirQAADpgTAAg");
	var mask_graphics_28 = new cjs.Graphics().p("At0V0QgTAAgBjyMAAAgkDQABjyATAAIbpAAQATAAAADyMAAAAkDQAADygTAAg");
	var mask_graphics_29 = new cjs.Graphics().p("At0WqQgTAAgBj8MAAAglbQABj8ATAAIbpAAQATAAAAD8MAAAAlbQAAD8gTAAg");
	var mask_graphics_30 = new cjs.Graphics().p("At0XfQgTAAgBkFMAAAgmzQABkFATAAIbpAAQATAAAAEFMAAAAmzQAAEFgTAAg");
	var mask_graphics_31 = new cjs.Graphics().p("At0YUQgTAAgBkOMAAAgoLQABkOATAAIbpAAQATAAAAEOMAAAAoLQAAEOgTAAg");
	var mask_graphics_32 = new cjs.Graphics().p("At0ZKQgTAAgBkYMAAAgpjQABkYATAAIbpAAQATAAAAEYMAAAApjQAAEYgTAAg");
	var mask_graphics_33 = new cjs.Graphics().p("At0Z/QgTAAgBkhMAAAgq7QABkhATAAIbpAAQATAAAAEhMAAAAq7QAAEhgTAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AXKa1QgUAAAAkqMAAAgsVQAAkpAUgBIbqAAQAUABAAEpMAAAAsVQAAEqgUAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:564,y:331.7}).wait(1).to({graphics:mask_graphics_5,x:564,y:326.4}).wait(1).to({graphics:mask_graphics_6,x:564,y:321}).wait(1).to({graphics:mask_graphics_7,x:564,y:315.7}).wait(1).to({graphics:mask_graphics_8,x:564,y:310.4}).wait(1).to({graphics:mask_graphics_9,x:564,y:305}).wait(1).to({graphics:mask_graphics_10,x:564,y:299.7}).wait(1).to({graphics:mask_graphics_11,x:564,y:294.4}).wait(1).to({graphics:mask_graphics_12,x:564,y:289}).wait(1).to({graphics:mask_graphics_13,x:564,y:283.7}).wait(1).to({graphics:mask_graphics_14,x:564,y:278.3}).wait(1).to({graphics:mask_graphics_15,x:564,y:273}).wait(1).to({graphics:mask_graphics_16,x:564,y:267.7}).wait(1).to({graphics:mask_graphics_17,x:564,y:262.3}).wait(1).to({graphics:mask_graphics_18,x:564,y:257}).wait(1).to({graphics:mask_graphics_19,x:564,y:251.6}).wait(1).to({graphics:mask_graphics_20,x:564,y:246.3}).wait(1).to({graphics:mask_graphics_21,x:564,y:241}).wait(1).to({graphics:mask_graphics_22,x:564,y:235.6}).wait(1).to({graphics:mask_graphics_23,x:564,y:230.3}).wait(1).to({graphics:mask_graphics_24,x:564,y:224.9}).wait(1).to({graphics:mask_graphics_25,x:564,y:219.6}).wait(1).to({graphics:mask_graphics_26,x:564,y:214.3}).wait(1).to({graphics:mask_graphics_27,x:564,y:208.9}).wait(1).to({graphics:mask_graphics_28,x:564,y:203.6}).wait(1).to({graphics:mask_graphics_29,x:564,y:198.2}).wait(1).to({graphics:mask_graphics_30,x:564,y:192.9}).wait(1).to({graphics:mask_graphics_31,x:564,y:187.6}).wait(1).to({graphics:mask_graphics_32,x:564,y:182.2}).wait(1).to({graphics:mask_graphics_33,x:564,y:176.9}).wait(1).to({graphics:mask_graphics_34,x:327.3,y:171.6}).wait(5));

	// ratlla
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#660099").ss(2,1,1).p("Am1YBMANrgwB");
	this.shape_4.setTransform(577.4,157.2);

	this.shape_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4}]},4).wait(35));

	// grafica
	this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(568.5,184.9,1,1,0,0,0,182.9,184.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(39));

	// mascara_funcions (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AF9UJQgVAAAAiXIAA2fQAAiYAVAAIQ2AAQAVAAAACYIAAWfQAACXgVAAg");
	mask_1.setTransform(148.1,129);

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(39));

	// mascara (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");
	mask_2.setTransform(107.7,123.3);

	// flechas
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_5.setTransform(188.3,231.1-incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_6.setTransform(176.5,231.1-incremento,0.641,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_7.setTransform(188.3,193.3-incremento);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_8.setTransform(176.5,193.3-incremento,0.641,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_9.setTransform(188.3,150.6-incremento);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_10.setTransform(176.5,150.5-incremento,0.641,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_11.setTransform(188.3,112.8-incremento);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_12.setTransform(176.5,112.7-incremento,0.641,1);

	this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = mask_2;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(39));

	// nombres_2
	this.instance_1 = new lib.nombres_taula3();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(39));

	// nombres
	this.instance_2 = new lib.nombres_taula2();
	this.instance_2.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_2.alpha = 0;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(39));

	// mascara_grafica (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_4.setTransform(66.6,134.1);

	// grafica
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_13.setTransform(69.1,160.5-incremento,1,1.097);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_14.setTransform(69.4,210.8-incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_15.setTransform(70,170-incremento,1.007,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_16.setTransform(70.2,129.5-incremento,1.011,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_17.setTransform(68.6,94-incremento);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_18.setTransform(53.1,160.2-incremento,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.text_4.mask = this.text_5.mask = mask_4;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]}).wait(39));

	// formula
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AirBgIAAgBQAIgGAHgKQAIgKAFgMQAGgNAEgOQAEgNAAgRQAAgOgEgPQgEgOgGgMQgGgMgHgKQgHgJgIgHIAAgBIAWAAQARAUAKAYQAKAXgBAbQABAegKAXQgKAYgRATgAlVBgQgRgTgKgYQgKgXABgeQgBgbAKgXQAKgYARgUIAXAAIAAABQgJAHgGAJQgIAKgGAMQgGAMgEAOQgDAPAAAOQAAARADANQAEAOAGANQAGAMAIAKQAHAKAIAGIAAABgADzA4QgLgDgIgDIAAgVIACAAQAIAGALADQAMAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgDgEQgCgFgEgCQgFgDgGgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAKgGgBgMQABgGgDgDQgCgEgEgDIgJgDIgLgCQgJAAgLAEQgKADgJAGIgBAAIAAgUIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGADAFADQAEAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgNAAgMgDgAGeA4IgWgqIgpAqIgWAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg4A1IAfA2gAjhA4IgXgqIgoAqIgXAAIA5g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAnLA4IAVhcIgMAAIADgPIANAAIABgDQAEgUAMgLQALgKATAAIAKAAIAJACIgDAQIgBAAIgIgBIgIgBQgMAAgGAFQgGAHgDAMIgBAEIAhAAIgEAPIggAAIgWBcgAAAAUIAAgPIByAAIAAAPgAAAgSIAAgQIByAAIAAAQg");
	this.shape_19.setTransform(48.7,16.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19}]}).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,1.7,756.7,366.5);


(lib.mc_pant4d = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape.setTransform(546,268);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(239,84,46,0.2)").s().p("AosBnQgUAAAAgUIAAilQAAgUAUAAIRZAAQAUAAAAAUIAAClQAAAUgUAAg");
	this.shape_1.setTransform(67.8,111.8,1.132,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_2.setTransform(546,268);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_3.setTransform(546,268);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(239,84,46,0.2)").s().p("Ap1BnQgXAAAAgUIAAilQAAgUAXAAITsAAQAWAAAAAUIAAClQAAAUgWAAg");
	this.shape_4.setTransform(67.8,230.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_5.setTransform(546,268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1,p:{y:111.8}},{t:this.shape,p:{x:546,y:268}}]},40).to({state:[{t:this.shape_1,p:{y:149.6}},{t:this.shape_2,p:{x:546,y:268}},{t:this.shape,p:{x:566.9,y:190.7}}]},29).to({state:[{t:this.shape_1,p:{y:191}},{t:this.shape_3,p:{x:546,y:268}},{t:this.shape_2,p:{x:566.9,y:190.7}},{t:this.shape,p:{x:590,y:112.6}}]},22).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape_4},{t:this.shape,p:{x:615,y:30.9}}]},23).wait(25));

	// grafica
	this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(568.5,184.9,1,1,0,0,0,182.9,184.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},19).wait(120));

	// mascara_funcions (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AF9UJQgVAAAAiXIAA2fQAAiYAVAAIQ2AAQAVAAAACYIAAWfQAACXgVAAg");
	mask.setTransform(148.1,129);

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(139));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");
	mask_1.setTransform(107.7,123.3);

	// flechas
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_6.setTransform(188.3,231.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_7.setTransform(176.5,231.1,0.641,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_8.setTransform(188.3,193.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_9.setTransform(176.5,193.3,0.641,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_10.setTransform(188.3,150.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_11.setTransform(176.5,150.5,0.641,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_12.setTransform(188.3,112.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_13.setTransform(176.5,112.7,0.641,1);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(139));

	// nombres_2
	this.instance_1 = new lib.nombres_taula3();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(139));

	// nombres
	this.instance_2 = new lib.nombres_taula2();
	this.instance_2.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_2.alpha = 0;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(139));

	// mascara_grafica (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_3.setTransform(66.6,134.1);

	// grafica
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_14.setTransform(69.1,160.5,1,1.097);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_15.setTransform(69.4,210.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_16.setTransform(70,170,1.007,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_17.setTransform(70.2,129.5,1.011,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_18.setTransform(68.6,94);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_19.setTransform(53.1,160.2,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.text_4.mask = this.text_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(139));

	// formula
	this.text_6 = new cjs.Text("f(x) = 3x", "italic 20px Verdana");
	this.text_6.lineHeight = 22;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_6}]}).wait(139));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,0,756.7,368.1);


(lib.mc_pant4c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape.setTransform(546,268);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(239,84,46,0.2)").s().p("AosBnQgUAAAAgUIAAilQAAgUAUAAIRZAAQAUAAAAAUIAAClQAAAUgUAAg");
	this.shape_1.setTransform(67.8,111.8,1.132,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_2.setTransform(546,268);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_3.setTransform(546,268);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(239,84,46,0.2)").s().p("Ap1BnQgXAAAAgUIAAilQAAgUAXAAITsAAQAWAAAAAUIAAClQAAAUgWAAg");
	this.shape_4.setTransform(67.8,230.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_5.setTransform(546,268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1,p:{y:111.8}},{t:this.shape,p:{x:546,y:268}}]},40).to({state:[{t:this.shape_1,p:{y:149.6}},{t:this.shape_2,p:{x:546,y:268}},{t:this.shape,p:{x:566.9,y:190.7}}]},29).to({state:[{t:this.shape_1,p:{y:191}},{t:this.shape_3,p:{x:546,y:268}},{t:this.shape_2,p:{x:566.9,y:190.7}},{t:this.shape,p:{x:590,y:112.6}}]},22).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape_4},{t:this.shape,p:{x:615,y:30.9}}]},23).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape,p:{x:615,y:30.9}}]},24).wait(1));

	// grafica
	this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(568.5,184.9,1,1,0,0,0,182.9,184.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},19).wait(120));

	// mascara_funcions (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AF9UJQgVAAAAiXIAA2fQAAiYAVAAIQ2AAQAVAAAACYIAAWfQAACXgVAAg");
	mask.setTransform(148.1,129);

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(139));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");
	mask_1.setTransform(107.7,123.3);

	// flechas
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_6.setTransform(188.3,231.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_7.setTransform(176.5,231.1,0.641,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_8.setTransform(188.3,193.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_9.setTransform(176.5,193.3,0.641,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_10.setTransform(188.3,150.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_11.setTransform(176.5,150.5,0.641,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_12.setTransform(188.3,112.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_13.setTransform(176.5,112.7,0.641,1);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(139));

	// nombres_2
	this.instance_1 = new lib.nombres_taula3();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(139));

	// nombres
	this.instance_2 = new lib.nombres_taula2();
	this.instance_2.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_2.alpha = 0;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(139));

	// mascara_grafica (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_3.setTransform(66.6,134.1);

	// grafica
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_14.setTransform(69.1,160.5,1,1.097);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_15.setTransform(69.4,210.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_16.setTransform(70,170,1.007,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_17.setTransform(70.2,129.5,1.011,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_18.setTransform(68.6,94);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_19.setTransform(53.1,160.2,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.text_4.mask = this.text_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(139));

	// formula
	this.text_6 = new cjs.Text("f(x) = 3x", "italic 20px Verdana");
	this.text_6.lineHeight = 22;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_6}]}).wait(139));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,0,756.7,368.1);


(lib.mc_pant4b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape.setTransform(546,268);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(239,84,46,0.2)").s().p("AosBnQgUAAAAgUIAAilQAAgUAUAAIRZAAQAUAAAAAUIAAClQAAAUgUAAg");
	this.shape_1.setTransform(67.8,111.8,1.132,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_2.setTransform(546,268);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_3.setTransform(546,268);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(239,84,46,0.2)").s().p("Ap1BnQgXAAAAgUIAAilQAAgUAXAAITsAAQAWAAAAAUIAAClQAAAUgWAAg");
	this.shape_4.setTransform(67.8,230.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_5.setTransform(546,268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1,p:{y:111.8}},{t:this.shape,p:{x:546,y:268}}]},40).to({state:[{t:this.shape_1,p:{y:149.6}},{t:this.shape_2,p:{x:546,y:268}},{t:this.shape,p:{x:566.9,y:190.7}}]},29).to({state:[{t:this.shape_1,p:{y:191}},{t:this.shape_3,p:{x:546,y:268}},{t:this.shape_2,p:{x:566.9,y:190.7}},{t:this.shape,p:{x:590,y:112.6}}]},22).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape_4},{t:this.shape,p:{x:615,y:30.9}}]},23).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape,p:{x:615,y:30.9}}]},24).wait(1));

	// grafica
	this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(568.5,184.9,1,1,0,0,0,182.9,184.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},19).wait(120));

	// mascara_funcions (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AF9UJQgVAAAAiXIAA2fQAAiYAVAAIQ2AAQAVAAAACYIAAWfQAACXgVAAg");
	mask.setTransform(148.1,129);

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(139));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");
	mask_1.setTransform(107.7,123.3);

	// flechas
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_6.setTransform(188.3,231.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_7.setTransform(176.5,231.1,0.641,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_8.setTransform(188.3,193.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_9.setTransform(176.5,193.3,0.641,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_10.setTransform(188.3,150.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_11.setTransform(176.5,150.5,0.641,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_12.setTransform(188.3,112.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_13.setTransform(176.5,112.7,0.641,1);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(139));

	// nombres_2
	this.instance_1 = new lib.nombres_taula3();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(139));

	// nombres
	this.instance_2 = new lib.nombres_taula2();
	this.instance_2.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_2.alpha = 0;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(139));

	// mascara_grafica (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_3.setTransform(66.6,134.1);

	// grafica
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_14.setTransform(69.1,160.5,1,1.097);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_15.setTransform(69.4,210.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_16.setTransform(70,170,1.007,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_17.setTransform(70.2,129.5,1.011,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_18.setTransform(68.6,94);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_19.setTransform(53.1,160.2,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.text_4.mask = this.text_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(139));

	// formula
	this.text_6 = new cjs.Text("f(x) = 3x", "italic 20px Verdana");
	this.text_6.lineHeight = 22;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_6}]}).wait(139));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,0,756.7,368.1);


(lib.mc_pant4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// punts
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape.setTransform(546,268);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(239,84,46,0.2)").s().p("AosBnQgUAAAAgUIAAilQAAgUAUAAIRZAAQAUAAAAAUIAAClQAAAUgUAAg");
	this.shape_1.setTransform(67.8,111.8-incremento,1.132,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_2.setTransform(546,268);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_3.setTransform(546,268);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(239,84,46,0.2)").s().p("Ap1BnQgXAAAAgUIAAilQAAgUAXAAITsAAQAWAAAAAUIAAClQAAAUgWAAg");
	this.shape_4.setTransform(67.8,230.6-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EF542E").s().p("AgcAcQgMgMAAgQQAAgPAMgNQAMgMAQAAQAQAAANAMQAMANAAAPQAAAQgMAMQgNANgQAAQgQAAgMgNg");
	this.shape_5.setTransform(546,268-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1,p:{y:111.8-incremento}},{t:this.shape,p:{x:546,y:268}}]},40).to({state:[{t:this.shape_1,p:{y:149.6-incremento}},{t:this.shape_2,p:{x:546,y:268}},{t:this.shape,p:{x:566.9,y:190.7}}]},29).to({state:[{t:this.shape_1,p:{y:191-incremento}},{t:this.shape_3,p:{x:546,y:268}},{t:this.shape_2,p:{x:566.9,y:190.7}},{t:this.shape,p:{x:590,y:112.6}}]},22).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape_4},{t:this.shape,p:{x:615,y:30.9}}]},23).to({state:[{t:this.shape_5},{t:this.shape_3,p:{x:566.9,y:190.7}},{t:this.shape_2,p:{x:590,y:112.6}},{t:this.shape,p:{x:615,y:30.9}}]},24).wait(1));

	// grafica
	this.instance = new lib.grafica_inici1("synched",0);
	this.instance.setTransform(568.5,184.9,1,1,0,0,0,182.9,184.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},19).wait(120));

	// mascara_funcions (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AF9UJQgVAAAAiXIAA2fQAAiYAVAAIQ2AAQAVAAAACYIAAWfQAACXgVAAg");
	mask.setTransform(148.1,129);

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(139));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");
	mask_1.setTransform(107.7,123.3);

	// flechas
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_6.setTransform(188.3,231.1-incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_7.setTransform(176.5,231.1-incremento,0.641,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_8.setTransform(188.3,193.3-incremento);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_9.setTransform(176.5,193.3-incremento,0.641,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_10.setTransform(188.3,150.6-incremento);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_11.setTransform(176.5,150.5-incremento,0.641,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_12.setTransform(188.3,112.8-incremento);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_13.setTransform(176.5,112.7-incremento,0.641,1);

	this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(139));

	// nombres_2
	this.instance_1 = new lib.nombres_taula3();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(139));

	// nombres
	this.instance_2 = new lib.nombres_taula2();
	this.instance_2.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_2.alpha = 0;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(139));

	// mascara_grafica (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_3.setTransform(66.6,134.1);

	// grafica
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_14.setTransform(69.1,160.5-incremento,1,1.097);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_15.setTransform(69.4,210.8-incremento);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_16.setTransform(70,170-incremento,1.007,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_17.setTransform(70.2,129.5-incremento,1.011,1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_18.setTransform(68.6,94-incremento);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_19.setTransform(53.1,160.2-incremento,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_14.mask = this.shape_15.mask = this.shape_16.mask = this.shape_17.mask = this.shape_18.mask = this.shape_19.mask = this.text_4.mask = this.text_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(139));

	// formula
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AirBgIAAgBQAIgGAHgKQAIgKAFgMQAGgNAEgOQAEgNAAgRQAAgOgEgPQgEgOgGgMQgGgMgHgKQgHgJgIgHIAAgBIAWAAQARAUAKAYQAKAXgBAbQABAegKAXQgKAYgRATgAlVBgQgRgTgKgYQgKgXABgeQgBgbAKgXQAKgYARgUIAXAAIAAABQgJAHgGAJQgIAKgGAMQgGAMgEAOQgDAPAAAOQAAARADANQAEAOAGANQAGAMAIAKQAHAKAIAGIAAABgADzA4QgLgDgIgDIAAgVIACAAQAIAGALADQAMAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgDgEQgCgFgEgCQgFgDgGgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAKgGgBgMQABgGgDgDQgCgEgEgDIgJgDIgLgCQgJAAgLAEQgKADgJAGIgBAAIAAgUIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGADAFADQAEAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgNAAgMgDgAGeA4IgWgqIgpAqIgWAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg4A1IAfA2gAjhA4IgXgqIgoAqIgXAAIA5g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAnLA4IAVhcIgMAAIADgPIANAAIABgDQAEgUAMgLQALgKATAAIAKAAIAJACIgDAQIgBAAIgIgBIgIgBQgMAAgGAFQgGAHgDAMIgBAEIAhAAIgEAPIggAAIgWBcgAAAAUIAAgPIByAAIAAAPgAAAgSIAAgQIByAAIAAAQg");
	this.shape_20.setTransform(48.7,16.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20}]}).wait(139));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,1.7,756.7,366.5);


(lib.mc_pant3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara_funcions (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_25 = new cjs.Graphics().p("AF9HcQgVAAAAgKIAAhhQAAgKAVAAIQ2AAQAVAAAAAKIAABhQAAAKgVAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AoZBMQgWAAAAgOIAAh8QAAgNAWAAIQzAAQAWAAAAANIAAB8QAAAOgWAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AoZBdQgWAAAAgQIAAiZQAAgQAWAAIQzAAQAWAAAAAQIAACZQAAAQgWAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AoZBvQgWAAAAgUIAAi1QAAgUAWAAIQzAAQAWAAAAAUIAAC1QAAAUgWAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AoZCAQgWAAAAgXIAAjSQAAgWAWAAIQzAAQAWAAAAAWIAADSQAAAXgWAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AoZCRQgWAAAAgZIAAjvQAAgZAWAAIQzAAQAWAAAAAZIAADvQAAAZgWAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AoZCjQgWAAAAgdIAAkMQAAgcAWAAIQzAAQAWAAAAAcIAAEMQAAAdgWAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AoZC0QgWAAAAgfIAAkpQAAgfAWAAIQzAAQAWAAAAAfIAAEpQAAAfgWAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AoZDGQgWAAAAgjIAAlFQAAgjAWAAIQzAAQAWAAAAAjIAAFFQAAAjgWAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AoZDXQgWAAAAgmIAAliQAAglAWAAIQzAAQAWAAAAAlIAAFiQAAAmgWAAg");
	var mask_graphics_35 = new cjs.Graphics().p("AoZDpQgWAAAAgpIAAl/QAAgpAWAAIQzAAQAWAAAAApIAAF/QAAApgWAAg");
	var mask_graphics_36 = new cjs.Graphics().p("AoZD6QgWAAAAgsIAAmcQAAgrAWAAIQzAAQAWAAAAArIAAGcQAAAsgWAAg");
	var mask_graphics_37 = new cjs.Graphics().p("AoZELQgWAAAAguIAAm5QAAguAWAAIQzAAQAWAAAAAuIAAG5QAAAugWAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AoZEdQgWAAAAgyIAAnWQAAgxAWAAIQzAAQAWAAAAAxIAAHWQAAAygWAAg");
	var mask_graphics_39 = new cjs.Graphics().p("AoZEuQgWAAAAg1IAAnyQAAg0AWAAIQzAAQAWAAAAA0IAAHyQAAA1gWAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AoZFAQgWAAAAg4IAAoPQAAg4AWAAIQzAAQAWAAAAA4IAAIPQAAA4gWAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AoZFRQgWAAAAg7IAAosQAAg6AWAAIQzAAQAWAAAAA6IAAIsQAAA7gWAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AoZFjQgWAAAAg+IAApJQAAg+AWAAIQzAAQAWAAAAA+IAAJJQAAA+gWAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AoZF0QgWAAAAhBIAApmQAAhAAWAAIQzAAQAWAAAABAIAAJmQAABBgWAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AoZGGQgWAAAAhFIAAqCQAAhEAWAAIQzAAQAWAAAABEIAAKCQAABFgWAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AoZGXQgWAAAAhHIAAqfQAAhHAWAAIQzAAQAWAAAABHIAAKfQAABHgWAAg");
	var mask_graphics_46 = new cjs.Graphics().p("AoZGoQgWAAAAhKIAAq8QAAhJAWAAIQzAAQAWAAAABJIAAK8QAABKgWAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AoZG6QgWAAAAhNIAArZQAAhNAWAAIQzAAQAWAAAABNIAALZQAABNgWAAg");
	var mask_graphics_48 = new cjs.Graphics().p("AoZHLQgWAAAAhQIAAr2QAAhPAWAAIQzAAQAWAAAABPIAAL2QAABQgWAAg");
	var mask_graphics_49 = new cjs.Graphics().p("AoZHdQgWAAAAhUIAAsSQAAhTAWAAIQzAAQAWAAAABTIAAMSQAABUgWAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AoZHuQgWAAAAhWIAAsvQAAhWAWAAIQzAAQAWAAAABWIAAMvQAABWgWAAg");
	var mask_graphics_51 = new cjs.Graphics().p("AoZIAQgWAAAAhaIAAtMQAAhZAWAAIQzAAQAWAAAABZIAANMQAABagWAAg");
	var mask_graphics_52 = new cjs.Graphics().p("AoZIRQgWAAAAhcIAAtpQAAhcAWAAIQzAAQAWAAAABcIAANpQAABcgWAAg");
	var mask_graphics_53 = new cjs.Graphics().p("AoZIiQgWAAAAhfIAAuGQAAheAWAAIQzAAQAWAAAABeIAAOGQAABfgWAAg");
	var mask_graphics_54 = new cjs.Graphics().p("AoZI0QgWAAAAhjIAAuiQAAhiAWAAIQzAAQAWAAAABiIAAOiQAABjgWAAg");
	var mask_graphics_55 = new cjs.Graphics().p("AoZJFQgWAAAAhlIAAu/QAAhlAWAAIQzAAQAWAAAABlIAAO/QAABlgWAAg");
	var mask_graphics_56 = new cjs.Graphics().p("AoZJXQgWAAAAhpIAAvcQAAhoAWAAIQzAAQAWAAAABoIAAPcQAABpgWAAg");
	var mask_graphics_57 = new cjs.Graphics().p("AoZJoQgWAAAAhrIAAv5QAAhrAWAAIQzAAQAWAAAABrIAAP5QAABrgWAAg");
	var mask_graphics_58 = new cjs.Graphics().p("AoZJ6QgWAAAAhvIAAwWQAAhuAWAAIQzAAQAWAAAABuIAAQWQAABvgWAAg");
	var mask_graphics_59 = new cjs.Graphics().p("AoZKLQgWAAAAhxIAAwzQAAhxAWAAIQzAAQAWAAAABxIAAQzQAABxgWAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AoZKcQgWAAAAh0IAAxPQAAh0AWAAIQzAAQAWAAAAB0IAARPQAAB0gWAAg");
	var mask_graphics_61 = new cjs.Graphics().p("AoZKuQgWAAAAh4IAAxsQAAh3AWAAIQzAAQAWAAAAB3IAARsQAAB4gWAAg");
	var mask_graphics_62 = new cjs.Graphics().p("AoZK/QgWAAAAh6IAAyJQAAh6AWAAIQzAAQAWAAAAB6IAASJQAAB6gWAAg");
	var mask_graphics_63 = new cjs.Graphics().p("AoZLRQgWAAAAh+IAAymQAAh9AWAAIQzAAQAWAAAAB9IAASmQAAB+gWAAg");
	var mask_graphics_64 = new cjs.Graphics().p("AoZLiQgWAAAAiAIAAzDQAAiAAWAAIQzAAQAWAAAACAIAATDQAACAgWAAg");
	var mask_graphics_65 = new cjs.Graphics().p("AoZL0QgWAAAAiEIAAzfQAAiEAWAAIQzAAQAWAAAACEIAATfQAACEgWAAg");
	var mask_graphics_66 = new cjs.Graphics().p("AoZMFQgWAAAAiHIAAz8QAAiGAWAAIQzAAQAWAAAACGIAAT8QAACHgWAAg");
	var mask_graphics_67 = new cjs.Graphics().p("AoZMXQgWAAAAiKIAA0ZQAAiKAWAAIQzAAQAWAAAACKIAAUZQAACKgWAAg");
	var mask_graphics_68 = new cjs.Graphics().p("AoZMoQgWAAAAiNIAA02QAAiMAWAAIQzAAQAWAAAACMIAAU2QAACNgWAAg");
	var mask_graphics_69 = new cjs.Graphics().p("AoZM5QgWAAAAiPIAA1TQAAiPAWAAIQzAAQAWAAAACPIAAVTQAACPgWAAg");
	var mask_graphics_70 = new cjs.Graphics().p("AoZNLQgWAAAAiTIAA1vQAAiTAWAAIQzAAQAWAAAACTIAAVvQAACTgWAAg");
	var mask_graphics_71 = new cjs.Graphics().p("AoZNcQgWAAAAiWIAA2MQAAiVAWAAIQzAAQAWAAAACVIAAWMQAACWgWAAg");
	var mask_graphics_72 = new cjs.Graphics().p("AoZNuQgWAAAAiZIAA2pQAAiZAWAAIQzAAQAWAAAACZIAAWpQAACZgWAAg");
	var mask_graphics_73 = new cjs.Graphics().p("AoZN/QgWAAAAicIAA3GQAAibAWAAIQzAAQAWAAAACbIAAXGQAACcgWAAg");
	var mask_graphics_74 = new cjs.Graphics().p("AoZORQgWAAAAifIAA3jQAAifAWAAIQzAAQAWAAAACfIAAXjQAACfgWAAg");
	var mask_graphics_75 = new cjs.Graphics().p("AF9VCQgVAAAAiiIAA3/QAAiiAVAAIQ2AAQAVAAAACiIAAX/QAACigVAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(25).to({graphics:mask_graphics_25,x:148.1,y:47.7}).wait(1).to({graphics:mask_graphics_26,x:240.1,y:91.3}).wait(1).to({graphics:mask_graphics_27,x:240.1,y:93}).wait(1).to({graphics:mask_graphics_28,x:240.1,y:94.7}).wait(1).to({graphics:mask_graphics_29,x:240.1,y:96.5}).wait(1).to({graphics:mask_graphics_30,x:240.1,y:98.2}).wait(1).to({graphics:mask_graphics_31,x:240.1,y:99.9}).wait(1).to({graphics:mask_graphics_32,x:240.1,y:101.7}).wait(1).to({graphics:mask_graphics_33,x:240.1,y:103.4}).wait(1).to({graphics:mask_graphics_34,x:240.1,y:105.1}).wait(1).to({graphics:mask_graphics_35,x:240.1,y:106.9}).wait(1).to({graphics:mask_graphics_36,x:240.1,y:108.6}).wait(1).to({graphics:mask_graphics_37,x:240.1,y:110.4}).wait(1).to({graphics:mask_graphics_38,x:240.1,y:112.1}).wait(1).to({graphics:mask_graphics_39,x:240.1,y:113.8}).wait(1).to({graphics:mask_graphics_40,x:240.1,y:115.6}).wait(1).to({graphics:mask_graphics_41,x:240.1,y:117.3}).wait(1).to({graphics:mask_graphics_42,x:240.1,y:119}).wait(1).to({graphics:mask_graphics_43,x:240.1,y:120.8}).wait(1).to({graphics:mask_graphics_44,x:240.1,y:122.5}).wait(1).to({graphics:mask_graphics_45,x:240.1,y:124.2}).wait(1).to({graphics:mask_graphics_46,x:240.1,y:126}).wait(1).to({graphics:mask_graphics_47,x:240.1,y:127.7}).wait(1).to({graphics:mask_graphics_48,x:240.1,y:129.4}).wait(1).to({graphics:mask_graphics_49,x:240.1,y:131.2}).wait(1).to({graphics:mask_graphics_50,x:240.1,y:132.9}).wait(1).to({graphics:mask_graphics_51,x:240.1,y:134.6}).wait(1).to({graphics:mask_graphics_52,x:240.1,y:136.4}).wait(1).to({graphics:mask_graphics_53,x:240.1,y:138.1}).wait(1).to({graphics:mask_graphics_54,x:240.1,y:139.9}).wait(1).to({graphics:mask_graphics_55,x:240.1,y:141.6}).wait(1).to({graphics:mask_graphics_56,x:240.1,y:143.3}).wait(1).to({graphics:mask_graphics_57,x:240.1,y:145.1}).wait(1).to({graphics:mask_graphics_58,x:240.1,y:146.8}).wait(1).to({graphics:mask_graphics_59,x:240.1,y:148.5}).wait(1).to({graphics:mask_graphics_60,x:240.1,y:150.3}).wait(1).to({graphics:mask_graphics_61,x:240.1,y:152}).wait(1).to({graphics:mask_graphics_62,x:240.1,y:153.7}).wait(1).to({graphics:mask_graphics_63,x:240.1,y:155.5}).wait(1).to({graphics:mask_graphics_64,x:240.1,y:157.2}).wait(1).to({graphics:mask_graphics_65,x:240.1,y:158.9}).wait(1).to({graphics:mask_graphics_66,x:240.1,y:160.7}).wait(1).to({graphics:mask_graphics_67,x:240.1,y:162.4}).wait(1).to({graphics:mask_graphics_68,x:240.1,y:164.2}).wait(1).to({graphics:mask_graphics_69,x:240.1,y:165.9}).wait(1).to({graphics:mask_graphics_70,x:240.1,y:167.6}).wait(1).to({graphics:mask_graphics_71,x:240.1,y:169.4}).wait(1).to({graphics:mask_graphics_72,x:240.1,y:171.1}).wait(1).to({graphics:mask_graphics_73,x:240.1,y:172.8}).wait(1).to({graphics:mask_graphics_74,x:240.1,y:174.6}).wait(1).to({graphics:mask_graphics_75,x:148.1,y:134.7}).wait(11));

	// funcions
	this.text = new cjs.Text("(2, 6)", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(201.9,214.7);

	this.text_1 = new cjs.Text("(1, 3)", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(201.9,176.5);

	this.text_2 = new cjs.Text("(0, 0)", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(201.9,134.6);

	this.text_3 = new cjs.Text("(–1, –3)", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(201.9,95.5);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},18).to({state:[{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},7).wait(61));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_18 = new cjs.Graphics().p("AG2H8QgcAAAAgKIAAhTQAAgJAcAAIJiAAQAdAAAAAJIAABTQAAAKgdAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AkvBCQgdAAAAgNIAAhpQAAgNAdAAIJfAAQAdAAAAANIAABpQAAANgdAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AkvBQQgdAAAAgPIAAiBQAAgPAdAAIJfAAQAdAAAAAPIAACBQAAAPgdAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AkvBfQgdAAAAgSIAAiZQAAgSAdAAIJfAAQAdAAAAASIAACZQAAASgdAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AkvBuQgdAAAAgVIAAixQAAgVAdAAIJfAAQAdAAAAAVIAACxQAAAVgdAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AkvB9QgdAAAAgYIAAjJQAAgYAdAAIJfAAQAdAAAAAYIAADJQAAAYgdAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AkvCLQgdAAAAgaIAAjhQAAgaAdAAIJfAAQAdAAAAAaIAADhQAAAagdAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AkvCaQgdAAAAgdIAAj5QAAgdAdAAIJfAAQAdAAAAAdIAAD5QAAAdgdAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AkvCpQgdAAAAggIAAkRQAAggAdAAIJfAAQAdAAAAAgIAAERQAAAggdAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AkvC4QgdAAAAgjIAAkpQAAgjAdAAIJfAAQAdAAAAAjIAAEpQAAAjgdAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AkvDHQgdAAAAgmIAAlBQAAgmAdAAIJfAAQAdAAAAAmIAAFBQAAAmgdAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AkvDVQgdAAAAgoIAAlZQAAgoAdAAIJfAAQAdAAAAAoIAAFZQAAAogdAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AkvDkQgdAAAAgrIAAlxQAAgrAdAAIJfAAQAdAAAAArIAAFxQAAArgdAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AkvDzQgdAAAAguIAAmJQAAguAdAAIJfAAQAdAAAAAuIAAGJQAAAugdAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AkvECQgdAAAAgxIAAmhQAAgxAdAAIJfAAQAdAAAAAxIAAGhQAAAxgdAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AkvEQQgdAAAAgzIAAm5QAAgzAdAAIJfAAQAdAAAAAzIAAG5QAAAzgdAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AkvEfQgdAAAAg2IAAnRQAAg2AdAAIJfAAQAdAAAAA2IAAHRQAAA2gdAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AkvEuQgdAAAAg5IAAnpQAAg5AdAAIJfAAQAdAAAAA5IAAHpQAAA5gdAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AkvE9QgdAAAAg8IAAoBQAAg8AdAAIJfAAQAdAAAAA8IAAIBQAAA8gdAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AkvFMQgdAAAAg/IAAoZQAAg/AdAAIJfAAQAdAAAAA/IAAIZQAAA/gdAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AkvFaQgdAAAAhBIAAoxQAAhBAdAAIJfAAQAdAAAABBIAAIxQAABBgdAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AkvFpQgdAAAAhEIAApJQAAhEAdAAIJfAAQAdAAAABEIAAJJQAABEgdAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AkvF4QgdAAAAhHIAAphQAAhHAdAAIJfAAQAdAAAABHIAAJhQAABHgdAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AkvGHQgdAAAAhKIAAp5QAAhKAdAAIJfAAQAdAAAABKIAAJ5QAABKgdAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AkvGVQgdAAAAhMIAAqRQAAhMAdAAIJfAAQAdAAAABMIAAKRQAABMgdAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkvGkQgdAAAAhPIAAqpQAAhPAdAAIJfAAQAdAAAABPIAAKpQAABPgdAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AkvGzQgdAAAAhSIAArBQAAhSAdAAIJfAAQAdAAAABSIAALBQAABSgdAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AkvHCQgdAAAAhVIAArZQAAhVAdAAIJfAAQAdAAAABVIAALZQAABVgdAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AkvHRQgdAAAAhYIAArxQAAhYAdAAIJfAAQAdAAAABYIAALxQAABYgdAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AkvHfQgdAAAAhaIAAsJQAAhaAdAAIJfAAQAdAAAABaIAAMJQAABagdAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AkvHuQgdAAAAhdIAAshQAAhdAdAAIJfAAQAdAAAABdIAAMhQAABdgdAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AkvH9QgdAAAAhgIAAs5QAAhgAdAAIJfAAQAdAAAABgIAAM5QAABggdAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AkvIMQgdAAAAhjIAAtRQAAhjAdAAIJfAAQAdAAAABjIAANRQAABjgdAAg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AkvIbQgdAAAAhmIAAtpQAAhmAdAAIJfAAQAdAAAABmIAANpQAABmgdAAg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AkvIpQgdAAAAhoIAAuBQAAhoAdAAIJfAAQAdAAAABoIAAOBQAABogdAAg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AkvI4QgdAAAAhrIAAuZQAAhrAdAAIJfAAQAdAAAABrIAAOZQAABrgdAAg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AkvJHQgdAAAAhuIAAuxQAAhuAdAAIJfAAQAdAAAABuIAAOxQAABugdAAg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AkvJWQgdAAAAhxIAAvJQAAhxAdAAIJfAAQAdAAAABxIAAPJQAABxgdAAg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AkvJkQgdAAAAhzIAAvhQAAhzAdAAIJfAAQAdAAAABzIAAPhQAABzgdAAg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AkvJzQgdAAAAh2IAAv5QAAh2AdAAIJfAAQAdAAAAB2IAAP5QAAB2gdAAg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AkvKCQgdAAAAh5IAAwRQAAh5AdAAIJfAAQAdAAAAB5IAAQRQAAB5gdAAg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AkvKRQgdAAAAh8IAAwpQAAh8AdAAIJfAAQAdAAAAB8IAAQpQAAB8gdAAg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AkvKgQgdAAAAh/IAAxBQAAh/AdAAIJfAAQAdAAAAB/IAARBQAAB/gdAAg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AkvKuQgdAAAAiBIAAxZQAAiBAdAAIJfAAQAdAAAACBIAARZQAACBgdAAg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AkvK9QgdAAAAiEIAAxxQAAiEAdAAIJfAAQAdAAAACEIAARxQAACEgdAAg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AkvLMQgdAAAAiHIAAyJQAAiHAdAAIJfAAQAdAAAACHIAASJQAACHgdAAg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AkvLbQgdAAAAiKIAAyhQAAiKAdAAIJfAAQAdAAAACKIAAShQAACKgdAAg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AkvLpQgdAAAAiMIAAy5QAAiMAdAAIJfAAQAdAAAACMIAAS5QAACMgdAAg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AkvL4QgdAAAAiPIAAzRQAAiPAdAAIJfAAQAdAAAACPIAATRQAACPgdAAg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AG2TRQgcAAAAiTIAAzoQAAiTAcAAIJiAAQAdAAAACTIAAToQAACTgdAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(18).to({graphics:mask_1_graphics_18,x:107.7,y:50.8}).wait(1).to({graphics:mask_1_graphics_19,x:182.1,y:98.1}).wait(1).to({graphics:mask_1_graphics_20,x:182.1,y:99.5}).wait(1).to({graphics:mask_1_graphics_21,x:182.1,y:101}).wait(1).to({graphics:mask_1_graphics_22,x:182.1,y:102.5}).wait(1).to({graphics:mask_1_graphics_23,x:182.1,y:104}).wait(1).to({graphics:mask_1_graphics_24,x:182.1,y:105.4}).wait(1).to({graphics:mask_1_graphics_25,x:182.1,y:106.9}).wait(1).to({graphics:mask_1_graphics_26,x:182.1,y:108.4}).wait(1).to({graphics:mask_1_graphics_27,x:182.1,y:109.9}).wait(1).to({graphics:mask_1_graphics_28,x:182.1,y:111.4}).wait(1).to({graphics:mask_1_graphics_29,x:182.1,y:112.8}).wait(1).to({graphics:mask_1_graphics_30,x:182.1,y:114.3}).wait(1).to({graphics:mask_1_graphics_31,x:182.1,y:115.8}).wait(1).to({graphics:mask_1_graphics_32,x:182.1,y:117.3}).wait(1).to({graphics:mask_1_graphics_33,x:182.1,y:118.8}).wait(1).to({graphics:mask_1_graphics_34,x:182.1,y:120.2}).wait(1).to({graphics:mask_1_graphics_35,x:182.1,y:121.7}).wait(1).to({graphics:mask_1_graphics_36,x:182.1,y:123.2}).wait(1).to({graphics:mask_1_graphics_37,x:182.1,y:124.7}).wait(1).to({graphics:mask_1_graphics_38,x:182.1,y:126.2}).wait(1).to({graphics:mask_1_graphics_39,x:182.1,y:127.6}).wait(1).to({graphics:mask_1_graphics_40,x:182.1,y:129.1}).wait(1).to({graphics:mask_1_graphics_41,x:182.1,y:130.6}).wait(1).to({graphics:mask_1_graphics_42,x:182.1,y:132.1}).wait(1).to({graphics:mask_1_graphics_43,x:182.1,y:133.6}).wait(1).to({graphics:mask_1_graphics_44,x:182.1,y:135}).wait(1).to({graphics:mask_1_graphics_45,x:182.1,y:136.5}).wait(1).to({graphics:mask_1_graphics_46,x:182.1,y:138}).wait(1).to({graphics:mask_1_graphics_47,x:182.1,y:139.5}).wait(1).to({graphics:mask_1_graphics_48,x:182.1,y:140.9}).wait(1).to({graphics:mask_1_graphics_49,x:182.1,y:142.4}).wait(1).to({graphics:mask_1_graphics_50,x:182.1,y:143.9}).wait(1).to({graphics:mask_1_graphics_51,x:182.1,y:145.4}).wait(1).to({graphics:mask_1_graphics_52,x:182.1,y:146.9}).wait(1).to({graphics:mask_1_graphics_53,x:182.1,y:148.3}).wait(1).to({graphics:mask_1_graphics_54,x:182.1,y:149.8}).wait(1).to({graphics:mask_1_graphics_55,x:182.1,y:151.3}).wait(1).to({graphics:mask_1_graphics_56,x:182.1,y:152.8}).wait(1).to({graphics:mask_1_graphics_57,x:182.1,y:154.3}).wait(1).to({graphics:mask_1_graphics_58,x:182.1,y:155.7}).wait(1).to({graphics:mask_1_graphics_59,x:182.1,y:157.2}).wait(1).to({graphics:mask_1_graphics_60,x:182.1,y:158.7}).wait(1).to({graphics:mask_1_graphics_61,x:182.1,y:160.2}).wait(1).to({graphics:mask_1_graphics_62,x:182.1,y:161.7}).wait(1).to({graphics:mask_1_graphics_63,x:182.1,y:163.1}).wait(1).to({graphics:mask_1_graphics_64,x:182.1,y:164.6}).wait(1).to({graphics:mask_1_graphics_65,x:182.1,y:166.1}).wait(1).to({graphics:mask_1_graphics_66,x:182.1,y:167.6}).wait(1).to({graphics:mask_1_graphics_67,x:107.7,y:123.3}).wait(19));

	// flechas
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape.setTransform(188.3,231.1-incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_1.setTransform(176.5,231.1-incremento,0.641,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_2.setTransform(188.3,193.3-incremento);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_3.setTransform(176.5,193.3-incremento,0.641,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_4.setTransform(188.3,150.6-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_5.setTransform(176.5,150.5-incremento,0.641,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgrgxIBXAxIhXAyg");
	this.shape_6.setTransform(188.3,112.8-incremento);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AjbAAIG3AA");
	this.shape_7.setTransform(176.5,112.7-incremento,0.641,1);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},18).wait(68));

	// nombres_2
	this.instance = new lib.nombres_taula3();
	this.instance.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(86));

	// nombres
	this.instance_1 = new lib.nombres_taula2();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance_1.alpha = 0;
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(86));

	// mascara_grafica (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");
	mask_3.setTransform(66.6,134.1);

	// grafica
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape_8.setTransform(69.1,160.5-incremento,1,1.097);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_9.setTransform(69.4,210.8-incremento);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_10.setTransform(70,170-incremento,1.007,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_11.setTransform(70.2,129.5-incremento,1.011,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_12.setTransform(68.6,94-incremento);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_13.setTransform(53.1,160.2-incremento,1,1.087);

	this.text_4 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(86.2,66);

	this.text_5 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(11,67.2);

	this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.text_4.mask = this.text_5.mask = mask_3;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_5},{t:this.text_4},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(86));

	// formula
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AirBgIAAgBQAIgGAHgKQAIgKAFgMQAGgNAEgOQAEgNAAgRQAAgOgEgPQgEgOgGgMQgGgMgHgKQgHgJgIgHIAAgBIAWAAQARAUAKAYQAKAXgBAbQABAegKAXQgKAYgRATgAlVBgQgRgTgKgYQgKgXABgeQgBgbAKgXQAKgYARgUIAXAAIAAABQgJAHgGAJQgIAKgGAMQgGAMgEAOQgDAPAAAOQAAARADANQAEAOAGANQAGAMAIAKQAHAKAIAGIAAABgADzA4QgLgDgIgDIAAgVIACAAQAIAGALADQAMAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgDgEQgCgFgEgCQgFgDgGgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAKgGgBgMQABgGgDgDQgCgEgEgDIgJgDIgLgCQgJAAgLAEQgKADgJAGIgBAAIAAgUIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGADAFADQAEAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgNAAgMgDgAGeA4IgWgqIgpAqIgWAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg4A1IAfA2gAjhA4IgXgqIgoAqIgXAAIA5g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAnLA4IAVhcIgMAAIADgPIANAAIABgDQAEgUAMgLQALgKATAAIAKAAIAJACIgDAQIgBAAIgIgBIgIgBQgMAAgGAFQgGAHgDAMIgBAEIAhAAIgEAPIggAAIgWBcgAAAAUIAAgPIByAAIAAAPgAAAgSIAAgQIByAAIAAAQg");
	this.shape_14.setTransform(48.7,16.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14}]}).wait(86));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,6.8,148.6,243.1);


(lib.mc_pant2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// mascara_nombres (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_29 = new cjs.Graphics().p("AiXUiQgUAAAAgTIAA+zQAAgVAUABIB8AAQAUgBAAAVIAAezQAAATgUAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AhUPuQgbAAAAgUIAA+zQAAgUAbAAICpAAQAbAAAAAUIAAezQAAAUgbAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AhrPuQgjAAAAgUIAA+zQAAgUAjAAIDXAAQAjAAAAAUIAAezQAAAUgjAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AiCPuQgqAAAAgUIAA+zQAAgUAqAAIEFAAQAqAAAAAUIAAezQAAAUgqAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AiZPuQgyAAAAgUIAA+zQAAgUAyAAIEzAAQAyAAAAAUIAAezQAAAUgyAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AiwPuQg6AAAAgUIAA+zQAAgUA6AAIFhAAQA6AAAAAUIAAezQAAAUg6AAg");
	var mask_graphics_35 = new cjs.Graphics().p("AjHPuQhBAAAAgUIAA+zQAAgUBBAAIGQAAQBAAAAAAUIAAezQAAAUhAAAg");
	var mask_graphics_36 = new cjs.Graphics().p("AjfPuQhIAAAAgUIAA+zQAAgUBIAAIG/AAQBIAAAAAUIAAezQAAAUhIAAg");
	var mask_graphics_37 = new cjs.Graphics().p("Aj2PuQhQAAAAgUIAA+zQAAgUBQAAIHtAAQBQAAAAAUIAAezQAAAUhQAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AkNPuQhXAAAAgUIAA+zQAAgUBXAAIIbAAQBXAAAAAUIAAezQAAAUhXAAg");
	var mask_graphics_39 = new cjs.Graphics().p("AkkPuQhfAAAAgUIAA+zQAAgUBfAAIJJAAQBfAAAAAUIAAezQAAAUhfAAg");
	var mask_graphics_40 = new cjs.Graphics().p("Ak7PuQhnAAAAgUIAA+zQAAgUBnAAIJ3AAQBnAAAAAUIAAezQAAAUhnAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AlSPuQhuAAAAgUIAA+zQAAgUBuAAIKmAAQBtAAAAAUIAAezQAAAUhtAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AlqPuQh1AAAAgUIAA+zQAAgUB1AAILVAAQB1AAAAAUIAAezQAAAUh1AAg");
	var mask_graphics_43 = new cjs.Graphics().p("AmBPuQh8AAAAgUIAA+zQAAgUB8AAIMDAAQB8AAAAAUIAAezQAAAUh8AAg");
	var mask_graphics_44 = new cjs.Graphics().p("AmYPuQiEAAAAgUIAA+zQAAgUCEAAIMxAAQCEAAAAAUIAAezQAAAUiEAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AmvPuQiMAAAAgUIAA+zQAAgUCMAAINfAAQCMAAAAAUIAAezQAAAUiMAAg");
	var mask_graphics_46 = new cjs.Graphics().p("AnGPuQiTAAAAgUIAA+zQAAgUCTAAIONAAQCTAAAAAUIAAezQAAAUiTAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AndPuQibAAAAgUIAA+zQAAgUCbAAIO8AAQCaAAAAAUIAAezQAAAUiaAAg");
	var mask_graphics_48 = new cjs.Graphics().p("An1PuQiiAAAAgUIAA+zQAAgUCiAAIPrAAQCiAAAAAUIAAezQAAAUiiAAg");
	var mask_graphics_49 = new cjs.Graphics().p("AoMPuQipAAAAgUIAA+zQAAgUCpAAIQZAAQCpAAAAAUIAAezQAAAUipAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AojPuQixAAAAgUIAA+zQAAgUCxAAIRHAAQCxAAAAAUIAAezQAAAUixAAg");
	var mask_graphics_51 = new cjs.Graphics().p("Ao6PuQi5AAAAgUIAA+zQAAgUC5AAIR1AAQC5AAAAAUIAAezQAAAUi5AAg");
	var mask_graphics_52 = new cjs.Graphics().p("ApRPuQjAAAAAgUIAA+zQAAgUDAAAISkAAQC/AAAAAUIAAezQAAAUi/AAg");
	var mask_graphics_53 = new cjs.Graphics().p("ApoPuQjIAAAAgUIAA+zQAAgUDIAAITSAAQDHAAAAAUIAAezQAAAUjHAAg");
	var mask_graphics_54 = new cjs.Graphics().p("Ap/PuQjQAAAAgUIAA+zQAAgUDQAAIUAAAQDPAAAAAUIAAezQAAAUjPAAg");
	var mask_graphics_55 = new cjs.Graphics().p("AqXPuQjWAAAAgUIAA+zQAAgUDWAAIUvAAQDWAAAAAUIAAezQAAAUjWAAg");
	var mask_graphics_56 = new cjs.Graphics().p("AquPuQjeAAAAgUIAA+zQAAgUDeAAIVdAAQDeAAAAAUIAAezQAAAUjeAAg");
	var mask_graphics_57 = new cjs.Graphics().p("ArFPuQjlAAAAgUIAA+zQAAgUDlAAIWLAAQDlAAAAAUIAAezQAAAUjlAAg");
	var mask_graphics_58 = new cjs.Graphics().p("ArcPuQjtAAAAgUIAA+zQAAgUDtAAIW6AAQDsAAAAAUIAAezQAAAUjsAAg");
	var mask_graphics_59 = new cjs.Graphics().p("Ar0UiQj0AAAAgTIAA+zQAAgVD0ABIXpAAQD0gBAAAVIAAezQAAATj0AAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_graphics_29,x:-17.2,y:131.5}).wait(1).to({graphics:mask_graphics_30,x:-23.2,y:162.4}).wait(1).to({graphics:mask_graphics_31,x:-20.1,y:162.4}).wait(1).to({graphics:mask_graphics_32,x:-17.1,y:162.4}).wait(1).to({graphics:mask_graphics_33,x:-14,y:162.4}).wait(1).to({graphics:mask_graphics_34,x:-10.9,y:162.4}).wait(1).to({graphics:mask_graphics_35,x:-7.9,y:162.4}).wait(1).to({graphics:mask_graphics_36,x:-4.8,y:162.4}).wait(1).to({graphics:mask_graphics_37,x:-1.7,y:162.4}).wait(1).to({graphics:mask_graphics_38,x:1.2,y:162.4}).wait(1).to({graphics:mask_graphics_39,x:4.3,y:162.4}).wait(1).to({graphics:mask_graphics_40,x:7.4,y:162.4}).wait(1).to({graphics:mask_graphics_41,x:10.4,y:162.4}).wait(1).to({graphics:mask_graphics_42,x:13.5,y:162.4}).wait(1).to({graphics:mask_graphics_43,x:16.5,y:162.4}).wait(1).to({graphics:mask_graphics_44,x:19.6,y:162.4}).wait(1).to({graphics:mask_graphics_45,x:22.7,y:162.4}).wait(1).to({graphics:mask_graphics_46,x:25.7,y:162.4}).wait(1).to({graphics:mask_graphics_47,x:28.8,y:162.4}).wait(1).to({graphics:mask_graphics_48,x:31.9,y:162.4}).wait(1).to({graphics:mask_graphics_49,x:34.9,y:162.4}).wait(1).to({graphics:mask_graphics_50,x:38,y:162.4}).wait(1).to({graphics:mask_graphics_51,x:41.1,y:162.4}).wait(1).to({graphics:mask_graphics_52,x:44.1,y:162.4}).wait(1).to({graphics:mask_graphics_53,x:47.2,y:162.4}).wait(1).to({graphics:mask_graphics_54,x:50.3,y:162.4}).wait(1).to({graphics:mask_graphics_55,x:53.3,y:162.4}).wait(1).to({graphics:mask_graphics_56,x:56.4,y:162.4}).wait(1).to({graphics:mask_graphics_57,x:59.4,y:162.4}).wait(1).to({graphics:mask_graphics_58,x:62.5,y:162.4}).wait(1).to({graphics:mask_graphics_59,x:65.6,y:131.5}).wait(28).to({graphics:null,x:0,y:0}).wait(63));

	// nombres_2
	this.instance = new lib.nombres_taula3();
	this.instance.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	this.instance.alpha = 0;
	this.instance._off = true;
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(87).to({_off:false},0).wait(38).to({alpha:1},0).wait(25));

	// nombres
	this.text = new cjs.Text("3 ·", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(62.7,214.9);

	this.text_1 = new cjs.Text("3 ·", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(62.7,178.2);

	this.text_2 = new cjs.Text("3 ·", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(62.7,136.2);

	this.text_3 = new cjs.Text("3 ·", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(62.7,99.4);

	this.text_4 = new cjs.Text("2", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(104.9,215.9);

	this.text_5 = new cjs.Text("1", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(104.9,177);

	this.text_6 = new cjs.Text("0", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(104.9,135);

	this.text_7 = new cjs.Text("(–1)", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(92.3,98.3);

	this.text_8 = new cjs.Text("2", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(18.8,215.9);

	this.text_9 = new cjs.Text("1", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(18.8,177);

	this.text_10 = new cjs.Text("0", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(18.8,135);

	this.text_11 = new cjs.Text("–1", "20px Verdana");
	this.text_11.lineHeight = 22;
	this.text_11.setTransform(6.2,98.3);

	this.instance_1 = new lib.nombres_taula2();
	this.instance_1.setTransform(73.2,171.1,1,1,0,0,0,67,72.8);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.text.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.instance_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]},29).to({state:[{t:this.instance_1,p:{alpha:1}}]},58).to({state:[{t:this.instance_1,p:{alpha:0}}]},38).wait(25));

	// mascara_grafica (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AuWBCQgUAAAAgUIAAhbQAAgUAUAAIctAAQAUAAAAAUIAABbQAAAUgUAAg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AuWB5QgUAAAAgkIAAioQAAglAUAAIctAAQAUAAAAAlIAACoQAAAkgUAAg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AuWCvQgUAAAAg0IAAj1QAAg0AUAAIctAAQAUAAAAA0IAAD1QAAA0gUAAg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AuWDmQgUAAAAhFIAAlBQAAhFAUAAIctAAQAUAAAABFIAAFBQAABFgUAAg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AuWEdQgUAAAAhWIAAmNQAAhWAUAAIctAAQAUAAAABWIAAGNQAABWgUAAg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AuWFTQgUAAAAhlIAAnaQAAhmAUAAIctAAQAUAAAABmIAAHaQAABlgUAAg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AuWGKQgUAAAAh2IAAonQAAh2AUAAIctAAQAUAAAAB2IAAInQAAB2gUAAg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AuWHAQgUAAAAiGIAApzQAAiGAUAAIctAAQAUAAAACGIAAJzQAACGgUAAg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AuWH3QgUAAAAiXIAAq/QAAiXAUAAIctAAQAUAAAACXIAAK/QAACXgUAAg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AuWIuQgUAAAAinIAAsMQAAioAUAAIctAAQAUAAAACoIAAMMQAACngUAAg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AuWJkQgUAAAAi3IAAtYQAAi4AUAAIctAAQAUAAAAC4IAANYQAAC3gUAAg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AuWKbQgUAAAAjIIAAulQAAjIAUAAIctAAQAUAAAADIIAAOlQAADIgUAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AuWLRQgUAAAAjYIAAvxQAAjYAUAAIctAAQAUAAAADYIAAPxQAADYgUAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AuWMIQgUAAAAjpIAAw9QAAjpAUAAIctAAQAUAAAADpIAAQ9QAADpgUAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AuWM/QgUAAAAj5IAAyKQAAj6AUAAIctAAQAUAAAAD6IAASKQAAD5gUAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AuWN1QgUAAAAkJIAAzXQAAkJAUAAIctAAQAUAAAAEJIAATXQAAEJgUAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AuWOsQgUAAAAkaIAA0jQAAkaAUAAIctAAQAUAAAAEaIAAUjQAAEagUAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AuWPiQgUAAAAkqIAA1vQAAkqAUAAIctAAQAUAAAAEqIAAVvQAAEqgUAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AuWQZQgUAAAAk6IAA28QAAk7AUAAIctAAQAUAAAAE7IAAW8QAAE6gUAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AuWU9QgUAAAAlLIAA4JQAAlKAUAAIctAAQAUAAAAFKIAAYJQAAFLgUAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:66.6,y:54.1}).wait(1).to({graphics:mask_1_graphics_1,x:66.6,y:59.5}).wait(1).to({graphics:mask_1_graphics_2,x:66.6,y:65}).wait(1).to({graphics:mask_1_graphics_3,x:66.6,y:70.5}).wait(1).to({graphics:mask_1_graphics_4,x:66.6,y:75.9}).wait(1).to({graphics:mask_1_graphics_5,x:66.6,y:81.4}).wait(1).to({graphics:mask_1_graphics_6,x:66.6,y:86.8}).wait(1).to({graphics:mask_1_graphics_7,x:66.6,y:92.3}).wait(1).to({graphics:mask_1_graphics_8,x:66.6,y:97.7}).wait(1).to({graphics:mask_1_graphics_9,x:66.6,y:103.2}).wait(1).to({graphics:mask_1_graphics_10,x:66.6,y:108.7}).wait(1).to({graphics:mask_1_graphics_11,x:66.6,y:114.1}).wait(1).to({graphics:mask_1_graphics_12,x:66.6,y:119.6}).wait(1).to({graphics:mask_1_graphics_13,x:66.6,y:125}).wait(1).to({graphics:mask_1_graphics_14,x:66.6,y:130.5}).wait(1).to({graphics:mask_1_graphics_15,x:66.6,y:136}).wait(1).to({graphics:mask_1_graphics_16,x:66.6,y:141.4}).wait(1).to({graphics:mask_1_graphics_17,x:66.6,y:146.9}).wait(1).to({graphics:mask_1_graphics_18,x:66.6,y:152.3}).wait(1).to({graphics:mask_1_graphics_19,x:66.6,y:134.1}).wait(131));

	// grafica
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("ALQsuI2fAAQgUAAAAAUIAAY1QAAAUAUAAIWfAAQAUAAAAgUIAA41QAAgUgUAAg");
	this.shape.setTransform(69.1,160.5-incremento,1,1.097);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_1.setTransform(69.4,210.8-incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_2.setTransform(70,170-incremento,1.007,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("ArVAAIWrAA");
	this.shape_3.setTransform(70.2,129.5-incremento,1.011,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("ArUAAIWpAA");
	this.shape_4.setTransform(68.6,94-incremento);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AAAszIAAZn");
	this.shape_5.setTransform(53.1,160.2-incremento,1,1.087);

	this.text_12 = new cjs.Text("y", "italic bold 20px Verdana");
	this.text_12.lineHeight = 22;
	this.text_12.setTransform(86.2,66);

	this.text_13 = new cjs.Text("x", "italic bold 20px Verdana");
	this.text_13.lineHeight = 22;
	this.text_13.setTransform(11,67.2);

	this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.text_12.mask = this.text_13.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_13},{t:this.text_12},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(150));

	// formula
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AirBgIAAgBQAIgGAHgKQAIgKAFgMQAGgNAEgOQAEgNAAgRQAAgOgEgPQgEgOgGgMQgGgMgHgKQgHgJgIgHIAAgBIAWAAQARAUAKAYQAKAXgBAbQABAegKAXQgKAYgRATgAlVBgQgRgTgKgYQgKgXABgeQgBgbAKgXQAKgYARgUIAXAAIAAABQgJAHgGAJQgIAKgGAMQgGAMgEAOQgDAPAAAOQAAARADANQAEAOAGANQAGAMAIAKQAHAKAIAGIAAABgADzA4QgLgDgIgDIAAgVIACAAQAIAGALADQAMAEAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgGAAgIQAAgHgDgEQgCgFgEgCQgFgDgGgCQgGgBgHAAIgJAAIAAgQIAHAAQAPAAAIgGQAKgGgBgMQABgGgDgDQgCgEgEgDIgJgDIgLgCQgJAAgLAEQgKADgJAGIgBAAIAAgUIASgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGADAFADQAEAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgLAAQgNAAgMgDgAGeA4IgWgqIgpAqIgWAAIA4g3Igfg0IAVAAIAWAqIApgqIAWAAIg4A1IAfA2gAjhA4IgXgqIgoAqIgXAAIA5g3Igfg0IAVAAIAWAqIApgqIAWAAIg3A1IAeA2gAnLA4IAVhcIgMAAIADgPIANAAIABgDQAEgUAMgLQALgKATAAIAKAAIAJACIgDAQIgBAAIgIgBIgIgBQgMAAgGAFQgGAHgDAMIgBAEIAhAAIgEAPIggAAIgWBcgAAAAUIAAgPIByAAIAAAPgAAAgSIAAgQIByAAIAAAQg");
	this.shape_6.setTransform(48.7,16.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6}]}).wait(150));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.9,6.8,148.6,243.1);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}