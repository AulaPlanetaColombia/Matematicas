(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titulo']);
this.instance = new lib.R4();
	this.instance.setTransform(189.2,524.2);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.R4(), 3);

	this.instance_1 = new lib.R3();
	this.instance_1.setTransform(189.2,479.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.R3(), 3);

	this.instance_2 = new lib.R2();
	this.instance_2.setTransform(189.2,435.7);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.R2(), 3);

	this.instance_3 = new lib.R1();
	this.instance_3.setTransform(189.2,391.4);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.R1(), 3);
  this.instance_3.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
       this.instance_2.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
          this.instance_1.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
          this.instance.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
	this.instance_4 = new lib._01_OPT();
	this.instance_4.setTransform(320.9,138.5,0.725,0.725);
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit1']);
this.instance = new lib.lanzadorMC();
	this.instance.setTransform(674.9,330.1,0.954,0.954,0,0,0,43.9,0.5);

	this.instance_1 = new lib.Btn12();
	this.instance_1.setTransform(189.2,395.7);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Btn12(), 3);

	this.instance_2 = new lib.Btn11();
	this.instance_2.setTransform(189.2,261.4);
       
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Btn11(), 3);
       this.instance_2.on("click", function (evt) {
            putStage(new lib.frame2_2b());
        });
        this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_2a = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit2'],"20px");
	this.instance = new lib.jabalina3();
	this.instance.setTransform(496.6,351.3,1,1,0,0,0,44,1.2);

	this.instance_1 = new lib.Btn112("single",1);
	this.instance_1.setTransform(383.2,472.4);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Btn112(), 3);

	this.instance_2 = new lib.Btn111();
	this.instance_2.setTransform(383.2,403.4);
        
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Btn111(), 3);
         this.instance_2.on("click", function (evt) {
            putStage(new lib.frame2_2b());
        });
       this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_2a());
        });
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit2'],"20px");
	this.instance = new lib.jabalina2();
	this.instance.setTransform(496.6,351.3,1,1,0,0,0,44,1.2);

	this.instance_1 = new lib.Btn112();
	this.instance_1.setTransform(383.2,472.4);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Btn112(), 3);

	this.instance_2 = new lib.Btn111();
	this.instance_2.setTransform(383.2,403.4);
        
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Btn111(), 3);
         this.instance_2.on("click", function (evt) {
            putStage(new lib.frame2_2c());
        });
       this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_2a());
        });
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2c = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit2'],"20px");
	this.instance = new lib.jabalina1();
	this.instance.setTransform(496.6,351.3,1,1,0,0,0,44,1.2);

	this.instance_1 = new lib.Btn112();
	this.instance_1.setTransform(383.2,472.4);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Btn112(), 3);

	this.instance_2 = new lib.Btn111("single",1);
	this.instance_2.setTransform(383.2,403.4);
        
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.Btn111(), 3);
         
       this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_2b());
        });
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_3 = function (numero) {
        this.initialize();
        clearTexts();
numero=numero||0;
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit3'],"20px");
        
        if (numero==0){
	this.instance = new lib.dados1();
	this.instance.setTransform(661.9,361,0.64,0.64,0,0,0,44.1,0.3);
    }
    if (numero==1){
        this.instance = new lib.animacion1();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
    if (numero==2){
        this.instance = new lib.animacion2();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
 if (numero==3){
        this.instance = new lib.animacion3();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
     if (numero==4){
        this.instance = new lib.animacion4();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
     if (numero==5){
        this.instance = new lib.animacion5();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
     if (numero==6){
        this.instance = new lib.animacion6();
	this.instance.setTransform(662,361.1,0.821,0.821,0,0,0,254.7,195.8);
    }
	this.text_1 = new cjs.Text("¿Sabes que resultado saldrá?", "bold 20px Verdana", "#FF6600");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 289;
	this.text_1.setTransform(220.5,380.9);

	this.instance_1 = new lib.Btn21();
	this.instance_1.setTransform(189.2,321.4);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.Btn21(), 3);
        
       this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_3(Math.floor((Math.random() * 6) +1) ));
        });
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.instance_1,this.text_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
        titulo2(this, txt['tit4']);
	this.instance = new lib.parchis();
	this.instance.setTransform(733.5,385,1,1,0,0,0,172.5,143);

	this.text_2 = new cjs.Text("El conjunto de los resultados posibles de una experiencia aleatoria se llama espacio muestral.", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 786;
	this.text_2.setTransform(80,151.9);
        var html = createDiv(txt['text1'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(90, 151-608);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_2,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit4']);
	
	this.text_2 = new cjs.Text("El conjunto de los resultados posibles de una experiencia aleatoria se llama espacio muestral.", "20px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 786;
	this.text_2.setTransform(80,151.9);
        var html = createDiv(txt['text1'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(90, 151-608);
    this.instance = new lib.animacion6();
	this.instance.setTransform(703.4,400,0.654,0.654,0,0,0,254.6,195.8);
 var flecha = new lib.animacion3();
    this.instance2 = new lib.fadeElement(flecha, 35);
    this.instance2.setTransform(703.4,400,0.654,0.654,0,0,0,254.6,195.8);
var flecha = new lib.animacion1();
    this.instance3 = new lib.fadeElement(flecha, 65);
    this.instance3.setTransform(703.4,400,0.654,0.654,0,0,0,254.6,195.8);
var flecha = new lib.animacion5();
    this.instance4 = new lib.fadeElement(flecha, 95);
    this.instance4.setTransform(703.4,400,0.654,0.654,0,0,0,254.6,195.8);
	this.text = new cjs.Text("Por ejemplo: \nal lanzar un dado de parchís el espacio muestral = (1, 2, 3, 4, 5, 6)", "20px Verdana");
	this.text.lineHeight = 27;
	this.text.lineWidth = 418;
	this.text.setTransform(90,231.9);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
         this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_2,this.instance,this.text,this.instance2,this.instance3,this.instance4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance = new lib.arbol();
	this.instance.setTransform(753,341.1,0.531,0.531,0,0,0,44,0.5);

	this.text = new cjs.Text("Cuando tenemos experimentos que combinan procesos aleatorios, la mejor forma de hallar el espacio muestral es a través de un diagrama de árbol. ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 464;
	this.text.setTransform(80,151.9);
         var html = createDiv(txt['text2'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 151-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
         this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_2,this.instance,this.text,this.instance2,this.instance3,this.instance4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
     this.instance = new lib.animacionArbol();
	this.instance.setTransform(437.1,385.2,1,1,0,0,0,290.3,140.3);

	this.text = new cjs.Text("Mediante el diagrama de árbol representamos todos los resultados posibles.\n\n\nPor ejemplo: Cuando lanzamos un dado y una moneda juntos el diagrama de árbol es: ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 787;
	this.text.setTransform(80,101.9);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_2,this.instance,this.text,this.instance2,this.instance3,this.instance4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
       this.instance = new lib.B36();
	this.instance.setTransform(189,480.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.B36(), 3);

	this.instance_1 = new lib.B35();
	this.instance_1.setTransform(189,430.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.B35(), 3);

	this.text = new cjs.Text(txt['text5'], "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 787;
	this.text.setTransform(80,305.9);

	this.instance_2 = new lib.B34();
	this.instance_2.setTransform(189,380.9);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.B34(), 3);

	this.instance_3 = new lib.B33();
	this.instance_3.setTransform(186.8,251.6);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.B33(), 3);

	this.instance_4 = new lib.B32();
	this.instance_4.setTransform(186.8,207.4);
	new cjs.ButtonHelper(this.instance_4, 0, 1, 2, false, new lib.B32(), 3);

	this.instance_5 = new lib.B31();
	this.instance_5.setTransform(186.8,163.1);
	new cjs.ButtonHelper(this.instance_5, 0, 1, 2, false, new lib.B31(), 3);
 this.instance_5.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
 this.instance_4.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });
 this.instance_3.on("click", function (evt) {
            putStage(new lib.frame4_4());
        });
 this.instance_2.on("click", function (evt) {
            putStage(new lib.frame4_5());
        });
 this.instance_1.on("click", function (evt) {
            putStage(new lib.frame4_6());
        });
 this.instance.on("click", function (evt) {
            putStage(new lib.frame4_7());
        });
       
	this.text_1 = new cjs.Text("Los subconjuntos del espacio muestral se llaman sucesos. \nEstos se dividen en:", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 798;
	this.text_1.setTransform(80,61.9);
 var html = createDiv(txt['text4'], "Verdana", "20px", '800px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(90, 61-608);
         this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text_1,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.text,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
       this.instance = new lib.dadoSuelto1("synched",0);
	this.instance.setTransform(262.8,299,0.498,0.498,0,0,0,44,0.4);

	this.text = new cjs.Text("Sucesos seguros, los que forman parte de todos los posibles resultados, ocurren siempre.\n\nSu probabilidad es 100%.\n\nPor ejemplo: Obtener un \nnúmero ≥ 1 al lanzar un dado.", "bold 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 341;
	this.text.setTransform(479.4,199.9);
 var html = createDiv(txt['text6'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.instance = new lib.dadoSuelto2("synched",0);
	this.instance.setTransform(263.8,299,0.498,0.498,0,0,0,44,0.4);

	this.text = new cjs.Text("Sucesos seguros, los que forman parte de todos los posibles resultados, ocurren siempre.\n\nSu probabilidad es 100%.\n\nPor ejemplo: Obtener un \nnúmero ≥ 1 al lanzar un dado.", "bold 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 341;
	this.text.setTransform(479.4,199.9);
 var html = createDiv(txt['text7'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.instance = new lib.dadoSuelto2("synched",0);
	this.instance.setTransform(263.8,299,0.498,0.498,0,0,0,44,0.4);


 var html = createDiv(txt['text8'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        
       this.text2 = new cjs.Text("Casos favorables al suceso\nCasos posibles   ", "20px Verdana");
	this.text2.textAlign = "center";
	this.text2.lineHeight = 26;
	this.text2.lineWidth = 403;
	this.text2.setTransform(666.5,331.9+incremento);

	this.shape2 = new cjs.Shape();
	this.shape2.graphics.f().s("#000000").ss(1,1,1).p("A1oAAMArRAAA");
	this.shape2.setTransform(667.5,358);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance,this.shape2,this.text2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.instance = new lib.dadoSuelto3("synched",0);
	this.instance.setTransform(264.8,299,0.498,0.498,0,0,0,44,0.4);

 var html = createDiv(txt['text9'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        
      this.text2 = new cjs.Text("el dado  =", "20px Verdana");
	this.text2.lineHeight = 20;
	this.text2.setTransform(482,296.9+incremento);

	this.text_1 = new cjs.Text("=", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(636.4,296.9+incremento);

	this.text_2 = new cjs.Text("2\n3", "20px Verdana");
	this.text_2.lineHeight = 25;
	this.text_2.setTransform(675.4,285.9+incremento);

	this.text_3 = new cjs.Text("4\n6", "20px Verdana");
	this.text_3.lineHeight = 25;
	this.text_3.setTransform(602.4,285.9+incremento);

	this.shape2 = new cjs.Shape();
	this.shape2.graphics.f().s("#000000").ss(1,1,1).p("ADmgEIEYAAAn9AFIEYAA");
	this.shape2.setTransform(647.4,311.5);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance,this.shape2,this.text2,this.text_3,this.text_2,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.instance = new lib.dadoSuelto3("synched",0);
	this.instance.setTransform(264.8,299,0.498,0.498,0,0,0,44,0.4);

 var html = createDiv(txt['text10'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        
    this.text2 = new cjs.Text("1\n6", "20px Verdana");
	this.text2.lineHeight = 25;
	this.text2.setTransform(740,246.9+incremento);

	this.shape2 = new cjs.Shape();
	this.shape2.graphics.f().s("#000000").ss(1,1,1).p("AiLAAIEXAA");
	this.shape2.setTransform(749,272);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance,this.shape2,this.text2,this.text_3,this.text_2,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
     this.instance = new lib.dadoSuelto3("synched",0);
	this.instance.setTransform(264.8,299,0.498,0.498,0,0,0,44,0.4);

 var html = createDiv(txt['text11'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(480, 200-608);
	this.cerrar = new lib.btn_cerrar();
	this.cerrar.setTransform(842.6,133);
	new cjs.ButtonHelper(this.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA8dgerMh45AAAQhkAAAABkMAAAA6PQAABkBkAAMB45AAAQBkAAAAhkMAAAg6PQAAhkhkAAg");
	this.shape.setTransform(476.4,299.5);
        
   this.text2 = new cjs.Text("1\n2", "20px Verdana");
	this.text2.lineHeight = 25;
	this.text2.setTransform(641,269+incremento);

	this.shape2 = new cjs.Shape();
	this.shape2.graphics.f().s("#000000").ss(1,1,1).p("AiLAAIEXAA");
	this.shape2.setTransform(650,294);
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.shape,this.cerrar,this.text,this.instance,this.shape2,this.text2,this.text_3,this.text_2,this.text_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
       this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhoA+QhhgHgagYQgbgXA7gZQA7gaBegNQBcgNBKAIQBKAHAbAYQAbAYgkAYQgkAaheANQg8AIg7AAQgjAAgkgDg");
	this.shape.setTransform(710,281.2,0.808,0.808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhbCzQgmg8AAhiQAAhfAmhKQAmhJA1gHQA2gHAmA8QAmA9AABcQAABbgmBJQgmBKg2AMQgIACgIAAQgrAAgggzg");
	this.shape_1.setTransform(820.4,414.9,0.808,0.808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhbCzQgmg8AAhiQAAhfAmhKQAmhJA1gHQA2gHAmA8QAmA9AABcQAABbgmBJQgmBKg2AMQgIACgIAAQgrAAgggzg");
	this.shape_2.setTransform(780.8,327.6,0.808,0.808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhFQBEhEBgAAQBhAABFBEQBEBFAABgQAABhhEBFQhFBFhhAAQhgAAhEhFg");
	this.shape_3.setTransform(718.9,429.1,0.808,0.808);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AilCmQhEhFAAhhQAAhgBEhFQBFhEBgAAQBhAABEBEQBFBFABBgQgBBhhFBFQhEBFhhAAQhgAAhFhFg");
	this.shape_4.setTransform(626.8,429.1,0.808,0.808);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhEQBEhFBggBQBgABBGBFQBFBEgBBgQABBhhFBFQhGBEhgAAQhgAAhEhEg");
	this.shape_5.setTransform(717.3,335.8,0.808,0.808);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhEQBEhFBggBQBhABBFBFQBEBEAABgQAABhhEBFQhFBEhhAAQhgAAhEhEg");
	this.shape_6.setTransform(624.4,335.8,0.808,0.808);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EDE7DA").s().p("AhwBOQgMgDgJACQAHgIAfgSQAZgOAFgTQAdgGAVgkQAXgtAOgKIAwA8QAdAeAjAKQg9AZggALQg4AUg1gKQgHABgGAFQgIAGgEABIgCAAQgHAAgKgCg");
	this.shape_7.setTransform(756.9,468.5,0.808,0.808);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EDE7DA").s().p("AunQ2QAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAAQgegMgZgfQgNgQgZgrQgDgMgEgeQgEgdgEgMQgBjSgIlyQgLmvgCimQgBhHgFieQgFicgBhVQgBg+AEgxIACg+QABgjAGgUQAIgbAYgWQAPgPAhgXQAigLA2gBQAuAAAnAGQBLgHBtgBIDHgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQDaAFG9gBQGWACEgAaQAvAUAYAzQAOAdAUBRIASBKQAKArADAaQAEAoAAA+IgBBrIAHIUQAEFDABDCQABChgBAzQgBAhAEA/QAAA2gPAjQg6BkhUAuQgOAFgfAFQgeAHgPAFIqpgEQmCAAkPAEQiUADhIAAQh7ABhZgOg");
	this.shape_8.setTransform(670.3,386.6,0.808,0.808);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EDE7DA").s().p("AgdA3QgSgrgFgKQgHgHgWgOQgUgOgHgLQAIgRAjgGQAsgHAJgFQAZgCAigHIA4gQIAGAAQgGARgOAQIgaAbQgHAMgbA+IgOAoQgJAXgJAMQgNgRgNghg");
	this.shape_9.setTransform(756.4,303.9,0.808,0.808);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EDE7DA").s().p("AmhTCQgwgegghFQgSjpgCmVQgDn7gFiVQgIj1ACiXQAAgKAFgPQAEgPAAgGQAAgFgDgNQgEgLABgIQACgVAMgmQALggAMgaQAehDBehbQAOgGBNgaQA4gTAdgUQAKABAMgFQAOgFAHAAQA+geBngnICshDQALgEAQgJIAagPQAHgDAPgEQANgEAIgEQAKgGAZgGIAqgKIAmgHQAWgEALgHIAHAAQAYALARAjQAJAUARAqQACAiAIAiQAIEzgBJQQAAJCAIEoQgHA2gSBMQgHASgPAVIgbAjIgRAJQgKAFgEAHQlaCMmSCNQgNACgNAAQghAAglgLg");
	this.shape_10.setTransform(800.5,368.8,0.808,0.808);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EDE7DA").s().p("ACeDFQh+gFgxAAIrmgGQmngCk0AEQAogcBDgdQAmgQBOgfQCAg2DghTQEGhjBdglQG9gQJhAHQFeAEKHAOQgnARg0ATIhfAgQhZA2hjAXQkABwkKBRQgtAChUAVQhQATgyABIgZAAQg8AAhdgEg");
	this.shape_11.setTransform(711.8,281.8,0.808,0.808);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("A3GUbQhCgigthRQgLg1gChFIABh9QABiDgHj0QgIjyABhyQABhTgHivQgCgtAAhXQAAhZgBgpQgJirgChXQgDiXARhuQBThxDAhFQA5gUBtgrQBwgtA0gTQAwgVB1gsQBkgnA7gcQAqgUAwgKQAmgJA6gFQA8gFCugBQCegBEeADQFLAECAAAQI2AAFAAKQAtAgAbA8QAXAzANBPQgVNtAeOoIgMA6IgMA5QgWAwguApQgFAEgSAJQgPAGgFAJQhXAciXA5QijA8hIAZQgaAJjOBPQiOA3hiAYQjTAJlggFQm3gGiEACQkuAGiYAAIjfAHIg1AAQhjAAhGgKgAGoUPQANADAHgBQAEgBAHgGQAHgFAGAAQA2AJA5gTQAggMA9gYQgjgKgdghIgvg7QgPAJgZAtQgVAmgdAHQgFATgZAOQgfASgHAHIAHAAIAOABgA2atwQg2ABghALQgiAXgPAOQgXAXgIAaQgGAUgBAkIgDA+QgEAxABA+QABBVAGCcQAFCeABBGQACClAKGxQAJFxAADTQAEAMAEAdQAEAeAEAMQAZArANAQQAYAeAeANQABAAABAAQAAAAABAAQAAABAAAAQAAABAAABQBaANB7AAQBHAACVgEQEOgDGFAAIKnADQAOgFAegGQAggGANgEQBVguA5hkQAPgjAAg2QgDg/AAghQABgzgBiiQAAjBgFlDIgHoUIABhrQAAg/gEgoQgDgZgKgrIgShKQgThRgOgdQgYgzgwgVQkggamUgCQm/ACjZgFQgBAAgBABQAAAAgBAAQAAABAAAAQAAABAAABIjIAAQhsABhLAIQglgGgqAAIgHAAgAMgvSQhMAagPAHQhdBbgeBCQgMAagLAgQgNAmgBAWQgBAHADAMQAEAMAAAGQAAAFgFAPQgEAPgBALQgBCWAID1QAFCWADH7QACGUARDqQAgBFAxAeQAzAPAsgGQGViNFaiMQAEgHAJgGIASgJIAagjQAQgVAHgSQAShMAHg1QgJkpABpCQAApPgIk0QgIgigBgiQgRgpgKgUQgQgjgZgMIgGAAQgMAHgVAEIgmAIIgqAKQgZAGgKAFQgIAFgNADQgQAEgHAEIgaAOQgQAKgKAEIitBCQhoAog/AdQgHABgOAFQgMAEgKAAQgcATg5ATgAJDuNQgiAIgbACQgJAFgsAHQgjAFgIARQAHALAUAOQAWAPAHAJQAFAKASArQANAhANAQQALgLAJgXIAOgoQAbhAAHgNIAagaQAOgQAGgRIgGAAIg4APgAsKuIILmAFQAxAAB+AGQByAEBAgBQAyAABQgUQBUgVAtgCQEKhQEAhyQBjgYBZg2IBfggQA0gSAngSQqHgOlegEQphgHm9AQQhdAmkGBiQjgBViAA2QhOAfgmARQhDAcgoAdQDNgDEBAAIENABg");
	this.shape_12.setTransform(713.4,370.2,0.808,0.808);

	this.text = new cjs.Text("Si un experimento aleatorio se repite N veces, la frecuencia absoluta es el número de veces que ha ocurrido un suceso. ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 791;
	this.text.setTransform(80,150.9);
         var html = createDiv(txt['text12'], "Verdana", "20px", '800px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 151-608);
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.text,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance = new lib.animacion8_2();
	this.instance.setTransform(474.4,328.3,1,1,0,0,0,394.4,174.2);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

  (lib.frame5_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     	// Capa 1
	this.text = new cjs.Text("3", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(754.5,378.9);

	this.text_1 = new cjs.Text("6", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(694.5,378.9);

	this.text_2 = new cjs.Text("6", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(635.5,378.9);

	this.text_3 = new cjs.Text("1", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(575.5,378.9);

	this.text_4 = new cjs.Text("4", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(516.5,378.9);

	this.text_5 = new cjs.Text("5", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(455.5,378.9);

	this.text_6 = new cjs.Text("6", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(754.5,332.9);

	this.text_7 = new cjs.Text("5", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(694.5,332.9);

	this.text_8 = new cjs.Text("4", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 20;
	this.text_8.setTransform(635.5,332.9);

	this.text_9 = new cjs.Text("3", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 20;
	this.text_9.setTransform(575.5,332.9);

	this.text_10 = new cjs.Text("2", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 20;
	this.text_10.setTransform(516.5,332.9);

	this.text_11 = new cjs.Text("1", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 20;
	this.text_11.setTransform(455.5,332.9);

	this.text_12 = new cjs.Text("Frecuencia absoluta", "bold 20px Verdana");
	this.text_12.lineHeight = 20;
	this.text_12.setTransform(179,377.9);

	this.text_13 = new cjs.Text("Suceso", "bold 20px Verdana");
	this.text_13.lineHeight = 20;
	this.text_13.setTransform(179,332.9);

	this.text_14 = new cjs.Text("Se ha lanzado el dado 25 veces y los resultados son: 2, 5, 6, 5, 1, 4, 2, 4, 4, 6, 1, 4, 1, 2, 5, 6, 4, 1, 2, 5, 5, 3, 5, 1, 4.\n\n\nOrganizamos los resultados en una tabla:", "20px Verdana");
	this.text_14.lineHeight = 25;
	this.text_14.lineWidth = 785;
	this.text_14.setTransform(80,133.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EAoJgHGIpYAAIAAHGIJYAAgEAxXAAAIAAliQAAhkhkAAInqAAEAoJAAAIJOAAEAoJAHHIHqAAQBkAAAAhkIAAljEAoJAHHIpYAAIpYAAIpYAAIpYAAIpWAAMgpFAAAQhkAAAAhkIAAljIAAliQAAhkBkAAMApFAAAIJWAAIJYAAIJYAAIJYAAEAoJAAAIAAHHAexHHIAAnHIpYAAIAAHHAmtnGIAAHGIJWAAIAAnGACpAAIJYAAIAAnGAVZnGIAAHGIpYAAIAAHHACpAAIAAHHAmtHHIAAnHMgqpAAA");
	this.shape.setTransform(470,370.5-incremento);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.shape,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame5_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     	// Capa 1
	// Capa 1
	this.text = new cjs.Text("0,12", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 20;
	this.text.setTransform(694.4,392.9);

	this.text_1 = new cjs.Text("0,24", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(634.4,392.9);

	this.text_2 = new cjs.Text("0,24", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(575.4,392.9);

	this.text_3 = new cjs.Text("0,04", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(515.4,392.9);

	this.text_4 = new cjs.Text("0,16", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(456.5,392.9);

	this.text_5 = new cjs.Text("0,2", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(395.5,392.9);

	this.text_6 = new cjs.Text("1", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(786.9,391.9);

	this.text_7 = new cjs.Text("25", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.setTransform(786.9,347.9);

	this.text_8 = new cjs.Text("Total", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 20;
	this.text_8.setTransform(786.9,303.9);

	this.text_9 = new cjs.Text("Frecuencia relativa", "bold 20px Verdana");
	this.text_9.lineHeight = 20;
	this.text_9.setTransform(119,390.9);

	this.text_10 = new cjs.Text("3", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 20;
	this.text_10.setTransform(694.5,348.9);

	this.text_11 = new cjs.Text("6", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 20;
	this.text_11.setTransform(634.5,348.9);

	this.text_12 = new cjs.Text("6", "20px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 20;
	this.text_12.setTransform(575.5,348.9);

	this.text_13 = new cjs.Text("1", "20px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 20;
	this.text_13.setTransform(515.5,348.9);

	this.text_14 = new cjs.Text("4", "20px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 20;
	this.text_14.setTransform(456.5,348.9);

	this.text_15 = new cjs.Text("5", "20px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 20;
	this.text_15.setTransform(395.5,348.9);

	this.text_16 = new cjs.Text("6", "20px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 20;
	this.text_16.setTransform(694.5,302.9);

	this.text_17 = new cjs.Text("5", "20px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 20;
	this.text_17.setTransform(634.5,302.9);

	this.text_18 = new cjs.Text("4", "20px Verdana");
	this.text_18.textAlign = "center";
	this.text_18.lineHeight = 20;
	this.text_18.setTransform(575.5,302.9);

	this.text_19 = new cjs.Text("3", "20px Verdana");
	this.text_19.textAlign = "center";
	this.text_19.lineHeight = 20;
	this.text_19.setTransform(515.5,302.9);

	this.text_20 = new cjs.Text("2", "20px Verdana");
	this.text_20.textAlign = "center";
	this.text_20.lineHeight = 20;
	this.text_20.setTransform(456.5,302.9);

	this.text_21 = new cjs.Text("1", "20px Verdana");
	this.text_21.textAlign = "center";
	this.text_21.lineHeight = 20;
	this.text_21.setTransform(395.5,302.9);

	this.text_22 = new cjs.Text("Frecuencia absoluta", "bold 20px Verdana");
	this.text_22.lineHeight = 20;
	this.text_22.setTransform(119,347.9);

	this.text_23 = new cjs.Text("Suceso", "bold 20px Verdana");
	this.text_23.lineHeight = 20;
	this.text_23.setTransform(119,302.9);

	this.text_24 = new cjs.Text("La frecuencia relativa de un suceso es el cociente de su frecuencia absoluta y el número de veces que se ha realizado el experimento.\n\nLa tabla de frecuencias del lanzamiento de dados es: ", "20px Verdana");
	this.text_24.lineHeight = 20;
	this.text_24.lineWidth = 785;
	this.text_24.setTransform(80,133.9);
 var html = createDiv(txt['text13'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text_24 = new cjs.DOMElement(html);
    this.text_24.setTransform(90, 133-608);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AexDXIKAAAIAAmtIqAAAgEAoxgDWIAAnHIqAAAIAAHHEAoxgKdIQaAAQBkAAAABkIAAFjIAAGtIAAFjQAABkhkAAIwaAAIqAAAIpYAAIpYAAIpYAAIpWAAIpYAAMgpFAAAQhkAAAAhkIAAljIAAmtIAAljQAAhkBkAAMApFAAAIJYAAIJWAAIJYAAIJYAAIJYAAEA6vgDWIx+AAEA6vADXIx+AAIAAHHAexKeIAAnHIpYAAIAAHHAwFDXIJYAAIAAmtIpYAAgAmtqdIAAHHIJWAAIAAnHAwFqdIAAHHMgqpAAAAMBjWIpYAAIAAGtIJYAAgAMBDXIJYAAIAAmtIpYAAAMBqdIAAHHAVZqdIAAHHIJYAAACpKeIAAnHIpWAAIAAHHAwFKeIAAnHMgqpAAAAMBKeIAAnH");
	this.shape.setTransform(470,362-incremento);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.shape,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
     	this.text = new cjs.Text("La probabilidad no permite saber cuando saldrá un 6 al lanzar un dado, pero sí permite saber que 6 es un suceso posible con probabilidad\n\n      = 0,166... \n\nPero ¡cuidado! Esto no quiere decir que si lanzas seis veces el dado salga seguro un 6. Cada lanzamiento es un experimento aleatorio que empieza de cero. ", "20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 456;
	this.text.setTransform(80,149.9);
 var html = createDiv(txt['text14'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 150-608);
	this.instance = new lib.animacion9();
	this.instance.setTransform(763.3,299.3,0.587,0.587,0,0,0,254.6,195.8);
var inc=0;
if (isbq) inc =36;
	this.text_1 = new cjs.Text("1\n6", "20px Verdana");
	this.text_1.lineHeight = 25;
	this.text_1.setTransform(90,274.9-inc+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AiLAAIEXAA");
	this.shape.setTransform(99,300-inc);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.shape,this.text_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       this.text = new cjs.Text("¡Investiga!\n\nAunque el azar no tiene memoria, si tiramos miles de veces el dado la frecuencia relativa se aproximará a la probabilidad, ¡puedes probar!", "bold 23px Verdana", "#FF6600");
	this.text.lineHeight = 23;
	this.text.lineWidth = 785;
	this.text.setTransform(80,421.9);
var html = createDiv(txt['text16'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 421-608);
	this.instance = new lib.grafico("synched",0);
	this.instance.setTransform(479.4,263.2,1.305,1.305,0,0,0,44.1,8.6);

	this.text_1 = new cjs.Text(txt['text15'], "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 787;
	this.text_1.setTransform(78,49.9);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.text_1,this.instance,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._01_OPT = function() {
	this.initialize(img._01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,864,648);


(lib.cara = function() {
	this.initialize(img.cara);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,100);


(lib.cruz = function() {
	this.initialize(img.cruz);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,100);


(lib.parchis_OPT = function() {
	this.initialize(img.parchis_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,660,543);


(lib.Path = function() {
	this.initialize(img.Path);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,487,213);


(lib.Path_1 = function() {
	this.initialize(img.Path_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,574,267);


(lib.Path_2 = function() {
	this.initialize(img.Path_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,683,353);


(lib.Path_0 = function() {
	this.initialize(img.Path_0);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,681,351);


(lib.Path_0_1 = function() {
	this.initialize(img.Path_0_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,572,265);


(lib.Path_0_2 = function() {
	this.initialize(img.Path_0_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,681,351);


(lib.Path_0_3 = function() {
	this.initialize(img.Path_0_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,485,211);


(lib.Path_0_4 = function() {
	this.initialize(img.Path_0_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,572,265);


(lib.Path_0_5 = function() {
	this.initialize(img.Path_0_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,485,211);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.parchis = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A68WVMAAAgspMA14AAAMAAAAspg");
	mask.setTransform(172.5,143);

	// Capa 2
	this.instance = new lib.parchis_OPT();
	this.instance.setTransform(-10,-12.2,0.561,0.561);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-10,-12.2,370.1,304.5);


(lib.moneda = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.cruz();
	this.instance.setTransform(-43.4,-49.6);

	this.instance_1 = new lib.cara();
	this.instance_1.setTransform(-45.4,-49.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.4,-49.6,87,100);


(lib.lanzadorMC = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#934607").s().p("AooGxQAOgmAfglQATgWApgnQAXgXArggIBEg1QA2glBVhCQBlhPAjgYIERjTQBbhFAtglQAVgOAvgmQAsgiAbgQQAFARAOAUIAYAiImMEvQjqCzifB7QgDAAgEAGQgPAHgHAKQgEAAgEAGQAAAAAAAAQAAAAAAAAQgBAAAAABQAAAAAAAAQgFAAgBAEIhhBEQg6AogpAaQgKAFgZARQgNAHgLAAQgJAAgIgEg");
	this.shape.setTransform(-124.1,-46.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF7F00").s().p("AgIAMIgWgjQAHgNANgCQAGAQAMATIAWAeQgBAGgLAGQgQgIgKgTg");
	this.shape_1.setTransform(-69.4,-88.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFC9B6").s().p("AAVAzIgKgDIgVglQgNgUgGgRQABgHAIgGQAIgIACgEQAGAVAMAeQASAjAFAPQgDACgDAAIgEgBg");
	this.shape_2.setTransform(-67.5,-97.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D14D13").s().p("AgVAHQgOgQgGgTQALgRALATIATAcQAHgCAPABQANABAHgCQgCANgOAJQgTAMgCADIgageg");
	this.shape_3.setTransform(-65.4,-90.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFC9B6").s().p("AAGA8QgHgXgeg/QADgJAKgKIAPgQIADAIQAAAGgBACQAdAtAEA5QgGAFgJAAQgFAAgGgCg");
	this.shape_4.setTransform(-63.9,-98.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFC9B6").s().p("AASBHIgKgDQgCgYgNggQgQghgEgRQAEgLAMgIQANgIAGgFQAOAWAAAkIgGA+QABADAGAGQAFAFAAAFQgCACgEAAIgEAAg");
	this.shape_5.setTransform(-60.1,-100.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFC9B6").s().p("AgUAAQACgJAPABIAYACQgBAMgSADIgDAAQgOAAgFgJg");
	this.shape_6.setTransform(-49.9,-111.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D14D13").s().p("AguBEQgfACgPgJQAHgPAPgOQAHgGAWgQIgCgGQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAABAAQAOgNAbgUIArgjQAMAWAmAuIhaBEQgKgCgnACg");
	this.shape_7.setTransform(-43.2,-110.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFC9B6").s().p("AABAEQgJgCgKABQAAgDAEgCQAEgDABgCQAVAGAHAJIgSgEg");
	this.shape_8.setTransform(-38.4,-103.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF7F00").s().p("AgegXQAFgLAOgDQAQApAaAWQAAAHgKAFQgjgTgQgqg");
	this.shape_9.setTransform(-34.5,-115.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAAAAQAAgDABADIAAACIgBgCg");
	this.shape_10.setTransform(19.9,-34.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgFAXIAQgiQgOgSgVAMQgVANAHAVQgEABgDgCQgEgCgCAAQgFglAmgIQAkgIAMAgQgCAFgKAFQgKAHgBAHQALAEAOgEIATgKQAGASgcAGQgJACgGAAQgOAAgFgKg");
	this.shape_11.setTransform(39.2,-96.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#015353").s().p("AAeAoQgSgJgBgQQgGgHgKgJIgTgRIgPgGQgIgDgEgFIAAgJQAGgEAJAEQAKAFAHgCQAUANAaAfIARAKQAJAHgCAKQgCALgIAAQgFAAgGgEg");
	this.shape_12.setTransform(39.5,240.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#015353").s().p("AARBeQgMgBgMgTQgRgYgDgCQgigLgNgHQAHgpAGgYQALgnAQgTIAmATQAYALAXACQABAKgBASIADAHIACAFQAAACgEAFQgDAGACAHQABAEANAKQAMAIgCANQgBAHgIAHQgKAJgCAFIABABIgEAPQgEABgMAKQgHAFgIAAIgDAAg");
	this.shape_13.setTransform(42.4,231.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgBAGQABgIAAgEQACABgBAFQAAAHgBAAIgBgBg");
	this.shape_14.setTransform(54.5,112.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFC9B6").s().p("AhFGuQgJgCgFgEIgFgMQgCgHAAgHQhLhZgdhsQhQiygshTIgSgdQgLgRgEgOQgig0gTgxQgUgQgwgKQg9gOgOgFQADgIgHgIQgJgJAAgGIADgeQADgPgHgJQAGgKgDgWQgEgbACgKQAPgIAVgDQAWgDARAFQgJAZgkAJQAAAKAGAMQAHAMAJAEQA8gCARABQAuABAeAJQAFABADgCIAGgCQAGAEALANQAKALAJAEQAFALAHAGQAmBbBMBZQAlArBrBmIAoA/QAZAmAFAlQACAGgFAEQgFAEAAADQAJgCAPgMQAKgCAFABQBSgzCjAIIBGhAQArghAwgLQATAAAbgDIAsgFQABAEgCAGQgBAHAAAEQADAhgIAgQgDBlgYA4QgFApgQAZQADAGgCAKIgEAQQgJgBgCgFIgDgMQgkgUgUgJQgjgPgfABQgXACgrANIgfAIQgTAFgKAGQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAABAAABQgBAEgCAAIgIgFQgEgDgEgBIgiAAQgSAAgIAEQgIABgIgGIgOgLQgFgDgPgDQgNgCgGgFQgGADgDAGQAjASAuAIQAwAIAzgGQBMgbAugBQAXAJAXACQAGAEAlAUQAaAPAMAOQgCAKAAATQAAAUgBAHQgBADgHgEQgJgGgDAAIgTgNQgLgIgKgEIgGgIQgEgEgEgCQhTAbhmAJQhoAJhigLQgNAIggAHQgjAGgOAJIgQgDg");
	this.shape_15.setTransform(-1.2,-66.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgcAAQAGgJAVgWQAFACAPgEQAMgDAFAFIgkAPQgUAKgEAQIABAPQgBAGgFAEQgNgOAOgVg");
	this.shape_16.setTransform(52.7,-122.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgFAJQgGgUgGgJQgBAAAAgBQAAgBAAAAQABgBAAAAQAAAAABgBIACgDQAFgBADAEQADAFADgBQAAAJALANQAKAOgDAMQgRgBgGgSg");
	this.shape_17.setTransform(54.9,-119.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#015353").s().p("AgkAFQAHgKAWgEIAjgHQAJAAAAAFIgkAMQgUAIgLAIQgFgHgBgFg");
	this.shape_18.setTransform(54.1,231.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#015353").s().p("Ag1AnQAJgNAagGIAsgJQgQgGgWAIIgnAMQgOgaAcgXQAbgVAfAHQARADAIAUQAIATgYADQAFADAMABQAKACgBAJQgFAIgVgBQgNgBgdAJQgQAEgMAAQgHAAgGgCg");
	this.shape_19.setTransform(54.4,226.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#015353").s().p("AgHgBIAPAAQgCACgGABIgCAAQgGAAABgDg");
	this.shape_20.setTransform(59.6,230.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag0ATQACgTAogMQAngMAXANQgCAKgMABIgXABQgLABgXAJQgUAIgLAAIgCAAg");
	this.shape_21.setTransform(57.1,233.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgNAQQgBgBAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQAMgYAVgGQgDAHgLAJQgJAKgDAHIgBAAQgBAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAAAg");
	this.shape_22.setTransform(61.7,136.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgMAIQABgXAMguIAGAAQgBAHgHAgQgJAZADARQABALAHAMQALAPACAEQgcgLACgrg");
	this.shape_23.setTransform(62.9,163.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgPgCIAagLQALAAAHAHQAAAEgIgBIgMAAQgJABgIAGQgLAJgHABQgGgMARgEg");
	this.shape_24.setTransform(67.8,-131.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgQgUQACgDAOAAIANAXQAIAPgHAJQgVgNgJgfg");
	this.shape_25.setTransform(69.6,-126.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#015353").s().p("AgnBDQg5gHgtgQIgBgSQAAgLgCgIQAIgBAFgGIAKgNIAEgPIAKgDQAHgDACAHQA0gWARgGQAngNAqgBQBOAYAPBMQgZAVgqAQQgaACgaAAQggAAghgDg");
	this.shape_26.setTransform(59.8,240.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAKBFQAHgFAPgGIAKgKQAFgGADgFQgDgMgPgJQgSgKgDgGQgMgGgPgRQgSgTgIgGQgCgIgIgIQgKgLgDgFQAAgHAHAAQAHABAEAHIAHAMQASAYAfAbIA5AqQgFAWgVAQIgoAYQgBgMALgHg");
	this.shape_27.setTransform(69.7,-118.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFBF00").s().p("Ai0DjQgCgHgFgEQgHAAgGAGQgFAHgHgBIgHglQgFgVgJgJQgGAAgDAGQgDAIgEAAQgIgVAKgfQAMgjgCgKQgHgBgEAHQgEAJgDABQABgpAUgpQAMgWAdgoQACgEgDgFQAAgBgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQBOiCCigjQAEgCgBgDQAAgHABgBIAaAOQAOAKAEANIATAJQAKAGAFAHQANgKAXgBQAYAAAMALQAAAEgGABQgGACAAACQAAAJAJAFQAKAGACADQAAAFABAFQACAEgBAEQAWATAKASQAOAXAAAgIgKgOQgGgIgCgIQgQghgogaQgPgJg9gfIgGAAQAFgFgBgFQgGAAgGADQgHADgEAAQgFAAgDgEQgEgFgEgBQgQAGgJARQgDgBgCgIQgCgHgDgCQgQgBAFAWQgYA7gpAhIgYAmQgPAZgHAQQgWA9ADAvQABAZAPAhQASAoADAMQgGgCgIgHQgIgIgHgBQg4AIgUAVIgBgQg");
	this.shape_28.setTransform(50.7,-124.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AhggJQgOgBgDgEIAAgEIABgDIAEgCQALADAgATQAaAMAZADIATAAQAOgBALADQAygMAiAEQgeALgxAEIgbABQhIAAggghg");
	this.shape_29.setTransform(65.2,-26);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#015353").s().p("AheAWQgfgGgJgFQgVgJAEgRQAJgCAMAEIAUAIQAJABAjAEQAcAGAXgCIAigBIAjgCQAWgBAbgPIApgXIACAAQAHABAAAKIgCARQgeAng3AKQhNgBhTgQg");
	this.shape_30.setTransform(60.7,249.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AhEAdQgEgIAIgGQAMgHAAgCQAUgGAlgPQAjgNAeABQABAGgEADQgGAFAAACIgUAAIgQAEQgLADgIAAQgMAEghANQgDABgKAJQgHAGgHAAIgCAAg");
	this.shape_31.setTransform(72.3,-99.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAAgiQADAAACACIgFAgQgBATgBAQQgFgUAHgxg");
	this.shape_32.setTransform(80.7,134.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAEg6QADgBACACQgHATgCAmIgFA8QgKg3ATg/g");
	this.shape_33.setTransform(80.7,1.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFC9B6").s().p("AgMEWQgQgJgmggQghgbgYgLQgUAdgugIQgtgJgLgeQACAAADADQADACAEgBQgGgYAVgMQAUgNAQATIgRAjQAHAPAcgGQAdgHgGgSIgUAKQgNAFgLgEQABgIAKgGQAKgHACgGQgMgfgmAHQgnAIAGAnQgNgRANgUQAGgKAUgSQAcgDAVAMQAMAHAUASQAJgOgJgVIgRgfQgDgRgNgSQgCgMgFgSQgBgMABgRIACgdQAEg+Avg7QA/hPAJgTQADAAgBAFQgBAGADgBQAJABAIgOIANgWQAFgBAEAFQAFAEAEABQACgBAIgFQAHgEAFgBQgCADABAEIABAHQAzAQA5AsQBNBuAkCWQABACACADIAEAEQADAOABATIAAAiQgMA7gJAmQglAfg9ARQg4APhFABQgNgIgIAAgACOB3QgnARgUAHQAAABgMAIQgIAFAEAIQAJABAHgHQAKgIADgBQAhgQAOgEQAIABALgDIAQgFIAUAAQAAgCAGgEQAEgEgBgGIgEAAQgcAAghAMgAAsiHQADAFAKALQAIAIACAIQAIAGASATQAPARAOAGQADAIASAKQAPAJADAMQgDAFgFAGIgKAIQgPAGgHAFQgNAHADAMIAogYQAVgOAFgWIg5gsQghgbgSgYIgHgMQgEgHgHgBQgHAAAAAHgAgzhaIgCADQgBAAAAAAQAAABgBAAQAAABAAAAQAAABABABQAGAIAGAWQAIASARABQADgMgKgNQgLgPAAgJQgFABgDgFQgCgEgDAAIgDABgAhXhgQgOAWANAOQAFgEABgGIgBgPQAEgSAVgKIAlgPQgFgFgMADQgPAEgHgCQgVAWgGAKgABciaQAJAhAXANQAHgJgIgQIgNgZQgQAAgCAEgABLi9QgRAHAGAMQAGgCALgIQALgIAJgBIAMAAQAHAAAAgEQgHgGgKgBIgcALg");
	this.shape_34.setTransform(58.6,-113.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFC9B6").s().p("AgKDKQgUgCgUgLIgigTQgJgTgFgqQgGgxgFgPQgag6gXhMQAEAAAEACQAEADAEAAQBOgGAzgMQA9gQAlgfQAKghADgTQAlA9AYBkQgBAygNAsQgOAvgaAcQAAAFgDAEQgDAFAAAEIggAbQgTAQgQAIIgVADIgMABIgJAAg");
	this.shape_35.setTransform(74.1,-74.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFC9B6").s().p("AgKgSQACgGAIgEQAFgFAGABQAAAYgCApQgOgggFgTg");
	this.shape_36.setTransform(89.7,-85.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFC9B6").s().p("AjiJtQgXgKgNgEQgDgdAFgqIAJhEQAAgJgCgRIgCgaQAAgrAJhAQAKhJAEgjQAmiJBLhwQABgFADgHQADgIAAgFQABgCAFgDIAHgDQANhHAKhpQgSg9gKhNQgKhLgBhMIgDgpQAAgYAGgNIAGgDQCnASAaAFQBrAQBGAeQgFAfgFBBQgFBFgEAeQgDAYgKAjIgPA3IgeA8QgSAlgQATQgHAlgTAXQACAugQAuQgLAlgZArQAOgIALgbQAMgdALgHQgBASgGAbIgJAmQhbCigoBeQgFAcgOAgIgbA1QgFAVgMAlQgNAmgFATQg6AGgXAcQgUgBgWgHgAgzAfQgCAsAeALQgCgEgLgQQgJgLgBgLQgDgSAJgaQAJgeABgIIgGAAQgOAtgBAYgACLkmQgJAzAFAUQABgQADgTIAFgiQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBgBAAAAIgBAAgAhEjkQABAAAAAAQAAAAABABQAAAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAABABAAQABAAAAAAQAEgIALgKQALgLADgHQgYAGgMAag");
	this.shape_37.setTransform(66.8,160.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAMBfQgJgUgIgFQAAgQgEgHQAOghgJgzIgZhSIAEAAQAMAYAKAoIAHAjQAGAUgBAMQAAAGgHAVQgDAQADAMQAMAOARAnQgLgFgIgUg");
	this.shape_38.setTransform(105.3,10);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AACAHQAWgsAIgoQACAAACACQgHAsgWAnQgMAcgfAqIAmhHg");
	this.shape_39.setTransform(113.8,-46.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgBAAQgOgogEgaIAEADQAEARAPAuQAMAoAFAcIgWhEg");
	this.shape_40.setTransform(124.1,7.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#00A0C6").s().p("AjdJkQgBgzgLhHQgQhdgCgYQgLgjgIgOQgSgYg+hJQgzg7gZgqQgIgCgHgJIgKgRQABgpgEgmQAAggAPguQAQgzACgZQANgjAFhDIAJhuQAIgIARgHQADAfALApQAEgLgEgsQgCgjAQgJIALAyQAHAgAAATQAKAdAeAhQALABANAGIAUALQAFgCASABQATABAIgCIASgLIARgJQAegSAZgsQAOgZAagzIAJguQAFgcAGgQIABhGQACgpAJgZQAEAKAAAYQABAXAEAKQAFgJABgrQABglAMgKQgBAJAAAPIgCAYQATBVBABBQApArBbA9QA9AbA/gCQAGAjAFBxQAFBgAOAsQAAALAFAkQADAdgDAUIAbByQAQBBAQAvQAAATAIAgQAIAjABASIABAnQABAUAFALQjkCVj/gJIhmACQg+gBgdgOgABYF8QAMA1gQAhQAEAHAAAQQAJAFAJAUQAJAUAKAFQgQgogMgOQgFgLAFgQQAHgWAAgGQAAgMgFgWIgJgjQgKgngMgYIgFAAIAZBSgAEYGHIAXBEQgEgcgNgnQgQgwgEgSIgFgDQAFAbAOApgAiRESQgVBAAKA4IAFg9QAEgnAHgTQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBgBAAIgBABgAmhAjIgCADIAAAEQAEAEAOABQAlApBfgHQAygEAegKQgigFgzAMQgLgCgOAAIgVAAQgZgDgagOQgfgSgMgEIgDACgADUjkQgHAogXAtIgnBIQAegrAPgbQAVgpAIgsIgEgCIgBAAg");
	this.shape_41.setTransform(95.8,-31.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#DD781D").s().p("AtzKZIgMgSQgIgLABgHQABgJAUgPIAggWIA3gqIGBkoQDmixCdh1QA3grDzi+QC6iSB7hUIAOgLQAJgHAFgDIBKguQAugeAfgQIBCgkQAngUAdgLIACAAQAHAEgHAJIgNAOQgnApg/AzIhsBWQiGBui/CTIlKD6ItsKhQgPgIgOgUg");
	this.shape_42.setTransform(55.8,-182.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AiVCAIAAgWQAGgKATgOQA9gaBOg4QAXgXAigaQAJgQAYgbQAZgbAJgQQADgDAAgDIAGAAQAGAKgKAJQgPANgBAEQgJAIgTAZQhfBrhvAyIgTANQgLAIgGAIQgDAJADATQgHgCAAgMg");
	this.shape_43.setTransform(138,-99.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#047391").s().p("Aj9GcQgsgMgTgJQglgEg6gJIhegPQgMgCgXAAQgagBgNgBQgKgBgfgIQgagIgQABQAPhkA+iRQBEieAShNQAQgaARg4QAUhBAKgVQAtAKA/ACQAgABBUgBQCtgCCvhPQBEgeAsgcIADAAQAIAQAQAZIAYAoQACADAFADQAFADACACQASAaA0A6QAuAzAUAkQAsAwAxBIIBUB/IAQALQACAHALARQAJANgBAKQgBAKgNALQgNAMgDAIQgSAMgYAXQgeAbgLAJIgqAiQgYAUgTANQhKBDg7AqQgagTgegtQgmg6gMgOQgfgag5g6QgVgLgHgOQgdgPghgiIg3g3QARgGADgKQgegEgZAFQgeAGgOAQQgLAqgZBDQgdBNgJAfQgHBCgXBEQgTgJgsgMg");
	this.shape_44.setTransform(116.7,61.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AAmCKIgFgUIgPg6IgPg8QgEgXgVgzQgTgugFgbQABgFADgCQAEAYAOAfIAYA2QAIAUAGAdIAKA0QAEARAKAgQAIAdABAVQgGgGgDgLg");
	this.shape_45.setTransform(195.2,167.8);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFC9B6").s().p("AEiK7QglgCgzgOQgDgEgEgJQgDgHgFgFIAAgKIAAgLQgmishHhrQgSgRgYghQgcghgJgSIgKgUQgGgNgJgEQgDgOgJgOIgQgZQgOgtgLhCQgHgogJhLQAFACAEALQAFAJAFABQgCgUgYgvQgUgqgBgiQgYhQhThGQhjhJgqgsQAsgpBohUQBihQAwgvQAAAAABAAQAAAAAAAAQAAAAAAABQAAAAAAABQBmCZAkCWQABAEAFAEQAFAEACADQAEAWAmBFQAeA1gHAtQAGAnAEARQAFAFAPAEQAaBbAmCiQArC6ASBHQAcBRAQBSQAAATgBAEQAEAUANAjQAMAkAFASQgaASgrAAIgNAAgAAMAmQAGAbATAvQAVAyAGAZIAOA8IAQA6IAFAUQADALAGAGQgBgVgIgdQgKgggEgRIgKg0QgHgfgIgTIgZg2QgOgggFgYQgDACgBAFg");
	this.shape_46.setTransform(189.2,149);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFC9B6").s().p("AAAADIgEgBIAAgDQAEgDACACQAEACgBAEIgFgBg");
	this.shape_47.setTransform(229.9,-175.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#015353").s().p("AgPgGQAAgkAWAHQAKAUgBAUQgDAXgOAJQgNgMgBgfg");
	this.shape_48.setTransform(229.6,216.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgWAJIARgbIAOgOQALgJAJAHQgBAKgLARQgMARgDAJQgCACgHAJQgHAIgIAAQgLgLALgSg");
	this.shape_49.setTransform(231,221.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#015353").s().p("AgTAJQAHgPAIgHQAKgJAOAIQgHAPgOASQgLgDgHgHg");
	this.shape_50.setTransform(234.6,222.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgdAcQAWgnAYgXQAHgBAGAFQgJALgNAaQgLAYgUAEQgDgGgDgBg");
	this.shape_51.setTransform(237.1,223.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFC9B6").s().p("AgygDQAmgFAZAKIASgKQALgIAJgDQgHAMgGAUQgHgCguAIIgJABQgXAAgDgXg");
	this.shape_52.setTransform(236.4,-176.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#015353").s().p("AgXANQACgHAKgIQAKgLABgHQAHgBAHAEIAKAGIgMAPQgIAKgDAIQgGgBgSgIg");
	this.shape_53.setTransform(240.3,224.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFC9B6").s().p("AgwAJIAHgMQAEgCAJAAIAOgCQAAALAOABQACgCABgHQABgJAEgDQAFAAARgGQANgEALABQgFAfgjALQgRAHgyACQgBgJAGgIg");
	this.shape_54.setTransform(236.9,-181.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgFgBIABgBQAEAAAGgCIgFAHIgCACg");
	this.shape_55.setTransform(243.7,222.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgDABQACgBADAAIACABg");
	this.shape_56.setTransform(245.1,221.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AAAAAQgFABgGAAIATgIIABACQgFABgCADIAJAAIAAABIAAAAIABAAIgQAIg");
	this.shape_57.setTransform(244.4,222.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#015353").s().p("AABAQQgRgBgTgGQAJgRAHgIQAHACARAKQATAIAMADQgHAKgUAAIgIgBg");
	this.shape_58.setTransform(248,227.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFC9B6").s().p("An6KFQghgHgTgNQAGgUAIgwQAIguAGgWQABgCAMgNQAHgIgHgHQgPAJgIAfQgKAsgDAGQABAYgJAPIgCAQQgBAKgDAEQhJgkg0g2Qg+g/gQhLQgIgnAcgmQAWgRA9gQQA+gQAWgRQAOgUASgMQBkiFDKg/QBGgTAkgnQAKgUATgaIAfgsQAJgNASgPIAXgaQAPgQALgIQARgMApgXIA7gnQAkgYAYgNQAMAAALgHIATgMIAHgBQAEgCADABQAsgVA0glIBYhCQARgZAbgbIAzgvIASgPQAJgIALgFIAHgGIAHgGQAEgDANgDQAMgDAGgEIA+AAQASgJAkgKQAtgLAMgFIAEAAQAHAGgFAKIgLAOQgMAGgJgBQgUASg0ANQg7AOgSAKQgYAkgkBRQALgDAGAAQAJABAKAFQARACASgHQAWgKAIgBQAEAAgBAEQgCAGABABQAUgNAWAKQAWAKgDAZQgIATglgQQgXAEgJAAQgJACgKAJQgMALgFADQgCAJgDADQgSAcg2APIhaAaQhMA1hqB/QhyCHg9AxQguAcguAMQgEACACAGQACAGgCACQgaAMgZAUQiDDFjJB3QgSAdgEA2IgDBjIgJABQgbAAgZgGgAjbCWQgJARgYAaQgYAbgKARQghAZgXAaQhQA3g+AaQgSAPgGAKIAAAVQAAAMAHACQgDgTADgJQAFgIALgHIATgNQBygzBehsQATgZAKgJQABgEAOgMQALgJgHgKIgFAAQgBACgDADg");
	this.shape_59.setTransform(174,-128.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFC9B6").s().p("AhtAdQAkgLBDgYQA8gUA4gCQAAAHgGAFIgIAIQgMABgQAHQhiAEg7AZg");
	this.shape_60.setTransform(245.3,-186.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#015353").s().p("ABzBcQgRgEgrgCQgsgBgSgFIifABQhegBgsgUQgGghAIgpQAMgvAEgXIAVgHQAiAOAxADQA2AEAigNQABAIAGAHQAIAJABADQgKATAFANQAJAGAMgEIAUgHQALABAEANIAIAVQAIACAGgGQAFgEAFABQANABAKAIIAQATQAOgBAEgGIABAAIA0AJQAdAEAUgKIAUgPQALgIARAEQAaAHAbAXQASAQAYAcQhTAOhXAAIgWAAg");
	this.shape_61.setTransform(236,228.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#015353").s().p("ABLAcQgOgBgagFQgagGgKgBQgggCheABQhNABgqgJQgCgBghgDQgagCgDgLQgEgTAZACQAOACAZAGQAhAEBHAAQBLAAAhADIAgAFIAeAEIAmABIAmABQAlACAogDIBHgIIAkgEQAVAAAHAPQgEAPgXADQgdABgLACQhEAIg5AAQgXAAgWgBg");
	this.shape_62.setTransform(235.4,238.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("EACOAnrQhYgGg6gfQgJgJgIgTIgNggQgKgLgcgXQgZgVgNgOQgBgSAEgRIAKgeQAMgrAHgUQAMghASgRQAIgoADg6QABg+ACgfIACgtQAAgcACgRQABgKAEgQIAFgZIABgUIABgVQAEgfANgkIAWg8QAJgZAVglQAhg8AkhKQAGgcAEg0IAHhRIgJgpQgGgZgBgTQgPg3gGgcQgJgmADg7IAEhkQgJgEgSgBQgSAAgIgDIALgjQAFgUACgTQAVhCBBikQA5iPAZhbQADgDADgIQAEgIACgDQABgLAIgUQAHgSAAgOQAGgJAIgWQAHgWAGgJQgDgmgLhBQgLhHgEgiQgHgvgjgsQgrgxgTgZQgNgSgvg5QgmgugWgeIgigVQgVgNgRgFIgvALQgcAHgWABQgDABgCADQgDADgDAAQg6AKhFABQgzABhTgFIhjAcIgigHIgRgoQgKgYgPgIQgFgPgNgRIgVgeQgEgMgNghQgLgcgEgTIgIgOQgEgKgEgEQgNgtgeg+IgxhnQgUglgig8Ig3hgQgYgIgIgIQgOgFgmgBQgkgCgPgGQg0AchDA0IhwBWIlUEDQjZCnh7BcQCeh8Dsi1IGMkvIgXgiQgOgUgGgRQgbARgrAiQgwAmgVAOQgsAlhcBFIkSDSQgkAahlBPQhVBCg2AmIhEA1QgqAggYAWQgpAngTAWQgeAlgOAmQARAKAXgNQAZgQALgFQAogaA6gpIBihEQg+A/hDAkQgWAOgtAgQgYAQgNAGQgYAJgVgEQgFgXAPgYIAbgkQAigsAcgWQBOhGCGhmQCviEArgjQFxkYDSijQgKgYgGgKQgMgLAAgGQgBgOAZgMQAcgNAEgLQAQgDATgKQAYgOAHgDQADgBAAgGQAAgHACgCQAYgGAigEQAEgDABgMQAAgLAGgDIAgACQAUABALAGIJxnbIJtnbQBFg1CJhsQB7hgBZg6QB7hOBNglIAjgRQAWgJARACQgBAVgSARQgYAVgEAIQgNAKgRASIgdAeQirCHkKDLIm3FRQiSBvkkDhQiSBwhLA3QgVAShZBCQhFAzgkAnQAFAFASAFIAfAlQASAWALARIACAIQACAFgBAFQAaA1AnA1QAdAoAwA1QAOARAcAbIAqArQA3A6AZAiIANAeQAIARACAQQCIgzB4AHQASgMAigdQAfgbAUgNQAYgQAtgIIBSgLQAGgGAcgRQAXgMAFgRQgGgXgPgjQgSgpgFgPQhAg3gjgVQgkAagwgOQgwgPgLgqQAEgbgLgdQgHgBgFAKQgFAJgGgCQgMgTgGgvQgFgCgHALQgHALgHgEIgDgiQAAgVAFgPQAAgFgHACQgGACAAgFQAKheAmg4QACgCgCgFQgDgFADgEQAvhEAigiQAjgeBXgsIAYgOQAOgHANADQAAgFgIgFQgHgFADgGQAbAAAVALQAXAMAIAVQAGABAJAGQAJAGAFABQASgGATABQAWACAJAKQACACANACQALABgBAIQAEAHgIABQgLgBgDABQACAIAHAGIANAJQABASANARQATAWACAFQgDAQAFAQIAJAXIAAAKQgBAGABADQABAIAFAMIAIAVQABAEAEAHIAFAKIAXBIQANAsAMAbQADARgEAdQgFAdACAMQAEARAKAWIARAjQAIgCALgHQAMgIAGgCQAIgPATgSIAdgfQAMgDAMgHIAUgNIBMgVQAkgKAdgYQANgKAlgnIA+hAQBJgrAugXQBFghBCgRIASgKIASgKQAHgGAMgQQAMgPAIgHQAOgeAWgcQAQgUAdgeQAsgtA8giIBKgvQAtgdAdgMQBbgmBohTIBYhbQA1gyAzgZQAsgCAPABIA2gSQAegJAbgEIAPgIQAJgGAIAEQAKAIgDASQgEARgKAFQAJADAXgCQAYgDAJADQgEApguALIhZAKQgBAAABABQAAAAAAAAQAAABABAAQAAABABABQAFAEgCAFQgIAMgIAZIgMAoQAUAPAFAHQAMAPgEAXQgLAUgdgBQgjgEgRABQgPAJgWAWQgWAZgNAIQgIAAgJAEIgPAGQg1ANgUAHQgnANgVAUIhDBDQglAmgYAhIg9BKQglAsgfAWQgSAYgeAYQgQAOgnAaQg/Adg5A0QgBADgDAFQgEAFABAFQgUAUg3BAQgtA2ggAcQgbAYgwAhIhPA2QgRAhgEA1QgDAwAIAvQADAxACBgQAFBTAMA8QAFAcAMBgQAKBKANAqQAkBiAIB1QAAAEADAEIAEAGQgBAIACAKQACAKgBAEQALASAFATIAMARQAIAJABAKQBbBlBkCIQBCBZBvChIATAZQgDAHgHAIIgNANIA9ByQAkBEAQA1IANAsQAIAZALAQQAFAZARAfQAWAqAEAKQAOATALAMQgDAKADARQAEARgEALQAPAbALAmQAGASANAzQARA/AjCVQAiCPAUBLQADAdAMAlIAXA/QAAAhANAvIAUBNQAHgOAHgGQAKgJAPABQAGAGAEARIAGAaIATANQAMAIAEAJIAVAEQALACAJgEQADACAMAQQAJAMAKAAIgBABIAEAIIAEgCIgSAaQgKAPgEAOQACASAOgCQgEAGgOABIgQgTQgKgKgNgBQgGgBgGAGQgGAGgIgCIgIgXQgEgNgLgBIgUAHQgMAEgJgGQgFgNAKgTQgBgDgIgJQgGgHgBgIQgiANg2gEQgxgDgigOIgVAHQgEAXgMAvQgIArAGAhQAsAUBeABICfgBQAUAFAsABQArACARAEQBiACBegQQgYgcgSgQQgbgXgagHQgRgFgLAJIgUAPQgUAKgdgEIg0gJIAXglQAOgXgEgTIAAAAIgBgBIAAgCIAAAAIgCgDIAGAAQAEABACAIIACAMQAVAUA1AKQA6ALATAMQARALAQAWIAdAkIABATIgBAUIgWAOQg6AKghADQgzAFgvgEIh/gMQgggDhDACQhDACgigDQhAgGgkgNQgQg2ALhAQAKg9AcgnQAAgJgIgfQgGgaACgRQgFgMgTg7QgPgsgOgXQABgEgCgFIgDgIQgSgoghgsIg+hJIgnhEQgYgogLggQgMgdgHg1QgIg8gGgVQACgOgEgRIgJgdQgBgEACgFIABgIQgLgTgEgKQgHgTAIgOQgKgkgPghQgkg2hHg9QhShBgngkQgDgDgGAGQgFAFgFgEQg8hZgxg5QhBhKhGgvQgJgKgcgbQgYgXgMgQQgDAAgHgGQgGgFgHABIgFgKQgDgGgEgCQgQgCgMAFQgJAEgLAJQgGAOgVBCQgQAygRAZIgWBrQgNA+gOAkQgIABgKgFQgLgFgHAAQgEAFgCALIgEAQQgBAqgGA0IgLBYQgHAOgFAWIgHAoQgmBWgqBSQABALgEAKIgHAQQACAvgGAtQgDAbgLA1QgpA5gXA0QgTAcgVAvIgkBPQgIAfggBKQgbBBgJAtQAEAKAJAMIAOAVQgFAzAsAjQAuAGAYAaQALALALAaIARApIALAOQAIAKABAEQAFAcgpAZQgsAchKAAIgigCgEAAOAmlQgEATAVAJQAJAFAeAGQBUAQBPABQA2gKAegpIACgRQABgKgIgBIgCAAIgpAXQgbAPgWADIgiACIgkABQgXACgcgGQgkgGgJgBIgTgIQgJgDgHAAIgFABgEAAZAliQgFAIgIABQACAIAAALIABASQAtAQA5AHQA6AGA9gFQAqgQAZgVQgPhOhOgYQgqABgpANQgRAGg0AWQgCgHgHADIgKADIgBgBQACgFAKgIQAIgIABgHQACgMgMgJQgNgKgBgGQgCgHADgFQAEgFAAgCIgCgGIgDgHQABgRgBgLQgXgCgWgLIgogTQgQAUgLAmQgGAYgHAsQANAHAiAKQADADARAYQAOASAKABQAKABAIgGQAMgJAEgCIgKANgEgBgAk0IAAAJQAEAFAIADIAPAGIATARQAMALAGAHQABAQASAJQAQAKADgRQACgKgIgHIgQgKQgaghgWgNQgHACgKgFQgFgCgEAAQgDAAgDACgEAd3AleQAMABAaAGQAaAFAOABQBKAFBfgMQAMgCAcgBQAYgDADgRQgHgPgVAAIgjAEIhHAIQgpADglgCIglgBIgngBIgfgEIgggFQghgDhMAAQhHAAgggEQgZgGgOgCQgZgCAEATQACAMAbADQAgADACABQArAJBMgBIAxgBQA2AAAYACgEAB3AkOQgoAMgCAVQALAAAWgIQAZgJALgBIAXgCQAMgCACgKQgMgHgRAAQgPAAgUAGgEABcAj/QgXAEgGAMQABAFAEAHQAMgIAVgIIAkgOQABgFgKAAIgkAHgEACaAj/QAIgBACgEIgSAAQAAAGAIgBgEACCAjbIguAJQgaAGgJAOQAOAEAbgHQAfgIANAAQAVABAFgIQABgJgKgCQgMgBgFgCQAYgDgIgVQgIgUgRgEQghgHgbAWQgcAWAOAdIAngMQAOgFAMAAQAIAAAGACgEAfTAjkQATAHATABQAaACAIgMQgLgCgTgKQgTgLgHgBQgHAHgJATgEAecAiXQgbAWgVApQADACADAFQAUgEANgXQAMgcAJgMQgEgEgFAAIgDABgEAeqAisQgCAHgKALQgKAKgDAHQATAIAIABQADgIAIgKIAMgRIgLgGQgFgDgHAAIgCAAgEAdXAiAIgQAOIgRAdQgLASALALQAIAAAHgIQAIgJADgCQADgJAMgTQALgRABgKQgEgDgEAAQgGAAgGAFgEAdrAibQgHAHgIARQAHAHALADQARgSAGgRQgHgEgGAAQgHAAgGAFgAByPSQgGANAAAYIADApQABBLAKBMQAKBNASA9QgKBpgNBGIgHAEQgFACgBADQAAAFgDAHQgDAIgBAFQhLBygkCJQgEAjgKBJQgJBAAAArIACAaQACAQAAAJIgJBFQgFAqADAdQANAEAVAJQAWAIAUAAQAXgbA6gGQAFgTANgnQAMgkAFgVIAbg1QAOggAFgcQAqhfBbihIAJgnQAGgaABgTQgLAIgMAdQgLAbgOAHQAZgrALgkQAQgwgCguQATgXAHglQAQgTASgmIAeg8IAPg3QAKgiADgYQAEgfAFhEQAFhBAFggQhGgdhrgQQgagFipgTIgGAEgEAcvAhpQABAhANANQAQgKADgXQABgVgKgVIgHgBQgRAAAAAegAVaYFQALBDAOAtIAQAYQAJAPADAOQAJAEAGAMIAKAVQALARAcAiQAYAgASARQBHBsAnCsIgBALIABAKQAEAEAEAIQADAIADAEQA0AOAkACQA1ADAdgUQgFgSgMglQgMgigFgVQACgDAAgUQgRhSgbhQQgThHgri6QgmilgahbQgPgDgEgFQgFgRgGgoQAHgtgeg1QglhEgFgXQgCgDgFgEQgEgEgCgDQgkiWhniaQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAQgwAvhiBQQhnBUgsAqQAqAsBiBJQBTBGAYBQQABAhAVArQAXAuADAVQgGgCgFgJQgEgKgFgCQAJBMAHAogABmRjQAEABAAgHQAAgIgCAAQAAADgCALgABpPAQAfAIAKABQANABAaABQAXAAAMACIBeAPQA6AJAlAEQATAJAsAMQAsAMATAJQAXhEAHhCQAJgfAdhNQAZhDALgqQAOgQAegGQAZgFAgAEQgDAKgTAGIA5A3QAhAiAdAPQAHAOAVALQA5A6AfAaQAMAOAmA6QAeAtAaATQA7gqBKhDQATgNAYgUIAqgiQALgJAegbQAYgXASgMQADgIANgMQANgLABgKQABgKgJgNQgLgRgCgHIgQgLIhUiBQgxhIgsgwQgUgkgugzQg0g6gSgaQgCgCgFgDQgFgDgCgDIgYgoQgQgZgIgQIgDAAQgsAchEAeQixBPitACQhUABgggBQg/gCgtgKQgKAVgUBBQgRA4gQAaQgSBNhECgQg+CRgPBkIAEAAQAPAAAXAHgAB5qeIgIBtQgFBEgNAjQgDAYgQAzQgOAugBAiQAFAmgBAqIAKAQQAGAJAJADQAZAqAyA7QA+BIASAXQAIAOALAiQADAZAPBcQAMBHAAA0QAeAOA9AAIBmgCQECAJDkiUQgGgMAAgUIgBgnQgCgRgIgjQgHghgBgRQgPgvgQhAIgbhzQADgTgEgeQgEgmAAgLQgPgsgEhgQgGhxgGgjQg+ACg9gaQhcg+gogqQhBhCgVhVIACgYQABgOADgJQgPAKgBAkQgBArgEAKQgEgLgBgXQgBgXgDgLQgKAagCApIgBBFQgFARgFAbIgJAvQgbAzgOAYQgYAsgeASIgSAJIgSALQgIACgSgBQgSgBgFACIgVgLQgMgGgLgBQgfghgKgdQAAgTgHgfIgLgzQgQAJADAjQADAtgEAKQgLgpgDgfQgQAHgJAJgAvRxNQgVADgPAHQgCAKAEAbQADAXgGAJQAHAJgDAQIgDAeQAAAGAJAJQAHAIgDAHQAOAGA9ANQAwAKAUARQATAwAiA1QAEAOALARIASAdQAsBVBQCyQAdBsBLBYQAAAIACAHIAFAMQAFADAJACIAQADQAOgIAjgHQAigGANgJQBiAMBogJQBmgJBTgbQAEABAEAFIAGAIQAJAEAKAHIATAOQADAAAJAGQAHAEABgDQABgIAAgTQAAgTACgLQgMgOgagOQgjgVgGgEQgXgCgXgIQguAAhMAcQgzAFgwgIQgugHgjgSQADgGAGgDQAGAEANADQAPADAFACIAOALQAIAHAIgCQAIgEASAAIAiAAQAEABAEADIAIAFQACABABgFQAAgBAAAAQAAgBABAAQAAgBABAAQABAAABAAQAAAAAAAAQABABAAAAQAAAAABABQAAABAAAAQAAABABABQAAAAAAAAQABABAAAAQABAAAAAAQAKgHATgFIAfgIQArgNAXgBQAfgCAjAQQASAJAkATIADANQACAFAJAAIAEgQQACgJgDgHQAQgYAFgpQAYg4ADhlQAIghgDghQAAgEABgGQACgGgBgFIgsAFQgbADgTABQguAKgrAiIhGBAQijgJhSAzQgFAAgKACQgPALgJADQAAgEAFgEQAFgEgCgGQgFgkgZgmIgqg/QhrhoglgsQhMhYgmhbQgHgGgFgMQgJgEgKgLQgLgNgGgEIgGADQgDACgFgBQgegKgugBQgRAAg8ACQgJgFgHgMQgGgLAAgLQAkgIAJgaQgKgCgMAAIgRABgAjxleQAEAFgBgFIgBgCIgCACgAC+rAQAFAPAGAyQAFAqAJATIAiATQAUALAUABQALABAMgBIAVgDQAQgIATgQIAggbQAAgEADgFQADgFAAgEQAagdAOguQANgsABg0QgYhkglg9QgDASgKAhQglAfg/AQQgzANhOAFQgEABgEgDQgEgDgEAAQAXBMAaA8gAMMsuQgLAMgBADQgGAWgIAuQgJAvgFAVQATANAgAHQAeAGAggBIAChjQAFg3ARgcQDJh3CEjGQAYgTAbgMQABgCgCgGQgBgGAEgCQAvgMAugdQA+gxByiJQBqh/BLg1IBagZQA2gQATgcQADgCACgKQAFgCAMgLQAKgJAIgDQAKAAAWgDQAmAPAIgTQADgZgXgKQgVgKgVAOQAAgCACgFQABgEgFAAQgHABgXAJQgRAIgSgCQgKgGgJAAQgGAAgKACQAjhQAZgkQASgKA7gPQAzgNAUgRQAJAAAMgFIALgOQAGgKgIgGIgDAAQgNAEgsAMQglAJgSAKIg+AAQgFAEgMADQgNADgFACIgGAHIgIAGQgKAFgKAHIgRAQIgzAuQgcAbgQAaIhYBBQg1AmgrAVQgEgBgEABIgGABIgTAMQgLAHgNABQgYANgjAXIg7AoQgpAWgTANQgMAIgPAQIgXAZQgRAQgJANIggAsQgSAagKAUQglAnhFAVQjLA+hjCGQgTAMgNAUQgWAQg+AQQg+AQgWARQgcAmAJAoQAQBKA9BAQA1A2BJAkQACgFABgJIACgQQAJgQAAgXQADgGAKgsQAHgfAPgJQAIAHgIAIgAHHt9QgIAFgCAGQAFAUAQAhQACgrAAgYIgCAAQgFAAgGADgABOuDQAmAgAQAJQAIAAAPAIQBFgBA4gPQA9gRAlgfQAJgmAMg7IAAgiQgBgTgDgOIgEgEQgCgDgBgCQgkiYhNhuQg5gsgzgQIgBgHQgBgEACgDIAGAAQA9AfAPAJQAoAaAQAhQACAIAGAIIAKAOQAAgfgOgYQgKgSgWgTQABgDgCgFQgBgFAAgEQgCgDgKgHQgJgFAAgIQAAgDAGgCQAGgBAAgDQgMgMgYAAQgXABgNALQgFgIgKgGIgTgJQgEgNgOgJIgagPQgBACAAAGQABAEgEACQiiAihOCCQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQADAFgCAEQgdApgMAYQgUAogBApQADgBAEgJQAEgHAHABQACAKgMAjQgKAgAIAUQAEAAADgHQADgHAGAAQAJAJAFAVIAHAlQAHABAFgHQAGgGAHAAQAFAEACAIIABAPQAUgVA4gIQAHACAIAHQAIAHAGACQgDgMgSgoQgPghgBgZQgDguAWg9QAHgTAPgZIAWgmQApggAag7QgFgXAQABQADACACAHQACAIADABQAJgRAQgGQAEABAEAFQADAFAFAAQAEAAAHgEQAGgDAGAAQABAFgFAFQgFABgHAEQgIAFgEABQgEgBgFgEQgEgFgFABIgNAWQgIAOgJgBQgDABABgGQABgFgDAAQgJATg/BPQgtA7gEA+IgCAdQgBATABAMQAFASACAMQANASADARIAPAfQAJAVgJAOQgSgSgMgHQgVgMgcADQgUASgGAKQgNAUANARQALAeAtAJQAsAIAUgdQAYALAhAbgAyNuSIAVAkQANAUAQAIQALgGABgHIgXgfQgNgTgGgRQgOACgGAOgAxwupQAGATAOASIAbAeQADgDATgMQANgJADgNQgIACgNgBQgOgBgKACIgSgeQgGgKgGAAQgFAAgFAIgAxwv5QgIAGgBAHQAHARANAWIAWAlIAKADQAGACAEgDQgFgPgRgkQgPgfgGgVQgCAEgIAIgAxLwMQgJAKgEAJQAeBBAJAYQAQAGALgKQgFg4gegwQABgCgBgGIgCgIIgQAQgAwewoQgMAIgDALQADASARAjQAPAfACAYIAKADQAGABADgCQAAgGgFgFQgGgFgBgEIAGg/QABglgOgWQgHAFgPAIgAs2wOIASAEQgHgMgXgGQgBADgEADQgEADAAAEIAHgBIAOACgAtkwPIBahFQglgvgMgWIgsAiQgcAUgPAPQgBAAAAAAQAAABgBAAQAAABAAABQAAAAABABIABAGQgWAQgHAHQgPANgHAPQAPAJAfgCIAegBQAPAAAGACgAvAxfQAGAMASgCQASgDABgOIgagCIgBAAQgOAAgCAJgAsxyfQARAsAkAUQAKgFABgHQgagXgSgrQgOADgGALgEAO0gnAIhDAkQgeAQguAeIhKAuQgGADgIAHIgOALQh7BUi6CSQjzC+g6ArQiaB3jmCxImCEoIg3AqIgfAWQgVAPgBAJQAAAHAHALIANASQAOAUAOAIINsqhIFLj8QC/iTCFhuIBshWQA/gzAogpIAMgOQAIgJgIgEIgCAAQgdALgmAUgAdD7ZIAEACQABgGgEgCQgEgDgDADIAAAGIACAAIAEAAgAdQ7yQAEAdAfgFQAwgIAHACQAGgWAHgMQgJADgLAIIgSAMQgTgIgYAAQgKAAgMABgAdr8eQgJAAgEACIgHAOQgGAIABAJQAygCATgHQAjgLAFghQgLgBgNAEQgRAGgFAAQgEADgBAJQgBAJgCACQgQgBAAgNIgOACgAfV9SQhDAZgkALIAUAAQA7gZBkgDQAQgJAMgCIAIgIQAGgFAAgGQg4ABg+AVg");
	this.shape_63.setTransform(44,0.5);

	this.addChild(this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-180.1,-253.6,448.4,508.3);


(lib.grafico = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.7,1,1).p("AYzADIgWAAQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAZQgCIAYAAQACAAAAACQAAADgCAAIgYAAQgDgCAAgBgAXJADIgVAAQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAXkAAIAFgCIAVAAQACAAADACQAAADgFAAIgVAAQgFAAAAgDgAV8ACQgCgCAAAAIAFgCIAVAAQADAAACACQAAADgFAAIgVAAQgCAAgBgBgAVlAAQAAADgFAAIgWAAQgFAAAAgDIAFgCIAWAAQACAAADACgAUTAAIAAgBQABgBABAAIAYAAQADAAAAACQAAADgDAAIgYAAQgCAAAAgDgAT5ADIgZAAQgCAAAAgDIABgBQAAgBABAAIAZAAQACAAAAACQAAADgCAAgAMiAAQAAADgCAAIgYAAQgDgCAAgBIADgCIAYAAQACAAAAACgAM8gCIAZAAQACAAAAACQAAADgCAAIgZAAQgCAAAAgDIABgBQAAgBABAAgAK2gCQACAAAAACQAAADgCAAIgVAAQgFAAAAgDIAFgCgALTgCIAYAAQACAAAAACQAAADgCAAIgYAAQgCgCAAgBgAJMgCQADAAACACQAAADgFAAIgVAAQgCAAgBgBQgCgCAAAAIAFgCgAJsgCIAVAAQADAAACACQAAADgFAAIgVAAQgFAAAAgDgAHoAAQAAADgFAAIgWAAQgFAAAAgDIAFgCIAWAAQACAAADACgAICgCIAWAAQACAAADACQAAADgFAAIgWAAQgFAAAAgDgASpAAIADgCIAYAAQACAAAAACQAAADgCAAIgYAAQgDgCAAgBgASPADIgWAAQgEAAAAgDIAEgCIAWAAQACAAAAACQAAADgCAAgAQlADIgVAAQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgARAAAIAFgCIAVAAQACAAADACQAAADgFAAIgVAAQgFAAAAgDgAPwgCQADAAACACQAAADgFAAIgVAAQgCAAgBgBQgCgCAAAAIAFgCgAOMAAQAAADgFAAIgWAAQgCAAAAgDIAAgBQABgBABAAIAWAAQACAAADACgAOmgCIAWAAQACAAADACQAAADgFAAIgWAAQgFAAAAgDgAgmADIgYAAQgDAAAAgDIABgBQAAgBACAAIAYAAQACAAAAACQAAADgCAAgAgOAAIAEgCIAUAAQADAAACACQAAADgFAAIgUAAQgBAAgCgBQgBgCAAAAgAApgCIAWAAQACAAADACQAAADgFAAIgWAAQgFAAAAgDgAiQADIgYAAQgCgCAAgBIACgCIAYAAQACAAAAACQAAADgCAAgAhzgCIAYAAQACAAAAACQAAADgCAAIgYAAQgCAAAAgDIAAgBQABgBABAAgAjfAAIACgCIAYAAQADAAAAACQAAADgDAAIgYAAQgCgCAAgBgAj1AAQAAADgFAAIgVAAQgFAAAAgDIAFgCIAVAAQADAAACACgAlJAAIAFgCIAWAAQACAAADACQAAADgFAAIgWAAQgFAAAAgDgAljADIgWAAQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAF+AAQAAADgCAAIgYAAQgDAAAAgDIABgBQAAgBACAAIAYAAQACAAAAACgAGYgCIAWAAQADAAACACQAAADgFAAIgWAAQgCAAAAgDIABgBQAAgBABAAgAESgCQACAAAAACQAAADgCAAIgYAAQgCgCAAgBIACgCgAEvgCIAYAAQACAAAAACQAAADgCAAIgYAAQgCgCAAgBgACoADIgVAAQgCAAgBgBQgCgCAAAAIAFgCIAVAAQADAAACACQAAADgFAAgADdgCQADAAACACQAAADgFAAIgVAAQgFAAAAgDIAFgCgABZAAIAFgCIAWAAQACAAADACQAAADgFAAIgWAAQgFAAAAgDgAs3AAQAAADgFAAIgWAAQgBAAgCgBQgBgCAAAAIAEgCIAWAAQADAAACACgAsdgCIAWAAQACAAADACQAAADgFAAIgWAAQgEAAAAgDgAumgCQADAAACACQAAADgFAAIgVAAQgCAAAAgDIAAgBQABgBABAAgAuGgCIAVAAQADAAACACQAAADgFAAIgVAAQgFAAAAgDgAwNgCQADAAAAACQAAADgDAAIgYAAQgCgCAAgBIACgCgAvwgCIAYAAQADAAAAACQAAADgDAAIgYAAQgCAAAAgDIAAgBQABgBABAAgAxxAAQAAADgFAAIgWAAQgFAAAAgDIAFgCIAWAAQACAAADACgAxCgCQADAAAAACQAAADgDAAIgYAAQgCgCAAgBIACgCgAmugCIAWAAQADAAACACQAAADgFAAIgWAAQgEAAAAgDgAn/gCQACAAAAACQAAADgCAAIgYAAQgCAAAAgDIAAgBQABgBABAAgAnigCIAVAAQADAAACACQAAADgFAAIgVAAQgDAAAAgDIABgBQAAgBACAAgAppgCQADAAAAACQAAADgDAAIgYAAQgCgCAAgBIACgCgApMgCIAYAAQADAAAAACQAAADgDAAIgYAAQgCgCAAgBgArNAAQAAADgFAAIgWAAQgFAAAAgDIAFgCIAWAAQACAAADACgAqzgCIAVAAQADAAAAACQAAADgDAAIgVAAQgFAAAAgDgA5lgCIAWAAQACAAADACQAAADgFAAIgWAAQgEAAAAgDgA4ygCIAYAAQACAAAAACQAAADgCAAIgYAAQgDgCAAgBgAzgADIgWAAQgBAAgCgBQgBgCAAAAIAEgCIAWAAQADAAACACQAAADgFAAgAzBgCIAWAAQACAAADACQAAADgFAAIgWAAQgEAAAAgDgA1KADIgVAAQgCAAgBgBQgCgCAAAAIAFgCIAVAAQADAAACACQAAADgFAAgA0vAAIAFgCIAVAAQADAAACACQAAADgFAAIgVAAQgFAAAAgDgA2WAAQAAgBAAAAQABgBABAAIAYAAQADAAAAACQAAADgDAAIgYAAQgCAAAAgDgA2xADIgYAAQgCAAAAgDQAAgBAAAAQABgBABAAIAYAAQADAAAAACQAAADgDAAgA4AAAIACgCIAYAAQADAAAAACQAAADgDAAIgYAAQgCgCAAgBg");
	this.shape.setTransform(60.5,-35.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AZQADQgDgCAAgBIADgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAYdADQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAXpADQgFAAAAgDIAFgCIAVAAQABAAAAAAQABAAAAAAQABABABAAQAAABABAAQAAADgFAAgAW0ADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAV/ADIgDgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIAFgCIAVAAQADAAACACQAAADgFAAgAVKADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAUVADQgCAAAAgDIAAgBIACgBIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgATgADQgCAAAAgDIABgBIABgBIAZAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQAAADgCAAgASsADQgDgCAAgBIADgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAR5ADQgEAAAAgDIAEgCIAWAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgARFADQgFAAAAgDIAFgCIAVAAQABAAAAAAQABAAAAAAQABABABAAQAAABABAAQAAADgFAAgAQQADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAPbADIgDgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIAFgCIAVAAQADAAACACQAAADgFAAgAOmADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgANxADQgCAAAAgDIAAgBIACgBIAWAAQACAAADACQAAADgFAAgAM8ADQgCAAAAgDIABgBIABgBIAZAAQAAAAABAAQAAAAAAAAQAAABABAAQAAABAAAAQAAADgCAAgAMIADQgDgCAAgBIADgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgALTADQgCgCAAgBIACgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAKhADQgFAAAAgDIAFgCIAVAAQABAAAAAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAJsADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAI3ADIgDgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIAFgCIAVAAQADAAACACQAAADgFAAgAICADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAHNADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAGYADQgCAAAAgDIABgBIABgBIAWAAQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAADgFAAgAFkADQgDAAAAgDIABgBIACgBIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAEvADQgCgCAAgBIACgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAD6ADQgCgCAAgBIACgCIAYAAQABAAAAAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgADIADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgACTADIgDgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIAFgCIAVAAQADAAACACQAAADgFAAgABeADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAApADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAgKADIgDgBQAAgBAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAIAEgCIAUAAQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAADgFAAgAg+ADQgDAAAAgDIABgBIACgBIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAhzADQgCAAAAgDIAAgBIACgBIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgAioADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABAAAAQAAABAAAAQAAADgCAAgAjdADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAkPADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAlEADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAl5ADQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAmuADQgEAAAAgDIAEgCIAWAAQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAADgFAAgAniADQgDAAAAgDIABgBIACgBIAVAAQADAAACACQAAADgFAAgAoXADQgCAAAAgDIAAgBIACgBIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgApMADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAqBADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAqzADQgFAAAAgDIAFgCIAVAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAroADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAsdADQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAtSADIgDgBQAAgBAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAIAEgCIAWAAQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAADgFAAgAuGADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgAu7ADQgCAAAAgDIAAgBIACgBIAVAAQADAAACACQAAADgFAAgAvwADQgCAAAAgDIAAgBIACgBIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAwlADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAxaADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgAyMADQgFAAAAgDIAFgCIAWAAQACAAADACQAAADgFAAgAzBADQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAgAz2ADIgDgBQAAgBAAAAQgBgBAAAAQAAAAAAAAQAAAAAAAAIAEgCIAWAAQABAAAAAAQABAAABAAQAAABABAAQAAABABAAQAAADgFAAgA0qADQgFAAAAgDIAFgCIAVAAQADAAACACQAAADgFAAgA1fADIgDgBQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIAFgCIAVAAQADAAACACQAAADgFAAgA2UADQgCAAAAgDIAAgBIACgBIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgA3JADQgCAAAAgDIAAgBIACgBIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgA3+ADQgCgCAAgBIACgCIAYAAQABAAAAAAQABAAAAAAQAAABABAAQAAABAAAAQAAADgDAAgA4yADQgDgCAAgBIADgCIAYAAQAAAAABAAQAAAAABAAQAAABAAAAQAAABAAAAQAAADgCAAgA5lADQgEAAAAgDIAEgCIAWAAQACAAADACQAAADgFAAg");
	this.shape_1.setTransform(60.5,-35.2);

	this.text = new cjs.Text(" ", "12px Times New Roman");
	this.text.lineHeight = 14;
	this.text.setTransform(18.2,-72);

	this.text_1 = new cjs.Text("Probabilidad", "bold 12px Verdana");
	this.text_1.lineHeight = 14;
	this.text_1.setTransform(-62.7,-75.3+incremento);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.7).p("AgZgZIAzAAIAAAzIgzAAg");
	this.shape_2.setTransform(-66.3,-65.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C0C0C0").s().p("AgZAaIAAgzIAzAAIAAAzg");
	this.shape_3.setTransform(-66.4,-66);

	this.text_2 = new cjs.Text("Frecuencia relativa", "bold 12px Verdana");
	this.text_2.lineHeight = 14;
	this.text_2.setTransform(-62.7,-91.1+incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.7).p("AgZgZIAzAAIAAAzIgzAAg");
	this.shape_4.setTransform(-66.3,-81.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF99CC").s().p("AgZAaIAAgzIAzAAIAAAzg");
	this.shape_5.setTransform(-66.4,-81.6);

	this.text_3 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_3.lineHeight = 14;
	this.text_3.setTransform(108.2,91.8);

	this.text_4 = new cjs.Text("Valor del dado", "bold 12px Arial");
	this.text_4.lineHeight = 14;
	this.text_4.setTransform(10.9,99.7+incremento);

	this.text_5 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_5.lineHeight = 14;
	this.text_5.setTransform(204.4,81.9);

	this.text_6 = new cjs.Text(" 6", "bold 12px Verdana");
	this.text_6.lineHeight = 14;
	this.text_6.setTransform(194.4,81.9+incremento);

	this.text_7 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_7.lineHeight = 14;
	this.text_7.setTransform(149.5,81.9);

	this.text_8 = new cjs.Text(" 5", "bold 12px Verdana");
	this.text_8.lineHeight = 14;
	this.text_8.setTransform(139.4,81.9+incremento);

	this.text_9 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_9.lineHeight = 14;
	this.text_9.setTransform(94.8,81.9);

	this.text_10 = new cjs.Text(" 4", "bold 12px Verdana");
	this.text_10.lineHeight = 14;
	this.text_10.setTransform(84.7,81.9+incremento);

	this.text_11 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_11.lineHeight = 14;
	this.text_11.setTransform(40,81.9);

	this.text_12 = new cjs.Text(" 3", "bold 12px Verdana");
	this.text_12.lineHeight = 14;
	this.text_12.setTransform(30,81.9+incremento);

	this.text_13 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_13.lineHeight = 14;
	this.text_13.setTransform(-14.6,81.9);

	this.text_14 = new cjs.Text(" 2", "bold 12px Verdana");
	this.text_14.lineHeight = 14;
	this.text_14.setTransform(-24.7,81.9+incremento);

	this.text_15 = new cjs.Text(" ", "bold 12px Verdana");
	this.text_15.lineHeight = 14;
	this.text_15.setTransform(-69.6,81.9);

	this.text_16 = new cjs.Text(" 1", "bold 12px Verdana");
	this.text_16.lineHeight = 14;
	this.text_16.setTransform(-79.7,81.9+incremento);

	this.text_17 = new cjs.Text(" ", "12px Times New Roman");
	this.text_17.lineHeight = 14;
	this.text_17.setTransform(-105.6,-99);

	this.text_18 = new cjs.Text("0,25", "bold 12px Verdana");
	this.text_18.lineHeight = 14;
	this.text_18.setTransform(-139.1,-100.3+incremento);

	this.text_19 = new cjs.Text(" ", "12px Times New Roman");
	this.text_19.lineHeight = 14;
	this.text_19.setTransform(-107,-65.3);

	this.text_20 = new cjs.Text("0,2", "bold 12px Verdana");
	this.text_20.lineHeight = 14;
	this.text_20.setTransform(-133.8,-66.6+incremento);

	this.text_21 = new cjs.Text(" ", "12px Times New Roman");
	this.text_21.lineHeight = 14;
	this.text_21.setTransform(-105.6,-31.4);

	this.text_22 = new cjs.Text("0,15", "bold 12px Verdana");
	this.text_22.lineHeight = 14;
	this.text_22.setTransform(-139.1,-32.7+incremento);

	this.text_23 = new cjs.Text(" ", "12px Times New Roman");
	this.text_23.lineHeight = 14;
	this.text_23.setTransform(-107,1.4);

	this.text_24 = new cjs.Text("0,1", "bold 12px Verdana");
	this.text_24.lineHeight = 14;
	this.text_24.setTransform(-133.8,0.1+incremento);

	this.text_25 = new cjs.Text(" ", "12px Times New Roman");
	this.text_25.lineHeight = 14;
	this.text_25.setTransform(-105.6,35.2);

	this.text_26 = new cjs.Text("0,05", "bold 12px Verdana");
	this.text_26.lineHeight = 14;
	this.text_26.setTransform(-139.1,33.9+incremento);

	this.text_27 = new cjs.Text(" ", "12px Times New Roman");
	this.text_27.lineHeight = 14;
	this.text_27.setTransform(-108.9,69.1);

	this.text_28 = new cjs.Text("0", "bold 12px Verdana");
	this.text_28.lineHeight = 14;
	this.text_28.setTransform(-115.7,67.8+incremento);

	this.text_29 = new cjs.Text(" ", "12px Times New Roman");
	this.text_29.lineHeight = 14;
	this.text_29.setTransform(-104.9,-48);

	this.text_30 = new cjs.Text("0,166", "bold 8px Verdana");
	this.text_30.lineHeight = 9;
	this.text_30.setTransform(-134.5,-44.1+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_6.setTransform(227.2,78.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_7.setTransform(172.2,78.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_8.setTransform(117.5,78.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_9.setTransform(63.5,78.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_10.setTransform(8.8,78.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_11.setTransform(-45.9,78.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(0.2,1,1).p("AAAAOIAAgb");
	this.shape_12.setTransform(-100.6,78.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_13.setTransform(63.3,77);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_14.setTransform(-102.1,-91.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_15.setTransform(-102.1,-57.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_16.setTransform(-102.1,-23.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_17.setTransform(-102.1,9.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_18.setTransform(-102.1,43.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(0.2,1,1).p("AgOAAIAdAA");
	this.shape_19.setTransform(-102.1,77);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(0.2,1,1).p("AAAtIIAAaR");
	this.shape_20.setTransform(-100.6,-7.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(0.7).p("ABTouIAARdIilAAIAAxdg");
	this.shape_21.setTransform(208.4,21);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#C0C0C0").s().p("AhRIuIAAxcICjAAIAARcg");
	this.shape_22.setTransform(208.2,20.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(0.7).p("ABSouIAARdIijAAIAAxdg");
	this.shape_23.setTransform(153.6,21);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#C0C0C0").s().p("AhRIuIAAxcICjAAIAARcg");
	this.shape_24.setTransform(153.5,20.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(0.7).p("AhRouICjAAIAARdIijAAg");
	this.shape_25.setTransform(98.9,21);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#C0C0C0").s().p("AhRIuIAAxcICjAAIAARcg");
	this.shape_26.setTransform(98.8,20.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(0.7).p("ABSouIAARdIijAAIAAxdg");
	this.shape_27.setTransform(44.9,21);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#C0C0C0").s().p("AhRIuIAAxcICjAAIAARcg");
	this.shape_28.setTransform(44.8,20.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(0.7).p("ABRouIAARdIihAAIAAxdg");
	this.shape_29.setTransform(-9.8,21);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#C0C0C0").s().p("AhQIuIAAxcIChAAIAARcg");
	this.shape_30.setTransform(-10,20.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(0.7).p("ABSouIAARdIijAAIAAxdg");
	this.shape_31.setTransform(-64.7,21);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#C0C0C0").s().p("AhRIuIAAxcICjAAIAARcg");
	this.shape_32.setTransform(-64.8,20.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(0.7).p("ABWGVIirAAIAAspICrAAg");
	this.shape_33.setTransform(191.4,36.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FF99CC").s().p("AhVGVIAAspICrAAIAAMpg");
	this.shape_34.setTransform(191.3,36.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(0.7).p("ABWsmIAAZNIirAAIAA5Ng");
	this.shape_35.setTransform(136.7,-3.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FF99CC").s().p("AhVMnIAA5NICrAAIAAZNg");
	this.shape_36.setTransform(136.6,-3.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(0.7).p("ABSsmIAAZNIikAAIAA5Ng");
	this.shape_37.setTransform(82.4,-3.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FF99CC").s().p("AhRMnIAA5NICjAAIAAZNg");
	this.shape_38.setTransform(82.2,-3.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(0.7).p("ABWCHIirAAIAAkNICrAAg");
	this.shape_39.setTransform(28,63.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FF99CC").s().p("AhVCHIAAkNICrAAIAAENg");
	this.shape_40.setTransform(27.9,63.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(0.7).p("ABWoXIAAQvIirAAIAAwvg");
	this.shape_41.setTransform(-26.6,23.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FF99CC").s().p("AhVIYIAAwvICrAAIAAQvg");
	this.shape_42.setTransform(-26.8,23.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(0.7).p("ABWqfIAAU+IirAAIAA0+g");
	this.shape_43.setTransform(-81.6,9.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FF99CC").s().p("AhVKfIAA0+ICrAAIAAU+g");
	this.shape_44.setTransform(-81.7,9.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#808080").ss(0.7).p("AZnNJMgzNAAAIAA6RMAzNAAAg");
	this.shape_45.setTransform(63.3,-7.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_46.setTransform(63.3,-91.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_47.setTransform(63.3,-57.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_48.setTransform(63.3,-23.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_49.setTransform(63.3,9.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#000000").ss(0.2,1,1).p("A5mAAMAzNAAA");
	this.shape_50.setTransform(63.3,43.1);

	this.addChild(this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_30,this.text_29,this.text_28,this.text_27,this.text_26,this.text_25,this.text_24,this.text_23,this.text_22,this.text_21,this.text_20,this.text_19,this.text_18,this.text_17,this.text_16,this.text_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.shape_5,this.shape_4,this.text_2,this.shape_3,this.shape_2,this.text_1,this.text,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-139.1,-100.3,366.4,217.8);


(lib.Path_3 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Path_0();

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,681,351);


(lib.Path_4 = function() {
	this.initialize();

	// Capa 1
	this.instance_1 = new lib.Path_0_1();

	this.addChild(this.instance_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,572,265);


(lib.Path_5 = function() {
	this.initialize();

	// Capa 1
	this.instance_2 = new lib.Path_0_2();

	this.addChild(this.instance_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,681,351);


(lib.Path_6 = function() {
	this.initialize();

	// Capa 1
	this.instance_3 = new lib.Path_0_3();

	this.addChild(this.instance_3);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,485,211);


(lib.Path_7 = function() {
	this.initialize();

	// Capa 1
	this.instance_4 = new lib.Path_0_4();

	this.addChild(this.instance_4);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,572,265);


(lib.Path_8 = function() {
	this.initialize();

	// Capa 1
	this.instance_5 = new lib.Path_0_5();

	this.addChild(this.instance_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,485,211);


(lib.dadoSuelto3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhoA+QhhgHgagYQgbgXA7gZQA7gaBegNQBcgNBKAIQBKAHAbAYQAbAYgkAYQgkAaheANQg8AIg7AAQgjAAgkgDg");
	this.shape.setTransform(32.5,-78.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhbCzQgmg8AAhiQAAhfAmhKQAmhJA1gHQA2gHAmA8QAmA9AABcQAABbgmBJQgmBKg2AMQgIACgIAAQgrAAgggzg");
	this.shape_1.setTransform(169.1,86.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhbCzQgmg8AAhiQAAhfAmhKQAmhJA1gHQA2gHAmA8QAmA9AABcQAABbgmBJQgmBKg2AMQgIACgIAAQgrAAgggzg");
	this.shape_2.setTransform(120.1,-21);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhFQBEhEBgAAQBhAABFBEQBEBFAABgQAABhhEBFQhFBFhhAAQhgAAhEhFg");
	this.shape_3.setTransform(43.5,104.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AilCmQhEhFAAhhQAAhgBEhFQBFhEBgAAQBhAABEBEQBFBFABBgQgBBhhFBFQhEBFhhAAQhgAAhFhFg");
	this.shape_4.setTransform(-70.4,104.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhEQBEhFBggBQBgABBGBFQBFBEgBBgQABBhhFBFQhGBEhgAAQhgAAhEhEg");
	this.shape_5.setTransform(41.5,-10.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhEQBEhFBggBQBhABBFBFQBEBEAABgQAABhhEBFQhFBEhhAAQhgAAhEhEg");
	this.shape_6.setTransform(-73.4,-10.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EDE7DA").s().p("AhwBOQgMgDgJACQAHgIAfgSQAZgOAFgTQAdgGAVgkQAXgtAOgKIAwA8QAdAeAjAKQg9AZggALQg4AUg1gKQgHABgGAFQgIAGgEABIgCAAQgHAAgKgCg");
	this.shape_7.setTransform(90.5,153.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EDE7DA").s().p("AunQ2QAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAAQgegMgZgfQgNgQgZgrQgDgMgEgeQgEgdgEgMQgBjSgIlyQgLmvgCimQgBhHgFieQgFicgBhVQgBg+AEgxIACg+QABgjAGgUQAIgbAYgWQAPgPAhgXQAigLA2gBQAuAAAnAGQBLgHBtgBIDHgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQDaAFG9gBQGWACEgAaQAvAUAYAzQAOAdAUBRIASBKQAKArADAaQAEAoAAA+IgBBrIAHIUQAEFDABDCQABChgBAzQgBAhAEA/QAAA2gPAjQg6BkhUAuQgOAFgfAFQgeAHgPAFIqpgEQmCAAkPAEQiUADhIAAQh7ABhZgOg");
	this.shape_8.setTransform(-16.6,52);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EDE7DA").s().p("AgdA3QgSgrgFgKQgHgHgWgOQgUgOgHgLQAIgRAjgGQAsgHAJgFQAZgCAigHIA4gQIAGAAQgGARgOAQIgaAbQgHAMgbA+IgOAoQgJAXgJAMQgNgRgNghg");
	this.shape_9.setTransform(89.9,-50.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EDE7DA").s().p("AmhTCQgwgegghFQgSjpgCmVQgDn7gFiVQgIj1ACiXQAAgKAFgPQAEgPAAgGQAAgFgDgNQgEgLABgIQACgVAMgmQALggAMgaQAehDBehbQAOgGBNgaQA4gTAdgUQAKABAMgFQAOgFAHAAQA+geBngnICshDQALgEAQgJIAagPQAHgDAPgEQANgEAIgEQAKgGAZgGIAqgKIAmgHQAWgEALgHIAHAAQAYALARAjQAJAUARAqQACAiAIAiQAIEzgBJQQAAJCAIEoQgHA2gSBMQgHASgPAVIgbAjIgRAJQgKAFgEAHQlaCMmSCNQgNACgNAAQghAAglgLg");
	this.shape_10.setTransform(144.5,29.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#EDE7DA").s().p("ACeDFQh+gFgxAAIrmgGQmngCk0AEQAogcBDgdQAmgQBOgfQCAg2DghTQEGhjBdglQG9gQJhAHQFeAEKHAOQgnARg0ATIhfAgQhZA2hjAXQkABwkKBRQgtAChUAVQhQATgyABIgZAAQg8AAhdgEg");
	this.shape_11.setTransform(34.8,-77.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("A3GUbQhCgigthRQgLg1gChFIABh9QABiDgHj0QgIjyABhyQABhTgHivQgCgtAAhXQAAhZgBgpQgJirgChXQgDiXARhuQBThxDAhFQA5gUBtgrQBwgtA0gTQAwgVB1gsQBkgnA7gcQAqgUAwgKQAmgJA6gFQA8gFCugBQCegBEeADQFLAECAAAQI2AAFAAKQAtAgAbA8QAXAzANBPQgVNtAeOoIgMA6IgMA5QgWAwguApQgFAEgSAJQgPAGgFAJQhXAciXA5QijA8hIAZQgaAJjOBPQiOA3hiAYQjTAJlggFQm3gGiEACQkuAGiYAAIjfAHIg1AAQhjAAhGgKgAGoUPQANADAHgBQAEgBAHgGQAHgFAGAAQA2AJA5gTQAggMA9gYQgjgKgdghIgvg7QgPAJgZAtQgVAmgdAHQgFATgZAOQgfASgHAHIAHAAIAOABgA2atwQg2ABghALQgiAXgPAOQgXAXgIAaQgGAUgBAkIgDA+QgEAxABA+QABBVAGCcQAFCeABBGQACClAKGxQAJFxAADTQAEAMAEAdQAEAeAEAMQAZArANAQQAYAeAeANQABAAABAAQAAAAABAAQAAABAAAAQAAABAAABQBaANB7AAQBHAACVgEQEOgDGFAAIKnADQAOgFAegGQAggGANgEQBVguA5hkQAPgjAAg2QgDg/AAghQABgzgBiiQAAjBgFlDIgHoUIABhrQAAg/gEgoQgDgZgKgrIgShKQgThRgOgdQgYgzgwgVQkggamUgCQm/ACjZgFQgBAAgBABQAAAAgBAAQAAABAAAAQAAABAAABIjIAAQhsABhLAIQglgGgqAAIgHAAgAMgvSQhMAagPAHQhdBbgeBCQgMAagLAgQgNAmgBAWQgBAHADAMQAEAMAAAGQAAAFgFAPQgEAPgBALQgBCWAID1QAFCWADH7QACGUARDqQAgBFAxAeQAzAPAsgGQGViNFaiMQAEgHAJgGIASgJIAagjQAQgVAHgSQAShMAHg1QgJkpABpCQAApPgIk0QgIgigBgiQgRgpgKgUQgQgjgZgMIgGAAQgMAHgVAEIgmAIIgqAKQgZAGgKAFQgIAFgNADQgQAEgHAEIgaAOQgQAKgKAEIitBCQhoAog/AdQgHABgOAFQgMAEgKAAQgcATg5ATgAJDuNQgiAIgbACQgJAFgsAHQgjAFgIARQAHALAUAOQAWAPAHAJQAFAKASArQANAhANAQQALgLAJgXIAOgoQAbhAAHgNIAagaQAOgQAGgRIgGAAIg4APgAsKuIILmAFQAxAAB+AGQByAEBAgBQAyAABQgUQBUgVAtgCQEKhQEAhyQBjgYBZg2IBfggQA0gSAngSQqHgOlegEQphgHm9AQQhdAmkGBiQjgBViAA2QhOAfgmARQhDAcgoAdQDNgDEBAAIENABg");
	this.shape_12.setTransform(36.7,31.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A33D").s().p("EgwlAWBQgyAAgigjQgkgiAAgyMAAAgoTQAAgxAkgjQAigjAygBMBhKAAAQAyABAkAjQAiAjABAxMAAAAoTQgBAygiAiQgkAjgyAAg");
	this.shape_13.setTransform(44,-21.3);

	this.addChild(this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-278.9,-162.3,646,325.8);


(lib.dadoSuelto2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDAvQhMgJgegUQgdgSAVgUQAVgUA8gHQA7gIBLAJQBMAJAwAVQAwASgVATQgWAUhOAHQgjAEgjAAQgoAAgqgFg");
	this.shape.setTransform(137,-48.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag+AtQhJgHgcgTQgdgSAUgRQAUgTA4gIQA4gIBHAHQBIAHAuASQAuASgUARQgTAThKAJQgpAEgoAAQgfAAgggDg");
	this.shape_1.setTransform(245.4,-50.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhKAzQhTgKghgWQgggUAXgVQAYgWBBgIQBBgIBRAKQBUAKA1AWQA1AUgYAVQgXAWhWAIQgmAEglAAQgtAAgvgGg");
	this.shape_2.setTransform(190.4,-32.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhJA1QhTgJghgVQghgWAXgUQAXgWBBgJQBBgKBSAJQBTAIA1AVQA2AVgXAUQgXAWhWAKQgvAFgvAAQgkAAglgDg");
	this.shape_3.setTransform(288.4,-32.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAADJQgvgKghhBQgihBAAhQQAAhSAig2QAhg1AvAGQAwAGAhBBQAiBBAABVQAABWgiA1QgcAtgmAAQgIAAgHgCg");
	this.shape_4.setTransform(113,54.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBVAAA9A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_5.setTransform(257.4,121.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_6.setTransform(257.4,19);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhEAxQhPgIgfgUQgfgUAWgTQAVgUA9gJQA9gJBNAIQBPAHAyAUQAyAUgVASQgWAVhQAJQgtAGgsAAQgiAAgigEg");
	this.shape_7.setTransform(213.1,-43.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAADJQgugKgihBQgihCAAhPQAAhSAig2QAig1AuAGQAwAGAiBBQAhBBAABVQAABWghA1QgdAtgmAAQgHAAgIgCg");
	this.shape_8.setTransform(92.6,104.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAADJQgvgKghhBQgihBAAhQQAAhSAig2QAhg1AvAGQAvAGAjBBQAhBBAABVQAABWghA1QgdAtgmAAQgIAAgHgCg");
	this.shape_9.setTransform(136,9.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA9g9BUAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg8A9hWAAQhUAAg9g9g");
	this.shape_10.setTransform(203.6,121.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBVAAA9A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_11.setTransform(304.4,121.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_12.setTransform(205.4,19);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_13.setTransform(307.1,19);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EDE7DA").s().p("ABJBAQgGgEgGAAQgvAIgxgRQg2gYgcgJQAegIAagbQAPgRAbgkQANAJAUAoQATAfAZAGQAFARAWAMQAcAQAFAHQgIgBgKACIgRACQgEgBgGgGg");
	this.shape_14.setTransform(162.1,163.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#EDE7DA").s().p("AG+PBQjxgDlUAAIpaADQgMgEgbgGQgcgFgMgEQhKgngzhaQgOgeAAgxQADg3AAgdIAAi8QAAiuAEkbIAHnVIgBhfQAAg3ADgkQADgXAJgmIAQhBQARhHAMgaQAVgsAqgUQD+gWFogCIJJgDQABAAAAABQABAAAAAAQABAAAAABQAAAAAAABQA+ABByAAQBgAABCAIQAigGAqAAQAvABAeAJQAeAVANANQAVATAHAYQAFARABAgIACA3QAEAngBA7QgBBLgECKQgFCMgBA+QgCCVgJF7QgIFGAAC6QgEAMgDAZQgEAagDALQgWAlgLAPQgWAbgbALQgBAAAAAAQgBAAAAABQAAAAAAABQAAAAAAABQhPAMhtAAIjCgEg");
	this.shape_15.setTransform(256.8,73.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EDE7DA").s().p("AgMA+QgHgYgFgLQgTgtgLgVIgXgYQgNgOgFgOIAFAAIAyANQAdAHAXACQAIAEAnAGQAeAFAHAPQgGAKgSAMQgTANgGAGQgFAJgPAmQgMAdgLAOQgIgKgIgUg");
	this.shape_16.setTransform(162.6,-16.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#EDE7DA").s().p("AEdQ9Qlfh7k2h+QgEgGgIgFIgQgIIgXgfQgOgSgGgQQgShPgEgkQAHkGAAn+QgBoLAHkQQAIggABgcQAJgRAOglQAPgfAWgKIAFAAQAKAGATADIAiAHIAlAJQAWAFAJAFQAHAEAMADQANAEAGADQAIADAPAJQAPAJAJADICZA7QBZAjA4AaQAGABAMAEQAMAEAIgBQAZASAyARQBDAWAOAGQBSBQAbA7QAdBDAEAlQAAAHgDAKQgDALAAAFQAAAFAEANQAEAOAAAJQACCGgHDXQgFCGgCG+QgCFmgQDOQgcA9grAbQgiAJgdAAIgVgBg");
	this.shape_17.setTransform(114.3,54.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EDE7DA").s().p("AkoCyQgsgBhHgRQhLgSgngCQjvhIjehiQhYgUhPgwQhwglgzgYINwgQQIbgGGJAOQBSAhDnBYQDHBIBxAwIBmAqQA8AaAjAZQkQgEl3ACIqQAFQgpAAhwAFQhRADg0AAIgZAAg");
	this.shape_18.setTransform(211.4,-40.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("ARYSMQiEgGhCAAQhOAAh7gCIjIgEQh1gBmEAFQk2AFi7gJQhXgVh9gwQi1hGgYgIQg+gViSg3QiFgxhNgZQgEgIgOgGQgQgHgEgEQgqglgSgqIgWhlQAbs0gTsPQAMhFAUgtQAXg2ApgcQEhgIHuAAQBzAAEigEQD+gDCKABQCbABA1AFQAyAEAiAHQArAJAlASQA1AZBYAiQBnAoAqASQAuARBjAnQBhAnAyARQCpA8BKBlQAPBhgDCGQgBBNgICXIgBBzQAABLgCAqQgGCaAABJQACBlgHDWQgHDYACB0IAABuQgBA9gKAvQgoBHg7AeQg+AJhYAAIgtAAgAmRR1QAHAFADABIARgCQALgCAIABQgGgHgcgPQgWgNgEgRQgagGgSghQgWgogNgIQgbAkgPAQQgaAdgfAJQAcAIA2AYQAzARAvgIQAGAAAGAFgAOVR1IDCAEQBtAABPgMQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAQAbgLAVgbQAMgOAWgmQADgLADgaQAEgZADgLQABi6AIlHQAJl9ACiTQAAg+AFiMQAEiKABhLQABg7gDgnIgCg2QgBgggFgSQgIgXgUgUQgNgNgegUQgegKgwAAQgpgBgiAGQhCgHhhgBQhxAAg/gBQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIpLACQlmACj+AXQgqATgVAsQgNAagRBIIgQBAQgJAmgCAXQgEAkAAA4IABBeIgGHVQgEEbgBCuIAAC8QABAdgDA4QAAAwANAfQAzBZBLAnQALAEAcAGQAbAFANAEIJYgCIBfAAQEYAADPACgA1hwjQgOAmgJARQgBAbgIAhQgHEPABILQAAH+gHEHQAEAkASBOQAGAQAOATIAXAfIAQAIQAIAFAEAGQE2B+FhB6QAlAFAvgNQArgaAcg9QAQjOAClmQACm/AFiFQAHjXgCiHQAAgJgEgNQgEgNAAgGQAAgFADgKQADgLAAgGQgEglgdhDQgbg8hShPQgOgGhDgXQgygRgZgRQgIAAgMgEQgMgEgGAAQg4gbhbgjIiZg6QgJgEgPgIQgPgKgIgDQgGgDgNgDQgMgDgHgEQgJgGgWgFIglgJIgigGQgTgEgKgGIgFAAQgWAKgPAfgAojsUIAXAYQALAVATAvQAFALAHAYQAIAUAKAKQALgOAMgdQAPgmAFgJQAGgIATgNQASgMAGgKQgHgPgegFQgngGgIgEQgZgCgdgHIgygNIgFAAQAFAOANAOgAmjx1ItwAQQAzAYBwAlQBPAwBYAUQDfBkDuBIQAoACBKASQBHARAsABQA6ABBkgEQBwgFAqAAIKPgFQF3gCEQAEQgjgZg7gaIhngqQhxgwjGhKQjohYhSghQkTgKlaAAQiVAAiiACg");
	this.shape_19.setTransform(209.6,55.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AhcA3QhVgGgYgVQgYgVA1gVQA0gXBTgMQBRgMBCAHQBBAHAYAVQAYAVggAVQggAXhTALQg2AHg0AAQgfAAgfgCg");
	this.shape_20.setTransform(-119.9,-46.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AhQCeQgig1AAhWQAAhUAihCQAihBAugGQAwgGAiA1QAhA2AABSQAABQghBBQgiBBgwAKQgGACgIAAQgmAAgcgtg");
	this.shape_21.setTransform(0.7,99.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AhQCeQgig1AAhWQAAhUAihCQAihBAugGQAvgGAiA1QAiA2AABSQAABPgiBCQgiBBgvAKQgGACgIAAQgmAAgcgtg");
	this.shape_22.setTransform(-42.5,4.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA9g9BUAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg8A9hWAAQhUAAg9g9g");
	this.shape_23.setTransform(-110.2,115.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AiRCSQg9g8AAhWQAAhUA9g9QA8g9BVAAQBWAAA8A9QA9A9AABUQAABWg9A8Qg9A9hVAAQhVAAg8g9g");
	this.shape_24.setTransform(-211,115.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AiRCSQg9g9AAhVQAAhVA9g8QA8g9BVAAQBVAAA9A9QA9A8AABVQAABWg9A8Qg8A9hWAAQhVAAg8g9g");
	this.shape_25.setTransform(-112,13.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AiRCSQg9g9AAhVQAAhVA9g8QA8g9BVAAQBVAAA9A9QA9A8AABVQAABWg9A8Qg8A9hWAAQhVAAg8g9g");
	this.shape_26.setTransform(-213.6,13.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#EDE7DA").s().p("AhjBEQgKgCgIABQAGgGAcgPQAVgNAFgRQAZgGATgfQAUgoANgIQAOAQAbAkQAbAaAeAKQg1AVgdAKQgxASgvgJQgGABgGAFQgGAEgDABIgSgCg");
	this.shape_27.setTransform(-68.7,158.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EDE7DA").s().p("As6O5QAAgBAAAAQAAgBgBAAQAAgBgBAAQAAAAgBAAQgbgLgVgbQgLgOgXgmQgDgLgEgaQgDgZgEgMQAAi7gIlFQgJmCgCiOQAAhCgFiIQgFiNgBhIQgBg3AEgrIACg2QABghAFgRQAHgXAVgVQANgMAegUQAegKAwgBQApAAAiAFQBDgHBggBICvAAQAAgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAQDAAEGJgCQFoACD+AXQAqASAVAtQANAaARBIIAQBAQAJAmACAXQAEAkgBA4IAABdIAGHWQAEEiABCmIAAC9QgBAdADA4QAAAvgNAfQgzBZhLAoQgMAEgbAGQgcAEgMAFIpagCQlTgBjxADQiDAEhAgBQhtAAhOgLg");
	this.shape_28.setTransform(-163.4,68.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#EDE7DA").s().p("AgZAxIgVgvQgGgGgTgNQgSgMgHgKQAIgPAegFQAngGAIgEQAWgCAfgHIAxgNIAGAAQgGAOgMAOIgYAYQgGAMgXA2IgNAjQgIAUgHAKQgLgOgMgdg");
	this.shape_29.setTransform(-69.2,-21.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#EDE7DA").s().p("AlwQ1Qgrgbgcg9QgPjPgCllQgDnEgEiAQgIjRACiMQAAgKAEgNQAEgOAAgEQAAgFgDgLQgDgKABgHQABgTAMghQAJgcALgYQAag6BThRQANgGBDgWQAygRAZgSQAJABALgEQAMgEAGgBQA4gaBagjICZg7QAIgDAPgJIAXgMQAHgDANgEQAMgDAGgEQAJgFAWgFIAlgJIAigHQATgDAKgGIAGAAQAVAKAPAfIAYA2QAAAeAIAeQAHEQAAILQgBH+AIEGQgGAqgQBJQgHAQgNASIgYAfIgPAIQgJAFgDAGQk3B+leB7IgWABQgdAAgigJg");
	this.shape_30.setTransform(-20.9,49.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#EDE7DA").s().p("ACLCvQhwgFgqAAIqQgFQl2gCkQAEQAkgZA7gaIBmgqQBxgwDHhIQDnhYBSghQGIgOIbAGQE1AEI8AMQg1AYhvAlQhPAwhWAUQjeBhjwBJQgoAChKASQhIARgrABIgZAAQg0AAhRgDg");
	this.shape_31.setTransform(-117.9,-45.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("A0aSDQg8gfgmhGQgKgvgCg9IABhuQABh2gHjWQgGjYABhjQABhSgHiRQgBgqAAhLIgBhzQgIiXgChNQgDiGAPhhQBKhkCpg9QAygRBhgnQBignAvgRQArgSBngoQBYgiA1gZQAlgSAqgJQAigHAzgEQA0gFCbgBQCKgBD+ADQEiAEBzAAQHvAAEhAIQAoAcAYA2QAUAtALBFQgSMKAaM5IgVBlQgSAqgrAlQgEAEgQAHQgNAGgFAIQhNAZiFAxQiTA3g8AVQgYAIi1BGQh+AwhXAVQi6AJk3gFQmEgFh1ABQkLAGiGAAIjGAGIgtAAQhYAAg+gJgAF3R5IARACQAEgBAGgFQAGgFAGAAQAvAIAzgRQAcgKA2gWQgfgJgagdQgbgjgOgRQgNAIgWAoQgTAhgZAGQgFARgWANQgcAPgFAHIAFgBIANACgAzzsJQgvAAgeAKQgfAVgMAMQgVAUgHAXQgGASAAAgIgCA2QgEArABA3QABBJAECMQAFCJABBBQACCMAJGEQAHFFABC8QADALAEAZQADAaADALQAXAmALAOQAWAbAaALQABAAABAAQAAAAABABQAAAAAAABQAAAAAAABQBPAMBtAAQA/AACDgEQDxgDFWABIJXACQANgEAbgFQAcgGAMgEQBLgoAyhYQAOgfgBgwQgCg4AAgdIAAi8QAAingEkiIgHnVIABheQAAg4gEgkQgCgWgJgnIgQhAQgRhHgMgbQgWgsgqgTQj+gXllgCQmLACjAgEQgBAAgBAAQAAAAgBAAQAAABAAAAQAAAAAAABIiwABQhgABhCAHQgggFglAAIgHAAgALDtgQhDAXgNAGQhTBQgaA7QgLAXgJAcQgMAhgBAUQgBAGADALQADAKAAAFQAAAFgEAOQgEANAAAJQgCCNAIDRQAECAADHEQACFlAPDPQAcA8ArAbQAvANAmgFQFgh7E3h9QADgGAJgFIAPgIIAYgfQANgTAHgQQAQhJAGgpQgIkHABn+QAAoLgHkPQgIgeAAgeIgYg3QgPgfgVgKIgGAAQgKAGgTAEIgiAGIglAJQgWAFgJAGQgGADgMAEQgNADgHADIgXANQgPAIgIAEIiZA6QhcAkg4AaQgGAAgMAEQgLAEgJAAQgZARgyARgAIAsjQgeAHgZACQgIAEgmAGQgfAFgHAPQAGAKASAMQATANAGAIIAVAvQAMAdALAOQAKgKAHgUIANgjQAXg4AHgMIAXgYQAMgOAGgOIgGAAIgxANgAqvsfIKPAFQAqAABxAFQBkAEA5gBQAsgBBHgRQBKgSAogCQDwhJDehjQBXgUBPgwQBvglA1gYQo8gMk1gEQocgGmIAOQhSAhjnBYQjHBKhxAwIhmAqQg7AagjAZQCsgDDXAAIEDABg");
	this.shape_32.setTransform(-116.2,50.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#00A33D").s().p("EgwlAWBQgyAAgigjQgkgiAAgyMAAAgoTQAAgxAkgjQAigjAygBMBhKAAAQAyABAkAjQAiAjABAxMAAAAoTQgBAygiAiQgkAjgyAAg");
	this.shape_33.setTransform(44,-21.3);

	this.addChild(this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-278.9,-162.3,646,334.8);


(lib.dadoSuelto1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhoA+QhhgHgagYQgbgXA7gZQA7gaBegNQBcgNBKAIQBKAHAbAYQAbAYgkAYQgkAaheANQg8AIg7AAQgjAAgkgDg");
	this.shape.setTransform(124.5,-86.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhoA+QhhgHgagYQgbgXA7gZQA7gaBegNQBcgNBKAIQBKAHAbAYQAbAYgkAYQgkAaheANQg8AIg7AAQgjAAgkgDg");
	this.shape_1.setTransform(-51.4,-70.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhbCzQgmg8AAhiQAAhfAmhKQAmhJA1gHQA2gHAmA8QAmA9AABcQAABbgmBJQgmBKg2AMQgIACgIAAQgrAAgggzg");
	this.shape_2.setTransform(146.1,24.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AilCmQhEhFAAhhQAAhgBEhFQBFhEBgAAQBhAABEBEQBFBFABBgQgBBhhFBFQhEBFhhAAQhgAAhFhFg");
	this.shape_3.setTransform(-70.4,104.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AikCmQhFhFgBhhQABhgBFhEQBEhFBggBQBgABBGBFQBFBEgBBgQABBhhFBFQhGBEhgAAQhgAAhEhEg");
	this.shape_4.setTransform(41.5,-10.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AikCmQhGhFABhhQgBhgBGhFQBEhFBgAAQBgAABFBFQBGBFgBBgQABBhhGBFQhFBFhgAAQhgAAhEhFg");
	this.shape_5.setTransform(-22.4,44.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#EDE7DA").s().p("AhwBOQgMgDgJACQAHgIAfgSQAZgOAFgTQAdgGAVgkQAXgtAOgKIAwA8QAdAeAjAKQg9AZggALQg4AUg1gKQgHABgGAFQgIAGgEABIgCAAQgHAAgKgCg");
	this.shape_6.setTransform(90.5,153.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#EDE7DA").s().p("AunQ2QAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAAQgegMgZgfQgNgQgZgrQgDgMgEgeQgEgdgEgMQgBjSgIlyQgLmvgCimQgBhHgFieQgFicgBhVQgBg+AEgxIACg+QABgjAGgUQAIgbAYgWQAPgPAhgXQAigLA2gBQAuAAAnAGQBLgHBtgBIDHgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABgBQDaAFG9gBQGWACEgAaQAvAUAYAzQAOAdAUBRIASBKQAKArADAaQAEAoAAA+IgBBrIAHIUQAEFDABDCQABChgBAzQgBAhAEA/QAAA2gPAjQg6BkhUAuQgOAFgfAFQgeAHgPAFIqpgEQmCAAkPAEQiUADhIAAQh7ABhZgOg");
	this.shape_7.setTransform(-16.6,52);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EDE7DA").s().p("AgdA3QgSgrgFgKQgHgHgWgOQgUgOgHgLQAIgRAjgGQAsgHAJgFQAZgCAigHIA4gQIAGAAQgGARgOAQIgaAbQgHAMgbA+IgOAoQgJAXgJAMQgNgRgNghg");
	this.shape_8.setTransform(89.9,-50.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EDE7DA").s().p("AmhTCQgwgegghFQgSjpgCmVQgDn7gFiVQgIj1ACiXQAAgKAFgPQAEgPAAgGQAAgFgDgNQgEgLABgIQACgVAMgmQALggAMgaQAehDBehbQAOgGBNgaQA4gTAdgUQAKABAMgFQAOgFAHAAQA+geBngnICshDQALgEAQgJIAagPQAHgDAPgEQANgEAIgEQAKgGAZgGIAqgKIAmgHQAWgEALgHIAHAAQAYALARAjQAJAUARAqQACAiAIAiQAIEzgBJQQAAJCAIEoQgHA2gSBMQgHASgPAVIgbAjIgRAJQgKAFgEAHQlaCMmSCNQgNACgNAAQghAAglgLg");
	this.shape_9.setTransform(144.5,29.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#EDE7DA").s().p("ACeDFQh+gFgxAAIrmgGQmngCk0AEQAogcBDgdQAmgQBOgfQCAg2DghTQEGhjBdglQG9gQJhAHQFeAEKHAOQgnARg0ATIhfAgQhZA2hjAXQkABwkKBRQgtAChUAVQhQATgyABIgZAAQg8AAhdgEg");
	this.shape_10.setTransform(34.8,-77.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("A3GUbQhCgigthRQgLg1gChFIABh9QABiDgHj0QgIjyABhyQABhTgHivQgCgtAAhXQAAhZgBgpQgJirgChXQgDiXARhuQBThxDAhFQA5gUBtgrQBwgtA0gTQAwgVB1gsQBkgnA7gcQAqgUAwgKQAmgJA6gFQA8gFCugBQCegBEeADQFLAECAAAQI2AAFAAKQAtAgAbA8QAXAzANBPQgVNtAeOoIgMA6IgMA5QgWAwguApQgFAEgSAJQgPAGgFAJQhXAciXA5QijA8hIAZQgaAJjOBPQiOA3hiAYQjTAJlggFQm3gGiEACQkuAGiYAAIjfAHIg1AAQhjAAhGgKgAGoUPQANADAHgBQAEgBAHgGQAHgFAGAAQA2AJA5gTQAggMA9gYQgjgKgdghIgvg7QgPAJgZAtQgVAmgdAHQgFATgZAOQgfASgHAHIAHAAIAOABgA2atwQg2ABghALQgiAXgPAOQgXAXgIAaQgGAUgBAkIgDA+QgEAxABA+QABBVAGCcQAFCeABBGQACClAKGxQAJFxAADTQAEAMAEAdQAEAeAEAMQAZArANAQQAYAeAeANQABAAABAAQAAAAABAAQAAABAAAAQAAABAAABQBaANB7AAQBHAACVgEQEOgDGFAAIKnADQAOgFAegGQAggGANgEQBVguA5hkQAPgjAAg2QgDg/AAghQABgzgBiiQAAjBgFlDIgHoUIABhrQAAg/gEgoQgDgZgKgrIgShKQgThRgOgdQgYgzgwgVQkggamUgCQm/ACjZgFQgBAAgBABQAAAAgBAAQAAABAAAAQAAABAAABIjIAAQhsABhLAIQglgGgqAAIgHAAgAMgvSQhMAagPAHQhdBbgeBCQgMAagLAgQgNAmgBAWQgBAHADAMQAEAMAAAGQAAAFgFAPQgEAPgBALQgBCWAID1QAFCWADH7QACGUARDqQAgBFAxAeQAzAPAsgGQGViNFaiMQAEgHAJgGIASgJIAagjQAQgVAHgSQAShMAHg1QgJkpABpCQAApPgIk0QgIgigBgiQgRgpgKgUQgQgjgZgMIgGAAQgMAHgVAEIgmAIIgqAKQgZAGgKAFQgIAFgNADQgQAEgHAEIgaAOQgQAKgKAEIitBCQhoAog/AdQgHABgOAFQgMAEgKAAQgcATg5ATgAJDuNQgiAIgbACQgJAFgsAHQgjAFgIARQAHALAUAOQAWAPAHAJQAFAKASArQANAhANAQQALgLAJgXIAOgoQAbhAAHgNIAagaQAOgQAGgRIgGAAIg4APgAsKuIILmAFQAxAAB+AGQByAEBAgBQAyAABQgUQBUgVAtgCQEKhQEAhyQBjgYBZg2IBfggQA0gSAngSQqHgOlegEQphgHm9AQQhdAmkGBiQjgBViAA2QhOAfgmARQhDAcgoAdQDNgDEBAAIENABg");
	this.shape_11.setTransform(36.7,31.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A33D").s().p("EgwlAWBQgyAAgigjQgkgiAAgyMAAAgoTQAAgxAkgjQAigjAygBMBhKAAAQAyABAkAjQAiAjABAxMAAAAoTQgBAygiAiQgkAjgyAAg");
	this.shape_12.setTransform(44,-21.3);

	this.addChild(this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-278.9,-162.3,646,325.8);


(lib.dados3_6 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape.setTransform(185.2,96.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_1.setTransform(185.2,96.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_2.setTransform(152.2,80.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_3.setTransform(152.2,80.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.6,1,1).p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQg0Aig9gkg");
	this.shape_4.setTransform(185.2,114.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_5.setTransform(185.2,114.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_6.setTransform(151.2,116.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_7.setTransform(151.2,116.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_8.setTransform(187.2,78.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_9.setTransform(187.2,78.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_10.setTransform(152.2,98.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_11.setTransform(152.2,98.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_12.setTransform(-252.4,233);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_13.setTransform(-231.1,195.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_14.setTransform(-196.1,107.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_15.setTransform(-168.4,28.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_16.setTransform(-150.8,-25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_17.setTransform(-133,-79.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_18.setTransform(-103.4,-135);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_19.setTransform(-48.1,183.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_20.setTransform(-52.8,-205.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_21.setTransform(-72.9,-189);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_22.setTransform(-81.3,-172);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_23.setTransform(-41.6,41.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_24.setTransform(-20.5,-118.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_25.setTransform(-36.6,-13.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_26.setTransform(72.7,-263.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_27.setTransform(-13.3,-154.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_28.setTransform(-47,-20.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_29.setTransform(-14.2,-248.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_30.setTransform(45.7,-24.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_31.setTransform(15.6,88.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_32.setTransform(88.1,-187.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_33.setTransform(15.8,-221.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_34.setTransform(40.8,36.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_35.setTransform(76.1,-91.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_36.setTransform(61.2,-189.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_37.setTransform(80.2,-138.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_38.setTransform(90.5,-79.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_39.setTransform(52.4,-279.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_40.setTransform(128.2,-201.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_41.setTransform(146,-142.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_42.setTransform(119.9,-95.1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_43.setTransform(168.7,96.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_44.setTransform(108.8,-101.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_45.setTransform(122.9,-177.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_46.setTransform(152,81.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_47.setTransform(154.1,110.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_48.setTransform(100.3,-167.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_49.setTransform(184.9,80.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_50.setTransform(185.5,109.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_51.setTransform(169,96.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_52.setTransform(44,-27.9);

	this.addChild(this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.9,-336.7,654,584.4);


(lib.dados3_5 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape.setTransform(152.2,78.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_1.setTransform(152.2,78.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_2.setTransform(186.2,112.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_3.setTransform(186.2,112.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.6,1,1).p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQg0Aig9gkg");
	this.shape_4.setTransform(151.2,114.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_5.setTransform(151.2,114.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_6.setTransform(187.2,78.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_7.setTransform(187.2,78.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_8.setTransform(168.2,95.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_9.setTransform(168.2,95.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_10.setTransform(-252.4,233);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_11.setTransform(-231.1,195);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_12.setTransform(-196.1,107.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_13.setTransform(-168.4,28.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_14.setTransform(-150.8,-25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_15.setTransform(-133,-79.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_16.setTransform(-103.4,-135);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_17.setTransform(-48.1,183.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_18.setTransform(-52.8,-205.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_19.setTransform(-72.9,-189);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_20.setTransform(-81.3,-172);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_21.setTransform(-41.6,41.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_22.setTransform(-20.5,-118.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_23.setTransform(-36.6,-13.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_24.setTransform(72.7,-264);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_25.setTransform(-13.3,-154.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_26.setTransform(-47,-20.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_27.setTransform(-14.2,-248.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_28.setTransform(45.7,-24.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_29.setTransform(15.6,88.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_30.setTransform(88.1,-187.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_31.setTransform(15.8,-221.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_32.setTransform(40.8,36.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_33.setTransform(76.1,-91.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_34.setTransform(61.2,-189.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_35.setTransform(80.2,-138.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_36.setTransform(90.5,-80);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_37.setTransform(52.4,-279.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_38.setTransform(128.2,-201.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_39.setTransform(146,-142.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_40.setTransform(119.9,-95.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_41.setTransform(168.7,96.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_42.setTransform(108.8,-101.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_43.setTransform(122.9,-177.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_44.setTransform(152,81.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_45.setTransform(154.1,110.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_46.setTransform(100.3,-168);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_47.setTransform(184.9,80.3);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_48.setTransform(185.5,109.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_49.setTransform(169,96.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_50.setTransform(44,-27.9);

	this.addChild(this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.9,-336.7,654,584.4);


(lib.dados3_4 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape.setTransform(152.2,78.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_1.setTransform(152.2,78.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_2.setTransform(186.2,112.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_3.setTransform(186.2,112.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.6,1,1).p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQg0Aig9gkg");
	this.shape_4.setTransform(151.2,114.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_5.setTransform(151.2,114.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_6.setTransform(187.2,78.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_7.setTransform(187.2,78.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_8.setTransform(-252.4,233);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_9.setTransform(-231.1,195.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_10.setTransform(-196.1,107.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_11.setTransform(-168.4,28.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_12.setTransform(-150.8,-25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_13.setTransform(-133,-79.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_14.setTransform(-103.4,-135);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_15.setTransform(-48.1,183.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_16.setTransform(-52.8,-205.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_17.setTransform(-72.9,-189);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_18.setTransform(-81.3,-172);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_19.setTransform(-41.6,41.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_20.setTransform(-20.5,-118.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_21.setTransform(-36.6,-13.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_22.setTransform(72.7,-263.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_23.setTransform(-13.3,-154.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_24.setTransform(-47,-20.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_25.setTransform(-14.2,-248.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_26.setTransform(45.7,-24.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_27.setTransform(15.6,88.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_28.setTransform(88.1,-187.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_29.setTransform(15.8,-221.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_30.setTransform(40.8,36.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_31.setTransform(76.1,-91.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_32.setTransform(61.2,-189.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_33.setTransform(80.2,-138.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_34.setTransform(90.5,-79.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_35.setTransform(52.4,-279.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_36.setTransform(128.2,-201.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_37.setTransform(146,-142.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_38.setTransform(119.9,-95.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_39.setTransform(168.7,96.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_40.setTransform(108.8,-101.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_41.setTransform(122.9,-177.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_42.setTransform(152,81.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_43.setTransform(154.1,110.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_44.setTransform(100.3,-167.9);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_45.setTransform(184.9,80.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_46.setTransform(185.5,109.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_47.setTransform(169,96.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_48.setTransform(44,-27.9);

	this.addChild(this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.9,-336.7,654,584.4);


(lib.dados3_3 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgzAig+gkg");
	this.shape.setTransform(152.6,113.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgdAAgggSg");
	this.shape_1.setTransform(152.6,113.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_2.setTransform(167.9,94);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeABgfgTg");
	this.shape_3.setTransform(167.9,94);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_4.setTransform(185.2,77.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_5.setTransform(185.2,77.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_6.setTransform(-252.4,232);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_7.setTransform(-231.1,194.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_8.setTransform(-196.1,106.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_9.setTransform(-168.4,27.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_10.setTransform(-150.8,-26);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_11.setTransform(-133,-80.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_12.setTransform(-103.4,-136);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_13.setTransform(-48.1,182.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_14.setTransform(-52.8,-206.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_15.setTransform(-72.9,-190);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_16.setTransform(-81.3,-173);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_17.setTransform(-41.6,40.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_18.setTransform(-20.5,-119.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_19.setTransform(-36.6,-14.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_20.setTransform(72.7,-264.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_21.setTransform(-13.3,-155.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_22.setTransform(-47,-21.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_23.setTransform(-14.2,-249.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_24.setTransform(45.7,-25.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_25.setTransform(15.6,87.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_26.setTransform(88.1,-188.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_27.setTransform(15.8,-222.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_28.setTransform(40.8,35.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_29.setTransform(76.1,-92.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_30.setTransform(61.2,-190.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_31.setTransform(80.2,-139.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_32.setTransform(90.5,-80.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_33.setTransform(52.4,-280.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_34.setTransform(128.2,-202.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_35.setTransform(146,-143.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_36.setTransform(119.9,-96.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_37.setTransform(168.7,95.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_38.setTransform(108.8,-102.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_39.setTransform(122.9,-178.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_40.setTransform(152,80.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_41.setTransform(154.1,109.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_42.setTransform(100.3,-168.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_43.setTransform(184.9,79.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_44.setTransform(185.5,108.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_45.setTransform(169,95.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_46.setTransform(44,-28.9);

	this.addChild(this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.9,-337.7,654,584.4);


(lib.dados3_2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQg0Aig9gkg");
	this.shape.setTransform(158.5,105.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_1.setTransform(158.5,105.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape_2.setTransform(179.5,81.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_3.setTransform(179.5,81.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_4.setTransform(-252.1,231.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_5.setTransform(-230.8,193.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_6.setTransform(-195.7,106.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_7.setTransform(-168,26.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_8.setTransform(-150.4,-26.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_9.setTransform(-132.6,-80.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_10.setTransform(-103,-136.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_11.setTransform(-47.7,181.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_12.setTransform(-52.4,-206.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_13.setTransform(-72.5,-190.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_14.setTransform(-81,-173.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_15.setTransform(-41.3,40);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_16.setTransform(-20.1,-120.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_17.setTransform(-36.3,-15.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_18.setTransform(73.1,-265.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_19.setTransform(-13,-155.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_20.setTransform(-46.7,-21.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_21.setTransform(-13.8,-249.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_22.setTransform(46.1,-26);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_23.setTransform(16,87.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_24.setTransform(88.5,-189.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_25.setTransform(16.2,-223);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_26.setTransform(41.2,35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_27.setTransform(76.5,-92.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_28.setTransform(61.5,-191.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_29.setTransform(80.6,-140.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_30.setTransform(90.9,-81.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_31.setTransform(52.7,-280.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_32.setTransform(128.6,-203.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_33.setTransform(146.3,-144.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_34.setTransform(120.2,-96.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_35.setTransform(169.1,95.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_36.setTransform(109.2,-102.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_37.setTransform(123.2,-179.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_38.setTransform(152.4,79.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_39.setTransform(154.4,108.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_40.setTransform(100.6,-169.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_41.setTransform(185.2,78.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_42.setTransform(185.9,107.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_43.setTransform(169.4,94.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape_44.setTransform(44.4,-29.3);

	this.addChild(this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.6,-338.1,654,584.4);


(lib.dados3_1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6,1,1).p("ABKgyQAXBKg3AjQg0Aig9gkQgahTA4giQA0ghA/Arg");
	this.shape.setTransform(168.5,93.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhHA5QgahTA4giQA0ghA/ArQAXBKg3AjQgaAQgaAAQgeAAgfgSg");
	this.shape_1.setTransform(168.5,93.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,0,0,4).p("ABQiPIidEcIgBAE");
	this.shape_2.setTransform(-252.1,231.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiYEQQgGgMAJgXQAGgQAJgNQAbghALgmQATgbAVgqIAkhHQAfgqAuhhQAwhlAdgoIAVAJIhWC3QgzBngwA/IgFAVQgEANAAAJQgaAbgcA0IguBXQgKgDgDgJg");
	this.shape_3.setTransform(-230.8,193.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AjWJNQAGgmAggmQANgrA1hyQAshfANhGQAPgPAKgiQALgmAHgSIAAg0QAVg7AFhIQAthmAxiPIBUj/IAVAHQgFA6glBlQgkBfgCBEQgyBAgcBuQgTBMgRCJQg4BzgXBeQgVAhgIASQgPAegDAhQgpA6gvBig");
	this.shape_4.setTransform(-195.7,106.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhRDCQBQj6A/iQIAUAGQhMD0hCCXg");
	this.shape_5.setTransform(-168,26.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhwFMQAdiWBAjAQBKjZAjhvIAXAIIAAArQgzB7g6C2IhgFBg");
	this.shape_6.setTransform(-150.4,-26.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhWDMQAUg/ASg+QA8ieA1iEIAWAIQgTAwg2ChQgrCFgiBJg");
	this.shape_7.setTransform(-132.6,-80.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AjlFWIAzh8IAXggQAOgTAKgLQABgHgEgJQgEgJACgIQA+hLBaieQBhirA1hFIARAKIhgClQg6BjglBAQAsgPAQg0QBShSBLhvIAVAPIgtBGQgbAsgVAaQgGAIgRANQgRANgHAJQgHAIgKAUQgKAVgGAHQgHAJgRALQgRANgHAIIg6BJQgmAvgZAbQgDAYgOAWIgaAoQAAAQgIAWQgJAZgCAMQgCADgQAFQgLAFgEAGg");
	this.shape_8.setTransform(-103,-136.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AmyKDIgfAAQAag8B0j9QBZjAAwiBQAUgSAZgqQAeg0AKgOQAIgFAVgUQATgQAOgGQBRhkCdiQQDAixA4g6IATAMQgHAJgCAMQg0AyhsBgQhdBXg3BHQgNAEgUASQgUAQgOAEIhGBQQgnAtgkAbQgKAZgUAaQgGAJgeAjIgUAvQgNAbgPAOQgkBnhKCUQheC9gYA1QgKAogQAog");
	this.shape_9.setTransform(-47.7,181.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AknGrQA+hcBBh9QAshTBGiSQgBgEgGAAIgUgOQBihtALgKQBBhBBBgiQAggkAeg0QAVgjAeg/IAZANQgMAagTAwIgfBKQAZAIAdACIgCATQgYALgwAMQg5ANgSAGQgWARgmAkQgmAkgVAQQgNAhg0BhQgsBQgRA7QgeAngdA3QgTAlgfBEQgbAcggAyg");
	this.shape_10.setTransform(-52.4,-206.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AiJC8QAWg4A8hdQA8heAWg2QAqgiAxg3IAUAOIgCAAQhxCLiPDzg");
	this.shape_11.setTransform(-72.5,-190.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFC9B6").s().p("AiEDBIBhilQCPjzBwiLIADAAQAFAAACAEQhHCUgrBTQhBB7g9BcQhLBvhSBSQgQA0guAPQAnhAA6hjg");
	this.shape_12.setTransform(-81,-173.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgECbIgOiiQgOjJAkhjIAOAAQALAbgLAtIgSBQQgCAwAOC4QANCZgVBOQgBg3gHhig");
	this.shape_13.setTransform(-41.3,40);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("Ai0JHQAShbgUg1QAEhEAEgfQAFg3APggQgKkoBekGQBYj3CoivIAaACQgbAvgwBAIhPBpQgHAbgPAcIgeAtQgdA6gfB2QgjCMgSAsQgFAlgHCWQgGB9gTBDQAABfgFBEQgGBSgSBDIgNAvQgJAagQANIAfiRg");
	this.shape_14.setTransform(-20.1,-120.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgCAWQgCiJgMheIARgYQAEgBAEADQAEADACAAQgBAaADDPQACCRgVBUQABiGgBhOg");
	this.shape_15.setTransform(-36.3,-15.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("ArpLVQBDi3AeheQA0ilADiEQgTgygLgWQgUgogfgLQAEBEgkBaQgVAzgvBeQgXgDhRAWQg9AQgdgeIACgTQA3AEBagOQAwguAchKQAchKAAhRQgWgIgKgFQgRgJgDgOQhFALgwAuQgnAmghBDIgZgMQAyhpAMgXQBUgtAJgEQA9gZA3ATQAwgkBthzQBfhkBHgrQANgRAZgjQDdh5Cvi7QARgEAWgMQAbgOAKgEQAhgDAgAJQATAFAjANQAGANAaAsQAVAjAIAbQgXCShsBwQgtAvioB+QhTBgglAtQhCBOgvBFQAkgGBGgbQBPgeAigJQA7gbBegzQBwhAAogUQC5heC6gHIB2gnQBDgXArgYQAlgBAdAPQARAJAeAZQAGAMAHAXIALAkQgKA2ABAfQgPAZgTAnIghA/QheBXjXBnQjxBzhTA+IgQgXQBAguAxgqQAVgEAggYQAfgWAZgDQgJgZgXglQgagqgIgTQgagfgMgRQgWgfAIgeQAZAJATAjQAbAyAFAGIAcA7QARAiAQAUQBZgQBgg7ICihkQAwg4AWg5QAdhNgYhFQgmgyg/ASQhNAigoAMQg5AShnAUQiUAcgYAFQkTCOgqAUQi1BbiaA2QhUBAhyCCQiLCfgwAtQgPBHgnBFgAorGaQgUAUgcABQAAAGgGAOQgFALACALQAfgVAYgYQAdgeAGgYQgVAYgMAMgABkqhIhKAiQhMByiMBHQgGANgSANIgcAVQhVAqhmBjQiLCGgeAYQgFATgbAZQgaAYgEAWQBWAjAOCEQALBlgeB8QAVgZAqgkQAygrAPgPQgDgSgzgwQgmglAagZIAsA1QAYAgAMAdQBbhHByiSQCSi7ArgtQgIgYgTgbQgMgSgbgeQgfgcgMgPQgWgcARgYQAhAbArA9QAxBFAWAXIBahFQAzgoAggkQBVhgAGiGQgIgXgRgVQgLgPgVgVQgWgFgVAAQgcAAgaAJg");
	this.shape_16.setTransform(73.1,-265.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgUAMQgXgvARguIAOAAQAFAqAMArQAJAaAUA0QgjgfgTgng");
	this.shape_17.setTransform(-13,-155.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFC9B6").s().p("EghMAp2IgHgDICKj5QADAJAKADIAuhXQAcg0AagbQAAgJAEgNIAFgVQAyg/AzhpIBWi3QAwhiAog6QAEghAOgeQAJgSAVghQAWheA6hzQARiLAThMQAdhuAxhAQAChEAkhfQAmhlAFg6QBEiXBMj2IBhk+QA6i4A0h8IAAgqQAihKAsiEQA3ikATgwQAEgGALgFQAPgGADgCQABgMAJgZQAIgWABgRIAZgnQAOgXAEgXQAZgbAmgvIA8hJQAHgIARgNQAQgOAHgIQAHgIAKgUQAKgUAGgJQAHgIASgNQAQgNAHgIQAUgbAbgrIAthHQAhgxAbgdQAfhEATgkQAdg3AegoQARg6ArhQQA2hjAOghQAVgQAkgkQAmglAVgQQATgGA4gOQAwgLAYgLQAeAeA8gQQBSgWAXADQAvheAUgzQAlhagEhEQAfALATAoQAMAWASAyQgCCEg1ClQgeBehDC3QinCuhaD3QheEGAKErQgPAfgGA3QgDAggFBDQAVA1gSBbIgfCRQAQgMAJgbIANgvQARhDAHhSQAFhEgBhfQAUhDAGh8QAHiZAFgkQASgtAjiLQAfh3Aeg5IAfguQAPgbAGgbIBQhqQAwg/AbgvQAmhFAQhHQAwgtCLifQByiCBThAQCag2C3hbQArgUETiQQAYgFCTgcQBogUA5gSQAogMBMgiQBAgSAmAyQAXBFgdBNQgVA6gxA5IihBkQhhA7hYAQQgQgUgRgiIgdg7QgFgGgbgyQgSgjgagJQgIAeAWAfQAMARAaAfQAJATAZAqQAYAlAJAZQgaADgeAWQggAYgVAEQgxAqhBAuQhIA0iFBVQiVBfg7AoQgSgSgTgnQgYgwgKgOQgKgMgTg3QgQgtgagLQgLAcAYAoQANAXAaAqQAOAfAYAkIArA9QhjCBg6BCQhaBnhVBIQgFALgHAZQgIAUgNAGQgUgrg3gsQhHg5gQgSQgHgHgNgpQgLgggVgFQgUASARAgQAaAwABAGQAZAaAqAhIBGA3QAjA0AoBJIBECDIgPATQAEAVAeBJQAaBAACAuQBIBjAlBgQACAIAOAFQAPAEACAHQAAACgHALQgFAHAIAIQARAxAjA3QAUAhArA+QBMB1AIBxIAAADQgMAcgFA2QgGBCgGAWQgQBHgfBHQgfBKgjArQgBgLgJgRQgJgQAAgNQgngxhahJQhghMgkgqQgng8hEhVIhwiLQgKgJgUgvQgQgngUAAQgCAcAQAhQAIAPAaAmQAPAWBgB8QBEBYAiBBIB4BlQBIA9AtAsQAIARARAgQAOAdAEAbIgQAjIgRAkQgQAfgRAQQgPBAgqB0QgrBzgOBCIgIAKIgKARQgFAKgGAFQhCC1hCB3QhSCWhoBgQAAAIgHALQgGALgBAIQg4A6jACxQidCQhRBkQgPAGgSAQQgWAUgHAFQgKAOgfA0QgYAqgUAUQgwCBhZDAQh1D9gZA8gAAiJgIAOClQAJBiABA2QAVhOgNiZQgQi6ADgwIAThQQALgtgLgbIgOAAQgmBjAODJgABpipIgTAYQAMBeACCKQABBNgBCHQAXhUgCiSQgDjPABgaQgCAAgEgDQgDgCgDAAIgCAAgAE70tQATAnAlAfQgUg0gJgaQgOgtgFgrIgOAAQgRAuAXAyg");
	this.shape_18.setTransform(-46.7,-21.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F7D9D0").s().p("AhgCgQgdgCgZgHIAfhLQATgwAMgaQAhhCAnglQAugvBFgMQADAQARAJQAKAFAWAIQAABQgcBJQgcBKgwAuQhCAKgwAAIgdgBg");
	this.shape_19.setTransform(-13.8,-249.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AARGPIAQgkIAQgkQgDgagPgdQgRgggHgRQgrgshIg9Ih4hoQgjg+hDhYQhgh8gQgXQgagmgHgOQgRghADgdQATABARAnQATAuALAKIBwCLQBEBVAmA8QAlAoBfBOQBYBJAnAxQABANAIAQQAJARABALQAjgrAghKQAehHARhJQAFgUAGhCQAFg2AMgcIAAgEIAYgCQBNgsAlhdQAYgYBYhSIAZAQIh0CMQhFBSg9ArQgeFBiuDDg");
	this.shape_20.setTransform(46.1,-26);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("Ai8EuQAAgJAHgKQAHgLAAgIQBnhhBRiVQBCh1BCi1QAFgFAGgLIAJgRIAbAFQhvFGi6DsQgJAEgNAKQgNALgHAEQgDAHgGAJIgLAOg");
	this.shape_21.setTransform(16,87.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AqTG/QgnhJgjg0IhHg3QgqghgZgaQgBgGgZgwQgSggAVgSQAVAFAKAfQAOApAHAIQAPASBHA5QA4AsATAqQAOgFAIgVIAaAFQgDAHACAKQASAIAdgcQAQgPAcggQAqgsBXhVQBMhNAphAQAlgOAZgyQBHg4CYhPQCihWA/gtQA0gJA0glIBWg/QBZgaBsgrIC8hOIAtARQAYAJAQALQAMAaAVA3QACAcgHAkQgJApAAATQgmBFhFBEQggAhhiBRQgxATgwAZIgNgZQByg9A5gwQAqgjAmgtQAogxANggQASgtgEg3QgFg8gcgaQgxgGgbACIhBAZQgmAPgPAWQiZArgTAIQhbAkgpA3QhVAkgpASQhJAhgmAkQhoAghmBHQg5AnhyBiQg0BPhrBoQiGCDgjAqQACAIgFAIIgGANQABAFAYBGQARAxgOAbIhEiDg");
	this.shape_22.setTransform(88.5,-189.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgoAbQAGgOAAgGQAcgBASgSQAMgMAVgYQgGAYgdAcQgWAYgfAVQgCgLAFgLg");
	this.shape_23.setTransform(16.2,-223);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AhYDOIAIgKQAPhBAqhzQAphzAOg/QARgRARgfIAXAAQgNBKggBVQgTAxgmBeQgJBHgnAwg");
	this.shape_24.setTransform(41.2,35);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AiqEbQgrg+gUggQgjg4gSgxQgHgHAEgHQAIgLAAgDQgDgHgPgEQgOgEgBgJQgmhehHhiQgDgugahAQgdhKgEgUQAoAOAUA0IAZBkQAQAXAbA3QAaA2ARAYQARgRAGgoQAggOAZgaQAVgWAWgiIAYAGIgIAXQgFAOgCALQgRAMgcAZQgeAcgPALQAGAPgHAMIgNAZQAKAbAcAzQBfhUC6iwQCniTCUhUQATgSAkgaQAughALgJIAaAOQgQARgNARQiTBhhHAzQh8BYhHBSQhGA1hLBLQg4A2hNBWQBfCPAPAcQA2BoAHByIgYACQgHhxhMh1g");
	this.shape_25.setTransform(76.5,-92.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AmGFaQAHgZAFgLQBVhIBahnQA6hCBjh/Igrg9QgYgkgOgfQgagqgNgXQgYgoALgcQAaALAQAtQATA3AKAMQAKAOAYAwQATAnASASQA5goCVhfQCFhVBIg0IARAXQg4ApgqAvQgWADgVAQQgVAUgMAIQgUAFgcAQQggARgOAFQhqBJh6CNQiGCjhJBMQgFAHgWAPQgUANgFAKg");
	this.shape_26.setTransform(61.5,-191.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AjoEWQAPgYAcgyQAtgqA0hKIBYh8QgRgSgcguQgbgtgSgTQgEgFg0gxQgjggABggQAZgGAUAaQALAPATAfIAmAnQAWAWALAPQAFAUASAaQASAdAFAPQAXgLATgbQANgPAVggQA6gpBJhBIASATQhFA+guAnQgLAagmApQgkAogLAcQg4AmhBBbQhRBygcAcg");
	this.shape_27.setTransform(80.6,-140.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgYAJQggglAdgXQASARASAiQAaApAHALQglgFgdgmg");
	this.shape_28.setTransform(90.9,-81.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFC9B6").s().p("AllEvQgOiEhVgkQAEgWAagYQAagZAFgUQAfgYCKiEQBmhiBVgqIAdgWQAPgMAGgOQCNhGBOhzIBKgiQAsgPA0ALQAWAWALAOQAQAWAIAXQgGCFhUBgQggAkg0ApIhbBFQgWgXgyhGQgrg8gggcQgSAYAWAcQAMAQAfAbQAbAeANASQATAbAHAZQgrAtiPC6QhyCThbBGQgNgdgYgfIgsg1QgaAYAnAlQAyAxADASQgPAPgyArQgpAkgWAYQAeh8gLhlg");
	this.shape_29.setTransform(52.7,-280.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAAAHQgqg8gLgTQgCgHAGgEQAGgEAAgEIAOAAQAHATASAZIAfAqQAmAzgPAuQgPgkgjgxg");
	this.shape_30.setTransform(128.6,-203.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgFDiQBihVAmg5QA9hbgCh+QgKgSgXgiQgvgSg0AMQgoAJgjAZQglAagjAfIhBA+QgjAhgVAVIgagPIAPgLQACgIAJgNQAIgLAAgLQAlgVArgpIBIhGQAYgJAcgSIAygeQAxgFAoALQAgAKAfAWQAIAWAPAkQAMAggCAcQgCAmgeA7QgiBDgFAYQgGAFg+BJQgpAwgqAQIgBABg");
	this.shape_31.setTransform(146.3,-144.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AkSEyQAsgoAbgcQAmgoAZglQBRg6BWhpQAzg+Bih9IgogVQgWgNgOgNQgRgegDgSQgIghAcgEQARAtAUAaQAaAiAlANIA2gvIAVAUQggAhjfD6QiXCuh2Bfg");
	this.shape_32.setTransform(120.2,-96.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AkrFMQgpgcgJhlIgDiqQgFh1gBg4QAAhhAVgyQALgPAdgOIAtgXQArgBDWgKQCkgHBjAEQAWAHATAXQAKANAUAcQAMBGACC6IAEB4QADBEgEAlQgKBnhOAeQg1AEhaACQhrACgqACQhgAKgzADIgYABQhIAAgggYgAg/k6IhxABQiCAIgRBLQgGCMALDkIAEBhQAHA2AaAYQCAAGCWgIIEKgRQAVgKARgUQAOgPAOgaQAFgxgEhbIgFiYQgCiAgCgTQgKhNgrgbQgqgHhJACQhUACgdgCQgkAKhDABg");
	this.shape_33.setTransform(169.1,95.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFC9B6").s().p("AnDGKQgPgchfiPQBNhXA4g4QBLhKBIg0QBHhSB8hYQBHgyCRhhQANgRAQgRQAVgXAjghIBBg+QAjgfAmgaQAkgZAogJQA0gMAvASQAXAiAKASQADB+g+BdQglA5hlBVIg2AvQglgOgZghQgVgbgQgtQgdAFAIAhQAEARARAeQANANAXANIAnAWQhiB9gyA7QhZBrhOA6QgaAlgmAoQgaAcgtApQhYBRgYAYQglBdhNAtQgHhyg2hogAjPDfQAfAmAlAFQgHgLgagrQgUgigSgRQgdAXAgAng");
	this.shape_34.setTransform(109.2,-102.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AjSCSQAugpBahVQBPhHA8guQBfgvAmgUIANAZQhnA1htBWQg6AuiFB3g");
	this.shape_35.setTransform(123.2,-179.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EDE7DA").s().p("AgcAtQgQgPgBgZQgBgXANgUQAhgUAYAOQAUANACAdQABAbgTAQQgMAKgQAAQgMAAgQgGg");
	this.shape_36.setTransform(152.4,79.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#EDE7DA").s().p("AguAPQgHgVATgXQASgXAWACQAbADAQAmQgGAvgpANQgngJgJgbg");
	this.shape_37.setTransform(154.4,108.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFC9B6").s().p("ApXKFQgbg3gPgYIgahkQgTg0gpgOIAPgTQAOgbgRgwQgZhHgBgFIAHgNQAEgHgBgJQAjgpCGiDQBrhnAzhPQBzhjA5goQBmhHBqggQAkgkBJghQApgSBVgkQApg3BbgkQATgHCYgsQAPgWAmgPIBCgZQAagCAyAHQAcAaAEA7QAEA3gRAtQgNAhgpAwQgmAtgpAjQg6AwhxA9QgmAUhfAvQg8AuhRBJQhaBTguApQhHBBg6ApQgVAggMAPQgUAbgXALQgFgPgUgdQgSgagEgUQgMgPgWgWIglgnQgUgfgLgPQgUgagZAGQgBAgAjAgQA1AxADAFQASATAbAtQAcAuARASIhXB+Qg0BKguAqQgcAygPAYQgVAjgVAVQgaAbgfAOQgGAogSARQgQgZgbg1gADkmkQgFAEACAHQALATArA+QAjAxAPAkQAPgtgmg1IgggrQgTgZgGgTIgPAAQAAAEgGAEg");
	this.shape_38.setTransform(100.6,-169.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#EDE7DA").s().p("AgdAoQgRgLgCgWQgCgVAPgQQAPgQAWgCQAUgBANAOQANAMABASQAFAxgyAFIgEAAQgQAAgNgJg");
	this.shape_39.setTransform(185.2,78.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#EDE7DA").s().p("AgtAUQgHgVASgZQATgYAVABQAcABAOAnQgEArgnARQgpgFgJgag");
	this.shape_40.setTransform(185.9,107.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#EDE7DA").s().p("AkcE/QgagZgHg1IgEhiQgLjkAGiMQARhLCCgHIBxgCQBDgBAkgJQAdACBUgCQBJgCAqAGQArAcAKBMQACAUACCAIAFCYQAEBbgFAxQgOAZgOAQQgRATgVALIkKAQQhZAFhRAAQg4AAg0gCgAi4BtQgSAXAHAXQAIAbApAJQApgNAGgxQgPgmgcgDIgDAAQgWAAgRAVgACBBnQgSAYAHAXQAJAbArAEQAngQAEgtQgOgogcgBIgBAAQgWAAgTAYgAjLi7QgNAVABAYQABAaAQAPQAlAOAVgTQATgQgBgdQgCgdgUgMQgKgGgMAAQgQAAgVALgACgjOQgYACgOAQQgQAQACAXQACAWARALQAQALAUgCQAygFgFgzQgCgSgMgMQgMgNgSAAIgEAAg");
	this.shape_41.setTransform(169.4,94.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_42.setTransform(44.4,-29.3);

	this.addChild(this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.6,-338.1,654,584.4);


(lib.dados2 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah0C9IBPilQAUglAphDQAyhLARghIAZAOQglBFhlCpQgaA8gfBBg");
	this.shape.setTransform(-239.2,226.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhyEVIAIgPIA9h+QAhhJASg5QASgzAXhfQAbhtAMgoIAdAGQgZCdg4CWQgtB9hNCNg");
	this.shape_1.setTransform(-218.5,179.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiBEHQAuiYBKhVIA0iXQAghVAhg5IAWAIQgfBYgTBDQgKAIAKAJQALALgCAHIhjCiQg5BgghBPg");
	this.shape_2.setTransform(-196.8,124.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgyDhIgVgIQAzjMBDjtIAaAHQgQBrglB6QgNAqg4Crg");
	this.shape_3.setTransform(-178.7,75.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("ArqYNIB1mUQBPkLAniKQAcgzAchWQAoh3AIgWQAXg4AbhWIAuiQQANgmAfhAQAkhJALgaQAGgOASglQAPggAHgTQAHgTAJglQAKgoAGgSQAHgVATgnQAVgoAHgTQAhhaAthnIBQi2QCZiSC8j7IE6mnIAWASQgaAigbApQgSAbhFBcQg3BJgaAyQhJBXgOASQgwA9gdA2QgyAvhRBeQhYBlgpApIg3BuQgKAXgNAnQgPAsgHARQgCAJgMASQgNARgDAJQgEAMgHAcQgGAagGAOQgEAKgPAZQgNAWgFANIgmB4QgYBIgUAuQgMAdgqBMQgkBDgOAqIgPAxQgJAcgIAUQgTAugEA8QgjA2gcBcIguCaQg+ClgXBDQguCDgdBoIgsCVQgbBZgLA1IgPBAQgJAjgRAZg");
	this.shape_4.setTransform(-99.2,-101.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AlWHoQAhhpAJgWQAZhHAcguQA3iFAlhOQA2huA3hSQCDiAAxgsQBphdBdg/IALAQIgbAUQgHAHgLAPQgLARgHAFQgOAMgmAbQgkAYgRARQgbAbg8AwQgyAtgNAwQgtAUgmBEQg0BYgOAPQgQAthTCxQg+CGgXBkg");
	this.shape_5.setTransform(-61.8,196.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFC9B6").s().p("EgZmAo+QAfhBAZg8QBoirAlhFQBOiOAuh9QA5iXAYieQAihPA4hgIBmikQACgHgMgLQgJgJAKgIQAShDAfhZIABAAQA6irANgqQAlh8APhrQARgZAJgjIAPhAQALg1AbhZIAsiVQAdhoAuiDQAXhBA+ilIAuiaQAchcAjg2QAEg8ATguQAIgUAJgcIAPgxQAOgqAkhDQAqhOAMgdQAUguAYhIIAmh4QAFgNANgWQAPgZAEgKQAGgOAGgaQAHgcAEgMQADgJANgRQAMgSAEgJQAHgRAPgsQANgnAKgXIA3huQApgpBWhlQBRheAygvQAdg2Awg9QAOgSBJhXQAagyA3hJQBFhcASgbQAbgpAagiQBEhXBLg3QCEgwDFgNQA7gRAngGQA1gJA2ABQgYAjgyBZQguBQgfArQgkA3gTAZQgiAsgmAVQgLAbgHALQgMAVgVADQgBgWgOgbQgHgNgTgfQgVgkgFgFQgSgVgYAFQgKAVAWAVQAMALAaAWQAwA4gCAlQgBAUgWAYQgaAagKANQgHAJgTAiQgOAZgPAMQiDFIjFEPIgIAKQhBBUgiApQg7BIgxAtQgVATgkAoQglAqgTASIg6A8QgiAlAAAjQAiACAdguQAig1AWgJQAPgVAmgoQAkgmAQgYQA7gwA3hCQAug4AxhNQBfhwBZijQA8huBZjFQASglAigtIA5hNQAGACAEANQAEAMAJAAQAHgHgHgOQgHgSADgKQAQgUBQhZQA8hDAegxQAbALAXAeIAlA0QBRAtBhgBQBcgZAwhoQASglARg9IAehoQAdAngBBQQgBBRggAiQgDAMAKAHQAKAHgCAKIgBAEQhADQhyC4Qg/A7hHBfIh5CoQg2CUgMAqQgjBygEBdIgPBZQgbChgMBlQgTCaAAB9QAADfgCAlQgJCOgrBYQggCvhRC4QgvBrhyDOQgEADgOANQgKAKgNABQgdBBhfBkQhdBigdBEQAXgQAtguIAjglQAVgWANgMIBAhIQAlgqAWgkQA3g7A4hmQA+h3Agg7QASgxArh+QAmhwAYg+QADg1AThDQAXhJAKgmQgHgVADgfIAIgyQgHikAIicQAHivAYiHQAaBNAnCkQAoCOA3BHQg4iXgZhRQgriLABh3QADgKgRACQgRABADgKQgBgeAGgoIAdhyQAQhBgJgvQAOgZAdhcQAXhMAegfQABCrA0DnQAOBAAeB+QAaBwAOBQIAJASQgWANAKAjQAGAUAPAmQAEASAEAqQAEAlAGARQAHApAVAMQgGAeAJAuIAPBPQAMBrguCAQgXA9hCCBQgSgTgegoQgegpgSgTQgOgPgqgjQgkgggRgVQgCgDgNgeQgJgUgRgFQgbARAPAcQAGALAcAcQALALAdAYQAZATAIAKIAfAiQAUAVANAUIAgApQAUAbADAQQADARgHAhIgKA4QgCAVgBAmIgBA3QgNCfgwCcQgvCbhCBfQAAAKgHASQgGASAAALQhvC4hrCJQh9CgiIB3QgfATgWAPQhcA+hpBeQgyAsiFB/Qg3BSg2BxQglBOg0CFQgcAugaBGQgIAXgiBpg");
	this.shape_6.setTransform(-83.3,-16.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AjXD2QAAgjAiglIA6g9QATgSAlgpQAkgpAVgRQAvgtA7hIQAhgpBChTIAVAQQgxBOguA3Qg3BDg7AtQgOAYgkAmQgmAogPAWQgWAJgiA1QgdAsggAAIgCAAg");
	this.shape_7.setTransform(-55.5,-129.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AkoNhQBfhkAehBQAMgBAKgKQAOgNAEgDQBzjOAshrQBRi4AgiwQArhXAJiOQACgkABjfQAAh+ASiaQAMhlAbihIAVAEQgHAoACAeQgEAKASgBQAQgCgDALQAAB2AqCMQAZBQA4CXQg3hHgoiNQgnilgahNQgXCHgICvQgICcAHCkIgHAzQgEAeAHAVQgJAmgYBKQgTBAgCA3QgZA+gmBwQgrB+gSAxQggA7g7B4Qg4Blg4A8QgVAjglAqIhBBIQgNAMgVAWIgjAlQgsAugYAQQAdhEBdhig");
	this.shape_8.setTransform(-1.9,-20.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AnxSUQAWgPAfgTQCIh2B9ihQBriJBti3QAAgMAGgRQAHgSAAgLQBChfAvibQAwibANidIABg4QABglACgWIAKg4QAHghgDgRQgDgQgUgaIgggpQgNgUgUgWIgfghQgIgKgZgVQgdgZgLgKQgcgcgGgMQgNgbAZgRQARAFAJATQANAfACACQARAWAkAgQAqAlAOAPQASATAeAoQAeApASATQBCiCAXg+QAuiBgMhrIgPhOQgJgvAGgdQgVgMgHgpQgGgSgEglQgEgqgEgSQgPgmgGgTQgKgjAWgOIAJgEQAPASAHAkIAKBBQAHAXAEApIAHBFQABAIASACQATABgBAKQgKAxATAsQAggFAfgQIAKATQggARgcAMQAHCcg+CiQgSAtgpBZQgpBYgSAuQAAAtgKBbQgKBSACA1QgNA1ggBZQgiBegMAvQg4CShrCqQg/BiiEC+QgcAZg7AxQgxAtgYAsQgVARgnAWIg/Amg");
	this.shape_9.setTransform(21.1,30.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AtnLSIAIgLQDFkOCDlJQAPgMAOgYQAUgjAGgIQAKgNAagYQAWgYABgVQADglgxg4QgagWgMgLQgWgVALgVQAXgFASAWQAFAFAVAjQAUAfAGANQAOAcACAVQAUgDAMgVQAHgLALgaQAmgWAigrQATgaAlg3QAegqAuhRQAyhZAYgjQg1gBg2AJQgnAGg7ARQjFANiDAxQhMA2hEBXIgWgSQA0hBAyg6QARgHAbgRQAagTARgGQBIgYCkgXQCngYBGgVQB0gFA8gHQBngNA5gdQCAADCWguIB5gnQBIgWA5gKIAkAJQAVAHAQABQARAQAOAcQAGAPANAmQgZDDinBqQhzBHj9A8IgGAZIgdgGQABgKgKgHQgJgHACgMQAggiABhRQABhQgcgnIgfBoQgRA9gRAmQgxBnhcAZQhfAChRguIglg0QgXgegagKQgfAwg7BDQhRBZgQAVQgDAJAHAQQAIAOgIAHQgIAAgEgLQgFgNgFgBIg6BLQgiAugRAkQhaDFg8BvQhZCjheBvgAhFnWQgwA5gwCPQAjA7A3AeQA9AhBYgDQBCgoAmhTQAghHAOhtQgXhAg7geQgRgBgRAAQhtAAhEBPgAJHqTIhiAmQg6AXgrAGIhaAEQgyACghAMQAFAZAWARQANALAhANQACAQARAYQARAbAEARQAJAjgFA7QgIBaAAAKQCSgpAggKQBiggA9gmQCghgAJi8QgHgHgIgPQgIgRgFgFQgggIgjAAQhEAAhQAcg");
	this.shape_10.setTransform(51.2,-226.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgBI0QglgFgJANQgNhPgbhxQgeh+gOhAQg0jlgBirQgeAfgXBMQgcBdgOAWQAIAvgQBBIgcByIgVgEIAQhZQADhdAjhwQANgqA2iUIB4ioQBHhfA+g7IAVAOQglA2hABUIhpCHIADgBIAGATQACATgEAdQgDAgABARQA0gHA8gSQAngOBCgZIALAbQg+AXhHAjQgsAGgqARQAABrAVBwQAOBMAgB5QA0gOA0gbQA1gaAugjIAPATQgOAIgoAiQghAcgTAJIg3ATQgiAKgNAYIAOBAQAHAnACAdQAQAGAFAQQAIAXACAEQBOALBdgTQAXgGCJgnIAHAaQhcAhgwAPQhUAdg4ACIg5gIg");
	this.shape_11.setTransform(57.1,-147.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFC9B6").s().p("AsgDcQBChTAlg3QBjiMAriMQAUgCAXgHIAogNQBogKClgtQCugwBYgMQCMgmDzAhIDHAaQBzAMBbgGQAVAGAPARQAKALANAXQADBPgvA9QgrA4hIAdQgcAMgiAKQhiAchIgEQgXgBhngXQhKgRgvARQgQgSgJg7QgIg7gRgSQgcASASA1QAcBRAAAGQgXAAgWAMIglAWIgUAHQibA7h5AeQigAnihAGIgeAHQgRAEgRgCQgRgPgNgrQgNgvgMgOQgWAOASAoQAJAWAWAmQg7AXhxBDQhqA/hGAXIgCABIBpiIg");
	this.shape_12.setTransform(132.9,-211.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFC9B6").s().p("AomCRQABgLgSgBQgTgBAAgJIgHhEQgFgpgHgVIgJhCQgIgjgPgSIgIAEIgKgSQAJgOAlAGIA7AIQA4gCBUgdQAwgPBdghQAugOAdgEIDkAGQCSAFBdALQAtgGAcACQAmAIAtAhQAyAmAaAJQASATA8AZQA4AXARAaQgFArgwAlQgdAXhAAfQhMADhEgcQgRgHhegzIgFg4QgDghgTgGQgWAFAJAkQAOAygBAIQgfALgfAHQhJARiqAPQiiAOhFAUQghg8ATg+QguAPAKA0QAHArAdAiQglALgsAgQg5AqgSAJQgeAPghAGQgTgtAKgwg");
	this.shape_13.setTransform(117.9,-75.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AtFDjQByi4BAjOIABgEIAeAGQgOAxgDAYQBjgMCHghIDkg5QEVhCDKAWQCXAdArAFQB4APBcgSQAIAHAbADQAdADAJAEQAVAQAQAfIAaA8QgTBUgWApQgyAzhbA7QghAHgvAQIgJgaQAigLAcgMQBIgdAqg3QAwg8gDhPQgNgXgKgLQgPgRgVgGQhbAGhzgMIjHgaQjzghiLAmQhZAMiuAwQilAuhoAJIgoANQgXAHgUACQgrCKhjCPg");
	this.shape_14.setTransform(144.8,-227.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AjSAeQBlgmAlgNQBPgaBHgHQAtgEBYACIgBAdQjSAIjIBMg");
	this.shape_15.setTransform(85.9,-173.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#F7D9D0").s().p("AhoCoQg3gdgjg7QAxiOAwg5QBNhbCFAOQA7AdAXBAQgOBrgfBHQgmBThDApIgKAAQhRAAg6gfg");
	this.shape_16.setTransform(54.1,-261.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AjaBeQAggYAXgYIgZhGQgPgsgFgiQAJABALgGQAKgGALADQAIBFAuApICeAAQBhgCBLgGIACAYQjQAPhpALQgSASgiATIg6Ahg");
	this.shape_17.setTransform(92.8,-137.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AoKCTQBFgXBrg/QBwhBA8gXQgWglgKgWQgRgpAWgOQALAPAOAuQAMAsARAOQARADASgFIAdgHQCggGCggnQB5geCcg7IAJAYIhtAuQhBAbguALQhyAaiPAUIkBAfIiRBQQhXAwhJASg");
	this.shape_18.setTransform(94.9,-190.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AlFBuQASgJA5gqQAsggAlgLQgdgggHgrQgKg2AugPQgTBAAhA8QBFgUCggOQCsgPBJgRIAHAdQh9AljJAEQhRANhXAoIiTBMg");
	this.shape_19.setTransform(102.6,-65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AB3CqQhfgjg5gDIgJADIgHgdQAggIAcgKQABgIgMg0QgJgiAUgGQAUAGADAgIAEA5QBfAzAQAHQBFAcBMgCQBAgfAdgXQAvgmAFgtQgRgag4gUQg8gZgRgTQgagJgzgmQgtgigmgHQgbgCgtAGQhcgLiSgFIjmgGQgdAEguANIgHgaQBQgYA9gHQBCABDDAOQCiAMBfgFQAwAbBYA8QBSAyBOANQADAKAOAMQANAMACAIQgRBMg+AyQguAlhZAkQhEgDhdgig");
	this.shape_20.setTransform(139.5,-82.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFC9B6").s().p("Ai9CAQAFg7gIgjQgFgRgRgYQgRgZgCgQQgggNgOgLQgWgQgFgaQAhgLAygDIBagDQArgHA6gWIBhgmQB5gsBeAXQAEAFAJARQAHAPAHAHQgIC6igBhQg+AlhgAgQggAKiSApQAAgKAIhag");
	this.shape_21.setTransform(103.1,-272.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AjwFHQgahUgRgoQhFijgbhKIAAgoQgBgYAGgLQB3hlDQhXQAggNFZh9QAaAAAZASIgOASQgnAMgwAdQgtAbglAhIgHAtQgEAbACAZIAcBnQARA9AOApQAMAiATBFQASA9AYAjIgPAFQgNAAgKAQQgLARAEASQAUgDALgGIAGALIhcA0QgVAFirBBQhxArheAKQgkgmgahHgAhZi8QheAfgpASQguAJgVAGQgmALgSARQgJAvAYBDQAJAaAxBuQAMAbAgBpQAgBfAdAPQAkATBKgbQBiglASgDQAhgPBHgaQA9gYAjgYQADgHAKgQQAJgNABgLQgWhggmh0IhDjOIgpgZQgYgOgfAEQgGABABAEIgJAAQgrAThZAdgAgDkiQiaA7heBBQC+g2BbgkQCVg5BchKQi7A/hXAigACHkUQgVAKgHAMIAYAOQAOAJARgBQAKgJADgVQAEgZgNgHQgGAHgZALg");
	this.shape_22.setTransform(165.9,51.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EDE7DA").s().p("AgNgMQBYgjC6g+QhcBJiUA4QhbAki+A2QBdhBCag5g");
	this.shape_23.setTransform(166.9,23.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgEBDQiCAijFAQIgCgaQDUgRBsg8QAIg8AGgcQAOgvAigMQgDARgXA+QgRAvABAnQBiAkAzANQBXAWBYAAIADAaQgaAEgOABQipgUiBgvg");
	this.shape_24.setTransform(148.1,-147.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgXA0QgpgZAbgtQAZguAqARQAfAdgVAkQgSAigkAAIgJAAg");
	this.shape_25.setTransform(153.6,79.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AkXBZIAVgIIAlgWQAWgLAXgCQgBgGgbhPQgSg2AcgSQARASAIA7QAJA6AQASQAugSBLASQBlAZAXABQBIAEBigeIAJAaIg9ASQgiAKgeADQgtAEhEgNQhUgQgZgCQgzgDg2AMQgsAJg2AWg");
	this.shape_26.setTransform(174.4,-216.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgtAUQgDgUAQgXQARgYAUgEQAZgEARAaQgCAlgLATQgOAYgeACQgfgHgEgag");
	this.shape_27.setTransform(161.9,60);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgnAAQAIguAfgMQAxAHgJAzQgIA1gpAGQgmgKAIgxg");
	this.shape_28.setTransform(170.9,41.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#EDE7DA").s().p("AiGE8QgdgPgghfQgghpgMgcQgxhsgJgaQgYhFAJguQASgSAmgKQAVgHAugJQApgSBegeQBZgeArgTIAJAAQgBgEAGgBQAfgEAYAPIApAZIBDDNQAmB1AWBfQgBALgJANQgKAQgDAIQgjAXg9AZQhHAaghAOQgSADhiAlQgsAQgeAAQgVAAgPgHgAh+C2QgaAvApAZQAsAEAVgmQAUgmgfgdQgLgEgKAAQgdAAgTAhgAAAgwQgUAEgRAYQgQAVADAWQAEAaAfAHQAegCAOgYQALgTACglQgOgWgVAAIgHAAgAAsi3QgIAyAmAKQArgHAIg0QAJg2gzgGQgfALgIAwg");
	this.shape_29.setTransform(162.4,59.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#EDE7DA").s().p("AgJAXIgYgPQAHgJAVgKQAXgMAGgHQANAIgEAWQgDAVgKAJIgEABQgOAAgLgIg");
	this.shape_30.setTransform(180.1,25.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("ADtDKQBcgbAugiQA+gtAOhLQgLgdgigVIhBggQg3gKhDgaIhygvQiLg3h3AGQhjAIhFABQhfAChYgHIABgcIBRACQAqAACxgIQCKgHBcAGQCNBDAbALQBkAnBhALQAHAGAzAeQAkAWAPAVIAAAbQAAAQAEAIQgmBNhDAyQhFAzhbAQg");
	this.shape_31.setTransform(157.5,-157.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgjAJQgJg1AjgTQAdAOANAtQAOAtgfAWIgCABQgoAAgJg3g");
	this.shape_32.setTransform(192.8,31.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#EDE7DA").s().p("AgQgIQAKgQALAAQANAAAHAVQgDALgQAIQgJAGgUADQgEgSALgPg");
	this.shape_33.setTransform(196,75.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("Ah6FJQAQgIADgOQgGgVgOAAIAQgFQA9gFA1ggQA2gfAegvQgTh1gwiHIhVjrIAOgSIASANQAyCYBnExQgGAGABAXQABAWgFAGQgSAig1AcQhJApgJAHQgiARgrAZg");
	this.shape_34.setTransform(209,43.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFC9B6").s().p("AsEBiQgVhwgBhsQAqgQAtgGQBJgjA+gYQDIhODUgIQBYAHBdgCQBFgCBjgIQB3gGCNA4IByAuQBDAaA3ALIBBAgQAiAVALAeQgOBMg+ArQguAhhcAbQhYAAhYgWQgzgNhhgjQgCgoARgvQAXg9ADgSQgiAMgNAwQgIAbgJA9QhsA7jSARQhLAGhhACIigAAQgugpgIhDQgLgDgKAGQgLAGgJgBQAFAgAPAsIAZBIQgXAYggAYQguAig1AbQg2Abg0AOQggh5gOhMg");
	this.shape_35.setTransform(123.1,-147.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#EDE7DA").s().p("AhLDOQgThFgLgiQgPgrgQg8IgdhmQgBgZADgbIAIgtQAlghAsgbQAwgdAlgMIBYDrQAvCHAUB1QgeAug2AgQg3Agg7AFQgYgjgTg9gAAeBuQgCAnAPAZQA3AHgBg5QgBgWgLgUQgMgTgQgEQgZAJgCAqgAh6hfQAJA4AsgBQAfgWgOgwQgNgtgfgOQgjATAJA3g");
	this.shape_36.setTransform(201.5,41.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgSA4QgQgZACgkQACgrAZgIQAPADAMAUQALATAAAVQABAygoAAIgMgBg");
	this.shape_37.setTransform(207.8,53.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgiAAgyMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAygiAiQgkAkgygBg");
	this.shape_38.setTransform(44.6,-30.1);

	this.addChild(this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.4,-300.6,654,546);


(lib.dados1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhbDVQgKgEANgSQAPgWAAgIIAnhcQAVg2AKgtQAZhEA0h2IAWAKQgGA6ghAnQgHAngWA1QgaBAgFAWQgSA3gRAgQgFAKgKAeQgJAVgPAAQgHAAgHgEg");
	this.shape.setTransform(-239.5,230);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhsDyQBXjIARgpQA5iJAjhzIAWAFQgHAVgSBLQgPA7gNAhQgsBlgYA4QgnBXglBCg");
	this.shape_1.setTransform(-221,184);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AidGPQAAgsAUg6QAWg/ACghIAqhLQAZgqAVgcQAEg8AmgrQA2idA/jIIAYAIQg5C7gfCCQgMAYgZAuQgUAmgJAkQgyBOgWAvQgkBMgJBQQgNAbgJAfg");
	this.shape_2.setTransform(-196.4,118.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AibHmQBOj/BQkxQAbg5AXhWQAMgsAZhwQAYgyAchGIAOAGQgBAjgWA4QgVA1ABAoQghBQgLAjQgVBDgFBBQgPAUgOA0QgOA2gNAVQgXBYgjBzIg9DIg");
	this.shape_3.setTransform(-167.3,29.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFC9B6").s().p("Egb8AmyQAKgeAFgKQARggASg3QAGgWAbhCQAWg1AGgnQAhgnAHg6QAkhCAohXQAag4ArhnQANghAPg7QAShLAHgVQAJgfANgbQAJhRAjhLQAXgvAzhOQAJgkAVgpQAZgtALgYQAgiDA4i6IA9jIQAjh0AXhXQANgVAPg3QAPg1AOgVQAFhAAWhEQALgiAghOQAAgoAVg2QAWg3ABgkIAXgrQAOgaAMgOIAAgwQAUguBPjCQA9iTAqhYQAOhLA+iJQA5iBAMhaIAGgPIA3hoQAhg+ALg0QBjiTCEiTQBvh7CViNQBjg7BshaQBAg1B8hzQAJgBALgFQANgGAHgBQAvgpAjgYQAwggAygRQBVgGCJAFQDAAFAiAAQDAABBrAaQAEAEAeAYQAVAQAHARQgKBBBDBOQASAVAmAqQAgAlANAeIApAIQAZAEAEAOQg1BXiLAHQiLAHhAhTQAhhFgahVQgXhJgygyQg2gMg5AaQhRAkgPADQg6AxgsATQhHAgg3geQgFgWgWg+QACgegCgOQgCgXgUABQgeANAVAwQAfBEAAAMIhCAhQgoATgiAFQg2AjhCBCQhHBLgmAjQi9EmijDcQjCEKjDDRQgFAHgfAVQgXAPgCAXQAZAFAZgXQAOgOAYgdIApgoQAYgXAJgVQAfgbArg7QAxhCAUgYQA+hCBRhuICGi4QCskiDBjKIBig6QA6gjAzgEQBCgGBUAtIBDAmQAnAXAZAKQAZgFAoADQAyADAVgBQARgHAngZQAigWAQgDQhJDfi6BvQhnAohWA0QgZAggbA3QgdA/gQAeQABAPgFAVQgFAXAAALQgdBEgfBeQgOAngoCBQgNBmgIC5IgKEdQgcEBgaCPQglDRg6CZQgbA2g3B9QgwBxghA8QgWAohVBwQhHBdgYBDQAUgGAZguQAbgyAUgMQAphBA8g2QAHgaATgfIAfg1QBsjjA7izQBQjuAVjpIASjMIANiPQAEgmADiLQAChvANhEQAMAWAXBEQAVA7ATAbQAEAUAQAWIAcAlQAJAMAQAbQAPAWARAJQgNgcgkgzQgmgzgOgcQgkhIgQg4QgXhTAOhCQAPhLA1iAQA1iDAPhCQANgNASgpQARgmASgNQAZATBYgIQBggKAcAMQgjAChDALQhAALgtACQgVAMgRAdQgRAjgLAQQgcCGgQDIQAdBFA1BTQAfAvA/BcQAaALAbAGQAIAaAYAcIAmAvQALAXAXAqQAVAnAHAhQANAGAMATIATAgQALAgAcA6QAVA3gHA9QABAMAJAKIAQASQgCAEgNAMQgKAJADAOQgGBlgiBdQgZBGgxBWQimhuhvhnQgcgggag/IgrhsIgPghQgMgUgRAFQgKAPALAYIAVAkQAOAXAvBbQAkBGAaAkQA6ArAeAoIBdA8QAyAmAUAtIgPAiQgIAWgIAKQgcB+grCBQhnE1i9EcQg8BZg4BKQgWATgfAQQg5BDh6BfQiKBrgwAwQgWAJgNAEQgMAagbAbQgQAPghAdQgoBZhKBxQgxCNglBPQgPAggpBFQgmBBgQAkQgJAVgPAoIgYA+IgZAuQgPAdgDAVgAKOhqQgFAEACAGQAJAgATAyQAWA4AHAXQACAMAAAbQADAWANAFQABg3gYhHQgbhNgDgpIgNAAQAAADgGAEgEAKQgiAQAFAZAVgCQAAgcgEgMQgGgTgRgCQgDAWAEAQg");
	this.shape_4.setTransform(-65.9,1.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AjPINIBuk7QBDi9A4hsQAIhAA3hxQA4hxAJhLIAhhNIAVAJIgGAPQgMBag6CBQg9CJgOBLQgrBWg6CTQhPDCgVAuIAAAwQgMAOgNAaIgXArg");
	this.shape_5.setTransform(-132.2,-72.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AkxGDIA9iJQAkhRAXg5QBFhNCBicQB3iLBfhTQATgQAvgkIANARQiXCNhvB7QiCCRhjCTQgLA0ghA+Ig3Bog");
	this.shape_6.setTransform(-82.8,-164.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ADmW8QAriBAbh+QAIgKAJgWIAOgiQgUgtgygmIhcg+Qgfgog5grQgbgkgkhGQgshbgOgXIgWgkQgKgYAKgPQARgFAMAUIAPAhIAoBsQAbA/AbAgQBvBnCmBwQAyhYAZhGQAhhdAGhlQgCgOAKgJQANgMABgEIgPgSQgJgKgCgMQAIg9gVg3Qgdg6gLggIgTggQgLgTgOgGQgHghgUgnQgYgqgKgXIgngvQgXgcgJgaQgagGgagLQhAhcgegvQg2hRgchFQAPjIAdiGQAKgQASgjQARgdAVgMQAsgCBAgLQBDgLAkgCQgcgMhgAKQhZAIgZgTQgRANgRAmQgTApgNANQgOBCg0CDQg0CAgQBLQgOBCAYBRQAQA4AkBIQAOAcAjAzQAkAzAOAcQgSgJgPgWQgQgbgGgMIgcglQgQgWgFgUQgTgbgUg7QgXhEgMgWQgNBEgDBvQgDCLgDAmIgNCPIgWgCIAKkdQAHi5ANhkQApiBANgnQAgheAdhEQAAgLAFgXQAEgVgBgPQAQgeAbg/QAbg3AZggQBXg0BmgoQC6hvBJjfQgPADgjAWQgmAZgRAHQgWABgxgDQgpgDgYAFQgagKgngXIhCgmQhUgthBAGQgyAEg7AjIhhA6QjBDKisEiIiHC4QhRBug9BCQgXAYgwBCQgrA7gfAbQgKATgXAXIgqAoQgXAdgOAOQgZAXgagFQACgXAYgPQAfgVAFgHQDCjPDFkKQCjjcC9kmQAmgjBHhLQBBhCA2gjQAigFAogTIBBghQgBgMgchEQgWgwAfgNQASgBACAXQABAOgBAeQAVA+AFAWQA3AeBIggQArgTA7gxQAPgDBRgkQA4gaA2AMQAzAyAWBJQAbBVgiBFQBABTCMgHQCKgHA2hXQgFgOgZgEIgogIQgOgegfglQgngqgSgVQhDhOAKhBQgGgRgVgQQgegYgEgEQhsgai/gBQgiAAjAgFQiHgFhVAGQgyARgwAgQgkAYgvApQgHABgMAGQgMAFgIABQh9Bzg/A1QhsBahkA7IgNgRIDVijQB4hgBMhVIBdg2QA2ggAhgcQAkgIA1gDQAxgEAkACQBfASDogCQDUgBBrAdICZCOQBbBVA7A7QAhBSg5A4QgUAVgkAWIg8AiQAbAqArAoQAgAdAzAnQBBBSgqB+QgGATgkBWQgaBAgHAoIgYgCQACgOAAgTQglgzhBgYQhLgdhFAdQgHAJgFAJIgbgEQAUgfAbgbQBAgKBGAZQAoAOBJAhQAphLARgqQAdhLgWhIQgagghFg/QhBg7gdgnQhbAJhLgUQhLgUgxgsQgcBCg3BCQgcAihOBMQgXAMgTAIIhRAiQgtAWgZAZQAfAIAogDIBKgFQgEgcAAgMQABgXAOgHIACgBQAHAEACASQACATAHADQAjAUBAAJQAlAFBPAGIAYhIQAQgrAaABQgEAhgXBEQgZBJgHAmIgagCIAKg0IgIAAQiRAPhJALQiBATg6AvQgbBOgLBnQgMBrALBaICIDRQAhAcA1AGQAjAFBRgEQAigIAtgQIBLgcQAphLBFhjIARAEQgLAYhYCiQg+BygXBZQAMCQBpAdQAbAHAgABIAPgJQAKgFAKAAQAHgSAegeQAbgcAGgZQAegYANgPQAXgaAAgXIAEgIQAbgZAkg1QAqg8ATgVIAWANIgOAbQANAHAdAMQAcAMAOAIQAKATAVAZIAkArQAqA1gEA2QgBASgMAgQgLAhgCAWQglAbg9BXQg4BPgwAbQguAAgjgSQgdgOgbgdQhWAqgtAUQhRAkhJgGQgwDvhuDEQgUA/gfBcIgzCZgAGjF+QAKAfAYAtQAcA1AIAVQgBBnAgA3QBBAGBFgbQAogQBIgmQgQgmgGgVQgLglAHgfQgEABgYAOQgXAOgPACIg5AAQgmgKgggYQgYgSgdggIgagwQgLgNgOAAQgLAAgNAIgAN4KQQAyALAfgiQgLgFg9gGQg2gGgUgOQAPArAyALgAN+GxQgrANgOAkQgRApAeA1QAZAGAxAHIBLANQAdgeAChDQgNgwgrgTQgWgKgXAAQgRAAgSAFgAMcGqQgSAYgEAlQgEAlALAgQAMAiAaAMQgDgRgNglQgMghgDgXQAjg5AWgUQAngkA6gBQB+AugMBfQAfgLARgiQAKgUANgyQgHhZgrg4Qgvg+hTgNQgOAYgtBBQglA3gTAlQAAAHAJAIQAIAIgEAMIgBAAQgdAAgTAagAEfCrQANAdAnA6QAjA2AOAjIA5AAIAehqQASg+ASgmQhXATiJALgAGNz0QhFAUhCAjQhMAogfApQAkARBCAnQA/AdBNgKQAzgaAMgJQAegXAEgjQAFgqgfgrQgagkgeAAQgHAAgIADgAL6z0QASAhAvAxQAxAyASAeQAGAAAKAGQAJAFAKgCQgGg0g3guQhEgxgdgYQAAgEgEAAIgBAAQgDAAgBAEg");
	this.shape_7.setTransform(20,-103.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AocLoQgBgKACgMQADgVAPgcIAZgvIAYg9QAPgpAJgVQAQgkAmhBQAphEAPghQAlhOAziOQBKhuAohaQAhgcAQgQQAbgaAMgbQANgDAWgKQAugwCKhrQB6heA5hDQAfgRAWgSQA4hKA8haIAXAQQhfCMgmAvQhPBjhVA3QgFAKgPAOQgPAPgFAJQgfAQgRANQgYASgLAYQgfAGghAYQgvAjgIAFQgOAQgrA7QgiAxgeAVQg9BqhpDUQhtDfg3BjQgEAWgLAaIgUAsQgJALgJAgQgLAXgYAAIgEgBg");
	this.shape_8.setTransform(-38,177.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AisIqQBVhwAWgoQAhg8AvhxQA2h+Abg1QA6iXAmjTQAZiPAdkCIAWACIgSDNQgWDphPDwQg7CxhqDjIgfA0QgTAggHAaQg9A1goBBQgUAMgbAyQgZAugVAHQAZhDBGhdg");
	this.shape_9.setTransform(-23.2,17.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgLAHQgDgOADgWQAPACAGATQADAKAAAcIgDAAQgQAAgFgXg");
	this.shape_10.setTransform(0.8,-217);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AAWBgQgBgbgBgNQgHgWgVg4QgTgygIggQgCgHAFgDQAFgEAAgEIAOAAQADApAYBQQAYBFgBA3QgNgFgCgWg");
	this.shape_11.setTransform(2.8,2.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AieEgQC7kcBokyIAaAIQgdBVgTBFQgcAzg5B1Qg0BwghA4QgdAngvBEg");
	this.shape_12.setTransform(29.8,74);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#EDE7DA").s().p("Aj3DkQgLhaAMhrQALhlAchOQA5gvCBgTQBHgLCRgPIAJAAIgLA0QgSBiACBCQACBUAiA/IAoAqIgVACQgPgMgfACQgXACgZAIQgggCgrAIQgrAHgZANQgiAAg2ANQg1AOgjgBQgIAAgLgHQgKgHgKABQgIAOAGALIgRAKgAiqA/QgYAIgOAWQgOAWAFAVQAFAYAbALQAmgCAVggQAWghgPgiQgQgKgQAAQgKAAgJADgAhDg3QglAiALArQAqAaAogeQAlgcgQgyQgRgOgSAAQgVAAgVATgABfixQgdAWgDAqQAdAoAmgcQAngdgJgxQgRgLgQAAQgQAAgQANg");
	this.shape_13.setTransform(50.8,-137.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#EDE7DA").s().p("AhRCYQg2gGgggcIiAjEIAQgKQAEAHAOAIQAQAJADAEIABAYQACALAKAAQAOABAGgUQAGgWAJgDQB4gYBFgKQBrgRBUgCQABgUgMgKIAVgCQAaAdAUAQQAbAXAcANQhGBjgpBLIhLAcQgsAQgiAIIg8ACQgjAAgTgDgAAHgiQgzAGgSAZQACAdAWARQATAPAbgBQAbgBATgRQAWgTABgbQgMgcgqAAIgQABg");
	this.shape_14.setTransform(56.5,-105.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgyAUQgFgUAOgVQAOgWAYgIQAYgIAZAPQAPAigWAfQgVAggkACQgbgLgFgYg");
	this.shape_15.setTransform(34.1,-126.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFC9B6").s().p("AhMAlQAZgZAsgUIBPgiIAFALQgNAHgBAXQgBAKAEAcIhHAFIgTABQgdAAgXgGg");
	this.shape_16.setTransform(40.8,-171.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("Ag0AqQgLgrAlgiQAkgjApAeQAQAwgnAeQgVAQgUAAQgTAAgUgMg");
	this.shape_17.setTransform(46.7,-139.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgtAgQgWgRgCgdQASgZAzgGQA4gGAOAhQgBAbgWATQgTARgbABIgCAAQgaAAgSgOg");
	this.shape_18.setTransform(57.2,-104.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#F7D9D0").s().p("AhDBWQhCgngjgRQAegnBNgoQA/gjBGgUQAlgMAhAtQAfArgFAoQgDAjgeAXQgNAJgyAaQgUACgTAAQg1AAgvgVg");
	this.shape_19.setTransform(52.6,-219.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgwAbQADgoAdgXQAcgYAjAXQAJAvgnAcQgQAMgMAAQgUAAgRgXg");
	this.shape_20.setTransform(62.1,-152);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFC9B6").s().p("AgJBnQgOgjgkg2Qgmg5gNgcQCGgLBYgUQgTAngRA9IgfBpg");
	this.shape_21.setTransform(60,-78.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("Ai1BEQgKAAgCgLIgBgYQgDgEgQgJQgOgIgEgHQgGgJAIgOQAKgBALAHQALAHAIAAQAiABA2gOQA1gNAiAAQAagNArgHQAqgIAgACQAagIAXgCQAfgCAOAMQAMAKAAAUQhVAChtARQhDAIh3AYQgKADgGAWQgFATgOAAIgBAAg");
	this.shape_22.setTransform(51.6,-115.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFC9B6").s().p("AhHCdQghg3AChmQgJgUgbg1QgYgtgKgfQAdgTATAYIAaAwQAdAgAZASQAgAYAkAKIA5AAQAPgCAXgOQAYgOADgBQgGAfALAjQAGAVAQAmQhIAmgoAQQg5AWgzAAIgYgBg");
	this.shape_23.setTransform(79.4,-49.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AhOB9IgGgBQg4gogFgrQgHgzAogxQAaggAzghQBSACAgAJQA1APAPAxIgEAIQgDAIgLgDQgNgFgEAAQgOgcgkgLQgggJgmAHQgmAIgbAVQgeAWgDAeQgIAkAXAiQASAaAhAVQgMAJgUAAIgGAAg");
	this.shape_24.setTransform(89.8,-71.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F7D9D0").s().p("AhmBzIAHgbQAYABAOgKQghgVgSgaQgXggAIgmQADgeAegWQAbgVAmgIQAmgHAgAJQAkALAOAcQAEAAANAFQALADADgIQAAAXgXAaQgNAPgeAWQgGAZgbAcQgcAegHASQgKAAgKAFIgPAJQgggBgbgHg");
	this.shape_25.setTransform(91.5,-68);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#F7D9D0").s().p("AgVCGQhLgIgehRQgehNAohFQAFgJAHgJQBFgdBJAdQBBAYAlAzQAAATgCAOQgHBQgiA6IgWgDIADgHQgUgEgeAMQgbAJgQAAIgGAAg");
	this.shape_26.setTransform(97.6,-138.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AhQBKQgwgwAAg2QgBg0Alg5IAbAEQgoBFAeBNQAeBRBJAIQATACAggLQAegLAUADIgDAHQgOAXggALQgZAJgsADQg2gaglgmg");
	this.shape_27.setTransform(92.5,-135.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F7D9D0").s().p("ABABUQgKgGgGAAQgSgegugxQgwgxgSghQABgEAEABQAEAAAAADQAdAZBCAwQA3AtAGA0IgGAAQgHAAgGgDg");
	this.shape_28.setTransform(104.6,-221.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFC9B6").s().p("AinCiQgLggAEgkQAEgmASgYQAUgbAdABQAEgKgIgHQgJgJAAgHQATgkAlg3QAthBAOgYQBRANAvA9QArA5AHBWQgNAygKAUQgRAigfALQAMhfh8gsQg6ABgnAiQgWAVgjA4QADAYAMAgQANAmADAQQgagMgMgig");
	this.shape_29.setTransform(115,-63.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAEALQgtgLgmgBQgEgOAHgHQACgDAMgHQAaAJA7APQAyAPAJAaIhOgWg");
	this.shape_30.setTransform(106.5,-172.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFC9B6").s().p("AgHAZQgygLgOgpQATAOA1AGQA8AGALADQgXAagiAAQgMAAgKgDg");
	this.shape_31.setTransform(109.7,-40.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFC9B6").s().p("Aj6DAQAXhZA+hwQBYikALgYQBpANA9gzQAvgnAghaQAEgBADADQAEADACAAQArByALA/QARBqgoBPQgTAVgqA8QgkA1gbAZQgPgxg1gPQgfgJhTgCQgzAhgaAgQgoAxAHA1QAFArA4AoIAGABIgHAbQhpgdgMiQg");
	this.shape_32.setTransform(94.6,-93);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFC9B6").s().p("ABBGuQg5gEg3hDQgwg5gXhFIACgxQAAgUgGgYQAEgTABggQACgkACgOIACgQQAHgkAZhJQAXhEAEghQgagBgQArIgYBIQhPgGglgFQhAgJgjgUQgHgDgCgTQgCgSgHgEIgCABIgFgLQATgIAXgMQBOhMAcgiQA3hCAchCQAxAsBLAUQBJAUBbgJQAdAnBBA7QBFA/AaAgQAWBIgdBLQgRAogpBLQhJghgogOQhGgZhAAKQgbAbgSAfQglA5ABA0QAAA3AuAxQAlAmA4AZQAsgDAZgIQAggLAOgXIAWADQgUAhgZAWQgyAsg+AAIgLAAgACTicQgHAHAEAOQAmABAvANIBOAWQgJgZgygRQg9gQgagIQgMAGgCADg");
	this.shape_33.setTransform(84,-159);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("ADOE6QAphRgShqQgKg/gshwQgCAAgEgDQgDgCgEAAQgfBYgvAnQg+AzhogMIgSgFQgcgNgbgXQgTgQgagdIgogoQgig/gChWQgChCAShiIAbACIgDARQgCANgBAkQgBAggFATQAHAYgBAVIgBAwQAXBFAwA3QA4BEA5ADQBDAFA2gxQAagVAUggQAhg6AHhRIAYACQALAUANAsQAPA0AKAYIAfBKQASAuADApQAFAwgQAwQgJAegbA1g");
	this.shape_34.setTransform(96.3,-124.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#F7D9D0").s().p("AgFBKQgxgIgZgGQgeg0ARgnQAOgkArgNQAogNAmARQArAUANAwQgCBBgdAeIhJgNg");
	this.shape_35.setTransform(113.1,-51.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#00A33D").s().p("EgxNAfeQgyABgigkQgkgjAAgxMAAAg7MQAAgyAkgjQAigkAyAAMBiaAAAQAyAAAkAkQAiAjABAyMAAAA7MQgBAxgiAjQgkAkgygBg");
	this.shape_36.setTransform(44,-29.5);

	this.addChild(this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-282.9,-250.9,654,502.8);


(lib.dado = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AilCmQhFhFABhhQgBhfBFhFQBFhFBggBQBgABBFBFQBFBFAABfQAABhhFBFQhFBEhgAAQhgAAhFhEg");
	this.shape.setTransform(-7.1,20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,1,1).p("ADrw9QhpgDhoAAQjFAAjGgBQizAAi2AEQhtAChtABQgtAEghAiQg9A8AJBaQADAZgBAZQgEC2AHC3QAHDBADDCQAECtAECvQAFC/gBC/QAACSARCRQALBhBUAyQAMAIAQgDQBCAHBAAAQCuACCvgDQCdgDCegBQC9gBC+ABQC5ACC6AEQBxADBtgLQAZgFAYgGQBygsAzh1QAJgUAAgVQACjHAAjGQAAjBgDjDQgDiwgDixQgDi2ABi2QAAg6gJg6QgRhjgYhjQgXhhhcgSQgDgBgCAAQlMgNlMgIg");
	this.shape_1.setTransform(-9.3,21);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EDE7DA").s().p("AJ5RBQi6gEi5gCQi+gBi9ABQieABidADQivADiugCQhAAAhCgHQgQADgMgIQhUgygLhhQgRiRAAiSQABi/gFi/IgIlcQgDjCgHjBQgHi3AEi2QABgZgDgZQgJhaA9g8QAhgiAtgEIDagDQC2gECzAAIGLABQBoAABpADQFMAIFMANIAFABQBcASAXBhQAYBjARBjQAJA6AAA6QgBC2ADC2IAGFhQADDDAADBQAADGgCDHQAAAVgJAUQgzB1hyAsIgxALQhZAJhbAAIgqgBg");
	this.shape_2.setTransform(-9.3,21);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgQAAIAhAAIgBAAIgdAAIgDAAg");
	this.shape_3.setTransform(79.4,131.4);

	this.addChild(this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-117.4,-87.9,216.1,219.5);


(lib.R4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Frecuencia absoluta y relativa", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.R3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Sucesos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.R2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Espacio muestral", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.R1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Experimentos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.Btn112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Disminuir el ángulo de lanzamiento", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"Disminuir el ángulo de lanzamiento",color:"#000000"}}]}).to({state:[{t:this.text,p:{text:"Aumentar el ángulo de lanzamiento",color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,9.5,1.2,1.633);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,9.5,1.2,1.633);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,9.5,1.2,1.633);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,49);


(lib.Btn111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Aumentar el ángulo de lanzamiento", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,9.5,1.2,1.633);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,9.5,1.2,1.633);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,9.5,1.2,1.633);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,49);


(lib.Btn21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Lanza el dado", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.Btn12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Experimentos aleatorios", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.Btn11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Experimentos deterministas", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.B36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text(" Sucesos igualmente probables", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.B35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text(" Sucesos poco probables ", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.B34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text(" Sucesos muy  probables", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.B33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Sucesos posibles", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.B32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Sucesos imposibles ", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.B31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("Sucesos seguros", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 286;
	this.text.setTransform(34,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,0,1.2,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,0,1.2,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,0,1.2,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.9,-14.9,290.5,30);


(lib.arbol = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3C290C").s().p("Ag8EYQADgYABgtIABhbQADhOAeiuQAHgmAmhHQAUgjATgcIgcBNQgfBZgHA0QgKA5gGB+QgFBzADAlIAHAjQABAGgNAFQgVAKgGAAIgBAAQgIAAADgZg");
	this.shape.setTransform(110.3,-55.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3C290C").s().p("AhiFcIgTgyQgOgogIgeQgOg2gBgKQgGgfADgfIAJhCIAHgsQABgQAVggQARgcAVgZQAQgTBEhMIBDhJQBJg/ANgQQAKgLgVAdQgVAegaAiQgNAQg2A/QgsA1gTAbQgRAZgnA0QgfAsgFAbQgFAgAOBVQAPBTARAnQAOAfAoAMQAUAFAPAAQgNAMgXALQgfANgJACIgLACQgNAAgEgMg");
	this.shape_1.setTransform(43.1,6.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#5F421E").s().p("ACeJPQgOgDgKgcQgIgVgNgVQgPgagMgZQgOgggvg1Igzg9QgIgNg2gsQgwgnADAAQAHACAkAaQAiAZARAQQAcAaAEACQAMALgKgaQgQgigIgVQgKgbgIgiQgIgigRggQgPgbgNgMQgJgHgjgOQgfgMACgBQAJgCA0ANQAKADAHgRQAGgQAAgZQAAgigPiYQgLhzgXhNQgMgogchOIgZhHIgLgeQgBgEAOARQALAPAUAnQAZAxAKARQARAbAMgYQAOgnALgRQAPgZALgGQALgGgNAUQgKAQgIAfIgQBDQgHAgAJBDQAFAmAOBSQAGAkAMB+QAMBzAGAkQAIAsA2B1QAVAtA4BsQAWAqAdAKQAbAIAVgWQAQgQgHAWIgNAuQgCAOgIALQgJAOgEAKQgFASgLAAIgDAAg");
	this.shape_2.setTransform(-4.6,-30.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#543611").s().p("AFKOHQgTgMg3hBQg0g+gVghQgNgVgJgdQgLgegMgWQgNgWgHgpQgGgngKgMQgMgPhUgXIhrgeQgYgKAcAAIApACIBIAIQBAAGACgLIADgyQADguAEgfQAJg7gsjFQgNg4gnhTQgihQgggwQgagpg3glQgogcgmgQQgWgJhdgHIhYgEIApgGQAwgFAoADQAyAEAUgBQAXgBgJgHQgIgGgagdIgZgcIAtAbQAyAfAgASQAgASBCA+IBYBaQAbAbAhgKQAagHAPgUQAMgQAdg3QAdg4ARgpQAOgjgChdIgFhXQgEgZglgoQAkAhAXATQAgAaAagXQAVgSAbhAQAVgvAIhrIAEhhIABA7QAABAgDAgQgEAigaBjQgXBTgNAoIgdBdQgXBGgTAeQgUAegaBfQgPA2gcBrQgPA4ASB3IAcCzQAHBaAXB5QAbCNAaAmQAhAwAsAkQAxAoAQgUIgXBKQgFAUgXABIgCAAQgUAAgVgOg");
	this.shape_3.setTransform(-25.8,-71.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3C290C").s().p("AhzYhQgfgOAAgMQAAgigJhgQgNiBgUhQIgri8QgVhVAAAtIAACHQAABDgIhJQgNhkgFgvQgJhPAEhSIAKjgQAFhtAEBDQAEA3AICwQAHCBAEhWQAPkSgekSQgdjogLiDQgUjtAOijQARi1AehuQAaheAxhTQAxhTBFhoQBIhyA0hEQArg5AwgtIBBg9QAcgfAlgbQAlgcgPAVQiRCzg5BEQgfAmgvBJQgvBMgRAWQglAvgXAnQgaArAdgaQAsgoBigcQARgFAlAEIAiAEIhKAXQhMAZgTAKQgXALggAlQgfAlgRAkQgTApglB4QgoCAgLA9QgJA3AIDbIANEnQABAwASEnQAREaACBTQACBcAOBxIAdDsQAXC+AqDdQgPgFgPgHg");
	this.shape_4.setTransform(88.3,144.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#5F421E").s().p("AAJYnQgagRgJg2QgLhBgDgfQgFg1AAhIQAAhNgTAVQgSAWADBBQACA3gJBXQgIBEgIAlQgFAWgzgLIgzgPQATg5AAgiQAAggAGg+QAHhLAKg7QAJg2ADhOIADh7QAIiYAPjdIASjfIAYkXQAJhwgHiqQgKidAAgbQAAglgVhdQgShUgOglQgKgcgygxQgsgqgZgPQgMgHh0g4Qh0g6gWgMQgcgOAQgBIAuAEQAbADBKAcQBMAeAYATQAmAdArATQA3AZgCgcQgDgagWg+IgkheIh2ktQArA+AYgkQAIgLAFgUIADgSIgBA1QABA+AMAtQASBFBNBdQBVBmApgjQAZgXBOhnQBQhoA2gwQA8g1BpigQBiicAPgTQAUgaAmgGQAPgCAHADQAHACgHAGQgWARgmArQgyA4gjA3QguBKhBBaQhJBmgVAQQgVAPhnCAQhgB6gOAYQgLATgBBzQgCBnAGCXQAUHdgEB6QgCA3gCCNQgCCCgCArQgCAuAZBdQAYBgAAAYQAAAsgNgWQgLgXAAg0QAAg/gQBtQgQBvgCBxQgDBlAfC/QAOBlAYCEQAHAvgRAAQgEAAgGgDg");
	this.shape_5.setTransform(42.8,146.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#543611").s().p("EgFHAjMQgfgFgagGIgvgKQAYjZAZkNQAyoaAFkIQARmAgHiQQgMjlhlh2QhxiChEguQg9gphOgFQhFgFhUALQhKALgnAQQgcAMg5AOIg0ANIBbgnQBggoAagJQAYgJAngDQAygFANgCQAfgFgXgeQgYgeg5gaQhCgehBggQhMgmgNgLQgMgIBiAgICSAxQAlAMA6AWIBbAmQARAHBSAXQBCATAhATQAxAeASgBQAWAAgYgvQg4ilg4iGQhskEhog+QjGh1g8gbQighLi3gYIAMgEIBQANQBiARBYAWQEaBJBMBkQBGBcBFA4QA7AxAHAMQAQAdAbgrQAYgnANg5QAHhFAGgfQALg2AogYQBUgzBYhMQAwgqAPgXQAVggAAgvQAAgsgIhNIgIhFIAXBUQAWBZgDAYQgDAegUAlQgVAngkAnIhTBaQg1A2gfAbQgfAagIAhIgSBdQgSBDgCA1QgCA3AOA2QALApAeBLQAdBLADAKQAFAVBUgmQBQglAsglQBuhiBChRQAjgrBChvQA+hnAcg7QAdg9AWhLQAbhbAVh+QAbijAEhSQAFhxgdg5QgkhIgdhMQgkhZgNhAIgYhuQgKgvAAgaIgEiQIAOB5QAQB/AMAZQALAZAZBOIAkBvQAKAcAeAuQAdAvAHAUQAKAaAfgbIA6hAQAmgqBYhIQAqg6ALgaQAKgXgIAhQgHAfgKANIg2BBQgxA4giAjQhlBkgKBpQgDAqgICTQgJCMgOA3QgTBNAFAdQAFAkAogYQAqgZBAgZQBAgZArgJQAcgFBngJQBkgKAbgGQA+gNAggLQA3gRAPgUQBgiCASgeQBBhqAbgPQAagQBIgxQhyBrgaAmIhGBuQg2BWgNANQgSARgoATQgoATggAGQg3AJhPASQhvAYgzARQg+AUhCAjQhEAlg7AtQg0AngkA3QgWAfgjBBIhABsQgmA/gUAUQgfAfgwA2Qg8BHgmA1QgvBCgdBEQgiBPAABBIAEEHQAEDkAABRQAABLAGCbQAECOgOBcQgPBiAGBcQADA3AOBtQAHBTAQh1QAPhxAAhoQAAgxAHikQAGiSgChPQgDhjANgXQANgXAABRIAFDYQAFCpgDBiQgBBUAACNQAAB5gCAqQgCAqgHAsQgDArAMBbIARCZQAFAzAMAlQAPAuALBTQALBTgOgeQgVgughhiQgnh3gCgtQgEhIgZhJQgahMAFCNQAFCFATBnQAKA4AQBFQAHApAjAyQASAaAQAQIAWAbQkKgIgxgHg");
	this.shape_6.setTransform(60.8,80.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#311F08").s().p("EgCEAwlQhXgKgagEQgngGAAgIQANhtAOiHQAdkPAFimIAfn5QAWlygNlcQgNhthChyQheijiUglQhcgYgYgFQhMgOgtAMIiDAlQAMBngdAWQgVAPgaBBQgNAhgIAdIA5AiIhQgeIAahYQADgKgJgFQgKgGgKAJQgQAMgtA3IAmhQIAmgVIAbAAIAtgyIgVhLIiSArIg1AAQgDAEgKArQgJAngGACQgIACgQAmIgOAmIAZBAIgrhAQAPgqAIgRQAEgKgPgIIgRgHIgXAHQgaAIgJAIIARgaIAQgGQASgHAEAAQAIAAAoAIQAQgtgDgRQgBgEADgIIhlAAIAggMQAkgMAbgEQhsgtgRAAQgOAAgnAOQgnAOgPAKQg9AqAAAMIgDBMIhYAdQA5ghAEgRQACgLgBgdIgBgbIhMAhIh2gEIg5A3IAqhYIA4APQA7AOAOgIICUhUQAbgPAxgSQA7gVAKAIQgCgLgIgLQgQgXgfgFQgfgGgcgbIgVgaIA7AQQA9AQAJAGQAMAGAtBWQAyATBEAXIACgBQADABAEAEQAXgHBCgZQA5gWAWgFQA2gMBWgfQAfgJAPgTQAegkhRgvQgqgYg+gbQhHgfg/gVQhNBXAAAPQAAALg0gJIgzgKIhYAAIAmgOQAogNAKAGQAPAIBFAAIAthHQAGgLAMgJQhggcgrANQg1APhUgoIhCA/QgOALgmgEQgqgFgDABQgNAFgmgTIAagCQAegCAPAEQAgAHAMAAQAZABAKgRQALgRAigkQgYgMgXgPIgSgMICRAfQAQADAfACIgCgsQAAgJgTgSQgTgRAAgGQAAgIAJgnIAKglIADAoQAFArAPANQATASAEBBIBrADQA+AEAdALIBDAcIAFgpQAAg2gPgaQgKgPgRgNIgPgJIhfAEIAygOQAwgRgPgPQg7hAgNgUQgHgKgkgQIgwgUQgMgFgNgbQgNghgIgPIguheIAfAhQAgAhACAQQADAXARAUQAUAYAdAAQAaAAAUANQAKAGAEAGQAEg7AAgVQAAgNgPgvIgPguIAbA+QAbBBgFAVQgMA4AfAcQAXAVATAdQAIgZAEgZQACgTATgaQATgaAUgNQARgKAcgGQANgEALgBIgoAZQgpAcgHAKQgNATgLAbQgQAlACAWQADAVAjA0QASAaARAWIgDAqIAGgVQAVgHAXgLQAugXAJgVQAphZAnAJQAiAIBNAuQhcgMgTgEQgMgDgUAWIgdAjQgKAMAUAQQASAPAaAHQAeAJA1gEQg9AUgWAAQgLAAgigZQgfgXgIAHIghAdQgZAVgOAAQgNAAgKAMIgDAyQBzAwAgAMQAVAHBKAQQA0AKAfAWQAbATA+APQBBAPAdASQBGArAXgDQhckFglhWQg/iRhPhiQhtiGkYhiQhXgfhegYIhNgRQgcAGgmAcQgUAPhCA4QhBA4gWAXQgoAngZAwIAoAVQArAXALAOQANARAKAZQAJAZgCAOQgBAMATASQAKAJAKAGQgMgCgOgFQgcgIgEgKIgGgpQgFgggPgOQgQgPhEguQgbA4gVBGQgWBJAAApQAAA5gdCAQBFAaAQAMQAMAKAQAoQAOAmgCAHQgCAJgkhMQgwgcgUgDQgMgBgNgHIgDAKIhMDFQAEgaAHgiQAOhEAQgoQASgqALg9QAGgmAHhNQAJhWAPhEIgdAdQgHAIg9A7IghAYQACBagKAfQgKAhguBGQASgvAKgfQAHgUACgYIABgqQAAgTAEgbQgjAXgOADQgSAEgtAcIgpAbQAMgQARgQQAhghATAAQAVAAAygiQAvggAQgXQAPgUBVhXIAIgaIAshhQAYg2gSADQgMABgxASQgxAQgfAEQgdAFhYgJQhXgIgYAEQgkAGg1AsQgxApgiAvQgqA7hTBUQAPgmAigqIAogzQAfgpASgVQgugWgeAFQgWAEgggKIgbgKIAgADQAjACATAAQAvAAAzgDQASgTALgJQAhgaAFgOQAFgSgcgPQgdgQg6gUQhEgYgsgGQgWARgRAYQgrA7g9AlQgkAWhbAOQBWgZAegRQAfgRBehzIjCANIAvgKIBlgUQA4gJBhASQBjAUAhAeQAfAcAwAJQAXAFBJAEQApACBwgZICQgfQAggFA7g4QBJhGAagQQAvgcAAgjQAAgcgbgWQgSgPg3hbIhMh9QgWgggoAHQgXAFghAUQiGBWg0AkQgDACAEAnQAEAmAEATIABAHQAKAEAVAGQAbAJAMAAQAPAAARAFQATAFAEAGQAEAGAcAHQAaAGAIgCQAKgCA5gZIA1ATIg1gCQgFAAgXAKQgXAKgIAAQgKAAAJAJQAEAEAOALQAHAEAcAHQAeAHAGACQANAHAEAlQgGgJgKgJQgSgTgOgCQgbgFgPgEQgbgHgHgMQgHgLgSgFQgTgEgEgDQgEgCgTADIgRAEIAMAgQAJAhgJAGQgMAGgNAZQAJgSABgFIAEgLQACgIgGgOQgGgPgFgWIgDgUQgJgGgRgJIgWgKQgKgEgKAEIgEABQABAsgQAcQgUAkgoBtQgDgcANgkIAdhFQAUgvgBgYQgEg0gVgxQgHgOgBgTQhwAogaAAQgVAAgsAeIhBAqQgiAQirBIQAfgVAlgXQBLgtAcgIQhEgIgSgOQgLgJgfACQgiAEgNAAQgQAAgTgQIgQgRIAYALQAdALAagGQA2gLAtAUQAVAJBAAGQAagQAigcIAdgaQiRguhIgRQg5gNgyALQg2AMghAlQgHAIgNAHIgWBnQgDAQgaAbQgMAOgMAKIguBAIAchDIAmgpIAXhDIAEguQgkAMg1AEIguACIAvgPQA1gRAagKQAPgHAqgfQAtgjAVgLQgzgdgRgKQgMgIgRgWIhfANIgegvIAtAZIBCgOQgHgQAAgJQAAgQgSgkIgSggIAFgyIAIAXQAJAbALATQASAfAIAtQACAKATATQATASASAJIBDAmIAOgBQAnAEBvAbQB0AdBFAYQA9AWBSgtQAtgYA3gxQAYgVBDgoIA+gkQg2gpgqgRIhhgeQhOgZgtgZQgwgagoAGIgeAMQgaAOgiAOIACAAIgpB1IAWhvQg+AVg8ACIgdgCQAaAAAigJIgog5IhhgnIBzATIAwBDIgJAFQBOgYBbg4QgpgUgSgFQgNgEgRgnIgPgmIgugRIA4ADIAmBAIAwAcIAkAaQDRBHAtADQANACASAGIgMhNIg8gzIgDgvIAUAqIBKAyIAOBgQArATA6AhQAwAbAfAWQATANBfCMQBbCIAqAVQA1AaBlATQBdARAngEQAcgCgZgkQgkgrgJgPQgNgUgfgZQgbgXgRgHIgtgXQgLAtgMAFQgPAGg4ARIgaAXIAYgkQAogIAKgEQAHgDAGgJQAGgIACgJQABgIAJgTIhFgkIhIhIIA2AlQA6AkAVADQAVADAxAgQAYAQAUAQQgbgdgegzQgbgthahjQhtgigUAAQgWAAgagHQgggHgJgMQgIgKglgYIgkgVIAjAKQAlAOAJAMQASAWBCAAQAZAABGARQgPgNgRg8IgOg5IAgA8QAmBBAhAaQAcAWAsA5IBEBcIgBgFQAShZAFgfQAGglg7heQgRgcABgyIAGgtIAEArQAIAyAQAeIAZAqQAPAZAHAOQADgKAHgOQAKgVAIgGQAJgHAFgUQAEgSgBgWQgBgRAPgdIAQgbIgJAeQgKAhAAANQAAAHgEAYQgDAQAFgBQAFgBASAFQASADALgMQAKgLAXgCQALgBAJACIguAXQgIAEgRACIgaACQgKACgHAOIgMAcQgJATgPAnQgIAlgPBWQgDANACARIABABQAVAZA7BOQA9BHBAAbQBDAbAZgmQAOgUAFg5QADglgNheQgOhkgWhXQgZhjg/hYQhGhhhOgaQhDgXhFgEQhBgDgwAPIhrBsIh6BUIAcgqIBMg4IAxg7QgnAPgoACQgqADgagLIgXgHIgsAoIhZAlIBAgqIAbgpQhDgIh5gHIhsgGIBTgBQBiAABFADIgtg8IhHgyIAIgwIAKAqIBJAtIAPAPQAKgSAHgJQAFgIACgQQACgPgCgOQgBgKAPgSIAPgQIgJAQQgJAQABAIQABALgCAQQgCARgFAJQgIAMgHAZIgFABIA0A0QA0AEAVAIQAqARBQgkQA4gZAugjQAYgTBdADQAvACAqAFQhrhHhuhDQhJgshZgFQg4gDhIAOQgoAIhbAdIiDArQgXAHgpADQgJApgPATQgRAWgmBLQAHg6APgUQAPgSANg7IhmADQg8ACgaAEIgoBPIhlAaIhAAvIhbAkICJhnIBbgUIAeg4QhuAegvgKQgUgEglgRIgfApIhHACIhZAXIBEgkIBMgMIAbgbQgkgRgZgPQgbgQACgGQACgIBIAgIgWgMIgXhUIhAhUIBPBLIAhBqIBaAqQAbANAxgSIBYgiIgmg6IhHgcIg4h7IBMBtIAeALQAhAOALAOQAOASAoAkIBUgCIBbgDIglgSIgwgoIgJgjQgIgiAEAFQAEAFATAhQAVAhAUAKIBOAmQAUgBATgDQA5gJAYgSQAWgSgYgKQgwgUgYgMQg2gbgWgYQgbgeg5goQg7gpgYgDIiggQIBggJIg1hvIhggaIgXhDQgCgFAQAZQAYAkAKADIA2AHQAqAFADAKQAFARApBOIAkAYIAOAAQAdAAA2AvQBCA5ALAFIAFACIAPgXQgmhAgFgiQgDgVgVgaIgVgWQAcATAZAdQAZAdAAAPQAAAQAdAhQALgNADgDQALgHAPgcQAPgfgFgJQgFgJABgtIABgsIAkgOIgKASQgJAWABAYQADAnAKAtIgQAOQgTAQgLASQgPAYgJA2QBVAsA2AYQAiAPBegSQB2gWAVAAQA0AAAPgKQANgJgPgXQgpg9g3hmQgfg6gyghQg5gcgZgPQgsgagsg/QgzAKgrAFQhLAIgMgMQgNgOg2gOIg0gMIhPAGIAsgUQAxgRAYASQAaASAjANQAdAKAQAAQAKAAAcgJQAhgKAQgDQAWgEAfACQgQgagGgTQgJgggkgoIgjghIAqAhQAwAtAkA8QAiA7AhAQIAgANQAWAJAUAMQArAcALgCQAHgBAAgRQAAgOgKg5QgKg/gLglQgKgnhDh7IiAgNQgbgIgegGQg8gMgSAMQgdAVgcANQglASgKgKQgJgIgzgBIgxABIAxgNQAzgLAOAHQAQAIAegNQAbgLAOgPQAJgLAbABQAQAAATAFIA8AIQhqhXgSgLQgFgDgHgMQghAJgdAFQgxAIgLgKQgNgKgsAEIgqAGIg2AfQAMgNAQgNQAhgaAaACQAPABAqgCQAcgBAGAFQAFAEARgKQAUgLALAAIAiAAQgIgSgJgZIgHgVIgyhGIAhAWQAiAZABAMQACAOAPAkQAPAjAGAHQAIAIAhAcQAkAfAMAFQASAJAeAhIBhARIhUh4QgOgVAMgyIAPguIgZghQgZgjgBgFQgCgFAJg6IAIg5IgBAwQgBA0AFAMQAHATApAtQAog+AAgIIAIggQAHgcgCgKQAPA1gHAXQgFAPgQAeQgOAbgLARQgIANgJApQgIAjAAAMQAAALA3AyIAsg9IgfBIIBFBzIAyBhQAHgLAHgQQANghgBgaQgCglgJglQgKgrgMgMQgNgMAAguQAAgtAKgfQAIgYgWgkIgYggIgCiXIAWCPIAfBAQgDBXgFAQQgFARANAcIA6g1IgUAfQgVAggCAHQgCAIAMBDQADAOAAAiQADAZAMgOIAWgcQAPgWAfhSQAFgmADgMQAEgNgDgSQgEgTgKgIQgJgJgFgTQgFgSACgNQABgKgIgfIgJgdIgwg4IBAhWIgFhoIAFhcIAGAsQAGAuAAAOIADBTIAJgMQAMgPAOgJQAXgOAcgtIgKg1IARAWQAPAXgHAIIgYAkQgTAbgMAKQgKAIgWAcQgVAagLAIQgQALgJASQgIATAKAIQAQALAWAhIAOgLQAQgMALgCQAPgCAPgLQASgNAFgQQAFgNAagYQANgMAMgJQgcAygKAOQgJAMgTAQQgVASgMAEQgSAGgHAGQgLAKgCAXQgBAVAKAjQAGARAFANIAaAaIAchGIgLA9IAQAHQARAFANgDQAPgEAWgVQAVgUAAgIQAAgHAfgHIAegGIgwAfIgtBDIhCAAQgHAAgQAVQgLAPgKARQgEAHgKAMQgFAUgGAPIgnBYIgrB1QgGAaAAAeIABA1QAAAsAIArQAKAyAQAOQAOANAjAzQAhAwAnA/QAVgmACgLQACgJAAgiIABghIA4gpIA6gGIgUAFQgXAIgIAHQgMALghAkIACAtQApAFAKgFIAzgXIAcARIgVACQgWADgIADQgLAFgTAGQgVAFgFgCQgFgBgMANIgLAOIgDAbQgCAgAEAVQBKBfDKBoQAsAWAJgbQAEgPgDhVQgDg/grhKQghg6g3g8Qg2g8hfhbQhVgjgOgHQgNgHgfgHIgegGQghghgCgJQgCgFAUAJQATAJAIAHQALAIA/AMQAKACA7AcQAFg1AFgLQADgIgMgUQgMgTgUgRQgRgPgIgdQgHgZAEgSQgPgqAAgNIAAhFIAJAQQAIAUgCAOQgDATANAnQAVgWAwgdIgNhcIAcBUIAZgCQAZgDAIgEQAJgEAKgOQAKgOACgJQABgHAPgcIAOgbQgFBGgNAOIgZAcQgTASgQABQgSACgSALQgPAIgXATQgUAQgJAZQgJAZAKAGQANAIAZAaIAzg4IgmBGIAPAyIgSAvIANAeIAJABIBABHQBMBSA+A9QBNBLAWB8QAFAEAJgLIAOgTQALgMACgbIAFgQQAFgQAEAAQAFAAATgXIgVgbIgWgNIAkgEIARAiQAZgNAAgGIAFhHIAEBRQgHANgKAOQgUAcgOAEQgPAEgDAUQgCAKABAKIAJADQAKADAHgCIAZgFQASgEAJADQANAEAdACIAPgdIAXAFQAZAGAHAEQALAGAbgCIgbAMQgegOgPAAQgKAAgOAQIgMAPIAcARIAiA0IgrguQg4gRgLgIQgIgGgbAJQgbAJgKALQgIAIgRAOIgVARIAEBAQACAyA6A5IAzAwQAgAdARAVQAnAxApgSQAjgQAZg5QAbg7ALhKQAOhXgVg0QgTgvg1g5Qg7g6gVgXQgTgUgphAQgphAgggkQgogrgogCQgGAAg/AMQgeAFgZgWQgMgLgggsQgTgagagdIgXgYIAiAXQAoAfAcAiQAdAhAdgCQARgCAogIQAgAAADgJQADgHgQgSQgSgUgUgwQgYg6gCg2QgEhUg9i0QgOgqgmguIgjglIAIADQALAGALAIIgEgrIgLgXQgKgVAAgKQAAgLAMgVIALgUIgHAcQgHAdABADQABAFAMATQAMASAFAHQAIAIgIAsIgCAAQAbAZAVAmQAbg3ADgKQACgGgEgVQgEgZABgJQABgNAMgfQALgfAAAGIgFAnQgEAmAGATIADAQIAEgBIAOAAQAQABAEABQAIACAXgMQgTAXgGACQgEABgogBQgBAVgKASIgZA1QAhBAAPAxIALgGQAPgJATgTQAmgjAThSQAHgagEg6QgPgvgOgPIggglQgSgWgHgVQgIgXgSgaQgPgUgLgLQgHgHgXABQgVABgNAFQgKAFgXgCQgSgBgQgEQgJgCgVAIQgRAHABgCQAKgRADgDQAMgOAOACIATAGQAEABgDgHIgJgfQgIgbgHgNQgHgNgggWIgegTIA9AZQAGACAOAWQAPAaABATQACAUAYAIQAVAHAWgGIA1gMIgwhUQgKgSgGg3IgDgzQAAgFgNgBQgPgDgCgHQgCgKgLgPIgKgNIAOAHQAQAJAEANQAFANALgDQAFgBAEgFIAAglQAAgHAIgWQALgegGATQgDAMAAAsIADAfQADAggDALQgCALAEAQQADAOAFAJQADAGAJgDQALgDACAAQAHADAsgUIAXgJIgLAFQgNAHgDAGQgDAGgSAIQgSAJgKAAQgKAAABAQQACAPAJARQAHANATATQAOAPAHAFQAFAEAMgHQAOgIAEgKQAFgOAAgzQAAgMAFgIQACgFADgCIgCBUQAAAHgKAOQgKAPgLAIQgKAHgEALQgDALAEAGIASAhQAQAhAKAQQAMAVAKgDQAJgDABgTIADgiQADgRAGgKQAGgJgBgSIgCgXIgDg2QgEgkAAgPQAAgagKggQgDgMgCgXIgEhMIARAhIgBAeQAAAfAIAKQAJALAAATQABALgCAYQAAAVAIANQAIAPAQACQAPABAOgNIAVgWQAIgJADgOQACgMgCgLQgBgIgJgSIgJgQIAMgbIgEgiQAeAcgJACQgHABgDAVQgEAUACAGIAMAhIAMgTQAOgTAKgGQAPgIA1giQgmAvgNgDQgJgBgRAbQgQAZAAAIQAAALgVAlQgYAqgQAAIgggDQgOgBADAPQACAQgCAhQgCAfgEAcQgEAcAAAiQAAAkAGAaQAHAkACBNQAAAXAagFQAVgEAhgWQANgJAdgaQAMgLgEAQQgKAlhsBAQg2A/gpA2QgaAiAIAmQAFAbAcBiQARBRAwA5IBbBYQAmAlAFgXQABgvAFgiQAOhQghhbQgMghgYg2IAAADQgKADgNACQgUACgKgFIgagPQgQgIgIAEQgHAEgKAAIgJgCIATgHQATgHAEACIAUAMQARALAEAAQAIAAAjgIIgSgnQAVAOAaAqIgBgHQAPgeACgMQABgIgLgeQgIgVgJgRQgDgIACgiIADghIAMBBQABAHAJAUQAIATAGAKQAGAKgBAUQgCAUgIAJQgIAIgIAXQAhA5AZBFQAWhpAThDQANgrgGgfIgShIQgGgYAEgYQAAgPAHgdQAGgdAGgLQAIgPADhRQgig/gPgNQgIgHgCgZQgBgdgEgGQgGgJgZgJIgegJQgFgBARgDIASgCIAuATQADgDACgGQADgLgEgMQgHgQgDgXQgDgZAFgHIAVgWQASgTAHgKQgVA1gIAEQgHAEAEAZIAHAkQAEAegKAUQgDAJAFAWQAFATAHANQAIAQAMAHQAPAJAKgTQAGgLAUgeQAOgWACgLQADgNgEgWQgFgWgFgBQgFgBAEgkIAFgkIABAbQACAdACAIIATA5IAlgbQAJgJAVgnQADgegCgSQAJAygCAGQgOAlgRANQgbAVgRAXQgJANgQAeIgPAaIAQgGQASgHAMgBQAPgCAQgGQARgHAFgGQAFgGAMALIAMALQgZADgNAGQgKAFgYAGQgZAGgKAAQgIAAgPAMIgNANIgJBHIgLA4QgFAiAMgGQATgLAugMQgQAQgPAFQgMADgMAIQgNAIgFAIIgFAQIADBQQADAvAVgBQAOgBAygUQAPgEAXgNQA2hCAHgHQAIgHALghQAMgigDgOIgJhDIAig0QAKhlgEgdIgKhWQgxhmgMgLIgggkQgbgfgJgGQgJgGgXATQgaAUgBAAQgFAAAFgHIAJgOQAFgGANgIQAMgIAKgDQAOgEAYALQgJgcgCgVQgBgNgWgOQgNgHgNgFQgEgCACgqIACgqIAJBHIANALQAOALAHABQAMACATAbIACAmIACAQQAEARAHALQAGAJASALQAQAJAAACQAAAHANg5QAGgKAEgOQAIgcgMgRQgMgRAQgQQAIgIAPgHQAFgEAkgLQgcAZgIAEQgGAEgEAQQgFASAEAJQAEAIgGAVQgGAQgFAJQgEAGgEAaQgEAYAAANQAAAPATA0IAPgLQARgMAIAAQAJAAAJgaQAJgYgCgGQgCgFAyghIBJhqIgKg1IAchLIgNBJIANA9IhDBVIAoARQgcAAgKAEQgGADgcASIgbARIgLAoIA9gHIhHAVQgXANgFAEQgEADgDAQIgDAPIAOBVIgBAdQgBAfgCAKQgEAOAAAmIBOgRIARg0IA1gRIAXgFQAZgGAJgGIAGgCIAAgKQACg2AIgSQALgYAUgeQAYgmAVgQQAKgLAVgpIgvg5QAUhYAAgiQAAgVgThBIgUg8IAUAZQAUAdABANIAJAtQAGAgAAALIABAaQgBASgEASQgHAZAkA0QANgcASguIgDhrIANgaQAOgaAHgDQALgEAuhLIAPhDQgDBogMAJQgKAHgUAcQgWAfgFASQgIAZAAA6IBBgIIAXg7IAegQIgaA2QgGAMgIANQgQAZgMAAQgMAAghAqIgfAqQgOAZgTAdQgjA4gWAQQgbAUgPAuQgRAxAOAjQALAfACA1IACA3QABAEAQgeQAWgqAYgYQAcgaAbhSIAVhNIAAA2QgDA6gQAaQgiAygRAcQgdAzACAaQAFA8AfBsQAKAggmA3Ig6BIQgNASgmAlQg+BvgbAbQgcAbgbA2IABgCQgHAPgGAXQAZgIAxgVQAUgJAQgUQARgVAEgaQAHglA0AAQARAAAwAlQhDgQgPAAQgKAAgMAQQgGAIgMAWQgGAKgDAXIgCAVIA/AJQAGAAgVAFQgVAFgKAAQgKAAgNgGIgTgJQgEgBgUAQQgVARgOAAQgSAAgbAQQgEAYgEAqIgGA+QgOBtgQAuQgOAkAJAPQAKARAlgaQAqgeBFgkQAigiAHgZIgThhIAZgLQAbgOAMgNQATgVAfhDIgDAwQgEAxgMAIQgMAIgYAWIgVAUIAPAlQAdgOAxgIQAXgFATgBIBQAdIiAANQgbADgjAbQggAZgbAlQgjAvhMAxQgMAIArASQAWAJAXAHQg5gEgagJQgVgGgSAMQgUAMgOAdQgTAlgxB2IgFAAIghBtQgVBCgNAzQgmCKAdDlQAZDLA/C4IAFANIADADQAuA6AQAOQAUAQANgSQAEgFAUgnQASgiAbgdQAeghgCgQIgRgjQgTgqgbhYQgHgZgDgbQhJhGgfgUQgUgOgKg1QgIgtAEgSQACgLgSguIgSgsIgEh5IAQA1QAQA3ACANQAEAVAXAqQAtgZAQgRQAJgKgHgsIgKgqIATAbQATAdAAALQAAAQgKAXQgNAbgPAFQgTAHgNAPQgPAQgCAVQgDAXAGAWQAHAZAQASQAUAVA/AxQAAgvAMgkQAPgnAVgoQAZgwAIAGQAHAFgUAmIghA9IgDAIIASghIA2gEQAXAAA8gmIAXAiIgqAAIiJAxQgLA0AMBLQARBgAzBMQAQAXAggRQAYgLBBg2QAtgnADgtQgEgwADgXQAFgggLhAQgLg4gLglQgLgdglgiQghgfgagKQgkgNgUgIQglgPgRgTQgOgPgPgnQgPgmgJgoIhngfIBjAMQgEgTAAgSQAAgigLhGIgMhAIAqBQIAGBYQANBiAfAsQAgAuAyAHQAqAFAFgQQACgHgahDQgehLgDgOQgIgegDgPQgEgaAIgQQgfhTAAgPQAAgLAVgXQATgVANgHQAPgJAQhYIAPiGIADA0QADA2gCAQIgFAnQgCAYgFAMIgNAnQgJAYgMAIQgNAJgDAXQgDATAEAQQACAJAIATQAagjANgOQAdggAkgWQAKgGAQgOQgDgEAAgKIgXiBIBKgzQALgIA5hHQgiBPgLANIgqAXQgfASADASQACAVASBNQA8hAA+hlIgxBkIBAgIQAWgEASgVQAUgXgDgYQgCgWAGgUQAEgLALgWQAMgVAAhYIATBQIgQApQgPAsAEAPQAGAUgOAiQgOAjgUADQgQADgwADIguADIgeA/QgqAkgoArQhUBVAAAcQAAAdAsBYQBcgHApgJQAXgFARgwQAPg0AGgMQAHgRAlgKQAbgHAUAAQAPAAA9hgQgaBHgMAVQgHAMgaAHQgeAGgJAEQgQAHgFAVQgFAVASgDQARgCAhAYQARAMANAMIAhAIQAjAIAMgDQAMgDAcAWQANALAMAMIhfgVIg4gDQgogDgHgPQgHgQgegGIgcgDQgPAlgPAJIgWAdQgQAUgXgHQgWgIgXAXQgRAQgKAWQApBLAjArQAoAyAaCUQANBKAEBAQARgOAUgTQAoglAPgbQAKgUATgwQhhhXADgZQACgSAUgxIAUguIgyhQIAlAaQAkAcAAANQAAANgJAYIgSArQgJAYACASQACAWARALIA7ArIAkhlQAJgdAkgpQATgUAQgPIgXAsQgZAzgKAmQBJgIALgDQAHgCAdAHIgcAPQgSAJgJAAIhEAAIgBgCQgDATAAAIQAAAwgoBdQgpBfghAcQgFAIAbAWQANALAOAJIAqgmIBBANIA1gEIgqAdIg1gIIguAlIA9ARIATBYIgthHQgTADgUABQgnABgCgNQgEgTgug+Ih4B5QhnB5gVAcQgSAZgQBJIgWBkQgIAfAdA/QAcA6AUAMQAoAZAbABQBYgiB2iPQB7iVAwiKQA/i4AajLQAcjlgliKIhQkMQgqiQgHhsQgIhwgQiDQgPgtgJgHQgogdgYAAQgOAAgWgRQgTgQgEABIgTAJQgOAGgJAAQgLAAgVgFQgVgFAHAAQAIAAA3gJQgCgmgKgQIgRgeQgNgQgKAAQgJAAglAIIgjAIIAagSQAcgTAKAAQA1AAAGAlQAFAaARAVQAQAUATAJQA9AZAVAGQARAFACgJQADgHgKgSQgHgMgDgdQgDgdgGgMQgGgKgRgoQgRgmgIgMQgIgMgMgfQgLgbgDgCIgkgbIARAHQASAFABgIIADgqQAEgkAEgMQAFgLgGgaQgGgaAAgGQAAgGAZgqIAYgoIgTApQgTApACAEQAEAGADAdQAEAfgFAQQgIAVgDAgQgDAlAIAMQAFAJAMAbQAJAUABgDQABgFAMgLQALgMAMgIQAIgGANgRQAKgNgBADQgCAGgSAeQgTAggKALQgKALAGAYQAEALANAcQAuBcALAOQAIALAIAYIANglIAPgiQAMgcgBgVQgBgXAigiQARgRARgMQAHgKgIgTIgQgiQgGgNAMgOQAGgHAHgEIgBAXQAAAYAGADQAIAFAFAOQAFAPgCAKQgDALgSAUQgSATgSANQgdAUAiAlQAOAPAGAEQALAHAHgFQAHgFAVAMIAYAQQAHACAXAdQgmgdgPgGQgIgEgZADQgYABgGgDQgGgDgNgRQgKgOAAADIgFAzQgHA3gFAZQgJAvARBiQAFAbAJAgIAOAvQAGAXAPALQARAOAXgGIAagHQANgHAYgSQBJg3AQgZQAhg0gPhfQgUh8gLgzQgOhJgQgpQgMgygKgTQgPgdg6gbQgpgSggggQgNgIgMgNQgLgMAAgDQAAgEgIgSIgFgJIAAAAIgTgoQggAOgSACQgNACgJgFQgJgGAMgDQASgEAPAEIAOgOQAOgRgCgNIgFgnQgEgaACgKQACgLgIgSQgKgTgDgJQgHgWgdgDIgkgCQgGADgKACQgUAEgWgFQgVgFgQAFIgMAGIADgPQAFgPADABQAIADAXAFQAdAGALgBQALgCgFgNIgKgXQgEgJgagKQgWgJgUgEQgQgCgOgPQgPgQAOAIQAPAJAqAIIA2ARIARA0IBOARQAAgmgEgOQgCgKgBgfIgBgdIANhVQgDgegGgEIgdgRIhGgVIA9AHIgMgoQgzgigJgEQgGgDgRgBIgQAAIAogRQBLAugCAHQgCAGAIAYQAKAaAIAAQAOAAAaAXQATg0AAgPQAAgNgDgYQgEgagEgGQgGgIgFgRQgGgVAEgIQAEgJgFgSQgFgQgGgEIgVgQIgPgNIATAGQAUAGADADIAXAPQAQAQgMARQgMARAHAcQAEAOAGAKQAOA5AAgHQAAgCAPgJQASgLAHgJQALgRACgbIACgmIALgOQAMgOAHgBQAMgCAXgVIAJhHQAGBTgGADQgMAEgOAIQgWAOgBANQgCAVgKAcIAOgFQAQgEAIACQAKADANAIQANAIAEAGIAKAOQAEAHgEAAIgbgUQgXgTgJAGQgJAGgbAfIghAkQgHAHgcA2IgaA0IgJBWQgEAdAKBlIAiA0IgDAbIgHAoQgDAOAMAiQAMAhAIAHQAHAHA2BCQAWANAQAEIA/AVQAWABACgvIADhQIgFgQQgEgIgNgIQgNgIgMgDQgJgDgLgJIgKgJIAZAHQAcAJAMAHQAMAGgGgiIgKg4IgKhHQgWgZgOAAQgKAAgYgGQgYgGgKgFQgJgEgPgDIgOgCIALgLQANgLAEAGQAGAGARAHQAQAGAPACQATACAaAMQgZgwgPgVQgRgXgbgVQgIgHgKgSQgIgOgEgLQgCgHAIgxQgBASADAeIALAVQANAVAGAGQAKAIAaATIATg5QAEgMACg0QALBHgHACQgGABgEAWQgEAVACAOQADALAOAWQAUAeAFALQAKATAQgJQAMgHAIgQQAHgNAEgTQAGgWgEgJQgJgSADggIAHgkQAEgZgHgEQgFgDgJgUIgPgiQAHAKATATIAUAWQAGAHgEAZQgDAXgGAQQgFAMAEALQACAGADADIAtgTQAmAEgHACQgRAEgNAFQgZAJgGAJQgEAGgCAdQgBAZgIAHQgKAIgVAjIgTAhIADAqQAEAtAFAJQAFALAHAdQAHAeAAAOIgBAAQAEAYgFAYIgTBIQgFAfAMArQATBDAXBpQAGgRALgZQAUgwAUgkQgIgYgHgHQgIgJgCgUQgCgUAGgKIAPgdQAJgUABgHIALhBQAIA/gGAMQgcBBACALQACAMAPAeIgBAHQAagqAUgOIgRAnQAhAIAJAAQAFAAARgLIAUgMQAEgCATAHIATAHQgPAEgMgGQgHgEgQAIIgaAPQgKAFgUgCQgOgCgJgDIgBgDQgYA2gMAhQghBbAOBQQAGAiAAAvQAFAXAnglIBbhYQAwg5ARhRQAbhiAGgbQAIgmgagiQgagiglgtIgggmQhsg/gKgmQgEgQALALQAdAaANAJQAhAWAWAEQAZAFAAgXQAChNAIgkQAFgaABgkQAAgigEgcQgFgdgCgeQgCghADgQQACgPgNABQgUADgNAAQgQAAgXgqQgWglAAgLQAAgIgQgZQgRgbgIABQgJACgWgXIgVgXIBFAqQAPAJAVAjIALghQACgGgDgUQgEgVgGgBQgGgBANgPIAOgOIgEAiIALAbIgIAQQgJASgCAIQgBALACAMQADAOAIAJIAUAWQAPANAOgBQARgCAIgPQAIgNAAgVIgCgjQABgTAIgLQANgQgFg3IARghIgEBMQgCAXgEAMQgJAgAAAaQAAAPgEAkIgEA2IgBAXQgBASAGAJQAGAKADARIACAiQACATAJADQAKADAMgVIAagxIASghQAEgGgDgLQgEgLgLgHQgKgIgLgPQgJgOAAgHIgChUIAFAHQAEAIAAAMQAAAzAGAOQAEAKANAIQANAHAEgEQAHgEAPgQQATgTAHgNQAJgRABgPQABgQgJAAQgKAAgSgJQgTgIgDgGQgCgGgNgHIgNgGIAZAKQAsAUAHgDQACAAAKADQAJADAEgGQAFgJADgOQAEgQgDgLQgCgLADggIADgfQAAgsgEgMQANAdAAALIAAAlIAKAGQALADAEgNQAFgNAPgJQAIgFAGgCIgKANQgKAPgCAKQgCAHgPADQgOABAAAFIgDAzQgFA3gLASIgvBUIA1AMQAWAGAVgHQAYgIABgUQACgTAPgaQAOgWAGgCIA8gZIgeATQgfAWgHANQgHANgIAbIgKAfQgCAHADgBIAUgGQAOgCAMAOIAMAUQABACgQgHQgVgIgKACQgtALgVgJQgNgFgVgBQgXgBgIAHQgLALgOAUQgTAagHAXQgHAVgSAWIggAlQgOAQgPAuQgFA3AHAdQAVBTAkAiQAfAeAPAEIALghQAQgoAUgoIgYg1QgKgSgCgVQgnABgEgBQgEgBgLgMIgKgMIAMAGQAOAGAEgCQAIgCAbAAIAEABIADgQQAGgTgEgmIgGgnQAAgGAMAfQAMAfABANQABAJgEAZQgFAVACAGQAEAKAbA3QAVgmAbgZIgDAAIgDgXQgBgYAEgFQAGgGAMgTQALgTACgFQACgGgPg2IALAUQALAVAAALQAAAKgJAVIgMAXQgBAIgCAjQASgNAMgEQgQAOgTAXQgmAugOAqQg9CxgEBXQgDA1gYA7QgTAwgTAUQgQASADAHQAEAJAgAAQAXAAAiAKQAdACAcghQAdgiAogfQAUgPAOgIQgmAlgfAqQggAsgLALQgZAWgegFQhAgMgFAAQgpACgnArQghAkgpBAQgpBAgSAUQgzAzgdAeQg1A5gTAvQgVA0ANBXQALBKAbA7QAaA5AjAQQAoASAogxQAdgkBHg+QA5g5ADgyQACgrACgVQgkgcgKgLQgKgLgbgJQgbgJgIAGQgHAFgfALIgdAJIgsAuIAjg0IAcgRQgVgfgPAAQgKAAgTAHIgRAHIgagMIAOAAQARAAAHgEQALgHAsgIIAPAdIAQgBQASgCAIgDQAIgDASAEIAZAFQAMACAPgGQABgKgCgKQgEgUgOgEQgOgEgUgcIgRgbIADhRIAGBHQAAAEANAIIAMAHIARgiIAkAEIgXANIgVAbIALAMQALALADAAQAGAAAHAgIADAPQAEAQAHAIIAOATQAIALAFgEQAWh7BOhMQBjhhBnh1IAIgBIANgeIgRgvIAPgyIgmhGIAyA4IAPgOQAPgPAIgFQAKgGgIgZQgJgZgUgQQgYgTgOgIQgSgLgSgCQgQgBgTgSIgagcQgIgJgGgmIgEglIAPAbQAOAcACAHQACAJAJAOQALAOAIAEQANAGAuADIAchUIgNBcIAaARQAeAUANAOQAMgpgDgRQgCgOAJgUIAJgQIAABFQAAAQgPAnQADASgHAZQgIAdgQAPQgUARgMATQgNAUAEAIQAFALAFA1IAfgOQAfgPAHgBIAlgIQAegHAGgFQAJgHATgJQATgJgBAFQgDAJghAhQg1AJgUALQgMAHhYAjQhfBbg2A8Qg3A8ghA6QgqBKgDA/QgDBVAEAPQAJAbArgWQDLhoBKhfQAEgVgDggIgDgbQgUgcgHACQgFACgVgFQgTgGgLgFQgIgDgWgDIgVgCIAcgRIAzAXQAKAFAogFIADgtQghgkgNgLQgIgHgWgIIgUgFIA6AGIA4ApIAAAhQABAiABAJQADAOAVAjQAlg+AjgxQAigyAPgOQAQgOAKgyQAIgrAAgsIABg1QAAgdgGgbIgrh1Qgcg7gLgdQgGgOgGgVQgKgMgEgHQgIgPgMgRQgQgVgHAAIhCAAIguhDIgwgfQA9AIAAAMQAAAIAWAUQAWAVAPAEQAUAFAZgOIgKg9IAcBGIAZgaQAXg1gCghQgCgXgMgKQgHgGgRgGQgNgEgVgSQgTgQgIgMIgXglIgPgbIAZAVQAaAYAEANQAGAQARANQAQALAPACQARADAXAWIAOgSQAPgTAJgHQALgIgJgTQgIgSgRgLQgKgIgVgaQgWgcgKgIQgNgKgTgbIgYgkQgGgIAPgXQAIgMAJgKIgLA1IARAZQAUAaAOAIQAXAOANAWIAChTQAAgOAHguIAGgsIAFBcIgFBoIA/BWIgwA4IgIAdQgJAfACAKQACANgFASQgGATgJAJQgJAIgEATQgDATAEAMQAEAPADAjQAgBSAOAWIAXAcQAMAOACgZQABgiACgOIAIgsQAEgYgCgHQgBgHgVggIgVgfIA7A1QAMgcgFgRQgDgKgCgvIgCguIAehAIAXiPIgDCXQgMAOgLASQgXAkAIAYQALAfAAAtQAAAugNAMQgMAMgKArQgJAmgCAkQgCAaAOAhQAGAQAHALIAzhhIBEhzIgehIIArA9QA4gyAAgLQAAgMgIgjQgJgpgIgNQgKgPgPgdQgPgdgGgQQgFgOAHgnQAPhVgJA+QgCAKAHAcIAHAgQAAAFAVAhIAUAgQAogtAIgTQAIgUgFhcQARBwgCAIQgDAIgwBBIAPAuQAMAygOAVIhUB4IBggRIASgSQAUgSALgGQALgFAlgfQAhgcAHgIQAGgHAPgjQAPgkACgOQACgMAhgZIAigWIgzBGIgHAVQgIAZgIASIAhAAQALAAAVALQAQAKAGgEQAFgFAdABQApACAQgBQAZgCAhAaQARANALANIg1gfQgUgEgWgCQgsgEgNAKQgSAQhpgcQgGAMgFADQgLAHg6AuIg4AtIA9gIQASgFARAAQAagBAKALQANAPAbALQAfANAPgIQAPgHAzALQAaAGAXAHQgYgCgZABQgzABgKAIQgKAKglgSQgbgNgegVQgRgMg8AMIg5AOIiAANQhCB5gLApQgLAlgKA/QgKA4AAAPQAAARAGABQAMACArgcQAhgVAogNQAhgQAjg7QAjg8AxgtQAYgXARgKQgQANgSAUQgkAogKAgQgFASgQAbQAfgCAWAEQAQADAhAKQAcAJAJAAQAQAAAegKQAjgMAagTQAYgSAxARQAYAIAUAMIhPgGQgZAFgbAHQg2AOgNAOQgMAMhMgIQgqgFgzgKQgtA/grAaQg1AZgdASQgzAhgfA6Qg0BhgrBCQgPAXANAJQAOAKA1AAQAVAAB2AWQBeASAhgPQAugUBegwQgJg1gPgZQgLgSgTgQIgQgOQAKgtADgnQABgYgJgWIgKgSIAjAOQAFBUgHAOQgFAJAPAfQAPAcAKAHQAFADAJANQAdghAAgQQAAgPAagdQAZgdAcgTQgKAJgLANQgVAagEAVQgFAigmBAIAQAXIAFgCQALgFBCg5QA1gvAdAAIAPAAIAkgYQAphOAFgRQADgKApgFIA3gHQAKgDAXgkQARgZgCAFIgXBDIhgAaIg1BvIBgAJIigAQQgZAEg7AoQg4AogbAeQgiAkhzAvQgYAKAXASQAYASA5AJQASADAVABQAygXAcgPQAUgKAVghIAWgmQAIgIgUBIIgxAoIgkASIBaADIBUACQAlggASgWQALgOAhgOQAQgHAOgEIBMhtIg4B7IhHAcIgnA6QAfAJA6AZQAxASAagNIBbgqIAhhqIBOhLIg/BUIgXBUIgWAMQBHggADAIQACAGgcAQQgYAPgkARIAaAbIBMAMIBFAkIhZgXIhHgCIgfgpQgmARgUAEQgvAKhtgeIAdA4IBcAUICJBnIhcgkIg/gvIhlgaIgohPQgagEg8gCIhmgDQAOA8ANARQAPAUAIA6QgmhLgSgWQgPgTgJgpQgpgDgWgHIiDgrQhbgdgpgIQhIgOg3ADQhZAFhJAsQhFAqhRA0IhDAsIBZgHQBdgDAYATQAtAiA5AaQBQAkAqgRQAVgIAzgEIA1g0IgFgBQgIgZgHgMQgFgJgDgRQgBgQABgLQACgIgKgQIgJgQIAPAQQAPASgBAKQgCAOACAPQACAQAFAIQAIAKAIARIAPgPIBKgtIAKgqIAHAwIhHAyIgtA8QBvgFCMADIhsAGQh6AHhCAIIAbApIA/AqIhYglIgsgoIgYAHQgZALgqgDQgogCgogPIAyA7IBMA4IAcAqIh6hUIhshsQgvgPhBADQhGAEhCAXQhPAahFBhQhABYgYBjQgWBXgOBkQgNBeADAlQAFA4ANAVQAaAmBCgbQBBgbA9hHQAhgmAvhBIABgBQACgTgDgLQgPhWgIglQgPgngKgTIgMgcQgHgOgJgCIgbgCQgQgCgJgEIgtgXIAUgBQAWACALALQALAMASgDIAWgEQAGABgDgQQgEgZAAgGQAAgNgKghIgJgeIAQAbQAPAdgBARQgBAWAEASQAFAUAJAHQAMAKAQApQAHgOAPgZQATgeAGgMQAQgeAHgyIAFgrIAFAtQACAygRAcQg8BeAGAlQAFAfASBZIAAAFIBEhcQArg5AdgWQAhgaAmhBQATggAMgcIgOA5QgRA8gOANIAmgIQApgJAQAAQBCAAASgWQAJgMAlgOQASgGARgEIgkAVQglAYgIAKQgJAMggAHQgbAHgVAAQgUAAhtAiQhbBlgaArQgTAggVAbIgRAVIAsggQAxggAVgDQAVgDA6gkQAegTAYgSIhIBIIhFAkQAJAVABAGQABAJAGAIQAHAJAHADQAJAEAoAIIAZAkIgbgXQg3gRgPgGQgNgFgKgtIguAXQgQAHgbAXQgfAZgNAUQggAmgNAUQgZAkAcACQAnAEBcgRQBlgTA1gaQArgVBbiIQBeiMAUgNQAfgWAwgbQA5ghAsgTIAOhgIBJgyIAVgqIgDAvIg9AzIgMBNQASgGANgCQAugDDRhHIAkgaIAwgcIAmhAIA4gDIguARIgPAmQgSAngNAEQgOAEgtAVQBeA5BLAXIgIgFIAwhDIBygTIhgAnIgpA5QAwAMAggEQgSAEgegBQg8gCg+gVIAWBvIgph1IACAAQgfgMgdgQQgLgJgUgDQgogGgvAaQguAahNAYQhNAWgVAIQgaAKglAZIggAXIA+AkQBDAoAXAVQCUCCBggiQBEgYB0gdQBwgbAngEIAOABQA4ghALgFQARgJAUgSQATgTACgKQAIguARgeQASgeAKgnIAFAyIgRAgQgSAkAAAQQAAAJgIAQIBCAOIAugZIgfAvIhfgNQgQAWgNAIIhEAnQAWALAtAjQApAfAQAHQAqAQBUAaQgTAAgbgCQg1gEgkgMIAEAuIAXBDIAmApIAcBDIguhAQgMgKgNgOQgZgbgDgQIgWhnQgNgHgHgIQghglg2gMQgzgLg4ANQgtALhbAbIhRAZIAcAaQAiAcAbAQQBAgGAVgJQAtgUA2ALQAZAGAdgLQAPgFAJgGQgGAIgKAJQgTAQgPAAIgwgEQgegCgLAJQgLAJgnAHIgkAGQAcAIBKAtQAlAXAgAVQirhIgjgQIhAgqQgtgegUAAQgbAAhvgoQgBASgHAPQgWAwgDA1QgCAYAUAvIAeBFQANAkgDAcQgphtgUgkQgQgdACgrIgEgBQgKgEgKAEIgWAKIgbAPIgDAUQgEAWgGAPQgGAOACAIIAEALQACAIAGANQgMgXgLgGQgKgGAKghIALggQgggJgIAEIgWAHQgSAFgHALQgIAMgaAHIgqAJQgPACgSATIgPASIAEgTQAFgVAIgEQAFgCAfgHQAcgHAHgEIASgPQAIgJgJAAQgIAAgXgKQgXgKgFAAIg2ACIA2gTIAdANQAfANAGABQAIACAbgGQAcgHAEgGQAEgGASgFQASgFAPAAQAUAAAygTIABgHQAEgSAEgnQAEgngDgCQhXg7hkg/QghgUgXgFQgngHgWAgIhMB9Qg3BbgSAPQgbAWAAAcQAAAjAuAcQAaAQBKBGQA6A4AgAFICQAfQBwAZApgCQBJgFAXgEQAxgKAegbQAhgeBkgUQBggSA5AJQBIANBMARIjCgNIAzA9QA2A9ATAKQAfARBWAZQgXgEgbgGQg3gMgWgOQgcgSgbgXQgdgbgUgcQgRgXgWgSQgsAGhEAYQg6AUgdAQQgcAPAFASQAFAOAhAaQAJAHAUAVQAzADAvAAQAeAAA4gFQgMAFgPAFQggAKgWgEQgdgEgwAVQAhAoA4BJQAjAqAPAmQhUhUgqg7QghgvgxgpQg1gsgkgGQgYgEhXAIQhYAJgdgFQgggEgxgQQgwgSgMgBQgSgDAYA2IAsBhIAIAaQBUBVAPAWQARAXAvAgQAxAiAWAAQATAAAhAhQAQAQANAQQhMg1gcgGQgQgDghgXQADAYAAAWQAAAbACAPQACAYAGAUIAcBOQgthGgLghQgJgfAChaIghgYIhFhDIgcgdQAPBEAIBWQAHBMAHAnQAKA9ASAqQARAoAOBEQAHAiAEAaIhMjFIgDgKQgOAHgLABQgNACgdAPIgaAOQgkBMgCgJQgCgHAOgmQAQgoAMgKQAOgLBGgbQgciAAAg5QAAgpgWhJQgVhHgbg3Qg9AogYAVQgPAOgEAgIgGApQgFAKgbAIIgbAHIAUgPQAUgSgBgMQgCgOAJgZQAJgYAOgSQASgWBMgkQgagwgngnQgXgYhAg3QhBg3gVgQQgmgcgdgGQhYAGhuAgQjdBBhtCGQh8CahXCLQgOAlAFAJQAFAJAXgHQAYgIAqALQAgAJAiAQQAVAJBjASICBAXQAgAIAXggQAWgdAEgqQAAgIAHgMQgmhUgSgMIg0gLQgMgCgWgNQgZgOgEgLQgDgKgYAEQgZAFgDgBQgEgBgQAUIgQAVQANgoAGgIQAEgGAQgEQANgDAHAAIAkAEIAIghIgUgmIAQgyIgCAUQgBAWABAGQABAFAIAQQAJAPABAEQACAKgGAVQgDAJAPAMQANALANAEQALADAlABQADgWAIgXQAIgYAHgEQAQgIAehcIAFhdQAIBagDALQgCALgNAlIAogDIAYgKQAXgNACgTQABgTAWgYQAMgNAKgJIBHgkQgtAngQALQgJAHgPAaIgVAoQgHAOgUANQgTAMgNAAQgLAAgRAMQgRALgIALQgJANgEATQgGAYAJALQAMAQANAWQAPAagCAGQgBAFARAVQAhgUA/gRIBHgVIAMhNIAaghQAdggATgCQATgCAlgXQASgLAPgMIARgzQgHBKgPAIIgwAUQgmAQgLAGQgLAHgKATIgOAeQgFALAQALQANAJAJAAQAGAAATgGQAVgFAPgGQAUgJAZgIQg6AqgPAGQgRAGgmAgIgBABIACAbQACAbgCAHQgBAHAXAFIAlAIQASAFA1AJQhFAIgKAAQgGAAgegPIgegQQgcAXgKAFQgGAEgFAXIgEAXIgKgsIA1g+IgOgRQgVAMgQAAQgfAAg4AWIgyAWIgJA8QgHA8AQADIBSAPQBDAOATAWQAYAbAvAeQAxAgAWAAQAeAABhgWIh5BIIABA1QAAALAhALQASAGAXAGQAKACAcARIhEgOIhHgIIgKhnQhkg8gWghQgVgdhkgFQhTgFg8AMQgjAGhNgZQhTgagNAAQgbAAAkAqQAeAjAlAdQANALAqAQQAyATAVALIgCgBQBAgXAHgFIAmgXQAggUABgHQACgIAeAUQAaASAQAOQAPAOA6AlIghA9IgCgvIgzg2QgwgWgSAGQgIACgjAXQgfAVgEgCQgGgBgCAmQAuA6A6BwQgigsgqgvIgFAjIAHAwQgIgKgIgMQgQgZACgMQABgKALggQhKhQgggGQgngIhKg3QgiArgIAIQgEAFABAnIADAxQAAAOgWAyQAHgygCgRQgCgMABg0QggA0gOAIQgKAFgGAoQgDAbAAAYQAAARhFBkQAmhHAEgZQAIhQADgZQADgPARgWQAYgdACgFQAHgNAPgPIAOgNIApgzQhAgxgrgwQgpgthVAfQhPAdg5BFQiFEsAHEfQAIFqASFsQASFeATDbQAPClAlD6IAiDeQAAAHg8AFQhqAIgdAEQhOAJhVgDIg3ADIgGAAQghAAgmgFgEgFlghEIABAAIgFAJQgJATAAADQAAADgKAMQgMANgNAIQgiAggnASQg6AbgPAdQgKATgMAyQgQApgPBJQgKAzgUB8QgPBfAhA0QAQAZBIA3QA8AsAjAGQAoAHAOgtQAPgxARixQgKhNgDgPIgOgwQgLgjAAgDQAAgDgKAOQgMARgGADQgGADgYgBQgZgDgIAEQgKAEgWAQIgVAPIAMgPQANgPAFgBQAEgBAUgPQAUgMAHAFQAIAFALgHQAGgFANgOQAjglgdgUQgTgNgRgTQgSgUgDgLQgDgKAGgPQAFgOAHgFQAKgGgEgsIANALQAMAOgGANIgRAiQgIATAIAKIAiAdQAiAigCAXQgBAVANAcIAPAiIAMAlQAIgXAJgMQAhhJAhg0QASgogOgPQgKgLgUggQgSgegBgGQgBgCAJAMQANARAJAGQALAIAMAMQAMALABAFQABADAJgUQAMgbAFgJQAIgMgEglQgDgggHgVQgFgQAEgfQADgdAEgGQAEgGgohQQAxBOAAAKQAAAGgHAaQgFAaAEALQAFAMADAkIAEAqQABAIASgFQAJgDAIgEQgdAXgHAEQgEACgKAbQgNAfgHAMQATgaAOgEQARgEALgMQA9hFgIgYQgSgxgFhEQgCgfAKgoIALgiIgCAwQAAA4AKAnQAMAyALALQAOAMAQgjQAQgjAAgyQABgrgKgkQgGgXgRgSQgPgPAAgHQAAgIgEghIgHg/QgDgjABgoIgHAHQgOAPgPACQgVAEgWAJQgaAKgDAJIgLAXQgEANALACQALABAcgGQAZgFAGgDQAGgCAGAfQgEgDgIgDQgQgFgWAFQgVAFgUgEIgQgFQgTAAgRACQgcADgIAWQgDAJgKATQgJATADAKQACAKgEAaIgGAnQgBANAOARQAHAIAHAGIAKgCQAMgBAKADQANADgJAGQgKAFgNgCQgKgBgVgIIgSgHgAzyOdIAGgFIgHAJIABgEgAG+pCQAOgGAEAFQACAEgFAAIgPgDgAdT8BIA4hAIgTAhQgTAigDAJQgFAOgFAZIgXALgA9Y7OQgFgZgFgOQgDgJgTgiIgSghIA4BAIARA+g");
	this.shape_7.setTransform(46.1,-4.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#24201A").s().p("EgCEAwlQhXgKgagEQgngGAAgIQANhtAOiHQAdkPAFimIAfn5QAWlygNlcQgNhthChyQheijiUglQhcgYgYgFQhMgOgtAMIiDAlQAMBngdAWQgVAPgaBBQgNAhgIAdIA5AiIhQgeIAahYQADgKgJgFQgKgGgKAJQgQAMgtA3IAmhQIAmgVIAbAAIAtgyIgVhLIiSArIg1AAQgDAEgKArQgJAngGACQgIACgQAmIgOAmIAZBAIgrhAQAPgqAIgRQAEgKgPgIIgRgHIgXAHQgaAIgJAIIARgaIAQgGQASgHAEAAQAIAAAoAIQAQgtgDgRQgBgEADgIIhlAAIAggMQAkgMAbgEQhsgtgRAAQgOAAgnAOQgnAOgPAKQg9AqAAAMIgDBMIhYAdQA5ghAEgRQACgLgBgdIgBgbIhMAhIh2gEIg5A3IAqhYIA4APQA7AOAOgIICUhUQAbgPAxgSQA7gVAKAIQgCgLgIgLQgQgXgfgFQgfgGgcgbIgVgaIA7AQQA9AQAJAGQAMAGAtBWQAyATBEAXIACgBQADABAEAEQAXgHBCgZQA5gWAWgFQA2gMBWgfQAfgJAPgTQAegkhRgvQgqgYg+gbQhHgfg/gVQhNBXAAAPQAAALg0gJIgzgKIhYAAIAmgOQAogNAKAGQAPAIBFAAIAthHQAGgLAMgJQhggcgrANQg1APhUgoIhCA/QgOALgmgEQgqgFgDABQgNAFgmgTIAagCQAegCAPAEQAgAHAMAAQAZABAKgRQALgRAigkQgYgMgXgPIgSgMICRAfQAQADAfACIgCgsQAAgJgTgSQgTgRAAgGQAAgIAJgnIAKglIADAoQAFArAPANQATASAEBBIBrADQA+AEAdALIBDAcIAFgpQAAg2gPgaQgKgPgRgNIgPgJIhfAEIAygOQAwgRgPgPQg7hAgNgUQgHgKgkgQIgwgUQgMgFgNgbQgNghgIgPIguheIAfAhQAgAhACAQQADAXARAUQAUAYAdAAQAaAAAUANQAKAGAEAGQAEg7AAgVQAAgNgPgvIgPguIAbA+QAbBBgFAVQgMA4AfAcQAXAVATAdQAIgZAEgZQACgTATgaQATgaAUgNQARgKAcgGQANgEALgBIgoAZQgpAcgHAKQgNATgLAbQgQAlACAWQADAVAjA0QASAaARAWIgDAqIAGgVQAVgHAXgLQAugXAJgVQAphZAnAJQAiAIBNAuQhcgMgTgEQgMgDgUAWIgdAjQgKAMAUAQQASAPAaAHQAeAJA1gEQg9AUgWAAQgLAAgigZQgfgXgIAHIghAdQgZAVgOAAQgNAAgKAMIgDAyQBzAwAgAMQAVAHBKAQQA0AKAfAWQAbATA+APQBBAPAdASQBGArAXgDQhckFglhWQg/iRhPhiQhtiGkYhiQhXgfhegYIhNgRQgcAGgmAcQgUAPhCA4QhBA4gWAXQgoAngZAwIAoAVQArAXALAOQANARAKAZQAJAZgCAOQgBAMATASQAKAJAKAGQgMgCgOgFQgcgIgEgKIgGgpQgFgggPgOQgQgPhEguQgbA4gVBGQgWBJAAApQAAA5gdCAQBFAaAQAMQAMAKAQAoQAOAmgCAHQgCAJgkhMQgwgcgUgDQgMgBgNgHIgDAKIhMDFQAEgaAHgiQAOhEAQgoQASgqALg9QAGgmAHhNQAJhWAPhEIgdAdQgHAIg9A7IghAYQACBagKAfQgKAhguBGQASgvAKgfQAHgUACgYIABgqQAAgTAEgbQgjAXgOADQgSAEgtAcIgpAbQAMgQARgQQAhghATAAQAVAAAygiQAvggAQgXQAPgUBVhXIAIgaIAshhQAYg2gSADQgMABgxASQgxAQgfAEQgdAFhYgJQhXgIgYAEQgkAGg1AsQgxApgiAvQgqA7hTBUQAPgmAigqIAogzQAfgpASgVQgugWgeAFQgWAEgggKIgbgKIAgADQAjACATAAQAvAAAzgDQASgTALgJQAhgaAFgOQAFgSgcgPQgdgQg6gUQhEgYgsgGQgWARgRAYQgrA7g9AlQgkAWhbAOQBWgZAegRQAfgRBehzIjCANIAvgKIBlgUQA4gJBhASQBjAUAhAeQAfAcAwAJQAXAFBJAEQApACBwgZICQgfQAggFA7g4QBJhGAagQQAvgcAAgjQAAgcgbgWQgSgPg3hbIhMh9QgWgggoAHQgXAFghAUQiGBWg0AkQgDACAEAnQAEAmAEATIABAHQAKAEAVAGQAbAJAMAAQAPAAARAFQATAFAEAGQAEAGAcAHQAaAGAIgCQAKgCA5gZIA1ATIg1gCQgFAAgXAKQgXAKgIAAQgKAAAJAJQAEAEAOALQAHAEAcAHQAeAHAGACQANAHAEAlQgGgJgKgJQgSgTgOgCQgbgFgPgEQgbgHgHgMQgHgLgSgFQgTgEgEgDQgEgCgTADIgRAEIAMAgQAJAhgJAGQgMAGgNAZQAJgSABgFIAEgLQACgIgGgOQgGgPgFgWIgDgUQgJgGgRgJIgWgKQgKgEgKAEIgEABQABAsgQAcQgUAkgoBtQgDgcANgkIAdhFQAUgvgBgYQgEg0gVgxQgHgOgBgTQhwAogaAAQgVAAgsAeIhBAqQgiAQirBIQAfgVAlgXQBLgtAcgIQhEgIgSgOQgLgJgfACQgiAEgNAAQgQAAgTgQIgQgRIAYALQAdALAagGQA2gLAtAUQAVAJBAAGQAagQAigcIAdgaQiRguhIgRQg5gNgyALQg2AMghAlQgHAIgNAHIgWBnQgDAQgaAbQgMAOgMAKIguBAIAchDIAmgpIAXhDIAEguQgkAMg1AEIguACIAvgPQA1gRAagKQAPgHAqgfQAtgjAVgLQgzgdgRgKQgMgIgRgWIhfANIgegvIAtAZIBCgOQgHgQAAgJQAAgQgSgkIgSggIAFgyIAIAXQAJAbALATQASAfAIAtQACAKATATQATASASAJIBDAmIAOgBQAnAEBvAbQB0AdBFAYQA9AWBSgtQAtgYA3gxQAYgVBDgoIA+gkQg2gpgqgRIhhgeQhOgZgtgZQgwgagoAGIgeAMQgaAOgiAOIACAAIgpB1IAWhvQg+AVg8ACIgdgCQAaAAAigJIgog5IhhgnIBzATIAwBDIgJAFQBOgYBbg4QgpgUgSgFQgNgEgRgnIgPgmIgugRIA4ADIAmBAIAwAcIAkAaQDRBHAtADQANACASAGIgMhNIg8gzIgDgvIAUAqIBKAyIAOBgQArATA6AhQAwAbAfAWQATANBfCMQBbCIAqAVQA1AaBlATQBdARAngEQAcgCgZgkQgkgrgJgPQgNgUgfgZQgbgXgRgHIgtgXQgLAtgMAFQgPAGg4ARIgaAXIAYgkQAogIAKgEQAHgDAGgJQAGgIACgJQABgIAJgTIhFgkIhIhIIA2AlQA6AkAVADQAVADAxAgQAYAQAUAQQgbgdgegzQgbgthahjQhtgigUAAQgWAAgagHQgggHgJgMQgIgKglgYIgkgVIAjAKQAlAOAJAMQASAWBCAAQAZAABGARQgPgNgRg8IgOg5IAgA8QAmBBAhAaQAcAWAsA5IBEBcIgBgFQAShZAFgfQAGglg7heQgRgcABgyIAGgtIAEArQAIAyAQAeIAZAqQAPAZAHAOQADgKAHgOQAKgVAIgGQAJgHAFgUQAEgSgBgWQgBgRAPgdIAQgbIgJAeQgKAhAAANQAAAHgEAYQgDAQAFgBQAFgBASAFQASADALgMQAKgLAXgCQALgBAJACIguAXQgIAEgRACIgaACQgKACgHAOIgMAcQgJATgPAnQgIAlgPBWQgDANACARIABABQAVAZA7BOQA9BHBAAbQBDAbAZgmQAOgUAFg5QADglgNheQgOhkgWhXQgZhjg/hYQhGhhhOgaQhDgXhFgEQhBgDgwAPIhrBsIh6BUIAcgqIBMg4IAxg7QgnAPgoACQgqADgagLIgXgHIgsAoIhZAlIBAgqIAbgpQhDgIh5gHIhsgGIBTgBQBiAABFADIgtg8IhHgyIAIgwIAKAqIBJAtIAPAPQAKgSAHgJQAFgIACgQQACgPgCgOQgBgKAPgSIAPgQIgJAQQgJAQABAIQABALgCAQQgCARgFAJQgIAMgHAZIgFABIA0A0QA0AEAVAIQAqARBQgkQA4gZAugjQAYgTBdADQAvACAqAFQhrhHhuhDQhJgshZgFQg4gDhIAOQgoAIhbAdIiDArQgXAHgpADQgJApgPATQgRAWgmBLQAHg6APgUQAPgSANg7IhmADQg8ACgaAEIgoBPIhlAaIhAAvIhbAkICJhnIBbgUIAeg4QhuAegvgKQgUgEglgRIgfApIhHACIhZAXIBEgkIBMgMIAbgbQgkgRgZgPQgbgQACgGQACgIBIAgIgWgMIgXhUIhAhUIBPBLIAhBqIBaAqQAbANAxgSIBYgiIgmg6IhHgcIg4h7IBMBtIAeALQAhAOALAOQAOASAoAkIBUgCIBbgDIglgSIgwgoIgJgjQgIgiAEAFQAEAFATAhQAVAhAUAKIBOAmQAUgBATgDQA5gJAYgSQAWgSgYgKQgwgUgYgMQg2gbgWgYQgbgeg5goQg7gpgYgDIiggQIBggJIg1hvIhggaIgXhDQgCgFAQAZQAYAkAKADIA2AHQAqAFADAKQAFARApBOIAkAYIAOAAQAdAAA2AvQBCA5ALAFIAFACIAPgXQgmhAgFgiQgDgVgVgaIgVgWQAcATAZAdQAZAdAAAPQAAAQAdAhQALgNADgDQALgHAPgcQAPgfgFgJQgFgJABgtIABgsIAkgOIgKASQgJAWABAYQADAnAKAtIgQAOQgTAQgLASQgPAYgJA2QBVAsA2AYQAiAPBegSQB2gWAVAAQA0AAAPgKQANgJgPgXQgpg9g3hmQgfg6gyghQg5gcgZgPQgsgagsg/QgzAKgrAFQhLAIgMgMQgNgOg2gOIg0gMIhPAGIAsgUQAxgRAYASQAaASAjANQAdAKAQAAQAKAAAcgJQAhgKAQgDQAWgEAfACQgQgagGgTQgJgggkgoIgjghIAqAhQAwAtAkA8QAiA7AhAQIAgANQAWAJAUAMQArAcALgCQAHgBAAgRQAAgOgKg5QgKg/gLglQgKgnhDh7IiAgNQgbgIgegGQg8gMgSAMQgdAVgcANQglASgKgKQgJgIgzgBIgxABIAxgNQAzgLAOAHQAQAIAegNQAbgLAOgPQAJgLAbABQAQAAATAFIA8AIQhqhXgSgLQgFgDgHgMQghAJgdAFQgxAIgLgKQgNgKgsAEIgqAGIg2AfQAMgNAQgNQAhgaAaACQAPABAqgCQAcgBAGAFQAFAEARgKQAUgLALAAIAiAAQgIgSgJgZIgHgVIgyhGIAhAWQAiAZABAMQACAOAPAkQAPAjAGAHQAIAIAhAcQAkAfAMAFQASAJAeAhIBhARIhUh4QgOgVAMgyIAPguIgZghQgZgjgBgFQgCgFAJg6IAIg5IgBAwQgBA0AFAMQAHATApAtQAog+AAgIIAIggQAHgcgCgKQAPA1gHAXQgFAPgQAeQgOAbgLARQgIANgJApQgIAjAAAMQAAALA3AyIAsg9IgfBIIBFBzIAyBhQAHgLAHgQQANghgBgaQgCglgJglQgKgrgMgMQgNgMAAguQAAgtAKgfQAIgYgWgkIgYggIgCiXIAWCPIAfBAQgDBXgFAQQgFARANAcIA6g1IgUAfQgVAggCAHQgCAIAMBDQADAOAAAiQADAZAMgOIAWgcQAPgWAfhSQAFgmADgMQAEgNgDgSQgEgTgKgIQgJgJgFgTQgFgSACgNQABgKgIgfIgJgdIgwg4IBAhWIgFhoIAFhcIAGAsQAGAuAAAOIADBTIAJgMQAMgPAOgJQAXgOAcgtIgKg1IARAWQAPAXgHAIIgYAkQgTAbgMAKQgKAIgWAcQgVAagLAIQgQALgJASQgIATAKAIQAQALAWAhIAOgLQAQgMALgCQAPgCAPgLQASgNAFgQQAFgNAagYQANgMAMgJQgcAygKAOQgJAMgTAQQgVASgMAEQgSAGgHAGQgLAKgCAXQgBAVAKAjQAGARAFANIAaAaIAchGIgLA9IAQAHQARAFANgDQAPgEAWgVQAVgUAAgIQAAgHAfgHIAegGIgwAfIgtBDIhCAAQgHAAgQAVQgLAPgKARQgEAHgKAMQgFAUgGAPIgnBYIgrB1QgGAaAAAeIABA1QAAAsAIArQAKAyAQAOQAOANAjAzQAhAwAnA/QAVgmACgLQACgJAAgiIABghIA4gpIA6gGIgUAFQgXAIgIAHQgMALghAkIACAtQApAFAKgFIAzgXIAcARIgVACQgWADgIADQgLAFgTAGQgVAFgFgCQgFgBgMANIgLAOIgDAbQgCAgAEAVQBKBfDKBoQAsAWAJgbQAEgPgDhVQgDg/grhKQghg6g3g8Qg2g8hfhbQhVgjgOgHQgNgHgfgHIgegGQghghgCgJQgCgFAUAJQATAJAIAHQALAIA/AMQAKACA7AcQAFg1AFgLQADgIgMgUQgMgTgUgRQgRgPgIgdQgHgZAEgSQgPgqAAgNIAAhFIAJAQQAIAUgCAOQgDATANAnQAVgWAwgdIgNhcIAcBUIAZgCQAZgDAIgEQAJgEAKgOQAKgOACgJQABgHAPgcIAOgbQgFBGgNAOIgZAcQgTASgQABQgSACgSALQgPAIgXATQgUAQgJAZQgJAZAKAGQANAIAZAaIAzg4IgmBGIAPAyIgSAvIANAeIAJABIBABHQBMBSA+A9QBNBLAWB8QAFAEAJgLIAOgTQALgMACgbIAFgQQAFgQAEAAQAFAAATgXIgVgbIgWgNIAkgEIARAiQAZgNAAgGIAFhHIAEBRQgHANgKAOQgUAcgOAEQgPAEgDAUQgCAKABAKIAJADQAKADAHgCIAZgFQASgEAJADQANAEAdACIAPgdIAXAFQAZAGAHAEQALAGAbgCIgbAMQgegOgPAAQgKAAgOAQIgMAPIAcARIAiA0IgrguQg4gRgLgIQgIgGgbAJQgbAJgKALQgIAIgRAOIgVARIAEBAQACAyA6A5IAzAwQAgAdARAVQAnAxApgSQAjgQAZg5QAbg7ALhKQAOhXgVg0QgTgvg1g5Qg7g6gVgXQgTgUgphAQgphAgggkQgogrgogCQgGAAg/AMQgeAFgZgWQgMgLgggsQgTgagagdIgXgYIAiAXQAoAfAcAiQAdAhAdgCQARgCAogIQAgAAADgJQADgHgQgSQgSgUgUgwQgYg6gCg2QgEhUg9i0QgOgqgmguIgjglIAIADQALAGALAIIgEgrIgLgXQgKgVAAgKQAAgLAMgVIALgUIgHAcQgHAdABADQABAFAMATQAMASAFAHQAIAIgIAsIgCAAQAbAZAVAmQAbg3ADgKQACgGgEgVQgEgZABgJQABgNAMgfQALgfAAAGIgFAnQgEAmAGATIADAQIAEgBIAOAAQAQABAEABQAIACAXgMQgTAXgGACQgEABgogBQgBAVgKASIgZA1QAhBAAPAxIALgGQAPgJATgTQAmgjAThSQAHgagEg6QgPgvgOgPIggglQgSgWgHgVQgIgXgSgaQgPgUgLgLQgHgHgXABQgVABgNAFQgKAFgXgCQgSgBgQgEQgJgCgVAIQgRAHABgCQAKgRADgDQAMgOAOACIATAGQAEABgDgHIgJgfQgIgbgHgNQgHgNgggWIgegTIA9AZQAGACAOAWQAPAaABATQACAUAYAIQAVAHAWgGIA1gMIgwhUQgKgSgGg3IgDgzQAAgFgNgBQgPgDgCgHQgCgKgLgPIgKgNIAOAHQAQAJAEANQAFANALgDQAFgBAEgFIAAglQAAgHAIgWQALgegGATQgDAMAAAsIADAfQADAggDALQgCALAEAQQADAOAFAJQADAGAJgDQALgDACAAQAHADAsgUIAXgJIgLAFQgNAHgDAGQgDAGgSAIQgSAJgKAAQgKAAABAQQACAPAJARQAHANATATQAOAPAHAFQAFAEAMgHQAOgIAEgKQAFgOAAgzQAAgMAFgIQACgFADgCIgCBUQAAAHgKAOQgKAPgLAIQgKAHgEALQgDALAEAGIASAhQAQAhAKAQQAMAVAKgDQAJgDABgTIADgiQADgRAGgKQAGgJgBgSIgCgXIgDg2QgEgkAAgPQAAgagKggQgDgMgCgXIgEhMIARAhIgBAeQAAAfAIAKQAJALAAATQABALgCAYQAAAVAIANQAIAPAQACQAPABAOgNIAVgWQAIgJADgOQACgMgCgLQgBgIgJgSIgJgQIAMgbIgEgiQAeAcgJACQgHABgDAVQgEAUACAGIAMAhIAMgTQAOgTAKgGQAPgIA1giQgmAvgNgDQgJgBgRAbQgQAZAAAIQAAALgVAlQgYAqgQAAIgggDQgOgBADAPQACAQgCAhQgCAfgEAcQgEAcAAAiQAAAkAGAaQAHAkACBNQAAAXAagFQAVgEAhgWQANgJAdgaQAMgLgEAQQgKAlhsBAQg2A/gpA2QgaAiAIAmQAFAbAcBiQARBRAwA5IBbBYQAmAlAFgXQABgvAFgiQAOhQghhbQgMghgYg2IAAADQgKADgNACQgUACgKgFIgagPQgQgIgIAEQgHAEgKAAIgJgCIATgHQATgHAEACIAUAMQARALAEAAQAIAAAjgIIgSgnQAVAOAaAqIgBgHQAPgeACgMQABgIgLgeQgIgVgJgRQgDgIACgiIADghIAMBBQABAHAJAUQAIATAGAKQAGAKgBAUQgCAUgIAJQgIAIgIAXQAhA5AZBFQAWhpAThDQANgrgGgfIgShIQgGgYAEgYQAAgPAHgdQAGgdAGgLQAIgPADhRQgig/gPgNQgIgHgCgZQgBgdgEgGQgGgJgZgJIgegJQgFgBARgDIASgCIAuATQADgDACgGQADgLgEgMQgHgQgDgXQgDgZAFgHIAVgWQASgTAHgKQgVA1gIAEQgHAEAEAZIAHAkQAEAegKAUQgDAJAFAWQAFATAHANQAIAQAMAHQAPAJAKgTQAGgLAUgeQAOgWACgLQADgNgEgWQgFgWgFgBQgFgBAEgkIAFgkIABAbQACAdACAIIATA5IAlgbQAJgJAVgnQADgegCgSQAJAygCAGQgOAlgRANQgbAVgRAXQgJANgQAeIgPAaIAQgGQASgHAMgBQAPgCAQgGQARgHAFgGQAFgGAMALIAMALQgZADgNAGQgKAFgYAGQgZAGgKAAQgIAAgPAMIgNANIgJBHIgLA4QgFAiAMgGQATgLAugMQgQAQgPAFQgMADgMAIQgNAIgFAIIgFAQIADBQQADAvAVgBQAOgBAygUQAPgEAXgNQA2hCAHgHQAIgHALghQAMgigDgOIgJhDIAig0QAKhlgEgdIgKhWQgxhmgMgLIgggkQgbgfgJgGQgJgGgXATQgaAUgBAAQgFAAAFgHIAJgOQAFgGANgIQAMgIAKgDQAOgEAYALQgJgcgCgVQgBgNgWgOQgNgHgNgFQgEgCACgqIACgqIAJBHIANALQAOALAHABQAMACATAbIACAmIACAQQAEARAHALQAGAJASALQAQAJAAACQAAAHANg5QAGgKAEgOQAIgcgMgRQgMgRAQgQQAIgIAPgHQAFgEAkgLQgcAZgIAEQgGAEgEAQQgFASAEAJQAEAIgGAVQgGAQgFAJQgEAGgEAaQgEAYAAANQAAAPATA0IAPgLQARgMAIAAQAJAAAJgaQAJgYgCgGQgCgFAyghIBJhqIgKg1IAchLIgNBJIANA9IhDBVIAoARQgcAAgKAEQgGADgcASIgbARIgLAoIA9gHIhHAVQgXANgFAEQgEADgDAQIgDAPIAOBVIgBAdQgBAfgCAKQgEAOAAAmIBOgRIARg0IA1gRIAXgFQAZgGAJgGIAGgCIAAgKQACg2AIgSQALgYAUgeQAYgmAVgQQAKgLAVgpIgvg5QAUhYAAgiQAAgVgThBIgUg8IAUAZQAUAdABANIAJAtQAGAgAAALIABAaQgBASgEASQgHAZAkA0QANgcASguIgDhrIANgaQAOgaAHgDQALgEAuhLIAPhDQgDBogMAJQgKAHgUAcQgWAfgFASQgIAZAAA6IBBgIIAXg7IAegQIgaA2QgGAMgIANQgQAZgMAAQgMAAghAqIgfAqQgOAZgTAdQgjA4gWAQQgbAUgPAuQgRAxAOAjQALAfACA1IACA3QABAEAQgeQAWgqAYgYQAcgaAbhSIAVhNIAAA2QgDA6gQAaQgiAygRAcQgdAzACAaQAFA8AfBsQAKAggmA3Ig6BIQgNASgmAlQg+BvgbAbQgcAbgbA2IABgCQgHAPgGAXQAZgIAxgVQAUgJAQgUQARgVAEgaQAHglA0AAQARAAAwAlQhDgQgPAAQgKAAgMAQQgGAIgMAWQgGAKgDAXIgCAVIA/AJQAGAAgVAFQgVAFgKAAQgKAAgNgGIgTgJQgEgBgUAQQgVARgOAAQgSAAgbAQQgEAYgEAqIgGA+QgOBtgQAuQgOAkAJAPQAKARAlgaQAqgeBFgkQAigiAHgZIgThhIAZgLQAbgOAMgNQATgVAfhDIgDAwQgEAxgMAIQgMAIgYAWIgVAUIAPAlQAdgOAxgIQAXgFATgBIBQAdIiAANQgbADgjAbQggAZgbAlQgjAvhMAxQgMAIArASQAWAJAXAHQg5gEgagJQgVgGgSAMQgUAMgOAdQgTAlgxB2IgFAAIghBtQgVBCgNAzQgmCKAdDlQAZDLA/C4IAFANIADADQAuA6AQAOQAUAQANgSQAEgFAUgnQASgiAbgdQAeghgCgQIgRgjQgTgqgbhYQgHgZgDgbQhJhGgfgUQgUgOgKg1QgIgtAEgSQACgLgSguIgSgsIgEh5IAQA1QAQA3ACANQAEAVAXAqQAtgZAQgRQAJgKgHgsIgKgqIATAbQATAdAAALQAAAQgKAXQgNAbgPAFQgTAHgNAPQgPAQgCAVQgDAXAGAWQAHAZAQASQAUAVA/AxQAAgvAMgkQAPgnAVgoQAZgwAIAGQAHAFgUAmIghA9IgDAIIASghIA2gEQAXAAA8gmIAXAiIgqAAIiJAxQgLA0AMBLQARBgAzBMQAQAXAggRQAYgLBBg2QAtgnADgtQgEgwADgXQAFgggLhAQgLg4gLglQgLgdglgiQghgfgagKQgkgNgUgIQglgPgRgTQgOgPgPgnQgPgmgJgoIhngfIBjAMQgEgTAAgSQAAgigLhGIgMhAIAqBQIAGBYQANBiAfAsQAgAuAyAHQAqAFAFgQQACgHgahDQgehLgDgOQgIgegDgPQgEgaAIgQQgfhTAAgPQAAgLAVgXQATgVANgHQAPgJAQhYIAPiGIADA0QADA2gCAQIgFAnQgCAYgFAMIgNAnQgJAYgMAIQgNAJgDAXQgDATAEAQQACAJAIATQAagjANgOQAdggAkgWQAKgGAQgOQgDgEAAgKIgXiBIBKgzQALgIA5hHQgiBPgLANIgqAXQgfASADASQACAVASBNQA8hAA+hlIgxBkIBAgIQAWgEASgVQAUgXgDgYQgCgWAGgUQAEgLALgWQAMgVAAhYIATBQIgQApQgPAsAEAPQAGAUgOAiQgOAjgUADQgQADgwADIguADIgeA/QgqAkgoArQhUBVAAAcQAAAdAsBYQBcgHApgJQAXgFARgwQAPg0AGgMQAHgRAlgKQAbgHAUAAQAPAAA9hgQgaBHgMAVQgHAMgaAHQgeAGgJAEQgQAHgFAVQgFAVASgDQARgCAhAYQARAMANAMIAhAIQAjAIAMgDQAMgDAcAWQANALAMAMIhfgVIg4gDQgogDgHgPQgHgQgegGIgcgDQgPAlgPAJIgWAdQgQAUgXgHQgWgIgXAXQgRAQgKAWQApBLAjArQAoAyAaCUQANBKAEBAQARgOAUgTQAoglAPgbQAKgUATgwQhhhXADgZQACgSAUgxIAUguIgyhQIAlAaQAkAcAAANQAAANgJAYIgSArQgJAYACASQACAWARALIA7ArIAkhlQAJgdAkgpQATgUAQgPIgXAsQgZAzgKAmQBJgIALgDQAHgCAdAHIgcAPQgSAJgJAAIhEAAIgBgCQgDATAAAIQAAAwgoBdQgpBfghAcQgFAIAbAWQANALAOAJIAqgmIBBANIA1gEIgqAdIg1gIIguAlIA9ARIATBYIgthHQgTADgUABQgnABgCgNQgEgTgug+Ih4B5QhnB5gVAcQgSAZgQBJIgWBkQgIAfAdA/QAcA6AUAMQAoAZAbABQBYgiB2iPQB7iVAwiKQA/i4AajLQAcjlgliKIhQkMQgqiQgHhsQgIhwgQiDQgPgtgJgHQgogdgYAAQgOAAgWgRQgTgQgEABIgTAJQgOAGgJAAQgLAAgVgFQgVgFAHAAQAIAAA3gJQgCgmgKgQIgRgeQgNgQgKAAQgJAAglAIIgjAIIAagSQAcgTAKAAQA1AAAGAlQAFAaARAVQAQAUATAJQA9AZAVAGQARAFACgJQADgHgKgSQgHgMgDgdQgDgdgGgMQgGgKgRgoQgRgmgIgMQgIgMgMgfQgLgbgDgCIgkgbIARAHQASAFABgIIADgqQAEgkAEgMQAFgLgGgaQgGgaAAgGQAAgGAZgqIAYgoIgTApQgTApACAEQAEAGADAdQAEAfgFAQQgIAVgDAgQgDAlAIAMQAFAJAMAbQAJAUABgDQABgFAMgLQALgMAMgIQAIgGANgRQAKgNgBADQgCAGgSAeQgTAggKALQgKALAGAYQAEALANAcQAuBcALAOQAIALAIAYIANglIAPgiQAMgcgBgVQgBgXAigiQARgRARgMQAHgKgIgTIgQgiQgGgNAMgOQAGgHAHgEIgBAXQAAAYAGADQAIAFAFAOQAFAPgCAKQgDALgSAUQgSATgSANQgdAUAiAlQAOAPAGAEQALAHAHgFQAHgFAVAMIAYAQQAHACAXAdQgmgdgPgGQgIgEgZADQgYABgGgDQgGgDgNgRQgKgOAAADIgFAzQgHA3gFAZQgJAvARBiQAFAbAJAgIAOAvQAGAXAPALQARAOAXgGIAagHQANgHAYgSQBJg3AQgZQAhg0gPhfQgUh8gLgzQgOhJgQgpQgMgygKgTQgPgdg6gbQgpgSggggQgNgIgMgNQgLgMAAgDQAAgEgIgSIgFgJIAAAAIgTgoQggAOgSACQgNACgJgFQgJgGAMgDQASgEAPAEIAOgOQAOgRgCgNIgFgnQgEgaACgKQACgLgIgSQgKgTgDgJQgHgWgdgDIgkgCQgGADgKACQgUAEgWgFQgVgFgQAFIgMAGIADgPQAFgPADABQAIADAXAFQAdAGALgBQALgCgFgNIgKgXQgEgJgagKQgWgJgUgEQgQgCgOgPQgPgQAOAIQAPAJAqAIIA2ARIARA0IBOARQAAgmgEgOQgCgKgBgfIgBgdIANhVQgDgegGgEIgdgRIhGgVIA9AHIgMgoQgzgigJgEQgGgDgRgBIgQAAIAogRQBLAugCAHQgCAGAIAYQAKAaAIAAQAOAAAaAXQATg0AAgPQAAgNgDgYQgEgagEgGQgGgIgFgRQgGgVAEgIQAEgJgFgSQgFgQgGgEIgVgQIgPgNIATAGQAUAGADADIAXAPQAQAQgMARQgMARAHAcQAEAOAGAKQAOA5AAgHQAAgCAPgJQASgLAHgJQALgRACgbIACgmIALgOQAMgOAHgBQAMgCAXgVIAJhHQAGBTgGADQgMAEgOAIQgWAOgBANQgCAVgKAcIAOgFQAQgEAIACQAKADANAIQANAIAEAGIAKAOQAEAHgEAAIgbgUQgXgTgJAGQgJAGgbAfIghAkQgHAHgcA2IgaA0IgJBWQgEAdAKBlIAiA0IgDAbIgHAoQgDAOAMAiQAMAhAIAHQAHAHA2BCQAWANAQAEIA/AVQAWABACgvIADhQIgFgQQgEgIgNgIQgNgIgMgDQgJgDgLgJIgKgJIAZAHQAcAJAMAHQAMAGgGgiIgKg4IgKhHQgWgZgOAAQgKAAgYgGQgYgGgKgFQgJgEgPgDIgOgCIALgLQANgLAEAGQAGAGARAHQAQAGAPACQATACAaAMQgZgwgPgVQgRgXgbgVQgIgHgKgSQgIgOgEgLQgCgHAIgxQgBASADAeIALAVQANAVAGAGQAKAIAaATIATg5QAEgMACg0QALBHgHACQgGABgEAWQgEAVACAOQADALAOAWQAUAeAFALQAKATAQgJQAMgHAIgQQAHgNAEgTQAGgWgEgJQgJgSADggIAHgkQAEgZgHgEQgFgDgJgUIgPgiQAHAKATATIAUAWQAGAHgEAZQgDAXgGAQQgFAMAEALQACAGADADIAtgTQAmAEgHACQgRAEgNAFQgZAJgGAJQgEAGgCAdQgBAZgIAHQgKAIgVAjIgTAhIADAqQAEAtAFAJQAFALAHAdQAHAeAAAOIgBAAQAEAYgFAYIgTBIQgFAfAMArQATBDAXBpQAGgRALgZQAUgwAUgkQgIgYgHgHQgIgJgCgUQgCgUAGgKIAPgdQAJgUABgHIALhBQAIA/gGAMQgcBBACALQACAMAPAeIgBAHQAagqAUgOIgRAnQAhAIAJAAQAFAAARgLIAUgMQAEgCATAHIATAHQgPAEgMgGQgHgEgQAIIgaAPQgKAFgUgCQgOgCgJgDIgBgDQgYA2gMAhQghBbAOBQQAGAiAAAvQAFAXAnglIBbhYQAwg5ARhRQAbhiAGgbQAIgmgagiQgagiglgtIgggmQhsg/gKgmQgEgQALALQAdAaANAJQAhAWAWAEQAZAFAAgXQAChNAIgkQAFgaABgkQAAgigEgcQgFgdgCgeQgCghADgQQACgPgNABQgUADgNAAQgQAAgXgqQgWglAAgLQAAgIgQgZQgRgbgIABQgJACgWgXIgVgXIBFAqQAPAJAVAjIALghQACgGgDgUQgEgVgGgBQgGgBANgPIAOgOIgEAiIALAbIgIAQQgJASgCAIQgBALACAMQADAOAIAJIAUAWQAPANAOgBQARgCAIgPQAIgNAAgVIgCgjQABgTAIgLQANgQgFg3IARghIgEBMQgCAXgEAMQgJAgAAAaQAAAPgEAkIgEA2IgBAXQgBASAGAJQAGAKADARIACAiQACATAJADQAKADAMgVIAagxIASghQAEgGgDgLQgEgLgLgHQgKgIgLgPQgJgOAAgHIgChUIAFAHQAEAIAAAMQAAAzAGAOQAEAKANAIQANAHAEgEQAHgEAPgQQATgTAHgNQAJgRABgPQABgQgJAAQgKAAgSgJQgTgIgDgGQgCgGgNgHIgNgGIAZAKQAsAUAHgDQACAAAKADQAJADAEgGQAFgJADgOQAEgQgDgLQgCgLADggIADgfQAAgsgEgMQANAdAAALIAAAlIAKAGQALADAEgNQAFgNAPgJQAIgFAGgCIgKANQgKAPgCAKQgCAHgPADQgOABAAAFIgDAzQgFA3gLASIgvBUIA1AMQAWAGAVgHQAYgIABgUQACgTAPgaQAOgWAGgCIA8gZIgeATQgfAWgHANQgHANgIAbIgKAfQgCAHADgBIAUgGQAOgCAMAOIAMAUQABACgQgHQgVgIgKACQgtALgVgJQgNgFgVgBQgXgBgIAHQgLALgOAUQgTAagHAXQgHAVgSAWIggAlQgOAQgPAuQgFA3AHAdQAVBTAkAiQAfAeAPAEIALghQAQgoAUgoIgYg1QgKgSgCgVQgnABgEgBQgEgBgLgMIgKgMIAMAGQAOAGAEgCQAIgCAbAAIAEABIADgQQAGgTgEgmIgGgnQAAgGAMAfQAMAfABANQABAJgEAZQgFAVACAGQAEAKAbA3QAVgmAbgZIgDAAIgDgXQgBgYAEgFQAGgGAMgTQALgTACgFQACgGgPg2IALAUQALAVAAALQAAAKgJAVIgMAXQgBAIgCAjQASgNAMgEQgQAOgTAXQgmAugOAqQg9CxgEBXQgDA1gYA7QgTAwgTAUQgQASADAHQAEAJAgAAQAXAAAiAKQAdACAcghQAdgiAogfQAUgPAOgIQgmAlgfAqQggAsgLALQgZAWgegFQhAgMgFAAQgpACgnArQghAkgpBAQgpBAgSAUQgzAzgdAeQg1A5gTAvQgVA0ANBXQALBKAbA7QAaA5AjAQQAoASAogxQAdgkBHg+QA5g5ADgyQACgrACgVQgkgcgKgLQgKgLgbgJQgbgJgIAGQgHAFgfALIgdAJIgsAuIAjg0IAcgRQgVgfgPAAQgKAAgTAHIgRAHIgagMIAOAAQARAAAHgEQALgHAsgIIAPAdIAQgBQASgCAIgDQAIgDASAEIAZAFQAMACAPgGQABgKgCgKQgEgUgOgEQgOgEgUgcIgRgbIADhRIAGBHQAAAEANAIIAMAHIARgiIAkAEIgXANIgVAbIALAMQALALADAAQAGAAAHAgIADAPQAEAQAHAIIAOATQAIALAFgEQAWh7BOhMQBjhhBnh1IAIgBIANgeIgRgvIAPgyIgmhGIAyA4IAPgOQAPgPAIgFQAKgGgIgZQgJgZgUgQQgYgTgOgIQgSgLgSgCQgQgBgTgSIgagcQgIgJgGgmIgEglIAPAbQAOAcACAHQACAJAJAOQALAOAIAEQANAGAuADIAchUIgNBcIAaARQAeAUANAOQAMgpgDgRQgCgOAJgUIAJgQIAABFQAAAQgPAnQADASgHAZQgIAdgQAPQgUARgMATQgNAUAEAIQAFALAFA1IAfgOQAfgPAHgBIAlgIQAegHAGgFQAJgHATgJQATgJgBAFQgDAJghAhQg1AJgUALQgMAHhYAjQhfBbg2A8Qg3A8ghA6QgqBKgDA/QgDBVAEAPQAJAbArgWQDLhoBKhfQAEgVgDggIgDgbQgUgcgHACQgFACgVgFQgTgGgLgFQgIgDgWgDIgVgCIAcgRIAzAXQAKAFAogFIADgtQghgkgNgLQgIgHgWgIIgUgFIA6AGIA4ApIAAAhQABAiABAJQADAOAVAjQAlg+AjgxQAigyAPgOQAQgOAKgyQAIgrAAgsIABg1QAAgdgGgbIgrh1Qgcg7gLgdQgGgOgGgVQgKgMgEgHQgIgPgMgRQgQgVgHAAIhCAAIguhDIgwgfQA9AIAAAMQAAAIAWAUQAWAVAPAEQAUAFAZgOIgKg9IAcBGIAZgaQAXg1gCghQgCgXgMgKQgHgGgRgGQgNgEgVgSQgTgQgIgMIgXglIgPgbIAZAVQAaAYAEANQAGAQARANQAQALAPACQARADAXAWIAOgSQAPgTAJgHQALgIgJgTQgIgSgRgLQgKgIgVgaQgWgcgKgIQgNgKgTgbIgYgkQgGgIAPgXQAIgMAJgKIgLA1IARAZQAUAaAOAIQAXAOANAWIAChTQAAgOAHguIAGgsIAFBcIgFBoIA/BWIgwA4IgIAdQgJAfACAKQACANgFASQgGATgJAJQgJAIgEATQgDATAEAMQAEAPADAjQAgBSAOAWIAXAcQAMAOACgZQABgiACgOIAIgsQAEgYgCgHQgBgHgVggIgVgfIA7A1QAMgcgFgRQgDgKgCgvIgCguIAehAIAXiPIgDCXQgMAOgLASQgXAkAIAYQALAfAAAtQAAAugNAMQgMAMgKArQgJAmgCAkQgCAaAOAhQAGAQAHALIAzhhIBEhzIgehIIArA9QA4gyAAgLQAAgMgIgjQgJgpgIgNQgKgPgPgdQgPgdgGgQQgFgOAHgnQAPhVgJA+QgCAKAHAcIAHAgQAAAFAVAhIAUAgQAogtAIgTQAIgUgFhcQARBwgCAIQgDAIgwBBIAPAuQAMAygOAVIhUB4IBggRIASgSQAUgSALgGQALgFAlgfQAhgcAHgIQAGgHAPgjQAPgkACgOQACgMAhgZIAigWIgzBGIgHAVQgIAZgIASIAhAAQALAAAVALQAQAKAGgEQAFgFAdABQApACAQgBQAZgCAhAaQARANALANIg1gfQgUgEgWgCQgsgEgNAKQgSAQhpgcQgGAMgFADQgLAHg6AuIg4AtIA9gIQASgFARAAQAagBAKALQANAPAbALQAfANAPgIQAPgHAzALQAaAGAXAHQgYgCgZABQgzABgKAIQgKAKglgSQgbgNgegVQgRgMg8AMIg5AOIiAANQhCB5gLApQgLAlgKA/QgKA4AAAPQAAARAGABQAMACArgcQAhgVAogNQAhgQAjg7QAjg8AxgtQAYgXARgKQgQANgSAUQgkAogKAgQgFASgQAbQAfgCAWAEQAQADAhAKQAcAJAJAAQAQAAAegKQAjgMAagTQAYgSAxARQAYAIAUAMIhPgGQgZAFgbAHQg2AOgNAOQgMAMhMgIQgqgFgzgKQgtA/grAaQg1AZgdASQgzAhgfA6Qg0BhgrBCQgPAXANAJQAOAKA1AAQAVAAB2AWQBeASAhgPQAugUBegwQgJg1gPgZQgLgSgTgQIgQgOQAKgtADgnQABgYgJgWIgKgSIAjAOQAFBUgHAOQgFAJAPAfQAPAcAKAHQAFADAJANQAdghAAgQQAAgPAagdQAZgdAcgTQgKAJgLANQgVAagEAVQgFAigmBAIAQAXIAFgCQALgFBCg5QA1gvAdAAIAPAAIAkgYQAphOAFgRQADgKApgFIA3gHQAKgDAXgkQARgZgCAFIgXBDIhgAaIg1BvIBgAJIigAQQgZAEg7AoQg4AogbAeQgiAkhzAvQgYAKAXASQAYASA5AJQASADAVABQAygXAcgPQAUgKAVghIAWgmQAIgIgUBIIgxAoIgkASIBaADIBUACQAlggASgWQALgOAhgOQAQgHAOgEIBMhtIg4B7IhHAcIgnA6QAfAJA6AZQAxASAagNIBbgqIAhhqIBOhLIg/BUIgXBUIgWAMQBHggADAIQACAGgcAQQgYAPgkARIAaAbIBMAMIBFAkIhZgXIhHgCIgfgpQgmARgUAEQgvAKhtgeIAdA4IBcAUICJBnIhcgkIg/gvIhlgaIgohPQgagEg8gCIhmgDQAOA8ANARQAPAUAIA6QgmhLgSgWQgPgTgJgpQgpgDgWgHIiDgrQhbgdgpgIQhIgOg3ADQhZAFhJAsQhFAqhRA0IhDAsIBZgHQBdgDAYATQAtAiA5AaQBQAkAqgRQAVgIAzgEIA1g0IgFgBQgIgZgHgMQgFgJgDgRQgBgQABgLQACgIgKgQIgJgQIAPAQQAPASgBAKQgCAOACAPQACAQAFAIQAIAKAIARIAPgPIBKgtIAKgqIAHAwIhHAyIgtA8QBvgFCMADIhsAGQh6AHhCAIIAbApIA/AqIhYglIgsgoIgYAHQgZALgqgDQgogCgogPIAyA7IBMA4IAcAqIh6hUIhshsQgvgPhBADQhGAEhCAXQhPAahFBhQhABYgYBjQgWBXgOBkQgNBeADAlQAFA4ANAVQAaAmBCgbQBBgbA9hHQAhgmAvhBIABgBQACgTgDgLQgPhWgIglQgPgngKgTIgMgcQgHgOgJgCIgbgCQgQgCgJgEIgtgXIAUgBQAWACALALQALAMASgDIAWgEQAGABgDgQQgEgZAAgGQAAgNgKghIgJgeIAQAbQAPAdgBARQgBAWAEASQAFAUAJAHQAMAKAQApQAHgOAPgZQATgeAGgMQAQgeAHgyIAFgrIAFAtQACAygRAcQg8BeAGAlQAFAfASBZIAAAFIBEhcQArg5AdgWQAhgaAmhBQATggAMgcIgOA5QgRA8gOANIAmgIQApgJAQAAQBCAAASgWQAJgMAlgOQASgGARgEIgkAVQglAYgIAKQgJAMggAHQgbAHgVAAQgUAAhtAiQhbBlgaArQgTAggVAbIgRAVIAsggQAxggAVgDQAVgDA6gkQAegTAYgSIhIBIIhFAkQAJAVABAGQABAJAGAIQAHAJAHADQAJAEAoAIIAZAkIgbgXQg3gRgPgGQgNgFgKgtIguAXQgQAHgbAXQgfAZgNAUQggAmgNAUQgZAkAcACQAnAEBcgRQBlgTA1gaQArgVBbiIQBeiMAUgNQAfgWAwgbQA5ghAsgTIAOhgIBJgyIAVgqIgDAvIg9AzIgMBNQASgGANgCQAugDDRhHIAkgaIAwgcIAmhAIA4gDIguARIgPAmQgSAngNAEQgOAEgtAVQBeA5BLAXIgIgFIAwhDIBygTIhgAnIgpA5QAwAMAggEQgSAEgegBQg8gCg+gVIAWBvIgph1IACAAQgfgMgdgQQgLgJgUgDQgogGgvAaQguAahNAYQhNAWgVAIQgaAKglAZIggAXIA+AkQBDAoAXAVQCUCCBggiQBEgYB0gdQBwgbAngEIAOABQA4ghALgFQARgJAUgSQATgTACgKQAIguARgeQASgeAKgnIAFAyIgRAgQgSAkAAAQQAAAJgIAQIBCAOIAugZIgfAvIhfgNQgQAWgNAIIhEAnQAWALAtAjQApAfAQAHQAqAQBUAaQgTAAgbgCQg1gEgkgMIAEAuIAXBDIAmApIAcBDIguhAQgMgKgNgOQgZgbgDgQIgWhnQgNgHgHgIQghglg2gMQgzgLg4ANQgtALhbAbIhRAZIAcAaQAiAcAbAQQBAgGAVgJQAtgUA2ALQAZAGAdgLQAPgFAJgGQgGAIgKAJQgTAQgPAAIgwgEQgegCgLAJQgLAJgnAHIgkAGQAcAIBKAtQAlAXAgAVQirhIgjgQIhAgqQgtgegUAAQgbAAhvgoQgBASgHAPQgWAwgDA1QgCAYAUAvIAeBFQANAkgDAcQgphtgUgkQgQgdACgrIgEgBQgKgEgKAEIgWAKIgbAPIgDAUQgEAWgGAPQgGAOACAIIAEALQACAIAGANQgMgXgLgGQgKgGAKghIALggQgggJgIAEIgWAHQgSAFgHALQgIAMgaAHIgqAJQgPACgSATIgPASIAEgTQAFgVAIgEQAFgCAfgHQAcgHAHgEIASgPQAIgJgJAAQgIAAgXgKQgXgKgFAAIg2ACIA2gTIAdANQAfANAGABQAIACAbgGQAcgHAEgGQAEgGASgFQASgFAPAAQAUAAAygTIABgHQAEgSAEgnQAEgngDgCQhXg7hkg/QghgUgXgFQgngHgWAgIhMB9Qg3BbgSAPQgbAWAAAcQAAAjAuAcQAaAQBKBGQA6A4AgAFICQAfQBwAZApgCQBJgFAXgEQAxgKAegbQAhgeBkgUQBggSA5AJQBIANBMARIjCgNIAzA9QA2A9ATAKQAfARBWAZQgXgEgbgGQg3gMgWgOQgcgSgbgXQgdgbgUgcQgRgXgWgSQgsAGhEAYQg6AUgdAQQgcAPAFASQAFAOAhAaQAJAHAUAVQAzADAvAAQAeAAA4gFQgMAFgPAFQggAKgWgEQgdgEgwAVQAhAoA4BJQAjAqAPAmQhUhUgqg7QghgvgxgpQg1gsgkgGQgYgEhXAIQhYAJgdgFQgggEgxgQQgwgSgMgBQgSgDAYA2IAsBhIAIAaQBUBVAPAWQARAXAvAgQAxAiAWAAQATAAAhAhQAQAQANAQQhMg1gcgGQgQgDghgXQADAYAAAWQAAAbACAPQACAYAGAUIAcBOQgthGgLghQgJgfAChaIghgYIhFhDIgcgdQAPBEAIBWQAHBMAHAnQAKA9ASAqQARAoAOBEQAHAiAEAaIhMjFIgDgKQgOAHgLABQgNACgdAPIgaAOQgkBMgCgJQgCgHAOgmQAQgoAMgKQAOgLBGgbQgciAAAg5QAAgpgWhJQgVhHgbg3Qg9AogYAVQgPAOgEAgIgGApQgFAKgbAIIgbAHIAUgPQAUgSgBgMQgCgOAJgZQAJgYAOgSQASgWBMgkQgagwgngnQgXgYhAg3QhBg3gVgQQgmgcgdgGQhYAGhuAgQjdBBhtCGQh8CahXCLQgOAlAFAJQAFAJAXgHQAYgIAqALQAgAJAiAQQAVAJBjASICBAXQAgAIAXggQAWgdAEgqQAAgIAHgMQgmhUgSgMIg0gLQgMgCgWgNQgZgOgEgLQgDgKgYAEQgZAFgDgBQgEgBgQAUIgQAVQANgoAGgIQAEgGAQgEQANgDAHAAIAkAEIAIghIgUgmIAQgyIgCAUQgBAWABAGQABAFAIAQQAJAPABAEQACAKgGAVQgDAJAPAMQANALANAEQALADAlABQADgWAIgXQAIgYAHgEQAQgIAehcIAFhdQAIBagDALQgCALgNAlIAogDIAYgKQAXgNACgTQABgTAWgYQAMgNAKgJIBHgkQgtAngQALQgJAHgPAaIgVAoQgHAOgUANQgTAMgNAAQgLAAgRAMQgRALgIALQgJANgEATQgGAYAJALQAMAQANAWQAPAagCAGQgBAFARAVQAhgUA/gRIBHgVIAMhNIAaghQAdggATgCQATgCAlgXQASgLAPgMIARgzQgHBKgPAIIgwAUQgmAQgLAGQgLAHgKATIgOAeQgFALAQALQANAJAJAAQAGAAATgGQAVgFAPgGQAUgJAZgIQg6AqgPAGQgRAGgmAgIgBABIACAbQACAbgCAHQgBAHAXAFIAlAIQASAFA1AJQhFAIgKAAQgGAAgegPIgegQQgcAXgKAFQgGAEgFAXIgEAXIgKgsIA1g+IgOgRQgVAMgQAAQgfAAg4AWIgyAWIgJA8QgHA8AQADIBSAPQBDAOATAWQAYAbAvAeQAxAgAWAAQAeAABhgWIh5BIIABA1QAAALAhALQASAGAXAGQAKACAcARIhEgOIhHgIIgKhnQhkg8gWghQgVgdhkgFQhTgFg8AMQgjAGhNgZQhTgagNAAQgbAAAkAqQAeAjAlAdQANALAqAQQAyATAVALIgCgBQBAgXAHgFIAmgXQAggUABgHQACgIAeAUQAaASAQAOQAPAOA6AlIghA9IgCgvIgzg2QgwgWgSAGQgIACgjAXQgfAVgEgCQgGgBgCAmQAuA6A6BwQgigsgqgvIgFAjIAHAwQgIgKgIgMQgQgZACgMQABgKALggQhKhQgggGQgngIhKg3QgiArgIAIQgEAFABAnIADAxQAAAOgWAyQAHgygCgRQgCgMABg0QggA0gOAIQgKAFgGAoQgDAbAAAYQAAARhFBkQAmhHAEgZQAIhQADgZQADgPARgWQAYgdACgFQAHgNAPgPIAOgNIApgzQhAgxgrgwQgpgthVAfQhPAdg5BFQiFEsAHEfQAIFqASFsQASFeATDbQAPClAlD6IAiDeQAAAHg8AFQhqAIgdAEQhOAJhVgDIg3ADIgGAAQghAAgmgFgEgFlghEIABAAIgFAJQgJATAAADQAAADgKAMQgMANgNAIQgiAggnASQg6AbgPAdQgKATgMAyQgQApgPBJQgKAzgUB8QgPBfAhA0QAQAZBIA3QA8AsAjAGQAoAHAOgtQAPgxARixQgKhNgDgPIgOgwQgLgjAAgDQAAgDgKAOQgMARgGADQgGADgYgBQgZgDgIAEQgKAEgWAQIgVAPIAMgPQANgPAFgBQAEgBAUgPQAUgMAHAFQAIAFALgHQAGgFANgOQAjglgdgUQgTgNgRgTQgSgUgDgLQgDgKAGgPQAFgOAHgFQAKgGgEgsIANALQAMAOgGANIgRAiQgIATAIAKIAiAdQAiAigCAXQgBAVANAcIAPAiIAMAlQAIgXAJgMQAhhJAhg0QASgogOgPQgKgLgUggQgSgegBgGQgBgCAJAMQANARAJAGQALAIAMAMQAMALABAFQABADAJgUQAMgbAFgJQAIgMgEglQgDgggHgVQgFgQAEgfQADgdAEgGQAEgGgohQQAxBOAAAKQAAAGgHAaQgFAaAEALQAFAMADAkIAEAqQABAIASgFQAJgDAIgEQgdAXgHAEQgEACgKAbQgNAfgHAMQATgaAOgEQARgEALgMQA9hFgIgYQgSgxgFhEQgCgfAKgoIALgiIgCAwQAAA4AKAnQAMAyALALQAOAMAQgjQAQgjAAgyQABgrgKgkQgGgXgRgSQgPgPAAgHQAAgIgEghIgHg/QgDgjABgoIgHAHQgOAPgPACQgVAEgWAJQgaAKgDAJIgLAXQgEANALACQALABAcgGQAZgFAGgDQAGgCAGAfQgEgDgIgDQgQgFgWAFQgVAFgUgEIgQgFQgTAAgRACQgcADgIAWQgDAJgKATQgJATADAKQACAKgEAaIgGAnQgBANAOARQAHAIAHAGIAKgCQAMgBAKADQANADgJAGQgKAFgNgCQgKgBgVgIIgSgHgAzyOdIAGgFIgHAJIABgEgAG+pCQAOgGAEAFQACAEgFAAIgPgDgAdT8BIA4hAIgTAhQgTAigDAJQgFAOgFAZIgXALgA9Y7OQgFgZgFgOQgDgJgTgiIgSghIA4BAIARA+g");
	this.shape_8.setTransform(46.1,-4.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#403514","#403514","#433816","#4B401B","#574B21","#635627","#6C5F33","#8F805E","#B0A388","#CCC4B1","#E3E0D6","#F5F4EF","#FEFEFD","#FFFFFF"],[0,0.082,0.094,0.106,0.122,0.133,0.165,0.29,0.412,0.533,0.655,0.773,0.89,1],0,0,0,0,0,212.9).s().p("A3pBkQp0gqABg6QgBg6J0gpQJzgpN2AAQN3AAJzApQJ0ApAAA6QAAA6p0AqQpzApt3AAQt2AApzgpg");
	this.shape_9.setTransform(49.2,303.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("EgtGA2mMAAAhtLMBaNAAAMAAABtLg");
	this.shape_10.setTransform(44,0.5);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-244.6,-348.9,577.5,699);


(lib.jabalina3 = function() {
	this.initialize();

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.3,0,0,4).p("AgEAAIAJAA");
	this.shape.setTransform(-301.2,164.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAgLOQgRgDgLgGQgDgCgBgGIgEgKQgPgNgHgHQgBgHACgGIAEgMQAFgUAIgIQADgNAAgQIABgcIABgbIADgPIAAgPQABgJACgGIARgnQAOgWAEgPQABAAAAAAQABgBAAAAQAAgBAAAAQABAAAAgBQACgIABgQIACgYQgEgQgBgJIgGgXQgDgMABgSIABgfQgDgBgFAAIgHgBIAFgWQAGgUAUgxQARgqAHgcQACgFACgBIAJgfQADgEAAgDIgIg8IgDgKQgEgLgKgMIgRgUQgJgKgYggQgOgIgGgDIgOADIgPADQgBAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgPADgaAAIgpAAQgBgBgBAAQAAgBgBAAQAAAAgBAAQAAAAAAAAIgWADQgMABgGgFQgDgRgFgFIgEgKIgFgKIgFgeIgDgHQgMg6gehGQgEgGgNgDIgVgHQgRAHgXAMIgmAVIhNAqIgdAQICRhRQgHgOgDgIQgrAWheA0QhZAygxAZIgrAZQgYAQgLASQAEAEAIgDIAMgFQAWgJAqgVQgLAJgUAJIghAPIgNAFQgIACgFgDQAAgGAFgGIAJgKQAMgLAUgMIAjgVIBgg1IDAhoQAAgDgGgOQACgEAHgCQAIgDACgDQAIgBAMgFQAAAAABAAQAAAAAAgBQABAAAAgBQAAgBABgBQAGgBAMAAQAAAAAAAAQABAAAAgBQAAAAAAgBQAAgBABgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAABAAQAMAAAGAFICchVIE2iqQAzgdAbgMIArgSIAWgIQAOgEALAAQgBAFgFAEIgIAHQgeAWgaAMQgpAZglATIk2CqQgzAdgbANQgLAHgcAPQgZANgNAKIAGAEQAKAOAFALIAAAGQAKAgAcApQAPATAIAMQAMATAFATQAdgMAoABIATgOQALgKAIgEQAFgCAMgCIAUgDIAKgGQAHgEABgFQgBgHgFgKIgHgRQgUgRgJgGQgLAIgNgEQgOgFgDgMQABgIgEgJQAAAAgBAAQAAABgBAAQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAABQAAAAgBAAQAAAAAAAAQgFgHgBgNQAAAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABQgCADgDgBQgBgPACgGQAAAAgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQADgbAMgRIAAgCQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAABAAQAUglAngRQAGgGAIABQAAAAAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBQgBAAgBgBQAAAAAAgBQgBAAABAAQAAgBAAAAQAGgBAGADIAJAGQACAFAJAEQAPgEAGAGIAEABQABAAAAAAQABABAAAAQABAAAAABQAAAAAAABQACADgHAAQABADAFADQABAGAEAFIAGAIQgBAFACAHIACAKIALAeIALAfQABAFgCAJIAAAMIAEALIAFALQAEgBAHgFQACgEAGgGIAIgJQAEgBAKgGIAWgGQALgDAJgHIAPgPIASgTQAugbAegHIAKgGIAMgNQAHgQARgRQANgMASgLQAcgTAOgHIAhgQIAcgUIAagbQAPgPAQgIIARAAIATgGIAOgDQAIgEACAAQADADgBAFQgBAGgDABQADABAHgBQAHgBACABQgBAMgOAEIgaADIABABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIgEAMIgEALQAGAFABACQAEAEgBAGQgDAHgJAAQgKgBgFAAQgFADgGAGQgHAIgEACIgVAGQgOADgGAEQgFAFgEABIgTAUQgMAMgHAKIgSAVQgLAOgJAGQgJAMgXAOQgaAQgIAIIgCADIAAADIgfAiQgSASgRAMIgaASQgFAKgBAQQgBAPADANIABArQABAYAEASIAFAmQADAWAEANQALAdACAjQAAABAAABQAAAAABAAQAAAAAAAAQABAAAAABIABAJIAFALIADAFIADAGQAoAsBGBlIAFAIQAAACgHAGIATAiQAKAUAFAQQAGAUAEAFQABAIAFAJIAIAPIAHAKQgBADABAFQACAFgCADQAGALAGAYQAGAUALAuQAKAtAHAWQABAMAKAbQAAAKADAOIAHAXQAEgJAHAAQADAEACALIAGAEQAEACABADQAJACADgCIAFAHQADAEAFgCIgGAJIgFAKQABAFAEAAQgBACgEAAIgFgGQgDgDgDAAIgEABQgBABgBAAQAAAAgBABQAAAAgBAAQAAAAgBgBIgCgGQgBgEgEgBIgFADQgEABgDgCQgBgDADgHQgFgEAAgDQgTAHghgKIgFACIgFAVQgDANACAKQAOAGAcAAIAvAAQA1AHApgIQgBgDgGgFIgJgIQgKgHgHAAIgFADIgEAEQgGADgJgCIgPgCIAHgMQAEgHgCgGIgDAAQAAAAAAAAQABAAAAAAQABgBAAAAQABAAABAAQACACAAAEQAGAHAQADQASADAGADQAFAEAFAGIAIALQABAEgBAIIgGADIgSAFQgJABgNAAIgYgDIgDAAIAAgBQAVABAcgDIAMgBQAHgBABgFQgCgEgHAAIgKABQgiADgKgBIgqgDIgggBIgfgBIgMgCQgHgBABAGIgCAAQgDgPAEgRQADgRAIgLIgDgMQgCgIABgFIgHgVQgEgNgFgHQgBgHgFgIIgIgNIgKgMIgLgMQgQgagGgPQgDgJgCgQQgDgRgCgHQABgFgEgNIABgFIgFgJQgCgFADgFQgDgLgFgJQgLgQgVgSIgkgeQAAAAgBgBQAAAAAAAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgjg3gmgZIgLgLQgHgHgDgEQgDgEgEAAIgDgFQgIgBgHAGIgIAYQgFAPgFAHIgGAgQgEASgEALQgDABgDgCIgFgBQgCACgBAHQAAAKgFAsQgDAGgDARIgYAyQABAGgEAGQABAVgGAdQgOAUgFANQgGAJgRAlQgCAJgKAWQgIAUgDANQACAFAGAIQgBAPANALQANABAIAIQAGAGAGARIADAEIACAFQACAJgPAIQgLAGgMABIgJAAQgMAAgOgDgAAJK7QgBAGAGADIAMADQAXAEAZABQASgEAIgLIAAgFQAAgBAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAIAAAAIgNAHQgIAFgGABIgVABQgHAAgJgCIgNgCIgGgCIgFgBIgBAAgAANKnIgEADIABALQAbAKAmgDQANgFAIgGQgFgXgXgHQgNAAgMAEIgVAIQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAAAAAIgDABIgBAAIAEgEIADgFQAAgDgDgDIgFgFQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAIABgCIgCgEIAAgJQgIAAgPgJQgIAJgFAcIAPAGIAGAHQACAGADAAQAFABAFgFIgCADgAgWKaIAAACQABACAHACIALALQAAAFAEACQAFADABgFQABgDgDgCIgFgDQgHgKgGgDQgCAAgDgBIgCgBIgCABgAApKOQgMAEgBAGQAEAAAGgCIALgDIAGgBQAEAAABgEQgEgBgFAAQgEAAgGABgAAgKKQgGABgCADIABAEIAVgJQAAAAAAAAQgBgBAAAAQAAAAgBAAQAAAAgBAAIgLACgAAzKKIADgCIgFAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAABAAgAAqJ/IACAAIgOADQgHACgDAEQAEABAIgCIANgDQAGABACgDQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBgBAAIgFgBIAAAAQAHgBgCgGQgDgGgFgBQgKgCgIAGQgIAHAEAIIALgDIAIgBIADAAgAJaKCQAFACAHAAQAHABADgEIgJgDIgIgEgAJKJrQgIAGgGANIABACQAGgBAEgIIAHgLIgDgBIgBAAgAJLJ2IgEAGIAIACIAHgKIgIgDQAAACgDADgAI1JkIgEAEIgFAJQgEAFADADQAFAAADgFIAFgIQADgFAAgEIgDgBIgDACgAI3JzQACACADABQAFgFACgFIgEgBQgFAAgDAIgAAnD/QgCAEABATQABAxALAlQgEAlgDAPIgEADIgCAHQgWAigMApIgDAgIgCAgIACAQIgDAUQgCANABAIIAJAEQAHADAGAAQAGgJASgBQAHgWADgNQALgVADgMQANgdAbgwQAEgPAAgJQgDACgEAIQgDAIgEADQAQgdgBgXQAFgHADgLQAEgGAGgLIAJgSQAGgWACgLQADgpADgSQgVgJgggFIg6gGgAIqJdQAAAKAEAEIADgDQACgCAAgFQABgGgDgGIgDgBQgFAAABAJgAGlHIQAIANABADQACABACAEIADAGIAMAPQAGAJAGAGQAWAhALAyIAAAGQACADACAFQAkAJAPgKQgIgVgCgMIAAgGQgFgbgIgWQgYhngNgyQgFgBgBgBQgDgJAAgIQACgNgJgQQgLgUgCgHIgEgFQgKgsgfguIgBgBQgOAOgdAYIgsAlQAMAOAeAVQAZAVAHAYQAAAKAGANQAHAOABAGQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAgBQgBAAAAgBQgBgBAAAAQAAgBgBAAQAAAAAAAAQAGAyAGASgAAkD5IANADIALAAIALABIA4AIQAGADANAEIATAGQAHgXABgRQARgqAGgXQAHgJAXACQgBADgGACIARARQAKAKAJAEQABAEAHAEIAaAZIAPAVQAJAOAIAFQAPgKAZgWQAJgGAQgOQAPgPAKgGQAAgDAEgDQAEgDABgDQAAgEgDgEIgEgHIgFgDIgYgmQgPgWgNgOQgGgLgOgPQgPgRgGgIQgBgBgBAAQAAAAgBgBQAAAAgBAAQAAgBAAAAQgKgQgEgJIgBAAQgNAJgUAJQg1AXg0ABIgiAAQgTgBgOgDIgJAaQgFARgFAHQgFAXgUAwQgTArgEAeIABAAQAEAAAHACgAApjsIgCAhQgCAUgEALIgFAWQgEAOgBAKIABAYQAEAHAEABQAHANAPARIAYAdQACADAEALIAFAhQAEAWAAAPQAJAEASAAIAeAAQBMACBFgsQgBgDAAgGIgBgKIgDgQIgCgPQgFgQgNgzQABgGgBgJIgBgOQgEgNgCgdQgBghgCgLQgTAAgSgIQgbgSgMgNQgTgUgHgZQAAgJACgFQgEADgBALQAAANgCADIgBgKIgBgKQgDAHAAAMIgBAVQgDAJgDASIgMAXQgHANgJAFIgLAGQgLAAgDABIgOgGQgIgIgEgKQAAgGgCgJIgDgPQgFACABALQABANgBADQgEgLAAgKQgFABgDADgAAShwQAAABAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQgBgLACgGQgEgEgIgFIgLgHQgIgBgFgCQgIgBgLAEIgSAFQgIADgTgDQgMgBgOgHQABgDAFACIAIACQAEAEAFABQAEgCAOABIAFACIABgBIABgBIAAABQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAEgCAOgEQAMgEAIAAQAJgBAJAFIAQAIIABAEQAAABAAAAQAAAAABAAQAAABABAAQAAAAABAAIACgFQAAgDgBgCQAFgHACgMQAGgQABgfQADgKgBgKIABgGQggAEgIADQgKAGgXAWQgxgDgYAPIgFABQgFAEgIACQABgEAFgCIAIgEQAAgOgIgNQgKgTgZggIgTgiQgLgUgEgSIgFgIQgEgFgCgDQgCABgDgBQgKgFgjgEQgEgEAAgIQAMgDACgFQgDgCgIgBQgGAAgFACIgBAKQgBAIgCACQADAEgEAIQgBAEACAEQACAEgBACQAEACARAGQAOAFAFAHIAXBEQANAoAHAeIADAPQACAKACAFIAOAcIABAIQAEAFAKgBQAPgCADAAQAKgCALACQA9AEAugPIACAEQAIAEAEAEIAAAAIAEABgAA+j2QABAFACAPQABAMADAGIAKAGQAGADAGAAIANgBIALgHIAJgIQACgDAAgCQAPgRABgiQgGgdgMgTQgBAFgDAKQgTAQgxADIgFgBQAGAVAJATgADukWIgEAEQgEANgEAcQALAIAWgBIABgdQACgRAFgIQA9gkAmg7QAIgGAHgDIAAgCQgBgBAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAPgEANgIQASgPAigoQAggmAWgQIAbgIQAQgEAFgJIACgDIAFgEIAGgEIAJgBQAMAFACgGQAAgHgGgDQgGgDgHAEQABgBAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAIgJADQgGACgFgBQgEgCgGABQAMgbAGgHQAFgEASgEQAPgEAGgFIAGgBIAEgFQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAIgBAAQgYAFgJAFIgTAAQgDACgHACIgFAEQgEACgHAGQgWAUgGAKIgaATQgQALgNAGIgEABIgGAEQgDACgEAAQgMAGgXAQIgSALQgEACgLANIgIAIIgSAbQgLAMgUAGQg7ASgfAoQgFADgFAHQgGAFgTAFQgSAEgHAFQgIAMACAMQAFAWATATQAPAQAWAKIACgIQACgFAAgHIAEgPQACgJAFgDQAAABAAAAQABABAAAAQAAABgBABQAAAAAAABgACKkrIAGAQIABgUIgCAAQgEAAgBAEgAAckvIAQAMQADAAAEACQAtgBAWgSIAGgdQAAgQgBgEIgCgDQgKgsgYgiQgQgNgQgFQgBAAAAgBQAAgBAAAAQAAgBAAAAQAAAAABgBIgHADQgDgDgDABIgDAGQgDAEgDAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgDAGgSAYQgMARgCASIAAASIACAJQACAGABAFIAFAJQADAGgDAEIgIgHQgGgEgIABQgOAMAGAIQADAJAOACQALACAGgIQAHADAKAJgAk4lYQAAAAgBAAQAAABgBAAQAAAAAAABQAAAAAAABQAFARAGAEIAEgCQgIgOgBgJIgCAAIgCABgAkylbQADANAJAJQAKgDACgGQgGgCgGABQgCgCgCgFQgCgGgCgBgAgblRQAGgGARgCIAEADIACACIgEgPQgEgKgBgIQAAgMAGgUQABgFAEgIIAHgLQAMgKAIgRQgBgHAEAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABABAAIABADQADgFAEgCIADABQAAABAAAAQAAAAABAAQAAABAAAAQABAAAAAAIADgBIAEgBQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAAAIACAAQASAJAEADQAMAIAFAKIAFAJQAAgRgNgLIgBgFQgGgDAAgEIACgBIABgCQgDgDgHAAQgHAAgEADQgCgDgIgDQgCgEgEgDIgHgFIgBADQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQgvAKgYAnIABABIAAACQgSAaAAASIACgDQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAABAAQAAADgDALQgDAJACAGQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQABAAAAgBQAAAAABAAQADADABAGIACALQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAgBQAAAAABgBQAAAAABAAQAAAAABgBQAAAAABAAQACACAAAGgAkil2QgDACgBADIAHAcQADACAFgCQABgIgDgMIgDgRIgGAEgAkYl5QgBAGAEALQADALAAAHQABACAEAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQgBAAAAgBIgCgEIAFgRQACgNgEgFIgLAGgAkwlvIAEAQQADAJAHABQgBgFgDgKQgEgKABgHQgGACgBAEgAjWlsQAEABAHADQgCgEgDgCIgDAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAAAgAjeltIAegQQgFgIgGgOIgBAAIgcAPQAAABAAABQAAABAAAAQAAABgBAAQAAAAAAAAQgOAIgDAFQADADAIABIAKABIACAAIAFABgAjImVQADAPALAGIACgBQgGgLgEgMIgGADgAGNrNQgLADgiANQggAMgbAOIgRAHImVDfQgJAHgWALIgPAIQgOAHgBADQAAACAFAJQAEAIACACIEliiICThRQAegPBQgvIAQgLIANgJQADgEgEAAIgCAAgAj1mJQAAAFAGAAQAGAAABgFIgHgBIgDgBQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAABgAIxouQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBAAAAAAQAAABAAAAIAAACIABAAIACAAgAIzo2QABAJAKgCIAQgCIAEgKIgLAHQgGgCgHAAIgHAAgAI4pDIgDAFIgBAFQAOgBAHgCQAKgDACgKQgEAAgEABIgGACQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIgBAEQgEgBgBgEIgHABgAJbpTQgUAIgLADIAGAAQASgHAegBQAEgDAEAAIADgDQAAAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQgQAAgTAGg");
	this.shape_1.setTransform(-305.6,100.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#934607").s().p("Ai0BmQALgSAYgPIArgaQAxgZBXgvQBeg0ArgXQADAJAHAOIkLCSQgEABgBABIgBABQgqAVgWAKIgMAFIgFABQgEAAgDgDg");
	this.shape_2.setTransform(-354.6,76.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF7F00").s().p("AgGgHQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAIAEgBQAAAJAHAMIgEACQgEgEgFgPg");
	this.shape_3.setTransform(-336.4,66.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D14D13").s().p("AgKgIIADgDQADACACAFQABAEABABQAFAAAGACQgBAFgKADQgIgIgCgLg");
	this.shape_4.setTransform(-335.2,66.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFC9B6").s().p("AgBAFIgFgOQACgDAEgDQAAAIADAHQADALAAAFQgGgBgBgKg");
	this.shape_5.setTransform(-335.5,64.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFC9B6").s().p("AAAASIgGgaQABgDADgDIAEgEIADARQADAKgBAJIgEABIgDgBg");
	this.shape_6.setTransform(-334.4,64.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFC9B6").s().p("AAAAUQAAgIgCgKQgEgKABgFIAJgHQAEAFgCANIgFAPIACAFQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAAAQgEAAAAgBg");
	this.shape_7.setTransform(-333.1,64);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFC9B6").s().p("ACFCJQAAAAgBgBQgBAAAAAAQgBAAAAAAQAAAAgBAAQgDgEgJgEIgEgEQguAPg9gEQgIgCgKACQgEAAgOACQgLABgEgFIAAgIIgPgcQgCgFgBgKIgEgPQgGgegOgmIgXhEQgFgHgNgFQgSgGgDgCQAAgCgCgEQgCgEABgEQAEgIgCgEQACgCAAgIIACgKQAEgCAHAAQAHABAEACQgDAFgMADQAAAIAFAEQAiAEALAFQACABADgBQABADAEAFIAFAIQAEASALAUIATAiQAZAeALATQAFANABAOIgGAEQgFACgBAEQAHgCAEgEIAEgBQAYgPAxADQAXgWALgGQAJgDAggEIAAAGQAAAKgCAKQgBAfgHAQQgBAMgFAHQABACgBADIgBAFQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAIgBgEIgQgIQgKgFgKABQgIAAgLAEQgPAEgDACQgBAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBgBIgBABIgBABIgFgCQgOgBgEACQgFgBgEgEIgIgCQgEgCgCADQAPAHAMABQATADAIgDIASgFQALgEAHABQAGACAIABIANAHQAIAFADAEQgBAGAAALIAAAAIgCgBg");
	this.shape_8.setTransform(-317.2,75.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFC9B6").s().p("AgFAAQABgCAEABIAGABQgBADgFAAQgFAAAAgDg");
	this.shape_9.setTransform(-329.6,61);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFC9B6").s().p("AgEAAQABgDADACQADABACACQgFgCgEAAg");
	this.shape_10.setTransform(-326.6,63.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D14D13").s().p("AgHASIgKgCQgIgBgCgCQACgGAPgHQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAgBIAagQIABAAQAGAPAFAGIgcAQQgDgCgEABg");
	this.shape_11.setTransform(-327.9,61.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF7F00").s().p("AgGgIIAFgDQADALAFAKIgCABQgJgFgCgOg");
	this.shape_12.setTransform(-325,60.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DD781D").s().p("AkiCaQgFgJAAgCQABgDANgHIAQgIQAVgLAKgHIGVjdIAQgHQAbgOAggMQAjgNAKgDQAHgBgDAFIgNAJIgRALQhQAvgdAPIiTBPIklCiQgCgCgEgIg");
	this.shape_13.setTransform(-295.1,44.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFBF00").s().p("Ag3BAQAAAAgBAAQAAAAgBABQAAAAAAAAQgBABAAAAQgBABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAIgCgLQgCgHgDgCQAAAAAAAAQgBAAAAABQAAAAAAAAQgBABAAAAQAAABAAAAQgBAAAAAAQAAABgBAAQAAAAAAAAQgDgGADgJQAEgLgBgDQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABIgCADQAAgTASgXIAAgCIAAgBQAXgnAvgLQABAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgCIAIAEQAEADABAEQAIADACAEQAFgDAGgBQAIAAADAEIgCACIgCABQABAEAGADIAAAFQAOALAAAQIgFgJQgFgJgMgIQgEgDgTgJIgCAAQABAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAAAIgEABIgDABQgBgBAAAAQAAAAgBAAQAAAAAAAAQAAgBgBAAIgCgBQgFACgCAEIgCgCQAAgBAAAAQAAgBgBAAQAAAAAAgBQAAAAgBAAQgEAAABAHQgGARgMAKIgHALQgFAHgCAEQgGATABANQAAAIAFAKIAGAPIgEgDIgFgCQgQACgGAGQAAgGgDgCg");
	this.shape_14.setTransform(-303.1,59.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFC9B6").s().p("AgDBTIgQgMQgKgJgHgDQgGAIgNgCQgOgCgDgJIAEABQgCgHAGgEQAGgEAFAGIgFAKQACAFAIgCQAJgCgCgFIgGADQgEABgDgBQAAgDADgBQADgCABgCQgEgKgLADQgMACACAMQgGgIAOgMQAIgBAGAEIAKAHQADgEgDgGIgFgJQgBgFgEgGIgCgJIAAgQQACgSAOgRQASgYADgGQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAABIAAABQADAAADgEIADgGQADgBACADIAGgDQAAABgBAAQAAAAAAABQAAAAAAABQABAAAAABQAQAFAQANQAYAiAKAqIACADQABAEAAAQIgGAdQgWASgtABQgCgCgDAAgAAqAjIgSAHIgDADQgBAAAAABQAAAAAAABQgBAAAAABQABAAAAABQAAAAABAAQABAAAAAAQABgBAAAAQABAAAAgBIAEgDIAOgGQAFAAAGgCIAGAAQADgBgBgDIgCAAQgHAAgKADgAANgnIAHAJIAHAIQAFAFAEACQABACAFADQAFADABADIgGAEIgGAEQgEACABADIALgHQAHgDABgGIgRgNQgJgIgGgHQgDgGgCAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAAAAAAABgAgPgYQACADACAGQACAFAFABQABgEgDgEQgDgEAAgDQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBACgAgZgRQABgBAAgGQABgGAHgDIALgEQgCgCgDABIgHABQgOAOAGAGgAAbgtQADAJAHAFQACgDgDgFIgEgHQgEAAgBABgAAWg3QgFACACADIAFgDQADgCADgBQAFACAAgDIgFgCg");
	this.shape_15.setTransform(-300.7,62.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAAAGIADgIQgDgGgGAEQgGAEACAFIgEgBQgCgKAMgCQAJgDAEAKQgBABgDABQgDABAAADQADABAEgBIAGgDQACAFgJACIgEABQgEAAAAgEg");
	this.shape_16.setTransform(-306.5,67.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#015353").s().p("AAJALQgGgCAAgFIgJgJQgHgCgBgCIAAgCQAAAAABAAQAAgBABAAQABAAAAABQABAAAAAAQADABACAAQAFADAIAIIAFADQADACgBADQAAABAAABQgBAAAAABQAAAAgBAAQAAABgBAAIgDgCg");
	this.shape_17.setTransform(-306.4,168.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#015353").s().p("AAFAcQgEgBgCgFIgGgIIgOgFQAEgaAIgKQAQAJAIABIAAAIIABAEIgBACQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIAEAEQAEACgBAEIgDAEIgDAEIAAABIgBAEQgFAFgEAAIgBAAg");
	this.shape_18.setTransform(-305.6,165.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#015353").s().p("AgbAGIgMgDQgGgDABgDQADgBADACIAGACIANAAQAJABAHAAIATgBQAGAAAIgDIANgHIAAAAQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABIAAAFQgIAJgSAFQgXgCgXgEg");
	this.shape_19.setTransform(-300.1,170.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFC9B6").s().p("AhCC5IgLgFQgBgIACgMIACgVIgBgPIADghIAEgfQALgpAXghIACgHIADgDQAEgPADglQgKglgBgxQgBgTACgEIABgBIA5AHQAfAFAVAIQgCATgDAoQgCALgHAXIgJASQgFAKgFAHQgCAKgGAHQABAWgPAcQAEgCADgJQADgIAEgCQAAAJgFAQQgbAvgKAdQgDAMgLAWQgDAMgIAWQgRACgHAIQgGAAgGgCgAgOAJQgBANAJADQgGgGgBgHQgBgEADgIIADgKIgCAAQgEAMAAAHgAAphXQgDAQACAGIADgVIgBgBIgBAAgAgThDIACABIAEgFIAEgGQgHACgDAIg");
	this.shape_20.setTransform(-298.3,144.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#015353").s().p("AgpAMIgBgLIAEgBIADgDIABgEIADgBQABAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAABIAVgIQAKgEANgBQAXAHAFAWQgIAGgNAFIgQABQgaAAgVgJg");
	this.shape_21.setTransform(-300.4,168.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAAgIIAFgBQAEgBABACIgKAEQgFADgBAEQAAAGgCABQgFgGANgMg");
	this.shape_22.setTransform(-302.5,59.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#047391").s().p("AhKB6QgNgDgGgDIg5gIIgKgBIgMgBIgMgCQgIgDgFABQAFgeASgrQAUguAGgXQAFgIAFgRIAJgZQANADATABIAjAAQA0gBAygYQAVgJAMgIIABAAQAEAJALAQQAAAAAAAAQABABAAAAQABAAAAABQABAAABAAQAFAJAQAQQANAQAGALQAOAOAOAWIAZAkIAFADIAEAHQADAEgBADQAAAEgEADQgEADgBACQgJAHgQAPQgQAOgJAFQgZAXgOAKQgIgFgJgOIgPgWIgagZQgHgEgCgDQgIgEgKgKIgPgRQADgCABgDQgUgCgIAJQgGAXgQAqQgBARgIAXIgSgHg");
	this.shape_23.setTransform(-283.4,114.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#015353").s().p("AgKABQACgBAHgCIAJgCQABAAAAAAQABAAAAABQAAAAAAAAQABAAgBABIgSAHIgCgEg");
	this.shape_24.setTransform(-302.1,165.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgOAFQAAgFAMgCQAKgEAHAEQAAACgEAAIgHAAIgJADQgFACgDAAIgBAAg");
	this.shape_25.setTransform(-301.2,166.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAAACQgCgEgCgDIABgCQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAAAQABABAAAAQAAAAAAAAQAAABAAAAQAAAAAAgBQAAADADACQADAEgBAEQgFAAAAgGg");
	this.shape_26.setTransform(-301.8,60.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgbgCQgFAAgBgBIAAgBIABgBIABgBIANAGQAHADAIABIAMAAQAQgDAJABQgIADgQACIgHAAQgVAAgJgJg");
	this.shape_27.setTransform(-298.8,88.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgPAEQADgEAHAAIAMgCIgCgBIADAAIAFABQABAAABAAQAAAAABABQAAAAAAAAQAAABAAAAQgCACgGgBIgLACIgJABIgDAAg");
	this.shape_28.setTransform(-301.9,164.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#015353").s().p("AgJgEQAIgGAIACQAFABADAGQACAEgHABIAAAAIgDABQgEgBgFACIgLADQgEgIAIgFg");
	this.shape_29.setTransform(-302.1,163.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFC9B6").s().p("AgCA8QgGgBgGgDIgKgGQgDgFgBgNQgCgPgCgEQgIgSgGgVIAEACQAwgEATgQQADgJAAgGQAMATAHAdQgBAhgPAQQAAADgCADIgKAIIgKAHIgJABIgCAAg");
	this.shape_30.setTransform(-296.1,74.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#00A0C6").s().p("AhBC2QAAgPgDgWIgGgjQgDgKgCgDIgZgdQgOgSgIgNQgDgBgEgHIgBgXQAAgJAEgOIAGgWQAEgLABgUIADggQADgEAEgBQABALADAKQABgDgBgNQgBgLAFgCIAEAPQACAJAAAGQADAKAIAJIAOAFQADgBALAAIALgGQAJgFAHgNIANgWQACgTADgIIABgVQAAgNADgHIACAKIAAAKQACgDAAgNQABgKACgEQAAAGAAAJQAFAYATAVQAMAMAcASQARAJATgBQACALABAhQACAdAEANIACAMQAAAJAAAGQAMA0AFAPIACAPIAEARIAAALQAAAGACADQhGAthJgDIgfABQgSAAgJgFgAAaBxQADAPgEALIABAGQACACADAGQADAFADACQgFgLgDgFQgCgDACgFIABgIIgDgVQgCgJgFgKIgBAAIAHAZgABaCIQgBgIgEgMIgGgTIgCgBQADANAKAbgAguB1QACgaADgKIgBAAQgGATACARgAh7AKIgBABIAAABQABACAEAAQALAMAdgCQAQgCAHgDQgIgBgQAEIgPgBQgHAAgIgFIgMgHgAA2gqIgMAWQATgbAEgTIgCgBQgCAMgHANg");
	this.shape_31.setTransform(-289.7,87);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#015353").s().p("AgBAAIADAAIgCAAIAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAAAg");
	this.shape_32.setTransform(-300.5,165.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgEAEQAEgGAFgCIgEAEIgDAFIgCgBg");
	this.shape_33.setTransform(-299.8,137.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCACQAAgFACgOIACAAIgCALQgCAHABAEQABAHAEAGQgHgDABgNg");
	this.shape_34.setTransform(-299.5,145.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AADAUIAGgDIAGgGQgBgEgFgDQgFgDgBgBQgDAAgEgGIgHgHIgHgKQAAAAAAgBQAAAAAAAAQAAAAABgBQAAAAABAAQACABADAFQAGAHAHAIIARALQgBAHgHAFIgLAHQAAgEADgCg");
	this.shape_35.setTransform(-297.4,61);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgTAIQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIADgDIAQgFQALgEAIABQABADgDABIgGAAQgGACgFAAIgMAEIgEADQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAIgBAAg");
	this.shape_36.setTransform(-296.6,66.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgDAAIAGgDIAFACQAAABgFAAQgDAAgBABIgFADQgCgEAFAAg");
	this.shape_37.setTransform(-298,57.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgEgFQABgBADAAIADAGQADAFgCACQgFgEgDgIg");
	this.shape_38.setTransform(-297.4,58.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AABgQIABAAQgCAKgBAYQgCgSAEgQg");
	this.shape_39.setTransform(-294.1,96.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAAgJIABABIgBASQgBgFABgOg");
	this.shape_40.setTransform(-294.1,136.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFC9B6").s().p("AgCgEQACgFADABIgBASIgEgOg");
	this.shape_41.setTransform(-291.5,70.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AADAcQgDgGAAgBIgBgHQACgKgBgOIgIgYIACAAQAEAJACAKIACASIgCAJQAAAEAAAEQAEAEAFALQgDgBgDgGg");
	this.shape_42.setTransform(-286.8,99.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFC9B6").s().p("AilC6QAEgcAEgMIAEgFQAAAAABgBQAAAAAAgBQAAAAAAgBQgBgBAAAAQgFACgCAKIgEAOQAAAHgCAFIgCAJQgWgLgPgQQgTgTgFgWQgCgMAIgLQAHgFASgFQATgFAGgFQAFgGAFgDQAfgpA7gSQAUgFALgLIASgaIAIgJQALgMAEgDIAQgKQAXgQAMgHQAEAAADgCIAGgEIAEAAQANgGAQgMIAagTQAGgJAWgUQAHgHAEgCIAFgEQAHgBADgCIATAAQAJgFAYgGIABAAQAAABABAAQAAABAAABQAAAAAAABQAAAAAAABIgEAEIgGACQgGAFgPAEQgSAEgFADQgGAIgMAbQAGgCAEADQAFAAAGgCIAJgDQAAAAABABQAAAAAAAAQAAABAAAAQAAABgBAAQAHgEAGADQAGADAAAIQgCAFgMgEIgJABIgGADIgFAEIgCAEQgFAIgQAFIgbAHQgWAQggAmQgiAngSAPQgNAIgNAEQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIAAACQgHADgIAHQgmA6g9AkQgFAJgCAQIgBAdIgFABQgSAAgKgIgAhAAsQgDAFgHAIIgKANQgLAIgGAHQgWAQgUAJIgIAHIAAAGQABAEACABQgBgGABgDQACgDAIgFQAigPAcghIAJgKIAEgFQADgCgCgDIgBAAIgBABg");
	this.shape_43.setTransform(-266.3,58.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAAABQAHgLACgMIACABQgEATgRAZIAKgWg");
	this.shape_44.setTransform(-284.3,82.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgFgTIACABIAEASQAEALABAJQgIgZgDgOg");
	this.shape_45.setTransform(-281.2,98.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgrAlIAAgFIAHgIQAUgIAUgQQAHgFAKgJIAKgNQAIgIACgEIABgCIACAAQACADgDADIgFAFIgIAKQgdAegfAPQgJAGgCADQgBACABAGQgCAAAAgFg");
	this.shape_46.setTransform(-277.1,66.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFC9B6").s().p("AA8DLQgCgFgDgCIAAgGQgKgzgWghQgGgGgHgJIgKgPIgCgGQgCgEgDgBQAAgDgIgNQgGgSgGgwQAAABAAAAQABAAAAABQAAAAABABQAAAAAAABQABABAAAAQAAABABAAQAAABABAAQAAAAABAAQgCgGgGgOQgGgMgBgKQgHgYgZgVQgdgWgMgNIAsgmQAdgXAOgOIABAAQAcAvALAsIAEAEQABAHALAUQAKAQgCANQAAAJACAIQACACAFABQANAvAYBoQAHAWAGAaIgBAHQADAMAHAVQgHAFgNAAQgMAAgSgFgAAEALQABAIAGAOQAGAOABAIIAJAjIACAGQABAEACABIgDgOIgEgPQgEgVgEgKIgHgQQgFgJAAgHg");
	this.shape_47.setTransform(-261.8,140.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AALApIgCgGIgJgjQAAgGgFgPQgGgOgCgIIABgCQABAIAFAJIAGAQQADAJAEATIAEAPIADAPQgCgCgBgDg");
	this.shape_48.setTransform(-260,146.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAkAFQgKgBgmAAQgeAAgPgEIgBgFIABAAQACADAHABIAKABQANABAXAAQAagBAJABIAYAEIACAAIAAABIgXgBg");
	this.shape_49.setTransform(-251.5,168);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#015353").s().p("AgBAYIgvAAQgcAAgOgGQgCgKADgLIAFgVIAFgCQAhAKATgHQAAADAFAEQgDAHABADQADACAEgBIAFgDQAEABABAEIACAEQABAAABAAQAAAAABAAQAAAAABAAQAAAAABgBIACAAQADAAADACIAFAGQAEAAABgCIABAAIAPACQAJACAGgDIAEgEIAFgDQAHAAAKAHIAJAIQAGAFABADQgVAEgZAAQgWAAgYgDg");
	this.shape_50.setTransform(-247.8,164.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgFACIAFgGIACgFQADgCADACQAAADgDAFIgFAGQgBAGgFAAQgDgDAEgGg");
	this.shape_51.setTransform(-249.3,162.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFC9B6").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQAAABAAAAIgBgBg");
	this.shape_52.setTransform(-249.6,44.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#015353").s().p("AgDgBQgBgKAGACQADAGgBAEQAAAHgEADQgDgEAAgIg");
	this.shape_53.setTransform(-249.7,161.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#015353").s().p("AAYAIIgCAAIgWgEQgJgBgcABQgXAAgMgCIgKgCQgIAAgBgCQgBgGAHABIAMACIAfABIAgABIAoADQAKAAAigCIAKgBQAHAAACADQgBAEgHABIgMABQgWACgRAAIgKAAg");
	this.shape_54.setTransform(-248,167.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFC9B6").s().p("AgOAAQAMgBAGABIALgFIgEAIIgOACIgDABQgHAAgBgGg");
	this.shape_55.setTransform(-247.7,43.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#015353").s().p("AgFACQAFgKAFAFQgCADgDAFQgDgBgCgCg");
	this.shape_56.setTransform(-248.3,162.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFC9B6").s().p("AgNACIACgCIAIgBQAAACADAAIABgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQABAAAAgBIAGgBQAFgCADABQgBAHgLAEQgEACgPAAIACgFg");
	this.shape_57.setTransform(-247.6,42.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgHAIQAGgKAGgHQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAIgGAKQgCAHgGABIgBgCg");
	this.shape_58.setTransform(-247.5,163.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFC9B6").s().p("AgfAIQAKgDAUgGQARgGARAAQAAAAgBABQAAAAAAABQAAAAAAAAQgBABAAAAIgDADQgEAAgEABQgbABgTAHg");
	this.shape_59.setTransform(-245.1,40.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#015353").s().p("AgGAEIAEgEQACgDAAgCIAHADIgHAIIgGgCg");
	this.shape_60.setTransform(-246.6,163.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#015353").s().p("AAAAFQgEgBgFgCIAFgGIAFAEIAJACQgCADgGAAIgCAAg");
	this.shape_61.setTransform(-244.3,164.2);

	// flecha1
	this.instance = new lib.Path();
	this.instance.setTransform(-263.6,-39);

	// flecha2
	this.instance_1 = new lib.Path_4();
	this.instance_1.setTransform(13.7,41,1,1,0,0,0,286,132.5);

	// flecha3
	this.instance_2 = new lib.Path_3();
	this.instance_2.setTransform(49.3,-1.7,1,1,0,0,0,340.5,175.5);

	// Capa 4
	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#11AA0C").s().p("AgFAAIgBAAQADAAAHAAQAKAAACAAQgEABgbAAg");
	this.shape_62.setTransform(-384.7,171.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#11AA0C").s().p("AgDAAIAEgBQADABAEAAIgPACQAAAAAAgBQAAAAAAAAQABgBABAAQABAAABAAg");
	this.shape_63.setTransform(-317.5,171.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#11AA0C").s().p("AgFAAIAGAAQABAAABAAQABAAAAAAQABAAAAAAQABAAAAAAIgHAAIgEAAg");
	this.shape_64.setTransform(-302.2,177.4);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#11AA0C").s().p("AgjALIgCgLQAAgFAHgEQAMgDAXAAIAhAAQgKAHgOADQABAAAAABQAAAAAAABQAAAAAAAAQAAAAgBAAIgIACQgBgBgBAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAFAAABgCQgJgBgFACQgIABACACQALABgDACQgIACAGACQAAADgQABIgFAAQgKAAgBgCg");
	this.shape_65.setTransform(-304.5,175.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#11AA0C").s().p("AgFACIgDgEQAIAAAEACQADAAACADg");
	this.shape_66.setTransform(-337.1,164.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#11AA0C").s().p("AgEAAIAIAAIgFABQAAAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAg");
	this.shape_67.setTransform(-335.7,165.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#11AA0C").s().p("AgEAAIAEAAIAFABg");
	this.shape_68.setTransform(-334.6,164.9);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#11AA0C").s().p("AgKADQAFgCACABQADADAFgCQgFgCAAgBQAAgDALgBIgCAIIgMABQgGAAgBgCg");
	this.shape_69.setTransform(-346.8,165);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#11AA0C").s().p("AAAAAQgEgBgKACIACgCIAbAAIgRADg");
	this.shape_70.setTransform(-349.4,165.2);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#11AA0C").s().p("AgRAGIgEgEQASADAFgDQALgCAIAAQgGgDgUAAQgYAAgJADIAMAAIgMAGQgBgBgBAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQgDADgRAAIgjgBQAHgCgHgDQgGgCAJgCIBlgCQAAAAABAAQAAAAABAAQAAAAABAAQABgBABAAIgDABIAfAAQAIACADADQADABAOAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIgFgEIAUAAIgBACIARgDQAEAEgSACQgNABAQADQgXADghAAIg1AAQABAAABAAQABAAAAAAQABAAAAgBQAAAAAAAAg");
	this.shape_71.setTransform(-321.9,164.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#11AA0C").s().p("AgHABQAHgBAAAAQAIAAAAABg");
	this.shape_72.setTransform(-277.7,163.7);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#11AA0C").s().p("AgOACIABgCIABgBIAbAAIgHABQgFABAFABg");
	this.shape_73.setTransform(-275.5,164.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#11AA0C").s().p("AAvALIABgDQgEAAgIACQgHACgHgBIASgGQgPACgQgBQgIAAgRACIABgBIgXABQgPABgHADIAAgFQgIAEgGgBQgIgDgLABIADAAQgKAAAAgCQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQgLgBgOAFQgNAGgNgCQABgCgEgDQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAMADAKgCQACgCgLAAQgKAAAIgDIgcgDIC8AAIACgCIAEACIArAAQgBgCAKgBIAOgBQgIACABACIARgBQADgBAXABQARAAgFgFIAOACQAKACAHgBIACADIACAAIgDABIgCAAIgIADQgCACAHAAIgYAAQgNAAABADQAIADAGAAQgLABgPACQgOACgLAAIAagGQAOgEgNgBIgQAFQgEgBAEgBIAHgCQgBgBgLAAQgLAAgDAAIAHACQAEABgHACIgrAIIADgCg");
	this.shape_74.setTransform(-295.7,164.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#11AA0C").s().p("AgEACIAKgCQgFgBgDABQgDAAgDgBIAQAAQABAAAAAAQAAABAAAAQAAAAgBAAQgBAAgBAAQgFACgDAAIgCAAg");
	this.shape_75.setTransform(-229.5,175);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#11AA0C").s().p("AgHAAQAAAAAHAAQAGAAACAAIgLABIgEgBg");
	this.shape_76.setTransform(-210.5,171.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#11AA0C").s().p("AgDAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIAJAAIgHABIgBAAIAAgBg");
	this.shape_77.setTransform(-225.8,164.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#11AA0C").s().p("AgVAEQgBgEASAAIAagEIgUAEIAEABQgGAEgKAAIgLgBg");
	this.shape_78.setTransform(-203.7,174.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#11AA0C").s().p("AAEADQgEgDgIAAQAIAAgBgDQgDgDANACQgKACAGACQAIAFgGABQAAAAAAgBQAAAAAAgBQgBAAAAgBQgBAAgBAAg");
	this.shape_79.setTransform(-195.6,174.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#11AA0C").s().p("AAAAAIgEgBQAJgBAAACQAAABgFABQAAAAABgBQAAAAAAgBQgBAAAAAAQAAAAAAAAg");
	this.shape_80.setTransform(-206.8,165.7);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#11AA0C").s().p("AgHAAQADgBAEABIAIABIgFAAQgJAAgBgBg");
	this.shape_81.setTransform(-195,170.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#11AA0C").s().p("AgDAAQgBAAgBAAQAAAAABAAQAAAAACAAQABAAABAAQAGAAAAAAQgDAAgGAAg");
	this.shape_82.setTransform(-202,164.2);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#11AA0C").s().p("AAAACQAAgCgUgBQAUgBAWABIgKABQgEADgHAAIgBgBg");
	this.shape_83.setTransform(-197.7,164.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#11AA0C").s().p("AAAAAIgDAAQgCgBALAAIAEgCIgDACQgBABgFAAIgKAEIAJgEg");
	this.shape_84.setTransform(-177.8,171.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#11AA0C").s().p("AAAAAIgGAAQAIAAAEAAIgDAAIgDAAg");
	this.shape_85.setTransform(-171.7,171.3);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#11AA0C").s().p("AgBAAQAFAAAAAAIABAAQAAABgGAAQgGgBAGAAg");
	this.shape_86.setTransform(-158.6,174.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#11AA0C").s().p("AgHAAIAPAAIgGABg");
	this.shape_87.setTransform(-140.4,175.6);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#11AA0C").s().p("AgCAAQAHgBgCgDIAIAEQgIAAgDACQgCACgHABQgCgCAJgDg");
	this.shape_88.setTransform(-151.5,166);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#11AA0C").s().p("AghAAQANABAUgCQARgEARADQgNAAgRACIgbAEg");
	this.shape_89.setTransform(-149.5,167.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#11AA0C").s().p("AABAAQAEAAABAAIgLAAIAGAAg");
	this.shape_90.setTransform(-123,166);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#11AA0C").s().p("AgVAFQADgEANgBQAIAAgCgEQgJAAgMAEQAAgFATABQAPAAAIAEQgHAAgOACQgJADgKAAIgDAAg");
	this.shape_91.setTransform(-94.1,173);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#11AA0C").s().p("AgFAAIALAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABg");
	this.shape_92.setTransform(-97.9,170.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#11AA0C").s().p("AAAAAQAHAAAAgBQACACgOABQgEgCAJAAg");
	this.shape_93.setTransform(-98.4,169.8);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#11AA0C").s().p("AhfA9IAfgnQguAAg8gEQgGgEAQgCQAPgCgBgBIARABQAAABgRACQgNABAKADIAkgBQATAAARgEQgFgEgTABQgXABgJgDQAIABAMgCIg3gEIgFACIAYACQgOAAgKACQgJADgBAEIADAAIgGACIgNgBIgEABIACgBIgMgCIgFABIABgBIgDAAIgVAFIgTADQgKACgLAAQAJAAgDgCIgSgFQgLgCgOAEIAOgBIgfAJQgFgCAKgCIAOgDQgLACgUgDQgRgDgFAEQgEgMgQABQAGACgFACQgFACAEACQgCABgJAAQgEgBgCABIABgBQgQgEgNAEQgMAGgFABQgRABgVgBIgiAAQAAgDgFgEQgGgEgHAAQgCACgNADQgNADgCACQAKACAGgDQAGgDAEgBQAEACABADQABACAHACIgcAAQgWAAgHgDIAFAAIgVgIQgMgFgSAFIgOADIACgCQgIAAgNgDQgHgBgOACIACgBQgIgCgNACIgTAEQgBgBgBgBQAAAAAAgBQAAAAAAgBQAAAAABAAIAHgDQgdgDgoANIgQgDQAIgBAGgDQAGgCgBgCIgJACIgLAAIANgJQgOgCgBAEQgBADgIgDQgNAAgBAHIgPgFQgCAEgeABQgBABAFACQAHABADgBQgCAFgUAAQgCgEgZAAQgWAAAEgFIg+ADQgmABgOACIgOgCQgHgCAHgCQgNAAgZAEQgWADgQgBIAGgBQAHAAAAgCQgKACgUgCQgTgDgOABQABAAAAAAQABgBAAAAQABAAAAAAQABgBAAAAQgCABgSADQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQABgBABAAQAAAAABAAQAAAAAAAAQAAAAgBAAQgggDgwAFQg1AEgZAAQAJAAAGgDQAFgCAAgCIgQgBQgEACgIABIgQACIgDgBQAAgBAAAAQgBAAABgBQAAAAAAAAQABAAABAAQgRgDgaAFQgcAGgTgBIAwgMIgMgEIAVgDQgHgBgKABQgHAAgBAAQAJgBABgCQgHgBgGABIgKACQAPgFAggCIAxgDQABgBAAABQABAAgBAAQgBAAgBABQgBABgCABIAOABQAHABAIgBQAFgCgGgBIgMAAQABgBAAgBQAAAAABAAQAAgBABAAQAAAAABAAIAIgBQABACAUABQAWABAFADQATgBgEgFQgCgEARABIALAFQAtgIAdACIgFAAQgDACAHADQAIABASgCQAOgBAGADQAMgDBDgJQAEAEgSACIgaAEIAUAAQgNAAgNAGQALABAMgDIAVgEQgDADAMAAIACgEIAFABIAfgDIgGgDQgEgCgFAAQADACgQAAQAFgBgGgBQgGgBgBgBQAhAAAQgCIADAEQAQABAcgBIgEACIAdABQAQAAAKACIA0gNQADgCAbADQAcADALgEQACAAgVAFQAEABAMgCQAIgCACADQgQgBAFADQAFAEgFAAQAYAAAKgDQgLAAAEgDQADgDgKABQAdgHAfADQAAADAKABIAGgDQABAAAAAAQAAAAAAAAQgBABgBAAQgBABgBAAQgHACAKABQAIgCAfAAQAYABAGgGQAGACgNACQgMADAMACQgFACgPAAQgNAAgCADQAHgBABADQACADADAAIAOgEIgDAAQAPgDAdAAIAxAAIAjgIQAVgFATABQgDABAKACQALACgMAEQAKACAKgCQAJgBAAgCIgPgCQAFgCALAAQAJAAAFABQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAIABADgBQAEgDADgBQACADANAAIAUABIAOgGQgEACAJABQAKAAABACIAQgFQAKgCAJABQgDABAIABQAKADAAABQANACAXgFQAWgEANADIgDACQAAAAAAABQAAAAABAAQAAABABAAQABAAABAAIAWgBQAGAAAAgBIAPgGQAKgDAMgCQgBgFgaAEIgHAEQgDgDgJABIgLABQAGgEAZgCQAhgDAHgBQgRgIgzABIALADIgNAAIAMAFIgfAAQAGAAAEADQAFADgIgBQgIgDgGACQgJADgDAAQAPAAgGADQgLgDgOgBQgOAAgKgDQACADgOAAQgQAAgBADIAKABIgUAEQgJgDAGgDQAGgCgQgCQgOgBgKAEQgMAEgKAAQAOgIAbAAIgKgCQAGgDAhACQgKADAJAAQAPABAEABQAAgBgDgDQgCgBAIgCIgggBQASABAQgHQAPgGAQACQgJABAHADIAJADIAbgCIgFgGQAIgBAOAFQANAEAMgEQACgDgRABQARgCASAFIAfAIIACgEQADgDAFgCIAAAFQAAACgGABQAIACATgEQgLgBAIgDIAOgDQAMAAgUAEIALADQAHABACgDQAAADgMADQgMAEgLABIAJAAQgFACgMgBQALAEgEAFIgBgBIAAgBQgPgCADAEQgEADAHABIANACIAMgBIAngQQAKgBAKACIARAEIAEgFQAcABgLAHIgGgCIgCACIAAABIAagDQgQAEAEADQAIAHgCACIAbgDQgKgBAEgCIAMgBQABACALgBIASgBIAAABQAMACAXgCQgBgBAJgEIAMgIQgLgBAAgBQABgBABAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAFACABgCQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgEgCIgdADQgPACgFAEQADABAGgCQAGgBADABQgHACgLABIgVAAIgGgEIgQACIAGgEQADgCAKAAQgBgCgJABIgSAAIgFAFQAAgBgHgCQgHgCAJgCIAbgEIgIgDIAXgBIgFADQARgCAHAFQAEAEASgDQAOgHAgACQgIABABACQAAAAABABQAAABAAAAQAAABgBAAQAAABAAAAQAKACAIgCIAMgEQAEACgBACQAAABgLAAQAAADAKAAQAKgBABADQAUAAAZgJQAUgIAfAFIgCACQATgBAbAAQAdABAPgBIAaAGQgHABgFADQgHADAEACQgHgDgMgCQgQgBgEgCQgBAAAAABQAAAAABAAQAAABAAAAQABAAABABIAEACIgLgCQgFgBgHABQANADgKABIgOgFQgJABgHAFQgFADgNgBQAMgIAKgCQgEAAAGgBQAIgCgFgBQgIADgMAAQgOAAgKABIAJgCIgegCQADABgMACQgOACABADQAQABAMAAIAfABQgUADgKAHIgCAAQgDADABADIACAIQAJgDAOAAIAYgBQACgDgHgBQgIgCgIABIARgDIgDADIArABQgFAAgEACIgGADIARADQgCgIAHAAQAkACASAJIADgBQgCgCAMgEIATgGQgBACAJABIAOACQACgDAAgCQAmACAtAAIAMgMQAHgHACgFQApgEARAEIgCACQALACAKgCQAEABgDACQgBAAAAABQgBAAAAABQAAAAABAAQAAAAABABIAZgDQgBADgfABQACAAABgBQABAAAAAAQABAAgBAAQAAgBgBAAQgEAAgSACQgPABgCgDIABgCQADgDgMAAQgPgDgEAIQAAABAJACQAJABgFACIANgCIAPABQgYAFgGgEQgNADgCAGQgBAGAIABQAAgBAPgDQALgCgPgDQAHgCAQgCIAagDIAAABIATgBQgJAEAAABIAbgGQgKACAKABIAQABIAGgEQADgDgGgBQgGgBgDABQgDACgFAAIAPgFIABAAIAJgEQAKAAgEAFQgCADANgCIgEgGIAvAEQAdADALgCQgEADAAAEQgBADAFADQgNgCgaABQgDgBAMgCQALgDAJAAQgDgFgQADQgQADgBgFQgRgCgNAFQgLAEgPgDQAAACgFABQgFABAAACQAEAEAVgBQAagBAIABIgHACQANABARgDIgBAAQAJgDADADQAFAFADAAIAKAAQAHAAgBgCIASAEIgBgFIAMABQAEABAGgCIAAgFIgZgBQAGgBACgCQACgCAHgBQgIADAIABQANABABACIAKgCIgDABQAEABAFgBIALgBIgQgEQgIgBgJACQAXgFANAAQALgCARAEQgGAAgCAHQgBAFgXgCQABgBAEABQgDgEgMADIgRAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAABAJABQgEgCAKgCQAMgDAJACIgCAIIAVABIgCAAQAEACAMAAQAPgBAGABIAbgCQAQgBgKgFQAIACALgBIATgDIgRgDIARgEIAPgGIACADQABAAAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIAvABQAbAAALgEQAHAAAPAFQANADAPgCQABAAAAgBQAAAAABAAQAAgBAAAAQABgBAAgBQABgCALABIgHADQgEADANgBQAIgDARACQATACAKgCIARACQAIABgCACIgZAAQgOABgCABQAAAAAAAAQAAgBgBAAQAAAAgBgBQgBAAgBAAQgBgBAAAAQAAAAABAAQAAgBABAAQABAAACAAQgNgCgGABQgIACgKgBQgBABAGACQAHABAEgBQAAADgUACQgOABAKAEQAJAAARgFQANgEALAEQgDABgLABQgLABgGAEIARACIALgEIgBABQARADALgFQARgGAIgBQgHgDACgEQACgFgFgBQAegCAAAIQgQACAAAEQAAADgPADIAAAFQAAAEAKABQALgDgDgCQgDgBAKgBQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAFgCAFABQAGAAAGgCIgDACQAIACAHgDQAGgCAGACQgCgCAFgBIANgDIgRgFQgMgDgOAAIgCAFQgCABgGABIAPAAIgJACIgOgCQALgBABgDQAEgFACgBIAPABIAKAAQgBADATAEIAiAFIgJAAQgJACAIABIALADIAIgDQgBABAAAAQAAAAAAAAQABABAAAAQABAAACAAQAGAAAHgDQAGgDAIgBQAAABgEAEQgEADAGABQAKAKAVgDIAMgCIgDAAIANADQgFADgLgBQgLgCgFADIgBACQgPAAgKAFIAegCQABACgFACIgGACIADgDQgJgCgNADQgPADgKAAIgCgBIACgBQgIACgRAAQgRgBgIADIAFgCIg4ALIAAACQAFACgPgCIgeAFQADACAIABIAMgCQAKgBgCgCQAGABALgBIAOAAQgHgCAIgBIALgEQABACAJAAQAHAAAAACIgEgBQgFgBgDACQgGACALABQALACgJACQAKgCAZgBQAYAAALgCIgLgCIATAAQAMABABABIgYABQAAACALAAQAMgBAAACIAagIIgLAAQAEgCAQABIAcACQgFAEgOgBQgTgBgHABQgHABAEADQAFADgGAAQAHADAJgDIAEABQgFAEgUABQgVADgIACIADgCQgSgEgVADQAGACAIgCQAAABgRACQAHABgBACQABAAAAAAQAAABABAAQAAAAABAAQAAAAABABQgHABgRgBQAAAAAAgBQgBAAAAAAQAAgBABAAQAAgBAAAAQABAAABgBQABAAAAAAQAAgBABAAQAAgBAAAAQgFABgIgCQgJgCgHABQASACgeAGIADABQgJAEgGgEIALgBQAAAAABAAQABgBAAAAQAAgBAAAAQAAAAAAgBIgQABIAFgCIgZABIgOALQgGgCgPADIADgBQgIgCgPABQgPABgBACQgBgBATgIQAQgHgiABQgMAAgFAFQgEAGgFABQABgBAAAAQAAAAgBAAQAAAAAAgBQAAAAgBAAQgFAAgEABIgJADQALADAGgDQgBACgLAAQgMgBgDACQAFgDgJgBQgKAAADgBQgagFgXAJQgGgEgNACQgOABgJgBIAMAAQAGgCgJgBQgIgBAHgCQgBAAAAAAQAAAAAAAAQAAAAAAAAQABABAAAAQACABADgBQAPgBgDgDIgRgEIAFgBIgZgGQAAAAAAABQAAAAAAAAQABABAAAAQABABABAAQgRgBgdAAIgsABQgDAGghACQgpABgJADQAFgCABgEQADgEgDgCIAKgDQAIgCAHAAIAHAEQAEACgFABQAQgBgFgDQgJgEADgCIAPACIAigJIgTgDIASAAIAYgBQAAgCgJgBQgKgBgBADQgCgBAJgCQAGgCgIgCQAQgEAmAFIADAGQAGABAFgDQAFgDAIABQgLABADADQADADgHAAQADABABADQACACAKAAQAGgEAHADQAIACAHgDQAAAAABABQAAAAAAAAQAAABAAAAQAAABgBAAQgCACAJABQAMgDADgDQACgBABgGQgJgBgIAEQgJAEgHgBIAcgJQgFgCgFAAQAHgBAFgCIAHgDQgeAAgDgDIADgCQgIgDgLAEIgUACQgKAAgCgCIAGgCIgpABIACgBQg5ANgrgBQAEAEAfAFIgJAFIgFgEIgPAEIAIADQgTABgVAEIgfAGIgBgBIgQACQALABgCADQgBAEgMgCIACgBQgFgBgOAAIgZABIgJAEQgJAAgFgEIgGgIQgOgBgPAEIgXAGIgWgEQgJgCADgBIgRAJQgKAGgVgGIAJgDIg4ADQghACgJgCQAHgGgYgFQgcgHgDgFQABACgGABIgIACQgGgDgHADQAGABgCAFQgCADAOgCQgXANgiAAIABgFIAVACQAAgCAFgBIAKgCQgVgBADgFQACgEgVAAIgEACIgGAAIACgBQgBgCgGAAIgIAEQgIgFAOgBQAMgCgGgDIAcgEQAOgDgDgEQgNgBgMAFQgNAGgOgCIgCgCQgGABgEACIgHAFQgBgDgIAAIgWAGIgVAHQAUgCARADQATACAVgCIgVADQgQADgBADIAAgEQgaAEgSgBIAKgDQgJACgUgDQgRgCgJAEIAHAAIgfAAIgbAIQABgBgIgCQgFgBAEgDQgLgCgLADIgQAEQgKgDALgBQAQgCABgDQgtgDgZAHQAJABgBACQgBgBgRAAIgDADQgOgDAOgDIgQACQgJABgHgDQAKgCAQABQAQAAAEgBQgQABgTgEQgUgFgWACIACgDQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBAAgBAAQgMAAABAEQABAEgCABQASgCANAGIgFADQAAgBgFgBIgHgBIgCAFQAAgEgIgDQgJgCgJABQAIADACACIACAFQgIADgIgCQgJgDgJACIAHgBQAEgCgJgBQgGAAgEACIgHAEQAEgCADgFQAEgEAFgDIAagCIgPgDQAKgBABgDIABgDQgOgDgJAEQgIAFgIgBQgEACAIAAQAHAAgHACQgKAAgCACQgDACgKABIADgCQgDgCgGABIgKACQAAAAgCAIQgCAIgTAAgAIUAtQgLACALAEIATgBQAMAAAAgDIAAABQAIABAFgDQADgDALABQABgDgMAAQgGAEgNABQAAgBAAAAQAAAAABgBQAAAAABAAQABAAACAAQAHAAgFgEQgCgBgOABQgMAAAFgEIAQABQAAgDAGgBQAGgCgBgCIAPAAQAIACAGgDIACgFQABgCALABQAMAHA0gCIAMgDQAAgBgLAAQgJAAAFgCIATgBIgBABQAFABANgDIgMADQgGABABADIAKACIAJAAIgDABQALABAFgDIAGgFQAKgDgMgDQgPgDABgCIA1gCQgJADACACQAFABACACQACABAKAAQgBgEAOgBQATgCAFgBQABAAABABQABAAAAABQABAAAAAAQAAAAgBABIgJAAQAAADAKAAIAPAAIAOgCQgBgBgBAAQAAgBgBAAQAAAAAAgBQABAAAAgBQACgCAJgBIAAgBIgggDQgUgBgIACIADgCQgJgBgYADQgTACgFgEQAAgBAAAAQAAAAgBgBQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIgQACIAEAAIgcAAIABAAIggAIIAAACIgDACIgLABIgJgCIgLgDIAaAAQADgGgPgCQAAAAABAAQABAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQgBAAgBAAIgIACQgGABAEAAIgugBQgegCgVADQAIgCgJgBQgIgCANAAQgLgDgIADQgKAEgKAAQAAgBAGAAQAIgBADgCQgSgBgdAFQgdACgRgBIgBgCIgVACQAKAHALAEQARAFAggBIgDAAQAMADAZgDQAZgEAPADQgOAEgPAIIAQgDQgDAEAIAAIARgBIgKAHQgFgCgKAAIgIAAQgBgBgMgDQgRgDgKABQABACAPACQAMACgJAEQAHgCAHABIANABQgHABAAADQgBADgEACIAVgCIgNADgADxAZQAJAFANAAIAZgDQANgBACgCQABABAIABQALACAGgCQAGgEASgDQANgCgFgBIgOABQgIABgEgDIAQgBIgKgEQAHACgFgJIgTABIACAAIgUAEQAJABADADQACADgLABIgBgCQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQgLgCgKAAQgMgBADAFQAMgDABAEQACAEAHgCQgEADgJAAIgNACQAGgDgFgDQgGgDgKgBQgWAAgKABQACACgBADQAAACAKABQgOACgLgDQALgBAAgBQgEgCgGgBIgJgCIgKAAIACACIgKADQAIgBABACIgDADQABgCgGAAIgJACIAKAFQgCABgIgBQgHgBABACQAVACAhgCIgJgEIAIAAQAHAAAFACgAAPAcQALAAAEgBQACgCAMgDQAKgDABgDQABgBgIgBIgQgBQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAJACgCAEQgHgEgHADQgHAFgHgBQgDADAKABgACjAOQABAAAAABQABAAAAAAQAAABAAAAQAAAAAAABQAIABACgBIACgDgABKAPQASACAVgBIAegKQAUgGAAgBQgCgCgGABIgKAAIACACIhGgDQAmAIAFAEQAFAGgvgBgAg4ANIADgEIgJAAQADADADABgAGHgbQgHgBgNACQgKAAABgDQAEgCALAAQALgBADgCIgKgCQAJgCAGACQAFAEALgCQgBgBgBgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAIABAEgCQgCgBgTgBQgNAAADgFQAFgBATAEQAUADAIgEIgBABQAOABAKgDIAOgEQAFABALgBIAQgCIAAADIAOgBQgEACgIAAIgRgCIABAFQgIgEgKADIgQAHQAFgBAYgBQARAAADgFIAKAEIAEgCQAFADgEADQgEADgLABQgBgBgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgQAFgNgBIAJgCQgjgBgJAHIgCgEQgEgFgHgDQgLADgDACIgFAHIgfAEg");
	this.shape_94.setTransform(-242.4,169.6);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#11AA0C").s().p("AgJgBQAKABAJAAQgJABgDABQAAgCgHgBg");
	this.shape_95.setTransform(-136.4,171.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#11AA0C").s().p("AgIAAIACAAIAOAAQABAAgBAAQAAAAAAABQgBAAAAAAQgBAAgBAAIgNgBg");
	this.shape_96.setTransform(-260.5,171.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#11AA0C").s().p("AAFAEQgNACgCgEQgBgCgPAAIgCAAIAFgCIgRgBIAUgBQABAAABABQAAAAABAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAQABAAABAAIANgBQADgCgIgCIAKABQAKACAFgBQgDACALABQAKABAEAAQgBADgOAAIgXACg");
	this.shape_97.setTransform(-183.7,171);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#11AA0C").s().p("AgGALIAMgDQAEgBgKgCIgggDIAUAAQAKgBAHADIAGgEQgMgBgiABQAWgHAsgEQAHACgEACQgGACAFABQgGgBgFACQgCAAAAAAQgBAAgBABQAAAAAAABQAAAAAAAAQAGABAJgCQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAABABQAAAAABAAIgQABQgKAAAAADQARAAgJADIgOAEQAAgBgGAAg");
	this.shape_98.setTransform(-96.2,167.7);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#11AA0C").s().p("AAsANIgnAAQgEgCAGAAIgjAAQgYAAgKACIgPgBQgJgCAFgCIgLABQAAAAAAAAQAAgBABAAQAAAAABAAQABAAABgBQAFAAAAgBIgFAAIACgFQACgCAPAAQAFABgJABQgKAAADAEQAFAAABgCIACgCQAKAAgBAEQACgBAJAAQAJAAADgCQALAAgCADQgDADAGAAIAIgHIAUABQAQgBgBgFQgCgHATgCQgDADAJAEQAJAEAMABQgdADgNgCQAJADgOAAQgOABADADQAPgFAWADIgEABQAFABANgDQAMgDAKABQAJAAgEAEQAOgCAAABIgGAIIgcABIgPgBg");
	this.shape_99.setTransform(-261.4,175.2);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#11AA0C").s().p("Ag8AAIgdACQAAgEAdABQAiABAJgEIAGADQAEABAHgBQAAgFASAAIAggBQABAAAAABQABAAgBAAQAAAAgBABQgBAAgCAAQgHACAFABIAQgDQAKgBAJACIgCAAQANgBgBADIgDACQgFAAgKAAIgOABQgGADgaACQABgCgGgCQgFgCABAAQgyAAgKABIAHAAQgMAAgCADQgDAEgHAAg");
	this.shape_100.setTransform(-289.4,173.9);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#11AA0C").s().p("AAAAAIAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABg");
	this.shape_101.setTransform(-267.9,173);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#11AA0C").s().p("AicATQgNgBABgEIAKgEQAEgCAKgBQAIAFASgCQAbgDAGABIAGgDQADgBAJgBQgBACgMADQgJABAHAEQALABALgBQAMgBAEgEQgSABACgGQADgEgSABIALgCQAHgCAGgBQAJABgNAEQgKACAYAAIAEgHIAeABQgYACgGADIAfABQAQABABACQARgDAogKQAjgLAYgDQAMABACADQABADgGADQAKAAAFgDIALgFQgJAEABACIAGAEIAKgCIhPAfQgJADgagBQgZgDgGADQAFgDgGgCQgGgCgJAAQgBABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAEACQgwgJgSAKIAKgHQgcADgMAEQABAAABgBQAAAAABAAQAAgBAAAAQAAAAAAAAQgFgDgLADQgMACgEgBIAIgCQABgCgPABQgHAAgFADQgGACAJABIgOgBIADADQgDgDgPgBg");
	this.shape_102.setTransform(-286.3,175.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#11AA0C").s().p("AAAAAIAEAAIgHABQADgBAAAAg");
	this.shape_103.setTransform(-267.7,173.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#11AA0C").s().p("AAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIgBABg");
	this.shape_104.setTransform(-346,167.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#11AA0C").s().p("AgcAGQANgCAEgEQAGgDAEgCIgFAAQgBAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAIAEgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQABABABAAQABAAAAAAQAAABAAAAQAAAAAAAAIAZgEIgFAEIgVAGIgEABIgLAEIgEAAQgGAAgGgCg");
	this.shape_105.setTransform(-247.8,164.7);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#11AA0C").s().p("AgkAHIAkgNIAAAAQgGACAGAEQADABAKgBIgDAAIAIAAQAJgBADABQgGAAAFACIAIADIg2gBQACgCAEAAQgHAAgGADQgFACgFAAIgCAAg");
	this.shape_106.setTransform(-263.5,172.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#11AA0C").s().p("AgdAJQANgCABgCIgJABQgGgBAFgCIAGgDIATACIALgFQgLgDABgBQACgBgDgEQABABASABQAPABAEADIgXAHIAHABQAEgBADgBIAAAIIAEAAIgGACIgEACQgKgDgVAAQgGACgGAAIgQABQgDgCAKgBg");
	this.shape_107.setTransform(-90.6,168.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#11AA0C").s().p("AgYAEQgEgBgFAAIgHAAQANgBAEgDQADgFASAAQgEAAgBACQAKADALgDIgBACIAcgBQgCADgNAAQgNAAgCAAIAQABIgbAEQAIgCgEgCQgEgBgGABQgBAEgDAAIgNACQABAAAAgBQAAAAAAAAQAAAAgBgBQAAAAgBgBg");
	this.shape_108.setTransform(-83,168.6);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#11AA0C").s().p("AgMAAIAQgBQAJABAKAAIgtACQgEgCAOAAg");
	this.shape_109.setTransform(-166.6,173.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#11AA0C").s().p("AgPAAIATAAQAKAAACAAIgWABIgJgBg");
	this.shape_110.setTransform(-125.1,179.6);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#11AA0C").s().p("AhhALIgFgLQgCgFATgEQAggDBCAAQBMABAPgBQgdAHgkADQAFACgFAAIgWACQgLgCAJAAQANgBABgBQgYgBgSACQgTABAEACQAiABgNACQgVACASACQgCADgpABIgOAAQgaAAgEgCg");
	this.shape_111.setTransform(-131.4,177.9);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#11AA0C").s().p("AgQACIgHgEQAYAAAMACQAHAAAEADg");
	this.shape_112.setTransform(-219.5,167);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#11AA0C").s().p("AgMAAIAZAAIgRABQgEgBgEAAg");
	this.shape_113.setTransform(-215.7,167.5);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#11AA0C").s().p("AgMAAIALAAIAOABg");
	this.shape_114.setTransform(-212.9,167.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#11AA0C").s().p("AgdADQANgDAFACQAIACARgBQgQgCACgBQACgDAcgBIgEAIIgjABQgTAAgBgCg");
	this.shape_115.setTransform(-245.8,167.5);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#11AA0C").s().p("AACAAQgMgBgeACIAFgCIBMgBIgwAFg");
	this.shape_116.setTransform(-252.7,167.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#11AA0C").s().p("AgyAFIgJgDQAyACAQgCQAfgCATgBQgQgDg6AAQhAAAgYAEIAhAAIgiAFQgIAAAAgBIAAgBQgIADgtAAIhggBQASgCgSgDQgQgCAagCIETgBIANgBIgHABIBSgBQAXABAJADQAGACAoAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQgBAAgCgBIgOgDIA4AAIgEABIAtgCQAMADgwADIgTAAQgCABAdACQg+ADhZAAIiTACQAMgBgDgCg");
	this.shape_117.setTransform(-178.4,167.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#11AA0C").s().p("AgUABIAUgBQAVAAAAABg");
	this.shape_118.setTransform(-59.1,165.8);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#11AA0C").s().p("AgmAAQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAIBNAAIgUABQgNABAMABIg+AAIADgCg");
	this.shape_119.setTransform(-53.3,166.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#11AA0C").s().p("AikAIQgVAFgQgCQgWgDgcABIAFAAQgaAAAAgBQAFgDABgCQgeAAgnAFQgkAFghgCQACgBgKgDQgIgDADgBQAfADAbgDQAFgDgfAAQgZAAAUgCIhJgDIH/gBQgBAAAAAAQABAAAAgBQABAAABAAQABAAABAAIAKABIB2AAQgDgCAaAAIAlgBQgVABADACIAtgBIBHAAQAuAAgMgFIAlACQAbACAUgBIADACIAGAAIgOACIgWADQgEACASAAIhCAAQghAAACADQARADAWABQgfAAgoACQglACgeAAIBEgGQAogEgkgBIgrAGQgLgBAKgCIATgCQgDgBgcAAQgdAAgJAAIATACQALABgSACIh0AHIAIgBIACgDQgLAAgVADQgSACgUgCIAvgFQg+gChcAFIACAAQhjABgWADg");
	this.shape_120.setTransform(-107.7,166.7);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#11AA0C").s().p("AgNACIAegCQgMgBgOABQgIAAgHgBIAwAAQAGABgOAAQgMACgMAAIgFAAg");
	this.shape_121.setTransform(70.9,176.8);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#11AA0C").s().p("AgWAAQgCAAAWAAQATAAAGAAIgZABIgUgBg");
	this.shape_122.setTransform(122.3,173.2);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#11AA0C").s().p("AgLAAQAAAAABAAQAAAAAAAAQgBAAAAAAQgBAAgBAAIAbAAIgVAAIgEABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBg");
	this.shape_123.setTransform(81,165.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#11AA0C").s().p("Ag5AEQgDgDAwgBIBGgDIgzADIAMABQgLACgUABIgQAAIgdAAg");
	this.shape_124.setTransform(140.5,176.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#11AA0C").s().p("AAJACQgMgCgVAAQAYAAgJgDQgIgDAoACQgfACATACQAXAEgQACQAEgBgNgDg");
	this.shape_125.setTransform(162.7,176.1);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#11AA0C").s().p("AAAAAQgGgBgIAAQAdgBAAACQgBAAgOACQAEgCgEAAg");
	this.shape_126.setTransform(132.2,167.4);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#11AA0C").s().p("AgVAAQAJgBAMABIAWABIgPAAQgZAAgDgBg");
	this.shape_127.setTransform(164,172.1);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#11AA0C").s().p("AgDADQADgDg6gBQA6gBA7ABQgIAAgRACQgLACgTAAIgHAAg");
	this.shape_128.setTransform(156.8,166.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#11AA0C").s().p("AgFAAIgNAAQgGAAAhAAIALgBIgJABQgDAAgJAAIgLACIAHgCg");
	this.shape_129.setTransform(211.4,172.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#11AA0C").s().p("AABAAIgSAAQATAAAQAAIgKAAIgHAAg");
	this.shape_130.setTransform(227.1,172.8);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#11AA0C").s().p("AgEAAQAOAAABAAIAEAAQAAABgUAAQgTgBAUAAg");
	this.shape_131.setTransform(262.5,175.9);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#11AA0C").s().p("AgUAAIApAAIgOABg");
	this.shape_132.setTransform(311.6,176.9);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#11AA0C").s().p("AgHAAQAXgBgFgDIATAEQgUAAgIACQgIACgWABQgEgCAZgDg");
	this.shape_133.setTransform(281.6,167.4);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#11AA0C").s().p("AhcAAQAkACA0gDQA1gEAsADQglABgrABIhNAFg");
	this.shape_134.setTransform(287,168.7);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#11AA0C").s().p("Ag7AFQAHgEAjgBQAbAAgGgEQAnAAARADQgUAAglADQgbADgbAAIgIAAg");
	this.shape_135.setTransform(436.7,174.2);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#11AA0C").s().p("AgRAAIAjAAIgLAAIgDABg");
	this.shape_136.setTransform(426.5,171.3);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#11AA0C").s().p("AgEAAQAYAAgBgBQAEABgPAAIgYACQgJgCAVAAg");
	this.shape_137.setTransform(425,170.9);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#11AA0C").s().p("AkCA8IBUgmQiUAAiNgEQgOgEAogCQAqgCgCgBIAuABQgBABgrACQgiABAXADIBkgBQAygBAugEQgMgEg2ACQg/ABgYgDQAWABAjgCIiXgDIgNABIA4ACQgeAAgYACQgbADgCAEIAIAAIgRACIguAAIAHgBIgugBIAEgBIgLAAIg5AFIg0AEQgtADgcgBQAqAAgIgCIgwgFQgdgCgmADIAkAAIhRAJQgQgCAagCIAqgDQgfACg3gDQgsgDgPAEQgMgMgpABQAPACgNACQgPACANACQgHABgWAAQgOgBgFABIADgBQgsgEgiAEQgfAGgPACQgwABg2gBIhbgBQgDgDgMgDQgQgEgTAAQgFABgmAEQgiADgEADQAdABAOgDQARgDAKgBQAKACAFADQADACASACIhMAAQg7AAgRgDIAKAAIg4gIQgggEgwAEIgmADIADgBQgWAAgggDQgTgCgjACIACAAQgYgCghACIgzAEQgLgDAIgBIATgDQhRgChpAMIgsgCQAVgBASgDQARgDgGgCIgXACIgfAAIAlgIQgmgDgDAFQgCADgWgEQgiAAgEAHIgpgEQgDADgeABIg2ABQgDABARACQAQABAJgBQgBACgWABIglABQgEgEhFABQg8AAANgFQjyADhDAEIgmgCQgSgCARgCQglAAhBAEQg6ADgsgBIAQgBQATAAgBgCQgbACgygCQg5gCgmABQAJgBAGgCIg3AEQgBAAgBAAQAAAAAAAAQAAAAACAAQABgBACAAQAKAAgDgBQhYgCiCAFQiJAEhCABQAUgBAOgCQAOgDAAgCIgsAAQgIABgaABIgqADIgJgCQAAAAgBgBQAAAAABAAQAAAAACgBQABAAACAAQgtgDhEAGQhNAGgzgBICBgMIghgEIA5gFQgRgCgbACQgVACgCgCQAYgBAAgCQgSgBgOABIgbACQApgEBXgCICCgDQAKgBgVAEIAlABQAXABATgBQAOgCgRgBIgeAAQACgDAbgBQACACA4ABQA7ABANADQA0gBgKgFQgIgEAxABIAeAFQBxgIBUABIgNABQgGABAHABIALACQAXABAvgBQAngCAQADQA+gGCYgGQAKAEgxACQhAACgIACIA0AAQggAAghAGQAdABAegDIA6gEQgGADAfAAIAGgFQABABAJAAIBWgCIgSgEQgKgCgNAAQANAEgugBQAKgCgOAAQgSgCAAgBQBWAAAsgBIAKAEIA/AAIA2gBIgJADIBLAAQAuAAAaACIBJgHQAvgDAVgDQAJgCBIACQBNADAcgEIgTACIgiAEQAOAAAfgCQAVgBAHADQgrgBALACQAPAEgOAAQBCAAAZgDQgdAAAKgDQAKgDgdABQBOgHBVADQAAADAbABIAQgDQAKAAgSACQgTACAdABQAWgCBRAAQBDAAANgGQASACghADQgiACAhADQgQACgpAAQggAAgHADQATgBAEACQADADAJAAIAngDIgJAAQAogDBPgBICEAAIBggJQA3gEA0AAQgKACAdACQAbACgdADQAbACAagBQAYgCABgCIgpgCQAOgCAcAAQAZAAAPABIgFABIgCABQAYABAFgCQAJgDAMAAQAFACAiAAIA1ABIAngGQgKACAWABQAdAAADACIAqgFQAagCAbABQgJABAVABQAbACAAACQAkACA9gFQA6gFAkADIgGACQgDACANAAIA9gBIgBABIACgBQANAAAAgBIApgGQAZgDAkgCQgGgGhEAFIgSAEQgKgDgYABIgfABQAUgEBEgCQBWgDATgBQgvgIiJACIAeACIgkAAIAjAFIhSAAQAQAAAIADQAMADgTgBQgXgCgQACQgWACgLAAIAYABQAKABgJABQgdgCgogBQgjgBgdgDQADAEgkAAQgoAAgFADIAaAAIg2AFQgYgDASgDQAOgCgogCQgngBgdAEQghAEgXAAQAggIBLAAIgbgCQAQgDBbACIgRACIAMAAQAqABAKACQABgBgJgDQgEgBAWgCIhMgBQArAAAngGQAogGArABQgYABARADIAaAEIBJgDIgPgFQAXgCAmAFQAjADAggDQAEgCgaAAIgTAAQAvgCAuAFIBXAIIAGgEQAGgDAPgCQAAAAAAAAQAAABgBAAQAAABAAABQAAAAAAABQAAACgQACQAUABA1gEQgegBAWgCIAmgEQAjABg7AEIAfADQATABAGgDQABACghAEQgiADgdABIAZABQgNABghAAQARACADACQACACgGADQgBAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgaAAQgJABADABQgLADAUABIAhACIAggBIBrgQQAcgBAaABIAuAEIAJgEQBOABgcAGQgBgBgOAAIgIACIBIgDQgqAEAMAEQARAGgDACIBIgDQgbgBANgCIAegCQACADAggBIAygBIgCABQAhACA+gCQgCgCA5gLQgggBACgCQAHgCgCgBQANABADgBQABgBAAAAQAAAAAAAAQAAAAgBgBQgBAAgCAAIgJgBIhNADQgoABgOAEQAIACAOgCQAQgBAJABQgSACgcABIg8AAIgOgEIgtACIAQgEQAKgCAcAAQgEgCgaABIguAAIgOAFQACgBgXgCQgRgCAZgCIBHgEIgTgDIA9gBIgPADQAwgCAPAEQANAEAygDQAogHBUACQgYABAEACQAFADgFACQAbABAVgCIAigEQAKADgCABQgCACgbgBQgCADAaAAQAegBACAEQA2AABCgKQA2gIBUAFIgGACQA2gCBHAAQBSABAlgBIBGAHQgRABgQADQgRACAKACQgUgDgggBIg3gDQgCABAIABIAMACQghgDgeABIAPACQAJACgPAAIgogEQgXABgSAEQgPAEghgBQAZgJAjgBQgMAAARgCQAWgBgPgCQgXADgfABQgoAAgXABIAVgCIhQgCQAKABgjACQgmADAEACIBLABQAfgBA0ACQgvABggAJIgGAAQgIADACADQAGAGAAACQAYgDAlAAQAsAAAWgBQAHgDgWgCQgTgBgWABIAugDIgJACIB1ACQgLAAgfAFIAvACQgGgHATAAQBhABAxAJIAJAAQgIgDAhgEIA0gGQgBADAWAAIAnACQAHgDgDgDQBsADB1gBIAggMQATgHAGgFQBkgEA5AEIgEACQAbACAcgCQAMABgJACQgJACAGABIBGgDQgIAEhRAAIAIgBQABAAABAAQABAAABAAQAAAAAAgBQAAAAgBAAQgLAAgxACQgnABgHgDQgCAAAAAAQgBAAAAAAQgBAAAAAAQABgBAAAAIAGgBQAHgDggAAQgkgCgPAHIAZADQAWACgKABIAigBQATgBAVABQhBAFgPgEQglADgDAHQgDAGAXAAQgDgBApgDQAegCgpgCQATgDAsgCIBGgDIgCABIA0gBQgXADgBACIBGgHQgUADAWABIAsABIgDACQANAEA5gBQBIgCATABQgOAAgEACQAkABAsgCIgEgBQAbgCAIACQAOAFAGABQAxAAgGgDIAxAEIgDgFIAfABQANABAPgCIACgFIhGgBQASgBAGgCQAFgCAUgBQgYADAYABQAgABACACIAcgDIgHACQAMABANgBQAPgCAMABIgpgEQgXgBgZACQAjgDA/gDQARgBAXABIAlACQgTABgEAHQgEAFg8gCQADgBAKABQgJgEgeACIgvAFQADACgFACQAAABAZABQgMgCAdgCQAdgDAbACIgHAHIA5ABIgGAAQAMADAggBQAngBARABIBJgCQAtgBgcgFQAVADAegCIA1gDIgwgDIAvgEIAngGIAIADQACABgFABIB9ABQBLAAAcgEQASAAAqAEQAhADAsgCQACAAAEgDQACgDAdABIgQADQgKADAigBQATgCAvABQAzACAagDIAuACQAYACgGACIhFAAQglABgHABQADgBgMgBQgHgBASgBQgigCgTABQgUACgcgBQgCABARACQATABAIgBQABADgzACQgoACAcAEQAbAAArgFQAjgFAdAEQgIABgfABQgcABgPAEIAsACIAfgEIgCABQAtADAdgFQAtgHAYgBQgWgCAHgFQAIgFgOgBQBRgBAAAHQgtADAAADQgCAEgnADQACAAgBAFQAAAEAcAAQAcgCgJgCQgHgCAagBQACAAABABQABAAAAAAQABAAAAABQAAAAgBAAQAMgBAQAAQAQABAQgCIgHABQASACATgCQATgCAQACQgIgDAQgBIAhgDIgtgEQgfgEglABIgIAEQgFACgRABIApgBIgYADIgogCQAegCAGgDQAJgEAEgBQAaABAPgBIAbAAQgCADA0AEIBcAFIgYAAQgYACAXACIAcACIAXgCIgBAAQgCABAIAAQATAAASgDQASgDATgBQABABgMAEQgIADAOABQAeAJA2gCQADgCAdgBIgGABIAiADQgPACgcgBQgdgBgPADIgCAEQgqAAgZAEIAnAAIAogBQAEABgNABIgQACIAGgDQgZAAghABQgpADgaAAIgEgBIACgBQgVACgvAAQgsAAgXADIAPgDIiWALIAAACQAFABgMAAIgUgBIhSAGIAcADQADgBAfgBQAagBgEgDQAOACAfgBIAkgBQgPgBASgCIAegDQAFABAXAAQATAAgBACQgRgCgOACQgSACAfACQAeABgXACQAagBBDgBQBAgBAfgCIgfgCIA0AAQAiABADABIhBABQgBADAdgBQAfAAACABIBHgIIggAAQANgCArABIBNACQgQADglAAQgzgBgTABQgTABAMADQAMADgRAAIAUABQAOAAAJgBIANABQgQADgzACQg7ACgUADIAJgCQgugDg9ACQANABAXgBIgsAEQASABAAABQAAACAIAAQgcACgjgCQgHgBAHgBQAJgCgBgBQgKAAgYgCQgWgCgVACQAgAAgWADIgpAFIAIAAQgaAFgPgEIAbgBQAMgBgEgCIgrABIAOgCIhFAAQggAJgHADQgNgCgqADIAHgCQgWgCgnACQgmABgFACQgDgBA0gIQAqgHhbABQghAAgMAFQgNAGgMABQABgBAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQgPAAgMACIgWACQAeADAPgDQgFACgcAAQgfAAgKABQAPgDgbgBQgYAAAGgBQgigCgoACQgiABgYAEQgSgEgfABQgqACgZgBIAkAAQAQgCgbgCQgXgBAagCQgCAAgCABQgBAAAAAAQgBAAABAAQAAABABAAQAGABAIgBQAmgBgHgDIgugEIARgBIhGgGQgBABAJACQgtgBhQAAIh2ABQgHAHhcABQhtACgXADQAMgDAFgEQAFgDgHgCIAbgDQAXgCASAAIATADQALACgOACQAtgBgRgDQgYgEAKgCQg1AAg5AFIhWAGIgCgCIgqADQAcABgEADQgEAEgggCIAGgBQgOgBgnAAIhAABIgbAEQgZAAgMgEQgKgGgHgCQgnAAgnADIg/AGIg6gDQgjgCAdgDQgMABgrAJQgdAHg5gGIAZgDIiXADQhYADgZgCQASgGhBgGQhLgGgJgFQADADgmACQgTgDgOADQAOABgEAFQgFADAmgCQg/ANhcAAIABgFIA9ACQgEgCAPgBIAagCQg4gBAHgFQAHgEg5AAIgKACIgRAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBgBAAQAAgCgQAAIgWAEQgVgEAkgCQAggCgOgCIBKgFQAogDgIgEQgkgBghAFQgiAGglgCIgJgCQgPABgMADIgSAEQgCgCgXgBIg6AHQgiADgXAEQA4gCAuACQAoACAtgBQhOADgFAGIABgFQhIAFgvgBIAcgDQgaABg2gCQgrgDgbAFIAUAAQgfABg1gBIhHAIQABgBgUgCQgPgBAMgCQgfgCgeACIgsAEQgRgBADgBIASgBQAsgCADgDQh0gDhJAHQAWABgBACIgvgCIgLADQgUgBABgCQAAgBATgCIgqACQgaACgPgDQAYgCAtAAQAsABAJgBQgqABg1gEQg0gFg9ACIAGgCQADgCgNAAQgfABACADQADAFgFABQAcgCAUABIAiAEIgKADQgBgBgOgBIgUgBIgFAFQACgEgYgCQgYgDgYACQAWACAEACQACABAFAFQgWADgZgDQgagDgZADIAUgCQAMgBgXgBQgRgBgLADIgUADQAMgCAKgEQAJgEANgDQAdAAAsgCIgrgEQAdgBAEgCQADgCAAgCQgqgDgXAEQgZAFgUAAQgMABAWABQAUAAgVACQgYgBgFACQgJADgbABIAKgDQgLgBgPABIgaACQgHAAABADIgBAFQgEAIg0AAQAGgCAAgBgAWeAqQgeACAcADIAzgBQAiAAABgDIABACQAUAAANgDQALgDAcACQABgFgdABIgUADQgNACgTAAQgGgBARgBQASAAgMgEQgEgBgpABQgfAAANgEIArABQAAgCARgCQAPgCgBgCQALgBAcACQAYABAPgDQAGgBAAgEQADgCAbABQAnAICHgDIAigDQgCgCgcAAQgYAAALgCIA0gBIgDACIAaAAIAYgCIgfACQgUACAFACIAaACIAZAAIgJACQAfABANgDIARgFQAbgEghgCQgpgDADgCICRgDQgZADAFACQAOABAGACQACABAcAAQgBgEAkgBQA0gCAMgBQANACgCABIgcAAQAEADAbAAIAnAAIAmgDQgZgDAxgDIABgBIhZgBQg2gBgUABIAJgBQgbgBg/ACQgzACgPgDQAAgBgGgBQgGgBAAgCIgsADIAKgCIhLABIACgBIhVAJIAAACIgJACQgPACgOgBIg1gFIBFAAQAKgFgsgDQALAAACgBQACgBgNgBIgVACQgRABAKACIh8gCQhPgDg4ADQASgBgXgCIgNgBIAbgBQgegDgWAEQgcAEgZAAQgCgBASAAQAVgBAHgCQgwgBhOAEQhPAFgsgBIgFgEIg4ACQAaAHAfAEQAuAFBYgBIgKAAQAfADBFgEQBFgEApAEQgoAEgoAIIAqgDQgHADAWAAIAvAAIgcAGQgOgBgagBIgXABQgBgBgigDQgsgDgbABQACABAoADQAfABgVAEQARgBASABIAlAAQgSACgCADQgCADgMABIA6gBIgjADgEAlTAAaQAHABAWABIAlACIAogDQAogEAMgCIgrgCQAhABBJgDQAAgCgagBQgagBgFADQgCgBAWgCQAQgCgUgCQAtgDBlAEIAGAGQAQABAOgDQANgDAXABQgcABAIADQAHADgTAAQAGABAEADQAGACAZAAQARgEAWACQAWADAPgDQAKABgIACQgGACAYAAQAggCAKgDQAEgCADgFQgYgBgYAEQgXADgSAAIBLgKQgNgBgMAAQAQgBAOgDIASgCQhSgBgEgCIAFgCQgKAAgRAAQgOAAgJABIg1ACQgaAAgGgCIAOgBIhuAAIAIAAQiaANh2gBQAMAEBSAEIgYAFIgOgEgAKMAXQAYAFAjgBIBBgCQAmgBAGgDQADABAVACQAeABARgCQAOgDAwgDQAjgDgMgBQg0ADgTgEIAsgBIgdgDQATABgMgJIg1ACIAFAAIg1ADQAcACAFADQAHACgfACQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAgBgBQgCgBAKgBQgdgDgcAAQgiAAALAEQAfgDAEAFQADAEAWgCQgPADgWAAIgjABQARgCgQgDQgOgDgegBQg6AAgaABQAFACgDADQACACAZABQgkACgfgCIATgCQAKAAgBgBQgKgCgRgBIgXgCIgbABIAHABIgeADQAZgBgBACQAAABgGADQABgDgPAAIgaACIAfAFQgHABgYgBQgRgBAEACQA5ACBYgCIgYgEIATAAQAVAAAOACgAArAbQAaAAAMgBQAGgCAggDQAcgDACgDQADgBgXgBIgpgBQgBABgIABQAaACgHAEQgVgEgPAEQgVAEgSgBQgJADAdABgAG5ANQAIABgEABQAYABAEgBQAEgBACgCgAFDAIQAPAFh9AAIgMABQAfACBKgBIBPgLIA3gHQgHgBgOAAIgcABIAIACIi+gDQBnAIALAEgAiaANIAIgEIgYgBQAGAEAKABgAQfgeQgQgBgnACQgXAAACgDQAKgBAdgBQAdgBAKgCIgbgCQAYgCANACQARAEAcgCQgKgDAIAAQAWABALgCQgHgBgyAAQgmgBAKgEQAMgCA3AEQA0ADAWgEIgCABQAmAAAagCIAlgFQAQACAfgBIAEAEQgYgDgZADIgsAHQAOgCBAAAQAwgBAGgFIAaAFIAMgCQAPACgMADQgNAEgcAAQgKgBACgBIgdADQgUACgcgBIAXgCQheAAgaAFIgEgDQgJgFgVgDQgfADgGACQgDADgNAEIhSAEgAfhgjQgIgBAfgDQAggDAZABQgJgGgtAEQgrACgCgFQgvgBgiAEQgeAFgpgEQgBADgMABIgLABIARgFQAJgCgRgBQgQgCgHACQgLACgMAAIAogGIADABIAYgFQAaABgKAEQgGAEAjgCIgJgHIB/AEQBNADAhgCQgNADgCAEQgBAEAPACQgcgBhPABgABrgqIAAAAgAVtgyIgmgBIAigCIAAACIAmgBQgJACgRAAIgIAAg");
	this.shape_138.setTransform(36.2,171.6);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#11AA0C").s().p("AgaAAQAdAAAYAAIgjABQgDgBgPAAg");
	this.shape_139.setTransform(322.5,172.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#11AA0C").s().p("AAAABQgVgBgCAAIAGAAIApAAQAAABgQAAIgIAAg");
	this.shape_140.setTransform(-12.6,173.5);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#11AA0C").s().p("AAPAEQgoACgEgEQgEgCgoAAIgFABIAPgDIgxgBIA4AAQAKAAgEACQgDABANAAIAjgBQAKgCgXgBIAeABIAnAAQgGACAdABIAnABQgFADglAAIg+ACg");
	this.shape_141.setTransform(194.6,172.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#11AA0C").s().p("AgSALIAkgCQAKgCgcgDIhYgCIA1AAQAcgBAWACIAPgDQgagBhkABQAmgEAugCQAggDBCgCQATACgNACQgOACAMABQgRgBgNACQgOAAAFACQAPABAZgDQACABgHACQgGABAIAAIgqABQgbgBgCAEQAwABgbACIgmAEQgEgBgOAAg");
	this.shape_142.setTransform(430.8,168.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#11AA0C").s().p("AgKAAQAQgBAEABQAEAAgLACQAEgBgRgBg");
	this.shape_143.setTransform(285.4,169.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#11AA0C").s().p("AjSAMQgXgCAMgBIgeABQgCgBANgBQANAAAAgBIgOAAQAIgBgBgFQAFgCApAAQANACgZAAQgbABAHAEQAOAAAFgCIADgCQAdAAgDAEQAFgBAYAAQAZAAAIgCQAegBgHADQgGADAQAAIAVgHIA5ABQAqgBgDgFQgDgHAzgCQgJADAXAEQAYAEAjABIg2ABQgnABgVgBQAYADglAAQgqABAMADQAngEA7ACIgKABQANAAAkgDQAggCAaABQAQAAACABQABAAAAABQAAAAgBAAQAAAAgBABQgBAAgBABQAmgCAAABIgRAIQg4ABg7gBIhqAAQgEgBAOgBQiWgBgsAEIgogCg");
	this.shape_144.setTransform(-15,177.1);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#11AA0C").s().p("AikAAIhOACQAAgEBNABQBbABAZgEQAWAEAZgBQgCgFA0AAIBYgBQAJABgRABQgTACAMABIAtgDQAagBAYABIgHACQAmgCgEACQgJADACAAIgqAAIgmAAQgMADgZACIgxABQAEgCgQgCQgPgCADAAIhUAAQg2AAgaABIANAAQgcABgGADQgGADgTAAg");
	this.shape_145.setTransform(-90.6,176);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#11AA0C").s().p("AgDABIADgBQABAAABAAQABAAAAAAQABAAAAAAQAAAAgBABg");
	this.shape_146.setTransform(-32.6,175);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#11AA0C").s().p("AmAAWQgBAAAAAAQAAAAABAAQAAABABAAQABAAABAAIgrgCQgkgCADgDIAagEQANgDAbAAQAUAEAzgBIBZgDIAPgDQAIgCAYAAQgDACgiADQgXACAUADQAdACAdgBQAigCAJgEQgwABAHgGQAGgEgvAAIAcgBQASgCATgBQAWABghADQgdAEBBgBIALgHIBTABQhBACgQADIBSAAQAwABADADQAugEBrgKQBcgLBDgDQAhAAAEAEQAEAEgSACQAdAAANgDIAdgFQgXAEABABIASAFIAZgBIjVAeQgZAEhEgCQhEgCgPACQAMgCgQgCQgQgDgaABQgEABAQACQiDgIgyAKIAbgHIg9ADIgtAEQAJgBgCgBQgPgCgeACQgfACgMgBIAVgCQAHgCgtABQgTABgNACQgPADAXABg");
	this.shape_147.setTransform(-82.3,177.2);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#11AA0C").s().p("AAnAAIgVABIg4AAIBNgBg");
	this.shape_148.setTransform(-23.1,173.5);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#11AA0C").s().p("AAAAAIALAAIgVABQAKgBAAAAg");
	this.shape_149.setTransform(-32.2,175.3);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#11AA0C").s().p("AAAAAQAHAAgEAAIgGAAg");
	this.shape_150.setTransform(-243.5,170.3);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#11AA0C").s().p("AhPAHQAjgDALgDQATgEAJgCIgOAAIAVgCQgFACAIAAQALABgEABIBEgEIgNAEIg5AGIgQABIgeAEIgPAAIgcgBg");
	this.shape_151.setTransform(21.4,166.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#11AA0C").s().p("AhlAHIBigNIADAAQgTACAPADQANACAagBIgIAAQAGAAASAAQAWgBAJABQgRAAAPABIAWADIiYAAQAFgCAKAAQgSAAgPADQgNACgOAAIgGAAg");
	this.shape_152.setTransform(-20.8,174.4);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#11AA0C").s().p("AhRAJQAigCADgCIgYABQgQgBAMgCQARgCAAgBIA3ABIAfgFQgfgCACgBQAGgCgLgCQAGABAwAAQApAAALAEIhAAHQAeAAAIgBIACAIIAJgBIgOACQgHACgGAAQglgCgwgBQgRADgPAAIgtABQgIgCAcgBg");
	this.shape_153.setTransform(446.1,169.2);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#11AA0C").s().p("AhEAEQgLgBgNABIgTgBQAkgBAJgDQAIgFAvAAIgJABIgDACQAhADAdgEIgEACIBNAAQgHACgiAAQgjAAgFAAIArABIhIAEQAVgCgNgCQgLgBgSABQgDAEgHAAIgjACQAHgBgLgCg");
	this.shape_154.setTransform(466.5,169.6);

	this.addChild(this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.instance_2,this.instance_1,this.instance,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-389.7,-177.2,867.6,357);


(lib.jabalina2 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AArL+QgbgCgQgJQgDgCgCgGIgEgKQgQgNgHgIQgBgGAFgNIAGgTQADgLAGgFQACgMABgRIABgcIABgbIADgQIABgMQABgKAJgcIAJgTIAVgpQACgIABgQIACgYQgEgQgBgKIgGgZQgDgMABgRIABgfIgIgBIgIgBQAFgOABgIQAGgTAUgyQARgrAHgcQACgFACgCIADgJQACgGAAgEIAEgJIAEgKIgEgfIgFgfQgCgOgKgMIgTgXQgZgdgLgQIgVgMIgOADIgPADQgBAAAAAAQAAABgBAAQAAAAgBAAQAAABAAAAQgbAFg0gDIgeAIIgKgCIgFgMQgDgHgFgDQgBgEgEgFIgHgJQgHgSgCgKIgFgIQgEgOgJgTIgPgfIghg6IgJgFQgEgBgMgBQgLAAgEgCQgQAIgVAQIghAaIhWBAIB3hbQgKgNgDgJIgVAQIgVAPIgpAgIhTBAIgpAgIgqAfIgVAQIgUAQQgZAYgGARQAGADAGgEIALgGIA7gpQgTAUgUAKIgUAOQgQAKgJgCQgBgHAEgHIAJgLQAKgOAIgGQAXgVApgfIBCgyQBghIBPg+IgFgKQgEgDAAgCQAAgEAHgEQAJgEABgDQAIgCAMgHQACgBAAgEIARgDQAAgBABAAQAAAAAAgBQAAgBAAAAQAAgBAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAOAAAGADIF2kfQBShCAsgdQApgZAUgKQAQgIAGABQAAAGgGAFIgIAJIgSASQhXBEixCHIjGCYIghAaQgVAPgLAMIAHADIASAXIABAFQAOAcAdAgIAaAaIAYAcQAGAOAAAFQAqgPAkACIAPgMIAQgMQAHgFANgDIAYgDIAKgHQAHgEACgFIgHgRIgHgRQgWgTgHgEQgKAIgOgEQgPgFgDgNQABgIgDgJQgBAAAAAAQgBAAAAABQgBAAAAABQAAAAgBABQAAABgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgDgFgDgPQAAAAgBAAQAAAAAAABQgBAAAAABQgBAAAAABQgBABAAABQgBAAAAAAQgBABgBAAQAAgBgBAAQgBgPACgGQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAgBAAAAQADgcAMgRIAAgCQgBgBAAAAQAAAAAAgBQAAAAAAAAQAAgBABAAQAPgWAJgJQAKgIAZgOIAIgEQAEgCAEABQAAgBAAAAQAAgBgBAAQAAAAgBgBQAAAAgBgBQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAgBAAAAQATAAAFANQAEABAFAEQAFgCAGAAQAHABADADIAEABQABAAABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQABAAgBAAQAAABAAAAQgBAAAAAAIgEAAQABAEAFADQABAGAEAFIAGAIQgCAIAFAIIAAAGIAEANIADAGIAHAWIAIAVQABAFgCAJIAAAMIAEAMIAFALQAFgBAGgFQADgFAFgFIAJgJQAEgBAJgGIAXgHQALgDAJgHIAPgPIATgTQAvgcAdgHIALgGIAMgNQAHgQARgRQAOgNASgLIAWgOQAOgJAJgEQAbgLAfgZQASgTAJgIQAQgPAPgIIASAAIAigKIAEgCQADgCACABQADADgBAFQgBAGgDABQADABAHgBQAHgBADABQgCAMgNAEIgbADIABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQgEAGgEARQAGAEABACQAEAFgBAHQgEAGgIAAIgQgBQgEACgHAHQgHAIgEACIgFACIgEABQgfAHgJAJQgfAfgIALIgTAWQgLANgJAHQgHAKgYARQgTAJgRAPIgCADIAAADIgXAZQgOAQgJAJQgOAMghAVQgKAWAFAhIACAsQABAZAEASIAFAlQADAXAEAMQALAeACAiQAAACADACQgBAEABAGIAFALIAEAFIACAGQArAvBEBkIAGAHQgBAEgGAFIATAiQAKAVAFAQQAGATAEAGQADANALAUIAIAJQgBADABAFQABAFgBAEQAFAJAJAfIAPBAQAKAqAHAYQABAMAKAbQAAARAKAeQAEgIAIAAQACACABAFIABAIIAGAEQAEACABADIAGABQAEAAACgBIAFAGQADADADABIABACIABAAQgIALgCAFQAAAFAFAAQgBABgEABIgFgFQgDgEgEAAIgEACQAAAAgBAAQAAAAgBABQgBAAAAAAQgBAAAAAAIgCgHQgCgEgDgBQgJAEgDgCQgCgEADgGQgEgEgBgEQgKAEgQgBQgPgBgKgEIgHACIgFAVQgCANACAKQANAGAdAAIAwAAQAGACANAAIASACQAfABAbgGQgQgTgNgDQgFgBgDACIgGAFQgGADgJgBIgQgDIAHgLQAEgHgBgGIAAgBIAAAAIgBgBIACAAQACABABAGQAGAGAQADQARADAGAEQAJAFAKAPQABAEgBAIIgHAEQgjAHgWgCIgmgEQgKgBgUABQgUAAgKgBQgUgBgLgEQgEgRADgTQADgSAIgMIgCgMQgCgIABgFIgIgWQgEgNgEgHIgBgFQgGgMgKgNIgTgWIgLgVQgHgMgEgKQgDgIgDgQQgCgSgCgHQABgGgEgMIAAgFIgEgJQgCgGACgEQgBgGgGgPQgLgQgWgSIgkgfQgBAAAAAAQAAAAAAAAQgBAAAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAgBAAAAQgng5gjgXQgPgOgHgJQgDgEgEABQgBgEgCgCQgIAAgHAFIgIAZQgFAPgFAHQgKAzgFALIgFgBIgFgCQgCADgCAHQAAAVgFAiQgCAFgEASQgLAagNAZQABADgCADIgCAFQABAVgGAeQgNASgHAQQgFAIgRAmQgDAJgJAXQgIAUgDANQABAFAHAIQgCAPANALQAOACAIAHQAFAGAGASIAGAIQACAJgMAHQgOAIgXAAIgJAAgAAELpQgBAGAGADIAMADQAYAEAZABQARgDAJgMIAAgFQAAgBAAgBQAAAAAAgBQgBAAAAAAQgBgBAAAAIgBAAQgQALgLABIgVACQgHAAgIgCIgOgCQgHgDgEAAIgBAAgAADLYIABALQAdAKAmgDQANgFAHgGQgEgYgYgHQgMAAgNAEIgVAJQAAgBAAAAQAAgBgBAAQAAAAAAAAQgBAAAAABIgDABIgBgBIAEgEIADgEQAAgEgDgCQgEgDgBgCQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIABgCIgCgEIAAgJQgHAAgFgDIgMgGQgIAJgEAdIAOAFIAGAIQAEAFACABQAFAAAFgFQgDAGgEABgAgcLHIAAADQABABAHADIALALQABAFAFACQAEADABgFQAAgDgCgCIgEgDQgIgLgGgDQgCABgDgCIgDAAIgCAAgAJBLUQAHAAAQAEQAWABAdgEIAMAAQAHgBABgGQgCgEgGAAIgLABQghAEgMgBIgqgDIgggBIgggBIgLgDQgIAAABAFQABAEAIABIAKABQANADAXgBIAnABgAAkK8QgMADgBAGQAEABAGgDIALgDIAHAAQAEgBAAgDQgDgCgFAAQgFAAgGACgAAbK3QgGABgCAEIABAEIAKgFIALgFQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBAAAAAAIgMACgAAnKsIgOADQgIACgDAEQAFABAIgCIANgCQAHAAABgCQAAgBAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAIgFgBQAHgBgCgGQgCgGgGgBQgKgCgIAGQgIAHAEAJIAMgEIAIgBIAEAAgAJcKvQASAGAEgHQgDAAgGgDIgIgEIgFAIgAJMKYQgIAGgHANIACACQAGgBAEgIIAGgLIgCgCIgBABgAJMKjIgDAGQAFACADAAIAGgKIgHgDIgEAFgAI3KRIgFAEIgFAJQgDAFADADQAEAAAEgFIAFgJQADgFAAgDIgDgBIgDACgAI5KgQABACAEABQAFgFACgFIgEgCQgFAAgDAJgAAiEnQgCAEABAHIAAANQABAxALAmQgCAdgFAYIgEACIgCAIQgXAjgJApIgEAgQgDAUAAANIABAPIgCAVQgCANABAIIAJAEQAGADAGAAQAHgJASgBQAIgXADgMQAMgZABgJQANgeAbgwQAFgPAAgKQgDADgEAIQgDAJgEACQAQgcgBgZQAFgGADgMQAEgGAGgLIAJgSIAJgiQACgpADgSQgVgJgggFIg7gHgAIrKKQAAAKAEAEIADgDQACgDABgEQAAgGgDgHIgCAAQgFAAAAAJgAGlHzQAHAKABAGQADABACAEIADAGIAMAPQAGAJAGAGQAWAiALAzIAAAGIAFAHQAkALAPgLQgIgVgCgMIAAgHQgFgagIgXQgYhpgOgyQgEgBgCgBIgDgRQACgOgJgQQgLgVgCgHQgDgCAAgCQgMgugfguIAAAAQgPAOgdAYQggAagNAMQANAOAeAVQAZAWAHAYQAAAKAHANQAGAOABAGQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAgBQgBgBAAAAQAAgBgBAAQAAAAAAAAQAFAwAHAVgAAfEiIANACIAWABIA5AJQAGADANADIATAHQAHgXACgSIAMggQAIgVADgMQAIgKAWADQgBADgFACIARAQQAKALAIAEQADAFAGACQARASAKAIIAOAWQAJANAJAGIAoghIAZgUQAQgPAJgHIAFgGQAEgDAAgDQABgDgDgEIgEgHIgFgDIgZgnQgPgWgNgPQgGgKgOgQQgQgRgFgIQgEgCgBgCIgOgYIgBAAQgMAIgWAKQg2AYgzAAIgjAAQgTgBgOgDQgDAHgGATQgFARgFAIQgFAXgVAxQgTArgEAfIABAAQAFAAAGACgAAkjJIgCAhQgCAVgEAKIgFAXQgEAOgBAKIABAYQAFAHADABQAHANAQASQASAVAGAGIAGAPIAFAjQADAWABAPQAJAEASAAIAfAAQBOACBEgsQgBgEAAgGIgBgMQgFgUAAgJIgShEQABgGgBgJIgBgPQgFgNgBgdQgCgjgBgKQgUABgSgIQgbgTgNgMQgTgUgGgaIABgOQgEADAAALQgBANgBADIgBgKIgCgLQgDAKAAAfIgGAcIgNAXQgHANgJAFIgLAGQgMAAgDABIgNgGQgJgKgDgIQAAgGgCgKIgEgPQgFADABAKQABAOgBADIgEgWQgFACgDADgAkxlIIABALQABAHgCADQACADgBAEIgBAJQAAACADADQABAAAAABQAAAAAAABQABABgBAAQAAABAAAAIAXAGQAPADAFAFQAGAPAKAQIAFAJIAGAJQANAaAYA1QAJAhAWAbIACAIQADABAHABQAEgCAKgCQAKgCAEgDQBAAHA1gRIAEAEIALAIQAFAEAAgCQAAgLACgGQgEgEgIgFIgLgHQgIgBgGgCQgNAAgYAIQggADgWgLIADgDQADACAIACIAFADQAAAAABAAQAAABABAAQAAAAABAAQABAAAAAAQAEgCAPABIAEADIACgBIABgBIAAABIABABQAEgDAOgDQAMgEAIgBQAJAAALAFIAPAIIABAEQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABABQADgHgCgDQAEgFADgPQAGgPABggQADgJgBgLIABgGIgcACQgMADgNALQgHAFgOAOQgygDgYAQQgBgBAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAIgIAEIACgCQAAgBAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAQgCgLgIgLIgMgUQgfgdgNgPQgXgbgLgbIgEgFIgFgFIgFgFIgCABIgDAAQgNgEghABQgHgEABgHQAKgDADgIIgHgBQgIAAgIAEgAA5jTIADAUQACAMADAGIAKAGQAGADAGAAIANgBIALgHIAKgIIAAgDIABgDQAQgRABgiQgIgfgLgSIgEAQQgTAQgyADIgFgBQAHAYAIARgADrj0IgDAEQgEANgFAcQALAIAXAAIABgeQABgRAGgIQA8gkAog8IAPgJQgBgEACgBQANgDAPgJQATgPAigpQAggnAXgQQAIgDATgFQAQgEAGgJIABgDIAFgEIAGgEIAKgBQALAFADgGQAAgHgGgEQgHgDgGAEQAAgBAAAAQABgBAAAAQAAgBgBAAQAAAAgBAAIgJAEQgFACgFgBQgFgCgGABQAKgXAIgMQAFgDASgFQAQgDAGgGIAGgBIAEgFQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAIgBAAQgYAFgKAFIgSAAQgDADgIABIgEAEQgFACgGAGQgVATgIALIgbAUQgPALgOAGIgEABQgHAGgGAAQgMAGgXARIgTAKQgFAEgKALIgIAJIgSAbQgKALgWAHQg8ATgfAoQgFAEgEAGQgHAFgTAFQgSAFgHAFQgIAMACALQAFAWASAUQAQAQAWALIACgJQADgFAAgHIAEgPQACgJAEgDQABABAAAAQAAABAAAAQAAABAAAAQAAABgBABgACJkMIgDADIAGAQIABgUIgBgBIgDACgAAXkOIARAMIAGADQAugBAWgTIAGgdIgBgUIgCgDQgLgtgXgiQgRgNgQgFIAAgCIAAgCIgHADQgDgDgDAAIgDAHQgDAEgDAAIAAgBQAAgBAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAQgDAGgTAYQgMARgBATIgBASIADAJQAEAGAAAFIADAJQADAHgCAEQgEgGgEgCQgGgEgJABIgIAJQgEAGAEAFQADAJAOADQAMACAGgJQAHAEAKAIgAlekTIAGALQAEAGAFADQADgCAAgCIgHgKQgEgFgBgFQgFAAgBAEgAlWkaQADAJAMAMIAGgFQAEgDABgDQgIgBgGABIgFgJQgBgBAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBABAAAAQAAABgBAAgAlWkyIgCAEQACAGAKARIADABQABAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAQgKgUgDgLIgDADgAlLk3IgDAFIALAbQAFACADgDQgBgRgJgOQABgCgCgDIgFAFgAk9lAQgDADgCADQABAFAFALQAFAJABAHQADADACgCQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAAAIgCgDIACgTQAAgLgEgHIgHAEgAghk0IAAAFQAHgHAQgCIAFADIAEACQgBgDgFgMQgFgKAAgIQgBgOAHgSIALgZQANgJAIgSQgBgHAEAAQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABIABADQADgGAFgBIACABQAAAAAAABQAAAAABAAQAAAAAAABQABAAAAAAIAEgBIADgBIgBADIACAAIAXAMQAMAIAFAKIAFAJQAAgRgOgLIAAgFIgEgDQgCgCgBgCIACgCIACgBQgDgDgIAAQgHAAgEADQgCgEgIgDQgBgEgEgDIgIgEIAAACIgBACQgwALgXAnIAAABIAAADIgMATQgGANAAAMIACgDQAAgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAADgDALQgDAJACAGQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAABAAQADADABAGIACALQABAAAAAAQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABgAj9k4IALABQgCgDgHgCIgCAEgAkTlNQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIAAACQgMAJgDAGQAEADAKAAIAPAAIAbgVQgMgQgDgFQgIAHgSAOgAkhlQQACADAGgBQAFAAAAgFIgIAAQgEAAgBADgAj1lkQAEANAMAHQAAgBABAAQABgBAAAAQAAgBAAAAQABgBAAAAQgIgHgFgNQgFABgBADgAEKrlQgQAIgeAUIgIAGQglAZg4AsIhbBHIjnCyIgRANQgPALgBADIAGALQAFAGAEACIEHjLIBkhMQA6gsAogiIAggaQATgPAMgMIAEgEQAAgBABgBQAAAAAAgBQAAAAAAgBQgBAAAAAAIgBAAQgGACgiASgAIyoPQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAABIAAABIABAAIACABgAI1oXQABAJAJgCIARgCQABgEADgGIgGADIgFAEQgGgDgHAAIgHABgAI5okIgCAEIgCAFQAPAAAGgCQALgEABgKQgDAAgEABIgGACQgBAAAAABQAAAAgBAAQAAABAAAAQAAABAAABIgBADQgFgBAAgDIgIABgAJdo0IgfALIAGAAQASgIAegBQAFgDADAAIADgDQABAAAAgBQAAAAAAgBQABAAAAAAQAAgBAAAAQgRAAgTAHg");
	this.shape.setTransform(-304.8,97.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#934607").s().p("AilCCQAGgRAZgYIAUgQIAVgQIApgfIAqgeIBQhAIApggIAVgPIAWgQQACAJAKANIjsC1IgCACIgHAFIgCACIgBAAQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAAAIg8ApIgKAGQgEADgDAAIgFgCg");
	this.shape_1.setTransform(-355.6,82.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF7F00").s().p("AgCADIgGgJQACgEAEAAQACAEACAGIAHAIQgBABgDACQgFgCgCgGg");
	this.shape_2.setTransform(-339.1,70.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFC9B6").s().p("AAGAPIgDgBQgJgPgCgGIADgEIADgDQACALAJASIgCAAIgBAAg");
	this.shape_3.setTransform(-338.5,67.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D14D13").s().p("AgLgIQADgFADAGIAFAHQAFAAAHAAQAAADgEADIgHAFQgKgLgCgIg");
	this.shape_4.setTransform(-337.9,69.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFC9B6").s().p("AABASIgJgZIADgGIAFgFQAAADAAACQAIANABARQAAAAgBABQAAAAgBAAQAAAAgBAAQgBABAAAAIgEgBg");
	this.shape_5.setTransform(-337.4,67.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFC9B6").s().p("AACAUQgBgHgCgKQgFgIgBgGQABgDAEgCIAEgEQAEAHAAALIgCARIACACQABABAAAAQABAAAAABQAAAAAAABQAAAAAAABIgCAAIgEgBg");
	this.shape_6.setTransform(-336.3,66.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFC9B6").s().p("AgYCAIgCgIQgXgbgJggQgYg2gNgYIgFgJIgFgJQgKgQgGgOQgGgGgOgCIgXgGQAAgBAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgDgDAAgCIABgJQAAgEgCgDQACgDgBgHIAAgKQAMgHAKAEQgCAHgLADQgBAIAHAEQAigBANADIACAAIACgBIAFAFIAGAFIADAFQAMAbAXAbQANAPAeAcIALATQAHAMACAKQABABAAAAQAAABgBAAQAAAAAAAAQAAABgBAAIgBADIAHgEQABgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAZgQAxADQAOgNAIgGQANgKAOgEIAbgCIAAAHQABALgDAIQgBAggHAPQgDAPgDAFQABAEgCAGQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAgBgBAAIgBgDIgRgJQgKgFgKABQgIAAgLAEQgOAEgEACIgBgBIgBgBIgBABIgBACIgFgEQgOgBgEADQgBAAAAAAQgBAAAAgBQgBAAgBAAQAAAAgBgBIgEgDQgJgCgDgCIgDADQAXALAggCQAXgJAOAAQAGADAIAAIANAHQAHAFAEAEQgBAGAAALQAAACgGgEIgMgHIgEgFQg2ARg/gGQgEACgIACQgLACgEADQgHgCgCgBg");
	this.shape_7.setTransform(-318.5,76.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D14D13").s().p("AgbASQADgGANgKIgBgBQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAAAABAAQAQgMAIgIQADAGAMAOIgbAUIgOAAIgCABQgIAAgEgDg");
	this.shape_8.setTransform(-331.2,63.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFC9B6").s().p("AgFAAQABgBAEAAIAGAAQgBADgFAAIAAAAQgDAAgCgCg");
	this.shape_9.setTransform(-333.2,63.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFC9B6").s().p("AgEABIACgCQAFABACACIgJgBg");
	this.shape_10.setTransform(-329.7,65.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF7F00").s().p("AgIgGQABgEAFAAQADALAIAGQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQgKgHgEgKg");
	this.shape_11.setTransform(-328.6,62.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DD781D").s().p("AkJDIIgGgLQAAgDAQgKIAQgNIDpixIBZhGQA4gsAlgaIAJgGQAdgTAQgJQAjgSAGgCIAAAAQABAAAAABQAAAAAAABQAAAAAAABQAAABgBAAIgDAEQgMAMgTAQIghAaQgoAhg6AtIhkBKIkHDLQgEgDgEgGg");
	this.shape_12.setTransform(-301.3,41.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFBF00").s().p("Ag2BEQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAAAgBIgCgKQgCgHgDgCQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQgDgFADgKQAEgLgBgDQAAAAgBAAQAAAAgBABQAAAAAAAAQgBABAAAAIgCADQAAgMAGgMIANgSIAAgDIgBgBQAXgnAwgKIABgCIAAgDIAIAFQAEACACAFQAHADADADQAEgDAHAAQAHAAAEADIgCABIgCACQAAACADACIADADIABAFQAOALAAARIgGgJQgFgKgMgIIgXgMIgBAAIABgDIgEABIgDABQgBAAAAAAQAAAAgBAAQAAgBAAAAQgBAAAAgBIgCgBQgFABgCAGIgCgDQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQgEAAABAHQgGASgMAJIgOAXQgGASAAAPQABAHAEAKQAGAMAAADIgEgCIgEgCQgRACgGAGIgBgFg");
	this.shape_13.setTransform(-302.8,59.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFC9B6").s().p("AgCBUIgRgNQgKgIgIgDQgFAIgOgCQgOgCgDgKIADACQgBgHAGgFQAGgDAFAGIgFAKQACAFAJgCQAIgCgBgGIgGAEQgEABgEgBQABgDACgCQAEgBAAgCQgDgKgMADQgMACACALQgEgFAEgGIAIgJQAIgBAHAFQADABAHAGQACgEgDgHIgFgJQAAgFgEgFIgDgKIAAgQQACgSAOgSQATgYADgGQAAAAAAAAQABAAAAAAQAAABAAAAQAAAAAAABIAAABQADAAACgEIAEgGQADAAACACIAGgDIgBACIABACQAQAGARAMQAXAiAKAsIADACIABAVIgHAdQgWASgtABIgEgCgAAqAjIgSAHIgDADQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAABQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAAAIAFgDQAGgEAIgCIAKgCIAHAAQACgCAAgDIgCAAQgIAAgKADgAANgnIAHAJIAHAIQAGAFADABQACADAEADQAFADABADQgBADgEABIgHAEQgEACABADIAMgGQAGgEACgGIgSgNQgJgJgFgHIgDgDIgDgCQAAAAgBAAQAAAAgBAAQAAAAAAABQAAAAAAABgAgOgaIgCACQADADACAGQABAFAGABQABgEgDgEQgDgEgBgDQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBgBAAAAIgCgBIAAAAgAgagRQACgBAAgHQABgFAGgDIAMgFQgCgBgEABIgGAAQgOAPAFAGgAAbguQADAKAHAFQACgDgDgFIgEgIQgEAAgBABgAAWg4QgFACACAEIAFgEIAGgCQAGABAAgCIgFgCg");
	this.shape_14.setTransform(-300.4,62.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAAAGIADgIQgDgGgGAEQgHAEACAFIgDgBQgCgKAMgCQAJgDAEAKQgBABgDABQgDABAAADQADABAEgBIAGgDQACAFgJACIgEABQgEAAAAgEg");
	this.shape_15.setTransform(-306.3,67.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#015353").s().p("AAJAMQgGgDAAgFIgJgJQgHgCgBgCIAAgCQAAgBABAAQAAAAABAAQAAAAABAAQABAAAAABQADABACAAQAFADAIAIIAFADQADACgBADQAAABAAABQgBAAAAABQAAAAgBABQAAAAgBAAIgDgBg");
	this.shape_16.setTransform(-306.2,169.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#015353").s().p("AgcAGIgLgDQgHgDABgEQAEgBAJAFIANAAQAJACAGgBIAUgBQALAAAQgKIAAAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIgBAFQgJAKgRADQgWgBgZgEg");
	this.shape_17.setTransform(-299.8,172.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#015353").s().p("AAFAcQgEgBgCgFIgGgIIgPgFQAFgbAIgJIAKAGQAHADAHAAIAAAJIABAEIgBACQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQAAABAEADQAEACgBAEIgDAEIgDAEIAAABIgBAEQgFAFgEAAIgBAAg");
	this.shape_18.setTransform(-305.3,166.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#015353").s().p("AgqANIgBgLQAFgBACgEIACgEIADgBQAAgBABAAQAAAAABAAQAAABAAAAQAAAAABABIAUgJQALgEAMAAQAYAHAEAWQgGAGgNAFIgRABQgaAAgXgIg");
	this.shape_19.setTransform(-300.1,169.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAAgIIAFgBQAEgBABACIgKAEQgFADgBAEQAAAGgCABQgFgGANgMg");
	this.shape_20.setTransform(-302.2,59.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#015353").s().p("AgKABQACgBAHgCIAJgCQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABIgLACIgIAFIgCgEg");
	this.shape_21.setTransform(-301.8,167);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOAFQAAgFAMgCQALgEAGAEQAAACgEAAIgHAAIgJADQgFACgDAAIgBAAg");
	this.shape_22.setTransform(-300.9,167.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#047391").s().p("AhLB8QgNgDgGgDIg5gJIgXgBIgMgDQgIgCgFAAQAFgeASgrQAVgvAFgXQAFgIAFgRQAGgTAEgHQANADATABIAjAAQA0AAA0gYQAWgLALgHIABAAIAPAYQABACADABQAGAJAPARQAOAPAGALQANAOAPAXIAaAkIAEADIAEAIQADAEAAADQgBADgDADIgFAGQgKAGgPAQIgaAUIgoAhQgIgGgJgNIgPgWQgKgIgRgSQgGgCgCgFQgJgEgKgLIgPgRQAEgBABgEQgUgDgJAKQgDAMgIAWIgLAgQgCASgHAXIgTgHg");
	this.shape_23.setTransform(-282.9,115.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AAAACQgCgEgCgDIABgCQAAAAAAAAQABAAAAAAQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAADADADQADADgBAEQgFAAAAgGg");
	this.shape_24.setTransform(-301.5,60.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgcgCQgEAAgBgBIAAgBIAAgBIABgBIAOAGQAHADAIABIAMAAQAQgDAJABQgIADgQACIgHAAQgVAAgKgJg");
	this.shape_25.setTransform(-298.4,89.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#015353").s().p("AgPALQADgEAIgCIAMgCQgFgCgGADIgLADQgFgHAJgGQAIgHAIACQAFACACAGQADAEgHABIAFABQABAAAAABQABAAAAAAQAAABABAAQAAABAAAAQgCACgGAAIgMADIgIABIgEgBg");
	this.shape_26.setTransform(-301.7,165.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFC9B6").s().p("AgOA5IgKgGQgDgGgCgMIgDgUQgIgPgHgYIAFABQAwgDATgQIAEgPQALARAIAfQgBAggQASIgBACIAAADIgKAIIgLAHIgLABQgGAAgGgDg");
	this.shape_27.setTransform(-295.7,74.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#00A0C6").s().p("AhCC5QAAgPgDgWIgGgkIgFgOQgGgIgTgWQgPgSgIgMQgDgBgEgIIgBgYQABgIAEgOIAFgWQAEgLABgUIADghQACgEAFgBIAFAWQABgDgBgOQgBgLAFgCIAEAPQACAJAAAGQADAJAIAKIAOAFQADgBAMABIALgGQAIgGAIgNIANgXIAFgbQAAggAEgJIABAKIABAKQACgDAAgNQABgLACgDIAAAPQAFAZATAUQAMANAcASQASAJATgBQACAKABAjQACAcAEAOIACANQABAJgBAFIARBEQABALAFAVIABALQgBAHACADQhEAthMgDIgfABQgSAAgKgEgAAbByQADAQgFAKQABAEAAADQADACADAGQADAGACABQgEgLgEgFQgCgDACgFIACgIIgEgVIgHgTIgBAAIAIAYgABcCKQgCgIgEgMIgGgUIgBgBIANApgAguB2QABgaAEgJIgBgBQgHASADASgAh9AKIAAABIAAABQAAACAFAAQALAMAdgCQAQgBAIgDQgKgBgPADIgPgBQgHAAgIgFIgNgGgAA3gqIgMAWQATgbADgUIgBgBQgCAMgHAOg");
	this.shape_28.setTransform(-289.2,87.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFC9B6").s().p("AhDC7IgLgEQgBgJACgNIACgUIgBgQQAAgMADgUIAEghQALgoAXgiIACgHIAEgDQAFgYACgdQgLglgBgyIAAgMQgBgIACgDIACgBIA5AGQAgAFAVAJQgDATgCAoIgJAjIgJASQgGALgEAGQgDALgFAHQABAXgQAbQAEgCADgIQAEgJADgCQAAAJgFAQQgbAwgLAdQgBAKgMAYQgDANgIAWQgSACgHAIQgGAAgGgCgAgGAZQgGgGgBgGQgBgFADgIIADgKIgCAAQgKAeAOAFgAAohCIADgVIgCgBQgCAQABAGgAgThEIACABIAEgFIAEgGQgHACgDAIg");
	this.shape_29.setTransform(-297.9,145.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgEAEQADgGAGgCIgEAEIgDAFIgCgBg");
	this.shape_30.setTransform(-299.5,138.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAAgRIACAAIgCAMQgCAGAAAFQACAGADAGQgLgFAIgeg");
	this.shape_31.setTransform(-299.1,146.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AADAUIAHgDQADgEABgDQgBgDgEgCQgFgDgBgCQgDgBgEgFIgIgIIgHgJQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAIADACIACAEQAGAHAHAIIASAMQgCAGgGAFIgMAHQAAgEADgCg");
	this.shape_32.setTransform(-297.1,61.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgTAIQgBAAAAgBQAAgBAAAAQABgBAAAAQAAAAABgBIADgDIAQgFQALgEAJABQAAADgDACIgGAAIgKACQgGAAgHAEIgEADQAAAAgBAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgBAAg");
	this.shape_33.setTransform(-296.3,66.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgEAAIAHgDIAFACQAAABgGAAIgDABIgGADQgCgDAFgBg");
	this.shape_34.setTransform(-297.6,57.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgEgFQABgBADAAIADAGQADAEgCADQgFgEgDgIg");
	this.shape_35.setTransform(-297.1,58.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AABgRIABABQgCAKgBAXQgDgRAFgRg");
	this.shape_36.setTransform(-293.7,97.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AAAgJIABAAIgBATQgBgFABgOg");
	this.shape_37.setTransform(-293.7,137.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFC9B6").s().p("AgCgEIACgEQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIgBATIgEgOg");
	this.shape_38.setTransform(-291,71.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AADAcQgDgGgBgBQABgEgCgDQADgKgBgOIgIgZIACAAIAGATIACATIgCAIQAAAFAAAEQAEAFAFALQgDgCgDgGg");
	this.shape_39.setTransform(-286.3,100);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAAACQAHgMACgMIACAAQgDAUgSAZIAKgVg");
	this.shape_40.setTransform(-283.8,82.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgsAmIAAgGIAHgIQAQgGAZgSQAIgGAKgIIAKgNQAHgIACgFIABgBIACAAQACADgDACIgEAFIgJAKQgdAgggAOIgKAJQgBADABAFQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAgBAAgBg");
	this.shape_41.setTransform(-276.5,66.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFC9B6").s().p("AA9DOIgFgHIAAgHQgLgzgWghQgGgGgGgJIgLgQIgCgGQgCgDgDgCQgBgFgHgLQgHgVgFguQAAAAAAABQABAAAAAAQAAABABABQAAAAAAABQABABAAAAQAAABABAAQAAABAAAAQABAAAAAAQgBgGgGgOQgHgMAAgLQgHgYgZgVQgegWgNgNQANgMAggaQAdgYAPgPIAAABQAdAuAMAuQAAACADACQACAHALAUQAJARgCANIADARQACACAEABQAOAwAYBoQAIAXAFAaIAAAHQACAMAIAVQgIAGgNAAQgNAAgRgFgAAEALQABAIAGAPIAIAWIAJAkQADAKABABIgCgPIgEgPIgIgfIgIgQQgEgJgBgIIgBACg");
	this.shape_42.setTransform(-261,142);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AAKAjIgJgjIgGgVQgGgOgCgJIABgBQACAHAEAKIAGAQIAHAcIAEAQIADAOQgCgBgCgKg");
	this.shape_43.setTransform(-259.2,147.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFC9B6").s().p("AinC8QAEgcAEgMIAEgFQAAgBABAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQgFACgCAJIgEAQQAAAGgDAFIgBAKQgWgLgQgRQgTgTgEgXQgDgLAIgMQAHgFATgEQATgGAGgEQAEgHAGgEQAegoA9gSQAVgGALgKIASgcIAIgIQAJgLAGgFIAQgKQAYgRAMgGQAGAAAHgGIAEAAQANgHAQgLIAagTQAIgMAVgTQAGgFAFgDIAFgEQAHgBADgCIATAAQAKgGAXgFIACAAQAAABABAAQAAABAAAAQAAABAAAAQAAABgBABIgDAEIgHACQgGAFgPAEQgSAEgFADQgJAMgJAXQAGgBAEACQAFABAGgCIAJgDQAAAAABAAQAAAAAAAAQAAABAAAAQAAABgBAAQAHgDAGACQAHAEgBAHQgCAGgMgFIgJACIgGADIgFAEIgCAEQgFAIgQAEQgTAFgJADQgWAQggAnQgjAngSAPQgQAJgLADQgCACACADIgQAJQgnA8g9AkQgFAJgBAQIgBAeQgXAAgLgIgAhBAtQgDAFgHAIIgKANQgKAHgHAJQgbASgQAGIgIAHIAAAHQAAABABABQAAAAAAABQAAAAABABQAAAAABAAQgBgFABgDIAKgJQAigPAdghIAJgKIAEgFQADgDgBgDIgCAAg");
	this.shape_44.setTransform(-265.6,58.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgFACIAFgHIACgEQAEgCACACQAAADgDAFIgFAGQgBAGgFAAQgDgDAEgGg");
	this.shape_45.setTransform(-248.4,163.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#015353").s().p("AgDgBQgBgLAGACQADAHgBAEQAAAHgEADQgDgEAAgIg");
	this.shape_46.setTransform(-248.8,162.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFC9B6").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABQAAAAgBgBQAAAAAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_47.setTransform(-248.7,44.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFC9B6").s().p("AgOADIADgDIAIgBQAAACADABIAAgCQABgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIAGgCQAEgCAEABQgCAIgKADQgEACgPABIABgFg");
	this.shape_48.setTransform(-246.6,42.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#015353").s().p("AAXAIQgQgDgHgBIglAAQgXAAgNgCIgLgCQgIAAAAgCQgBgGAHABIAMACIAfABIAhABIAoADQALAAAigCIAKgBQAHAAACADQgBAEgHABIgMABQgXACgTAAIgJAAg");
	this.shape_49.setTransform(-247.1,169.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#015353").s().p("AgEACQAEgKAFAFQgBADgEAFQgDgBgBgCg");
	this.shape_50.setTransform(-247.3,164.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFC9B6").s().p("AggAIIAfgJQARgGARgBQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAIgDACQgEABgFABQgcABgSAHg");
	this.shape_51.setTransform(-244.1,40.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgHAIQAGgKAGgHQABAAAAAAQABAAAAAAQABAAAAAAQAAABABAAIgHAKQgCAHgGABIgBgCg");
	this.shape_52.setTransform(-246.6,164.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFC9B6").s().p("AgOAAQAMgBAGABIAFgBIAGgEQgDAFAAADIgPACIgEABQgGAAgBgGg");
	this.shape_53.setTransform(-246.8,43.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#015353").s().p("AgGAEIAEgEIACgFIAHADIgHAIQgBAAgFgCg");
	this.shape_54.setTransform(-245.6,164.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#015353").s().p("AAiAbIgSgBQgMgBgFgBIgwAAQgcAAgOgGQgCgKADgLIAFgWIAGgCQALAEAOABQARACAKgEQAAAEAFAEQgEAFACAFQADACAJgEQAEAAABAEIACAFQABABAAAAQABAAABgBQAAAAABAAQAAAAABgBIABAAQAEAAADACIAFAGQAEgBABgCIABAAIAQADQAIABAGgDIAGgEQAEgCAFABQAMADARATQgXAFgaAAIgKgBg");
	this.shape_55.setTransform(-246.9,165.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AAAAAIABAAIgBABIAAAAg");
	this.shape_56.setTransform(-244.5,164.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AAAAAIgCAAIAEgBIAAABIgCAAIADAAIAAAAIAAAAIgDACg");
	this.shape_57.setTransform(-244.3,164.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AAAAAIAAAAIABAAg");
	this.shape_58.setTransform(-244.1,164);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#015353").s().p("AgKACIAGgGIAGAEQAFABAEAAQgDAEgGAAQgDAAgJgDg");
	this.shape_59.setTransform(-243.3,165.6);

	// flecha1
	this.instance = new lib.Path_6();
	this.instance.setTransform(-19.5,68.7,1,1,0,0,0,242.5,105.5);

	// flecha2
	this.instance_1 = new lib.Path_1();
	this.instance_1.setTransform(-272.3,-92);

	// flecha3
	this.instance_2 = new lib.Path_5();
	this.instance_2.setTransform(50.1,-0.8,1,1,0,0,0,340.5,175.5);

	// Capa 4
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#11AA0C").s().p("AgFAAIgBAAQADAAAHAAQAKAAACAAQgEABgbAAg");
	this.shape_60.setTransform(-383.9,172.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#11AA0C").s().p("AgDAAIAEgBQADABAEAAIgPACQAAAAAAgBQAAAAAAAAQABgBABAAQABAAABAAg");
	this.shape_61.setTransform(-316.7,172.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#11AA0C").s().p("AgFAAIAGAAQABAAABAAQABAAAAAAQABAAAAAAQABAAAAAAIgHAAIgEAAg");
	this.shape_62.setTransform(-301.4,178.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#11AA0C").s().p("AgjALIgCgLQAAgFAHgEQAMgDAXAAIAhAAQgKAHgOADQABAAAAABQAAAAAAABQAAAAAAAAQAAAAgBAAIgIACQgBgBgBAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAFAAABgCQgJgBgFACQgIABACACQALABgDACQgIACAGACQAAADgQABIgFAAQgKAAgBgCg");
	this.shape_63.setTransform(-303.7,176.6);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#11AA0C").s().p("AgFACIgDgEQAIAAAEACQADAAACADg");
	this.shape_64.setTransform(-336.3,165.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#11AA0C").s().p("AgEAAIAIAAIgFABQAAAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAg");
	this.shape_65.setTransform(-334.9,166);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#11AA0C").s().p("AgEAAIAEAAIAFABg");
	this.shape_66.setTransform(-333.8,165.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#11AA0C").s().p("AgKADQAFgCACABQADADAFgCQgFgCAAgBQAAgDALgBIgCAIIgMABQgGAAgBgCg");
	this.shape_67.setTransform(-346,165.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#11AA0C").s().p("AAAAAQgEgBgKACIACgCIAbAAIgRADg");
	this.shape_68.setTransform(-348.6,166);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#11AA0C").s().p("AgRAGIgEgEQASADAFgDQALgCAIAAQgGgDgUAAQgYAAgJADIAMAAIgMAGQgBgBgBAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQgDADgRAAIgjgBQAHgCgHgDQgGgCAJgCIBlgCQAAAAABAAQAAAAABAAQAAAAABAAQABgBABAAIgDABIAfAAQAIACADADQADABAOAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIgFgEIAUAAIgBACIARgDQAEAEgSACQgNABAQADQgXADghAAIg1AAQABAAABAAQABAAAAAAQABAAAAgBQAAAAAAAAg");
	this.shape_69.setTransform(-321.1,165.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#11AA0C").s().p("AgHABQAHgBAAAAQAIAAAAABg");
	this.shape_70.setTransform(-276.9,164.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#11AA0C").s().p("AgOACIABgCIABgBIAbAAIgHABQgFABAFABg");
	this.shape_71.setTransform(-274.7,165);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#11AA0C").s().p("AAvALIABgDQgEAAgIACQgHACgHgBIASgGQgPACgQgBQgIAAgRACIABgBIgXABQgPABgHADIAAgFQgIAEgGgBQgIgDgLABIADAAQgKAAAAgCQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQgLgBgOAFQgNAGgNgCQABgCgEgDQgBAAAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAMADAKgCQACgCgLAAQgKAAAIgDIgcgDIC8AAIACgCIAEACIArAAQgBgCAKgBIAOgBQgIACABACIARgBQADgBAXABQARAAgFgFIAOACQAKACAHgBIACADIACAAIgDABIgCAAIgIADQgCACAHAAIgYAAQgNAAABADQAIADAGAAQgLABgPACQgOACgLAAIAagGQAOgEgNgBIgQAFQgEgBAEgBIAHgCQgBgBgLAAQgLAAgDAAIAHACQAEABgHACIgrAIIADgCg");
	this.shape_72.setTransform(-294.9,165.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#11AA0C").s().p("AgEACIAKgCQgFgBgDABQgDAAgDgBIAQAAQABAAAAAAQAAABAAAAQAAAAgBAAQgBAAgBAAQgFACgDAAIgCAAg");
	this.shape_73.setTransform(-228.7,175.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#11AA0C").s().p("AgHAAQAAAAAHAAQAGAAACAAIgLABIgEgBg");
	this.shape_74.setTransform(-209.7,172.4);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#11AA0C").s().p("AgDAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIAJAAIgHABIgBAAIAAgBg");
	this.shape_75.setTransform(-225,164.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#11AA0C").s().p("AgVAEQgBgEASAAIAagEIgUAEIAEABQgGAEgKAAIgLgBg");
	this.shape_76.setTransform(-202.9,175.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#11AA0C").s().p("AAEADQgEgDgIAAQAIAAgBgDQgDgDANACQgKACAGACQAIAFgGABQAAAAAAgBQAAAAAAgBQgBAAAAgBQgBAAgBAAg");
	this.shape_77.setTransform(-194.8,175.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#11AA0C").s().p("AAAAAIgEgBQAJgBAAACQAAABgFABQAAAAABgBQAAAAAAgBQgBAAAAAAQAAAAAAAAg");
	this.shape_78.setTransform(-206,166.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#11AA0C").s().p("AgHAAQADgBAEABIAIABIgFAAQgJAAgBgBg");
	this.shape_79.setTransform(-194.2,171.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#11AA0C").s().p("AgDAAQgBAAgBAAQAAAAABAAQAAAAACAAQABAAABAAQAGAAAAAAQgDAAgGAAg");
	this.shape_80.setTransform(-201.2,165);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#11AA0C").s().p("AAAACQAAgCgUgBQAUgBAWABIgKABQgEADgHAAIgBgBg");
	this.shape_81.setTransform(-196.9,165.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#11AA0C").s().p("AAAAAIgDAAQgCgBALAAIAEgCIgDACQgBABgFAAIgKAEIAJgEg");
	this.shape_82.setTransform(-177,172.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#11AA0C").s().p("AAAAAIgGAAQAIAAAEAAIgDAAIgDAAg");
	this.shape_83.setTransform(-170.9,172.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#11AA0C").s().p("AgBAAQAFAAAAAAIABAAQAAABgGAAQgGgBAGAAg");
	this.shape_84.setTransform(-157.8,175.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#11AA0C").s().p("AgHAAIAPAAIgGABg");
	this.shape_85.setTransform(-139.6,176.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#11AA0C").s().p("AgCAAQAHgBgCgDIAIAEQgIAAgDACQgCACgHABQgCgCAJgDg");
	this.shape_86.setTransform(-150.7,166.9);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#11AA0C").s().p("AghAAQANABAUgCQARgEARADQgNAAgRACIgbAEg");
	this.shape_87.setTransform(-148.7,168.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#11AA0C").s().p("AABAAQAEAAABAAIgLAAIAGAAg");
	this.shape_88.setTransform(-122.2,166.9);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#11AA0C").s().p("AgVAFQADgEANgBQAIAAgCgEQgJAAgMAEQAAgFATABQAPAAAIAEQgHAAgOACQgJADgKAAIgDAAg");
	this.shape_89.setTransform(-93.3,173.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#11AA0C").s().p("AgFAAIALAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABg");
	this.shape_90.setTransform(-97.1,171.1);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#11AA0C").s().p("AAAAAQAHAAAAgBQACACgOABQgEgCAJAAg");
	this.shape_91.setTransform(-97.6,170.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#11AA0C").s().p("AhfA9IAfgnQguAAg8gEQgGgEAQgCQAPgCgBgBIARABQAAABgRACQgNABAKADIAkgBQATAAARgEQgFgEgTABQgXABgJgDQAIABAMgCIg3gEIgFACIAYACQgOAAgKACQgJADgBAEIADAAIgGACIgNgBIgEABIACgBIgMgCIgFABIABgBIgDAAIgVAFIgTADQgKACgLAAQAJAAgDgCIgSgFQgLgCgOAEIAOgBIgfAJQgFgCAKgCIAOgDQgLACgUgDQgRgDgFAEQgEgMgQABQAGACgFACQgFACAEACQgCABgJAAQgEgBgCABIABgBQgQgEgNAEQgMAGgFABQgRABgVgBIgiAAQAAgDgFgEQgGgEgHAAQgCACgNADQgNADgCACQAKACAGgDQAGgDAEgBQAEACABADQABACAHACIgcAAQgWAAgHgDIAFAAIgVgIQgMgFgSAFIgOADIACgCQgIAAgNgDQgHgBgOACIACgBQgIgCgNACIgTAEQgBgBgBgBQAAAAAAgBQAAAAAAgBQAAAAABAAIAHgDQgdgDgoANIgQgDQAIgBAGgDQAGgCgBgCIgJACIgLAAIANgJQgOgCgBAEQgBADgIgDQgNAAgBAHIgPgFQgCAEgeABQgBABAFACQAHABADgBQgCAFgUAAQgCgEgZAAQgWAAAEgFIg+ADQgmABgOACIgOgCQgHgCAHgCQgNAAgZAEQgWADgQgBIAGgBQAHAAAAgCQgKACgUgCQgTgDgOABQABAAAAAAQABgBAAAAQABAAAAAAQABgBAAAAQgCABgSADQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQABgBABAAQAAAAABAAQAAAAAAAAQAAAAgBAAQgggDgwAFQg1AEgZAAQAJAAAGgDQAFgCAAgCIgQgBQgEACgIABIgQACIgDgBQAAgBAAAAQgBAAABgBQAAAAAAAAQABAAABAAQgRgDgaAFQgcAGgTgBIAwgMIgMgEIAVgDQgHgBgKABQgHAAgBAAQAJgBABgCQgHgBgGABIgKACQAPgFAggCIAxgDQABgBAAABQABAAgBAAQgBAAgBABQgBABgCABIAOABQAHABAIgBQAFgCgGgBIgMAAQABgBAAgBQAAAAABAAQAAgBABAAQAAAAABAAIAIgBQABACAUABQAWABAFADQATgBgEgFQgCgEARABIALAFQAtgIAdACIgFAAQgDACAHADQAIABASgCQAOgBAGADQAMgDBDgJQAEAEgSACIgaAEIAUAAQgNAAgNAGQALABAMgDIAVgEQgDADAMAAIACgEIAFABIAfgDIgGgDQgEgCgFAAQADACgQAAQAFgBgGgBQgGgBgBgBQAhAAAQgCIADAEQAQABAcgBIgEACIAdABQAQAAAKACIA0gNQADgCAbADQAcADALgEQACAAgVAFQAEABAMgCQAIgCACADQgQgBAFADQAFAEgFAAQAYAAAKgDQgLAAAEgDQADgDgKABQAdgHAfADQAAADAKABIAGgDQABAAAAAAQAAAAAAAAQgBABgBAAQgBABgBAAQgHACAKABQAIgCAfAAQAYABAGgGQAGACgNACQgMADAMACQgFACgPAAQgNAAgCADQAHgBABADQACADADAAIAOgEIgDAAQAPgDAdAAIAxAAIAjgIQAVgFATABQgDABAKACQALACgMAEQAKACAKgCQAJgBAAgCIgPgCQAFgCALAAQAJAAAFABQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAIABADgBQAEgDADgBQACADANAAIAUABIAOgGQgEACAJABQAKAAABACIAQgFQAKgCAJABQgDABAIABQAKADAAABQANACAXgFQAWgEANADIgDACQAAAAAAABQAAAAABAAQAAABABAAQABAAABAAIAWgBQAGAAAAgBIAPgGQAKgDAMgCQgBgFgaAEIgHAEQgDgDgJABIgLABQAGgEAZgCQAhgDAHgBQgRgIgzABIALADIgNAAIAMAFIgfAAQAGAAAEADQAFADgIgBQgIgDgGACQgJADgDAAQAPAAgGADQgLgDgOgBQgOAAgKgDQACADgOAAQgQAAgBADIAKABIgUAEQgJgDAGgDQAGgCgQgCQgOgBgKAEQgMAEgKAAQAOgIAbAAIgKgCQAGgDAhACQgKADAJAAQAPABAEABQAAgBgDgDQgCgBAIgCIgggBQASABAQgHQAPgGAQACQgJABAHADIAJADIAbgCIgFgGQAIgBAOAFQANAEAMgEQACgDgRABQARgCASAFIAfAIIACgEQADgDAFgCIAAAFQAAACgGABQAIACATgEQgLgBAIgDIAOgDQAMAAgUAEIALADQAHABACgDQAAADgMADQgMAEgLABIAJAAQgFACgMgBQALAEgEAFIgBgBIAAgBQgPgCADAEQgEADAHABIANACIAMgBIAngQQAKgBAKACIARAEIAEgFQAcABgLAHIgGgCIgCACIAAABIAagDQgQAEAEADQAIAHgCACIAbgDQgKgBAEgCIAMgBQABACALgBIASgBIAAABQAMACAXgCQgBgBAJgEIAMgIQgLgBAAgBQABgBABAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAFACABgCQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgEgCIgdADQgPACgFAEQADABAGgCQAGgBADABQgHACgLABIgVAAIgGgEIgQACIAGgEQADgCAKAAQgBgCgJABIgSAAIgFAFQAAgBgHgCQgHgCAJgCIAbgEIgIgDIAXgBIgFADQARgCAHAFQAEAEASgDQAOgHAgACQgIABABACQAAAAABABQAAABAAAAQAAABgBAAQAAABAAAAQAKACAIgCIAMgEQAEACgBACQAAABgLAAQAAADAKAAQAKgBABADQAUAAAZgJQAUgIAfAFIgCACQATgBAbAAQAdABAPgBIAaAGQgHABgFADQgHADAEACQgHgDgMgCQgQgBgEgCQgBAAAAABQAAAAABAAQAAABAAAAQABAAABABIAEACIgLgCQgFgBgHABQANADgKABIgOgFQgJABgHAFQgFADgNgBQAMgIAKgCQgEAAAGgBQAIgCgFgBQgIADgMAAQgOAAgKABIAJgCIgegCQADABgMACQgOACABADQAQABAMAAIAfABQgUADgKAHIgCAAQgDADABADIACAIQAJgDAOAAIAYgBQACgDgHgBQgIgCgIABIARgDIgDADIArABQgFAAgEACIgGADIARADQgCgIAHAAQAkACASAJIADgBQgCgCAMgEIATgGQgBACAJABIAOACQACgDAAgCQAmACAtAAIAMgMQAHgHACgFQApgEARAEIgCACQALACAKgCQAEABgDACQgBAAAAABQgBAAAAABQAAAAABAAQAAAAABABIAZgDQgBADgfABQACAAABgBQABAAAAAAQABAAgBAAQAAgBgBAAQgEAAgSACQgPABgCgDIABgCQADgDgMAAQgPgDgEAIQAAABAJACQAJABgFACIANgCIAPABQgYAFgGgEQgNADgCAGQgBAGAIABQAAgBAPgDQALgCgPgDQAHgCAQgCIAagDIAAABIATgBQgJAEAAABIAbgGQgKACAKABIAQABIAGgEQADgDgGgBQgGgBgDABQgDACgFAAIAPgFIABAAIAJgEQAKAAgEAFQgCADANgCIgEgGIAvAEQAdADALgCQgEADAAAEQgBADAFADQgNgCgaABQgDgBAMgCQALgDAJAAQgDgFgQADQgQADgBgFQgRgCgNAFQgLAEgPgDQAAACgFABQgFABAAACQAEAEAVgBQAagBAIABIgHACQANABARgDIgBAAQAJgDADADQAFAFADAAIAKAAQAHAAgBgCIASAEIgBgFIAMABQAEABAGgCIAAgFIgZgBQAGgBACgCQACgCAHgBQgIADAIABQANABABACIAKgCIgDABQAEABAFgBIALgBIgQgEQgIgBgJACQAXgFANAAQALgCARAEQgGAAgCAHQgBAFgXgCQABgBAEABQgDgEgMADIgRAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAABAJABQgEgCAKgCQAMgDAJACIgCAIIAVABIgCAAQAEACAMAAQAPgBAGABIAbgCQAQgBgKgFQAIACALgBIATgDIgRgDIARgEIAPgGIACADQABAAAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIAvABQAbAAALgEQAHAAAPAFQANADAPgCQABAAAAgBQAAAAABAAQAAgBAAAAQABgBAAgBQABgCALABIgHADQgEADANgBQAIgDARACQATACAKgCIARACQAIABgCACIgZAAQgOABgCABQAAAAAAAAQAAgBgBAAQAAAAgBgBQgBAAgBAAQgBgBAAAAQAAAAABAAQAAgBABAAQABAAACAAQgNgCgGABQgIACgKgBQgBABAGACQAHABAEgBQAAADgUACQgOABAKAEQAJAAARgFQANgEALAEQgDABgLABQgLABgGAEIARACIALgEIgBABQARADALgFQARgGAIgBQgHgDACgEQACgFgFgBQAegCAAAIQgQACAAAEQAAADgPADIAAAFQAAAEAKABQALgDgDgCQgDgBAKgBQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAFgCAFABQAGAAAGgCIgDACQAIACAHgDQAGgCAGACQgCgCAFgBIANgDIgRgFQgMgDgOAAIgCAFQgCABgGABIAPAAIgJACIgOgCQALgBABgDQAEgFACgBIAPABIAKAAQgBADATAEIAiAFIgJAAQgJACAIABIALADIAIgDQgBABAAAAQAAAAAAAAQABABAAAAQABAAACAAQAGAAAHgDQAGgDAIgBQAAABgEAEQgEADAGABQAKAKAVgDIAMgCIgDAAIANADQgFADgLgBQgLgCgFADIgBACQgPAAgKAFIAegCQABACgFACIgGACIADgDQgJgCgNADQgPADgKAAIgCgBIACgBQgIACgRAAQgRgBgIADIAFgCIg4ALIAAACQAFACgPgCIgeAFQADACAIABIAMgCQAKgBgCgCQAGABALgBIAOAAQgHgCAIgBIALgEQABACAJAAQAHAAAAACIgEgBQgFgBgDACQgGACALABQALACgJACQAKgCAZgBQAYAAALgCIgLgCIATAAQAMABABABIgYABQAAACALAAQAMgBAAACIAagIIgLAAQAEgCAQABIAcACQgFAEgOgBQgTgBgHABQgHABAEADQAFADgGAAQAHADAJgDIAEABQgFAEgUABQgVADgIACIADgCQgSgEgVADQAGACAIgCQAAABgRACQAHABgBACQABAAAAAAQAAABABAAQAAAAABAAQAAAAABABQgHABgRgBQAAAAAAgBQgBAAAAAAQAAgBABAAQAAgBAAAAQABAAABgBQABAAAAAAQAAgBABAAQAAgBAAAAQgFABgIgCQgJgCgHABQASACgeAGIADABQgJAEgGgEIALgBQAAAAABAAQABgBAAAAQAAgBAAAAQAAAAAAgBIgQABIAFgCIgZABIgOALQgGgCgPADIADgBQgIgCgPABQgPABgBACQgBgBATgIQAQgHgiABQgMAAgFAFQgEAGgFABQABgBAAAAQAAAAgBAAQAAAAAAgBQAAAAgBAAQgFAAgEABIgJADQALADAGgDQgBACgLAAQgMgBgDACQAFgDgJgBQgKAAADgBQgagFgXAJQgGgEgNACQgOABgJgBIAMAAQAGgCgJgBQgIgBAHgCQgBAAAAAAQAAAAAAAAQAAAAAAAAQABABAAAAQACABADgBQAPgBgDgDIgRgEIAFgBIgZgGQAAAAAAABQAAAAAAAAQABABAAAAQABABABAAQgRgBgdAAIgsABQgDAGghACQgpABgJADQAFgCABgEQADgEgDgCIAKgDQAIgCAHAAIAHAEQAEACgFABQAQgBgFgDQgJgEADgCIAPACIAigJIgTgDIASAAIAYgBQAAgCgJgBQgKgBgBADQgCgBAJgCQAGgCgIgCQAQgEAmAFIADAGQAGABAFgDQAFgDAIABQgLABADADQADADgHAAQADABABADQACACAKAAQAGgEAHADQAIACAHgDQAAAAABABQAAAAAAAAQAAABAAAAQAAABgBAAQgCACAJABQAMgDADgDQACgBABgGQgJgBgIAEQgJAEgHgBIAcgJQgFgCgFAAQAHgBAFgCIAHgDQgeAAgDgDIADgCQgIgDgLAEIgUACQgKAAgCgCIAGgCIgpABIACgBQg5ANgrgBQAEAEAfAFIgJAFIgFgEIgPAEIAIADQgTABgVAEIgfAGIgBgBIgQACQALABgCADQgBAEgMgCIACgBQgFgBgOAAIgZABIgJAEQgJAAgFgEIgGgIQgOgBgPAEIgXAGIgWgEQgJgCADgBIgRAJQgKAGgVgGIAJgDIg4ADQghACgJgCQAHgGgYgFQgcgHgDgFQABACgGABIgIACQgGgDgHADQAGABgCAFQgCADAOgCQgXANgiAAIABgFIAVACQAAgCAFgBIAKgCQgVgBADgFQACgEgVAAIgEACIgGAAIACgBQgBgCgGAAIgIAEQgIgFAOgBQAMgCgGgDIAcgEQAOgDgDgEQgNgBgMAFQgNAGgOgCIgCgCQgGABgEACIgHAFQgBgDgIAAIgWAGIgVAHQAUgCARADQATACAVgCIgVADQgQADgBADIAAgEQgaAEgSgBIAKgDQgJACgUgDQgRgCgJAEIAHAAIgfAAIgbAIQABgBgIgCQgFgBAEgDQgLgCgLADIgQAEQgKgDALgBQAQgCABgDQgtgDgZAHQAJABgBACQgBgBgRAAIgDADQgOgDAOgDIgQACQgJABgHgDQAKgCAQABQAQAAAEgBQgQABgTgEQgUgFgWACIACgDQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBAAgBAAQgMAAABAEQABAEgCABQASgCANAGIgFADQAAgBgFgBIgHgBIgCAFQAAgEgIgDQgJgCgJABQAIADACACIACAFQgIADgIgCQgJgDgJACIAHgBQAEgCgJgBQgGAAgEACIgHAEQAEgCADgFQAEgEAFgDIAagCIgPgDQAKgBABgDIABgDQgOgDgJAEQgIAFgIgBQgEACAIAAQAHAAgHACQgKAAgCACQgDACgKABIADgCQgDgCgGABIgKACQAAAAgCAIQgCAIgTAAgAIUAtQgLACALAEIATgBQAMAAAAgDIAAABQAIABAFgDQADgDALABQABgDgMAAQgGAEgNABQAAgBAAAAQAAAAABgBQAAAAABAAQABAAACAAQAHAAgFgEQgCgBgOABQgMAAAFgEIAQABQAAgDAGgBQAGgCgBgCIAPAAQAIACAGgDIACgFQABgCALABQAMAHA0gCIAMgDQAAgBgLAAQgJAAAFgCIATgBIgBABQAFABANgDIgMADQgGABABADIAKACIAJAAIgDABQALABAFgDIAGgFQAKgDgMgDQgPgDABgCIA1gCQgJADACACQAFABACACQACABAKAAQgBgEAOgBQATgCAFgBQABAAABABQABAAAAABQABAAAAAAQAAAAgBABIgJAAQAAADAKAAIAPAAIAOgCQgBgBgBAAQAAgBgBAAQAAAAAAgBQABAAAAgBQACgCAJgBIAAgBIgggDQgUgBgIACIADgCQgJgBgYADQgTACgFgEQAAgBAAAAQAAAAgBgBQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIgQACIAEAAIgcAAIABAAIggAIIAAACIgDACIgLABIgJgCIgLgDIAaAAQADgGgPgCQAAAAABAAQABAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQgBAAgBAAIgIACQgGABAEAAIgugBQgegCgVADQAIgCgJgBQgIgCANAAQgLgDgIADQgKAEgKAAQAAgBAGAAQAIgBADgCQgSgBgdAFQgdACgRgBIgBgCIgVACQAKAHALAEQARAFAggBIgDAAQAMADAZgDQAZgEAPADQgOAEgPAIIAQgDQgDAEAIAAIARgBIgKAHQgFgCgKAAIgIAAQgBgBgMgDQgRgDgKABQABACAPACQAMACgJAEQAHgCAHABIANABQgHABAAADQgBADgEACIAVgCIgNADgADxAZQAJAFANAAIAZgDQANgBACgCQABABAIABQALACAGgCQAGgEASgDQANgCgFgBIgOABQgIABgEgDIAQgBIgKgEQAHACgFgJIgTABIACAAIgUAEQAJABADADQACADgLABIgBgCQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQgLgCgKAAQgMgBADAFQAMgDABAEQACAEAHgCQgEADgJAAIgNACQAGgDgFgDQgGgDgKgBQgWAAgKABQACACgBADQAAACAKABQgOACgLgDQALgBAAgBQgEgCgGgBIgJgCIgKAAIACACIgKADQAIgBABACIgDADQABgCgGAAIgJACIAKAFQgCABgIgBQgHgBABACQAVACAhgCIgJgEIAIAAQAHAAAFACgAAPAcQALAAAEgBQACgCAMgDQAKgDABgDQABgBgIgBIgQgBQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAJACgCAEQgHgEgHADQgHAFgHgBQgDADAKABgACjAOQABAAAAABQABAAAAAAQAAABAAAAQAAAAAAABQAIABACgBIACgDgABKAPQASACAVgBIAegKQAUgGAAgBQgCgCgGABIgKAAIACACIhGgDQAmAIAFAEQAFAGgvgBgAg4ANIADgEIgJAAQADADADABgAGHgbQgHgBgNACQgKAAABgDQAEgCALAAQALgBADgCIgKgCQAJgCAGACQAFAEALgCQgBgBgBgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAIABAEgCQgCgBgTgBQgNAAADgFQAFgBATAEQAUADAIgEIgBABQAOABAKgDIAOgEQAFABALgBIAQgCIAAADIAOgBQgEACgIAAIgRgCIABAFQgIgEgKADIgQAHQAFgBAYgBQARAAADgFIAKAEIAEgCQAFADgEADQgEADgLABQgBgBgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgQAFgNgBIAJgCQgjgBgJAHIgCgEQgEgFgHgDQgLADgDACIgFAHIgfAEg");
	this.shape_92.setTransform(-241.6,170.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#11AA0C").s().p("AgJgBQAKABAJAAQgJABgDABQAAgCgHgBg");
	this.shape_93.setTransform(-135.6,172.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#11AA0C").s().p("AgIAAIACAAIAOAAQABAAgBAAQAAAAAAABQgBAAAAAAQgBAAgBAAIgNgBg");
	this.shape_94.setTransform(-259.7,172.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#11AA0C").s().p("AAFAEQgNACgCgEQgBgCgPAAIgCAAIAFgCIgRgBIAUgBQABAAABABQAAAAABAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAQABAAABAAIANgBQADgCgIgCIAKABQAKACAFgBQgDACALABQAKABAEAAQgBADgOAAIgXACg");
	this.shape_95.setTransform(-182.9,171.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#11AA0C").s().p("AgGALIAMgDQAEgBgKgCIgggDIAUAAQAKgBAHADIAGgEQgMgBgiABQAWgHAsgEQAHACgEACQgGACAFABQgGgBgFACQgCAAAAAAQgBAAgBABQAAAAAAABQAAAAAAAAQAGABAJgCQAAAAAAAAQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAABABQAAAAABAAIgQABQgKAAAAADQARAAgJADIgOAEQAAgBgGAAg");
	this.shape_96.setTransform(-95.4,168.6);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#11AA0C").s().p("AAsANIgnAAQgEgCAGAAIgjAAQgYAAgKACIgPgBQgJgCAFgCIgLABQAAAAAAAAQAAgBABAAQAAAAABAAQABAAABgBQAFAAAAgBIgFAAIACgFQACgCAPAAQAFABgJABQgKAAADAEQAFAAABgCIACgCQAKAAgBAEQACgBAJAAQAJAAADgCQALAAgCADQgDADAGAAIAIgHIAUABQAQgBgBgFQgCgHATgCQgDADAJAEQAJAEAMABQgdADgNgCQAJADgOAAQgOABADADQAPgFAWADIgEABQAFABANgDQAMgDAKABQAJAAgEAEQAOgCAAABIgGAIIgcABIgPgBg");
	this.shape_97.setTransform(-260.6,176);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#11AA0C").s().p("Ag8AAIgdACQAAgEAdABQAiABAJgEIAGADQAEABAHgBQAAgFASAAIAggBQABAAAAABQABAAgBAAQAAAAgBABQgBAAgCAAQgHACAFABIAQgDQAKgBAJACIgCAAQANgBgBADIgDACQgFAAgKAAIgOABQgGADgaACQABgCgGgCQgFgCABAAQgyAAgKABIAHAAQgMAAgCADQgDAEgHAAg");
	this.shape_98.setTransform(-288.6,174.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#11AA0C").s().p("AAAAAIAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABg");
	this.shape_99.setTransform(-267.1,173.8);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#11AA0C").s().p("AicATQgNgBABgEIAKgEQAEgCAKgBQAIAFASgCQAbgDAGABIAGgDQADgBAJgBQgBACgMADQgJABAHAEQALABALgBQAMgBAEgEQgSABACgGQADgEgSABIALgCQAHgCAGgBQAJABgNAEQgKACAYAAIAEgHIAeABQgYACgGADIAfABQAQABABACQARgDAogKQAjgLAYgDQAMABACADQABADgGADQAKAAAFgDIALgFQgJAEABACIAGAEIAKgCIhPAfQgJADgagBQgZgDgGADQAFgDgGgCQgGgCgJAAQgBABAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAEACQgwgJgSAKIAKgHQgcADgMAEQABAAABgBQAAAAABAAQAAgBAAAAQAAAAAAAAQgFgDgLADQgMACgEgBIAIgCQABgCgPABQgHAAgFADQgGACAJABIgOgBIADADQgDgDgPgBg");
	this.shape_100.setTransform(-285.5,176.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#11AA0C").s().p("AAAAAIAEAAIgHABQADgBAAAAg");
	this.shape_101.setTransform(-266.9,174.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#11AA0C").s().p("AAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIgBABg");
	this.shape_102.setTransform(-345.2,168.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#11AA0C").s().p("AgcAGQANgCAEgEQAGgDAEgCIgFAAQgBAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAIAEgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQABABABAAQABAAAAAAQAAABAAAAQAAAAAAAAIAZgEIgFAEIgVAGIgEABIgLAEIgEAAQgGAAgGgCg");
	this.shape_103.setTransform(-247,165.6);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#11AA0C").s().p("AgkAHIAkgNIAAAAQgGACAGAEQADABAKgBIgDAAIAIAAQAJgBADABQgGAAAFACIAIADIg2gBQACgCAEAAQgHAAgGADQgFACgFAAIgCAAg");
	this.shape_104.setTransform(-262.7,173.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#11AA0C").s().p("AgdAJQANgCABgCIgJABQgGgBAFgCIAGgDIATACIALgFQgLgDABgBQACgBgDgEQABABASABQAPABAEADIgXAHIAHABQAEgBADgBIAAAIIAEAAIgGACIgEACQgKgDgVAAQgGACgGAAIgQABQgDgCAKgBg");
	this.shape_105.setTransform(-89.8,169);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#11AA0C").s().p("AgYAEQgEgBgFAAIgHAAQANgBAEgDQADgFASAAQgEAAgBACQAKADALgDIgBACIAcgBQgCADgNAAQgNAAgCAAIAQABIgbAEQAIgCgEgCQgEgBgGABQgBAEgDAAIgNACQABAAAAgBQAAAAAAAAQAAAAgBgBQAAAAgBgBg");
	this.shape_106.setTransform(-82.2,169.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#11AA0C").s().p("AgMAAIAQgBQAJABAKAAIgtACQgEgCAOAAg");
	this.shape_107.setTransform(-165.8,174.5);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#11AA0C").s().p("AgPAAIATAAQAKAAACAAIgWABIgJgBg");
	this.shape_108.setTransform(-124.3,180.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#11AA0C").s().p("AhhALIgFgLQgCgFATgEQAggDBCAAQBMABAPgBQgdAHgkADQAFACgFAAIgWACQgLgCAJAAQANgBABgBQgYgBgSACQgTABAEACQAiABgNACQgVACASACQgCADgpABIgOAAQgaAAgEgCg");
	this.shape_109.setTransform(-130.6,178.8);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#11AA0C").s().p("AgQACIgHgEQAYAAAMACQAHAAAEADg");
	this.shape_110.setTransform(-218.7,167.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#11AA0C").s().p("AgMAAIAZAAIgRABQgEgBgEAAg");
	this.shape_111.setTransform(-214.9,168.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#11AA0C").s().p("AgMAAIALAAIAOABg");
	this.shape_112.setTransform(-212.1,168.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#11AA0C").s().p("AgdADQANgDAFACQAIACARgBQgQgCACgBQACgDAcgBIgEAIIgjABQgTAAgBgCg");
	this.shape_113.setTransform(-245,168.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#11AA0C").s().p("AACAAQgMgBgeACIAFgCIBMgBIgwAFg");
	this.shape_114.setTransform(-251.9,168.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#11AA0C").s().p("AgyAFIgJgDQAyACAQgCQAfgCATgBQgQgDg6AAQhAAAgYAEIAhAAIgiAFQgIAAAAgBIAAgBQgIADgtAAIhggBQASgCgSgDQgQgCAagCIETgBIANgBIgHABIBSgBQAXABAJADQAGACAoAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQgBAAgCgBIgOgDIA4AAIgEABIAtgCQAMADgwADIgTAAQgCABAdACQg+ADhZAAIiTACQAMgBgDgCg");
	this.shape_115.setTransform(-177.6,168);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#11AA0C").s().p("AgUABIAUgBQAVAAAAABg");
	this.shape_116.setTransform(-58.3,166.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#11AA0C").s().p("AgmAAQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAIBNAAIgUABQgNABAMABIg+AAIADgCg");
	this.shape_117.setTransform(-52.5,167);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#11AA0C").s().p("AikAIQgVAFgQgCQgWgDgcABIAFAAQgaAAAAgBQAFgDABgCQgeAAgnAFQgkAFghgCQACgBgKgDQgIgDADgBQAfADAbgDQAFgDgfAAQgZAAAUgCIhJgDIH/gBQgBAAAAAAQABAAAAgBQABAAABAAQABAAABAAIAKABIB2AAQgDgCAaAAIAlgBQgVABADACIAtgBIBHAAQAuAAgMgFIAlACQAbACAUgBIADACIAGAAIgOACIgWADQgEACASAAIhCAAQghAAACADQARADAWABQgfAAgoACQglACgeAAIBEgGQAogEgkgBIgrAGQgLgBAKgCIATgCQgDgBgcAAQgdAAgJAAIATACQALABgSACIh0AHIAIgBIACgDQgLAAgVADQgSACgUgCIAvgFQg+gChcAFIACAAQhjABgWADg");
	this.shape_118.setTransform(-106.9,167.6);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#11AA0C").s().p("AgNACIAegCQgMgBgOABQgIAAgHgBIAwAAQAGABgOAAQgMACgMAAIgFAAg");
	this.shape_119.setTransform(71.7,177.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#11AA0C").s().p("AgWAAQgCAAAWAAQATAAAGAAIgZABIgUgBg");
	this.shape_120.setTransform(123.1,174.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#11AA0C").s().p("AgLAAQAAAAABAAQAAAAAAAAQgBAAAAAAQgBAAgBAAIAbAAIgVAAIgEABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBg");
	this.shape_121.setTransform(81.8,166.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#11AA0C").s().p("Ag5AEQgDgDAwgBIBGgDIgzADIAMABQgLACgUABIgQAAIgdAAg");
	this.shape_122.setTransform(141.3,177.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#11AA0C").s().p("AAJACQgMgCgVAAQAYAAgJgDQgIgDAoACQgfACATACQAXAEgQACQAEgBgNgDg");
	this.shape_123.setTransform(163.5,176.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#11AA0C").s().p("AAAAAQgGgBgIAAQAdgBAAACQgBAAgOACQAEgCgEAAg");
	this.shape_124.setTransform(133,168.2);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#11AA0C").s().p("AgVAAQAJgBAMABIAWABIgPAAQgZAAgDgBg");
	this.shape_125.setTransform(164.8,172.9);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#11AA0C").s().p("AgDADQADgDg6gBQA6gBA7ABQgIAAgRACQgLACgTAAIgHAAg");
	this.shape_126.setTransform(157.6,167);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#11AA0C").s().p("AgFAAIgNAAQgGAAAhAAIALgBIgJABQgDAAgJAAIgLACIAHgCg");
	this.shape_127.setTransform(212.2,173.7);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#11AA0C").s().p("AABAAIgSAAQATAAAQAAIgKAAIgHAAg");
	this.shape_128.setTransform(227.9,173.6);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#11AA0C").s().p("AgEAAQAOAAABAAIAEAAQAAABgUAAQgTgBAUAAg");
	this.shape_129.setTransform(263.3,176.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#11AA0C").s().p("AgUAAIApAAIgOABg");
	this.shape_130.setTransform(312.4,177.8);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#11AA0C").s().p("AgHAAQAXgBgFgDIATAEQgUAAgIACQgIACgWABQgEgCAZgDg");
	this.shape_131.setTransform(282.4,168.3);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#11AA0C").s().p("AhcAAQAkACA0gDQA1gEAsADQglABgrABIhNAFg");
	this.shape_132.setTransform(287.8,169.5);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#11AA0C").s().p("Ag7AFQAHgEAjgBQAbAAgGgEQAnAAARADQgUAAglADQgbADgbAAIgIAAg");
	this.shape_133.setTransform(437.5,175);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#11AA0C").s().p("AgRAAIAjAAIgLAAIgDABg");
	this.shape_134.setTransform(427.3,172.2);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#11AA0C").s().p("AgEAAQAYAAgBgBQAEABgPAAIgYACQgJgCAVAAg");
	this.shape_135.setTransform(425.8,171.7);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#11AA0C").s().p("AkCA8IBUgmQiUAAiNgEQgOgEAogCQAqgCgCgBIAuABQgBABgrACQgiABAXADIBkgBQAygBAugEQgMgEg2ACQg/ABgYgDQAWABAjgCIiXgDIgNABIA4ACQgeAAgYACQgbADgCAEIAIAAIgRACIguAAIAHgBIgugBIAEgBIgLAAIg5AFIg0AEQgtADgcgBQAqAAgIgCIgwgFQgdgCgmADIAkAAIhRAJQgQgCAagCIAqgDQgfACg3gDQgsgDgPAEQgMgMgpABQAPACgNACQgPACANACQgHABgWAAQgOgBgFABIADgBQgsgEgiAEQgfAGgPACQgwABg2gBIhbgBQgDgDgMgDQgQgEgTAAQgFABgmAEQgiADgEADQAdABAOgDQARgDAKgBQAKACAFADQADACASACIhMAAQg7AAgRgDIAKAAIg4gIQgggEgwAEIgmADIADgBQgWAAgggDQgTgCgjACIACAAQgYgCghACIgzAEQgLgDAIgBIATgDQhRgChpAMIgsgCQAVgBASgDQARgDgGgCIgXACIgfAAIAlgIQgmgDgDAFQgCADgWgEQgiAAgEAHIgpgEQgDADgeABIg2ABQgDABARACQAQABAJgBQgBACgWABIglABQgEgEhFABQg8AAANgFQjyADhDAEIgmgCQgSgCARgCQglAAhBAEQg6ADgsgBIAQgBQATAAgBgCQgbACgygCQg5gCgmABQAJgBAGgCIg3AEQgBAAgBAAQAAAAAAAAQAAAAACAAQABgBACAAQAKAAgDgBQhYgCiCAFQiJAEhCABQAUgBAOgCQAOgDAAgCIgsAAQgIABgaABIgqADIgJgCQAAAAgBgBQAAAAABAAQAAAAACgBQABAAACAAQgtgDhEAGQhNAGgzgBICBgMIghgEIA5gFQgRgCgbACQgVACgCgCQAYgBAAgCQgSgBgOABIgbACQApgEBXgCICCgDQAKgBgVAEIAlABQAXABATgBQAOgCgRgBIgeAAQACgDAbgBQACACA4ABQA7ABANADQA0gBgKgFQgIgEAxABIAeAFQBxgIBUABIgNABQgGABAHABIALACQAXABAvgBQAngCAQADQA+gGCYgGQAKAEgxACQhAACgIACIA0AAQggAAghAGQAdABAegDIA6gEQgGADAfAAIAGgFQABABAJAAIBWgCIgSgEQgKgCgNAAQANAEgugBQAKgCgOAAQgSgCAAgBQBWAAAsgBIAKAEIA/AAIA2gBIgJADIBLAAQAuAAAaACIBJgHQAvgDAVgDQAJgCBIACQBNADAcgEIgTACIgiAEQAOAAAfgCQAVgBAHADQgrgBALACQAPAEgOAAQBCAAAZgDQgdAAAKgDQAKgDgdABQBOgHBVADQAAADAbABIAQgDQAKAAgSACQgTACAdABQAWgCBRAAQBDAAANgGQASACghADQgiACAhADQgQACgpAAQggAAgHADQATgBAEACQADADAJAAIAngDIgJAAQAogDBPgBICEAAIBggJQA3gEA0AAQgKACAdACQAbACgdADQAbACAagBQAYgCABgCIgpgCQAOgCAcAAQAZAAAPABIgFABIgCABQAYABAFgCQAJgDAMAAQAFACAiAAIA1ABIAngGQgKACAWABQAdAAADACIAqgFQAagCAbABQgJABAVABQAbACAAACQAkACA9gFQA6gFAkADIgGACQgDACANAAIA9gBIgBABIACgBQANAAAAgBIApgGQAZgDAkgCQgGgGhEAFIgSAEQgKgDgYABIgfABQAUgEBEgCQBWgDATgBQgvgIiJACIAeACIgkAAIAjAFIhSAAQAQAAAIADQAMADgTgBQgXgCgQACQgWACgLAAIAYABQAKABgJABQgdgCgogBQgjgBgdgDQADAEgkAAQgoAAgFADIAaAAIg2AFQgYgDASgDQAOgCgogCQgngBgdAEQghAEgXAAQAggIBLAAIgbgCQAQgDBbACIgRACIAMAAQAqABAKACQABgBgJgDQgEgBAWgCIhMgBQArAAAngGQAogGArABQgYABARADIAaAEIBJgDIgPgFQAXgCAmAFQAjADAggDQAEgCgaAAIgTAAQAvgCAuAFIBXAIIAGgEQAGgDAPgCQAAAAAAAAQAAABgBAAQAAABAAABQAAAAAAABQAAACgQACQAUABA1gEQgegBAWgCIAmgEQAjABg7AEIAfADQATABAGgDQABACghAEQgiADgdABIAZABQgNABghAAQARACADACQACACgGADQgBAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgaAAQgJABADABQgLADAUABIAhACIAggBIBrgQQAcgBAaABIAuAEIAJgEQBOABgcAGQgBgBgOAAIgIACIBIgDQgqAEAMAEQARAGgDACIBIgDQgbgBANgCIAegCQACADAggBIAygBIgCABQAhACA+gCQgCgCA5gLQgggBACgCQAHgCgCgBQANABADgBQABgBAAAAQAAAAAAAAQAAAAgBgBQgBAAgCAAIgJgBIhNADQgoABgOAEQAIACAOgCQAQgBAJABQgSACgcABIg8AAIgOgEIgtACIAQgEQAKgCAcAAQgEgCgaABIguAAIgOAFQACgBgXgCQgRgCAZgCIBHgEIgTgDIA9gBIgPADQAwgCAPAEQANAEAygDQAogHBUACQgYABAEACQAFADgFACQAbABAVgCIAigEQAKADgCABQgCACgbgBQgCADAaAAQAegBACAEQA2AABCgKQA2gIBUAFIgGACQA2gCBHAAQBSABAlgBIBGAHQgRABgQADQgRACAKACQgUgDgggBIg3gDQgCABAIABIAMACQghgDgeABIAPACQAJACgPAAIgogEQgXABgSAEQgPAEghgBQAZgJAjgBQgMAAARgCQAWgBgPgCQgXADgfABQgoAAgXABIAVgCIhQgCQAKABgjACQgmADAEACIBLABQAfgBA0ACQgvABggAJIgGAAQgIADACADQAGAGAAACQAYgDAlAAQAsAAAWgBQAHgDgWgCQgTgBgWABIAugDIgJACIB1ACQgLAAgfAFIAvACQgGgHATAAQBhABAxAJIAJAAQgIgDAhgEIA0gGQgBADAWAAIAnACQAHgDgDgDQBsADB1gBIAggMQATgHAGgFQBkgEA5AEIgEACQAbACAcgCQAMABgJACQgJACAGABIBGgDQgIAEhRAAIAIgBQABAAABAAQABAAABAAQAAAAAAgBQAAAAgBAAQgLAAgxACQgnABgHgDQgCAAAAAAQgBAAAAAAQgBAAAAAAQABgBAAAAIAGgBQAHgDggAAQgkgCgPAHIAZADQAWACgKABIAigBQATgBAVABQhBAFgPgEQglADgDAHQgDAGAXAAQgDgBApgDQAegCgpgCQATgDAsgCIBGgDIgCABIA0gBQgXADgBACIBGgHQgUADAWABIAsABIgDACQANAEA5gBQBIgCATABQgOAAgEACQAkABAsgCIgEgBQAbgCAIACQAOAFAGABQAxAAgGgDIAxAEIgDgFIAfABQANABAPgCIACgFIhGgBQASgBAGgCQAFgCAUgBQgYADAYABQAgABACACIAcgDIgHACQAMABANgBQAPgCAMABIgpgEQgXgBgZACQAjgDA/gDQARgBAXABIAlACQgTABgEAHQgEAFg8gCQADgBAKABQgJgEgeACIgvAFQADACgFACQAAABAZABQgMgCAdgCQAdgDAbACIgHAHIA5ABIgGAAQAMADAggBQAngBARABIBJgCQAtgBgcgFQAVADAegCIA1gDIgwgDIAvgEIAngGIAIADQACABgFABIB9ABQBLAAAcgEQASAAAqAEQAhADAsgCQACAAAEgDQACgDAdABIgQADQgKADAigBQATgCAvABQAzACAagDIAuACQAYACgGACIhFAAQglABgHABQADgBgMgBQgHgBASgBQgigCgTABQgUACgcgBQgCABARACQATABAIgBQABADgzACQgoACAcAEQAbAAArgFQAjgFAdAEQgIABgfABQgcABgPAEIAsACIAfgEIgCABQAtADAdgFQAtgHAYgBQgWgCAHgFQAIgFgOgBQBRgBAAAHQgtADAAADQgCAEgnADQACAAgBAFQAAAEAcAAQAcgCgJgCQgHgCAagBQACAAABABQABAAAAAAQABAAAAABQAAAAgBAAQAMgBAQAAQAQABAQgCIgHABQASACATgCQATgCAQACQgIgDAQgBIAhgDIgtgEQgfgEglABIgIAEQgFACgRABIApgBIgYADIgogCQAegCAGgDQAJgEAEgBQAaABAPgBIAbAAQgCADA0AEIBcAFIgYAAQgYACAXACIAcACIAXgCIgBAAQgCABAIAAQATAAASgDQASgDATgBQABABgMAEQgIADAOABQAeAJA2gCQADgCAdgBIgGABIAiADQgPACgcgBQgdgBgPADIgCAEQgqAAgZAEIAnAAIAogBQAEABgNABIgQACIAGgDQgZAAghABQgpADgaAAIgEgBIACgBQgVACgvAAQgsAAgXADIAPgDIiWALIAAACQAFABgMAAIgUgBIhSAGIAcADQADgBAfgBQAagBgEgDQAOACAfgBIAkgBQgPgBASgCIAegDQAFABAXAAQATAAgBACQgRgCgOACQgSACAfACQAeABgXACQAagBBDgBQBAgBAfgCIgfgCIA0AAQAiABADABIhBABQgBADAdgBQAfAAACABIBHgIIggAAQANgCArABIBNACQgQADglAAQgzgBgTABQgTABAMADQAMADgRAAIAUABQAOAAAJgBIANABQgQADgzACQg7ACgUADIAJgCQgugDg9ACQANABAXgBIgsAEQASABAAABQAAACAIAAQgcACgjgCQgHgBAHgBQAJgCgBgBQgKAAgYgCQgWgCgVACQAgAAgWADIgpAFIAIAAQgaAFgPgEIAbgBQAMgBgEgCIgrABIAOgCIhFAAQggAJgHADQgNgCgqADIAHgCQgWgCgnACQgmABgFACQgDgBA0gIQAqgHhbABQghAAgMAFQgNAGgMABQABgBAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQgPAAgMACIgWACQAeADAPgDQgFACgcAAQgfAAgKABQAPgDgbgBQgYAAAGgBQgigCgoACQgiABgYAEQgSgEgfABQgqACgZgBIAkAAQAQgCgbgCQgXgBAagCQgCAAgCABQgBAAAAAAQgBAAABAAQAAABABAAQAGABAIgBQAmgBgHgDIgugEIARgBIhGgGQgBABAJACQgtgBhQAAIh2ABQgHAHhcABQhtACgXADQAMgDAFgEQAFgDgHgCIAbgDQAXgCASAAIATADQALACgOACQAtgBgRgDQgYgEAKgCQg1AAg5AFIhWAGIgCgCIgqADQAcABgEADQgEAEgggCIAGgBQgOgBgnAAIhAABIgbAEQgZAAgMgEQgKgGgHgCQgnAAgnADIg/AGIg6gDQgjgCAdgDQgMABgrAJQgdAHg5gGIAZgDIiXADQhYADgZgCQASgGhBgGQhLgGgJgFQADADgmACQgTgDgOADQAOABgEAFQgFADAmgCQg/ANhcAAIABgFIA9ACQgEgCAPgBIAagCQg4gBAHgFQAHgEg5AAIgKACIgRAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBgBAAQAAgCgQAAIgWAEQgVgEAkgCQAggCgOgCIBKgFQAogDgIgEQgkgBghAFQgiAGglgCIgJgCQgPABgMADIgSAEQgCgCgXgBIg6AHQgiADgXAEQA4gCAuACQAoACAtgBQhOADgFAGIABgFQhIAFgvgBIAcgDQgaABg2gCQgrgDgbAFIAUAAQgfABg1gBIhHAIQABgBgUgCQgPgBAMgCQgfgCgeACIgsAEQgRgBADgBIASgBQAsgCADgDQh0gDhJAHQAWABgBACIgvgCIgLADQgUgBABgCQAAgBATgCIgqACQgaACgPgDQAYgCAtAAQAsABAJgBQgqABg1gEQg0gFg9ACIAGgCQADgCgNAAQgfABACADQADAFgFABQAcgCAUABIAiAEIgKADQgBgBgOgBIgUgBIgFAFQACgEgYgCQgYgDgYACQAWACAEACQACABAFAFQgWADgZgDQgagDgZADIAUgCQAMgBgXgBQgRgBgLADIgUADQAMgCAKgEQAJgEANgDQAdAAAsgCIgrgEQAdgBAEgCQADgCAAgCQgqgDgXAEQgZAFgUAAQgMABAWABQAUAAgVACQgYgBgFACQgJADgbABIAKgDQgLgBgPABIgaACQgHAAABADIgBAFQgEAIg0AAQAGgCAAgBgAWeAqQgeACAcADIAzgBQAiAAABgDIABACQAUAAANgDQALgDAcACQABgFgdABIgUADQgNACgTAAQgGgBARgBQASAAgMgEQgEgBgpABQgfAAANgEIArABQAAgCARgCQAPgCgBgCQALgBAcACQAYABAPgDQAGgBAAgEQADgCAbABQAnAICHgDIAigDQgCgCgcAAQgYAAALgCIA0gBIgDACIAaAAIAYgCIgfACQgUACAFACIAaACIAZAAIgJACQAfABANgDIARgFQAbgEghgCQgpgDADgCICRgDQgZADAFACQAOABAGACQACABAcAAQgBgEAkgBQA0gCAMgBQANACgCABIgcAAQAEADAbAAIAnAAIAmgDQgZgDAxgDIABgBIhZgBQg2gBgUABIAJgBQgbgBg/ACQgzACgPgDQAAgBgGgBQgGgBAAgCIgsADIAKgCIhLABIACgBIhVAJIAAACIgJACQgPACgOgBIg1gFIBFAAQAKgFgsgDQALAAACgBQACgBgNgBIgVACQgRABAKACIh8gCQhPgDg4ADQASgBgXgCIgNgBIAbgBQgegDgWAEQgcAEgZAAQgCgBASAAQAVgBAHgCQgwgBhOAEQhPAFgsgBIgFgEIg4ACQAaAHAfAEQAuAFBYgBIgKAAQAfADBFgEQBFgEApAEQgoAEgoAIIAqgDQgHADAWAAIAvAAIgcAGQgOgBgagBIgXABQgBgBgigDQgsgDgbABQACABAoADQAfABgVAEQARgBASABIAlAAQgSACgCADQgCADgMABIA6gBIgjADgEAlTAAaQAHABAWABIAlACIAogDQAogEAMgCIgrgCQAhABBJgDQAAgCgagBQgagBgFADQgCgBAWgCQAQgCgUgCQAtgDBlAEIAGAGQAQABAOgDQANgDAXABQgcABAIADQAHADgTAAQAGABAEADQAGACAZAAQARgEAWACQAWADAPgDQAKABgIACQgGACAYAAQAggCAKgDQAEgCADgFQgYgBgYAEQgXADgSAAIBLgKQgNgBgMAAQAQgBAOgDIASgCQhSgBgEgCIAFgCQgKAAgRAAQgOAAgJABIg1ACQgaAAgGgCIAOgBIhuAAIAIAAQiaANh2gBQAMAEBSAEIgYAFIgOgEgAKMAXQAYAFAjgBIBBgCQAmgBAGgDQADABAVACQAeABARgCQAOgDAwgDQAjgDgMgBQg0ADgTgEIAsgBIgdgDQATABgMgJIg1ACIAFAAIg1ADQAcACAFADQAHACgfACQAAAAAAgBQAAAAAAAAQAAAAgBgBQAAAAgBgBQgCgBAKgBQgdgDgcAAQgiAAALAEQAfgDAEAFQADAEAWgCQgPADgWAAIgjABQARgCgQgDQgOgDgegBQg6AAgaABQAFACgDADQACACAZABQgkACgfgCIATgCQAKAAgBgBQgKgCgRgBIgXgCIgbABIAHABIgeADQAZgBgBACQAAABgGADQABgDgPAAIgaACIAfAFQgHABgYgBQgRgBAEACQA5ACBYgCIgYgEIATAAQAVAAAOACgAArAbQAaAAAMgBQAGgCAggDQAcgDACgDQADgBgXgBIgpgBQgBABgIABQAaACgHAEQgVgEgPAEQgVAEgSgBQgJADAdABgAG5ANQAIABgEABQAYABAEgBQAEgBACgCgAFDAIQAPAFh9AAIgMABQAfACBKgBIBPgLIA3gHQgHgBgOAAIgcABIAIACIi+gDQBnAIALAEgAiaANIAIgEIgYgBQAGAEAKABgAQfgeQgQgBgnACQgXAAACgDQAKgBAdgBQAdgBAKgCIgbgCQAYgCANACQARAEAcgCQgKgDAIAAQAWABALgCQgHgBgyAAQgmgBAKgEQAMgCA3AEQA0ADAWgEIgCABQAmAAAagCIAlgFQAQACAfgBIAEAEQgYgDgZADIgsAHQAOgCBAAAQAwgBAGgFIAaAFIAMgCQAPACgMADQgNAEgcAAQgKgBACgBIgdADQgUACgcgBIAXgCQheAAgaAFIgEgDQgJgFgVgDQgfADgGACQgDADgNAEIhSAEgAfhgjQgIgBAfgDQAggDAZABQgJgGgtAEQgrACgCgFQgvgBgiAEQgeAFgpgEQgBADgMABIgLABIARgFQAJgCgRgBQgQgCgHACQgLACgMAAIAogGIADABIAYgFQAaABgKAEQgGAEAjgCIgJgHIB/AEQBNADAhgCQgNADgCAEQgBAEAPACQgcgBhPABgABrgqIAAAAgAVtgyIgmgBIAigCIAAACIAmgBQgJACgRAAIgIAAg");
	this.shape_136.setTransform(37,172.4);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#11AA0C").s().p("AgaAAQAdAAAYAAIgjABQgDgBgPAAg");
	this.shape_137.setTransform(323.3,173.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#11AA0C").s().p("AAAABQgVgBgCAAIAGAAIApAAQAAABgQAAIgIAAg");
	this.shape_138.setTransform(-11.8,174.4);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#11AA0C").s().p("AAPAEQgoACgEgEQgEgCgoAAIgFABIAPgDIgxgBIA4AAQAKAAgEACQgDABANAAIAjgBQAKgCgXgBIAeABIAnAAQgGACAdABIAnABQgFADglAAIg+ACg");
	this.shape_139.setTransform(195.4,173.4);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#11AA0C").s().p("AgSALIAkgCQAKgCgcgDIhYgCIA1AAQAcgBAWACIAPgDQgagBhkABQAmgEAugCQAggDBCgCQATACgNACQgOACAMABQgRgBgNACQgOAAAFACQAPABAZgDQACABgHACQgGABAIAAIgqABQgbgBgCAEQAwABgbACIgmAEQgEgBgOAAg");
	this.shape_140.setTransform(431.6,169.7);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#11AA0C").s().p("AgKAAQAQgBAEABQAEAAgLACQAEgBgRgBg");
	this.shape_141.setTransform(286.2,170.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#11AA0C").s().p("AjSAMQgXgCAMgBIgeABQgCgBANgBQANAAAAgBIgOAAQAIgBgBgFQAFgCApAAQANACgZAAQgbABAHAEQAOAAAFgCIADgCQAdAAgDAEQAFgBAYAAQAZAAAIgCQAegBgHADQgGADAQAAIAVgHIA5ABQAqgBgDgFQgDgHAzgCQgJADAXAEQAYAEAjABIg2ABQgnABgVgBQAYADglAAQgqABAMADQAngEA7ACIgKABQANAAAkgDQAggCAaABQAQAAACABQABAAAAABQAAAAgBAAQAAAAgBABQgBAAgBABQAmgCAAABIgRAIQg4ABg7gBIhqAAQgEgBAOgBQiWgBgsAEIgogCg");
	this.shape_142.setTransform(-14.2,178);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#11AA0C").s().p("AikAAIhOACQAAgEBNABQBbABAZgEQAWAEAZgBQgCgFA0AAIBYgBQAJABgRABQgTACAMABIAtgDQAagBAYABIgHACQAmgCgEACQgJADACAAIgqAAIgmAAQgMADgZACIgxABQAEgCgQgCQgPgCADAAIhUAAQg2AAgaABIANAAQgcABgGADQgGADgTAAg");
	this.shape_143.setTransform(-89.8,176.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#11AA0C").s().p("AgDABIADgBQABAAABAAQABAAAAAAQABAAAAAAQAAAAgBABg");
	this.shape_144.setTransform(-31.8,175.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#11AA0C").s().p("AmAAWQgBAAAAAAQAAAAABAAQAAABABAAQABAAABAAIgrgCQgkgCADgDIAagEQANgDAbAAQAUAEAzgBIBZgDIAPgDQAIgCAYAAQgDACgiADQgXACAUADQAdACAdgBQAigCAJgEQgwABAHgGQAGgEgvAAIAcgBQASgCATgBQAWABghADQgdAEBBgBIALgHIBTABQhBACgQADIBSAAQAwABADADQAugEBrgKQBcgLBDgDQAhAAAEAEQAEAEgSACQAdAAANgDIAdgFQgXAEABABIASAFIAZgBIjVAeQgZAEhEgCQhEgCgPACQAMgCgQgCQgQgDgaABQgEABAQACQiDgIgyAKIAbgHIg9ADIgtAEQAJgBgCgBQgPgCgeACQgfACgMgBIAVgCQAHgCgtABQgTABgNACQgPADAXABg");
	this.shape_145.setTransform(-81.5,178.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#11AA0C").s().p("AAnAAIgVABIg4AAIBNgBg");
	this.shape_146.setTransform(-22.3,174.4);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#11AA0C").s().p("AAAAAIALAAIgVABQAKgBAAAAg");
	this.shape_147.setTransform(-31.4,176.1);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#11AA0C").s().p("AAAAAQAHAAgEAAIgGAAg");
	this.shape_148.setTransform(-242.7,171.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#11AA0C").s().p("AhPAHQAjgDALgDQATgEAJgCIgOAAIAVgCQgFACAIAAQALABgEABIBEgEIgNAEIg5AGIgQABIgeAEIgPAAIgcgBg");
	this.shape_149.setTransform(22.2,167.5);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#11AA0C").s().p("AhlAHIBigNIADAAQgTACAPADQANACAagBIgIAAQAGAAASAAQAWgBAJABQgRAAAPABIAWADIiYAAQAFgCAKAAQgSAAgPADQgNACgOAAIgGAAg");
	this.shape_150.setTransform(-20,175.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#11AA0C").s().p("AhRAJQAigCADgCIgYABQgQgBAMgCQARgCAAgBIA3ABIAfgFQgfgCACgBQAGgCgLgCQAGABAwAAQApAAALAEIhAAHQAeAAAIgBIACAIIAJgBIgOACQgHACgGAAQglgCgwgBQgRADgPAAIgtABQgIgCAcgBg");
	this.shape_151.setTransform(446.9,170.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#11AA0C").s().p("AhEAEQgLgBgNABIgTgBQAkgBAJgDQAIgFAvAAIgJABIgDACQAhADAdgEIgEACIBNAAQgHACgiAAQgjAAgFAAIArABIhIAEQAVgCgNgCQgLgBgSABQgDAEgHAAIgjACQAHgBgLgCg");
	this.shape_152.setTransform(467.3,170.5);

	this.addChild(this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.shape_62,this.shape_61,this.shape_60,this.instance_2,this.instance_1,this.instance,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-388.9,-176.4,867.6,357);


(lib.jabalina1 = function() {
	this.initialize();

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.2,0,0,4).p("AAEAAIgEAAIgDAA");
	this.shape.setTransform(-301.7,165.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(0.2,0,0,4).p("AgBABIADgB");
	this.shape_1.setTransform(-244.8,163.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgQMlQgDgFgDgBQgBgLgKgIQgNgKgCgEQAAgKAFgNIAGgUIAIgKIAFgfQgCgkAHggQAAgPAGgPIALgbQACgHAJgQQAJgPADgKQADgDABgCQAAgGACgIQAEgkgFgWIgDgMQgCgIgCgEQgCgTADgpQgCgCgFAAIgJgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBIABgDQADgIAAgGQAGgTAVgyQARgqAIgcQAHgLADgRQACgDACgGIAEgJQgFgogGggQgHgQgPgSIgagdIgSgXQgNgJgIgDQgRAFgNABQAAAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAQgYADgMAAIgRgBIgQAAQgJAAgOAEQgQAFgGAAIgFgFQgDgEgBgDQgFgFgEgCQgCgDgHgGQgGgFgDgEQgMgRgCgGIgTgXIgSgYQgGgJgNgOIgUgXQgGgEgPgQQgHgDgNABIgVACQgKAHgJALIgRAUIihC9IAAAAICljEIgTgTIiGChQgqAzgdAeQgJANgUAaQgRAXgEAXQAJAAAIgIQAIgKAEgDIAZgbQAGgIAKgJQgFAJgOARIgYAXIgMANQgIAGgIABQgDgHADgIIAGgOQAGgNAIgLQATgZAhgnIA1g+ICNioQgGgJgHgEQABgGAGgEQAGgGABgDQAIgDAKgLIgBgEIASgHIAAgFQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAOgEAFACQBmh2CBikIA5hHQAjgrAUgeQAmg0ASgTIAfghIARgQQAKgJAJgEQABAFgCAHIgGAKQgPAcgWAdQgnA1gPASQiRDAi8DgQAAABAAAAQAAABAAAAQAAABgBABQAAAAgBABIgCAEIAHACIAYATQAUAeAzAgQASAKAWAQQAFAHAOAIQAOAJAFAGQACgBADgDQAGAAAOgFQANgEAJAAIAfAAIAYgUQAPgKAPgCIAWgDIALgHQAHgDABgFQgBgHgFgLIgHgSIgegXQgLAIgPgFQgPgFgDgNQACgHgEgJQAAAAgBAAQAAAAAAAAQgBABAAAAQgBABAAAAQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQgDgGgDgPQAAAAAAAAQgBAAAAABQgBAAAAAAQgBABAAABQgBABAAAAQgBABAAAAQgBAAAAAAQgBABAAgBQgCgNACgIQAAAAAAgBQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAAAQAEghALgNIgBgCQAAgBAAAAQAAAAAAAAQAAAAABAAQAAgBAAAAQAUglAogSIAIgEIAHAAQAAgBAAAAQAAAAAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQABAAAAgBQAHAAAHADQAHAEADAHIAIAEIAOgCQADABAFAEIAFABQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQgBAAAAAAIgEgBQABAFAGADQAAAGAEAFIAHAIQgBAGACAGQACAHAAAEQAIATAPAsIAAALQgDAKAEALIAHARQAJgEADgCIADgGIANgNQAFgBAJgGQAbgHALgGQAFgDAFgGIAKgKIAJgKQAGgGADgEQAKgEARgMIAegOQATgEAMgJIAKgNIADgFQAMgWAagXIAbgSQARgMALgFIARgJQAKgFAGgEIAOgLQAOgLADgGIADgCIADgCQAUgdAbgPQAMABANgEIAXgHIAFgDIAFgCQAEACgBAGQgBAFgDADQAIABALgCQABAJgIAEQgEADgLAEQgDgBgGABIgJAAQABAIgIAVQAMAHgBAKQgFAIgHAAQgFgBgLABQgEADgGAHIgKAKIgWAHQgNADgHAFQgSAPgkAvQghApgZARQgOAHgWASQgFAKgSAUIgMAOIgNAOQgHAGgPALIgYARQgFAJgBARQgBAPADAOQgBAVADAWIgBAEIAIA6QAEAhAGAVQALAeACAlQADAFgBAIQADAEACAGQANAUAQATQAXAbAkAzIAcAoIAGAHQAAADgDADIgDAEIALAXQAJAOADAJQAEAHAGASQAFARAEAHQAGAXAQAUQgBADABAFQABAEgCADQALAYANA+IAOA+QAIAlAIAXQABASAJAdIAEgGQADgDAEAAQAEADABAMIAKAIQAGAEAGgCIAGAGQADAEAFgCIAAABIgGAIIgFAJQAAAGAEAAQgFAFgEgKIgHgCIgEACQAAAAgBAAQAAABgBAAQAAAAgBAAQgBAAAAgBQgCgKgFgBQgIAGgFgFQAAgFADgDQgEgFgBgDQgKADgRgBQgPgBgLgEIgFACIgFAVQgDANABAKQAOAGAdAAIAugBQAyAJAugJQABgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAIgFgFIgIgIIgJgEQgFgDgEABQgDABgEADQgDAEgDAAQgMAAgOgCIAHgNQAFgHgDgFIAAgBQADAAAAAGQAGAGAQADQATAFAFACQAOAOAEAGQACAIgCAEQgBACgFACIgHABQgPAGgqgDIAAgCIAaABIAWgEIALAAQAHgCAAgFQgDgDgGAAIgKABIgWACQgYACgXgCIgQgDIgZAAQgaAAgfgEQgDACABAEIgBAAQgDgQADgRQAEgRAIgKQgEgQAAgJIgGgWQgFgMgEgHQgDgOgMgPIgTgYQgNgTgFgMQgIgTgDgTQABgHgDgOIgBgKIgCgIQgBgCACgDQgEgFgCgHIABgHQgCgJgEgJIgKgPIgdgaIgegaQAAAAgBAAQAAAAgBAAQAAAAAAABQgBAAAAAAIgDABIgQgWQgNgTgDgEQgVgVgVgPIgOgOQgIgJgHgDIgCgFQgKgBgGAGIgIAYQgFAOgFAIIgHAfQgFAUgFAKQgCABgDgCIgFgBQgCACgCAIIgCAbIgEAaIgGAYQgQAigJAPQABAFgEAGQAAAegGAVIgVAiIgEAGQgRAhgQAqQgEAGgGAXIAEAHIAEAGQgCAQAOAKQANABAHAIQAEAEADAHIAFAMIAFAGQACAEgCAEQgLASgkABQgfAAgVgMgAgDMlIAOADQATAEAZAAQANgEAFgEQAIgGgCgJIgBgBQgWALgEABQgVACgMAAQgUgGgKgBQAAAHAIADgAgLMLIABAJQAHAEAeAFQAfADASgOQgEgSgLgIIgJgDIgFgDQgFAAgMADQgHABgWAJQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAABAAAAIgCABQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBAAAAIACgEQABgEgDgDQgDgDAAgCQABgHgCgMQgHABgHgEIgLgFQgJAIgEAdIAOAFIAGAIQAEAFAEABQAFAAAFgEgAgsL5IAAABQAAAEAIACIAHAHQAFAEABAEQAGAIADgGQAEgHgJgBIgOgPIgFAAIgFgCgAAaLtQgHABgFACQgHAEAAAEQAGAAANgFIAIgBQAFAAABgEQgEgCgFAAIgFABgAADLtIACAFIAKgFIALgEIgGgBQgIAAgJAFgAAXLfIABAAIgOADQgIACgCADQADACAIgCIANgDQAIAAABgCQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBAAgBAAIgFgBQAFgCAAgBQAAgPgSAFQgRAEAFAOIALgDIAKgCIACABgAJQLiQARAGAFgHIgIgDIgJgEIgFAIgAJALLIgHAHQgHAHAAAGQABAAAAABQABAAABAAQAAAAABgBQAAAAABAAIADgDQAJgLAAgGIgBgBIgCABgAJBLWIgEAFQADADAFAAQABgCACgDIAEgGIgHgCIgEAFgAIiLQQgDAFABAEQAGgBAFgHIAHgOQgDgCgDACIgEADQAEgIgFgKIgFAAQgGAHAHAQQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAIACgCIgFAIgAItLTQACADAEAAIAGgKIgDgBQgFAAgEAIgAAYFeQgCAFAAAIIAAAOQAAATAHAnIAFAZIgCARIgGAjIgEACIgCAIQgVAhgNApQAAAGgCALIgDARIgDAfIABARIgDAUQgBAMAAAHIALAFQAGACAHAAQAIgJAOAAQAEgEABgLQAGgLABgJQALgSAEgQQAMgZAdgyQAFgSABgIQgEACgEAJQgDAIgEACIALgWQAFgNgBgPQAHgKACgKQAFgFAGgLIAJgSQABgGADgEQAEgQADgZIAFgqQgjgOhQgHQAAAAAAAAQAAAAAAABQAAAAAAAAQgBAAAAABgAGcIpQAGAJACAGIAPAWQAJANAIAHQATAeANA1IgBAGQADACABAFQAoAJALgKIgFgSQgEgMABgJQgGgegHgTQgXhngNgyIgFgCIgCgJIgCgJQACgOgJgQQgLgUgBgHQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQgNgwgdgqIAAgBQgPAOgeAYQgfAagOAMQANAOAeAVQAZAVAGAYQABAKAGANQAGAOABAGQAAAAAAAAQgBgBAAAAQgBAAAAgBQAAgBgBAAQAAgBAAgBQgBAAAAgBQAAAAgBAAQAAgBgBAAQAGAxAGAUgABGCtQgFAQgGAIQgFAYgVAvQgTAsgFAdQAVAEAMABQANABAYAEIAkAGQAMAFAaAHQAHgVACgTIAMghQAIgUAEgNQAJgIAWACQgBAEgGABIAkAhQAZAVALAMIAOAVQAJAMAHAGQAVgOAUgTQANgJAZgWIANgKIAFgGQAEgEABgDQgBgEgCgDIgEgHIgEgDIgZgnQgPgWgNgOQgIgNgOgPIgYgbQgKgSgFgGIgCABQgwAcg5ALQhJADgdgGQgDAGgHAVgAAdiTIgDAhQgBAVgEAKIgGAYQgEAPAAAKIABAXQACAEAFAEQAIAKAQATIAYAdQADAEADALQAAAJAFAaQADAWAAAPQAKAFASAAIAggBQAvADAtgRQAkgNATgPQgCgIABgMIgDgQIgDgQQgFgPgMg0QABgLgDgQIgFgZQgBgqgEgXQgQAAgWgIQgcgTgMgNQgTgUgHgaQAAgIACgGIgCAAQgCAEgBAKIgBAQIgCgKQAAgHgBgDQgDAIAAANIgBAVQgDAJgDATIgPAbIgCgBIACgFQAQgRABgjQgGgXgNgbQgDAEgCAMQgDAFgNAEQgVAJggABIgFgBIABAFQACACgBADQADAFADAKIAHAQIADAUQACANADAGIgCAAQgHgKABgKIgDgLIgCgKQgFACABALQABANgBAEIgFgWQgFABgCAEgAk2i8IAOAQIANAQIAMALIA3BGQAOAXAHAHIAgAcQALgCAYgHQA8AHA2gQQALAIAKAHIAAgTQgZgXgcAFQgZAMgggHIgKgEQgHgBgCgDIACgCQAEABAHADIALAFIALgBQAIAAAEACIACgBIACABQAegJAIAAQAKgBALAFQAGADAJAGQABAFADABIACgFIAAgGIACgDQANglABg1QgZABgPAFQgJAFgaAXIgiAAQgNABgQAGIgYAKQABgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAIgLgKIgEgBIgggdQhIgpghgsQgGgBgGgGQAAAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAQgBAAAAAAQgOgBghAIQgFgCgEgIQAKgFABgIQgJAAgMAHQgBAEADAHQADAHgBADQACACACAKQABAJAFAAIABAEIAWAAIAEAAQAMAAAHADgADmi/IgDAEQgFAJgCAYQgCAHAAADQALAGAXABIABgcQABgRAEgJIAsggQAmgmATgdIAEgEIALgGIAAgDQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAbgHASgYQAWgTAWgiQAbggARgMQAKgFAXgFQAGgDAIgJQAHgKAGgDIAKgBQAHADAEgCQAEgIgHgFQgIgEgGAFQAAgBABAAQAAgBAAAAQAAgBgBAAQAAAAgBAAIgMAFQgHACgFgEIgDABQAAAAAAABQgBAAAAAAQAAAAgBAAQAAgBgBAAQAKgZAHgLQAGgDARgFQAPgFAGgFIAGgCIADgEQACgDgBgDIgDAAIgRAGQgKADgFAEQgDgBgGAAIgJABQgEABgGADIgIAFIgSATQgLALgGAJIgZAVQgQAMgMAHQgEAAgFADQgFAEgEAAQgTAMgPALIgJAFIgFAFIgGAEQgPAMgNAWIgKAQIgRAOQhKAXggArQgFADgFAHQgIAFgFACQgTADgIAEQgHAFgDABQgIAJABANQAHAZARASQAOAPAZAOQACgGAAgEIAFgVQACgOAGgEQAAAAABABQAAAAAAABQAAAAAAABQAAAAgBABgAmTiuQALANAIADQADgCAAgCQgNgLgFgHQgDACgBAEgAmNi3QAEAIAPAJIAGgGQADgDAAgEIgPADIgGgIQAAAAAAgBQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAgBABQAAAAgBABgAmSjPIgCAEQADAGAPAPIAGgBQgCgEgIgJQgGgIgDgGIgBgBIgCAEgAmIjXQgDAEAAADIASAYQAGABACgFQgGgPgMgNIgCgEIgDAFgAmAjcQACAGAHAJQAIAKACAGIAGgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBgBgBAAIgDgDQgBgXgIgMQgIAEgCAHgACCjWIgCACQABAHAFAJIAAgKQABgIgCgDIgDADgAASjXQAMAKALADQAtgCAVgRIAGgeIAAgPQgBgCAAgDQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQgIgdgMgaQgFgKgEgDQgIgTgggLIAAgEIgHACQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAgBAAIgDgBQgBABgCAFQgCAEgDABQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgFAJQgRAWgEAIQgLATABAZQACAIAFALIAIATQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAIgKgHQgGgEgJABQgHAGgDAFQgBAOAQAGQAQAFAJgKQAEADAOALgAlXj4IABADQgJALgDAHQAGACAJgCQALgEAEAAQAMgMAKgPQgIgFgLgMgAk8jpIAMAAQgCgDgFgBIAAAAQgEAAgBAEgAlgj8QgEAAgBADQACAEAGgCQAFgBAAgFIgIABgAgqj8QAHgGAKgCIAIAAIAHAFIgCgIIgDgEIgFgNQgBgPABgDQAAgWASgaQAMgMAGgQIAAgEQABgBAAgBQAAAAABAAQAAgBABAAQAAAAABAAQABABABAFIAEgEQACgDACAAIADABQAAABAAAAQABAAAAABQAAAAABAAQAAAAAAAAIAEgBQAAgBABAAQAAAAABAAQAAAAABAAQAAAAAAAAIgBAEIABAAQAKADARAJQAFAEAGAIIAJAPQAAgQgOgMQgCgDABgDIgEgDQgCgBgBgDQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAgBgBQgEgDgHAAQgHAAgEADQgEgFgGgBQgCgGgMgGQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAAAQgFAAgGAEIgKABQgjASgQAbIABAEIgMATQgGAMgBANQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAAAQACADgEAKQgDAKACAGQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQADACACAHIACAMQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAQAAgBABAAQAAAAABgBQAAAAAAAAQABAAAAAAQADABAAAHgAk/kVQAIALANAFQABgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQgEgDgGgFIgJgJgAB3sqQgYATgkApIgOAPQgbAhgNARQh0CaiTCzIgoAyQgLANgCAEQAGAJANAHQCIikA0hDIBch1QAzhDAlg1IANgRIAMgSIALgSQAHgLADgKIgBAAgAIpnsQAAAFAGADIAKgDQAGgCAFABQABgHACgDIgGADIgEAEQgIgCgFAAIgHABgAInnkIgBgCQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAABgBAAIAAABIAEABIAAAAgAIsn6IgBAFIgCAFQAOAAAHgDQAKgEABgKQgLABgEAFIAAACIgBACQgEgBAAgDIgJABgAJXoQQgFAEgNAFQgOAFgFADQACgBADABQAZgJAFgBIAOgBQAIgBAFgDIACgDQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBgBAAIAAAAg");
	this.shape_2.setTransform(-304.2,91.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#934607").s().p("AhzB2QAVgaAJgNQAdgeAqgzICEihIASATIijDEIgRAUIgCAEQgBAAAAAAQgBABAAAAQAAABAAAAQAAAAAAABIgBAAIgCACIgBABIgCADIgBABQgBABAAAAQAAAAAAAAQgBAAAAABQAAAAABAAIgBABIgBAAIgCADIgBABQAAAAAAAAQgBABAAAAQAAAAAAABQgBAAAAAAIAAABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAABAAIgBABQgKAJgGAIIgZAbQgFADgHAKQgIAIgJAAQADgXARgXg");
	this.shape_3.setTransform(-356.8,90.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFC9B6").s().p("AgLgFIACgEIACgEIACABQACAGAFAGQAIAJACAEIgHABQgNgOgDgFg");
	this.shape_4.setTransform(-343.5,71.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF7F00").s().p("AgKgEQABgEADgBQAGAGALAJQgBACgDACQgHgCgKgMg");
	this.shape_5.setTransform(-343.5,74.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFC9B6").s().p("AAEARIgPgVQAAgEACgDIAEgGIABAEQALANAFAOQgBAEgEAAIgDgBg");
	this.shape_6.setTransform(-342.5,71.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFC9B6").s().p("AgCAFQgHgHgCgHQACgGAIgEQAGALABAWIAEACQAAABABAAQAAABAAAAQABABAAAAQAAAAAAABIgGABQgBgHgHgJg");
	this.shape_7.setTransform(-341.5,70.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#D14D13").s().p("AgMgGQACgEAFAEIAFAGIAOgCQgBACgDAEIgFAFQgNgJgEgGg");
	this.shape_8.setTransform(-342.6,73.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFC9B6").s().p("AgWBVQgHgHgOgXIg3hEIgMgLIgNgQIgOgQQgIgDgPAAIgWAAIgBgEQgFAAgBgJQgCgKgCgCQABgDgDgHQgDgHABgEQAMgHAJAAQgBAIgKAFQAEAIAFACQAhgIAOABQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQAAgBABAAQAAAAAAAAQAGAGAGABQAhAsBIApIAeAbIAEABIALAKQAAAAAAABQAAAAAAABQgBAAAAABQgBAAAAABIAYgKQAQgGANgBIAiAAQAagVAJgFQAPgFAbgBQgBAzgNAlIgCADIAAAGIgCAFQgDgBgBgFQgLgGgGgDQgLgFgKABQgIAAgeAJIgCgBIgCABQgEgCgIAAIgLABIgLgFQgHgDgEgBIgCACQACADAHABIAKAEQAgAHAZgMQAcgFAbAXIAAATQgMgHgLgIQg2AQg8gHQgYAHgLACIgegcg");
	this.shape_9.setTransform(-321.5,78.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFC9B6").s().p("AgFAAQABgBAEAAIAGgBQAAADgFABIgCABQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBg");
	this.shape_10.setTransform(-339.4,66.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D14D13").s().p("AgYAXQACgHAKgLIgBgDIATgZQALAMAIAFQgKANgMAMQgDAAgKAEIgJABIgFgBg");
	this.shape_11.setTransform(-337.1,66.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFC9B6").s().p("AAAAAQADAAACABIgJABQAAgDAEABg");
	this.shape_12.setTransform(-335.3,67.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF7F00").s().p("AgKgEIAEgFIAHAJQAFAEAFACQAAAAAAABQAAAAgBABQAAABAAAAQgBABgBAAQgKgFgIgJg");
	this.shape_13.setTransform(-335.1,64.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFBF00").s().p("Ag4BBQAAAAgBAAQAAABgBAAQAAAAAAAAQgBABAAAAQgBABAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAIgCgLQgCgHgDgCQgBAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBAAAAAAQgCgHADgKQAEgJgCgEQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQAAAAgBAAQABgNAGgMIAMgRIgBgEQAQgaAlgSIAIgCQAGgDAFAAQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAMAFACAGQAGACAEAFQAEgEAHAAQAHAAAEAEQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAAAABQABACACACIAEACQgBADACADQAOANAAAPIgJgOQgGgIgFgEQgRgJgKgEIgBAAIABgDQAAAAgBgBQAAAAAAAAQgBAAAAABQgBAAAAAAIgEABQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAIgDgCQgCABgCACIgEAEQgBgFgBAAQgBAAgBAAQAAAAgBAAQAAAAAAABQgBABAAAAIAAAEQgFAQgNAMQgSAZAAAWQgBADABAOIAFANIADAFIACAIIgHgGIgIABQgKACgHAFQAAgGgDgCg");
	this.shape_14.setTransform(-303.1,58.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAFAJQgBgFgEgEIgGgFQgIgCAAgDIAAgCIABAAIAFABIAFABIAMAMQAJACgEAGQAAABgBABQAAAAgBAAQAAABAAAAQgBAAAAAAQgDAAgDgEg");
	this.shape_15.setTransform(-307.2,169);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#015353").s().p("AgBAWIgGgIIgPgFQAFgbAIgJIAKAGQAHADAHAAQABALgBAHQABAAAEAEQADACAAAEIgEAEQAAABgBAAQAAABgBAAQAAABAAAAQgBABAAAAIgBAFQgGAFgFAAQgEgCgBgEg");
	this.shape_16.setTransform(-306.2,166.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFC9B6").s().p("AgQBKQgOgLgGgDQgJAKgQgFQgQgGABgOQADgFAHgGQAJgBAGAEIAKAHQAAAAAAAAQABAAAAAAQAAgBABAAQAAgBAAgBIgIgSQgFgLgCgJQgBgWALgUQAEgIATgWIAFgJQAAAAAAAAQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQADgBACgEQACgFABgBIADABQAAAAABABQAAAAAAAAQAAAAABAAQAAABABAAIAFgDIAAAEQAgALAIATQAEADAFAKQAMAbAIAbQAAAAAAAAQAAABAAAAQAAABABAAQAAABABAAQAAAEABACIAAAOIgGAeQgVARgtACQgJgCgMgLgAg2AvQgEAFgCAFQAEAEAIgBQAIgCgCgGQgJAGgFgDQABgCADgCQADgCAAgDQgEgIgLACQgLACABAMIAEABQgCgHAHgEIAEgBQAEAAADAEgAAmAmQgRAGgBAGQADABADgDQADgDACgBIANgFQAFAAAGgCIAEABIADgCQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQgPAAgKAFgAANgpQAEAHAIAIIANAMQAKAGABAEQgBAEgHABQgHAEgBAEQASgHACgJIgPgNQgLgJgFgFQgDgHgEgCQgBAAAAABQgBAAAAAAQAAAAAAABQAAAAAAAAgAgQgZIAEAJQACAGAFABQACgFgDgDQgEgFAAgDIgCgBIgDgBIgBACgAgMgnIgGABQgEADgDAGQgFAJAEACQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIABgEQABgFAGgDIALgEIgEgBIgCAAgAAbguQADAKAHADQACgCgCgFIgEgHIgDAAIgDABgAAXg6QgFACAAAEQACAAAFgDQAFgEAGABIgCgCIgDgBIgIADg");
	this.shape_17.setTransform(-300.6,62.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAAAHQAAgFADgDQgDgHgGAEQgHADADAGIgEgBQgCgKALgCQAJgDAFAJQgBACgCABQgEACAAACQAEADAJgGQACAFgIACIgEABQgFAAAAgDg");
	this.shape_18.setTransform(-306.5,67.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFC9B6").s().p("AhHC5IgLgFQAAgHABgMIADgTIgBgSIADgfIADgRQACgLAAgFQANgpAXggIACgHIAEgDIAGgjIACgRIgFgYQgHgoAAgTIAAgNQAAgJACgFQAAAAAAgBQAAAAABAAQAAAAAAAAQAAgBAAAAQBOAIAjANIgFAqQgDAZgEARQgDADgBAHIgJARQgGALgFAGQgCAKgHAJQABAPgFAMIgLAVQAEgCADgIQAEgJAEgCQgBAJgFARQgdAygKAZQgEAQgLASQgBAJgGALQgBAMgEAEQgOgBgKAKQgHgBgGgCgAgGAaIgFgIQgDgFABgGIAFgRIgBAAQgNAeAQAGgAAphBQABgBAAAAQABgBAAAAQAAgBAAAAQAAgBAAgBIAAgEQACgHAAgFIgBgBIgDAWgAgPhJQgDADAAAEQAFgDAFgIQgDABgEADg");
	this.shape_19.setTransform(-298.5,145.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVAIIgQgEQgIgCAAgFQAKAAAWAEQAMABATgCQAEAAAWgKIABAAQACAKgIAEQgFAEgNADQgXAAgTgDg");
	this.shape_20.setTransform(-300.8,171.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#015353").s().p("AgDAVQgggFgIgEIAAgJIAHgFIABgFIADgBQABgBAAAAQABAAAAAAQAAABABAAQAAAAAAABQAWgJAHgBQAKgDAFAAIAFADIAIADQALAIAFAQQgPALgYAAIgIAAg");
	this.shape_21.setTransform(-301,169.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgBgHQAQgFABANQgBACgEACIgCAAQgEgBgGADIgMACQgGgLASgFg");
	this.shape_22.setTransform(-302.7,164.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgKAAQAKgGALADIgLADIgJAEg");
	this.shape_23.setTransform(-302.7,166.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgHAAQADgEAEgEIAFgBQAEAAACABIgLAEQgFADgBADIAAAEQAAABAAAAQgBABAAABQAAAAAAAAQAAABgBAAQgEgBAFgJg");
	this.shape_24.setTransform(-302.4,59.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A0C6").s().p("AhDC5QAAgPgDgWQgFgaAAgJQgDgLgDgDIgYgeQgQgTgIgLQgFgEgCgFIgBgXQAAgIAEgOIAGgZQAEgKABgUIADgiQACgDAFgCIAFAWQABgEgBgNQgBgKAFgDIACALIADAKQgBAKAHAKIAHAIIAOAGQACgBAGAAQAFABACgBQANgEALgPIAPgbQADgTADgJIABgVQAAgNADgHQABACAAAIIACAJIABgQQABgKACgEIAAAAQAAAGAAAIQAFAbATATQAMANAcAUQAWAHAQAAQAEAYABApIAFAYQADAPgBALQAMA2AFAPIADAQIADARQgBALACAIQgTAPgkANQgtARgtgCIggAAQgSAAgKgFgAAbBzQADARgEAKIABAHQADABADAHQACAGADAAQgFgLgEgFQgBgEAEgNIgFgUQgDgOgEgFIAHAYgABdCLIgMgoIgCAAQAGATAIAVgAguB4QABgcAEgIIgBgBQgIARAEAUgAh/AMIAPAIQAJAFAJgBQAMABAagEQgDgCgGABIgLABIgSABQgIgBgIgEIgOgIIgDADgAA4gpIgMAVQAUgaACgVIgCAAQgBAMgHAOg");
	this.shape_25.setTransform(-289.2,87.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAAACIgEgHIABgCIACABIABABQAAADADACQADAEgBAEQgFAAAAgGg");
	this.shape_26.setTransform(-301.7,60.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgQAEQADgEAIAAIAMgDIAAAAIACAAIAFAAQABAAAAABQABAAAAAAQAAABAAAAQABABgBAAQgBABgHAAIgMADIgHAAIgFAAg");
	this.shape_27.setTransform(-302.5,165.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgPAFQAAgEAHgBQAFgDAFgBQAIgBAGADQgBACgFAAIgIAAQgKAFgGAAIgBAAg");
	this.shape_28.setTransform(-301.8,167);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFC9B6").s().p("AgBA9QgGAAgHgEIgLgGQgCgFgCgNIgEgVIgGgNQgDgLgDgFQAAgDgBgCIgCgFIAFACQAggCAUgIQAMgFAEgFQACgLADgEQANAaAFAYQAAAggRASIgBAEIgIAIQgOAJgIAAIgBAAg");
	this.shape_29.setTransform(-295.8,74.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgBAHQgJAAgJgEIgPgGIADgDIAOAGQAIAEAIABIAQgBIALgBQAGgBADACQgXADgMAAIgBAAg");
	this.shape_30.setTransform(-298.5,89);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AAAAAQABgDAEgBQgFAFgDAEQgBgEAEgBg");
	this.shape_31.setTransform(-299.9,138);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AABgRIABAAIgDARQgBAGACAFIAEAHQgOgFALgeg");
	this.shape_32.setTransform(-299.7,146);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAHATQAHgEABgDQgBgFgKgFIgLgLQgIgIgEgGQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAgBQAEACADAHQAFAGAJAIIAQAMQgDAKgRAIQABgFAGgDg");
	this.shape_33.setTransform(-297.2,60.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgWAEIgGgGIABAAIALAEQAHADAGABQAIABAPgJIAIgHIABABQgKANgNAEQgDABgDgBQgFAAgDABIgOgGg");
	this.shape_34.setTransform(-295.5,79.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgDAAIAHgDIADABIACACQgGgBgDABQgFAEgCAAQAAgEAEAAg");
	this.shape_35.setTransform(-297.9,56.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgUAIQABgFARgFQAIgEAPgBQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAIgCACIgEgBQgGADgGAAIgKADQgCAAgEADQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_36.setTransform(-296.4,66.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgEgFQACgBACAAIAEAGQACAEgCADQgFgDgDgJg");
	this.shape_37.setTransform(-297.3,58.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAAgJIABABQABAEgCAFIAAAFQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAgTg");
	this.shape_38.setTransform(-294.1,137.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AABgRIACABQgDAIAAAaQgEgSAFgRg");
	this.shape_39.setTransform(-293.7,97.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#DD781D").s().p("AjYD+QACgEALgNIAogxQCTizB0iYQANgSAbghIAOgPQAkgoAYgTIACgBIABAAQgDAJgHALIgLATIgMASIgNARQglA0g1BEIhaBzQg0BCiICkQgNgHgGgJg");
	this.shape_40.setTransform(-313.7,37.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFC9B6").s().p("AgCgEIACgCIACgDQABADAAAGIgBAKQgDgJgBgFg");
	this.shape_41.setTransform(-291,70.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFC9B6").s().p("AiiDEQAAgDACgHQACgYAFgJIADgEQAAgBABAAQAAgBAAAAQAAgBgBAAQAAgBAAAAQgGAEgCAOIgFAVQAAAEgCAGQgZgOgOgOQgRgTgHgZQgBgMAIgKQADgBAHgFQAIgEATgDQAFgCAIgFQAFgHAFgDQAggrBKgXIARgMIAKgQQANgWAPgLIAEgFIAFgEIAJgGQAPgLATgLQAEgBAFgEQAFgDAEAAQAMgGAQgNIAZgVQAGgJALgLIASgTIAIgEQAGgEAEgBIAJgBQAGAAADABQAFgEAKgDIARgFIADAAQABADgCACIgDAEIgGACQgGAFgPAFQgRAFgGADQgHALgKAaQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAIADgBQAFADAHgCIAMgFQABAAAAAAQAAAAAAABQAAAAAAABQAAABAAABQAGgGAIAFQAHAEgEAIQgEACgHgDIgKABQgGADgHAKQgIAJgGADQgXAFgKAFQgRAMgbAgQgWAigWASQgSAXgZAHQAAAAAAABQgBAAAAAAQAAAAAAABQAAAAABABIAAACIgLAHIgEADQgTAegmAlIgsAgQgEAJgBARIgBAdQgXgCgLgGgAg9AyIgKANQgHAJgDAFIgXAUQgOAKgOAGIgIAFQgFADgCADQgBAKACACIAAgIQACgDADgCIAFgEQAbgMAegdIALgPIAHgGQAEgEgBgEIgCAAIgBABg");
	this.shape_42.setTransform(-266,57.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AADAeQgDgHgBgBIgBgHQADgKgCgPIgHgZQAFAGADANIACATQgCANAAAEQADAEAGAMQgDAAgDgGg");
	this.shape_43.setTransform(-286.2,100);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AAAACQAHgMACgMIABAAQgCAVgRAYIAJgVg");
	this.shape_44.setTransform(-283.6,82.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgrAfQACgDAFgDIAIgFQAOgFAOgLIAVgSQADgFAHgIIAKgOIABgBIACAAQABAEgEAEIgHAHIgLAOQgcAcgbALIgFAEQgDACgCADIAAAIQgCgCABgKg");
	this.shape_45.setTransform(-276.4,66.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgFgTIABAAIAKAnQgGgUgFgTg");
	this.shape_46.setTransform(-280.5,99.2);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFC9B6").s().p("AA6DMQgBgFgDgCIABgGQgNg1gTgeQgIgHgJgNIgMgWQgDgGgFgJQgHgUgFgvQAAABAAAAQABAAAAABQAAAAABABQAAAAABABQAAABAAAAQAAABABAAQAAABABAAQAAAAAAAAQgBgGgGgOQgGgNAAgKQgHgYgZgVQgegVgNgOQAOgMAfgaQAfgYAOgOIAAABQAcAqAMAwQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQABAHAMAUQAIAQgBAOIABAJIACAJIAGACQAMAwAXBnQAHATAGAeQgBAJAEAMIAGASQgHAGgOAAQgMAAgTgFgAAEALQACAJAFANQAHAPACAHIAEAYQAEAOADAJQgBgJgIgkQgCgJgGgPIgJgXIgBABg");
	this.shape_47.setTransform(-261.3,141.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#047391").s().p("AheB2IglgGQgYgFgNgBQgMAAgVgEQAFgeATgrQAVgtAGgYQAFgIAGgRQAGgUADgGQAdAGBJgEQA4gKAvgcIACgCQAFAGAKATIAYAbQAOAPAIANQANAOAPAWIAZAkIAEAEIAEAGQACAEABAEQgBADgDAEIgGAFIgMALQgaAWgNAJQgUASgUAPQgIgGgJgMIgOgWQgLgLgZgVIgighQAEgCABgDQgUgCgJAIQgDANgJAUIgMAgQgCAUgHAVQgagIgLgEg");
	this.shape_48.setTransform(-283,115.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AAGAXIgFgXQgBgGgFgPQgGgOgBgIIABgCIAJAXQAEAQACAHQAIAjABAKQgEgJgDgOg");
	this.shape_49.setTransform(-259.5,147.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AAdAEIguAAQgbgBgPgDIgBgFIABAAQAHAEAKABIAVAAIAYABIAcgBQAIABATAEIADAAIAAABQgUAAgMgCg");
	this.shape_50.setTransform(-251,169);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgFACIAFgHIAAAAQAAAAAAgBIADgDQADgCACACIgHALQgCAIgGABQgCgEAEgFg");
	this.shape_51.setTransform(-248.8,163.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFC9B6").s().p("AAAAAIAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABABIgBgBg");
	this.shape_52.setTransform(-249.2,42.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAAALQgHgOAGgHIADAAQAFAKgEAGIAAABIgBABIgCACIAAABIAAAAg");
	this.shape_53.setTransform(-249.3,162);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFC9B6").s().p("AgNADIACgDIAIgBQAAABADABIAAgBIAAgBQAEgFALgBQgBAIgJAEQgGADgNAAIABgFg");
	this.shape_54.setTransform(-247.2,41);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFC9B6").s().p("AgNAAQAHgBAKABIAFgCIAFgEQgBAEgBAFQgGgBgGACIgIADQgFgDAAgEg");
	this.shape_55.setTransform(-247.3,42.3);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgFACQAFgJAGAEIgGAIQgCAAgDgDg");
	this.shape_56.setTransform(-247.8,163.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgHAKQAAgGAHgGIAFgHIACAAIABAAQgBAGgHAKIgCACIgDABIgCAAg");
	this.shape_57.setTransform(-247.1,164.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFC9B6").s().p("AgMACQAMgDAFgEIAZgEIABAAQAAAAAAABQAAAAABAAQAAABAAAAQgBAAAAABIgCADQgEADgIAAIgOAAQgDABgZAJQgEgBgCABQAGgEANgEg");
	this.shape_58.setTransform(-244.7,39.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgGADIAEgDIACgFIAHACIgEAEQgCADgBACQgDAAgDgDg");
	this.shape_59.setTransform(-246.1,164.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#015353").s().p("AgCAXIguABQgdAAgOgGQgBgLADgKIAFgVIAFgCQALAEAPABQARABAKgDQABADAEAEQgDAEAAAFQAFAEAIgFQAFABACAIQAAAAABAAQAAAAABAAQAAAAABAAQABAAAAgBIACAAIAHABQAEAKAFgGIACAAQAOADAMgBQADAAADgDQAEgEADAAQAEAAAFACIAJAEIAIAIIAFAEQAAABABAAQABABAAAAQAAABAAAAQAAABAAAAQgYAFgYAAQgYAAgWgEg");
	this.shape_60.setTransform(-247.5,165.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgJACIAEgGIAHAEIAIACQgCADgGAAQgEAAgHgDg");
	this.shape_61.setTransform(-243.8,165.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AAbAIIgDAAQgSgEgHAAIgcAAIgagBIgUgBQgLgCgHgCQAAgDADgCQAfAEAaAAIAYAAIAPACQAWABAZAAIAVgDIAKgBQAHAAADADQgBAEgGABIgLABIgWADIgHAAIgUAAg");
	this.shape_62.setTransform(-247.6,168.6);

	// flecha1
	this.instance = new lib.Path_8();
	this.instance.setTransform(-20.3,67.8,1,1,0,0,0,242.5,105.5);

	// flecha2
	this.instance_1 = new lib.Path_7();
	this.instance_1.setTransform(13.7,41,1,1,0,0,0,286,132.5);

	// flecha3
	this.instance_2 = new lib.Path_2();
	this.instance_2.setTransform(-292.2,-178.7);

	// Capa 4
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#11AA0C").s().p("AgFAAIgBAAQADAAAHAAQAKAAACAAQgEABgbAAg");
	this.shape_63.setTransform(-384.7,171.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#11AA0C").s().p("AgDAAIAEgBQADABAEAAIgPACQAAgBAAAAQAAAAAAAAQABgBABAAQABAAABAAg");
	this.shape_64.setTransform(-317.5,171.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#11AA0C").s().p("AgFAAIAGAAQABAAABAAQABAAAAAAQABAAAAAAQABAAAAAAIgHAAIgEAAg");
	this.shape_65.setTransform(-302.2,177.4);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#11AA0C").s().p("AgjALIgCgLQAAgFAHgEQAMgDAXAAIAhAAQgKAHgOADQABAAAAABQAAAAAAABQAAAAAAAAQAAAAgBAAIgIACQgBgBgBAAQAAgBAAAAQAAAAAAAAQAAAAABAAQAFAAABgCQgJgBgFACQgIABACACQALABgDACQgIACAGACQAAADgQABIgFAAQgKAAgBgCg");
	this.shape_66.setTransform(-304.5,175.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#11AA0C").s().p("AgFACIgDgEQAIAAAEACQADAAACADg");
	this.shape_67.setTransform(-337.1,164.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#11AA0C").s().p("AgEgBIAIABIgFACQgCgBgBgCg");
	this.shape_68.setTransform(-335.7,165.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#11AA0C").s().p("AgEAAIAEAAIAFABg");
	this.shape_69.setTransform(-334.6,164.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#11AA0C").s().p("AgKADQAFgCACABQADADAFgCQgFgCAAgBQAAgDALgBIgCAIIgMABQgGAAgBgCg");
	this.shape_70.setTransform(-346.8,165);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#11AA0C").s().p("AAAAAQgEgBgKACIACgCIAbgBIgRAFg");
	this.shape_71.setTransform(-349.4,165.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#11AA0C").s().p("AgRAFIgEgDQASADAFgDQALgCAIAAQgGgDgUAAQgYgBgJAEIAMAAIgMAFQgBAAgBAAQAAAAgBAAQAAgBAAAAQAAAAAAgBQgDADgRAAIgjgCQAHgCgHgCQgGgDAJgBIBlgBQAAgBABAAQAAAAABAAQAAAAABAAQABAAABAAIgDABIAfgBQAIABADAEQADABAOAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBgBAAIgFgEIAUAAIgBACIARgCQAEADgSACQgNABAQACQgXAEghAAIg1ABQABgBABAAQABAAAAAAQABgBAAAAQAAAAAAgBg");
	this.shape_72.setTransform(-321.9,164.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#11AA0C").s().p("AgHABQAHgBAAAAQAIAAAAABg");
	this.shape_73.setTransform(-277.7,163.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#11AA0C").s().p("AgOACIABgCIABgBIAbAAIgHABQgFABAFABg");
	this.shape_74.setTransform(-275.5,164.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#11AA0C").s().p("AAvAKIABgCQgEgBgIADQgHACgHgBIASgFQgPAAgQAAQgIAAgRACIABAAIgXAAQgPABgHACIAAgEQgIAFgGgCQgIgDgLABIADAAQgKAAAAgBQABgBAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQgLgBgOAGQgNAEgNgCQABgBgEgCQgBgBAAgBQgBgBAAAAQAAgBAAAAQAAgBAAAAQAMADAKgDQACgBgLAAQgKAAAIgDIgcgEIC8AAIACgBIAEABIArAAQgBgBAKAAIAOgCQgIACABABIARAAQADgBAXABQARABgFgFIAOACQAKABAHAAIACABIACAAIgDABIgCABIgIADQgCACAHAAIgYAAQgNAAABACQAIAEAGABQgLgBgPADQgOACgLgBIAagFQAOgEgNgBIgQAGQgEgBAEgCIAHgCQgBgBgLAAQgLgBgDABIAHABQAEACgHACIgrAHIADgCg");
	this.shape_75.setTransform(-295.7,164.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#11AA0C").s().p("AgEACIAKgCQgFgBgDABQgDAAgDgBIAQAAQABAAAAAAQAAABAAAAQAAAAgBAAQgBAAgBAAQgFACgDAAIgCAAg");
	this.shape_76.setTransform(-229.5,175);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#11AA0C").s().p("AgHAAQAAAAAHAAIAIAAIgLABIgEgBg");
	this.shape_77.setTransform(-210.5,171.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#11AA0C").s().p("AgDAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAgBAAIAJAAIgHABIgBAAIAAgBg");
	this.shape_78.setTransform(-225.8,164);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#11AA0C").s().p("AgVAEQgBgEASAAIAagEIgUAEIAEABQgGAEgKAAIgLgBg");
	this.shape_79.setTransform(-203.7,174.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#11AA0C").s().p("AAEADQgEgDgIAAQAIAAgBgDQgDgDANACQgKACAGACQAIAFgGABQAAAAAAgBQAAAAAAgBQgBAAAAgBQgBAAgBAAg");
	this.shape_80.setTransform(-195.6,174.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#11AA0C").s().p("AAAAAIgEgBQAJgBAAACQAAABgFABQAAAAABgBQAAAAAAgBQgBAAAAAAQAAAAAAAAg");
	this.shape_81.setTransform(-206.8,165.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#11AA0C").s().p("AgHAAQADgBAEABIAIABIgFAAQgJAAgBgBg");
	this.shape_82.setTransform(-195,170.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#11AA0C").s().p("AgDAAQgBAAgBAAQAAAAABAAQAAAAACAAQABAAABAAQAGAAAAABQgDgBgGAAg");
	this.shape_83.setTransform(-202,164.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#11AA0C").s().p("AAAACQAAgCgUgBQAUgBAWABIgKABQgEADgHAAIgBgBg");
	this.shape_84.setTransform(-197.7,164.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#11AA0C").s().p("AAAAAIgDAAQgCgBALAAIAEgCIgDACQgBABgFAAIgKAEIAJgEg");
	this.shape_85.setTransform(-177.8,171.4);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#11AA0C").s().p("AAAAAIgGAAQAIAAAEAAIgDAAIgDAAg");
	this.shape_86.setTransform(-171.7,171.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#11AA0C").s().p("AgBAAQAFAAAAgBIABABQAAABgGABQgGgCAGAAg");
	this.shape_87.setTransform(-158.6,174.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#11AA0C").s().p("AgHAAIAPAAIgGABg");
	this.shape_88.setTransform(-140.4,175.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#11AA0C").s().p("AgCAAQAHgBgCgDIAIAEQgIAAgDACQgCACgHABQgCgCAJgDg");
	this.shape_89.setTransform(-151.5,166);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#11AA0C").s().p("AghAAQANABAUgCQARgEARADQgNAAgRACIgbAEg");
	this.shape_90.setTransform(-149.5,167.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#11AA0C").s().p("AABAAQAEAAABAAIgLAAIAGAAg");
	this.shape_91.setTransform(-123,166);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#11AA0C").s().p("AgVAFQADgEANgBQAIAAgCgEQgJAAgMAEQAAgFATABQAPAAAIAEQgHAAgOACQgJADgKAAIgDAAg");
	this.shape_92.setTransform(-94.1,173);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#11AA0C").s().p("AgFAAIALAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABg");
	this.shape_93.setTransform(-97.9,170.2);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#11AA0C").s().p("AAAAAQAHAAAAgBQACABgOACQgEgCAJAAg");
	this.shape_94.setTransform(-98.4,169.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#11AA0C").s().p("AhfA9IAfgnQguAAg8gEQgGgEAQgCQAPgCgBgBIARABQAAABgRACQgNABAKADIAkgBQATAAARgEQgFgEgTABQgXABgJgDQAIABAMgCIg3gEIgFACIAYACQgOAAgKACQgJADgBAEIADAAIgGACIgNgBIgEABIACgBIgMgCIgFABIABgBIgDAAIgVAFIgTADQgKACgLAAQAJAAgDgCIgSgFQgLgCgOAEIAOgBIgfAJQgFgCAKgCIAOgDQgLACgUgDQgRgDgFAEQgEgMgQABQAGACgFACQgFACAEACQgCABgJAAQgEgBgCABIABgBQgQgEgNAEQgMAGgFABQgRABgVgBIgiAAQAAgDgFgEQgGgEgHAAQgCACgNADQgNADgCACQAKACAGgDQAGgDAEgBQAEACABADQABACAHACIgcAAQgWAAgHgDIAFAAIgVgIQgMgFgSAFIgOADIACgCQgIAAgNgDQgHgBgOACIACgBQgIgCgNACIgTAEQgBgBgBgBQAAAAAAgBQAAAAAAgBQAAAAABAAIAHgDQgdgDgoANIgQgDQAIgBAGgDQAGgCgBgCIgJACIgLAAIANgJQgOgCgBAEQgBADgIgDQgNAAgBAHIgPgFQgCAEgeABQgBABAFACQAHABADgBQgCAFgUAAQgCgEgZAAQgWAAAEgFIg+ADQgmABgOACIgOgCQgHgCAHgCQgNAAgZAEQgWADgQgBIAGgBQAHAAAAgCQgKACgUgCQgTgDgOABQABAAAAAAQABgBAAAAQABAAAAAAQABgBAAAAQgCABgSADQgBAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQABgBABAAQAAAAABAAQAAAAAAAAQAAAAgBAAQgggDgwAFQg1AEgZAAQAJAAAGgDQAFgCAAgCIgQgBQgEACgIABIgQACIgDgBQAAgBAAAAQgBAAABgBQAAAAAAAAQABAAABAAQgRgDgaAFQgcAGgTgBIAwgMIgMgEIAVgDQgHgBgKABQgHAAgBAAQAJgBABgCQgHgBgGABIgKACQAPgFAggCIAxgDQABgBAAABQABAAgBAAQgBAAgBABQgBABgCABIAOABQAHABAIgBQAFgCgGgBIgMAAQABgBAAgBQAAAAABAAQAAgBABAAQAAAAABAAIAIgBQABACAUABQAWABAFADQATgBgEgFQgCgEARABIALAFQAtgIAdACIgFAAQgDACAHADQAIABASgCQAOgBAGADQAMgDBDgJQAEAEgSACIgaAEIAUAAQgNAAgNAGQALABAMgDIAVgEQgDADAMAAIACgEIAFABIAfgDIgGgDQgEgCgFAAQADACgQAAQAFgBgGgBQgGgBgBgBQAhAAAQgCIADAEQAQABAcgBIgEACIAdABQAQAAAKACIA0gNQADgCAbADQAcADALgEQACAAgVAFQAEABAMgCQAIgCACADQgQgBAFADQAFAEgFAAQAYAAAKgDQgLAAAEgDQADgDgKABQAdgHAfADQAAADAKABIAGgDQABAAAAAAQAAAAAAAAQgBABgBAAQgBABgBAAQgHACAKABQAIgCAfAAQAYABAGgGQAGACgNACQgMADAMACQgFACgPAAQgNAAgCADQAHgBABADQACADADAAIAOgEIgDAAQAPgDAdAAIAxAAIAjgIQAVgFATABQgDABAKACQALACgMAEQAKACAKgCQAJgBAAgCIgPgCQAFgCALAAQAJAAAFABQAAAAAAAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAIABADgBQAEgDADgBQACADANAAIAUABIAOgGQgEACAJABQAKAAABACIAQgFQAKgCAJABQgDABAIABQAKADAAABQANACAXgFQAWgEANADIgDACQAAAAAAABQAAAAABAAQAAABABAAQABAAABAAIAWgBQAGAAAAgBIAPgGQAKgDAMgCQgBgFgaAEIgHAEQgDgDgJABIgLABQAGgEAZgCQAhgDAHgBQgRgIgzABIALADIgNAAIAMAFIgfAAQAGAAAEADQAFADgIgBQgIgDgGACQgJADgDAAQAPAAgGADQgLgDgOgBQgOAAgKgDQACADgOAAQgQAAgBADIAKABIgUAEQgJgDAGgDQAGgCgQgCQgOgBgKAEQgMAEgKAAQAOgIAbAAIgKgCQAGgDAhACQgKADAJAAQAPABAEABQAAAAAAgBQgBAAAAgBQAAAAgBgBQgBAAAAgBQgCgBAIgCIgggBQASABAQgHQAPgGAQACQgJABAHADIAJADIAbgCIgFgGQAIgBAOAFQANAEAMgEQACgDgRABQARgCASAFIAfAIIACgEQADgDAFgCIAAAFQAAACgGABQAIACATgEQgLgBAIgDIAOgDQAMAAgUAEIALADQAHABACgDQAAADgMADQgMAEgLABIAJAAQgFACgMgBQALAEgEAFIgBgBIAAgBQgPgCADAEQgEADAHABIANACIAMgBIAngQQAKgBAKACIARAEIAEgFQAcABgLAHIgGgCIgCACIAAABIAagDQgQAEAEADQAIAHgCACIAbgDQgKgBAEgCIAMgBQABACALgBIASgBIAAABQAMACAXgCQgBgBAJgEIAMgIQgLgBAAgBQABgBABAAQAAgBAAAAQABgBAAAAQAAgBgBAAQAFACABgCQAAAAABAAQAAgBAAAAQAAAAgBAAQAAAAAAAAIgEgCIgdADQgPACgFAEQADABAGgCQAGgBADABQgHACgLABIgVAAIgGgEIgQACIAGgEQADgCAKAAQgBgCgJABIgSAAIgFAFQAAgBgHgCQgHgCAJgCIAbgEIgIgDIAXgBIgFADQARgCAHAFQAEAEASgDQAOgHAgACQgIABABACQAAAAABABQAAABAAAAQAAABgBAAQAAABAAAAQAKACAIgCIAMgEQAEACgBACQAAABgLAAQAAADAKAAQAKgBABADQAUAAAZgJQAUgIAfAFIgCACQATgBAbAAQAdABAPgBIAaAGQgHABgFADQgHADAEACQgHgDgMgCQgQgBgEgCQgBAAAAABQAAAAABAAQAAABAAAAQABAAABABIAEACIgLgCQgFgBgHABQANADgKABIgOgFQgJABgHAFQgFADgNgBQAMgIAKgCQgEAAAGgBQAIgCgFgBQgIADgMAAQgOAAgKABIAJgCIgegCQADABgMACQgOACABADQAQABAMAAIAfABQgUADgKAHIgCAAQgDADABADIACAIQAJgDAOAAIAYgBQACgDgHgBQgIgCgIABIARgDIgDADIArABQgFAAgEACIgGADIARADQgCgIAHAAQAkACASAJIADgBQgCgCAMgEIATgGQgBACAJABIAOACQACgDAAgCQAmACAtAAIAMgMQAHgHACgFQApgEARAEIgCACQALACAKgCQAEABgDACQgBAAAAABQgBAAAAABQAAAAABAAQAAAAABABIAZgDQgBADgfABQACAAABgBQABAAAAAAQABAAgBAAQAAgBgBAAQgEAAgSACQgPABgCgDIABgCQADgDgMAAQgPgDgEAIQAAABAJACQAJABgFACIANgCIAPABQgYAFgGgEQgNADgCAGQgBAGAIABQAAgBAPgDQALgCgPgDQAHgCAQgCIAagDIAAABIATgBQgJAEAAABIAbgGQgKACAKABIAQABIAGgEQADgDgGgBQgGgBgDABQgDACgFAAIAPgFIABAAIAJgEQAKAAgEAFQgCADANgCIgEgGIAvAEQAdADALgCQgEADAAAEQgBADAFADQgNgCgaABQgDgBAMgCQALgDAJAAQgDgFgQADQgQADgBgFQgRgCgNAFQgLAEgPgDQAAACgFABQgFABAAACQAEAEAVgBQAagBAIABIgHACQANABARgDIgBAAQAJgDADADQAFAFADAAIAKAAQAHAAgBgCIASAEIgBgFIAMABQAEABAGgCIAAgFIgZgBQAGgBACgCQACgCAHgBQgIADAIABQANABABACIAKgCIgDABQAEABAFgBIALgBIgQgEQgIgBgJACQAXgFANAAQALgCARAEQgGAAgCAHQgBAFgXgCQABgBAEABQgDgEgMADIgRAEQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAABAJABQgEgCAKgCQAMgDAJACIgCAIIAVABIgCAAQAEACAMAAQAPgBAGABIAbgCQAQgBgKgFQAIACALgBIATgDIgRgDIARgEIAPgGIACADQABAAAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIAvABQAbAAALgEQAHAAAPAFQANADAPgCQABAAAAgBQAAAAABAAQAAgBAAAAQABgBAAgBQABgCALABIgHADQgEADANgBQAIgDARACQATACAKgCIARACQAIABgCACIgZAAQgOABgCABQAAAAAAAAQAAgBgBAAQAAAAgBgBQgBAAgBAAQgBgBAAAAQAAAAABAAQAAgBABAAQABAAACAAQgNgCgGABQgIACgKgBQgBABAGACQAHABAEgBQAAADgUACQgOABAKAEQAJAAARgFQANgEALAEQgDABgLABQgLABgGAEIARACIALgEIgBABQARADALgFQARgGAIgBQgHgDACgEQACgFgFgBQAegCAAAIQgQACAAAEQAAADgPADIAAAFQAAAEAKABQALgDgDgCQgDgBAKgBQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAFgCAFABQAGAAAGgCIgDACQAIACAHgDQAGgCAGACQgCgCAFgBIANgDIgRgFQgMgDgOAAIgCAFQgCABgGABIAPAAIgJACIgOgCQALgBABgDQAEgFACgBIAPABIAKAAQgBADATAEIAiAFIgJAAQgJACAIABIALADIAIgDQgBABAAAAQAAAAAAAAQABABAAAAQABAAACAAQAGAAAHgDQAGgDAIgBQAAABgEAEQgEADAGABQAKAKAVgDIAMgCIgDAAIANADQgFADgLgBQgLgCgFADIgBACQgPAAgKAFIAegCQABACgFACIgGACIADgDQgJgCgNADQgPADgKAAIgCgBIACgBQgIACgRAAQgRgBgIADIAFgCIg4ALIAAACQAFACgPgCIgeAFQADACAIABIAMgCQAKgBgCgCQAGABALgBIAOAAQgHgCAIgBIALgEQABACAJAAQAHAAAAACIgEgBQgFgBgDACQgGACALABQALACgJACQAKgCAZgBQAYAAALgCIgLgCIATAAQAMABABABIgYABQAAACALAAQAMgBAAACIAagIIgLAAQAEgCAQABIAcACQgFAEgOgBQgTgBgHABQgHABAEADQAFADgGAAQAHADAJgDIAEABQgFAEgUABQgVADgIACIADgCQgSgEgVADQAGACAIgCQAAABgRACQAHABgBACQABAAAAAAQAAABABAAQAAAAABAAQAAAAABABQgHABgRgBQAAAAAAgBQgBAAAAAAQAAgBABAAQAAgBAAAAQABAAABgBQABAAAAAAQAAgBABAAQAAgBAAAAQgFABgIgCQgJgCgHABQASACgeAGIADABQgJAEgGgEIALgBQAAAAABAAQABgBAAAAQAAgBAAAAQAAAAAAgBIgQABIAFgCIgZABIgOALQgGgCgPADIADgBQgIgCgPABQgPABgBACQgBgBATgIQAQgHgiABQgMAAgFAFQgEAGgFABQABgBAAAAQAAAAgBAAQAAAAAAgBQAAAAgBAAQgFAAgEABIgJADQALADAGgDQgBACgLAAQgMgBgDACQAFgDgJgBQgKAAADgBQgagFgXAJQgGgEgNACQgOABgJgBIAMAAQAGgCgJgBQgIgBAHgCQgBAAAAAAQAAAAAAAAQAAAAAAAAQABABAAAAQACABADgBQAPgBgDgDIgRgEIAFgBIgZgGQAAAAAAABQAAAAAAAAQABABAAAAQABABABAAQgRgBgdAAIgsABQgDAGghACQgpABgJADQAFgCABgEQADgEgDgCIAKgDQAIgCAHAAIAHAEQAEACgFABQAQgBgFgDQgJgEADgCIAPACIAigJIgTgDIASAAIAYgBQAAgCgJgBQgKgBgBADQgCgBAJgCQAGgCgIgCQAQgEAmAFIADAGQAGABAFgDQAFgDAIABQgLABADADQADADgHAAQADABABADQACACAKAAQAGgEAHADQAIACAHgDQAAAAABABQAAAAAAAAQAAABAAAAQAAABgBAAQgCACAJABQAMgDADgDQACgBABgGQgJgBgIAEQgJAEgHgBIAcgJQgFgCgFAAQAHgBAFgCIAHgDQgeAAgDgDIADgCQgIgDgLAEIgUACQgKAAgCgCIAGgCIgpABIACgBQg5ANgrgBQAEAEAfAFIgJAFIgFgEIgPAEIAIADQgTABgVAEIgfAGIgBgBIgQACQALABgCADQgBAEgMgCIACgBQgFgBgOAAIgZABIgJAEQgJAAgFgEIgGgIQgOgBgPAEIgXAGIgWgEQgJgCADgBIgRAJQgKAGgVgGIAJgDIg4ADQghACgJgCQAHgGgYgFQgcgHgDgFQABACgGABIgIACQgGgDgHADQAGABgCAFQgCADAOgCQgXANgiAAIABgFIAVACQAAgCAFgBIAKgCQgVgBADgFQACgEgVAAIgEACIgGAAIACgBQgBgCgGAAIgIAEQgIgFAOgBQAMgCgGgDIAcgEQAOgDgDgEQgNgBgMAFQgNAGgOgCIgCgCQgGABgEACIgHAFQgBgDgIAAIgWAGIgVAHQAUgCARADQATACAVgCIgVADQgQADgBADIAAgEQgaAEgSgBIAKgDQgJACgUgDQgRgCgJAEIAHAAIgfAAIgbAIQABgBgIgCQgFgBAEgDQgLgCgLADIgQAEQgKgDALgBQAQgCABgDQgtgDgZAHQAJABgBACQgBgBgRAAIgDADQgOgDAOgDIgQACQgJABgHgDQAKgCAQABQAQAAAEgBQgQABgTgEQgUgFgWACIACgDQAAAAAAgBQAAAAAAAAQgBAAAAAAQgBAAgBAAQgMAAABAEQABAEgCABQASgCANAGIgFADQAAgBgFgBIgHgBIgCAFQAAgEgIgDQgJgCgJABQAIADACACIACAFQgIADgIgCQgJgDgJACIAHgBQAEgCgJgBQgGAAgEACIgHAEQAEgCADgFQAEgEAFgDIAagCIgPgDQAKgBABgDIABgDQgOgDgJAEQgIAFgIgBQgEACAIAAQAHAAgHACQgKAAgCACQgDACgKABIADgCQgDgCgGABIgKACQAAAAgCAIQgCAIgTAAgAIUAtQgLACALAEIATgBQAMAAAAgDIAAABQAIABAFgDQADgDALABQABgDgMAAQgGAEgNABQAAgBAAAAQAAAAABgBQAAAAABAAQABAAACAAQAHAAgFgEQgCgBgOABQgMAAAFgEIAQABQAAgDAGgBQAGgCgBgCIAPAAQAIACAGgDIACgFQABgCALABQAMAHA0gCIAMgDQAAgBgLAAQgJAAAFgCIATgBIgBABQAFABANgDIgMADQgGABABADIAKACIAJAAIgDABQALABAFgDIAGgFQAKgDgMgDQgPgDABgCIA1gCQgJADACACQAFABACACQACABAKAAQgBgEAOgBQATgCAFgBQABAAABABQABAAAAABQABAAAAAAQAAAAgBABIgJAAQAAADAKAAIAPAAIAOgCQgBgBgBAAQAAgBgBAAQAAAAAAgBQABAAAAgBQACgCAJgBIAAgBIgggDQgUgBgIACIADgCQgJgBgYADQgTACgFgEQAAgBAAAAQAAAAgBgBQAAAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIgQACIAEAAIgcAAIABAAIggAIIAAACIgDACIgLABIgJgCIgLgDIAaAAQADgGgPgCQAAAAABAAQABAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQgBAAgBAAIgIACQgGABAEAAIgugBQgegCgVADQAIgCgJgBQgIgCANAAQgLgDgIADQgKAEgKAAQAAgBAGAAQAIgBADgCQgSgBgdAFQgdACgRgBIgBgCIgVACQAKAHALAEQARAFAggBIgDAAQAMADAZgDQAZgEAPADQgOAEgPAIIAQgDQgDAEAIAAIARgBIgKAHQgFgCgKAAIgIAAQgBgBgMgDQgRgDgKABQABACAPACQAMACgJAEQAHgCAHABIANABQgHABAAADQgBADgEACIAVgCIgNADgADxAZQAJAFANAAIAZgDQANgBACgCQABABAIABQALACAGgCQAGgEASgDQANgCgFgBIgOABQgIABgEgDIAQgBIgKgEQAHACgFgJIgTABIACAAIgUAEQAJABADADQACADgLABIgBgCQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQgLgCgKAAQgMgBADAFQAMgDABAEQACAEAHgCQgEADgJAAIgNACQAGgDgFgDQgGgDgKgBQgWAAgKABQACACgBADQAAACAKABQgOACgLgDQALgBAAgBQgEgCgGgBIgJgCIgKAAIACACIgKADQAIgBABACIgDADQABgCgGAAIgJACIAKAFQgCABgIgBQgHgBABACQAVACAhgCIgJgEIAIAAQAHAAAFACgAAPAcQALAAAEgBQACgCAMgDQAKgDABgDQABgBgIgBIgQgBQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAJACgCAEQgHgEgHADQgHAFgHgBQgDADAKABgACjAOQABAAAAABQABAAAAAAQAAABAAAAQAAAAAAABQAIABACgBIACgDgABKAPQASACAVgBIAegKQAUgGAAgBQgCgCgGABIgKAAIACACIhGgDQAmAIAFAEQAFAGgvgBgAg4ANIADgEIgJAAQADADADABgAGHgbQgHgBgNACQgKAAABgDQAEgCALAAQALgBADgCIgKgCQAJgCAGACQAFAEALgCQgBgBgBgBQAAAAAAAAQAAgBAAAAQAAAAABAAQAIABAEgCQgCgBgTgBQgNAAADgFQAFgBATAEQAUADAIgEIgBABQAOABAKgDIAOgEQAFABALgBIAQgCIAAADIAOgBQgEACgIAAIgRgCIABAFQgIgEgKADIgQAHQAFgBAYgBQARAAADgFIAKAEIAEgCQAFADgEADQgEADgLABQgBgBgBAAQAAAAgBgBQAAAAAAAAQAAgBAAAAQgQAFgNgBIAJgCQgjgBgJAHIgCgEQgEgFgHgDQgLADgDACIgFAHIgfAEg");
	this.shape_95.setTransform(-242.4,169.6);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#11AA0C").s().p("AgJAAQAKAAAJAAQgJABgDAAQAAgBgHAAg");
	this.shape_96.setTransform(-136.4,171.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#11AA0C").s().p("AgIAAIACAAIAOAAQABAAgBAAQAAAAAAABQgBAAAAAAQgBAAgBAAIgNgBg");
	this.shape_97.setTransform(-260.5,171.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#11AA0C").s().p("AAFAEQgNACgCgEQgBgCgPAAIgCAAIAFgCIgRgBIAUgBQABAAABABQAAAAABAAQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAAAQABAAABAAIANgBQADgCgIgCIAKABQAKACAFgBQgDACALABQAKABAEAAQgBADgOAAIgXACg");
	this.shape_98.setTransform(-183.7,170.9);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#11AA0C").s().p("AgGAKIAMgBQAEgCgKgDIgggCIAUgBQAKAAAHACIAGgDQgMgBgiABQAWgHAsgDQAHABgEACQgGACAFABQgGgBgFABQgCABAAAAQgBAAgBABQAAAAAAABQAAAAAAABQAGAAAJgDQAAABAAAAQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAABABQAAAAABAAIgQAAQgKABAAADQARAAgJADIgOADQAAgBgGAAg");
	this.shape_99.setTransform(-96.2,167.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#11AA0C").s().p("AAsANIgnAAQgEgCAGAAIgjAAQgYAAgKACIgPgBQgJgCAFgCIgLABQAAAAAAAAQAAgBABAAQAAAAABAAQABAAABgBQAFAAAAgBIgFAAIACgFQACgCAPAAQAFABgJABQgKAAADAEQAFAAABgCIACgCQAKAAgBAEQACgBAJAAQAJAAADgCQALAAgCADQgDADAGAAIAIgHIAUABQAQgBgBgFQgCgHATgCQgDADAJAEQAJAEAMABQgdADgNgCQAJADgOAAQgOABADADQAPgFAWADIgEABQAFABANgDQAMgDAKABQAJAAgEAEQAOgCAAABIgGAIIgcABIgPgBg");
	this.shape_100.setTransform(-261.4,175.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#11AA0C").s().p("Ag8AAIgdACQAAgEAdABQAiABAJgEIAGADQAEABAHgBQAAgFASAAIAggBQABAAAAABQABAAgBAAQAAAAgBABQgBAAgCAAQgHACAFABIAQgDQAKgBAJACIgCAAQANgBgBADIgDACQgFAAgKAAIgOABQgGADgaACQABgCgGgCQgFgCABAAQgyAAgKABIAHAAQgMAAgCADQgDAEgHAAg");
	this.shape_101.setTransform(-289.4,173.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#11AA0C").s().p("AAAAAIAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAg");
	this.shape_102.setTransform(-267.9,172.9);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#11AA0C").s().p("AicATQgNgBABgDIAKgFQAEgCAKgBQAIAFASgCQAbgCAGAAIAGgDQADgCAJAAQgBACgMADQgJACAHADQALABALAAQAMgBAEgFQgSABACgGQADgEgSABIALgCQAHgDAGAAQAJABgNAEQgKACAYAAIAEgHIAeABQgYACgGACIAfABQAQABABADQARgDAogLQAjgKAYgDQAMAAACAEQABAEgGACQAKgBAFgCIALgFQgJAEABABIAGAFIAKgBIhPAdQgJAEgagBQgZgDgGADQAFgCgGgDQgGgDgJACQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAABAAIAEABQgwgHgSAIIAKgFQgcACgMAEQABAAABgBQAAAAABAAQAAgBAAAAQAAAAAAgBQgFgBgLABQgMACgEgBIAIgBQABgDgPACQgHAAgFACQgGADAJACIgOgCIADADQgDgDgPgBg");
	this.shape_103.setTransform(-286.3,175.2);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#11AA0C").s().p("AAAgBIAEABIgHACQADgCAAgBg");
	this.shape_104.setTransform(-267.7,173.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#11AA0C").s().p("AAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIgBAAg");
	this.shape_105.setTransform(-346,167.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#11AA0C").s().p("AgcAGQANgCAEgEQAGgDAEgCIgFAAQgBAAAAAAQAAAAABAAQAAAAABAAQAAgBABAAIAEgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQABABABAAQABAAAAAAQAAABAAAAQAAAAAAAAIAZgEIgFAEIgVAGIgEABIgLAEIgEAAQgGAAgGgCg");
	this.shape_106.setTransform(-247.8,164.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#11AA0C").s().p("AgkAHIAkgNIAAAAQgGACAGAEQADABAKgBIgDAAIAIAAQAJgBADABQgGAAAFACIAIADIg2gBQACgCAEAAQgHAAgGADQgFACgFAAIgCAAg");
	this.shape_107.setTransform(-263.5,172.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#11AA0C").s().p("AgdAJQANgBABgDIgJABQgGgBAFgCIAGgDIATACIALgFQgLgDABgBQACgBgDgDQABABASAAQAPAAAEAFIgXAGIAHABQAEAAADgCIAAAHIAEAAIgGACIgEADQgKgDgVgBQgGADgGABIgQABQgDgDAKgBg");
	this.shape_108.setTransform(-90.6,168.1);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#11AA0C").s().p("AgYAFQgEgCgFABIgHgBQANgBAEgDQADgFASAAQgEAAgBADQAKACALgDIgBACIAcAAQgCACgNAAQgNAAgCAAIAQABIgbAEQAIgCgEgCQgEgBgGABQgBAEgDABIgNABQABAAAAgBQAAAAAAAAQAAAAgBgBQAAAAgBAAg");
	this.shape_109.setTransform(-83,168.5);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#11AA0C").s().p("AgMAAIAQgBQAJABAKAAIgtACQgEgBAOgBg");
	this.shape_110.setTransform(-166.6,173.6);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#11AA0C").s().p("AgPAAIATAAQAKAAACAAIgWABIgJgBg");
	this.shape_111.setTransform(-125.1,179.6);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#11AA0C").s().p("AhhALIgFgLQgCgFATgEQAggDBCAAQBMABAPgBQgdAHgkADQAFACgFAAIgWACQgLgCAJAAQANgBABgBQgYgBgSACQgTABAEACQAiABgNACQgVACASACQgCADgpABIgOAAQgaAAgEgCg");
	this.shape_112.setTransform(-131.4,177.9);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#11AA0C").s().p("AgQACIgHgEQAYAAAMACQAHAAAEADg");
	this.shape_113.setTransform(-219.5,166.9);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#11AA0C").s().p("AgMgBIAZABIgRACQgEgBgEgCg");
	this.shape_114.setTransform(-215.7,167.5);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#11AA0C").s().p("AgMAAIALAAIAOABg");
	this.shape_115.setTransform(-212.9,167.2);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#11AA0C").s().p("AgdADQANgDAFACQAIACARgBQgQgCACgBQACgDAcgBIgEAIIgjABQgTAAgBgCg");
	this.shape_116.setTransform(-245.8,167.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#11AA0C").s().p("AACAAQgMgBgeACIAFgCIBMgBIgwAFg");
	this.shape_117.setTransform(-252.7,167.5);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#11AA0C").s().p("AgyAFIgJgDQAyACAQgCQAfgCATAAQgQgDg6AAQhAAAgYADIAhAAIgiAGQgIgBAAgBIAAgBQgIADgtAAIhggBQASgCgSgDQgQgCAagBIETgDIANgBIgHABIBSgBQAXACAJAEQAGABAoAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQgBAAgCAAIgOgEIA4gBIgEADIAtgDQAMADgwADIgTAAQgCACAdABQg+ADhZAAIiTABQAMAAgDgCg");
	this.shape_118.setTransform(-178.4,167.1);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#11AA0C").s().p("AgUABIAUgBQAVAAAAABg");
	this.shape_119.setTransform(-59.1,165.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#11AA0C").s().p("AgmAAQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAIBNAAIgUABQgNABAMABIg+AAIADgCg");
	this.shape_120.setTransform(-53.3,166.1);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#11AA0C").s().p("AikAIQgVAFgQgCQgWgDgcACIAFgBQgaAAAAgBQAFgDABgCQgeAAgnAFQgkAFghgCQACgBgKgDQgIgDADgBQAfADAbgDQAFgDgfAAQgZAAAUgCIhJgDIH/gBQgBAAAAAAQABAAAAgBQABAAABAAQABAAABAAIAKABIB2AAQgDgCAaAAIAlgCQgVACADACIAtgBIBHAAQAuAAgMgFIAlACQAbACAUgBIADACIAGAAIgOACIgWADQgEACASAAIhCAAQghAAACADQARADAWABQgfAAgoACQglACgeAAIBEgGQAogEgkgBIgrAGQgLgBAKgCIATgCQgDgBgcAAQgdAAgJAAIATACQALABgSACIh0AIIAIgCIACgDQgLAAgVADQgSACgUgCIAvgFQg+gChcAFIACAAQhjABgWADg");
	this.shape_121.setTransform(-107.7,166.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#11AA0C").s().p("AgNACIAegCQgMgBgOABQgIAAgHgBIAwAAQAGABgOAAQgMACgMAAIgFAAg");
	this.shape_122.setTransform(70.9,176.8);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#11AA0C").s().p("AgWAAQgCAAAWAAQATAAAGAAIgYABIgVgBg");
	this.shape_123.setTransform(122.3,173.2);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#11AA0C").s().p("AgLAAQAAAAABAAQAAAAAAAAQgBAAAAAAQgBAAgBAAIAbAAIgVAAIgEABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABgBg");
	this.shape_124.setTransform(81,165.8);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#11AA0C").s().p("Ag5AEQgDgDAwgBIBGgDIgzADIAMABQgLACgUABIgPAAIgeAAg");
	this.shape_125.setTransform(140.5,176.2);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#11AA0C").s().p("AAJACQgMgCgVAAQAYAAgJgDQgIgDAoACQgfACATACQAXAEgQACQAEgBgNgDg");
	this.shape_126.setTransform(162.7,176);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#11AA0C").s().p("AAAAAQgGgBgIAAQAdgBAAACQgBAAgOACQAEgCgEAAg");
	this.shape_127.setTransform(132.2,167.3);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#11AA0C").s().p("AgVAAQAJgBAMABIAWABIgOAAQgaAAgDgBg");
	this.shape_128.setTransform(164,172);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#11AA0C").s().p("AgDADQADgDg6gBQA6gBA7ABQgIAAgRACQgLACgTAAIgHAAg");
	this.shape_129.setTransform(156.8,166.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#11AA0C").s().p("AgFABIgNAAQgGgCAhABIALgBIgJABQgDABgJAAIgLABIAHgBg");
	this.shape_130.setTransform(211.4,172.8);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#11AA0C").s().p("AABAAIgSAAQATAAAQAAIgKAAIgHAAg");
	this.shape_131.setTransform(227.1,172.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#11AA0C").s().p("AgEAAQAOAAABgBIAEABQAAABgUABQgTgCAUAAg");
	this.shape_132.setTransform(262.5,175.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#11AA0C").s().p("AgUAAIApAAIgOABg");
	this.shape_133.setTransform(311.6,176.9);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#11AA0C").s().p("AgHAAQAXgBgFgDIATAEQgUAAgIACQgIACgWABQgEgCAZgDg");
	this.shape_134.setTransform(281.6,167.4);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#11AA0C").s().p("AhcAAQAkACA0gDQA1gEAsADQglABgrABIhNAFg");
	this.shape_135.setTransform(287,168.6);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#11AA0C").s().p("Ag7AFQAHgEAjgBQAbAAgGgEQAnAAARADQgUAAglADQgbADgbAAIgIAAg");
	this.shape_136.setTransform(436.7,174.1);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#11AA0C").s().p("AgRAAIAjAAIgLAAIgDABg");
	this.shape_137.setTransform(426.5,171.3);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#11AA0C").s().p("AgEAAQAYAAgBgBQAEABgPAAIgYACQgJgCAVAAg");
	this.shape_138.setTransform(425,170.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#11AA0C").s().p("AkCA8IBUgmQiUAAiNgEQgOgEAogCQAqgCgCgBIAuABQgBABgrACQgiABAXADIBkgBQAygBAugEQgMgEg2ACQg/ABgYgDQAWABAjgCIiXgDIgNABIA4ACQgeAAgYACQgbADgCAEIAIAAIgRACIguAAIAHgBIgugBIAEgBIgLAAIg5AFIg0AEQgtADgcgBQAqAAgIgCIgwgFQgdgCgmADIAkAAIhRAJQgQgCAagCIAqgDQgfACg3gDQgsgDgPAEQgMgMgpABQAPACgNACQgPACANACQgHABgWAAQgOgBgFABIADgBQgsgEgiAEQgfAGgPACQgwABg2gBIhbgBQgDgDgMgDQgQgEgTAAQgFABgmAEQgiADgEADQAdABAOgDQARgDAKgBQAKACAFADQADACASACIhMAAQg7AAgRgDIAKAAIg4gIQgggEgwAEIgmADIADgBQgWAAgggDQgTgCgjACIACAAQgYgCghACIgzAEQgLgDAIgBIATgDQhRgChpAMIgsgCQAVgBASgDQARgDgGgCIgXACIgfAAIAlgIQgmgDgDAFQgCADgWgEQgiAAgEAHIgpgEQgDADgeABIg2ABQgDABARACQAQABAJgBQgBACgWABIglABQgEgEhFABQg8AAANgFQjyADhDAEIgmgCQgSgCARgCQglAAhBAEQg6ADgsgBIAQgBQATAAgBgCQgbACgygCQg5gCgmABQAJgBAGgCIg3AEQgBAAgBAAQAAAAAAAAQAAAAACAAQABgBACAAQAKAAgDgBQhYgCiCAFQiJAEhCABQAUgBAOgCQAOgDAAgCIgsAAQgIABgaABIgqADIgJgCQAAAAgBAAQAAgBABAAQAAAAACAAQABgBACAAQgtgDhEAGQhNAGgzgBICBgMIghgEIA5gFQgRgCgbACQgVACgCgCQAYgBAAgCQgSgBgOABIgbACQApgEBXgCICCgDQAKgBgVAEIAlABQAXABATgBQAOgCgRgBIgeAAQACgDAbgBQACACA4ABQA7ABANADQA0gBgKgFQgIgEAxABIAeAFQBxgIBUABIgNABQgGABAHABIALACQAXABAvgBQAngCAQADQA+gGCYgGQAKAEgxACQhAACgIACIA0AAQggAAghAGQAdABAegDIA6gEQgGADAfAAIAGgFQABABAJAAIBWgCIgSgEQgKgCgNAAQANAEgugBQAKgCgOAAQgSgCAAgBQBWAAAsgBIAKAEIA/AAIA2gBIgJADIBLAAQAuAAAaACIBJgHQAvgDAVgDQAJgCBIACQBNADAcgEIgTACIgiAEQAOAAAfgCQAVgBAHADQgrgBALACQAPAEgOAAQBCAAAZgDQgdAAAKgDQAKgDgdABQBOgHBVADQAAADAbABIAQgDQAKAAgSACQgTACAdABQAWgCBRAAQBDAAANgGQASACghADQgiACAhADQgQACgpAAQggAAgHADQATgBAEACQADADAJAAIAngDIgJAAQAogDBPgBICEAAIBggJQA3gEA0AAQgKACAdACQAbACgdADQAbACAagBQAYgCABgCIgpgCQAOgCAcAAQAZAAAPABIgFABIgCABQAYABAFgCQAJgDAMAAQAFACAiAAIA1ABIAngGQgKACAWABQAdAAADACIAqgFQAagCAbABQgJABAVABQAbACAAACQAkACA9gFQA6gFAkADIgGACQgDACANAAIA9gBIgBABIACgBQANAAAAgBIApgGQAZgDAkgCQgGgGhEAFIgSAEQgKgDgYABIgfABQAUgEBEgCQBWgDATgBQgvgIiJACIAeACIgkAAIAjAFIhSAAQAQAAAIADQAMADgTgBQgXgCgQACQgWACgLAAIAYABQAKABgJABQgdgCgogBQgjgBgdgDQADAEgkAAQgoAAgFADIAaAAIg2AFQgYgDASgDQAOgCgogCQgngBgdAEQghAEgXAAQAggIBLAAIgbgCQAQgDBbACIgRACIAMAAQAqABAKACQABgBgJgDQgEgBAWgCIhMgBQArAAAngGQAogGArABQgYABARADIAaAEIBJgDIgPgFQAXgCAmAFQAjADAggDQAEgCgaAAIgTAAQAvgCAuAFIBXAIIAGgEQAGgDAPgCQAAAAAAAAQAAABgBAAQAAABAAABQAAAAAAABQAAACgQACQAUABA1gEQgegBAWgCIAmgEQAjABg7AEIAfADQATABAGgDQABACghAEQgiADgdABIAZABQgNABghAAQARACADACQACACgGADQgBAAABgBQAAAAAAAAQAAAAAAAAQAAAAAAgBQAAAAAAAAIgaAAQgJABADABQgLADAUABIAhACIAggBIBrgQQAcgBAaABIAuAEIAJgEQBOABgcAGQgBgBgOAAIgIACIBIgDQgqAEAMAEQARAGgDACIBIgDQgbgBANgCIAegCQACADAggBIAygBIgCABQAhACA+gCQgCgCA5gLQgggBACgCQAHgCgCgBQANABADgBQABgBAAAAQAAAAAAAAQAAAAgBgBQgBAAgCAAIgJgBIhNADQgoABgOAEQAIACAOgCQAQgBAJABQgSACgcABIg8AAIgOgEIgtACIAQgEQAKgCAcAAQgEgCgaABIguAAIgOAFQACgBgXgCQgRgCAZgCIBHgEIgTgDIA9gBIgPADQAwgCAPAEQANAEAygDQAogHBUACQgYABAEACQAFADgFACQAbABAVgCIAigEQAKADgCABQgCACgbgBQgCADAaAAQAegBACAEQA2AABCgKQA2gIBUAFIgGACQA2gCBHAAQBSABAlgBIBGAHQgRABgQADQgRACAKACQgUgDgggBIg3gDQgCABAIABIAMACQghgDgeABIAPACQAJACgPAAIgogEQgXABgSAEQgPAEghgBQAZgJAjgBQgMAAARgCQAWgBgPgCQgXADgfABQgoAAgXABIAVgCIhQgCQAKABgjACQgmADAEACIBLABQAfgBA0ACQgvABggAJIgGAAQgIADACADQAGAGAAACQAYgDAlAAQAsAAAWgBQAHgDgWgCQgTgBgWABIAugDIgJACIB1ACQgLAAgfAFIAvACQgGgHATAAQBhABAxAJIAJAAQgIgDAhgEIA0gGQgBADAWAAIAnACQAHgDgDgDQBsADB1gBIAggMQATgHAGgFQBkgEA5AEIgEACQAbACAcgCQAMABgJACQgJACAGABIBGgDQgIAEhRAAIAIgBQABAAABAAQABAAABAAQAAAAAAgBQAAAAgBAAQgLAAgxACQgnABgHgDQgCAAAAAAQgBAAAAAAQgBAAAAAAQABgBAAAAIAGgBQAHgDggAAQgkgCgPAHIAZADQAWACgKABIAigBQATgBAVABQhBAFgPgEQglADgDAHQgDAGAXAAQgDgBApgDQAegCgpgCQATgDAsgCIBGgDIgCABIA0gBQgXADgBACIBGgHQgUADAWABIAsABIgDACQANAEA5gBQBIgCATABQgOAAgEACQAkABAsgCIgEgBQAbgCAIACQAOAFAGABQAxAAgGgDIAxAEIgDgFIAfABQANABAPgCIACgFIhGgBQASgBAGgCQAFgCAUgBQgYADAYABQAgABACACIAcgDIgHACQAMABANgBQAPgCAMABIgpgEQgXgBgZACQAjgDA/gDQARgBAXABIAlACQgTABgEAHQgEAFg8gCQADgBAKABQgJgEgeACIgvAFQADACgFACQAAABAZABQgMgCAdgCQAdgDAbACIgHAHIA5ABIgGAAQAMADAggBQAngBARABIBJgCQAtgBgcgFQAVADAegCIA1gDIgwgDIAvgEIAngGIAIADQACABgFABIB9ABQBLAAAcgEQASAAAqAEQAhADAsgCQACAAAEgDQACgDAdABIgQADQgKADAigBQATgCAvABQAzACAagDIAuACQAYACgGACIhFAAQglABgHABQADgBgMgBQgHgBASgBQgigCgTABQgUACgcgBQgCABARACQATABAIgBQABADgzACQgoACAcAEQAbAAArgFQAjgFAdAEQgIABgfABQgcABgPAEIAsACIAfgEIgCABQAtADAdgFQAtgHAYgBQgWgCAHgFQAIgFgOgBQBRgBAAAHQgtADAAADQgCAEgnADQACAAgBAFQAAAEAcAAQAcgCgJgCQgHgCAagBQACAAABABQABAAAAAAQABAAAAABQAAAAgBAAQAMgBAQAAQAQABAQgCIgHABQASACATgCQATgCAQACQgIgDAQgBIAhgDIgtgEQgfgEglABIgIAEQgGACgQABIApgBIgYADIgogCQAegCAGgDQAJgEAEgBQAaABAPgBIAbAAQgCADA0AEIBcAFIgYAAQgYACAXACIAcACIAXgCIgBAAQgCABAIAAQATAAASgDQASgDATgBQABABgMAEQgIADAOABQAeAJA2gCQADgCAdgBIgGABIAiADQgPACgcgBQgdgBgPADIgCAEQgqAAgZAEIAnAAIAogBQAEABgNABIgQACIAGgDQgZAAghABQgpADgaAAIgEgBIACgBQgUACgwAAQgsAAgXADIAPgDIiWALIAAACQAFABgMAAIgUgBIhSAGIAcADQADgBAfgBQAagBgEgDQAOACAfgBIAkgBQgPgBASgCIAegDQAFABAXAAQATAAgBACQgRgCgOACQgSACAfACQAeABgXACQAagBBDgBQBAgBAfgCIgfgCIA0AAQAiABADABIhBABQgBADAdgBQAfAAACABIBHgIIggAAQANgCArABIBNACQgQADglAAQgzgBgTABQgTABAMADQAMADgRAAIAUABQAOAAAJgBIANABQgQADgzACQg7ACgUADIAJgCQgugDg9ACQANABAXgBIgsAEQASABAAABQAAACAIAAQgcACgjgCQgHgBAHgBQAJgCgBgBQgKAAgYgCQgWgCgVACQAgAAgWADIgpAFIAIAAQgaAFgPgEIAbgBQAMgBgEgCIgrABIAOgCIhFAAQggAJgHADQgNgCgqADIAHgCQgWgCgnACQgmABgFACQgDgBA0gIQAqgHhbABQghAAgMAFQgNAGgMABQABgBAAAAQAAAAAAAAQAAAAgBgBQAAAAgBAAQgPAAgMACIgWACQAeADAPgDQgFACgcAAQgfAAgKABQAPgDgbgBQgYAAAGgBQgigCgoACQgiABgYAEQgSgEgfABQgqACgZgBIAkAAQAQgCgbgCQgXgBAagCQgCAAgCABQgBAAAAAAQgBAAABAAQAAABABAAQAGABAIgBQAmgBgHgDIgugEIARgBIhGgGQgBABAJACQgtgBhQAAIh2ABQgHAHhcABQhtACgXADQAMgDAFgEQAFgDgHgCIAbgDQAXgCASAAIATADQALACgOACQAtgBgRgDQgYgEAKgCQg1AAg5AFIhWAGIgCgCIgqADQAcABgEADQgEAEgggCIAGgBQgOgBgnAAIhAABIgbAEQgZAAgMgEQgKgGgHgCQgnAAgnADIg/AGIg6gDQgjgCAdgDQgMABgrAJQgdAHg5gGIAZgDIiXADQhYADgZgCQASgGhBgGQhLgGgJgFQADADgmACQgTgDgOADQAOABgEAFQgFADAmgCQg/ANhcAAIABgFIA9ACQgEgCAPgBIAagCQg4gBAHgFQAHgEg5AAIgKACIgRAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBgBAAQAAgCgQAAIgWAEQgVgEAkgCQAggCgOgCIBKgFQAogDgIgEQgkgBghAFQgiAGglgCIgJgCQgPABgMADIgSAEQgCgCgXgBIg6AHQgiADgXAEQA4gCAuACQAoACAtgBQhOADgFAGIABgFQhIAFgvgBIAcgDQgaABg2gCQgrgDgbAFIAUAAQgfABg1gBIhHAIQABgBgUgCQgPgBAMgCQgfgCgeACIgsAEQgRgBADgBIASgBQAsgCADgDQh0gDhJAHQAWABgBACIgvgCIgLADQgUgBABgCQAAgBATgCIgqACQgaACgPgDQAYgCAtAAQAsABAJgBQgqABg1gEQg0gFg9ACIAGgCQADgCgNAAQgfABACADQADAFgFABQAcgCAUABIAiAEIgKADQgBgBgOgBIgUgBIgFAFQACgEgYgCQgYgDgYACQAWACAEACQACABAFAFQgWADgZgDQgagDgZADIAUgCQAMgBgXgBQgRgBgLADIgUADQAMgCAKgEQAJgEANgDQAdAAAsgCIgrgEQAdgBAEgCQABgBAAAAQABgBAAAAQABgBAAAAQAAgBAAAAQgqgDgXAEQgZAFgUAAQgMABAWABQAUAAgVACQgYgBgFACQgJADgbABIAKgDQgLgBgPABIgaACQgHAAABADIgBAFQgEAIg0AAQAGgCAAgBgAWeAqQgeACAcADIAzgBQAiAAABgDIABACQAUAAANgDQALgDAcACQABgFgdABIgUADQgNACgTAAQgGgBARgBQASAAgMgEQgEgBgpABQgfAAANgEIArABQAAgCARgCQAPgCgBgCQALgBAcACQAYABAPgDQAGgBAAgEQADgCAbABQAnAICHgDIAigDQgCgCgcAAQgYAAALgCIA0gBIgDACIAaAAIAYgCIgfACQgUACAFACIAaACIAZAAIgJACQAfABANgDIARgFQAbgEghgCQgpgDADgCICRgDQgZADAFACQAOABAGACQACABAcAAQgBgEAkgBQA0gCAMgBQANACgCABIgcAAQAEADAbAAIAnAAIAmgDQgZgDAxgDIABgBIhZgBQg2gBgUABIAJgBQgbgBg/ACQgzACgPgDQAAgBgGgBQgGgBAAgCIgsADIAKgCIhLABIACgBIhVAJIAAACIgJACQgPACgOgBIg1gFIBFAAQAKgFgsgDQALAAACgBQACgBgNgBIgVACQgRABAKACIh8gCQhPgDg4ADQASgBgXgCIgNgBIAbgBQgegDgWAEQgcAEgZAAQgCgBASAAQAVgBAHgCQgwgBhOAEQhPAFgsgBIgFgEIg4ACQAaAHAfAEQAuAFBYgBIgKAAQAfADBFgEQBFgEApAEQgoAEgoAIIAqgDQgHADAWAAIAvAAIgcAGQgOgBgagBIgXABQgBgBgigDQgsgDgbABQACABAoADQAfABgVAEQARgBASABIAlAAQgSACgCADQgCADgMABIA6gBIgjADgEAlTAAaQAHABAWABIAlACIAogDQAogEAMgCIgrgCQAhABBJgDQAAgCgagBQgagBgFADQgCgBAWgCQAQgCgUgCQAtgDBlAEIAGAGQAQABAOgDQANgDAXABQgcABAIADQAHADgTAAQAGABAEADQAGACAZAAQARgEAWACQAWADAPgDQAKABgIACQgGACAYAAQAggCAKgDQAEgCADgFQgYgBgYAEQgXADgSAAIBLgKQgNgBgMAAQAQgBAOgDIASgCQhSgBgEgCIAFgCQgKAAgRAAQgOAAgJABIg1ACQgaAAgGgCIAOgBIhuAAIAIAAQiaANh2gBQAMAEBSAEIgYAFIgOgEgAKMAXQAYAFAjgBIBBgCQAmgBAGgDQADABAVACQAeABARgCQAOgDAwgDQAjgDgMgBQg0ADgTgEIAsgBIgdgDQATABgMgJIg1ACIAFAAIg1ADQAcACAFADQAHACgfACQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBgBQgCgBAKgBQgdgDgcAAQgiAAALAEQAfgDAEAFQADAEAWgCQgPADgWAAIgjABQARgCgQgDQgOgDgegBQg6AAgaABQAFACgDADQACACAZABQgkACgfgCIATgCQAKAAgBgBQgKgCgRgBIgXgCIgbABIAHABIgeADQAZgBgBACQAAABgGADQABgDgPAAIgaACIAfAFQgHABgYgBQgRgBAEACQA5ACBYgCIgYgEIATAAQAVAAAOACgAArAbQAaAAAMgBQAGgCAggDQAcgDACgDQADgBgXgBIgpgBQgBABgIABQAaACgHAEQgVgEgPAEQgVAEgSgBQgJADAdABgAG5ANQAIABgEABQAYABAEgBQAEgBACgCgAFDAIQAPAFh9AAIgMABQAfACBKgBIBPgLIA3gHQgHgBgOAAIgcABIAIACIi+gDQBnAIALAEgAiaANIAIgEIgYgBQAGAEAKABgAQfgeQgQgBgnACQgXAAACgDQAKgBAdgBQAdgBAKgCIgbgCQAYgCANACQARAEAcgCQgKgDAIAAQAWABALgCQgHgBgyAAQgmgBAKgEQAMgCA3AEQA0ADAWgEIgCABQAmAAAagCIAlgFQAQACAfgBIAEAEQgYgDgZADIgsAHQAOgCBAAAQAwgBAGgFIAaAFIAMgCQAPACgMADQgNAEgcAAQgKgBACgBIgdADQgUACgcgBIAXgCQheAAgaAFIgEgDQgJgFgVgDQgfADgGACQgDADgNAEIhSAEgAfhgjQgIgBAfgDQAggDAZABQgJgGgtAEQgrACgCgFQgvgBgiAEQgeAFgpgEQgBADgMABIgLABIARgFQAJgCgRgBQgQgCgHACQgLACgMAAIAogGIADABIAYgFQAaABgKAEQgGAEAjgCIgJgHIB/AEQBNADAhgCQgNADgCAEQgBAEAPACQgcgBhPABgABrgqIAAAAgAVtgyIgmgBIAigCIAAACIAmgBQgJACgRAAIgIAAg");
	this.shape_139.setTransform(36.2,171.5);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#11AA0C").s().p("AgagBQAdABAYAAIgjACQgDgCgPgBg");
	this.shape_140.setTransform(322.5,172.8);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#11AA0C").s().p("AAAABQgVgBgCAAIAGAAIApAAQAAABgQAAIgIAAg");
	this.shape_141.setTransform(-12.6,173.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#11AA0C").s().p("AAPAEQgoACgEgEQgEgCgoAAIgFABIAPgDIgxgBIA4AAQAKAAgEACQgDABANAAIAjgBQAKgCgXgBIAeABIAnAAQgGACAdABIAnABQgFADglAAIg+ACg");
	this.shape_142.setTransform(194.6,172.5);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#11AA0C").s().p("AgSAKIAkgCQAKgBgcgCIhYgDIA1gBQAcAAAWADIAPgEQgagBhkABQAmgEAugDQAggCBCgBQATABgNACQgOACAMABQgRgBgNACQgOABAFACQAPAAAZgCQACABgHABQgGABAIAAIgqAAQgbAAgCAEQAwAAgbADIgmADQgEgBgOAAg");
	this.shape_143.setTransform(430.8,168.8);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#11AA0C").s().p("AgKAAQAQgBAEABQAEAAgLACQAEgBgRgBg");
	this.shape_144.setTransform(285.4,169.2);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#11AA0C").s().p("AjSAMQgXgCAMgBIgeABQgCgBANgBQANAAAAgBIgOAAQAIgBgBgFQAFgCApAAQANACgZAAQgbABAHAEQAOAAAFgCIADgCQAdAAgDAEQAFgBAYAAQAZAAAIgCQAegBgHADQgGADAQAAIAVgHIA5ABQAqgBgDgFQgDgHAzgCQgJADAXAEQAYAEAjABIg2ABQgnABgVgBQAYADglAAQgqABAMADQAngEA7ACIgKABQANAAAkgDQAggCAaABQAQAAACABQABAAAAABQAAAAgBAAQAAAAgBABQgBAAgBABQAmgCAAABIgRAIQg4ABg7gBIhqAAQgEgBAOgBQiWgBgsAEIgogCg");
	this.shape_145.setTransform(-15,177.1);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#11AA0C").s().p("AikAAIhOACQAAgEBNABQBbABAZgEQAWAEAZgBQgCgFA0AAIBYgBQAJABgRABQgTACAMABIAtgDQAagBAYABIgHACQAmgCgEACQgJADACAAIgqAAIgmAAQgMADgZACIgxABQAEgCgQgCQgPgCADAAIhUAAQg2AAgaABIANAAQgcABgGADQgGADgTAAg");
	this.shape_146.setTransform(-90.6,176);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#11AA0C").s().p("AgDABIADgBQABAAABAAQABAAAAAAQABAAAAAAQAAAAgBABg");
	this.shape_147.setTransform(-32.6,174.9);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#11AA0C").s().p("AmAAWQgBAAAAAAQAAAAABAAQAAABABAAQABAAABAAIgrgCQgkgCADgDIAagEQANgDAbAAQAUAEAzgBIBZgDIAPgDQAIgCAYAAQgDACgiADQgXACAUADQAdACAdgBQAigCAJgEQgwABAHgGQAGgEgvAAIAcgBQASgCATgBQAWABghADQgdAEBBgBIALgHIBTABQhBACgQADIBSAAQAwABADADQAugEBrgKQBcgLBDgDQAhAAAEAEQAEAEgSACQAdAAANgDIAdgFQgXAEABABIASAFIAZgBIjVAeQgZAEhEgCQhEgCgPACQAMgCgQgCQgQgDgaABQgEABAQACQiDgIgyAKIAbgHIg9ADIgtAEQAJgBgCgBQgPgCgeACQgfACgMgBIAVgCQAHgCgtABQgTABgNACQgPADAXABg");
	this.shape_148.setTransform(-82.3,177.2);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#11AA0C").s().p("AAngBIgVACIg4ABIBNgDg");
	this.shape_149.setTransform(-23.1,173.5);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#11AA0C").s().p("AAAAAIALAAIgVABQAKgBAAAAg");
	this.shape_150.setTransform(-32.2,175.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#11AA0C").s().p("AAAAAQAHAAgEAAIgGABg");
	this.shape_151.setTransform(-243.5,170.3);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#11AA0C").s().p("AhPAHQAjgDALgDQATgEAJgCIgOAAIAVgCQgFACAIAAQALABgEABIBEgEIgNAEIg5AGIgQABIgeAEIgPAAIgcgBg");
	this.shape_152.setTransform(21.4,166.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#11AA0C").s().p("AhlAHIBigNIADAAQgTACAPADQANACAagBIgIAAQAGAAASAAQAWgBAJABQgRAAAPABIAWADIiYAAQAFgCAKAAQgSAAgPADQgMACgPAAIgGAAg");
	this.shape_153.setTransform(-20.8,174.3);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#11AA0C").s().p("AhRAJQAigBADgDIgYABQgQgBAMgCQARgCAAgBIA3ACIAfgGQgfgCACgBQAGgCgLgDQAGACAwAAQApAAALAEIhAAHQAeAAAIgBIACAHIAJAAIgOADQgHACgGAAQglgDgwAAQgRACgPABIgtAAQgIgCAcgBg");
	this.shape_154.setTransform(446.1,169.2);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#11AA0C").s().p("AhEAFQgLgCgNAAIgTAAQAkAAAJgEQAIgFAvAAIgJABIgDABQAhAEAdgEIgEACIBNAAQgHACgiAAQgjgBgFABIArABIhIAEQAVgCgNgCQgLgBgSABQgDAEgHABIgjABQAHgBgLgBg");
	this.shape_155.setTransform(466.5,169.6);

	this.addChild(this.shape_155,this.shape_154,this.shape_153,this.shape_152,this.shape_151,this.shape_150,this.shape_149,this.shape_148,this.shape_147,this.shape_146,this.shape_145,this.shape_144,this.shape_143,this.shape_142,this.shape_141,this.shape_140,this.shape_139,this.shape_138,this.shape_137,this.shape_136,this.shape_135,this.shape_134,this.shape_133,this.shape_132,this.shape_131,this.shape_130,this.shape_129,this.shape_128,this.shape_127,this.shape_126,this.shape_125,this.shape_124,this.shape_123,this.shape_122,this.shape_121,this.shape_120,this.shape_119,this.shape_118,this.shape_117,this.shape_116,this.shape_115,this.shape_114,this.shape_113,this.shape_112,this.shape_111,this.shape_110,this.shape_109,this.shape_108,this.shape_107,this.shape_106,this.shape_105,this.shape_104,this.shape_103,this.shape_102,this.shape_101,this.shape_100,this.shape_99,this.shape_98,this.shape_97,this.shape_96,this.shape_95,this.shape_94,this.shape_93,this.shape_92,this.shape_91,this.shape_90,this.shape_89,this.shape_88,this.shape_87,this.shape_86,this.shape_85,this.shape_84,this.shape_83,this.shape_82,this.shape_81,this.shape_80,this.shape_79,this.shape_78,this.shape_77,this.shape_76,this.shape_75,this.shape_74,this.shape_73,this.shape_72,this.shape_71,this.shape_70,this.shape_69,this.shape_68,this.shape_67,this.shape_66,this.shape_65,this.shape_64,this.shape_63,this.instance_2,this.instance_1,this.instance,this.shape_62,this.shape_61,this.shape_60,this.shape_59,this.shape_58,this.shape_57,this.shape_56,this.shape_55,this.shape_54,this.shape_53,this.shape_52,this.shape_51,this.shape_50,this.shape_49,this.shape_48,this.shape_47,this.shape_46,this.shape_45,this.shape_44,this.shape_43,this.shape_42,this.shape_41,this.shape_40,this.shape_39,this.shape_38,this.shape_37,this.shape_36,this.shape_35,this.shape_34,this.shape_33,this.shape_32,this.shape_31,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-389.7,-178.7,867.6,358.4);


(lib.combinado2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.dado("synched",0);
	this.instance.setTransform(141.2,50,0.344,0.344,0,0,0,-10,20.9);

	this.instance_1 = new lib.moneda("single",0);
	this.instance_1.setTransform(44.6,50.1,1,1,0,0,0,-0.9,0.4);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2,0,176.5,100);


(lib.combinado1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.dado("synched",0);
	this.instance.setTransform(141.2,50,0.344,0.344,0,0,0,-10,20.9);

	this.instance_1 = new lib.moneda("single",1);
	this.instance_1.setTransform(44.6,50.1,1,1,0,0,0,-0.9,0.4);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,178.5,100);


(lib.animacionArbol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 7
	this.instance = new lib.combinado1("synched",0);
	this.instance.setTransform(89.4,147.5,2.409,2.409,0,0,0,89.4,50);

	this.instance_1 = new lib.combinado2("synched",0);
	this.instance_1.setTransform(89.4,147.5,2.409,2.409,0,0,0,89.4,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance,p:{scaleX:2.409,scaleY:2.409,x:89.4,regX:89.4,regY:50,y:147.5}}]},14).to({state:[{t:this.instance,p:{scaleX:0.949,scaleY:0.949,x:89.5,regX:89.4,regY:50,y:147.5}}]},4).to({state:[{t:this.instance,p:{scaleX:1.106,scaleY:1.106,x:89.6,regX:89.5,regY:50,y:147.5}}]},2).to({state:[{t:this.instance,p:{scaleX:0.926,scaleY:0.926,x:89.6,regX:89.5,regY:50.1,y:147.6}}]},2).to({state:[{t:this.instance_1,p:{scaleX:2.409,scaleY:2.409,x:89.4,regX:89.4,regY:50,y:147.5}}]},26).to({state:[{t:this.instance_1,p:{scaleX:0.949,scaleY:0.949,x:89.5,regX:89.4,regY:50,y:147.5}}]},4).to({state:[{t:this.instance_1,p:{scaleX:1.106,scaleY:1.106,x:89.6,regX:89.5,regY:50,y:147.5}}]},2).to({state:[{t:this.instance_1,p:{scaleX:0.926,scaleY:0.926,x:89.6,regX:89.5,regY:50.2,y:147.6}}]},2).wait(30));

	// Capa 6
	this.text = new cjs.Text("1", "16px Verdana");
	this.text.lineHeight = 16;
	this.text.setTransform(566.2,0);

	this.text_1 = new cjs.Text("cara", "20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(325.2,42);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAyjgIaam4ArFjLIwFNk");
	this.shape.setTransform(385.2,79.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.text_1},{t:this.text}]},32).to({state:[]},53).wait(1));

	// Capa 5
	this.text_2 = new cjs.Text("1", "16px Verdana");
	this.text_2.lineHeight = 16;
	this.text_2.setTransform(566.2,160);

	this.text_3 = new cjs.Text("cruz", "20px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(325.2,202);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAyFiIaam1A7KlhIO/K5");
	this.shape_1.setTransform(385.2,181.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.text_3},{t:this.text_2}]},65).wait(21));

	// Capa 1
	this.text_4 = new cjs.Text("6", "16px Verdana");
	this.text_4.lineHeight = 16;
	this.text_4.setTransform(566.2,97.3);

	this.text_5 = new cjs.Text("5", "16px Verdana");
	this.text_5.lineHeight = 16;
	this.text_5.setTransform(566.2,77.8);

	this.text_6 = new cjs.Text("4", "16px Verdana");
	this.text_6.lineHeight = 16;
	this.text_6.setTransform(566.2,58.4);

	this.text_7 = new cjs.Text("3", "16px Verdana");
	this.text_7.lineHeight = 16;
	this.text_7.setTransform(566.2,38.9);

	this.text_8 = new cjs.Text("2", "16px Verdana");
	this.text_8.lineHeight = 16;
	this.text_8.setTransform(566.2,19.5);

	this.text_9 = new cjs.Text("1", "16px Verdana");
	this.text_9.lineHeight = 16;
	this.text_9.setTransform(566.2,0);

	this.text_10 = new cjs.Text("6", "16px Verdana");
	this.text_10.lineHeight = 16;
	this.text_10.setTransform(566.2,257.3);

	this.text_11 = new cjs.Text("5", "16px Verdana");
	this.text_11.lineHeight = 16;
	this.text_11.setTransform(566.2,237.8);

	this.text_12 = new cjs.Text("4", "16px Verdana");
	this.text_12.lineHeight = 16;
	this.text_12.setTransform(566.2,218.4);

	this.text_13 = new cjs.Text("3", "16px Verdana");
	this.text_13.lineHeight = 16;
	this.text_13.setTransform(566.2,198.9);

	this.text_14 = new cjs.Text("2", "16px Verdana");
	this.text_14.lineHeight = 16;
	this.text_14.setTransform(566.2,179.5);

	this.text_15 = new cjs.Text("cara", "20px Verdana");
	this.text_15.lineHeight = 20;
	this.text_15.setTransform(325.2,42);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AbHlJI6an0Iaam3Aazw3I6GD6IakhGAazq7I6GiCIakE2AazODI6GiCIakE2AazIHI6GD6IakhGAbHT1I6an0ArKsoIwFNk");
	this.shape_2.setTransform(385.7,140.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4}]},85).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_3();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(28).to({_off:false},0).to({alpha:1},10).wait(22));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({alpha:1},9).wait(11).to({alpha:0},10).wait(22));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(8).to({alpha:0},9).wait(43));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,509.2,391.5);


(lib.animacion8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.instance = new lib.dados3_5();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(50).wait(25).to({_off:false},0).to({alpha:1},8).to({_off:true},18).wait(49));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).wait(8).to({_off:false},0).to({alpha:1},9).wait(8).to({alpha:0},8).to({_off:true},18).wait(49));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(8).to({alpha:0},9).to({_off:true},34).wait(49));

	// Capa 9
	this.instance_3 = new lib.dados3_2();
	this.instance_3.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24).to({_off:false},0).to({alpha:1},10).to({_off:true},16).wait(100));

	// Capa 10
	this.instance_4 = new lib.dados2();
	this.instance_4.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(8).to({_off:false},0).to({alpha:1},9).wait(7).to({alpha:0},10).to({_off:true},16).wait(100));

	// Capa 11
	this.instance_5 = new lib.dados1();
	this.instance_5.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({alpha:0},9).to({_off:true},33).wait(100));

	// Capa 13
	this.instance_6 = new lib.dados3_6();
	this.instance_6.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(101).wait(24).to({_off:false},0).to({alpha:1},10).wait(15));

	// Capa 14
	this.instance_7 = new lib.dados2();
	this.instance_7.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(101).wait(7).to({_off:false},0).to({alpha:1},10).wait(7).to({alpha:0},10).wait(15));

	// Capa 15
	this.instance_8 = new lib.dados1();
	this.instance_8.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(101).to({_off:false},0).wait(7).to({alpha:0},10).wait(32));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,509.2,391.5);


(lib.animacion7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	/* Layers with classic tweens must contain only a single symbol instance. */

	// Capa 2
	this.instance = new lib.dados2();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({alpha:1},6).wait(7).to({alpha:0},8).to({_off:true},12).wait(8).to({_off:false},0).to({alpha:1},8).wait(6).to({alpha:0},8).to({_off:true},9).wait(8).to({_off:false},0).to({alpha:1},9).wait(9).to({alpha:0},10).wait(11));

	// Capa 1
	this.instance_1 = new lib.dados1();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({alpha:0},6).wait(27).to({alpha:1},0).wait(8).to({alpha:0},8).wait(23).to({alpha:1},0).wait(8).to({alpha:0},9).wait(30));

	// Capa 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(126));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_6();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(27).to({_off:false},0).to({alpha:1},10).wait(23));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},9).wait(11).to({alpha:0},10).wait(23));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({alpha:0},9).wait(44));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_5();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(27).to({_off:false},0).to({alpha:1},10).wait(23));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},9).wait(11).to({alpha:0},10).wait(23));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({alpha:0},9).wait(44));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_4();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off:false},0).to({alpha:1},9).wait(25));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},9).wait(10).to({alpha:0},9).wait(25));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({alpha:0},9).wait(44));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_3();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(28).to({_off:false},0).to({alpha:1},9).wait(23));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({alpha:1},9).wait(11).to({alpha:0},9).wait(23));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(8).to({alpha:0},9).wait(43));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_2();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({_off:false},0).to({alpha:1},9).wait(27));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).to({alpha:1},9).wait(9).to({alpha:0},9).wait(27));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(6).to({alpha:0},9).wait(45));

	// Capa 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.instance = new lib.dados3_1();
	this.instance.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off:false},0).to({alpha:1},8).wait(26));

	// Capa 2
	this.instance_1 = new lib.dados2();
	this.instance_1.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({alpha:1},10).wait(9).to({alpha:0},8).wait(26));

	// Capa 1
	this.instance_2 = new lib.dados1();
	this.instance_2.setTransform(254.7,195.7,0.779,0.779,0,0,0,44.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({alpha:0},10).wait(43));

	// Capa 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A33D").s().p("EgxMAfeQgzABgjgkQgigigBgyMAAAg7MQABgyAigjQAjgkAzAAMBiaAAAQAxAAAjAkQAkAjgBAyMAAAA7MQABAygkAiQgjAkgxgBg");
	this.shape.setTransform(254.4,171.9,0.779,0.779);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,0,509.5,391.5);


(lib.animacion8_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.instance = new lib.animacion8("synched",0,false);
	this.instance.setTransform(417.3,120,0.674,0.674,0,0,0,254.6,195.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(187));

	// Capa 1
	this.text = new cjs.Text("Se ha lanzado el dado 25 veces y los resultados son:", "20px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 785;
	this.text.setTransform(0,295.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"Se ha lanzado el dado 25 veces y los resultados son:"}}]}).to({state:[{t:this.text,p:{text:"Se ha lanzado el dado 25 veces y los resultados son: 2"}}]},34).to({state:[{t:this.text,p:{text:"Se ha lanzado el dado 25 veces y los resultados son: 2, 5"}}]},51).to({state:[{t:this.text,p:{text:"Se ha lanzado el dado 25 veces y los resultados son: 2, 5, 6"}}]},56).to({state:[{t:this.text,p:{text:"Se ha lanzado el dado 25 veces y los resultados son: 2, 5, 6, 5, 1, 4, 2, 4, 4, 6, 1, 4, 1, 2, 5, 6, 4, 1, 2, 5, 5, 3, 5, 1, 4."}}]},22).wait(24));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-57.7,789,381.9);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}