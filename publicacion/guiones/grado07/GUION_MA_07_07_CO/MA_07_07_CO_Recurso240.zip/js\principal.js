(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
      
this.text = new cjs.Text(txt['tit2'], "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 263;
	this.text.setTransform(232.6,360.1+incremento);

	this.text_1 = new cjs.Text(txt['tit1'], "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 263;
	this.text_1.setTransform(233.6,211.1+incremento);

	this.instance = new lib.btn_cuales();
	this.instance.setTransform(234.6,371.2,1,1,0,0,0,133.9,28.9);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_cuales(), 3);
this.instance.on("click", function (evt) {
        putStage(new lib.frame3_1());
    });

	this.instance_1 = new lib.btn_cuales();
	this.instance_1.setTransform(235.5,222.2,1,1,0,0,0,133.9,28.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_cuales(), 3);

 this.instance_1.on("click", function (evt) {
        putStage(new lib.frame2_1());
    });
	this.instance_2 = new lib._57283753();
	this.instance_2.setTransform(342.4,0);
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance_2,this.instance_1,this.instance,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
      this.instance= new lib.garbanzo1();

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.garbanzo2();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.garbanzo3();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.garbanzo4();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.garbanzo5();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.garbanzo6();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
      this.instance= new lib.garbanzo7();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });
       
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

     (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
      this.instance= new lib.peces1();

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.peces2();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.peces3();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.peces4();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
      this.instance= new lib.peces5();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
      this.instance= new lib.peces6();
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
      
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib.comida = function() {
	this.initialize(img.comida);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,102);

(lib.garbanzo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text("Se pesa un garbanzo y se observa que su masa es de 6 g.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 760;
	this.text.setTransform(50.6,119.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(34));

	// grmos
	this.text_1 = new cjs.Text("6 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(224.4,389.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1}]},49).wait(1));

	// plato granbanzos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AUFiWQrLAhvAACQtOADgtgcQAJA5BgA0QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+gA0CiSQAAADABADQgFgDAEgDQAAgBAAgBIADAAQgCABgBABg");
	this.shape.setTransform(531.4,517.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhfg1gKg5QAtAcNOgCQPAgDLLghQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYgA0DiUIADAAIgDACIAAgCg");
	this.shape_1.setTransform(531.5,517.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(50));

	// cuerpo
	this.instance = new lib.balanza();
	this.instance.setTransform(225.8,380.4,1,1,0,0,0,115,152);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(50));

	// granbanzo
	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(422.3,437.7);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(407.3,434.8);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(407.3,452.7);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(391.3,453.3);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(380.3,467.3);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(532.5,439.7);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(469.3,435.7);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(492.3,432.7);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(515.3,437.3);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(505.5,462.6);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(475.3,455.3);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(435.3,457.7);

	this.instance_13 = new lib.Símbolo4("synched",0);
	this.instance_13.setTransform(458.3,443.3);

	this.instance_14 = new lib.Símbolo4("synched",0);
	this.instance_14.setTransform(436.3,439.3);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(572.4,446.9);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(552.4,453.9);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(530.4,456.9);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(511.3,459.3);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(488.3,460.3);

	this.instance_20 = new lib.Símbolo4("synched",0);
	this.instance_20.setTransform(464.3,462.3);

	this.instance_21 = new lib.Símbolo4("synched",0);
	this.instance_21.setTransform(442.3,460.3);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(420.3,457.3);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(586.5,464.7);

	this.instance_24 = new lib.Símbolo4("synched",0);
	this.instance_24.setTransform(566.4,470.8);

	this.instance_25 = new lib.Símbolo4("synched",0);
	this.instance_25.setTransform(542.3,475.2);

	this.instance_26 = new lib.Símbolo4("synched",0);
	this.instance_26.setTransform(519.3,478.2);

	this.instance_27 = new lib.Símbolo4("synched",0);
	this.instance_27.setTransform(494.3,480.2);

	this.instance_28 = new lib.Símbolo4("synched",0);
	this.instance_28.setTransform(472.3,480.2);

	this.instance_29 = new lib.Símbolo4("synched",0);
	this.instance_29.setTransform(448.3,478.2);

	this.instance_30 = new lib.Símbolo4("synched",0);
	this.instance_30.setTransform(425.3,478.2);

	this.instance_31 = new lib.Símbolo4("synched",0);
	this.instance_31.setTransform(401.3,473.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(50));

	// Capa 7
	this.instance_32 = new lib.taza_bascula();
	this.instance_32.setTransform(224.5,284,1,1,0,0,0,115,57.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).wait(50));

	// Capa 8
	this.instance_33 = new lib.Símbolo4("synched",0);
	this.instance_33.setTransform(536.5,422.2);

	this.instance_34 = new lib.Símbolo4("synched",0);
	this.instance_34.setTransform(505.5,416.7);

	this.instance_35 = new lib.Símbolo4("synched",0);
	this.instance_35.setTransform(480.3,437.8);

	this.instance_36 = new lib.Símbolo4("synched",0);
	this.instance_36.setTransform(498.3,448.3);

	this.instance_37 = new lib.Símbolo4("synched",0);
	this.instance_37.setTransform(552.4,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33}]}).wait(50));

	// Capa 9
	this.instance_38 = new lib.Símbolo4("synched",0);
	this.instance_38.setTransform(438.3,417.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_38}]}).wait(50));

	// Capa 10
	this.instance_39 = new lib.Símbolo4("synched",0);
	this.instance_39.setTransform(461.3,416.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_39}]}).wait(50));

	// Capa 11
	this.instance_40 = new lib.Símbolo4("synched",0);
	this.instance_40.setTransform(448.3,432.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_40}]}).wait(50));

	// grabarzo2
	this.instance_41 = new lib.Símbolo4("synched",0);
	this.instance_41.setTransform(521.4,426.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_41}]}).wait(50));

	// granbanzo
	this.instance_42 = new lib.Símbolo4();
	this.instance_42.setTransform(530.4,456.9,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(1).to({x:529.9,y:446.6},0).wait(1).to({x:529.4,y:436.4},0).wait(1).to({x:528.7,y:426.2},0).wait(1).to({x:527.9,y:416},0).wait(1).to({x:526.9,y:405.8},0).wait(1).to({x:525.8,y:395.6},0).wait(1).to({x:524.5,y:385.4},0).wait(1).to({x:523.1,y:375.3},0).wait(1).to({x:521.5,y:365.2},0).wait(1).to({x:519.7,y:355.1},0).wait(1).to({x:517.6,y:345},0).wait(1).to({x:515.4,y:335.1},0).wait(1).to({x:512.8,y:325.1},0).wait(1).to({x:510,y:315.3},0).wait(1).to({x:506.9,y:305.5},0).wait(1).to({x:503.4,y:295.9},0).wait(1).to({x:499.6,y:286.4},0).wait(1).to({x:495.3,y:277.1},0).wait(1).to({x:490.5,y:268},0).wait(1).to({x:485.3,y:259.2},0).wait(1).to({x:479.5,y:250.8},0).wait(1).to({x:473.1,y:242.8},0).wait(1).to({x:466,y:235.4},0).wait(1).to({x:458.3,y:228.6},0).wait(1).to({x:450,y:222.6},0).wait(1).to({x:441.1,y:217.6},0).wait(1).to({x:431.7,y:213.5},0).wait(1).to({x:422,y:210.4},0).wait(1).to({x:411.9,y:208.3},0).wait(1).to({x:401.8,y:207.2},0).wait(1).to({x:391.5,y:207},0).wait(1).to({x:381.3,y:207.6},0).wait(1).to({x:371.1,y:208.8},0).wait(1).to({x:361.1,y:210.7},0).wait(1).to({x:351.1,y:213.2},0).wait(1).to({x:341.3,y:216.1},0).wait(1).to({x:331.6,y:219.4},0).wait(1).to({x:322.1,y:223.1},0).wait(1).to({x:312.6,y:227.1},0).wait(1).to({x:303.3,y:231.4},0).wait(1).to({x:294.1,y:235.9},0).wait(1).to({x:285.1,y:240.7},0).wait(1).to({x:276.1,y:245.7},0).wait(1).to({x:267.3,y:250.9},0).wait(1).to({x:258.6,y:256.2},0).wait(1).to({x:249.9,y:261.7},0).wait(1).to({x:241.3,y:267.3},0).wait(1).to({x:232.9,y:273},0).wait(1).to({x:224.5,y:278.9},0).wait(1));

	

	this.text_2 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_2.lineHeight = 42;
	this.text_2.lineWidth = 554;
	this.text_2.setTransform(106,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,50.4,619.5,511.4);
(lib.garbanzo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text("Si se pesan 2 garbanzos, la masa es de 12 g.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 547;
	this.text.setTransform(49.6,119.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},25).wait(25));

	// grmos
	this.text_1 = new cjs.Text("6 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(224.4,389.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1,p:{text:"6 g",lineWidth:55}}]}).to({state:[{t:this.text_1,p:{text:"6 g",lineWidth:55}}]},48).to({state:[{t:this.text_1,p:{text:"12 g",lineWidth:69}}]},1).wait(1));

	// plato granbanzos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AUFiWQrLAhvAACQtOADgtgcQAJA5BgA0QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+gA0CiSQAAADABADQgFgDAEgDQAAgBAAgBIADAAQgCABgBABg");
	this.shape.setTransform(531.4,517.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhfg1gKg5QAtAcNOgCQPAgDLLghQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYgA0DiUIADAAIgDACIAAgCg");
	this.shape_1.setTransform(531.5,517.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(50));

	// cuerpo
	this.instance = new lib.balanza();
	this.instance.setTransform(225.8,380.4,1,1,0,0,0,115,152);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(50));

	// granbanzo
	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(422.3,437.7);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(407.3,434.8);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(407.3,452.7);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(391.3,453.3);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(380.3,467.3);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(532.5,439.7);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(469.3,435.7);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(492.3,432.7);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(515.3,437.3);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(505.5,462.6);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(475.3,455.3);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(435.3,457.7);

	this.instance_13 = new lib.Símbolo4("synched",0);
	this.instance_13.setTransform(458.3,443.3);

	this.instance_14 = new lib.Símbolo4("synched",0);
	this.instance_14.setTransform(436.3,439.3);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(572.4,446.9);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(552.4,453.9);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(530.4,456.9);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(511.3,459.3);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(488.3,460.3);

	this.instance_20 = new lib.Símbolo4("synched",0);
	this.instance_20.setTransform(464.3,462.3);

	this.instance_21 = new lib.Símbolo4("synched",0);
	this.instance_21.setTransform(442.3,460.3);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(420.3,457.3);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(586.5,464.7);

	this.instance_24 = new lib.Símbolo4("synched",0);
	this.instance_24.setTransform(566.4,470.8);

	this.instance_25 = new lib.Símbolo4("synched",0);
	this.instance_25.setTransform(542.3,475.2);

	this.instance_26 = new lib.Símbolo4("synched",0);
	this.instance_26.setTransform(519.3,478.2);

	this.instance_27 = new lib.Símbolo4("synched",0);
	this.instance_27.setTransform(494.3,480.2);

	this.instance_28 = new lib.Símbolo4("synched",0);
	this.instance_28.setTransform(472.3,480.2);

	this.instance_29 = new lib.Símbolo4("synched",0);
	this.instance_29.setTransform(448.3,478.2);

	this.instance_30 = new lib.Símbolo4("synched",0);
	this.instance_30.setTransform(425.3,478.2);

	this.instance_31 = new lib.Símbolo4("synched",0);
	this.instance_31.setTransform(401.3,473.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(50));

	// Capa 7
	this.instance_32 = new lib.taza_bascula();
	this.instance_32.setTransform(224.5,284,1,1,0,0,0,115,57.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).wait(50));

	// Capa 8
	this.instance_33 = new lib.Símbolo4("synched",0);
	this.instance_33.setTransform(536.5,422.2);

	this.instance_34 = new lib.Símbolo4("synched",0);
	this.instance_34.setTransform(505.5,416.7);

	this.instance_35 = new lib.Símbolo4("synched",0);
	this.instance_35.setTransform(480.3,437.8);

	this.instance_36 = new lib.Símbolo4("synched",0);
	this.instance_36.setTransform(498.3,448.3);

	this.instance_37 = new lib.Símbolo4("synched",0);
	this.instance_37.setTransform(552.4,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33}]}).wait(50));

	// Capa 9
	this.instance_38 = new lib.Símbolo4("synched",0);
	this.instance_38.setTransform(438.3,417.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_38}]}).wait(50));

	// Capa 10
	this.instance_39 = new lib.Símbolo4("synched",0);
	this.instance_39.setTransform(461.3,416.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_39}]}).wait(50));

	// Capa 11
	this.instance_40 = new lib.Símbolo4("synched",0);
	this.instance_40.setTransform(448.3,432.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_40}]}).wait(50));

	// grabarzo2
	this.instance_41 = new lib.Símbolo4("synched",0);
	this.instance_41.setTransform(571.4,468.8,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(1).to({x:567.7,y:458.4},0).wait(1).to({x:563.9,y:448.1},0).wait(1).to({x:560,y:437.8},0).wait(1).to({x:556,y:427.6},0).wait(1).to({x:551.9,y:417.4},0).wait(1).to({x:547.7,y:407.2},0).wait(1).to({x:543.4,y:397.1},0).wait(1).to({x:538.9,y:387},0).wait(1).to({x:534.3,y:377},0).wait(1).to({x:529.6,y:367.1},0).wait(1).to({x:524.7,y:357.2},0).wait(1).to({x:519.7,y:347.4},0).wait(1).to({x:514.4,y:337.7},0).wait(1).to({x:509.1,y:328.1},0).wait(1).to({x:503.5,y:318.6},0).wait(1).to({x:497.7,y:309.3},0).wait(1).to({x:491.7,y:300.1},0).wait(1).to({x:485.4,y:291},0).wait(1).to({x:478.9,y:282.1},0).wait(1).to({x:472.2,y:273.4},0).wait(1).to({x:465.1,y:265},0).wait(1).to({x:457.7,y:256.8},0).wait(1).to({x:450,y:249},0).wait(1).to({x:441.9,y:241.5},0).wait(1).to({x:433.4,y:234.5},0).wait(1).to({x:424.6,y:227.9},0).wait(1).to({x:415.4,y:221.9},0).wait(1).to({x:405.7,y:216.6},0).wait(1).to({x:395.7,y:212},0).wait(1).to({x:385.4,y:208.3},0).wait(1).to({x:374.8,y:205.4},0).wait(1).to({x:363.9,y:203.5},0).wait(1).to({x:353,y:202.6},0).wait(1).to({x:342},0).wait(1).to({x:331,y:203.6},0).wait(1).to({x:320.2,y:205.5},0).wait(1).to({x:309.5,y:208.2},0).wait(1).to({x:299,y:211.6},0).wait(1).to({x:288.8,y:215.6},0).wait(1).to({x:278.8,y:220.3},0).wait(1).to({x:269.1,y:225.4},0).wait(1).to({x:259.6,y:231},0).wait(1).to({x:250.3,y:237},0).wait(1).to({x:241.3,y:243.3},0).wait(1).to({x:232.5,y:249.9},0).wait(1).to({x:224,y:256.8},0).wait(1).to({x:215.6,y:263.9},0).wait(1).to({x:207.4,y:271.3},0).wait(1).to({x:199.4,y:278.8},0).wait(1));

	// granbanzo
	this.instance_42 = new lib.Símbolo4();
	this.instance_42.setTransform(224.5,278.9,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(50));

	// rewind
	this.text_2 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_2.lineHeight = 42;
	this.text_2.lineWidth = 554;
	this.text_2.setTransform(106,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2}]}).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.5,50.4,571.5,495.3);
(lib.garbanzo3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text("Si se pesan 5 garbanzos, la masa es de 30 g.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 525;
	this.text.setTransform(50.8,119.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},40).wait(20));

	// grmos
	this.text_1 = new cjs.Text("12 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(224.4,389.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1,p:{text:"12 g"}}]}).to({state:[{t:this.text_1,p:{text:"30 g"}}]},59).wait(1));

	// plato granbanzos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AUFiWQrLAhvAACQtOADgtgcQAJA5BgA0QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+gA0CiSQAAADABADQgFgDAEgDQAAgBAAgBIADAAQgCABgBABg");
	this.shape.setTransform(531.4,517.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhfg1gKg5QAtAcNOgCQPAgDLLghQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYgA0DiUIADAAIgDACIAAgCg");
	this.shape_1.setTransform(531.5,517.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(60));

	// cuerpo
	this.instance = new lib.balanza();
	this.instance.setTransform(225.8,380.4,1,1,0,0,0,115,152);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(60));

	// granbanzo
	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(422.3,437.7);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(407.3,434.8);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(407.3,452.7);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(391.3,453.3);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(380.3,467.3);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(532.5,439.7);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(469.3,435.7);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(492.3,432.7);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(515.3,437.3);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(505.5,462.6);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(475.3,455.3);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(435.3,457.7);

	this.instance_13 = new lib.Símbolo4("synched",0);
	this.instance_13.setTransform(458.3,443.3);

	this.instance_14 = new lib.Símbolo4("synched",0);
	this.instance_14.setTransform(436.3,439.3);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(572.4,446.9);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(552.4,453.9);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(530.4,456.9);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(511.3,459.3);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(488.3,460.3);

	this.instance_20 = new lib.Símbolo4("synched",0);
	this.instance_20.setTransform(464.3,462.3);

	this.instance_21 = new lib.Símbolo4("synched",0);
	this.instance_21.setTransform(442.3,460.3);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(420.3,457.3);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(586.5,464.7);

	this.instance_24 = new lib.Símbolo4("synched",0);
	this.instance_24.setTransform(566.4,470.8);

	this.instance_25 = new lib.Símbolo4("synched",0);
	this.instance_25.setTransform(542.3,475.2);

	this.instance_26 = new lib.Símbolo4("synched",0);
	this.instance_26.setTransform(519.3,478.2);

	this.instance_27 = new lib.Símbolo4("synched",0);
	this.instance_27.setTransform(494.3,480.2);

	this.instance_28 = new lib.Símbolo4("synched",0);
	this.instance_28.setTransform(472.3,480.2);

	this.instance_29 = new lib.Símbolo4("synched",0);
	this.instance_29.setTransform(448.3,478.2);

	this.instance_30 = new lib.Símbolo4("synched",0);
	this.instance_30.setTransform(425.3,478.2);

	this.instance_31 = new lib.Símbolo4("synched",0);
	this.instance_31.setTransform(401.3,473.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(60));

	// Capa 7
	this.instance_32 = new lib.taza_bascula();
	this.instance_32.setTransform(224.5,284,1,1,0,0,0,115,57.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).wait(60));

	// Capa 8
	this.instance_33 = new lib.Símbolo4("synched",0);
	this.instance_33.setTransform(536.5,422.2);

	this.instance_34 = new lib.Símbolo4("synched",0);
	this.instance_34.setTransform(505.5,416.7);

	this.instance_35 = new lib.Símbolo4("synched",0);
	this.instance_35.setTransform(480.3,437.8);

	this.instance_36 = new lib.Símbolo4("synched",0);
	this.instance_36.setTransform(498.3,448.3);

	this.instance_37 = new lib.Símbolo4("synched",0);
	this.instance_37.setTransform(552.4,431);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33}]}).wait(60));

	// Capa 9
	this.instance_38 = new lib.Símbolo4("synched",0);
	this.instance_38.setTransform(438.3,417.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(10).to({regX:50,regY:42.5,x:488.3,y:460.3},0).wait(1).to({x:485.7,y:450.6},0).wait(1).to({x:483.1,y:441.1},0).wait(1).to({x:480.3,y:431.5},0).wait(1).to({x:477.5,y:421.9},0).wait(1).to({x:474.6,y:412.4},0).wait(1).to({x:471.6,y:403},0).wait(1).to({x:468.5,y:393.5},0).wait(1).to({x:465.2,y:384.1},0).wait(1).to({x:461.9,y:374.7},0).wait(1).to({x:458.4,y:365.4},0).wait(1).to({x:454.8,y:356.1},0).wait(1).to({x:451,y:346.9},0).wait(1).to({x:447.1,y:337.8},0).wait(1).to({x:443,y:328.7},0).wait(1).to({x:438.7,y:319.7},0).wait(1).to({x:434.3,y:310.8},0).wait(1).to({x:429.6,y:302},0).wait(1).to({x:424.8,y:293.3},0).wait(1).to({x:419.6,y:284.8},0).wait(1).to({x:414.2,y:276.4},0).wait(1).to({x:408.5,y:268.3},0).wait(1).to({x:402.5,y:260.3},0).wait(1).to({x:396.2,y:252.7},0).wait(1).to({x:389.5,y:245.4},0).wait(1).to({x:382.3,y:238.4},0).wait(1).to({x:374.8,y:231.9},0).wait(1).to({x:366.8,y:226},0).wait(1).to({x:358.4,y:220.6},0).wait(1).to({x:349.6,y:216.1},0).wait(1).to({x:340.3,y:212.4},0).wait(1).to({x:330.8,y:209.6},0).wait(1).to({x:321,y:207.8},0).wait(1).to({x:311.1,y:207},0).wait(1).to({x:301.1,y:207.3},0).wait(1).to({x:291.3,y:208.4},0).wait(1).to({x:281.5,y:210.4},0).wait(1).to({x:271.9,y:213.1},0).wait(1).to({x:262.6,y:216.5},0).wait(1).to({x:253.5,y:220.5},0).wait(1).to({x:244.6,y:225},0).wait(1).to({x:235.9,y:229.9},0).wait(1).to({x:227.5,y:235.1},0).wait(1).to({x:219.3,y:240.7},0).wait(1).to({x:211.2,y:246.6},0).wait(1).to({x:203.4,y:252.8},0).wait(1).to({x:195.8,y:259.1},0).wait(1).to({x:188.3,y:265.7},0).wait(1).to({x:180.9,y:272.4},0).wait(1).to({x:173.8,y:279.3},0).wait(1));

	// Capa 10
	this.instance_39 = new lib.Símbolo4("synched",0);
	this.instance_39.setTransform(461.3,416.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(6).to({regX:50,regY:42.5,x:511.3,y:459.3},0).wait(1).to({x:508.3,y:450.1},0).wait(1).to({x:505.3,y:440.9},0).wait(1).to({x:502.2,y:431.8},0).wait(1).to({x:499.1,y:422.7},0).wait(1).to({x:496,y:413.6},0).wait(1).to({x:492.8,y:404.5},0).wait(1).to({x:489.6,y:395.4},0).wait(1).to({x:486.3,y:386.3},0).wait(1).to({x:483,y:377.3},0).wait(1).to({x:479.6,y:368.3},0).wait(1).to({x:476.1,y:359.3},0).wait(1).to({x:472.6,y:350.3},0).wait(1).to({x:469,y:341.4},0).wait(1).to({x:465.4,y:332.5},0).wait(1).to({x:461.7,y:323.6},0).wait(1).to({x:457.9,y:314.7},0).wait(1).to({x:453.9,y:305.9},0).wait(1).to({x:449.9,y:297.1},0).wait(1).to({x:445.8,y:288.4},0).wait(1).to({x:441.6,y:279.8},0).wait(1).to({x:437.2,y:271.2},0).wait(1).to({x:432.7,y:262.7},0).wait(1).to({x:428.1,y:254.2},0).wait(1).to({x:423.2,y:245.9},0).wait(1).to({x:418.2,y:237.7},0).wait(1).to({x:412.9,y:229.7},0).wait(1).to({x:407.3,y:221.8},0).wait(1).to({x:401.4,y:214.2},0).wait(1).to({x:395.1,y:206.9},0).wait(1).to({x:388.3,y:200},0).wait(1).to({x:381,y:193.7},0).wait(1).to({x:373.1,y:188.3},0).wait(1).to({x:364.4,y:184.1},0).wait(1).to({x:355.1,y:181.8},0).wait(1).to({x:345.5,y:181.9},0).wait(1).to({x:336.2,y:184.5},0).wait(1).to({x:327.7,y:189},0).wait(1).to({x:320.2,y:195},0).wait(1).to({x:313.4,y:201.9},0).wait(1).to({x:307.4,y:209.5},0).wait(1).to({x:302,y:217.4},0).wait(1).to({x:297,y:225.6},0).wait(1).to({x:292.3,y:234.1},0).wait(1).to({x:288.1,y:242.7},0).wait(1).to({x:284,y:251.5},0).wait(1).to({x:280.3,y:260.3},0).wait(1).to({x:276.7,y:269.3},0).wait(1).to({x:273.3,y:278.3},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// Capa 11
	this.instance_40 = new lib.Símbolo4("synched",0);
	this.instance_40.setTransform(498.3,474.8,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_40).wait(1).to({x:496.9,y:466},0).wait(1).to({x:495.4,y:457.2},0).wait(1).to({x:493.9,y:448.5},0).wait(1).to({x:492.3,y:439.7},0).wait(1).to({x:490.6,y:431},0).wait(1).to({x:488.9,y:422.3},0).wait(1).to({x:487.1,y:413.5},0).wait(1).to({x:485.1,y:404.9},0).wait(1).to({x:483.1,y:396.2},0).wait(1).to({x:481,y:387.5},0).wait(1).to({x:478.8,y:378.9},0).wait(1).to({x:476.5,y:370.3},0).wait(1).to({x:474.1,y:361.8},0).wait(1).to({x:471.5,y:353.2},0).wait(1).to({x:468.8,y:344.8},0).wait(1).to({x:466,y:336.3},0).wait(1).to({x:463,y:328},0).wait(1).to({x:459.8,y:319.6},0).wait(1).to({x:456.4,y:311.4},0).wait(1).to({x:452.8,y:303.3},0).wait(1).to({x:449,y:295.2},0).wait(1).to({x:444.9,y:287.3},0).wait(1).to({x:440.5,y:279.6},0).wait(1).to({x:435.9,y:272},0).wait(1).to({x:430.9,y:264.6},0).wait(1).to({x:425.5,y:257.6},0).wait(1).to({x:419.6,y:250.8},0).wait(1).to({x:413.4,y:244.5},0).wait(1).to({x:406.6,y:238.8},0).wait(1).to({x:399.3,y:233.6},0).wait(1).to({x:391.6,y:229.3},0).wait(1).to({x:383.4,y:225.8},0).wait(1).to({x:374.8,y:223.4},0).wait(1).to({x:366,y:222},0).wait(1).to({x:357.2,y:221.6},0).wait(1).to({x:348.3,y:222.2},0).wait(1).to({x:339.5,y:223.8},0).wait(1).to({x:330.9,y:226},0).wait(1).to({x:322.5,y:229},0).wait(1).to({x:314.3,y:232.5},0).wait(1).to({x:306.4,y:236.5},0).wait(1).to({x:298.6,y:240.9},0).wait(1).to({x:291.1,y:245.6},0).wait(1).to({x:283.8,y:250.6},0).wait(1).to({x:276.6,y:255.9},0).wait(1).to({x:269.6,y:261.4},0).wait(1).to({x:262.7,y:267},0).wait(1).to({x:256,y:272.9},0).wait(1).to({x:249.5,y:278.9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// grabarzo2
	this.instance_41 = new lib.Símbolo4("synched",0);
	this.instance_41.setTransform(199.4,278.8,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// granbanzo
	this.instance_42 = new lib.Símbolo4();
	this.instance_42.setTransform(224.5,278.9,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(60));

	// rewind
	this.text_2 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_2.lineHeight = 42;
	this.text_2.lineWidth = 554;
	this.text_2.setTransform(106,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2}]}).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.5,50.4,571.5,495.3);
(lib.garbanzo4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text("Si se pesan 10 garbanzos, la masa es de 60 g.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 530;
	this.text.setTransform(50.3,119.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[]},1).to({state:[{t:this.text}]},29).wait(45));

	// grmos
	this.text_1 = new cjs.Text("30 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(224.4,389.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1,p:{text:"30 g"}}]}).to({state:[{t:this.text_1,p:{text:"60 g"}}]},74).wait(1));

	// plato granbanzos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AUFiWQrLAhvAACQtOADgtgcQAJA5BgA0QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+gA0CiSQAAADABADQgFgDAEgDQAAgBAAgBIADAAQgCABgBABg");
	this.shape.setTransform(531.4,517.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhfg1gKg5QAtAcNOgCQPAgDLLghQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYgA0DiUIADAAIgDACIAAgCg");
	this.shape_1.setTransform(531.5,517.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(75));

	// cuerpo
	this.instance = new lib.balanza();
	this.instance.setTransform(225.8,380.4,1,1,0,0,0,115,152);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(75));

	// granbanzo
	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(422.3,437.7);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(407.3,434.8);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(407.3,452.7);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(391.3,453.3);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(380.3,467.3);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(532.5,439.7);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(469.3,435.7);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(492.3,432.7);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(515.3,437.3);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(505.5,462.6);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(475.3,455.3);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(435.3,457.7);

	this.instance_13 = new lib.Símbolo4("synched",0);
	this.instance_13.setTransform(458.3,443.3);

	this.instance_14 = new lib.Símbolo4("synched",0);
	this.instance_14.setTransform(436.3,439.3);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(572.4,446.9);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(552.4,453.9);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(530.4,456.9);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(511.3,459.3);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(488.3,460.3);

	this.instance_20 = new lib.Símbolo4("synched",0);
	this.instance_20.setTransform(464.3,462.3);

	this.instance_21 = new lib.Símbolo4("synched",0);
	this.instance_21.setTransform(442.3,460.3);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(420.3,457.3);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(586.5,464.7);

	this.instance_24 = new lib.Símbolo4("synched",0);
	this.instance_24.setTransform(566.4,470.8);

	this.instance_25 = new lib.Símbolo4("synched",0);
	this.instance_25.setTransform(542.3,475.2);

	this.instance_26 = new lib.Símbolo4("synched",0);
	this.instance_26.setTransform(519.3,478.2);

	this.instance_27 = new lib.Símbolo4("synched",0);
	this.instance_27.setTransform(494.3,480.2);

	this.instance_28 = new lib.Símbolo4("synched",0);
	this.instance_28.setTransform(472.3,480.2);

	this.instance_29 = new lib.Símbolo4("synched",0);
	this.instance_29.setTransform(448.3,478.2);

	this.instance_30 = new lib.Símbolo4("synched",0);
	this.instance_30.setTransform(425.3,478.2);

	this.instance_31 = new lib.Símbolo4("synched",0);
	this.instance_31.setTransform(401.3,473.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(75));

	// Capa 7
	this.instance_32 = new lib.taza_bascula();
	this.instance_32.setTransform(224.5,284,1,1,0,0,0,115,57.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_32}]}).wait(75));

	// Capa 8
	this.instance_33 = new lib.Símbolo1();
	this.instance_33.setTransform(554.9,465.2,1,1,0,0,0,51.6,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(1).to({regX:63,regY:41.5,rotation:0.2,x:567.1,y:470.2},0).wait(1).to({rotation:0.4,x:567.9,y:462.6},0).wait(1).to({rotation:0.6,x:568.6,y:455},0).wait(1).to({rotation:0.8,x:569.2,y:447.5},0).wait(1).to({rotation:1,x:569.7,y:439.8},0).wait(1).to({rotation:1.2,x:570.1,y:432.3},0).wait(1).to({rotation:1.4,x:570.5,y:424.6},0).wait(1).to({rotation:1.6,x:570.8,y:417.1},0).wait(1).to({rotation:1.8,x:570.9,y:409.4},0).wait(1).to({rotation:2,x:571,y:401.8},0).wait(1).to({rotation:2.2,x:570.9,y:394.2},0).wait(1).to({rotation:2.4,x:570.8,y:386.5},0).wait(1).to({rotation:2.6,x:570.5,y:379},0).wait(1).to({rotation:2.8,x:570,y:371.3},0).wait(1).to({rotation:3,x:569.4,y:363.8},0).wait(1).to({rotation:3.2,x:568.7,y:356.2},0).wait(1).to({rotation:3.4,x:567.8,y:348.6},0).wait(1).to({rotation:3.6,x:566.7,y:341},0).wait(1).to({rotation:3.9,x:565.5,y:333.5},0).wait(1).to({rotation:4.1,x:564,y:326},0).wait(1).to({rotation:4.3,x:562.4,y:318.6},0).wait(1).to({rotation:4.5,x:560.4,y:311.2},0).wait(1).to({rotation:4.7,x:558.3,y:303.9},0).wait(1).to({rotation:4.9,x:555.8,y:296.7},0).wait(1).to({rotation:5.1,x:553.1,y:289.5},0).wait(1).to({rotation:5.3,x:550.1,y:282.5},0).wait(1).to({rotation:5.5,x:546.7,y:275.6},0).wait(1).to({rotation:5.7,x:543.1,y:269},0).wait(1).to({rotation:5.9,x:539,y:262.5},0).wait(1).to({rotation:6.1,x:534.6,y:256.2},0).wait(1).to({rotation:6.3,x:529.7,y:250.2},0).wait(1).to({rotation:6.5,x:524.6,y:244.6},0).wait(1).to({rotation:6.7,x:519,y:239.3},0).wait(1).to({rotation:6.9,x:513.1,y:234.4},0).wait(1).to({rotation:7.1,x:506.9,y:230},0).wait(1).to({rotation:7.3,x:500.4,y:225.9},0).wait(1).to({rotation:7.5,x:493.5,y:222.4},0).wait(1).to({rotation:7.7,x:486.5,y:219.3},0).wait(1).to({rotation:7.9,x:479.3,y:216.6},0).wait(1).to({rotation:8.1,x:471.9,y:214.4},0).wait(1).to({rotation:8.3,x:464.5,y:212.5},0).wait(1).to({rotation:8.5,x:456.9,y:211.2},0).wait(1).to({rotation:8.7,x:449.2,y:210.1},0).wait(1).to({rotation:8.9,x:441.6,y:209.4},0).wait(1).to({rotation:9.1,x:433.9,y:209.1},0).wait(1).to({rotation:9.3,x:426.2,y:209},0).wait(1).to({rotation:9.5,x:418.5,y:209.2},0).wait(1).to({rotation:9.7,x:410.8,y:209.6},0).wait(1).to({rotation:9.9,x:403.1,y:210.3},0).wait(1).to({rotation:10.1,x:395.4,y:211.2},0).wait(1).to({rotation:10.3,x:387.8,y:212.4},0).wait(1).to({rotation:10.5,x:380.2,y:213.6},0).wait(1).to({rotation:10.7,x:372.6,y:215.1},0).wait(1).to({rotation:10.9,x:365.1,y:216.7},0).wait(1).to({rotation:11.1,x:357.6,y:218.4},0).wait(1).to({rotation:11.4,x:350.1,y:220.3},0).wait(1).to({rotation:11.6,x:342.7,y:222.3},0).wait(1).to({rotation:11.8,x:335.3,y:224.5},0).wait(1).to({rotation:12,x:327.9,y:226.7},0).wait(1).to({rotation:12.2,x:320.5,y:229.1},0).wait(1).to({rotation:12.4,x:313.2,y:231.6},0).wait(1).to({rotation:12.6,x:305.9,y:234.1},0).wait(1).to({rotation:12.8,x:298.7,y:236.7},0).wait(1).to({rotation:13,x:291.5,y:239.5},0).wait(1).to({rotation:13.2,x:284.3,y:242.2},0).wait(1).to({rotation:13.4,x:277.1,y:245.1},0).wait(1).to({rotation:13.6,x:270,y:248.1},0).wait(1).to({rotation:13.8,x:262.9,y:251},0).wait(1).to({rotation:14,x:255.8,y:254.1},0).wait(1).to({rotation:14.2,x:248.8,y:257.3},0).wait(1).to({rotation:14.4,x:241.7,y:260.4},0).wait(1).to({rotation:14.6,x:234.7,y:263.6},0).wait(1).to({rotation:14.8,x:227.7,y:266.9},0).wait(1).to({rotation:15,x:220.7,y:270.3},0).wait(1));

	// Capa 9
	this.instance_34 = new lib.Símbolo4("synched",0);
	this.instance_34.setTransform(173.8,279.3,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// Capa 10
	this.instance_35 = new lib.Símbolo4("synched",0);
	this.instance_35.setTransform(273.3,278.3,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// Capa 11
	this.instance_36 = new lib.Símbolo4("synched",0);
	this.instance_36.setTransform(249.5,278.9,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_36).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// grabarzo2
	this.instance_37 = new lib.Símbolo4("synched",0);
	this.instance_37.setTransform(199.4,278.8,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// granbanzo
	this.instance_38 = new lib.Símbolo4();
	this.instance_38.setTransform(224.5,278.9,1,1,0,0,0,50,42.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(75));

	// rewind
	this.text_2 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_2.lineHeight = 42;
	this.text_2.lineWidth = 554;
	this.text_2.setTransform(106,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2}]}).wait(75));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92.5,50.4,571.5,495.3);
(lib.garbanzo5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 2
	this.text = new cjs.Text("A continuación se organizan estos valores en una gráfica. ", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(373,119.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text}]}).wait(115));

	// Capa 3
	this.instance = new lib.Símbolo4("synched",0);
	this.instance.setTransform(171.7,254.8,0.833,0.833,0,0,0,50.1,42.5);

	this.text_1 = new cjs.Text("60 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(831.3,311.1+incremento,0.833,0.833);

	this.instance_1 = new lib.balanza();
	this.instance_1.setTransform(830.5,315.8,0.557,0.557,0,0,0,115,152);

	this.instance_2 = new lib.taza_bascula();
	this.instance_2.setTransform(829.8,262.1,0.557,0.557,0,0,0,115,57.5);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(800.2,240.2,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(882.2,248.5,0.833,0.833,0,0,0,50,42.5);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(818,241.8,0.833,0.833,0,0,0,50,42.5);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(858,241.8,0.833,0.833,0,0,0,50,42.5);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(838,241.8,0.833,0.833,0,0,0,50,42.5);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(790.5,255.1,0.833,0.833,0,0,0,50,42.5);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(868.5,253.4,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(808.5,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(848.5,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(828.5,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.text_2 = new cjs.Text("30 g", "bold 20px Verdana", "#00FF00");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(621,311.1+incremento,0.833,0.833);

	this.instance_13 = new lib.balanza();
	this.instance_13.setTransform(619.2,315.8,0.557,0.557,0,0,0,115,152);

	this.instance_14 = new lib.taza_bascula();
	this.instance_14.setTransform(618.5,262.1,0.557,0.557,0,0,0,115,57.5);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(579.2,255.1,0.833,0.833,0,0,0,50,42.5);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(657.2,253.4,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(597.2,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(637.2,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(617.2,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.text_3 = new cjs.Text("12 g", "bold 20px Verdana", "#00FF00");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(395.8,311.1+incremento,0.833,0.833);

	this.instance_20 = new lib.balanza();
	this.instance_20.setTransform(395.5,315.8,0.557,0.557,0,0,0,115,152);

	this.instance_21 = new lib.taza_bascula();
	this.instance_21.setTransform(394.8,262.1,0.557,0.557,0,0,0,115,57.5);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(385.7,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(405.7,256.7,0.833,0.833,0,0,0,50.1,42.5);

	this.text_4 = new cjs.Text("6 g", "bold 20px Verdana", "#00FF00");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(175.1,311+incremento,0.833,0.833);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_4},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.text_3},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.text_2},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.text_1},{t:this.instance}]}).wait(115));

	// bascula
	this.instance_24 = new lib.balanza();
	this.instance_24.setTransform(174.3,314.2,0.557,0.557,0,0,0,115,152);

	this.instance_25 = new lib.taza_bascula();
	this.instance_25.setTransform(173.6,260.5,0.557,0.557,0,0,0,115,57.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_25},{t:this.instance_24}]}).wait(115));

	// Capa 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhUHLIAAuVICoAAIAAOVg");
	var mask_graphics_1 = new cjs.Graphics().p("AhkHLIAAuVIDJAAIAAOVg");
	var mask_graphics_2 = new cjs.Graphics().p("Ah0HLIAAuVIDpAAIAAOVg");
	var mask_graphics_3 = new cjs.Graphics().p("AiEHLIAAuVIEJAAIAAOVg");
	var mask_graphics_4 = new cjs.Graphics().p("AiVHLIAAuVIErAAIAAOVg");
	var mask_graphics_5 = new cjs.Graphics().p("AilHLIAAuVIFLAAIAAOVg");
	var mask_graphics_6 = new cjs.Graphics().p("Ai1HLIAAuVIFrAAIAAOVg");
	var mask_graphics_7 = new cjs.Graphics().p("AjGHLIAAuVIGNAAIAAOVg");
	var mask_graphics_8 = new cjs.Graphics().p("AjWHLIAAuVIGtAAIAAOVg");
	var mask_graphics_9 = new cjs.Graphics().p("AjmHLIAAuVIHNAAIAAOVg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj3HLIAAuVIHvAAIAAOVg");
	var mask_graphics_11 = new cjs.Graphics().p("AkHHLIAAuVIIPAAIAAOVg");
	var mask_graphics_12 = new cjs.Graphics().p("AkXHLIAAuVIIvAAIAAOVg");
	var mask_graphics_13 = new cjs.Graphics().p("AkoHLIAAuVIJRAAIAAOVg");
	var mask_graphics_14 = new cjs.Graphics().p("Ak4HLIAAuVIJxAAIAAOVg");
	var mask_graphics_15 = new cjs.Graphics().p("AlIHLIAAuVIKRAAIAAOVg");
	var mask_graphics_16 = new cjs.Graphics().p("AlZHLIAAuVIKzAAIAAOVg");
	var mask_graphics_17 = new cjs.Graphics().p("AlpHLIAAuVILTAAIAAOVg");
	var mask_graphics_18 = new cjs.Graphics().p("Al5HLIAAuVILzAAIAAOVg");
	var mask_graphics_19 = new cjs.Graphics().p("AmKHLIAAuVIMVAAIAAOVg");
	var mask_graphics_20 = new cjs.Graphics().p("AmaHLIAAuVIM1AAIAAOVg");
	var mask_graphics_21 = new cjs.Graphics().p("AmqHLIAAuVINVAAIAAOVg");
	var mask_graphics_22 = new cjs.Graphics().p("Am6HLIAAuVIN1AAIAAOVg");
	var mask_graphics_23 = new cjs.Graphics().p("AnLHLIAAuVIOXAAIAAOVg");
	var mask_graphics_24 = new cjs.Graphics().p("AnbHLIAAuVIO3AAIAAOVg");
	var mask_graphics_25 = new cjs.Graphics().p("AnrHLIAAuVIPXAAIAAOVg");
	var mask_graphics_26 = new cjs.Graphics().p("An8HLIAAuVIP5AAIAAOVg");
	var mask_graphics_27 = new cjs.Graphics().p("AoMHLIAAuVIQZAAIAAOVg");
	var mask_graphics_28 = new cjs.Graphics().p("AocHLIAAuVIQ5AAIAAOVg");
	var mask_graphics_29 = new cjs.Graphics().p("AotHLIAAuVIRbAAIAAOVg");
	var mask_graphics_30 = new cjs.Graphics().p("Ao9HLIAAuVIR7AAIAAOVg");
	var mask_graphics_31 = new cjs.Graphics().p("ApNHLIAAuVISbAAIAAOVg");
	var mask_graphics_32 = new cjs.Graphics().p("ApeHLIAAuVIS9AAIAAOVg");
	var mask_graphics_33 = new cjs.Graphics().p("ApuHLIAAuVITdAAIAAOVg");
	var mask_graphics_34 = new cjs.Graphics().p("Ap+HLIAAuVIT9AAIAAOVg");
	var mask_graphics_35 = new cjs.Graphics().p("AqPHLIAAuVIUfAAIAAOVg");
	var mask_graphics_36 = new cjs.Graphics().p("AqfHLIAAuVIU/AAIAAOVg");
	var mask_graphics_37 = new cjs.Graphics().p("AqvHLIAAuVIVfAAIAAOVg");
	var mask_graphics_38 = new cjs.Graphics().p("ArAHLIAAuVIWBAAIAAOVg");
	var mask_graphics_39 = new cjs.Graphics().p("ArQHLIAAuVIWhAAIAAOVg");
	var mask_graphics_40 = new cjs.Graphics().p("ArgHLIAAuVIXBAAIAAOVg");
	var mask_graphics_41 = new cjs.Graphics().p("ArwHLIAAuVIXhAAIAAOVg");
	var mask_graphics_42 = new cjs.Graphics().p("AsBHLIAAuVIYDAAIAAOVg");
	var mask_graphics_43 = new cjs.Graphics().p("AsRHLIAAuVIYjAAIAAOVg");
	var mask_graphics_44 = new cjs.Graphics().p("AshHLIAAuVIZDAAIAAOVg");
	var mask_graphics_45 = new cjs.Graphics().p("AsyHLIAAuVIZlAAIAAOVg");
	var mask_graphics_46 = new cjs.Graphics().p("AtCHLIAAuVIaFAAIAAOVg");
	var mask_graphics_47 = new cjs.Graphics().p("AtSHLIAAuVIalAAIAAOVg");
	var mask_graphics_48 = new cjs.Graphics().p("AtjHLIAAuVIbHAAIAAOVg");
	var mask_graphics_49 = new cjs.Graphics().p("AtzHLIAAuVIbnAAIAAOVg");
	var mask_graphics_50 = new cjs.Graphics().p("AuDHLIAAuVIcHAAIAAOVg");
	var mask_graphics_51 = new cjs.Graphics().p("AuUHLIAAuVIcpAAIAAOVg");
	var mask_graphics_52 = new cjs.Graphics().p("AukHLIAAuVIdJAAIAAOVg");
	var mask_graphics_53 = new cjs.Graphics().p("Au0HLIAAuVIdpAAIAAOVg");
	var mask_graphics_54 = new cjs.Graphics().p("AvFHLIAAuVIeLAAIAAOVg");
	var mask_graphics_55 = new cjs.Graphics().p("AvVHLIAAuVIerAAIAAOVg");
	var mask_graphics_56 = new cjs.Graphics().p("AvlHLIAAuVIfLAAIAAOVg");
	var mask_graphics_57 = new cjs.Graphics().p("Av2HLIAAuVIftAAIAAOVg");
	var mask_graphics_58 = new cjs.Graphics().p("AwGHLIAAuVMAgNAAAIAAOVg");
	var mask_graphics_59 = new cjs.Graphics().p("AwWHLIAAuVMAgtAAAIAAOVg");
	var mask_graphics_60 = new cjs.Graphics().p("AwmHLIAAuVMAhNAAAIAAOVg");
	var mask_graphics_61 = new cjs.Graphics().p("Aw3HLIAAuVMAhvAAAIAAOVg");
	var mask_graphics_62 = new cjs.Graphics().p("AxHHLIAAuVMAiPAAAIAAOVg");
	var mask_graphics_63 = new cjs.Graphics().p("AxXHLIAAuVMAivAAAIAAOVg");
	var mask_graphics_64 = new cjs.Graphics().p("AxoHLIAAuVMAjRAAAIAAOVg");
	var mask_graphics_65 = new cjs.Graphics().p("Ax4HLIAAuVMAjxAAAIAAOVg");
	var mask_graphics_66 = new cjs.Graphics().p("AyIHLIAAuVMAkRAAAIAAOVg");
	var mask_graphics_67 = new cjs.Graphics().p("AyZHLIAAuVMAkzAAAIAAOVg");
	var mask_graphics_68 = new cjs.Graphics().p("AypHLIAAuVMAlTAAAIAAOVg");
	var mask_graphics_69 = new cjs.Graphics().p("Ay5HLIAAuVMAlzAAAIAAOVg");
	var mask_graphics_70 = new cjs.Graphics().p("AzKHLIAAuVMAmVAAAIAAOVg");
	var mask_graphics_71 = new cjs.Graphics().p("AzaHLIAAuVMAm1AAAIAAOVg");
	var mask_graphics_72 = new cjs.Graphics().p("AzqHLIAAuVMAnVAAAIAAOVg");
	var mask_graphics_73 = new cjs.Graphics().p("Az7HLIAAuVMAn3AAAIAAOVg");
	var mask_graphics_74 = new cjs.Graphics().p("A0LHLIAAuVMAoXAAAIAAOVg");
	var mask_graphics_75 = new cjs.Graphics().p("A0bHLIAAuVMAo3AAAIAAOVg");
	var mask_graphics_76 = new cjs.Graphics().p("A0sHLIAAuVMApZAAAIAAOVg");
	var mask_graphics_77 = new cjs.Graphics().p("A08HLIAAuVMAp5AAAIAAOVg");
	var mask_graphics_78 = new cjs.Graphics().p("A1MHLIAAuVMAqZAAAIAAOVg");
	var mask_graphics_79 = new cjs.Graphics().p("A1cHLIAAuVMAq5AAAIAAOVg");
	var mask_graphics_80 = new cjs.Graphics().p("A1tHLIAAuVMArbAAAIAAOVg");
	var mask_graphics_81 = new cjs.Graphics().p("A19HLIAAuVMAr7AAAIAAOVg");
	var mask_graphics_82 = new cjs.Graphics().p("A2NHLIAAuVMAsbAAAIAAOVg");
	var mask_graphics_83 = new cjs.Graphics().p("A2eHLIAAuVMAs9AAAIAAOVg");
	var mask_graphics_84 = new cjs.Graphics().p("A2uHLIAAuVMAtdAAAIAAOVg");
	var mask_graphics_85 = new cjs.Graphics().p("A2+HLIAAuVMAt9AAAIAAOVg");
	var mask_graphics_86 = new cjs.Graphics().p("A3PHLIAAuVMAufAAAIAAOVg");
	var mask_graphics_87 = new cjs.Graphics().p("A3fHLIAAuVMAu/AAAIAAOVg");
	var mask_graphics_88 = new cjs.Graphics().p("A3vHLIAAuVMAvfAAAIAAOVg");
	var mask_graphics_89 = new cjs.Graphics().p("A4AHLIAAuVMAwBAAAIAAOVg");
	var mask_graphics_90 = new cjs.Graphics().p("A4QHLIAAuVMAwhAAAIAAOVg");
	var mask_graphics_91 = new cjs.Graphics().p("A4gHLIAAuVMAxBAAAIAAOVg");
	var mask_graphics_92 = new cjs.Graphics().p("A4xHLIAAuVMAxjAAAIAAOVg");
	var mask_graphics_93 = new cjs.Graphics().p("A5BHLIAAuVMAyDAAAIAAOVg");
	var mask_graphics_94 = new cjs.Graphics().p("A5RHLIAAuVMAyjAAAIAAOVg");
	var mask_graphics_95 = new cjs.Graphics().p("A5iHLIAAuVMAzEAAAIAAOVg");
	var mask_graphics_96 = new cjs.Graphics().p("A5yHLIAAuVMAzlAAAIAAOVg");
	var mask_graphics_97 = new cjs.Graphics().p("A6CHLIAAuVMA0FAAAIAAOVg");
	var mask_graphics_98 = new cjs.Graphics().p("A6SHLIAAuVMA0lAAAIAAOVg");
	var mask_graphics_99 = new cjs.Graphics().p("A6jHLIAAuVMA1HAAAIAAOVg");
	var mask_graphics_100 = new cjs.Graphics().p("A6zHLIAAuVMA1nAAAIAAOVg");
	var mask_graphics_101 = new cjs.Graphics().p("A7DHLIAAuVMA2HAAAIAAOVg");
	var mask_graphics_102 = new cjs.Graphics().p("A7UHLIAAuVMA2pAAAIAAOVg");
	var mask_graphics_103 = new cjs.Graphics().p("A7kHLIAAuVMA3JAAAIAAOVg");
	var mask_graphics_104 = new cjs.Graphics().p("A70HLIAAuVMA3pAAAIAAOVg");
	var mask_graphics_105 = new cjs.Graphics().p("A8FHLIAAuVMA4LAAAIAAOVg");
	var mask_graphics_106 = new cjs.Graphics().p("A8VHLIAAuVMA4rAAAIAAOVg");
	var mask_graphics_107 = new cjs.Graphics().p("A8lHLIAAuVMA5LAAAIAAOVg");
	var mask_graphics_108 = new cjs.Graphics().p("A82HLIAAuVMA5tAAAIAAOVg");
	var mask_graphics_109 = new cjs.Graphics().p("A9GHLIAAuVMA6NAAAIAAOVg");
	var mask_graphics_110 = new cjs.Graphics().p("A9WHLIAAuVMA6tAAAIAAOVg");
	var mask_graphics_111 = new cjs.Graphics().p("A9nHLIAAuVMA7PAAAIAAOVg");
	var mask_graphics_112 = new cjs.Graphics().p("A93HLIAAuVMA7vAAAIAAOVg");
	var mask_graphics_113 = new cjs.Graphics().p("A+HHLIAAuVMA8PAAAIAAOVg");
	var mask_graphics_114 = new cjs.Graphics().p("A+YHLIAAuVMA8wAAAIAAOVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:410.5,y:470}).wait(1).to({graphics:mask_graphics_1,x:412.1,y:470}).wait(1).to({graphics:mask_graphics_2,x:413.7,y:470}).wait(1).to({graphics:mask_graphics_3,x:415.3,y:470}).wait(1).to({graphics:mask_graphics_4,x:417,y:470}).wait(1).to({graphics:mask_graphics_5,x:418.6,y:470}).wait(1).to({graphics:mask_graphics_6,x:420.2,y:470}).wait(1).to({graphics:mask_graphics_7,x:421.9,y:470}).wait(1).to({graphics:mask_graphics_8,x:423.5,y:470}).wait(1).to({graphics:mask_graphics_9,x:425.1,y:470.1}).wait(1).to({graphics:mask_graphics_10,x:426.8,y:470.1}).wait(1).to({graphics:mask_graphics_11,x:428.4,y:470.1}).wait(1).to({graphics:mask_graphics_12,x:430,y:470.1}).wait(1).to({graphics:mask_graphics_13,x:431.7,y:470.1}).wait(1).to({graphics:mask_graphics_14,x:433.3,y:470.1}).wait(1).to({graphics:mask_graphics_15,x:434.9,y:470.1}).wait(1).to({graphics:mask_graphics_16,x:436.6,y:470.1}).wait(1).to({graphics:mask_graphics_17,x:438.2,y:470.1}).wait(1).to({graphics:mask_graphics_18,x:439.8,y:470.1}).wait(1).to({graphics:mask_graphics_19,x:441.5,y:470.1}).wait(1).to({graphics:mask_graphics_20,x:443.1,y:470.2}).wait(1).to({graphics:mask_graphics_21,x:444.7,y:470.2}).wait(1).to({graphics:mask_graphics_22,x:446.3,y:470.2}).wait(1).to({graphics:mask_graphics_23,x:448,y:470.2}).wait(1).to({graphics:mask_graphics_24,x:449.6,y:470.2}).wait(1).to({graphics:mask_graphics_25,x:451.2,y:470.2}).wait(1).to({graphics:mask_graphics_26,x:452.9,y:470.2}).wait(1).to({graphics:mask_graphics_27,x:454.5,y:470.2}).wait(1).to({graphics:mask_graphics_28,x:456.1,y:470.2}).wait(1).to({graphics:mask_graphics_29,x:457.8,y:470.2}).wait(1).to({graphics:mask_graphics_30,x:459.4,y:470.2}).wait(1).to({graphics:mask_graphics_31,x:461,y:470.2}).wait(1).to({graphics:mask_graphics_32,x:462.7,y:470.3}).wait(1).to({graphics:mask_graphics_33,x:464.3,y:470.3}).wait(1).to({graphics:mask_graphics_34,x:465.9,y:470.3}).wait(1).to({graphics:mask_graphics_35,x:467.6,y:470.3}).wait(1).to({graphics:mask_graphics_36,x:469.2,y:470.3}).wait(1).to({graphics:mask_graphics_37,x:470.8,y:470.3}).wait(1).to({graphics:mask_graphics_38,x:472.5,y:470.3}).wait(1).to({graphics:mask_graphics_39,x:474.1,y:470.3}).wait(1).to({graphics:mask_graphics_40,x:475.7,y:470.3}).wait(1).to({graphics:mask_graphics_41,x:477.3,y:470.3}).wait(1).to({graphics:mask_graphics_42,x:479,y:470.3}).wait(1).to({graphics:mask_graphics_43,x:480.6,y:470.4}).wait(1).to({graphics:mask_graphics_44,x:482.2,y:470.4}).wait(1).to({graphics:mask_graphics_45,x:483.9,y:470.4}).wait(1).to({graphics:mask_graphics_46,x:485.5,y:470.4}).wait(1).to({graphics:mask_graphics_47,x:487.1,y:470.4}).wait(1).to({graphics:mask_graphics_48,x:488.8,y:470.4}).wait(1).to({graphics:mask_graphics_49,x:490.4,y:470.4}).wait(1).to({graphics:mask_graphics_50,x:492,y:470.4}).wait(1).to({graphics:mask_graphics_51,x:493.7,y:470.4}).wait(1).to({graphics:mask_graphics_52,x:495.3,y:470.4}).wait(1).to({graphics:mask_graphics_53,x:496.9,y:470.4}).wait(1).to({graphics:mask_graphics_54,x:498.6,y:470.4}).wait(1).to({graphics:mask_graphics_55,x:500.2,y:470.5}).wait(1).to({graphics:mask_graphics_56,x:470.8,y:470.5}).wait(1).to({graphics:mask_graphics_57,x:503.5,y:470.5}).wait(1).to({graphics:mask_graphics_58,x:505.1,y:470.5}).wait(1).to({graphics:mask_graphics_59,x:506.7,y:470.5}).wait(1).to({graphics:mask_graphics_60,x:508.3,y:470.5}).wait(1).to({graphics:mask_graphics_61,x:510,y:470.5}).wait(1).to({graphics:mask_graphics_62,x:511.6,y:470.5}).wait(1).to({graphics:mask_graphics_63,x:513.2,y:470.5}).wait(1).to({graphics:mask_graphics_64,x:514.9,y:470.5}).wait(1).to({graphics:mask_graphics_65,x:516.5,y:470.5}).wait(1).to({graphics:mask_graphics_66,x:518.1,y:470.6}).wait(1).to({graphics:mask_graphics_67,x:519.8,y:470.6}).wait(1).to({graphics:mask_graphics_68,x:521.4,y:470.6}).wait(1).to({graphics:mask_graphics_69,x:523,y:470.6}).wait(1).to({graphics:mask_graphics_70,x:524.7,y:470.6}).wait(1).to({graphics:mask_graphics_71,x:526.3,y:470.6}).wait(1).to({graphics:mask_graphics_72,x:527.9,y:470.6}).wait(1).to({graphics:mask_graphics_73,x:529.6,y:470.6}).wait(1).to({graphics:mask_graphics_74,x:531.2,y:470.6}).wait(1).to({graphics:mask_graphics_75,x:532.8,y:470.6}).wait(1).to({graphics:mask_graphics_76,x:534.5,y:470.6}).wait(1).to({graphics:mask_graphics_77,x:536.1,y:470.7}).wait(1).to({graphics:mask_graphics_78,x:537.7,y:470.7}).wait(1).to({graphics:mask_graphics_79,x:539.3,y:470.7}).wait(1).to({graphics:mask_graphics_80,x:541,y:470.7}).wait(1).to({graphics:mask_graphics_81,x:542.6,y:470.7}).wait(1).to({graphics:mask_graphics_82,x:544.2,y:470.7}).wait(1).to({graphics:mask_graphics_83,x:545.9,y:470.7}).wait(1).to({graphics:mask_graphics_84,x:547.5,y:470.7}).wait(1).to({graphics:mask_graphics_85,x:549.1,y:470.7}).wait(1).to({graphics:mask_graphics_86,x:550.8,y:470.7}).wait(1).to({graphics:mask_graphics_87,x:552.4,y:470.7}).wait(1).to({graphics:mask_graphics_88,x:554,y:470.7}).wait(1).to({graphics:mask_graphics_89,x:555.7,y:470.8}).wait(1).to({graphics:mask_graphics_90,x:557.3,y:470.8}).wait(1).to({graphics:mask_graphics_91,x:558.9,y:470.8}).wait(1).to({graphics:mask_graphics_92,x:560.6,y:470.8}).wait(1).to({graphics:mask_graphics_93,x:562.2,y:470.8}).wait(1).to({graphics:mask_graphics_94,x:563.8,y:470.8}).wait(1).to({graphics:mask_graphics_95,x:565.5,y:470.8}).wait(1).to({graphics:mask_graphics_96,x:567.1,y:470.8}).wait(1).to({graphics:mask_graphics_97,x:568.7,y:470.8}).wait(1).to({graphics:mask_graphics_98,x:570.3,y:470.8}).wait(1).to({graphics:mask_graphics_99,x:572,y:470.8}).wait(1).to({graphics:mask_graphics_100,x:573.6,y:470.9}).wait(1).to({graphics:mask_graphics_101,x:575.2,y:470.9}).wait(1).to({graphics:mask_graphics_102,x:576.9,y:470.9}).wait(1).to({graphics:mask_graphics_103,x:578.5,y:470.9}).wait(1).to({graphics:mask_graphics_104,x:580.1,y:470.9}).wait(1).to({graphics:mask_graphics_105,x:581.8,y:470.9}).wait(1).to({graphics:mask_graphics_106,x:583.4,y:470.9}).wait(1).to({graphics:mask_graphics_107,x:585,y:470.9}).wait(1).to({graphics:mask_graphics_108,x:586.7,y:470.9}).wait(1).to({graphics:mask_graphics_109,x:588.3,y:470.9}).wait(1).to({graphics:mask_graphics_110,x:589.9,y:470.9}).wait(1).to({graphics:mask_graphics_111,x:591.6,y:470.9}).wait(1).to({graphics:mask_graphics_112,x:593.2,y:470}).wait(1).to({graphics:mask_graphics_113,x:594.8,y:470}).wait(1).to({graphics:mask_graphics_114,x:596.5,y:470}).wait(1));
mask.setTransform(0,-40);
	// Capa 6
	this.text_5 = new cjs.Text("60", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(751.1,491.9);

	this.text_6 = new cjs.Text("10", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(749.1,439.9);

	this.text_7 = new cjs.Text("30", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(651.1,491.9);

	this.text_8 = new cjs.Text("5", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(648.1,439.9);

	this.text_9 = new cjs.Text("12 ", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(551.1,491.9);

	this.text_10 = new cjs.Text("2", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(547.1,439.9);

	this.text_11 = new cjs.Text("6 ", "20px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.setTransform(448.1,491.9);

	this.text_12 = new cjs.Text("1", "20px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 22;
	this.text_12.setTransform(447.1,439.9);

	this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5}]},19).wait(96));

	// tabla
	this.text_13 = new cjs.Text("masa (g)", "20px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 22;
	this.text_13.lineWidth = 211;
	this.text_13.setTransform(290.5,491.8);

	this.text_14 = new cjs.Text("nº de garbanzos", "20px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 22;
	this.text_14.lineWidth = 210;
	this.text_14.setTransform(290.2,439.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EAgpAH+IPUAAIAAn+IvUAAIAAH+IvyAAIvyAAIvcAAMghlAAAIAAn+IAAn9MAhlAAAIPcAAIPyAAIPyAAIPUAAIAAH9AQ3n9IAAH9IPyAAIAAn9ABFH+IAAn+IvcAAIAAH+AQ3H+IAAn+IvyAAIAAn9AuXn9IAAH9MghlAAA");
	this.shape.setTransform(492,480-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_14},{t:this.text_13}]}).wait(115));

	// ffwd-back
	

	this.text_15 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_15.lineHeight = 42;
	this.text_15.lineWidth = 554;
	this.text_15.setTransform(106,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_15}]}).wait(115));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,50.4,860.7,511.4);
(lib.garbanzo6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text(txt['tit1'], "48px Georgia");
	this.text.lineHeight = 50;
	this.text.lineWidth = 754;
	this.text.setTransform(106,50.4);

	this.text_1 = new cjs.Text("Al representar una relación de proporcionalidad directa gráficamente, siempre se obtiene una recta creciente.", "22px Verdana");
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 847;
	this.text_1.setTransform(50.4,119.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.text}]}).wait(140));

	// Capa 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1,1,1).p("AA2g2QAXAYAAAeQAAAggXAWQgXAXgfAAQgeAAgYgXQgWgWAAggQAAgeAWgYQAYgWAeAAQAfAAAXAWg");
	this.shape.setTransform(276,529.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag1A2QgXgXAAgfQAAgeAXgXQAWgXAfAAQAgAAAWAXQAXAXAAAeQAAAfgXAXQgWAXggAAQgfAAgWgXg");
	this.shape_1.setTransform(276,529.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,1,1).p("AAABNQgeAAgYgXQgWgWAAggQAAgeAWgYQAYgWAeAAQAfAAAXAWQAXAYAAAeQAAAggXAWQgXAXgfAAg");
	this.shape_2.setTransform(276,529.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FF0000").ss(1,1,1).p("ACdg2QgWgWAAggQAAggAWgXQAXgXAgAAQAgAAAWAXQAYAXAAAgQAAAggYAWQgWAXggAAQggAAgXgXgAkKCjQgXgWAAggQAAggAXgXQAXgXAgAAQAgAAAWAXQAXAXAAAgQAAAggXAWQgWAXggAAQggAAgXgXg");
	this.shape_3.setTransform(297.3,518.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AkKCkQgWgXAAggQAAggAWgXQAXgXAgABQAggBAWAXQAYAXAAAgQAAAggYAXQgWAWggAAQggAAgXgWgACdg2QgXgWABggQgBggAXgXQAXgWAgAAQAgAAAWAWQAXAXABAgQgBAggXAWQgWAYggAAQggAAgXgYg");
	this.shape_4.setTransform(297.3,518.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FF0000").ss(1,1,1).p("AoMC3QAAggAWgXQAXgWAgAAQAgAAAXAWQAXAXAAAgQAAAggXAXQgXAXggAAQggAAgXgXQgWgXAAgggAu1GSQAAggAWgXQAXgWAgAAQAgAAAXAWQAXAXAAAgQAAAggXAXQgXAXggAAQggAAgXgXQgWgXAAgggAOfnIQAXAXAAAgQAAAggXAWQgWAXggAAQghAAgWgXQgXgWAAggQAAggAXgXQAWgXAhAAQAgAAAWAXg");
	this.shape_5.setTransform(363.3,489.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AueHJQgXgXAAggQAAggAXgXQAWgWAhAAQAgAAAWAWQAXAXAAAgQAAAggXAXQgWAXggAAQghAAgWgXgAn1DuQgXgXAAggQAAggAXgXQAWgWAhAAQAgAAAWAWQAXAXAAAgQAAAggXAXQgWAXggAAQghAAgWgXgAMylbQgXgWAAggQAAggAXgXQAWgXAhAAQAgAAAWAXQAXAXAAAgQAAAggXAWQgWAXggAAQghAAgWgXg");
	this.shape_6.setTransform(363.3,489.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF0000").ss(1,1,1).p("AfttzQAAAggXAWQgWAYggAAQggAAgXgYQgXgWAAggQAAggAXgXQAXgWAgAAQAgAAAWAWQAXAXAAAggA32LnQgfAAgYgXQgWgXAAggQAAggAWgXQAYgWAfAAQAgAAAXAWQAXAXAAAgQAAAggXAXQgXAXggAAgA+fPBQgfAAgYgWQgWgXAAggQAAggAWgXQAYgXAfAAQAgAAAXAXQAXAXAAAgQAAAggXAXQgXAWggAAgAiWAYQAXAWAAAhQAAAggXAWQgWAXggAAQghAAgWgXQgXgWAAggQAAghAXgWQAWgXAhAAQAgAAAWAXg");
	this.shape_7.setTransform(471.2,441.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("A/VOrQgXgXAAggQAAggAXgXQAWgXAhABQAggBAWAXQAXAXAAAgQAAAggXAXQgWAWggAAQghAAgWgWgA4sLPQgXgWAAggQAAggAXgXQAWgWAhAAQAgAAAWAWQAXAXAAAgQAAAggXAWQgWAYggAAQghAAgWgYgAkDCFQgXgXAAgfQAAggAXgXQAWgXAhAAQAgAAAWAXQAXAXAAAgQAAAfgXAXQgWAXggAAQghAAgWgXgAdos9QgWgWAAggQAAggAWgXQAYgWAfgBQAgABAXAWQAXAXAAAgQAAAggXAWQgXAYggAAQgfAAgYgYg");
	this.shape_8.setTransform(471.2,441.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},9).to({state:[{t:this.shape_4},{t:this.shape_3}]},21).to({state:[{t:this.shape_6},{t:this.shape_5}]},71).to({state:[{t:this.shape_8},{t:this.shape_7}]},38).wait(1));

	// Capa 5
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FF0000").ss(3,1,1).p("AhAAcICBg3");
	this.shape_9.setTransform(280.6,525.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF0000").ss(3,1,1).p("AiKA9IEVh5");
	this.shape_10.setTransform(288,522.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FF0000").ss(3,1,1).p("Aj0BsIHpjX");
	this.shape_11.setTransform(298.6,517.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF0000").ss(3,1,1).p("Ak4CJIJxkS");
	this.shape_12.setTransform(305.4,514.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF0000").ss(3,1,1).p("AmiC4INFlv");
	this.shape_13.setTransform(316,510);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF0000").ss(3,1,1).p("ApYEIISxoP");
	this.shape_14.setTransform(334.2,502);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FF0000").ss(3,1,1).p("ArnFHIXPqN");
	this.shape_15.setTransform(348.5,495.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FF0000").ss(3,1,1).p("At0GFIbpsJ");
	this.shape_16.setTransform(362.6,489.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF0000").ss(3,1,1).p("AvzG9Ifnt5");
	this.shape_17.setTransform(375.3,483.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF0000").ss(3,1,1).p("A2PJzMAsfgTl");
	this.shape_18.setTransform(416.5,465.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF0000").ss(3,1,1).p("A/KNuMA+Vgbb");
	this.shape_19.setTransform(473.6,440.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},9).to({state:[{t:this.shape_10}]},11).to({state:[{t:this.shape_11}]},10).to({state:[{t:this.shape_12}]},15).to({state:[{t:this.shape_13}]},16).to({state:[{t:this.shape_14}]},14).to({state:[{t:this.shape_15}]},13).to({state:[{t:this.shape_16}]},13).to({state:[{t:this.shape_17}]},12).to({state:[{t:this.shape_18}]},14).to({state:[{t:this.shape_19}]},12).wait(1));

	// extras
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(2).p("AeRgQIAAAnEAlBgAQIAAAnEglAgAWIAAAtA+cgQIAAAnA3sgQIAAAnADRgQIAAAnAKBgQIAAAnARCgQIAAAnAXhgQIAAAnAxFgQIAAAnAqEgQIAAAnAjUgQIAAAn");
	this.shape_20.setTransform(471.2,548.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20}]}).wait(140));

	// tabla
	this.text_2 = new cjs.Text("12", "15px Verdana");
	this.text_2.lineHeight = 17;
	this.text_2.setTransform(739.7,559.5,0.903,0.903);

	this.text_3 = new cjs.Text("11", "15px Verdana");
	this.text_3.lineHeight = 17;
	this.text_3.setTransform(699,559.5,0.903,0.903);

	this.text_4 = new cjs.Text("10", "15px Verdana");
	this.text_4.lineHeight = 17;
	this.text_4.setTransform(655.4,559.5,0.903,0.903);

	this.text_5 = new cjs.Text("9", "15px Verdana");
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(614.6,559.5,0.903,0.903);

	this.text_6 = new cjs.Text("8", "15px Verdana");
	this.text_6.lineHeight = 17;
	this.text_6.setTransform(574.6,559.5,0.903,0.903);

	this.text_7 = new cjs.Text("7", "15px Verdana");
	this.text_7.lineHeight = 17;
	this.text_7.setTransform(529.2,559.5,0.903,0.903);

	this.text_8 = new cjs.Text("6", "15px Verdana");
	this.text_8.lineHeight = 17;
	this.text_8.setTransform(485.8,559.5,0.903,0.903);

	this.text_9 = new cjs.Text("5", "15px Verdana");
	this.text_9.lineHeight = 17;
	this.text_9.setTransform(443,559.5,0.903,0.903);

	this.text_10 = new cjs.Text("4", "15px Verdana");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(398.5,559.5,0.903,0.903);

	this.text_11 = new cjs.Text("3", "15px Verdana");
	this.text_11.lineHeight = 17;
	this.text_11.setTransform(355.2,559.5,0.903,0.903);

	this.text_12 = new cjs.Text("2", "15px Verdana");
	this.text_12.lineHeight = 17;
	this.text_12.setTransform(313.5,559.5,0.903,0.903);

	this.text_13 = new cjs.Text("1", "15px Verdana");
	this.text_13.lineHeight = 17;
	this.text_13.lineWidth = 12;
	this.text_13.setTransform(270.1,559.5,0.903,0.903);

	this.text_14 = new cjs.Text("0", "15px Verdana");
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(230.6,559,0.903,0.903);

	this.text_15 = new cjs.Text("60", "15px Verdana");
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(210.4,341,0.903,0.903);

	this.text_16 = new cjs.Text("50", "15px Verdana");
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(210.4,375.3,0.903,0.903);

	this.text_17 = new cjs.Text("40", "15px Verdana");
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(210.4,407,0.903,0.903);

	this.text_18 = new cjs.Text("30", "15px Verdana");
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(210.4,440,0.903,0.903);

	this.text_19 = new cjs.Text("20", "15px Verdana");
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(210.7,473.7,0.903,0.903);

	this.text_20 = new cjs.Text("10", "15px Verdana");
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(210.6,503.9,0.903,0.903);

	this.text_21 = new cjs.Text("0", "15px Verdana");
	this.text_21.lineHeight = 17;
	this.text_21.setTransform(210.7,534.9,0.903,0.903);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#666666").ss(2).p("EAoZARqMhQxAAAEgoYgRpMBQxAAAEgoYAHkMBQxAAAEgoYAMnMBQxAAAEAoZgCgMhQxAAAEAoZACoMhQxAAAEgoYgMtMBQxAAAEAoZgHjMhQxAAA");
	this.shape_21.setTransform(492.8,433.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(2).p("EAoZgRpIAAE8IAAFKIAAFDIAAFIIAAE8IAAFDIAGAAEAoZAMnIAAFDEgoYARqIAAlDIgGAAEgoYACoIAAlIIAAlDIAAlKIAAk8EgoYACoIgGAAEgoYAHkIgGAAEgoYACoIAAE8IAAFD");
	this.shape_22.setTransform(492.8,433.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B9FFFF").s().p("EgoXARqIAAlDMBQvAAAMhQvAAAIAAlDMBQvAAAMhQvAAAIAAk8IAAlIIAAlDIAAlKIAAk8MBQvAAAIAAE8MhQvAAAMBQvAAAIAAFKMhQvAAAMBQvAAAIAAFDMhQvAAAMBQvAAAIAAFIMhQvAAAMBQvAAAIAAE8IAAFDIAAFDgEAoYgMtg");
	this.shape_23.setTransform(492.8,433.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2}]}).wait(140));

	// Capa 8
	this.text_22 = new cjs.Text("60", "20px Verdana");
	this.text_22.textAlign = "center";
	this.text_22.lineHeight = 22;
	this.text_22.lineWidth = 73;
	this.text_22.setTransform(707.5,272.5);

	this.text_23 = new cjs.Text("10", "20px Verdana");
	this.text_23.textAlign = "center";
	this.text_23.lineHeight = 22;
	this.text_23.lineWidth = 74;
	this.text_23.setTransform(708,220.5);

	this.text_24 = new cjs.Text("30", "20px Verdana");
	this.text_24.textAlign = "center";
	this.text_24.lineHeight = 22;
	this.text_24.lineWidth = 75;
	this.text_24.setTransform(628.5,272.5);

	this.text_25 = new cjs.Text("5", "20px Verdana");
	this.text_25.textAlign = "center";
	this.text_25.lineHeight = 22;
	this.text_25.lineWidth = 76;
	this.text_25.setTransform(629,220.5);

	this.text_26 = new cjs.Text("12 ", "20px Verdana");
	this.text_26.textAlign = "center";
	this.text_26.lineHeight = 22;
	this.text_26.lineWidth = 75;
	this.text_26.setTransform(548.5,272.5);

	this.text_27 = new cjs.Text("2", "20px Verdana");
	this.text_27.textAlign = "center";
	this.text_27.lineHeight = 22;
	this.text_27.lineWidth = 76;
	this.text_27.setTransform(548,220.5);

	this.text_28 = new cjs.Text("6 ", "20px Verdana");
	this.text_28.textAlign = "center";
	this.text_28.lineHeight = 22;
	this.text_28.lineWidth = 74;
	this.text_28.setTransform(470,272.5);

	this.text_29 = new cjs.Text("1", "20px Verdana");
	this.text_29.textAlign = "center";
	this.text_29.lineHeight = 22;
	this.text_29.lineWidth = 74;
	this.text_29.setTransform(469,220.5);

	this.text_30 = new cjs.Text("masa (g)", "20px Verdana");
	this.text_30.textAlign = "center";
	this.text_30.lineHeight = 22;
	this.text_30.setTransform(337.7,272.4);

	this.text_31 = new cjs.Text("nº de garbanzos", "20px Verdana");
	this.text_31.textAlign = "center";
	this.text_31.lineHeight = 22;
	this.text_31.setTransform(334.7,220.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(2).p("EAoGAAAIAAH+IsIAAIshAAIsgAAIsOAAI+0AAIAAn+IAAn9Ie0AAIMOAAIMgAAIMhAAIMIAAIAAH9IsIAAIAAH+APdn9IAAH9IMhAAIAAn9EgoFAAAIe0AAIAAn9AC9H+IAAn+IsOAAIAAH+AC9n9IAAH9IMgAAIAAH+");
	this.shape_24.setTransform(492.2,260.6-incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.text_31},{t:this.text_30},{t:this.text_29},{t:this.text_28},{t:this.text_27},{t:this.text_26},{t:this.text_25},{t:this.text_24},{t:this.text_23},{t:this.text_22}]}).wait(140));

	// ff-back
	



	this.text_32 = new cjs.Text("nº de garbanzos", "15px Verdana");
	this.text_32.textAlign = "center";
	this.text_32.lineHeight = 17;
	this.text_32.setTransform(830.3,557.4);

	this.text_33 = new cjs.Text("masa g", "15px Verdana");
	this.text_33.textAlign = "center";
	this.text_33.lineHeight = 17;
	this.text_33.setTransform(163.5,374.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_33},{t:this.text_32}]}).wait(140));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,50.4,857,529.3);
(lib.garbanzo7 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("- La relación de proporcionalidad directa siempre se representa con una  \n   recta creciente.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.lineWidth = 846;
	this.text.setTransform(51.8,440.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AUFiWQrLAhvAACQtOADgtgcQAJA5BgA0QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+gA0CiSQAAADABADQgFgDAEgDQAAgBAAgBIADAAQgCABgBABg");
	this.shape.setTransform(813.6,306.2,0.76,0.76);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhfg1gKg5QAtAcNOgCQPAgDLLghQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYgA0DiUIADAAIgDACIAAgCg");
	this.shape_1.setTransform(813.7,306.2,0.76,0.76);

	this.instance = new lib.Símbolo4("synched",0);
	this.instance.setTransform(730.8,245.8,0.76,0.76);

	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(719.4,243.6,0.76,0.76);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(719.4,257.2,0.76,0.76);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(707.2,257.6,0.76,0.76);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(698.8,268.2,0.76,0.76);

	this.instance_5 = new lib.Símbolo4("synched",0);
	this.instance_5.setTransform(814.5,247.3,0.76,0.76);

	this.instance_6 = new lib.Símbolo4("synched",0);
	this.instance_6.setTransform(766.5,244.3,0.76,0.76);

	this.instance_7 = new lib.Símbolo4("synched",0);
	this.instance_7.setTransform(784,242,0.76,0.76);

	this.instance_8 = new lib.Símbolo4("synched",0);
	this.instance_8.setTransform(801.4,245.5,0.76,0.76);

	this.instance_9 = new lib.Símbolo4("synched",0);
	this.instance_9.setTransform(794,264.7,0.76,0.76);

	this.instance_10 = new lib.Símbolo4("synched",0);
	this.instance_10.setTransform(771,259.2,0.76,0.76);

	this.instance_11 = new lib.Símbolo4("synched",0);
	this.instance_11.setTransform(740.7,260.9,0.76,0.76);

	this.instance_12 = new lib.Símbolo4("synched",0);
	this.instance_12.setTransform(758.1,250,0.76,0.76);

	this.instance_13 = new lib.Símbolo4("synched",0);
	this.instance_13.setTransform(741.4,247,0.76,0.76);

	this.instance_14 = new lib.Símbolo4("synched",0);
	this.instance_14.setTransform(844.8,252.7,0.76,0.76);

	this.instance_15 = new lib.Símbolo4("synched",0);
	this.instance_15.setTransform(829.6,258.1,0.76,0.76);

	this.instance_16 = new lib.Símbolo4("synched",0);
	this.instance_16.setTransform(812.9,260.4,0.76,0.76);

	this.instance_17 = new lib.Símbolo4("synched",0);
	this.instance_17.setTransform(798.4,262.2,0.76,0.76);

	this.instance_18 = new lib.Símbolo4("synched",0);
	this.instance_18.setTransform(780.9,262.9,0.76,0.76);

	this.instance_19 = new lib.Símbolo4("synched",0);
	this.instance_19.setTransform(762.7,264.5,0.76,0.76);

	this.instance_20 = new lib.Símbolo4("synched",0);
	this.instance_20.setTransform(746,262.9,0.76,0.76);

	this.instance_21 = new lib.Símbolo4("synched",0);
	this.instance_21.setTransform(729.2,260.7,0.76,0.76);

	this.instance_22 = new lib.Símbolo4("synched",0);
	this.instance_22.setTransform(855.5,266.3,0.76,0.76);

	this.instance_23 = new lib.Símbolo4("synched",0);
	this.instance_23.setTransform(840.3,270.9,0.76,0.76);

	this.instance_24 = new lib.Símbolo4("synched",0);
	this.instance_24.setTransform(821.9,274.3,0.76,0.76);

	this.instance_25 = new lib.Símbolo4("synched",0);
	this.instance_25.setTransform(804.5,276.6,0.76,0.76);

	this.instance_26 = new lib.Símbolo4("synched",0);
	this.instance_26.setTransform(785.5,278.1,0.76,0.76);

	this.instance_27 = new lib.Símbolo4("synched",0);
	this.instance_27.setTransform(768.8,278.1,0.76,0.76);

	this.instance_28 = new lib.Símbolo4("synched",0);
	this.instance_28.setTransform(750.5,276.6,0.76,0.76);

	this.instance_29 = new lib.Símbolo4("synched",0);
	this.instance_29.setTransform(733,276.6,0.76,0.76);

	this.instance_30 = new lib.Símbolo4("synched",0);
	this.instance_30.setTransform(714.8,272.8,0.76,0.76);

	this.text_1 = new cjs.Text("60 g", "bold 20px Verdana", "#00FF00");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(654.5,218.5+incremento,0.917,0.917);

	this.instance_31 = new lib.balanza();
	this.instance_31.setTransform(655.9,222.5,0.613,0.613,0,0,0,114.8,152);

	this.instance_32 = new lib.taza_bascula();
	this.instance_32.setTransform(655.2,163.4,0.613,0.613,0,0,0,114.9,57.5);

	this.instance_33 = new lib.Símbolo4("synched",0);
	this.instance_33.setTransform(623,139.3,0.917,0.917,0,0,0,50.3,42.4);

	this.instance_34 = new lib.Símbolo4("synched",0);
	this.instance_34.setTransform(713,148.4,0.917,0.917,0,0,0,50,42.5);

	this.instance_35 = new lib.Símbolo4("synched",0);
	this.instance_35.setTransform(642.4,141.2,0.917,0.917,0,0,0,50,42.6);

	this.instance_36 = new lib.Símbolo4("synched",0);
	this.instance_36.setTransform(686.4,141.2,0.917,0.917,0,0,0,50,42.6);

	this.instance_37 = new lib.Símbolo4("synched",0);
	this.instance_37.setTransform(664.4,141.2,0.917,0.917,0,0,0,50,42.6);

	this.instance_38 = new lib.Símbolo4("synched",0);
	this.instance_38.setTransform(612.1,155.7,0.917,0.917,0,0,0,50,42.5);

	this.instance_39 = new lib.Símbolo4("synched",0);
	this.instance_39.setTransform(697.8,153.9,0.917,0.917,0,0,0,50,42.6);

	this.instance_40 = new lib.Símbolo4("synched",0);
	this.instance_40.setTransform(631.8,157.4,0.917,0.917,0,0,0,50,42.4);

	this.instance_41 = new lib.Símbolo4("synched",0);
	this.instance_41.setTransform(675.8,157.4,0.917,0.917,0,0,0,50,42.4);

	this.instance_42 = new lib.Símbolo4("synched",0);
	this.instance_42.setTransform(653.8,157.4,0.917,0.917,0,0,0,50,42.4);

	this.text_2 = new cjs.Text("- La relación de proporcionalidad es 6.\n   · Un garbanzo tiene una masa de 6 g, la masa de un número de  \n     garbanzos es la multiplicación de ese número por 6.", "22px Verdana");
	this.text_2.lineHeight = 24;
	this.text_2.lineWidth = 846;
	this.text_2.setTransform(51,300.6);

	this.text_3 = new cjs.Text("- La relación de proporcionalidad es directa.\n   · Al aumentar el número de garbanzos  \n     aumenta de igual manera la masa total.", "22px Verdana", "#1F1410");
	this.text_3.lineHeight = 26;
	this.text_3.lineWidth = 496;
	this.text_3.setTransform(51.3,149.2);

	this.text_4 = new cjs.Text(txt['tit1'], "40px Georgia");
	this.text_4.lineHeight = 42;
	this.text_4.lineWidth = 554;
	this.text_4.setTransform(106,50);

	
	this.addChild(this.text_4,this.text_3,this.text_2,this.instance_42,this.instance_41,this.instance_40,this.instance_39,this.instance_38,this.instance_37,this.instance_36,this.instance_35,this.instance_34,this.instance_33,this.instance_32,this.instance_31,this.text_1,this.instance_30,this.instance_29,this.instance_28,this.instance_27,this.instance_26,this.instance_25,this.instance_24,this.instance_23,this.instance_22,this.instance_21,this.instance_20,this.instance_19,this.instance_18,this.instance_17,this.instance_16,this.instance_15,this.instance_14,this.instance_13,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(45,50,869,511.4);
(lib.peces1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.instance = new lib.Símbolo8();
	this.instance.setTransform(475,135.3,1,1,0,0,0,406.8,15.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(80));

	// Capa 3
	this.text = new cjs.Text("Total: 20 peces", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(270,510);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},16).wait(64));

	// dias
	this.instance_1 = new lib.numeros();
	this.instance_1.setTransform(839.5,282.3,1,1,0,0,0,364.4,-21.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(80));

	// calendario
	this.instance_2 = new lib.Símbolo3();
	this.instance_2.setTransform(891.3,269.1,0.523,0.523,0,0,0,177.1,84.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).wait(80));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiPKPIAA0dIEgAAIAAUdg");
	var mask_graphics_1 = new cjs.Graphics().p("AirKPIAA0dIFXAAIAAUdg");
	var mask_graphics_2 = new cjs.Graphics().p("AjGKPIAA0dIGNAAIAAUdg");
	var mask_graphics_3 = new cjs.Graphics().p("AjiKPIAA0dIHFAAIAAUdg");
	var mask_graphics_4 = new cjs.Graphics().p("Aj9KPIAA0dIH7AAIAAUdg");
	var mask_graphics_5 = new cjs.Graphics().p("AkZKPIAA0dIIzAAIAAUdg");
	var mask_graphics_6 = new cjs.Graphics().p("Ak0KPIAA0dIJpAAIAAUdg");
	var mask_graphics_7 = new cjs.Graphics().p("AlPKPIAA0dIKfAAIAAUdg");
	var mask_graphics_8 = new cjs.Graphics().p("AlrKPIAA0dILXAAIAAUdg");
	var mask_graphics_9 = new cjs.Graphics().p("AmGKPIAA0dIMNAAIAAUdg");
	var mask_graphics_10 = new cjs.Graphics().p("AmiKPIAA0dINFAAIAAUdg");
	var mask_graphics_11 = new cjs.Graphics().p("Am9KPIAA0dIN7AAIAAUdg");
	var mask_graphics_12 = new cjs.Graphics().p("AnZKPIAA0dIOzAAIAAUdg");
	var mask_graphics_13 = new cjs.Graphics().p("An0KPIAA0dIPpAAIAAUdg");
	var mask_graphics_14 = new cjs.Graphics().p("AoPKPIAA0dIQfAAIAAUdg");
	var mask_graphics_15 = new cjs.Graphics().p("AorKPIAA0dIRXAAIAAUdg");
	var mask_graphics_16 = new cjs.Graphics().p("ApGKPIAA0dISNAAIAAUdg");
	var mask_graphics_17 = new cjs.Graphics().p("ApiKPIAA0dITFAAIAAUdg");
	var mask_graphics_18 = new cjs.Graphics().p("Ap9KPIAA0dIT7AAIAAUdg");
	var mask_graphics_19 = new cjs.Graphics().p("AqYKPIAA0dIUxAAIAAUdg");
	var mask_graphics_20 = new cjs.Graphics().p("Aq0KPIAA0dIVpAAIAAUdg");
	var mask_graphics_21 = new cjs.Graphics().p("ArPKPIAA0dIWfAAIAAUdg");
	var mask_graphics_22 = new cjs.Graphics().p("ArrKPIAA0dIXXAAIAAUdg");
	var mask_graphics_23 = new cjs.Graphics().p("AsGKPIAA0dIYNAAIAAUdg");
	var mask_graphics_24 = new cjs.Graphics().p("AsiKPIAA0dIZFAAIAAUdg");
	var mask_graphics_25 = new cjs.Graphics().p("As9KPIAA0dIZ7AAIAAUdg");
	var mask_graphics_26 = new cjs.Graphics().p("AtYKPIAA0dIaxAAIAAUdg");
	var mask_graphics_27 = new cjs.Graphics().p("At0KPIAA0dIbpAAIAAUdg");
	var mask_graphics_28 = new cjs.Graphics().p("AuPKPIAA0dIcfAAIAAUdg");
	var mask_graphics_29 = new cjs.Graphics().p("AurKPIAA0dIdXAAIAAUdg");
	var mask_graphics_30 = new cjs.Graphics().p("AvGKPIAA0dIeNAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("AviKPIAA0dIfFAAIAAUdg");
	var mask_graphics_32 = new cjs.Graphics().p("Av9KPIAA0dIf7AAIAAUdg");
	var mask_graphics_33 = new cjs.Graphics().p("AwYKPIAA0dMAgxAAAIAAUdg");
	var mask_graphics_34 = new cjs.Graphics().p("Aw0KPIAA0dMAhpAAAIAAUdg");
	var mask_graphics_35 = new cjs.Graphics().p("AxPKPIAA0dMAifAAAIAAUdg");
	var mask_graphics_36 = new cjs.Graphics().p("AxrKPIAA0dMAjXAAAIAAUdg");
	var mask_graphics_37 = new cjs.Graphics().p("AyGKPIAA0dMAkNAAAIAAUdg");
	var mask_graphics_38 = new cjs.Graphics().p("AyhKPIAA0dMAlDAAAIAAUdg");
	var mask_graphics_39 = new cjs.Graphics().p("Ay9KPIAA0dMAl7AAAIAAUdg");
	var mask_graphics_40 = new cjs.Graphics().p("AzYKPIAA0dMAmxAAAIAAUdg");
	var mask_graphics_41 = new cjs.Graphics().p("Az0KPIAA0dMAnpAAAIAAUdg");
	var mask_graphics_42 = new cjs.Graphics().p("A0PKPIAA0dMAofAAAIAAUdg");
	var mask_graphics_43 = new cjs.Graphics().p("A0rKPIAA0dMApXAAAIAAUdg");
	var mask_graphics_44 = new cjs.Graphics().p("A1GKPIAA0dMAqNAAAIAAUdg");
	var mask_graphics_45 = new cjs.Graphics().p("A1hKPIAA0dMArDAAAIAAUdg");
	var mask_graphics_46 = new cjs.Graphics().p("A19KPIAA0dMAr7AAAIAAUdg");
	var mask_graphics_47 = new cjs.Graphics().p("A2YKPIAA0dMAsxAAAIAAUdg");
	var mask_graphics_48 = new cjs.Graphics().p("A20KPIAA0dMAtpAAAIAAUdg");
	var mask_graphics_49 = new cjs.Graphics().p("A3PKPIAA0dMAufAAAIAAUdg");
	var mask_graphics_50 = new cjs.Graphics().p("A3rKPIAA0dMAvXAAAIAAUdg");
	var mask_graphics_51 = new cjs.Graphics().p("A4GKPIAA0dMAwNAAAIAAUdg");
	var mask_graphics_52 = new cjs.Graphics().p("A4hKPIAA0dMAxDAAAIAAUdg");
	var mask_graphics_53 = new cjs.Graphics().p("A49KPIAA0dMAx7AAAIAAUdg");
	var mask_graphics_54 = new cjs.Graphics().p("A5YKPIAA0dMAyxAAAIAAUdg");
	var mask_graphics_55 = new cjs.Graphics().p("A50KPIAA0dMAzpAAAIAAUdg");
	var mask_graphics_56 = new cjs.Graphics().p("A6PKPIAA0dMA0fAAAIAAUdg");
	var mask_graphics_57 = new cjs.Graphics().p("A6qKPIAA0dMA1VAAAIAAUdg");
	var mask_graphics_58 = new cjs.Graphics().p("A7GKPIAA0dMA2NAAAIAAUdg");
	var mask_graphics_59 = new cjs.Graphics().p("A7hKPIAA0dMA3DAAAIAAUdg");
	var mask_graphics_60 = new cjs.Graphics().p("A79KPIAA0dMA37AAAIAAUdg");
	var mask_graphics_61 = new cjs.Graphics().p("A8YKPIAA0dMA4xAAAIAAUdg");
	var mask_graphics_62 = new cjs.Graphics().p("A80KPIAA0dMA5pAAAIAAUdg");
	var mask_graphics_63 = new cjs.Graphics().p("A9PKPIAA0dMA6fAAAIAAUdg");
	var mask_graphics_64 = new cjs.Graphics().p("A9qKPIAA0dMA7VAAAIAAUdg");
	var mask_graphics_65 = new cjs.Graphics().p("A+GKPIAA0dMA8NAAAIAAUdg");
	var mask_graphics_66 = new cjs.Graphics().p("A+hKPIAA0dMA9DAAAIAAUdg");
	var mask_graphics_67 = new cjs.Graphics().p("A+9KPIAA0dMA97AAAIAAUdg");
	var mask_graphics_68 = new cjs.Graphics().p("A/YKPIAA0dMA+xAAAIAAUdg");
	var mask_graphics_69 = new cjs.Graphics().p("A/0KPIAA0dMA/pAAAIAAUdg");
	var mask_graphics_70 = new cjs.Graphics().p("EggPAKPIAA0dMBAfAAAIAAUdg");
	var mask_graphics_71 = new cjs.Graphics().p("EggqAKPIAA0dMBBVAAAIAAUdg");
	var mask_graphics_72 = new cjs.Graphics().p("EghGAKPIAA0dMBCNAAAIAAUdg");
	var mask_graphics_73 = new cjs.Graphics().p("EghhAKPIAA0dMBDDAAAIAAUdg");
	var mask_graphics_74 = new cjs.Graphics().p("Egh9AKPIAA0dMBD7AAAIAAUdg");
	var mask_graphics_75 = new cjs.Graphics().p("EgiYAKPIAA0dMBExAAAIAAUdg");
	var mask_graphics_76 = new cjs.Graphics().p("EgizAKPIAA0dMBFnAAAIAAUdg");
	var mask_graphics_77 = new cjs.Graphics().p("EgjPAKPIAA0dMBGfAAAIAAUdg");
	var mask_graphics_78 = new cjs.Graphics().p("EgjqAKPIAA0dMBHVAAAIAAUdg");
	var mask_graphics_79 = new cjs.Graphics().p("EgkGAKPIAA0dMBINAAAIAAUdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:29.5,y:265.6}).wait(1).to({graphics:mask_graphics_1,x:32.2,y:265.6}).wait(1).to({graphics:mask_graphics_2,x:35,y:265.6}).wait(1).to({graphics:mask_graphics_3,x:37.7,y:265.6}).wait(1).to({graphics:mask_graphics_4,x:40.5,y:265.6}).wait(1).to({graphics:mask_graphics_5,x:43.2,y:265.6}).wait(1).to({graphics:mask_graphics_6,x:45.9,y:265.6}).wait(1).to({graphics:mask_graphics_7,x:48.7,y:265.6}).wait(1).to({graphics:mask_graphics_8,x:51.4,y:265.6}).wait(1).to({graphics:mask_graphics_9,x:54.2,y:265.6}).wait(1).to({graphics:mask_graphics_10,x:56.9,y:265.6}).wait(1).to({graphics:mask_graphics_11,x:59.6,y:265.6}).wait(1).to({graphics:mask_graphics_12,x:62.4,y:265.6}).wait(1).to({graphics:mask_graphics_13,x:65.1,y:265.6}).wait(1).to({graphics:mask_graphics_14,x:67.9,y:265.6}).wait(1).to({graphics:mask_graphics_15,x:70.6,y:265.6}).wait(1).to({graphics:mask_graphics_16,x:73.3,y:265.6}).wait(1).to({graphics:mask_graphics_17,x:76.1,y:265.6}).wait(1).to({graphics:mask_graphics_18,x:78.8,y:265.6}).wait(1).to({graphics:mask_graphics_19,x:81.6,y:265.6}).wait(1).to({graphics:mask_graphics_20,x:84.3,y:265.6}).wait(1).to({graphics:mask_graphics_21,x:87,y:265.6}).wait(1).to({graphics:mask_graphics_22,x:89.8,y:265.6}).wait(1).to({graphics:mask_graphics_23,x:92.5,y:265.6}).wait(1).to({graphics:mask_graphics_24,x:95.3,y:265.6}).wait(1).to({graphics:mask_graphics_25,x:98,y:265.6}).wait(1).to({graphics:mask_graphics_26,x:100.7,y:265.6}).wait(1).to({graphics:mask_graphics_27,x:103.5,y:265.6}).wait(1).to({graphics:mask_graphics_28,x:106.2,y:265.6}).wait(1).to({graphics:mask_graphics_29,x:109,y:265.6}).wait(1).to({graphics:mask_graphics_30,x:111.7,y:265.6}).wait(1).to({graphics:mask_graphics_31,x:114.4,y:265.6}).wait(1).to({graphics:mask_graphics_32,x:117.2,y:265.6}).wait(1).to({graphics:mask_graphics_33,x:119.9,y:265.6}).wait(1).to({graphics:mask_graphics_34,x:122.7,y:265.6}).wait(1).to({graphics:mask_graphics_35,x:125.4,y:265.6}).wait(1).to({graphics:mask_graphics_36,x:128.1,y:265.6}).wait(1).to({graphics:mask_graphics_37,x:130.9,y:265.6}).wait(1).to({graphics:mask_graphics_38,x:133.6,y:265.6}).wait(1).to({graphics:mask_graphics_39,x:136.4,y:265.6}).wait(1).to({graphics:mask_graphics_40,x:139.1,y:265.6}).wait(1).to({graphics:mask_graphics_41,x:141.8,y:265.6}).wait(1).to({graphics:mask_graphics_42,x:144.6,y:265.6}).wait(1).to({graphics:mask_graphics_43,x:147.3,y:265.6}).wait(1).to({graphics:mask_graphics_44,x:150.1,y:265.6}).wait(1).to({graphics:mask_graphics_45,x:152.8,y:265.6}).wait(1).to({graphics:mask_graphics_46,x:155.5,y:265.6}).wait(1).to({graphics:mask_graphics_47,x:158.3,y:265.6}).wait(1).to({graphics:mask_graphics_48,x:161,y:265.6}).wait(1).to({graphics:mask_graphics_49,x:163.8,y:265.6}).wait(1).to({graphics:mask_graphics_50,x:166.5,y:265.6}).wait(1).to({graphics:mask_graphics_51,x:169.2,y:265.6}).wait(1).to({graphics:mask_graphics_52,x:172,y:265.6}).wait(1).to({graphics:mask_graphics_53,x:174.7,y:265.6}).wait(1).to({graphics:mask_graphics_54,x:177.5,y:265.6}).wait(1).to({graphics:mask_graphics_55,x:180.2,y:265.6}).wait(1).to({graphics:mask_graphics_56,x:183,y:265.6}).wait(1).to({graphics:mask_graphics_57,x:185.7,y:265.6}).wait(1).to({graphics:mask_graphics_58,x:188.4,y:265.6}).wait(1).to({graphics:mask_graphics_59,x:191.2,y:265.6}).wait(1).to({graphics:mask_graphics_60,x:193.9,y:265.6}).wait(1).to({graphics:mask_graphics_61,x:196.7,y:265.6}).wait(1).to({graphics:mask_graphics_62,x:199.4,y:265.6}).wait(1).to({graphics:mask_graphics_63,x:202.1,y:265.6}).wait(1).to({graphics:mask_graphics_64,x:204.9,y:265.6}).wait(1).to({graphics:mask_graphics_65,x:207.6,y:265.6}).wait(1).to({graphics:mask_graphics_66,x:210.4,y:265.6}).wait(1).to({graphics:mask_graphics_67,x:213.1,y:265.6}).wait(1).to({graphics:mask_graphics_68,x:215.8,y:265.6}).wait(1).to({graphics:mask_graphics_69,x:218.6,y:265.6}).wait(1).to({graphics:mask_graphics_70,x:221.3,y:265.6}).wait(1).to({graphics:mask_graphics_71,x:224.1,y:265.6}).wait(1).to({graphics:mask_graphics_72,x:226.8,y:265.6}).wait(1).to({graphics:mask_graphics_73,x:229.5,y:265.6}).wait(1).to({graphics:mask_graphics_74,x:232.3,y:265.6}).wait(1).to({graphics:mask_graphics_75,x:235,y:265.6}).wait(1).to({graphics:mask_graphics_76,x:237.8,y:265.6}).wait(1).to({graphics:mask_graphics_77,x:240.5,y:265.6}).wait(1).to({graphics:mask_graphics_78,x:243.2,y:265.6}).wait(1).to({graphics:mask_graphics_79,x:246,y:265.6}).wait(1));

	// txttabla
	this.text_1 = new cjs.Text("15", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 96;
	this.text_1.setTransform(626.2,281.9);

	this.text_2 = new cjs.Text("80", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 95;
	this.text_2.setTransform(626.7,229.9);

	this.text_3 = new cjs.Text("30", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 94;
	this.text_3.setTransform(526.1,281.9);

	this.text_4 = new cjs.Text("40", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 97;
	this.text_4.setTransform(525.6,229.9);

	this.text_5 = new cjs.Text("60", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 93;
	this.text_5.setTransform(425.6,281.9);

	this.text_6 = new cjs.Text("20", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 95;
	this.text_6.setTransform(425.6,229.9);

	this.text_7 = new cjs.Text("duración de la comida (días)", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 324;
	this.text_7.setTransform(212.1,279.8);

	this.text_8 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 324;
	this.text_8.setTransform(212,229.9);

	this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1}]}).wait(80));

	// tabla
	this.instance_3 = new lib.Símbolo11();
	this.instance_3.setTransform(405,269.8,1,1,0,0,0,274.9,51);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EArCAH5MhV5AAAIAAv7");
	this.shape.setTransform(324.5,270.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_3}]}).wait(80));

	// titulo
	this.text_9 = new cjs.Text(txt['tit2'], "40px Georgia");
	this.text_9.lineHeight = 42;
	this.text_9.lineWidth = 554;
	this.text_9.setTransform(110,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_9}]}).wait(80));

	// Capa 11
	this.instance_4 = new lib.Símbolo2();
	this.instance_4.setTransform(808.6,431.6,0.742,0.752,0,0,0,77.5,93);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").p("EgxHgIOIAAjhMBiPgAJIAADeIAAUNMgzkAAEMgurAACg");
	this.shape_1.setTransform(365.4,425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],228.2,13,0,228.2,13,232.7).s().p("AABAAIAAAAIgBABIABgBg");
	this.shape_2.setTransform(593.7,338.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,255,0.086)").s().p("EgxGgJ+MBiNgALIAAUNMgzkAADMgupAADg");
	this.shape_3.setTransform(365.4,436.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],2.5,27.2,0,2.5,27.2,266.8).s().p("EgxGgBqMBiNgAJIAADcMhiNAALg");
	this.shape_4.setTransform(365.4,360.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_4}]}).wait(80));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Aq2JhIAAzBIVtAAIAATBg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Aq2JaIAAyzIVtAAIAASzg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Aq2JTIAAylIVtAAIAASlg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Aq2JMIAAyXIVtAAIAASXg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Aq2JFIAAyJIVtAAIAASJg");
	var mask_1_graphics_5 = new cjs.Graphics().p("Aq2I+IAAx7IVtAAIAAR7g");
	var mask_1_graphics_6 = new cjs.Graphics().p("Aq2I3IAAxtIVtAAIAARtg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Aq2IwIAAxfIVtAAIAARfg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Aq2IpIAAxRIVtAAIAARRg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Aq2IiIAAxDIVtAAIAARDg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Aq2IbIAAw1IVtAAIAAQ1g");
	var mask_1_graphics_11 = new cjs.Graphics().p("Aq2IUIAAwnIVtAAIAAQng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Aq2INIAAwZIVtAAIAAQZg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Aq2IGIAAwLIVtAAIAAQLg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Aq2H/IAAv9IVtAAIAAP9g");
	var mask_1_graphics_15 = new cjs.Graphics().p("Aq2H4IAAvvIVtAAIAAPvg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aq2HxIAAvhIVtAAIAAPhg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Aq2HqIAAvTIVtAAIAAPTg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aq2HjIAAvFIVtAAIAAPFg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Aq2HcIAAu3IVtAAIAAO3g");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aq2HVIAAupIVtAAIAAOpg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aq2HOIAAubIVtAAIAAObg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Aq2HHIAAuNIVtAAIAAONg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Aq2HAIAAt/IVtAAIAAN/g");
	var mask_1_graphics_24 = new cjs.Graphics().p("Aq2G5IAAtxIVtAAIAANxg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Aq2GyIAAtjIVtAAIAANjg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aq2GrIAAtVIVtAAIAANVg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Aq2GkIAAtHIVtAAIAANHg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Aq2GdIAAs5IVtAAIAAM5g");
	var mask_1_graphics_29 = new cjs.Graphics().p("Aq2GWIAAsrIVtAAIAAMrg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Aq2GPIAAsdIVtAAIAAMdg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Aq2GIIAAsPIVtAAIAAMPg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Aq2GBIAAsBIVtAAIAAMBg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Aq2F6IAArzIVtAAIAALzg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Aq2FzIAArlIVtAAIAALlg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq2FsIAArXIVtAAIAALXg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Aq2FkIAArHIVtAAIAALHg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Aq2FdIAAq5IVtAAIAAK5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("Aq2FWIAAqrIVtAAIAAKrg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Aq2FPIAAqdIVtAAIAAKdg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Aq2FIIAAqPIVtAAIAAKPg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Aq2FBIAAqBIVtAAIAAKBg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Aq2E6IAApzIVtAAIAAJzg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Aq2EzIAAplIVtAAIAAJlg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aq2EsIAApXIVtAAIAAJXg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Aq2ElIAApJIVtAAIAAJJg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Aq2EeIAAo7IVtAAIAAI7g");
	var mask_1_graphics_47 = new cjs.Graphics().p("Aq2EXIAAotIVtAAIAAItg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Aq2EQIAAofIVtAAIAAIfg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Aq2EJIAAoRIVtAAIAAIRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Aq2ECIAAoDIVtAAIAAIDg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Aq2D7IAAn1IVtAAIAAH1g");
	var mask_1_graphics_52 = new cjs.Graphics().p("Aq2D0IAAnnIVtAAIAAHng");
	var mask_1_graphics_53 = new cjs.Graphics().p("Aq2DtIAAnZIVtAAIAAHZg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Aq2DmIAAnLIVtAAIAAHLg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Aq2DfIAAm9IVtAAIAAG9g");
	var mask_1_graphics_56 = new cjs.Graphics().p("Aq2DYIAAmvIVtAAIAAGvg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Aq2DRIAAmhIVtAAIAAGhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Aq2DKIAAmTIVtAAIAAGTg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Aq2DDIAAmFIVtAAIAAGFg");
	var mask_1_graphics_60 = new cjs.Graphics().p("Aq2C8IAAl3IVtAAIAAF3g");
	var mask_1_graphics_61 = new cjs.Graphics().p("Aq2C1IAAlpIVtAAIAAFpg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Aq2CuIAAlbIVtAAIAAFbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Aq2CnIAAlNIVtAAIAAFNg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Aq2CgIAAk/IVtAAIAAE/g");
	var mask_1_graphics_65 = new cjs.Graphics().p("Aq2CZIAAkxIVtAAIAAExg");
	var mask_1_graphics_66 = new cjs.Graphics().p("Aq2CSIAAkjIVtAAIAAEjg");
	var mask_1_graphics_67 = new cjs.Graphics().p("Aq2CLIAAkVIVtAAIAAEVg");
	var mask_1_graphics_68 = new cjs.Graphics().p("Aq2CEIAAkHIVtAAIAAEHg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Aq2B9IAAj5IVtAAIAAD5g");
	var mask_1_graphics_70 = new cjs.Graphics().p("Aq2B2IAAjrIVtAAIAADrg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Aq2BuIAAjbIVtAAIAADbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Aq2BnIAAjNIVtAAIAADNg");
	var mask_1_graphics_73 = new cjs.Graphics().p("Aq2BgIAAi/IVtAAIAAC/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("Aq2BZIAAixIVtAAIAACxg");
	var mask_1_graphics_75 = new cjs.Graphics().p("Aq2BSIAAijIVtAAIAACjg");
	var mask_1_graphics_76 = new cjs.Graphics().p("Aq2BLIAAiVIVtAAIAACVg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Aq2BEIAAiHIVtAAIAACHg");
	var mask_1_graphics_78 = new cjs.Graphics().p("Aq2A9IAAh5IVtAAIAAB5g");
	var mask_1_graphics_79 = new cjs.Graphics().p("Aq2A2IAAhrIVtAAIAABrg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:813.7,y:446.1}).wait(1).to({graphics:mask_1_graphics_1,x:813.7,y:447}).wait(1).to({graphics:mask_1_graphics_2,x:813.7,y:447.8}).wait(1).to({graphics:mask_1_graphics_3,x:813.7,y:448.7}).wait(1).to({graphics:mask_1_graphics_4,x:813.7,y:449.6}).wait(1).to({graphics:mask_1_graphics_5,x:813.7,y:450.5}).wait(1).to({graphics:mask_1_graphics_6,x:813.7,y:451.3}).wait(1).to({graphics:mask_1_graphics_7,x:813.7,y:452.2}).wait(1).to({graphics:mask_1_graphics_8,x:813.7,y:453.1}).wait(1).to({graphics:mask_1_graphics_9,x:813.7,y:454}).wait(1).to({graphics:mask_1_graphics_10,x:813.7,y:454.8}).wait(1).to({graphics:mask_1_graphics_11,x:813.7,y:455.7}).wait(1).to({graphics:mask_1_graphics_12,x:813.7,y:456.6}).wait(1).to({graphics:mask_1_graphics_13,x:813.7,y:457.5}).wait(1).to({graphics:mask_1_graphics_14,x:813.7,y:458.3}).wait(1).to({graphics:mask_1_graphics_15,x:813.7,y:459.2}).wait(1).to({graphics:mask_1_graphics_16,x:813.7,y:460.1}).wait(1).to({graphics:mask_1_graphics_17,x:813.7,y:461}).wait(1).to({graphics:mask_1_graphics_18,x:813.7,y:461.8}).wait(1).to({graphics:mask_1_graphics_19,x:813.7,y:462.7}).wait(1).to({graphics:mask_1_graphics_20,x:813.7,y:463.6}).wait(1).to({graphics:mask_1_graphics_21,x:813.7,y:464.4}).wait(1).to({graphics:mask_1_graphics_22,x:813.7,y:465.3}).wait(1).to({graphics:mask_1_graphics_23,x:813.7,y:466.2}).wait(1).to({graphics:mask_1_graphics_24,x:813.7,y:467.1}).wait(1).to({graphics:mask_1_graphics_25,x:813.7,y:467.9}).wait(1).to({graphics:mask_1_graphics_26,x:813.7,y:468.8}).wait(1).to({graphics:mask_1_graphics_27,x:813.7,y:469.7}).wait(1).to({graphics:mask_1_graphics_28,x:813.7,y:470.6}).wait(1).to({graphics:mask_1_graphics_29,x:813.7,y:471.4}).wait(1).to({graphics:mask_1_graphics_30,x:813.7,y:472.3}).wait(1).to({graphics:mask_1_graphics_31,x:813.7,y:473.2}).wait(1).to({graphics:mask_1_graphics_32,x:813.7,y:474.1}).wait(1).to({graphics:mask_1_graphics_33,x:813.7,y:474.9}).wait(1).to({graphics:mask_1_graphics_34,x:813.7,y:475.8}).wait(1).to({graphics:mask_1_graphics_35,x:813.7,y:476.7}).wait(1).to({graphics:mask_1_graphics_36,x:813.7,y:477.6}).wait(1).to({graphics:mask_1_graphics_37,x:813.7,y:478.4}).wait(1).to({graphics:mask_1_graphics_38,x:813.7,y:479.3}).wait(1).to({graphics:mask_1_graphics_39,x:813.7,y:480.2}).wait(1).to({graphics:mask_1_graphics_40,x:813.7,y:481}).wait(1).to({graphics:mask_1_graphics_41,x:813.7,y:481.9}).wait(1).to({graphics:mask_1_graphics_42,x:813.7,y:482.8}).wait(1).to({graphics:mask_1_graphics_43,x:813.7,y:483.7}).wait(1).to({graphics:mask_1_graphics_44,x:813.7,y:484.5}).wait(1).to({graphics:mask_1_graphics_45,x:813.7,y:485.4}).wait(1).to({graphics:mask_1_graphics_46,x:813.7,y:486.3}).wait(1).to({graphics:mask_1_graphics_47,x:813.7,y:487.2}).wait(1).to({graphics:mask_1_graphics_48,x:813.7,y:488}).wait(1).to({graphics:mask_1_graphics_49,x:813.7,y:488.9}).wait(1).to({graphics:mask_1_graphics_50,x:813.7,y:489.8}).wait(1).to({graphics:mask_1_graphics_51,x:813.7,y:490.7}).wait(1).to({graphics:mask_1_graphics_52,x:813.7,y:491.5}).wait(1).to({graphics:mask_1_graphics_53,x:813.7,y:492.4}).wait(1).to({graphics:mask_1_graphics_54,x:813.7,y:493.3}).wait(1).to({graphics:mask_1_graphics_55,x:813.7,y:494.2}).wait(1).to({graphics:mask_1_graphics_56,x:813.7,y:495}).wait(1).to({graphics:mask_1_graphics_57,x:813.7,y:495.9}).wait(1).to({graphics:mask_1_graphics_58,x:813.7,y:496.8}).wait(1).to({graphics:mask_1_graphics_59,x:813.7,y:497.7}).wait(1).to({graphics:mask_1_graphics_60,x:813.7,y:498.5}).wait(1).to({graphics:mask_1_graphics_61,x:813.7,y:499.4}).wait(1).to({graphics:mask_1_graphics_62,x:813.7,y:500.3}).wait(1).to({graphics:mask_1_graphics_63,x:813.7,y:470.1}).wait(1).to({graphics:mask_1_graphics_64,x:813.7,y:502}).wait(1).to({graphics:mask_1_graphics_65,x:813.7,y:502.9}).wait(1).to({graphics:mask_1_graphics_66,x:813.7,y:503.8}).wait(1).to({graphics:mask_1_graphics_67,x:813.7,y:504.6}).wait(1).to({graphics:mask_1_graphics_68,x:813.7,y:505.5}).wait(1).to({graphics:mask_1_graphics_69,x:813.7,y:506.4}).wait(1).to({graphics:mask_1_graphics_70,x:813.7,y:507.3}).wait(1).to({graphics:mask_1_graphics_71,x:813.7,y:508.1}).wait(1).to({graphics:mask_1_graphics_72,x:813.7,y:509}).wait(1).to({graphics:mask_1_graphics_73,x:813.7,y:509.9}).wait(1).to({graphics:mask_1_graphics_74,x:813.7,y:510.8}).wait(1).to({graphics:mask_1_graphics_75,x:813.7,y:511.6}).wait(1).to({graphics:mask_1_graphics_76,x:813.7,y:512.5}).wait(1).to({graphics:mask_1_graphics_77,x:813.7,y:513.4}).wait(1).to({graphics:mask_1_graphics_78,x:813.7,y:514.3}).wait(1).to({graphics:mask_1_graphics_79,x:813.7,y:515.1}).wait(1));

	// comida
	this.shape_5 = new lib.comida();
	
	this.shape_5.setTransform(757,401);

	

	this.shape_5.mask =  mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).wait(80));

	// pez
	this.instance_5 = new lib.pez2();
	this.instance_5.setTransform(324.8,456.3,0.3,0.295,0,0,0,75.8,89.9);

	this.instance_6 = new lib.pez2();
	this.instance_6.setTransform(299.2,479.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_7 = new lib.pez2();
	this.instance_7.setTransform(227.4,434.3,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_8 = new lib.pez1();
	this.instance_8.setTransform(143.8,453.9,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_9 = new lib.pez1();
	this.instance_9.setTransform(229.9,441.9,0.297,0.377,0,0,0,150.2,90);

	this.instance_10 = new lib.pez2();
	this.instance_10.setTransform(192.7,463.4,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_11 = new lib.pez2();
	this.instance_11.setTransform(255.6,469.5,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_12 = new lib.pez2();
	this.instance_12.setTransform(228.2,481,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_13 = new lib.pez2();
	this.instance_13.setTransform(263.5,485.6,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_14 = new lib.pez1();
	this.instance_14.setTransform(289.4,452.6,0.297,0.377,0,0,0,150.2,90);

	this.instance_15 = new lib.pez1();
	this.instance_15.setTransform(244.1,428.8,0.297,0.377,0,0,180,150.2,90);

	this.instance_16 = new lib.pez1();
	this.instance_16.setTransform(307.3,466.3,0.297,0.377,0,0,0,150.1,90);

	this.instance_17 = new lib.pez1();
	this.instance_17.setTransform(262.1,442.4,0.297,0.377,0,0,180,150.1,90);

	this.instance_18 = new lib.pez2();
	this.instance_18.setTransform(139.8,473.4,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_19 = new lib.pez2();
	this.instance_19.setTransform(174.5,484.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_20 = new lib.pez2();
	this.instance_20.setTransform(129.7,489.5,0.115,0.115,0,0,0,75.9,89.9);

	this.instance_21 = new lib.pez1();
	this.instance_21.setTransform(96.9,456.5,0.377,0.377,0,0,180,150.1,90);

	this.instance_22 = new lib.pez1();
	this.instance_22.setTransform(154.4,432.7,0.377,0.377,0,0,0,150.1,90);

	this.instance_23 = new lib.pez1();
	this.instance_23.setTransform(74.1,470.2,0.377,0.377,0,0,180,150.1,90);

	this.instance_24 = new lib.pez1();
	this.instance_24.setTransform(131.6,446.3,0.377,0.377,0,0,0,150.1,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,50.4,829.4,451.3);
(lib.peces2 = function() {
	this.initialize();

	// txt
	this.text = new cjs.Text("¿Cuántos días durará el balde de comida si se añaden 20 peces más?", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(429,118.7);

	// Capa 2
	this.text_1 = new cjs.Text("Total: 20 peces", "22px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.setTransform(270,510);

	// dias
	this.text_2 = new cjs.Text("?", "bold 34px Verdana", "#FFFFFF");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(837.4,259.5);

	// calendario
	this.instance = new lib.Símbolo3();
	this.instance.setTransform(891.3,269.1,0.523,0.523,0,0,0,177.1,84.5);

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgkGAKPIAA0dMBINAAAIAAUdg");
	mask.setTransform(246,265.6);

	// txttabla
	this.text_3 = new cjs.Text("15", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 96;
	this.text_3.setTransform(626.2,281.9);

	this.text_4 = new cjs.Text("80", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 95;
	this.text_4.setTransform(626.7,229.9);

	this.text_5 = new cjs.Text("30", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 94;
	this.text_5.setTransform(526.1,281.9);

	this.text_6 = new cjs.Text("40", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 97;
	this.text_6.setTransform(525.6,229.9);

	this.text_7 = new cjs.Text("60", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 93;
	this.text_7.setTransform(425.6,281.9);

	this.text_8 = new cjs.Text("20", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 95;
	this.text_8.setTransform(425.6,229.9);

	this.text_9 = new cjs.Text("duración de la comida (días)", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 324;
	this.text_9.setTransform(212.1,279.8);

	this.text_10 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 324;
	this.text_10.setTransform(212,229.9);

	this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = mask;

	// tabla
	this.instance_1 = new lib.Símbolo11();
	this.instance_1.setTransform(405,269.8,1,1,0,0,0,274.9,51);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EArCAH5MhV5AAAIAAv7");
	this.shape.setTransform(324.5,270.5);

	// titulo
	this.text_11 = new cjs.Text(txt['tit2'], "40px Georgia");
	this.text_11.lineHeight = 42;
	this.text_11.lineWidth = 554;
	this.text_11.setTransform(110,50.4);

	// Capa 10
	this.instance_2 = new lib.Símbolo2();
	this.instance_2.setTransform(808.6,431.6,0.742,0.752,0,0,0,77.5,93);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").p("EgxHgIOIAAjhMBiPgAJIAADeIAAUNMgzkAAEMgurAACg");
	this.shape_1.setTransform(365.4,425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],228.2,13,0,228.2,13,232.7).s().p("AABAAIAAAAIgBABIABgBg");
	this.shape_2.setTransform(593.7,338.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,255,0.086)").s().p("EgxGgJ+MBiNgALIAAUNMgzkAADMgupAADg");
	this.shape_3.setTransform(365.4,436.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],2.5,27.2,0,2.5,27.2,266.8).s().p("EgxGgBqMBiNgAJIAADcMhiNAALg");
	this.shape_4.setTransform(365.4,360.6);

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Aq2A2IAAhrIVtAAIAABrg");
	mask_1.setTransform(813.7,515.1);

	// comida
	this.shape_5 = new lib.comida();
	
	this.shape_5.setTransform(757,401);

	

	this.shape_5.mask =  mask_1;



	// Capa 15
	this.instance_3 = new lib._20peces();
	this.instance_3.setTransform(538.1,444.2,1,1,0,0,0,112,45.6);
	this.instance_3.alpha = 0;

	// pez
	this.instance_4 = new lib.pez2();
	this.instance_4.setTransform(324.8,456.3,0.3,0.295,0,0,0,75.8,89.9);

	this.instance_5 = new lib.pez2();
	this.instance_5.setTransform(299.2,479.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_6 = new lib.pez2();
	this.instance_6.setTransform(227.4,434.3,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_7 = new lib.pez1();
	this.instance_7.setTransform(143.8,453.9,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_8 = new lib.pez1();
	this.instance_8.setTransform(229.9,441.9,0.297,0.377,0,0,0,150.2,90);

	this.instance_9 = new lib.pez2();
	this.instance_9.setTransform(192.7,463.4,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_10 = new lib.pez2();
	this.instance_10.setTransform(255.6,469.5,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_11 = new lib.pez2();
	this.instance_11.setTransform(228.2,481,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_12 = new lib.pez2();
	this.instance_12.setTransform(263.5,485.6,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_13 = new lib.pez1();
	this.instance_13.setTransform(289.4,452.6,0.297,0.377,0,0,0,150.2,90);

	this.instance_14 = new lib.pez1();
	this.instance_14.setTransform(244.1,428.8,0.297,0.377,0,0,180,150.2,90);

	this.instance_15 = new lib.pez1();
	this.instance_15.setTransform(307.3,466.3,0.297,0.377,0,0,0,150.1,90);

	this.instance_16 = new lib.pez1();
	this.instance_16.setTransform(262.1,442.4,0.297,0.377,0,0,180,150.1,90);

	this.instance_17 = new lib.pez2();
	this.instance_17.setTransform(139.8,473.4,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_18 = new lib.pez2();
	this.instance_18.setTransform(174.5,484.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_19 = new lib.pez2();
	this.instance_19.setTransform(129.7,489.5,0.115,0.115,0,0,0,75.9,89.9);

	this.instance_20 = new lib.pez1();
	this.instance_20.setTransform(96.9,456.5,0.377,0.377,0,0,180,150.1,90);

	this.instance_21 = new lib.pez1();
	this.instance_21.setTransform(154.4,432.7,0.377,0.377,0,0,0,150.1,90);

	this.instance_22 = new lib.pez1();
	this.instance_22.setTransform(74.1,470.2,0.377,0.377,0,0,180,150.1,90);

	this.instance_23 = new lib.pez1();
	this.instance_23.setTransform(131.6,446.3,0.377,0.377,0,0,0,150.1,90);

	this.addChild(this.instance_23,this.instance_22,this.instance_21,this.instance_20,this.instance_19,this.instance_18,this.instance_17,this.instance_16,this.instance_15,this.instance_14,this.instance_13,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.instance_2,this.text_11,this.shape,this.instance_1,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.instance,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(50,50.4,829.4,506.9);
(lib.peces3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.instance = new lib.Símbolo10();
	this.instance.setTransform(475.1,135.3,1,1,0,0,0,163.7,15.4);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(71).to({_off:false},0).to({alpha:1},7).wait(1));

	// Capa 3
	this.text = new cjs.Text("Total: 40 peces", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(270,510);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},23).wait(56));

	// dias
	this.text_1 = new cjs.Text("2", "bold 34px Verdana", "#FFFFFF");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 36;
	this.text_1.setTransform(837.4,259.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1,p:{text:"2",lineWidth:24}}]}).to({state:[{t:this.text_1,p:{text:"3",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"4",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"5",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"6",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"7",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"8",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"9",lineWidth:24}}]},1).to({state:[{t:this.text_1,p:{text:"10",lineWidth:49}}]},1).to({state:[{t:this.text_1,p:{text:"11",lineWidth:49}}]},1).to({state:[{t:this.text_1,p:{text:"12",lineWidth:49}}]},2).to({state:[{t:this.text_1,p:{text:"13",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"14",lineWidth:49}}]},3).to({state:[{t:this.text_1,p:{text:"15",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"16",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"17",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"18",lineWidth:49}}]},5).to({state:[{t:this.text_1,p:{text:"19",lineWidth:49}}]},6).to({state:[{t:this.text_1,p:{text:"20",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"21",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"22",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"23",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"24",lineWidth:49}}]},5).to({state:[{t:this.text_1,p:{text:"25",lineWidth:49}}]},5).to({state:[{t:this.text_1,p:{text:"27",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"29",lineWidth:49}}]},4).to({state:[{t:this.text_1,p:{text:"30",lineWidth:49}}]},3).wait(1));

	// calendario
	this.instance_1 = new lib.Símbolo3();
	this.instance_1.setTransform(891.3,269.1,0.523,0.523,0,0,0,177.1,84.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).wait(79));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgkGAKPIAA0dMBINAAAIAAUdg");
	var mask_graphics_1 = new cjs.Graphics().p("EgkMAKPIAA0dMBIZAAAIAAUdg");
	var mask_graphics_2 = new cjs.Graphics().p("EgkTAKPIAA0dMBInAAAIAAUdg");
	var mask_graphics_3 = new cjs.Graphics().p("EgkZAKPIAA0dMBIzAAAIAAUdg");
	var mask_graphics_4 = new cjs.Graphics().p("EgkgAKPIAA0dMBJBAAAIAAUdg");
	var mask_graphics_5 = new cjs.Graphics().p("EgkmAKPIAA0dMBJNAAAIAAUdg");
	var mask_graphics_6 = new cjs.Graphics().p("EgktAKPIAA0dMBJbAAAIAAUdg");
	var mask_graphics_7 = new cjs.Graphics().p("EgkzAKPIAA0dMBJnAAAIAAUdg");
	var mask_graphics_8 = new cjs.Graphics().p("Egk6AKPIAA0dMBJ1AAAIAAUdg");
	var mask_graphics_9 = new cjs.Graphics().p("EglAAKPIAA0dMBKBAAAIAAUdg");
	var mask_graphics_10 = new cjs.Graphics().p("EglHAKPIAA0dMBKPAAAIAAUdg");
	var mask_graphics_11 = new cjs.Graphics().p("EglNAKPIAA0dMBKbAAAIAAUdg");
	var mask_graphics_12 = new cjs.Graphics().p("EglTAKPIAA0dMBKnAAAIAAUdg");
	var mask_graphics_13 = new cjs.Graphics().p("EglaAKPIAA0dMBK1AAAIAAUdg");
	var mask_graphics_14 = new cjs.Graphics().p("EglgAKPIAA0dMBLBAAAIAAUdg");
	var mask_graphics_15 = new cjs.Graphics().p("EglnAKPIAA0dMBLPAAAIAAUdg");
	var mask_graphics_16 = new cjs.Graphics().p("EgltAKPIAA0dMBLbAAAIAAUdg");
	var mask_graphics_17 = new cjs.Graphics().p("Egl0AKPIAA0dMBLpAAAIAAUdg");
	var mask_graphics_18 = new cjs.Graphics().p("Egl6AKPIAA0dMBL1AAAIAAUdg");
	var mask_graphics_19 = new cjs.Graphics().p("EgmBAKPIAA0dMBMDAAAIAAUdg");
	var mask_graphics_20 = new cjs.Graphics().p("EgmHAKPIAA0dMBMPAAAIAAUdg");
	var mask_graphics_21 = new cjs.Graphics().p("EgmOAKPIAA0dMBMdAAAIAAUdg");
	var mask_graphics_22 = new cjs.Graphics().p("EgmUAKPIAA0dMBMpAAAIAAUdg");
	var mask_graphics_23 = new cjs.Graphics().p("EgmbAKPIAA0dMBM3AAAIAAUdg");
	var mask_graphics_24 = new cjs.Graphics().p("EgmhAKPIAA0dMBNDAAAIAAUdg");
	var mask_graphics_25 = new cjs.Graphics().p("EgmoAKPIAA0dMBNRAAAIAAUdg");
	var mask_graphics_26 = new cjs.Graphics().p("EgmuAKPIAA0dMBNdAAAIAAUdg");
	var mask_graphics_27 = new cjs.Graphics().p("Egm1AKPIAA0dMBNrAAAIAAUdg");
	var mask_graphics_28 = new cjs.Graphics().p("Egm7AKPIAA0dMBN3AAAIAAUdg");
	var mask_graphics_29 = new cjs.Graphics().p("EgnCAKPIAA0dMBOFAAAIAAUdg");
	var mask_graphics_30 = new cjs.Graphics().p("EgnIAKPIAA0dMBORAAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("EgnPAKPIAA0dMBOfAAAIAAUdg");
	var mask_graphics_32 = new cjs.Graphics().p("EgnVAKPIAA0dMBOrAAAIAAUdg");
	var mask_graphics_33 = new cjs.Graphics().p("EgncAKPIAA0dMBO5AAAIAAUdg");
	var mask_graphics_34 = new cjs.Graphics().p("EgniAKPIAA0dMBPFAAAIAAUdg");
	var mask_graphics_35 = new cjs.Graphics().p("EgnoAKPIAA0dMBPRAAAIAAUdg");
	var mask_graphics_36 = new cjs.Graphics().p("EgnvAKPIAA0dMBPfAAAIAAUdg");
	var mask_graphics_37 = new cjs.Graphics().p("Egn1AKPIAA0dMBPrAAAIAAUdg");
	var mask_graphics_38 = new cjs.Graphics().p("Egn8AKPIAA0dMBP5AAAIAAUdg");
	var mask_graphics_39 = new cjs.Graphics().p("EgoCAKPIAA0dMBQFAAAIAAUdg");
	var mask_graphics_40 = new cjs.Graphics().p("EgoJAKPIAA0dMBQTAAAIAAUdg");
	var mask_graphics_41 = new cjs.Graphics().p("EgoPAKPIAA0dMBQfAAAIAAUdg");
	var mask_graphics_42 = new cjs.Graphics().p("EgoWAKPIAA0dMBQtAAAIAAUdg");
	var mask_graphics_43 = new cjs.Graphics().p("EgocAKPIAA0dMBQ5AAAIAAUdg");
	var mask_graphics_44 = new cjs.Graphics().p("EgojAKPIAA0dMBRHAAAIAAUdg");
	var mask_graphics_45 = new cjs.Graphics().p("EgopAKPIAA0dMBRTAAAIAAUdg");
	var mask_graphics_46 = new cjs.Graphics().p("EgowAKPIAA0dMBRhAAAIAAUdg");
	var mask_graphics_47 = new cjs.Graphics().p("Ego2AKPIAA0dMBRtAAAIAAUdg");
	var mask_graphics_48 = new cjs.Graphics().p("Ego9AKPIAA0dMBR7AAAIAAUdg");
	var mask_graphics_49 = new cjs.Graphics().p("EgpDAKPIAA0dMBSHAAAIAAUdg");
	var mask_graphics_50 = new cjs.Graphics().p("EgpKAKPIAA0dMBSVAAAIAAUdg");
	var mask_graphics_51 = new cjs.Graphics().p("EgpQAKPIAA0dMBShAAAIAAUdg");
	var mask_graphics_52 = new cjs.Graphics().p("EgpXAKPIAA0dMBSvAAAIAAUdg");
	var mask_graphics_53 = new cjs.Graphics().p("EgpdAKPIAA0dMBS7AAAIAAUdg");
	var mask_graphics_54 = new cjs.Graphics().p("EgpkAKPIAA0dMBTJAAAIAAUdg");
	var mask_graphics_55 = new cjs.Graphics().p("EgpqAKPIAA0dMBTVAAAIAAUdg");
	var mask_graphics_56 = new cjs.Graphics().p("EgpwAKPIAA0dMBThAAAIAAUdg");
	var mask_graphics_57 = new cjs.Graphics().p("Egp3AKPIAA0dMBTvAAAIAAUdg");
	var mask_graphics_58 = new cjs.Graphics().p("Egp9AKPIAA0dMBT7AAAIAAUdg");
	var mask_graphics_59 = new cjs.Graphics().p("EgqEAKPIAA0dMBUJAAAIAAUdg");
	var mask_graphics_60 = new cjs.Graphics().p("EgqKAKPIAA0dMBUVAAAIAAUdg");
	var mask_graphics_61 = new cjs.Graphics().p("EgqRAKPIAA0dMBUjAAAIAAUdg");
	var mask_graphics_62 = new cjs.Graphics().p("EgqXAKPIAA0dMBUvAAAIAAUdg");
	var mask_graphics_63 = new cjs.Graphics().p("EgqeAKPIAA0dMBU9AAAIAAUdg");
	var mask_graphics_64 = new cjs.Graphics().p("EgqkAKPIAA0dMBVJAAAIAAUdg");
	var mask_graphics_65 = new cjs.Graphics().p("EgqrAKPIAA0dMBVXAAAIAAUdg");
	var mask_graphics_66 = new cjs.Graphics().p("EgqxAKPIAA0dMBVjAAAIAAUdg");
	var mask_graphics_67 = new cjs.Graphics().p("Egq4AKPIAA0dMBVxAAAIAAUdg");
	var mask_graphics_68 = new cjs.Graphics().p("Egq+AKPIAA0dMBV9AAAIAAUdg");
	var mask_graphics_69 = new cjs.Graphics().p("EgrFAKPIAA0dMBWLAAAIAAUdg");
	var mask_graphics_70 = new cjs.Graphics().p("EgrLAKPIAA0dMBWXAAAIAAUdg");
	var mask_graphics_71 = new cjs.Graphics().p("EgrSAKPIAA0dMBWlAAAIAAUdg");
	var mask_graphics_72 = new cjs.Graphics().p("EgrYAKPIAA0dMBWxAAAIAAUdg");
	var mask_graphics_73 = new cjs.Graphics().p("EgrfAKPIAA0dMBW/AAAIAAUdg");
	var mask_graphics_74 = new cjs.Graphics().p("EgrlAKPIAA0dMBXLAAAIAAUdg");
	var mask_graphics_75 = new cjs.Graphics().p("EgrsAKPIAA0dMBXZAAAIAAUdg");
	var mask_graphics_76 = new cjs.Graphics().p("EgryAKPIAA0dMBXlAAAIAAUdg");
	var mask_graphics_77 = new cjs.Graphics().p("Egr5AKPIAA0dMBXzAAAIAAUdg");
	var mask_graphics_78 = new cjs.Graphics().p("Egr/AKPIAA0dMBX/AAAIAAUdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:246,y:265.6}).wait(1).to({graphics:mask_graphics_1,x:246.6,y:265.6}).wait(1).to({graphics:mask_graphics_2,x:247.3,y:265.6}).wait(1).to({graphics:mask_graphics_3,x:247.9,y:265.6}).wait(1).to({graphics:mask_graphics_4,x:248.6,y:265.6}).wait(1).to({graphics:mask_graphics_5,x:249.2,y:265.6}).wait(1).to({graphics:mask_graphics_6,x:249.9,y:265.6}).wait(1).to({graphics:mask_graphics_7,x:250.5,y:265.6}).wait(1).to({graphics:mask_graphics_8,x:251.2,y:265.6}).wait(1).to({graphics:mask_graphics_9,x:251.8,y:265.6}).wait(1).to({graphics:mask_graphics_10,x:252.5,y:265.6}).wait(1).to({graphics:mask_graphics_11,x:253.1,y:265.6}).wait(1).to({graphics:mask_graphics_12,x:253.7,y:265.6}).wait(1).to({graphics:mask_graphics_13,x:254.4,y:265.6}).wait(1).to({graphics:mask_graphics_14,x:255,y:265.6}).wait(1).to({graphics:mask_graphics_15,x:255.7,y:265.6}).wait(1).to({graphics:mask_graphics_16,x:256.3,y:265.6}).wait(1).to({graphics:mask_graphics_17,x:257,y:265.6}).wait(1).to({graphics:mask_graphics_18,x:257.6,y:265.6}).wait(1).to({graphics:mask_graphics_19,x:258.3,y:265.6}).wait(1).to({graphics:mask_graphics_20,x:258.9,y:265.6}).wait(1).to({graphics:mask_graphics_21,x:259.6,y:265.6}).wait(1).to({graphics:mask_graphics_22,x:260.2,y:265.6}).wait(1).to({graphics:mask_graphics_23,x:260.9,y:265.6}).wait(1).to({graphics:mask_graphics_24,x:261.5,y:265.6}).wait(1).to({graphics:mask_graphics_25,x:262.2,y:265.6}).wait(1).to({graphics:mask_graphics_26,x:262.8,y:265.6}).wait(1).to({graphics:mask_graphics_27,x:263.5,y:265.6}).wait(1).to({graphics:mask_graphics_28,x:264.1,y:265.6}).wait(1).to({graphics:mask_graphics_29,x:264.8,y:265.6}).wait(1).to({graphics:mask_graphics_30,x:265.4,y:265.6}).wait(1).to({graphics:mask_graphics_31,x:266.1,y:265.6}).wait(1).to({graphics:mask_graphics_32,x:266.7,y:265.6}).wait(1).to({graphics:mask_graphics_33,x:267.4,y:265.6}).wait(1).to({graphics:mask_graphics_34,x:268,y:265.6}).wait(1).to({graphics:mask_graphics_35,x:268.6,y:265.6}).wait(1).to({graphics:mask_graphics_36,x:269.3,y:265.6}).wait(1).to({graphics:mask_graphics_37,x:269.9,y:265.6}).wait(1).to({graphics:mask_graphics_38,x:270.6,y:265.6}).wait(1).to({graphics:mask_graphics_39,x:271.2,y:265.6}).wait(1).to({graphics:mask_graphics_40,x:271.9,y:265.6}).wait(1).to({graphics:mask_graphics_41,x:272.5,y:265.6}).wait(1).to({graphics:mask_graphics_42,x:273.2,y:265.6}).wait(1).to({graphics:mask_graphics_43,x:273.8,y:265.6}).wait(1).to({graphics:mask_graphics_44,x:274.5,y:265.6}).wait(1).to({graphics:mask_graphics_45,x:275.1,y:265.6}).wait(1).to({graphics:mask_graphics_46,x:275.8,y:265.6}).wait(1).to({graphics:mask_graphics_47,x:276.4,y:265.6}).wait(1).to({graphics:mask_graphics_48,x:277.1,y:265.6}).wait(1).to({graphics:mask_graphics_49,x:277.7,y:265.6}).wait(1).to({graphics:mask_graphics_50,x:278.4,y:265.6}).wait(1).to({graphics:mask_graphics_51,x:279,y:265.6}).wait(1).to({graphics:mask_graphics_52,x:279.7,y:265.6}).wait(1).to({graphics:mask_graphics_53,x:280.3,y:265.6}).wait(1).to({graphics:mask_graphics_54,x:281,y:265.6}).wait(1).to({graphics:mask_graphics_55,x:281.6,y:265.6}).wait(1).to({graphics:mask_graphics_56,x:282.2,y:265.6}).wait(1).to({graphics:mask_graphics_57,x:282.9,y:265.6}).wait(1).to({graphics:mask_graphics_58,x:283.5,y:265.6}).wait(1).to({graphics:mask_graphics_59,x:284.2,y:265.6}).wait(1).to({graphics:mask_graphics_60,x:284.8,y:265.6}).wait(1).to({graphics:mask_graphics_61,x:285.5,y:265.6}).wait(1).to({graphics:mask_graphics_62,x:286.1,y:265.6}).wait(1).to({graphics:mask_graphics_63,x:286.8,y:265.6}).wait(1).to({graphics:mask_graphics_64,x:287.4,y:265.6}).wait(1).to({graphics:mask_graphics_65,x:288.1,y:265.6}).wait(1).to({graphics:mask_graphics_66,x:288.7,y:265.6}).wait(1).to({graphics:mask_graphics_67,x:289.4,y:265.6}).wait(1).to({graphics:mask_graphics_68,x:290,y:265.6}).wait(1).to({graphics:mask_graphics_69,x:290.7,y:265.6}).wait(1).to({graphics:mask_graphics_70,x:291.3,y:265.6}).wait(1).to({graphics:mask_graphics_71,x:292,y:265.6}).wait(1).to({graphics:mask_graphics_72,x:292.6,y:265.6}).wait(1).to({graphics:mask_graphics_73,x:293.3,y:265.6}).wait(1).to({graphics:mask_graphics_74,x:293.9,y:265.6}).wait(1).to({graphics:mask_graphics_75,x:294.6,y:265.6}).wait(1).to({graphics:mask_graphics_76,x:295.2,y:265.6}).wait(1).to({graphics:mask_graphics_77,x:295.9,y:265.6}).wait(1).to({graphics:mask_graphics_78,x:296.5,y:265.6}).wait(1));

	// txttabla
	this.text_2 = new cjs.Text("15", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 96;
	this.text_2.setTransform(626.2,281.9);

	this.text_3 = new cjs.Text("80", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 95;
	this.text_3.setTransform(626.7,229.9);

	this.text_4 = new cjs.Text("30", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 94;
	this.text_4.setTransform(526.1,281.9);

	this.text_5 = new cjs.Text("40", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 97;
	this.text_5.setTransform(525.6,229.9);

	this.text_6 = new cjs.Text("60", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 93;
	this.text_6.setTransform(425.6,281.9);

	this.text_7 = new cjs.Text("20", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 95;
	this.text_7.setTransform(425.6,229.9);

	this.text_8 = new cjs.Text("duración de la comida (días)", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 324;
	this.text_8.setTransform(212.1,279.8);

	this.text_9 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 324;
	this.text_9.setTransform(212,229.9);

	this.text_2.mask = this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2}]}).wait(79));

	// tabla
	this.instance_2 = new lib.Símbolo11();
	this.instance_2.setTransform(405,269.8,1,1,0,0,0,274.9,51);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EArCAH5MhV5AAAIAAv7");
	this.shape.setTransform(324.5,270.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_2}]}).wait(79));

	// titulo
	this.text_10 = new cjs.Text(txt['tit2'], "40px Georgia");
	this.text_10.lineHeight = 42;
	this.text_10.lineWidth = 554;
	this.text_10.setTransform(110,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_10}]}).wait(79));

	// Capa 11
	this.instance_3 = new lib.Símbolo2();
	this.instance_3.setTransform(808.6,431.6,0.742,0.752,0,0,0,77.5,93);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").p("EgxHgIOIAAjhMBiPgAJIAADeIAAUNMgzkAAEMgurAACg");
	this.shape_1.setTransform(365.4,425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],228.2,13,0,228.2,13,232.7).s().p("AABAAIAAAAIgBABIABgBg");
	this.shape_2.setTransform(593.7,338.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,255,0.086)").s().p("EgxGgJ+MBiNgALIAAUNMgzkAADMgupAADg");
	this.shape_3.setTransform(365.4,436.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],2.5,27.2,0,2.5,27.2,266.8).s().p("EgxGgBqMBiNgAJIAADcMhiNAALg");
	this.shape_4.setTransform(365.4,360.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_3}]}).wait(79));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Aq2JhIAAzBIVtAAIAATBg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Aq2JaIAAyzIVtAAIAASzg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Aq2JTIAAylIVtAAIAASlg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Aq2JMIAAyXIVtAAIAASXg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Aq2JFIAAyJIVtAAIAASJg");
	var mask_1_graphics_5 = new cjs.Graphics().p("Aq2I+IAAx7IVtAAIAAR7g");
	var mask_1_graphics_6 = new cjs.Graphics().p("Aq2I3IAAxtIVtAAIAARtg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Aq2IwIAAxfIVtAAIAARfg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Aq2IpIAAxRIVtAAIAARRg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Aq2IhIAAxBIVtAAIAARBg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Aq2IaIAAwzIVtAAIAAQzg");
	var mask_1_graphics_11 = new cjs.Graphics().p("Aq2ITIAAwlIVtAAIAAQlg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Aq2IMIAAwXIVtAAIAAQXg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Aq2IFIAAwJIVtAAIAAQJg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Aq2H+IAAv7IVtAAIAAP7g");
	var mask_1_graphics_15 = new cjs.Graphics().p("Aq2H3IAAvtIVtAAIAAPtg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aq2HwIAAvfIVtAAIAAPfg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Aq2HoIAAvPIVtAAIAAPPg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aq2HhIAAvBIVtAAIAAPBg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Aq2HaIAAuzIVtAAIAAOzg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aq2HTIAAulIVtAAIAAOlg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aq2HMIAAuXIVtAAIAAOXg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Aq2HFIAAuJIVtAAIAAOJg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Aq2G+IAAt7IVtAAIAAN7g");
	var mask_1_graphics_24 = new cjs.Graphics().p("Aq2G3IAAttIVtAAIAANtg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Aq2GwIAAtfIVtAAIAANfg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aq2GoIAAtPIVtAAIAANPg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Aq2GhIAAtBIVtAAIAANBg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Aq2GaIAAszIVtAAIAAMzg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Aq2GTIAAslIVtAAIAAMlg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Aq2GMIAAsXIVtAAIAAMXg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Aq2GFIAAsJIVtAAIAAMJg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Aq2F+IAAr7IVtAAIAAL7g");
	var mask_1_graphics_33 = new cjs.Graphics().p("Aq2F3IAArtIVtAAIAALtg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Aq2FvIAArdIVtAAIAALdg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq2FoIAArPIVtAAIAALPg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Aq2FhIAArBIVtAAIAALBg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Aq2FaIAAqzIVtAAIAAKzg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Aq2FTIAAqlIVtAAIAAKlg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Aq2FMIAAqXIVtAAIAAKXg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Aq2FFIAAqJIVtAAIAAKJg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Aq2E+IAAp7IVtAAIAAJ7g");
	var mask_1_graphics_42 = new cjs.Graphics().p("Aq2E3IAAptIVtAAIAAJtg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Aq2EvIAApdIVtAAIAAJdg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aq2EoIAApPIVtAAIAAJPg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Aq2EhIAApBIVtAAIAAJBg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Aq2EaIAAozIVtAAIAAIzg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Aq2ETIAAolIVtAAIAAIlg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Aq2EMIAAoXIVtAAIAAIXg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Aq2EFIAAoJIVtAAIAAIJg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Aq2D+IAAn7IVtAAIAAH7g");
	var mask_1_graphics_51 = new cjs.Graphics().p("Aq2D2IAAnrIVtAAIAAHrg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Aq2DvIAAndIVtAAIAAHdg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Aq2DoIAAnPIVtAAIAAHPg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Aq2DhIAAnBIVtAAIAAHBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Aq2DaIAAmzIVtAAIAAGzg");
	var mask_1_graphics_56 = new cjs.Graphics().p("Aq2DTIAAmlIVtAAIAAGlg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Aq2DMIAAmXIVtAAIAAGXg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Aq2DFIAAmJIVtAAIAAGJg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Aq2C+IAAl7IVtAAIAAF7g");
	var mask_1_graphics_60 = new cjs.Graphics().p("Aq2C2IAAlrIVtAAIAAFrg");
	var mask_1_graphics_61 = new cjs.Graphics().p("Aq2CvIAAldIVtAAIAAFdg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Aq2CoIAAlPIVtAAIAAFPg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Aq2ChIAAlBIVtAAIAAFBg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Aq2CaIAAkzIVtAAIAAEzg");
	var mask_1_graphics_65 = new cjs.Graphics().p("Aq2CTIAAklIVtAAIAAElg");
	var mask_1_graphics_66 = new cjs.Graphics().p("Aq2CMIAAkXIVtAAIAAEXg");
	var mask_1_graphics_67 = new cjs.Graphics().p("Aq2CFIAAkJIVtAAIAAEJg");
	var mask_1_graphics_68 = new cjs.Graphics().p("Aq2B9IAAj5IVtAAIAAD5g");
	var mask_1_graphics_69 = new cjs.Graphics().p("Aq2B2IAAjrIVtAAIAADrg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Aq2BvIAAjdIVtAAIAADdg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Aq2BoIAAjPIVtAAIAADPg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Aq2BhIAAjBIVtAAIAADBg");
	var mask_1_graphics_73 = new cjs.Graphics().p("Aq2BaIAAizIVtAAIAACzg");
	var mask_1_graphics_74 = new cjs.Graphics().p("Aq2BTIAAilIVtAAIAAClg");
	var mask_1_graphics_75 = new cjs.Graphics().p("Aq2BMIAAiXIVtAAIAACXg");
	var mask_1_graphics_76 = new cjs.Graphics().p("Aq2BEIAAiHIVtAAIAACHg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Aq2A9IAAh5IVtAAIAAB5g");
	var mask_1_graphics_78 = new cjs.Graphics().p("Aq2A2IAAhrIVtAAIAABrg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:813.7,y:446.1}).wait(1).to({graphics:mask_1_graphics_1,x:813.7,y:447}).wait(1).to({graphics:mask_1_graphics_2,x:813.7,y:447.9}).wait(1).to({graphics:mask_1_graphics_3,x:813.7,y:448.8}).wait(1).to({graphics:mask_1_graphics_4,x:813.7,y:449.6}).wait(1).to({graphics:mask_1_graphics_5,x:813.7,y:450.5}).wait(1).to({graphics:mask_1_graphics_6,x:813.7,y:451.4}).wait(1).to({graphics:mask_1_graphics_7,x:813.7,y:452.3}).wait(1).to({graphics:mask_1_graphics_8,x:813.7,y:453.2}).wait(1).to({graphics:mask_1_graphics_9,x:813.7,y:454.1}).wait(1).to({graphics:mask_1_graphics_10,x:813.7,y:454.9}).wait(1).to({graphics:mask_1_graphics_11,x:813.7,y:455.8}).wait(1).to({graphics:mask_1_graphics_12,x:813.7,y:456.7}).wait(1).to({graphics:mask_1_graphics_13,x:813.7,y:457.6}).wait(1).to({graphics:mask_1_graphics_14,x:813.7,y:458.5}).wait(1).to({graphics:mask_1_graphics_15,x:813.7,y:459.4}).wait(1).to({graphics:mask_1_graphics_16,x:813.7,y:460.3}).wait(1).to({graphics:mask_1_graphics_17,x:813.7,y:461.1}).wait(1).to({graphics:mask_1_graphics_18,x:813.7,y:462}).wait(1).to({graphics:mask_1_graphics_19,x:813.7,y:462.9}).wait(1).to({graphics:mask_1_graphics_20,x:813.7,y:463.8}).wait(1).to({graphics:mask_1_graphics_21,x:813.7,y:464.7}).wait(1).to({graphics:mask_1_graphics_22,x:813.7,y:465.6}).wait(1).to({graphics:mask_1_graphics_23,x:813.7,y:466.5}).wait(1).to({graphics:mask_1_graphics_24,x:813.7,y:467.3}).wait(1).to({graphics:mask_1_graphics_25,x:813.7,y:468.2}).wait(1).to({graphics:mask_1_graphics_26,x:813.7,y:469.1}).wait(1).to({graphics:mask_1_graphics_27,x:813.7,y:470}).wait(1).to({graphics:mask_1_graphics_28,x:813.7,y:470.9}).wait(1).to({graphics:mask_1_graphics_29,x:813.7,y:471.8}).wait(1).to({graphics:mask_1_graphics_30,x:813.7,y:472.6}).wait(1).to({graphics:mask_1_graphics_31,x:813.7,y:473.5}).wait(1).to({graphics:mask_1_graphics_32,x:813.7,y:474.4}).wait(1).to({graphics:mask_1_graphics_33,x:813.7,y:475.3}).wait(1).to({graphics:mask_1_graphics_34,x:813.7,y:476.2}).wait(1).to({graphics:mask_1_graphics_35,x:813.7,y:477.1}).wait(1).to({graphics:mask_1_graphics_36,x:813.7,y:478}).wait(1).to({graphics:mask_1_graphics_37,x:813.7,y:478.8}).wait(1).to({graphics:mask_1_graphics_38,x:813.7,y:479.7}).wait(1).to({graphics:mask_1_graphics_39,x:813.7,y:480.6}).wait(1).to({graphics:mask_1_graphics_40,x:813.7,y:481.5}).wait(1).to({graphics:mask_1_graphics_41,x:813.7,y:482.4}).wait(1).to({graphics:mask_1_graphics_42,x:813.7,y:483.3}).wait(1).to({graphics:mask_1_graphics_43,x:813.7,y:484.2}).wait(1).to({graphics:mask_1_graphics_44,x:813.7,y:485}).wait(1).to({graphics:mask_1_graphics_45,x:813.7,y:485.9}).wait(1).to({graphics:mask_1_graphics_46,x:813.7,y:486.8}).wait(1).to({graphics:mask_1_graphics_47,x:813.7,y:487.7}).wait(1).to({graphics:mask_1_graphics_48,x:813.7,y:488.6}).wait(1).to({graphics:mask_1_graphics_49,x:813.7,y:489.5}).wait(1).to({graphics:mask_1_graphics_50,x:813.7,y:490.3}).wait(1).to({graphics:mask_1_graphics_51,x:813.7,y:491.2}).wait(1).to({graphics:mask_1_graphics_52,x:813.7,y:492.1}).wait(1).to({graphics:mask_1_graphics_53,x:813.7,y:493}).wait(1).to({graphics:mask_1_graphics_54,x:813.7,y:493.9}).wait(1).to({graphics:mask_1_graphics_55,x:813.7,y:494.8}).wait(1).to({graphics:mask_1_graphics_56,x:813.7,y:495.7}).wait(1).to({graphics:mask_1_graphics_57,x:813.7,y:496.5}).wait(1).to({graphics:mask_1_graphics_58,x:813.7,y:497.4}).wait(1).to({graphics:mask_1_graphics_59,x:813.7,y:498.3}).wait(1).to({graphics:mask_1_graphics_60,x:813.7,y:499.2}).wait(1).to({graphics:mask_1_graphics_61,x:813.7,y:500.1}).wait(1).to({graphics:mask_1_graphics_62,x:813.7,y:470}).wait(1).to({graphics:mask_1_graphics_63,x:813.7,y:470.9}).wait(1).to({graphics:mask_1_graphics_64,x:813.7,y:502.7}).wait(1).to({graphics:mask_1_graphics_65,x:813.7,y:503.6}).wait(1).to({graphics:mask_1_graphics_66,x:813.7,y:504.5}).wait(1).to({graphics:mask_1_graphics_67,x:813.7,y:505.4}).wait(1).to({graphics:mask_1_graphics_68,x:813.7,y:506.3}).wait(1).to({graphics:mask_1_graphics_69,x:813.7,y:507.2}).wait(1).to({graphics:mask_1_graphics_70,x:813.7,y:508}).wait(1).to({graphics:mask_1_graphics_71,x:813.7,y:508.9}).wait(1).to({graphics:mask_1_graphics_72,x:813.7,y:509.8}).wait(1).to({graphics:mask_1_graphics_73,x:813.7,y:510.7}).wait(1).to({graphics:mask_1_graphics_74,x:813.7,y:511.6}).wait(1).to({graphics:mask_1_graphics_75,x:813.7,y:512.5}).wait(1).to({graphics:mask_1_graphics_76,x:813.7,y:513.4}).wait(1).to({graphics:mask_1_graphics_77,x:813.7,y:514.2}).wait(1).to({graphics:mask_1_graphics_78,x:813.7,y:515.1}).wait(1));

	// comida
	this.shape_5 = new lib.comida();
	
	this.shape_5.setTransform(757,401);

	

	this.shape_5.mask =  mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).wait(80));


	// Capa 16
	this.instance_4 = new lib._20peces();
	this.instance_4.setTransform(538.1,444.2,1,1,0,0,0,112,45.6);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({alpha:0.988},78).wait(1));

	// pez
	this.instance_5 = new lib.pez2();
	this.instance_5.setTransform(324.8,456.3,0.3,0.295,0,0,0,75.8,89.9);

	this.instance_6 = new lib.pez2();
	this.instance_6.setTransform(299.2,479.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_7 = new lib.pez2();
	this.instance_7.setTransform(227.4,434.3,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_8 = new lib.pez1();
	this.instance_8.setTransform(143.8,453.9,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_9 = new lib.pez1();
	this.instance_9.setTransform(229.9,441.9,0.297,0.377,0,0,0,150.2,90);

	this.instance_10 = new lib.pez2();
	this.instance_10.setTransform(192.7,463.4,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_11 = new lib.pez2();
	this.instance_11.setTransform(255.6,469.5,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_12 = new lib.pez2();
	this.instance_12.setTransform(228.2,481,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_13 = new lib.pez2();
	this.instance_13.setTransform(263.5,485.6,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_14 = new lib.pez1();
	this.instance_14.setTransform(289.4,452.6,0.297,0.377,0,0,0,150.2,90);

	this.instance_15 = new lib.pez1();
	this.instance_15.setTransform(244.1,428.8,0.297,0.377,0,0,180,150.2,90);

	this.instance_16 = new lib.pez1();
	this.instance_16.setTransform(307.3,466.3,0.297,0.377,0,0,0,150.1,90);

	this.instance_17 = new lib.pez1();
	this.instance_17.setTransform(262.1,442.4,0.297,0.377,0,0,180,150.1,90);

	this.instance_18 = new lib.pez2();
	this.instance_18.setTransform(139.8,473.4,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_19 = new lib.pez2();
	this.instance_19.setTransform(174.5,484.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_20 = new lib.pez2();
	this.instance_20.setTransform(129.7,489.5,0.115,0.115,0,0,0,75.9,89.9);

	this.instance_21 = new lib.pez1();
	this.instance_21.setTransform(96.9,456.5,0.377,0.377,0,0,180,150.1,90);

	this.instance_22 = new lib.pez1();
	this.instance_22.setTransform(154.4,432.7,0.377,0.377,0,0,0,150.1,90);

	this.instance_23 = new lib.pez1();
	this.instance_23.setTransform(74.1,470.2,0.377,0.377,0,0,180,150.1,90);

	this.instance_24 = new lib.pez1();
	this.instance_24.setTransform(131.6,446.3,0.377,0.377,0,0,0,150.1,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(79));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,50.4,829.4,451.3);
(lib.peces4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// txt
	this.text = new cjs.Text("Observa que los productos son constantes: 20 · 60 = 40 · 30 = 80 · 15 = 1.200\nEsta es una característica de la proporcionalidad inversa.", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.lineWidth = 828;
	this.text.setTransform(51.5,120.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text}]},80).wait(1));

	// Capa 3
	this.text_1 = new cjs.Text("Total: 40 peces", "22px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 24;
	this.text_1.setTransform(270,510);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1,p:{x:247.1,text:"Total: 40 peces"}}]}).to({state:[]},1).to({state:[{t:this.text_1,p:{x:246.1,text:"Total: 80 peces"}}]},31).wait(49));

	// dias
	this.text_2 = new cjs.Text("1", "bold 34px Verdana", "#FFFFFF");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 36;
	this.text_2.setTransform(837.4,259.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2,p:{text:"1",lineWidth:24}}]}).to({state:[{t:this.text_2,p:{text:"2",lineWidth:24}}]},11).to({state:[{t:this.text_2,p:{text:"3",lineWidth:24}}]},6).to({state:[{t:this.text_2,p:{text:"4",lineWidth:24}}]},5).to({state:[{t:this.text_2,p:{text:"5",lineWidth:24}}]},5).to({state:[{t:this.text_2,p:{text:"6",lineWidth:24}}]},4).to({state:[{t:this.text_2,p:{text:"7",lineWidth:24}}]},3).to({state:[{t:this.text_2,p:{text:"8",lineWidth:24}}]},4).to({state:[{t:this.text_2,p:{text:"9",lineWidth:24}}]},4).to({state:[{t:this.text_2,p:{text:"10",lineWidth:49}}]},4).to({state:[{t:this.text_2,p:{text:"11",lineWidth:49}}]},6).to({state:[{t:this.text_2,p:{text:"12",lineWidth:49}}]},8).to({state:[{t:this.text_2,p:{text:"13",lineWidth:49}}]},7).to({state:[{t:this.text_2,p:{text:"14",lineWidth:49}}]},7).to({state:[{t:this.text_2,p:{text:"15",lineWidth:49}}]},5).to({state:[{t:this.text_2,p:{text:"15",lineWidth:49}}]},1).wait(1));

	// calendario
	this.instance = new lib.Símbolo3();
	this.instance.setTransform(891.3,269.1,0.523,0.523,0,0,0,177.1,84.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(81));

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Egr/AKPIAA0dMBX/AAAIAAUdg");
	var mask_graphics_1 = new cjs.Graphics().p("EgsEAKPIAA0dMBYJAAAIAAUdg");
	var mask_graphics_2 = new cjs.Graphics().p("EgsIAKPIAA0dMBYRAAAIAAUdg");
	var mask_graphics_3 = new cjs.Graphics().p("EgsNAKPIAA0dMBYbAAAIAAUdg");
	var mask_graphics_4 = new cjs.Graphics().p("EgsRAKPIAA0dMBYjAAAIAAUdg");
	var mask_graphics_5 = new cjs.Graphics().p("EgsWAKPIAA0dMBYtAAAIAAUdg");
	var mask_graphics_6 = new cjs.Graphics().p("EgsaAKPIAA0dMBY1AAAIAAUdg");
	var mask_graphics_7 = new cjs.Graphics().p("EgsfAKPIAA0dMBY/AAAIAAUdg");
	var mask_graphics_8 = new cjs.Graphics().p("EgsjAKPIAA0dMBZHAAAIAAUdg");
	var mask_graphics_9 = new cjs.Graphics().p("EgsoAKPIAA0dMBZRAAAIAAUdg");
	var mask_graphics_10 = new cjs.Graphics().p("EgstAKPIAA0dMBZbAAAIAAUdg");
	var mask_graphics_11 = new cjs.Graphics().p("EgsxAKPIAA0dMBZjAAAIAAUdg");
	var mask_graphics_12 = new cjs.Graphics().p("Egs2AKPIAA0dMBZtAAAIAAUdg");
	var mask_graphics_13 = new cjs.Graphics().p("Egs6AKPIAA0dMBZ1AAAIAAUdg");
	var mask_graphics_14 = new cjs.Graphics().p("Egs/AKPIAA0dMBZ/AAAIAAUdg");
	var mask_graphics_15 = new cjs.Graphics().p("EgtDAKPIAA0dMBaHAAAIAAUdg");
	var mask_graphics_16 = new cjs.Graphics().p("EgtIAKPIAA0dMBaRAAAIAAUdg");
	var mask_graphics_17 = new cjs.Graphics().p("EgtMAKPIAA0dMBaZAAAIAAUdg");
	var mask_graphics_18 = new cjs.Graphics().p("EgtRAKPIAA0dMBajAAAIAAUdg");
	var mask_graphics_19 = new cjs.Graphics().p("EgtVAKPIAA0dMBarAAAIAAUdg");
	var mask_graphics_20 = new cjs.Graphics().p("EgtaAKPIAA0dMBa1AAAIAAUdg");
	var mask_graphics_21 = new cjs.Graphics().p("EgtfAKPIAA0dMBa/AAAIAAUdg");
	var mask_graphics_22 = new cjs.Graphics().p("EgtjAKPIAA0dMBbHAAAIAAUdg");
	var mask_graphics_23 = new cjs.Graphics().p("EgtoAKPIAA0dMBbRAAAIAAUdg");
	var mask_graphics_24 = new cjs.Graphics().p("EgtsAKPIAA0dMBbZAAAIAAUdg");
	var mask_graphics_25 = new cjs.Graphics().p("EgtxAKPIAA0dMBbjAAAIAAUdg");
	var mask_graphics_26 = new cjs.Graphics().p("Egt1AKPIAA0dMBbrAAAIAAUdg");
	var mask_graphics_27 = new cjs.Graphics().p("Egt6AKPIAA0dMBb1AAAIAAUdg");
	var mask_graphics_28 = new cjs.Graphics().p("Egt+AKPIAA0dMBb9AAAIAAUdg");
	var mask_graphics_29 = new cjs.Graphics().p("EguDAKPIAA0dMBcHAAAIAAUdg");
	var mask_graphics_30 = new cjs.Graphics().p("EguIAKPIAA0dMBcRAAAIAAUdg");
	var mask_graphics_31 = new cjs.Graphics().p("EguMAKPIAA0dMBcZAAAIAAUdg");
	var mask_graphics_32 = new cjs.Graphics().p("EguRAKPIAA0dMBcjAAAIAAUdg");
	var mask_graphics_33 = new cjs.Graphics().p("EguVAKPIAA0dMBcrAAAIAAUdg");
	var mask_graphics_34 = new cjs.Graphics().p("EguaAKPIAA0dMBc1AAAIAAUdg");
	var mask_graphics_35 = new cjs.Graphics().p("EgueAKPIAA0dMBc9AAAIAAUdg");
	var mask_graphics_36 = new cjs.Graphics().p("EgujAKPIAA0dMBdHAAAIAAUdg");
	var mask_graphics_37 = new cjs.Graphics().p("EgunAKPIAA0dMBdPAAAIAAUdg");
	var mask_graphics_38 = new cjs.Graphics().p("EgusAKPIAA0dMBdZAAAIAAUdg");
	var mask_graphics_39 = new cjs.Graphics().p("EguwAKPIAA0dMBdhAAAIAAUdg");
	var mask_graphics_40 = new cjs.Graphics().p("Egu1AKPIAA0dMBdrAAAIAAUdg");
	var mask_graphics_41 = new cjs.Graphics().p("Egu6AKPIAA0dMBd1AAAIAAUdg");
	var mask_graphics_42 = new cjs.Graphics().p("Egu+AKPIAA0dMBd9AAAIAAUdg");
	var mask_graphics_43 = new cjs.Graphics().p("EgvDAKPIAA0dMBeHAAAIAAUdg");
	var mask_graphics_44 = new cjs.Graphics().p("EgvHAKPIAA0dMBePAAAIAAUdg");
	var mask_graphics_45 = new cjs.Graphics().p("EgvMAKPIAA0dMBeZAAAIAAUdg");
	var mask_graphics_46 = new cjs.Graphics().p("EgvQAKPIAA0dMBehAAAIAAUdg");
	var mask_graphics_47 = new cjs.Graphics().p("EgvVAKPIAA0dMBerAAAIAAUdg");
	var mask_graphics_48 = new cjs.Graphics().p("EgvZAKPIAA0dMBezAAAIAAUdg");
	var mask_graphics_49 = new cjs.Graphics().p("EgveAKPIAA0dMBe9AAAIAAUdg");
	var mask_graphics_50 = new cjs.Graphics().p("EgvjAKPIAA0dMBfHAAAIAAUdg");
	var mask_graphics_51 = new cjs.Graphics().p("EgvnAKPIAA0dMBfPAAAIAAUdg");
	var mask_graphics_52 = new cjs.Graphics().p("EgvsAKPIAA0dMBfZAAAIAAUdg");
	var mask_graphics_53 = new cjs.Graphics().p("EgvwAKPIAA0dMBfhAAAIAAUdg");
	var mask_graphics_54 = new cjs.Graphics().p("Egv1AKPIAA0dMBfrAAAIAAUdg");
	var mask_graphics_55 = new cjs.Graphics().p("Egv5AKPIAA0dMBfzAAAIAAUdg");
	var mask_graphics_56 = new cjs.Graphics().p("Egv+AKPIAA0dMBf9AAAIAAUdg");
	var mask_graphics_57 = new cjs.Graphics().p("EgwCAKPIAA0dMBgFAAAIAAUdg");
	var mask_graphics_58 = new cjs.Graphics().p("EgwHAKPIAA0dMBgPAAAIAAUdg");
	var mask_graphics_59 = new cjs.Graphics().p("EgwLAKPIAA0dMBgXAAAIAAUdg");
	var mask_graphics_60 = new cjs.Graphics().p("EgwQAKPIAA0dMBghAAAIAAUdg");
	var mask_graphics_61 = new cjs.Graphics().p("EgwVAKPIAA0dMBgrAAAIAAUdg");
	var mask_graphics_62 = new cjs.Graphics().p("EgwZAKPIAA0dMBgzAAAIAAUdg");
	var mask_graphics_63 = new cjs.Graphics().p("EgweAKPIAA0dMBg9AAAIAAUdg");
	var mask_graphics_64 = new cjs.Graphics().p("EgwiAKPIAA0dMBhFAAAIAAUdg");
	var mask_graphics_65 = new cjs.Graphics().p("EgwnAKPIAA0dMBhPAAAIAAUdg");
	var mask_graphics_66 = new cjs.Graphics().p("EgwrAKPIAA0dMBhXAAAIAAUdg");
	var mask_graphics_67 = new cjs.Graphics().p("EgwwAKPIAA0dMBhhAAAIAAUdg");
	var mask_graphics_68 = new cjs.Graphics().p("Egw0AKPIAA0dMBhpAAAIAAUdg");
	var mask_graphics_69 = new cjs.Graphics().p("Egw5AKPIAA0dMBhzAAAIAAUdg");
	var mask_graphics_70 = new cjs.Graphics().p("Egw+AKPIAA0dMBh9AAAIAAUdg");
	var mask_graphics_71 = new cjs.Graphics().p("EgxCAKPIAA0dMBiFAAAIAAUdg");
	var mask_graphics_72 = new cjs.Graphics().p("EgxHAKPIAA0dMBiPAAAIAAUdg");
	var mask_graphics_73 = new cjs.Graphics().p("EgxLAKPIAA0dMBiXAAAIAAUdg");
	var mask_graphics_74 = new cjs.Graphics().p("EgxQAKPIAA0dMBihAAAIAAUdg");
	var mask_graphics_75 = new cjs.Graphics().p("EgxUAKPIAA0dMBipAAAIAAUdg");
	var mask_graphics_76 = new cjs.Graphics().p("EgxZAKPIAA0dMBizAAAIAAUdg");
	var mask_graphics_77 = new cjs.Graphics().p("EgxdAKPIAA0dMBi7AAAIAAUdg");
	var mask_graphics_78 = new cjs.Graphics().p("EgxiAKPIAA0dMBjFAAAIAAUdg");
	var mask_graphics_79 = new cjs.Graphics().p("EgxnAKPIAA0dMBjPAAAIAAUdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:296.5,y:265.6}).wait(1).to({graphics:mask_graphics_1,x:297,y:265.6}).wait(1).to({graphics:mask_graphics_2,x:297.4,y:265.6}).wait(1).to({graphics:mask_graphics_3,x:297.9,y:265.6}).wait(1).to({graphics:mask_graphics_4,x:298.3,y:265.6}).wait(1).to({graphics:mask_graphics_5,x:298.8,y:265.6}).wait(1).to({graphics:mask_graphics_6,x:299.2,y:265.6}).wait(1).to({graphics:mask_graphics_7,x:299.7,y:265.6}).wait(1).to({graphics:mask_graphics_8,x:300.1,y:265.6}).wait(1).to({graphics:mask_graphics_9,x:300.6,y:265.6}).wait(1).to({graphics:mask_graphics_10,x:301.1,y:265.6}).wait(1).to({graphics:mask_graphics_11,x:301.5,y:265.6}).wait(1).to({graphics:mask_graphics_12,x:302,y:265.6}).wait(1).to({graphics:mask_graphics_13,x:302.4,y:265.6}).wait(1).to({graphics:mask_graphics_14,x:302.9,y:265.6}).wait(1).to({graphics:mask_graphics_15,x:303.3,y:265.6}).wait(1).to({graphics:mask_graphics_16,x:303.8,y:265.6}).wait(1).to({graphics:mask_graphics_17,x:304.2,y:265.6}).wait(1).to({graphics:mask_graphics_18,x:304.7,y:265.6}).wait(1).to({graphics:mask_graphics_19,x:305.1,y:265.6}).wait(1).to({graphics:mask_graphics_20,x:305.6,y:265.6}).wait(1).to({graphics:mask_graphics_21,x:306.1,y:265.6}).wait(1).to({graphics:mask_graphics_22,x:306.5,y:265.6}).wait(1).to({graphics:mask_graphics_23,x:307,y:265.6}).wait(1).to({graphics:mask_graphics_24,x:307.4,y:265.6}).wait(1).to({graphics:mask_graphics_25,x:307.9,y:265.6}).wait(1).to({graphics:mask_graphics_26,x:308.3,y:265.6}).wait(1).to({graphics:mask_graphics_27,x:308.8,y:265.6}).wait(1).to({graphics:mask_graphics_28,x:309.2,y:265.6}).wait(1).to({graphics:mask_graphics_29,x:309.7,y:265.6}).wait(1).to({graphics:mask_graphics_30,x:310.2,y:265.6}).wait(1).to({graphics:mask_graphics_31,x:310.6,y:265.6}).wait(1).to({graphics:mask_graphics_32,x:311.1,y:265.6}).wait(1).to({graphics:mask_graphics_33,x:311.5,y:265.6}).wait(1).to({graphics:mask_graphics_34,x:312,y:265.6}).wait(1).to({graphics:mask_graphics_35,x:312.4,y:265.6}).wait(1).to({graphics:mask_graphics_36,x:312.9,y:265.6}).wait(1).to({graphics:mask_graphics_37,x:313.3,y:265.6}).wait(1).to({graphics:mask_graphics_38,x:313.8,y:265.6}).wait(1).to({graphics:mask_graphics_39,x:314.2,y:265.6}).wait(1).to({graphics:mask_graphics_40,x:314.7,y:265.6}).wait(1).to({graphics:mask_graphics_41,x:315.2,y:265.6}).wait(1).to({graphics:mask_graphics_42,x:315.6,y:265.6}).wait(1).to({graphics:mask_graphics_43,x:316.1,y:265.6}).wait(1).to({graphics:mask_graphics_44,x:316.5,y:265.6}).wait(1).to({graphics:mask_graphics_45,x:317,y:265.6}).wait(1).to({graphics:mask_graphics_46,x:317.4,y:265.6}).wait(1).to({graphics:mask_graphics_47,x:317.9,y:265.6}).wait(1).to({graphics:mask_graphics_48,x:318.3,y:265.6}).wait(1).to({graphics:mask_graphics_49,x:318.8,y:265.6}).wait(1).to({graphics:mask_graphics_50,x:319.3,y:265.6}).wait(1).to({graphics:mask_graphics_51,x:319.7,y:265.6}).wait(1).to({graphics:mask_graphics_52,x:320.2,y:265.6}).wait(1).to({graphics:mask_graphics_53,x:320.6,y:265.6}).wait(1).to({graphics:mask_graphics_54,x:321.1,y:265.6}).wait(1).to({graphics:mask_graphics_55,x:321.5,y:265.6}).wait(1).to({graphics:mask_graphics_56,x:322,y:265.6}).wait(1).to({graphics:mask_graphics_57,x:322.4,y:265.6}).wait(1).to({graphics:mask_graphics_58,x:322.9,y:265.6}).wait(1).to({graphics:mask_graphics_59,x:323.3,y:265.6}).wait(1).to({graphics:mask_graphics_60,x:323.8,y:265.6}).wait(1).to({graphics:mask_graphics_61,x:324.3,y:265.6}).wait(1).to({graphics:mask_graphics_62,x:324.7,y:265.6}).wait(1).to({graphics:mask_graphics_63,x:325.2,y:265.6}).wait(1).to({graphics:mask_graphics_64,x:325.6,y:265.6}).wait(1).to({graphics:mask_graphics_65,x:326.1,y:265.6}).wait(1).to({graphics:mask_graphics_66,x:326.5,y:265.6}).wait(1).to({graphics:mask_graphics_67,x:327,y:265.6}).wait(1).to({graphics:mask_graphics_68,x:327.4,y:265.6}).wait(1).to({graphics:mask_graphics_69,x:327.9,y:265.6}).wait(1).to({graphics:mask_graphics_70,x:328.4,y:265.6}).wait(1).to({graphics:mask_graphics_71,x:328.8,y:265.6}).wait(1).to({graphics:mask_graphics_72,x:329.3,y:265.6}).wait(1).to({graphics:mask_graphics_73,x:329.7,y:265.6}).wait(1).to({graphics:mask_graphics_74,x:330.2,y:265.6}).wait(1).to({graphics:mask_graphics_75,x:330.6,y:265.6}).wait(1).to({graphics:mask_graphics_76,x:331.1,y:265.6}).wait(1).to({graphics:mask_graphics_77,x:331.5,y:265.6}).wait(1).to({graphics:mask_graphics_78,x:332,y:265.6}).wait(1).to({graphics:mask_graphics_79,x:332.5,y:265.6}).wait(2));

	// txttabla
	this.text_3 = new cjs.Text("15", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 96;
	this.text_3.setTransform(626.2,281.9);

	this.text_4 = new cjs.Text("80", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 95;
	this.text_4.setTransform(626.7,229.9);

	this.text_5 = new cjs.Text("30", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 94;
	this.text_5.setTransform(526.1,281.9);

	this.text_6 = new cjs.Text("40", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 97;
	this.text_6.setTransform(525.6,229.9);

	this.text_7 = new cjs.Text("60", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 93;
	this.text_7.setTransform(425.6,281.9);

	this.text_8 = new cjs.Text("20", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 95;
	this.text_8.setTransform(425.6,229.9);

	this.text_9 = new cjs.Text("duración de la comida (días)", "20px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 22;
	this.text_9.lineWidth = 324;
	this.text_9.setTransform(212.1,279.8);

	this.text_10 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 22;
	this.text_10.lineWidth = 324;
	this.text_10.setTransform(212,229.9);

	this.text_3.mask = this.text_4.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.text_10.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3}]}).wait(81));

	// tabla
	this.instance_1 = new lib.Símbolo11();
	this.instance_1.setTransform(405,269.8,1,1,0,0,0,274.9,51);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EArCAH5MhV5AAAIAAv7");
	this.shape.setTransform(324.5,270.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(81));

	// titulo
	this.text_11 = new cjs.Text("Proporcionalidad inversa", "40px Georgia");
	this.text_11.lineHeight = 42;
	this.text_11.lineWidth = 554;
	this.text_11.setTransform(110,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_11}]}).wait(81));

	// Capa 11
	this.instance_2 = new lib.Símbolo2();
	this.instance_2.setTransform(808.6,431.6,0.742,0.752,0,0,0,77.5,93);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").p("EgxHgIOIAAjhMBiPgAJIAADeIAAUNMgzkAAEMgurAACg");
	this.shape_1.setTransform(365.4,425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],228.2,13,0,228.2,13,232.7).s().p("AABAAIAAAAIgBABIABgBg");
	this.shape_2.setTransform(593.7,338.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,255,0.086)").s().p("EgxGgJ+MBiNgALIAAUNMgzkAADMgupAADg");
	this.shape_3.setTransform(365.4,436.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],2.5,27.2,0,2.5,27.2,266.8).s().p("EgxGgBqMBiNgAJIAADcMhiNAALg");
	this.shape_4.setTransform(365.4,360.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance_2}]}).wait(81));

	// mascara (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Aq2JhIAAzBIVtAAIAATBg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Aq2JaIAAyzIVtAAIAASzg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Aq2JTIAAylIVtAAIAASlg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Aq2JMIAAyXIVtAAIAASXg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Aq2JFIAAyJIVtAAIAASJg");
	var mask_1_graphics_5 = new cjs.Graphics().p("Aq2I+IAAx7IVtAAIAAR7g");
	var mask_1_graphics_6 = new cjs.Graphics().p("Aq2I3IAAxtIVtAAIAARtg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Aq2IwIAAxfIVtAAIAARfg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Aq2IpIAAxRIVtAAIAARRg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Aq2IiIAAxDIVtAAIAARDg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Aq2IbIAAw1IVtAAIAAQ1g");
	var mask_1_graphics_11 = new cjs.Graphics().p("Aq2IUIAAwnIVtAAIAAQng");
	var mask_1_graphics_12 = new cjs.Graphics().p("Aq2INIAAwZIVtAAIAAQZg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Aq2IGIAAwLIVtAAIAAQLg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Aq2H/IAAv9IVtAAIAAP9g");
	var mask_1_graphics_15 = new cjs.Graphics().p("Aq2H4IAAvvIVtAAIAAPvg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aq2HxIAAvhIVtAAIAAPhg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Aq2HqIAAvTIVtAAIAAPTg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aq2HjIAAvFIVtAAIAAPFg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Aq2HcIAAu3IVtAAIAAO3g");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aq2HVIAAupIVtAAIAAOpg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aq2HOIAAubIVtAAIAAObg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Aq2HHIAAuNIVtAAIAAONg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Aq2HAIAAt/IVtAAIAAN/g");
	var mask_1_graphics_24 = new cjs.Graphics().p("Aq2G5IAAtxIVtAAIAANxg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Aq2GyIAAtjIVtAAIAANjg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aq2GrIAAtVIVtAAIAANVg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Aq2GkIAAtHIVtAAIAANHg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Aq2GdIAAs5IVtAAIAAM5g");
	var mask_1_graphics_29 = new cjs.Graphics().p("Aq2GWIAAsrIVtAAIAAMrg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Aq2GPIAAsdIVtAAIAAMdg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Aq2GIIAAsPIVtAAIAAMPg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Aq2GBIAAsBIVtAAIAAMBg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Aq2F6IAArzIVtAAIAALzg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Aq2FzIAArlIVtAAIAALlg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq2FsIAArXIVtAAIAALXg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Aq2FkIAArHIVtAAIAALHg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Aq2FdIAAq5IVtAAIAAK5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("Aq2FWIAAqrIVtAAIAAKrg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Aq2FPIAAqdIVtAAIAAKdg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Aq2FIIAAqPIVtAAIAAKPg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Aq2FBIAAqBIVtAAIAAKBg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Aq2E6IAApzIVtAAIAAJzg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Aq2EzIAAplIVtAAIAAJlg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aq2EsIAApXIVtAAIAAJXg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Aq2ElIAApJIVtAAIAAJJg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Aq2EeIAAo7IVtAAIAAI7g");
	var mask_1_graphics_47 = new cjs.Graphics().p("Aq2EXIAAotIVtAAIAAItg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Aq2EQIAAofIVtAAIAAIfg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Aq2EJIAAoRIVtAAIAAIRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Aq2ECIAAoDIVtAAIAAIDg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Aq2D7IAAn1IVtAAIAAH1g");
	var mask_1_graphics_52 = new cjs.Graphics().p("Aq2D0IAAnnIVtAAIAAHng");
	var mask_1_graphics_53 = new cjs.Graphics().p("Aq2DtIAAnZIVtAAIAAHZg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Aq2DmIAAnLIVtAAIAAHLg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Aq2DfIAAm9IVtAAIAAG9g");
	var mask_1_graphics_56 = new cjs.Graphics().p("Aq2DYIAAmvIVtAAIAAGvg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Aq2DRIAAmhIVtAAIAAGhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Aq2DKIAAmTIVtAAIAAGTg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Aq2DDIAAmFIVtAAIAAGFg");
	var mask_1_graphics_60 = new cjs.Graphics().p("Aq2C8IAAl3IVtAAIAAF3g");
	var mask_1_graphics_61 = new cjs.Graphics().p("Aq2C1IAAlpIVtAAIAAFpg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Aq2CuIAAlbIVtAAIAAFbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Aq2CnIAAlNIVtAAIAAFNg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Aq2CgIAAk/IVtAAIAAE/g");
	var mask_1_graphics_65 = new cjs.Graphics().p("Aq2CZIAAkxIVtAAIAAExg");
	var mask_1_graphics_66 = new cjs.Graphics().p("Aq2CSIAAkjIVtAAIAAEjg");
	var mask_1_graphics_67 = new cjs.Graphics().p("Aq2CLIAAkVIVtAAIAAEVg");
	var mask_1_graphics_68 = new cjs.Graphics().p("Aq2CEIAAkHIVtAAIAAEHg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Aq2B9IAAj5IVtAAIAAD5g");
	var mask_1_graphics_70 = new cjs.Graphics().p("Aq2B2IAAjrIVtAAIAADrg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Aq2BuIAAjbIVtAAIAADbg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Aq2BnIAAjNIVtAAIAADNg");
	var mask_1_graphics_73 = new cjs.Graphics().p("Aq2BgIAAi/IVtAAIAAC/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("Aq2BZIAAixIVtAAIAACxg");
	var mask_1_graphics_75 = new cjs.Graphics().p("Aq2BSIAAijIVtAAIAACjg");
	var mask_1_graphics_76 = new cjs.Graphics().p("Aq2BLIAAiVIVtAAIAACVg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Aq2BEIAAiHIVtAAIAACHg");
	var mask_1_graphics_78 = new cjs.Graphics().p("Aq2A9IAAh5IVtAAIAAB5g");
	var mask_1_graphics_79 = new cjs.Graphics().p("Aq2A2IAAhrIVtAAIAABrg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:813.7,y:446.1}).wait(1).to({graphics:mask_1_graphics_1,x:813.7,y:447}).wait(1).to({graphics:mask_1_graphics_2,x:813.7,y:447.8}).wait(1).to({graphics:mask_1_graphics_3,x:813.7,y:448.7}).wait(1).to({graphics:mask_1_graphics_4,x:813.7,y:449.6}).wait(1).to({graphics:mask_1_graphics_5,x:813.7,y:450.5}).wait(1).to({graphics:mask_1_graphics_6,x:813.7,y:451.3}).wait(1).to({graphics:mask_1_graphics_7,x:813.7,y:452.2}).wait(1).to({graphics:mask_1_graphics_8,x:813.7,y:453.1}).wait(1).to({graphics:mask_1_graphics_9,x:813.7,y:454}).wait(1).to({graphics:mask_1_graphics_10,x:813.7,y:454.8}).wait(1).to({graphics:mask_1_graphics_11,x:813.7,y:455.7}).wait(1).to({graphics:mask_1_graphics_12,x:813.7,y:456.6}).wait(1).to({graphics:mask_1_graphics_13,x:813.7,y:457.5}).wait(1).to({graphics:mask_1_graphics_14,x:813.7,y:458.3}).wait(1).to({graphics:mask_1_graphics_15,x:813.7,y:459.2}).wait(1).to({graphics:mask_1_graphics_16,x:813.7,y:460.1}).wait(1).to({graphics:mask_1_graphics_17,x:813.7,y:461}).wait(1).to({graphics:mask_1_graphics_18,x:813.7,y:461.8}).wait(1).to({graphics:mask_1_graphics_19,x:813.7,y:462.7}).wait(1).to({graphics:mask_1_graphics_20,x:813.7,y:463.6}).wait(1).to({graphics:mask_1_graphics_21,x:813.7,y:464.4}).wait(1).to({graphics:mask_1_graphics_22,x:813.7,y:465.3}).wait(1).to({graphics:mask_1_graphics_23,x:813.7,y:466.2}).wait(1).to({graphics:mask_1_graphics_24,x:813.7,y:467.1}).wait(1).to({graphics:mask_1_graphics_25,x:813.7,y:467.9}).wait(1).to({graphics:mask_1_graphics_26,x:813.7,y:468.8}).wait(1).to({graphics:mask_1_graphics_27,x:813.7,y:469.7}).wait(1).to({graphics:mask_1_graphics_28,x:813.7,y:470.6}).wait(1).to({graphics:mask_1_graphics_29,x:813.7,y:471.4}).wait(1).to({graphics:mask_1_graphics_30,x:813.7,y:472.3}).wait(1).to({graphics:mask_1_graphics_31,x:813.7,y:473.2}).wait(1).to({graphics:mask_1_graphics_32,x:813.7,y:474.1}).wait(1).to({graphics:mask_1_graphics_33,x:813.7,y:474.9}).wait(1).to({graphics:mask_1_graphics_34,x:813.7,y:475.8}).wait(1).to({graphics:mask_1_graphics_35,x:813.7,y:476.7}).wait(1).to({graphics:mask_1_graphics_36,x:813.7,y:477.6}).wait(1).to({graphics:mask_1_graphics_37,x:813.7,y:478.4}).wait(1).to({graphics:mask_1_graphics_38,x:813.7,y:479.3}).wait(1).to({graphics:mask_1_graphics_39,x:813.7,y:480.2}).wait(1).to({graphics:mask_1_graphics_40,x:813.7,y:481}).wait(1).to({graphics:mask_1_graphics_41,x:813.7,y:481.9}).wait(1).to({graphics:mask_1_graphics_42,x:813.7,y:482.8}).wait(1).to({graphics:mask_1_graphics_43,x:813.7,y:483.7}).wait(1).to({graphics:mask_1_graphics_44,x:813.7,y:484.5}).wait(1).to({graphics:mask_1_graphics_45,x:813.7,y:485.4}).wait(1).to({graphics:mask_1_graphics_46,x:813.7,y:486.3}).wait(1).to({graphics:mask_1_graphics_47,x:813.7,y:487.2}).wait(1).to({graphics:mask_1_graphics_48,x:813.7,y:488}).wait(1).to({graphics:mask_1_graphics_49,x:813.7,y:488.9}).wait(1).to({graphics:mask_1_graphics_50,x:813.7,y:489.8}).wait(1).to({graphics:mask_1_graphics_51,x:813.7,y:490.7}).wait(1).to({graphics:mask_1_graphics_52,x:813.7,y:491.5}).wait(1).to({graphics:mask_1_graphics_53,x:813.7,y:492.4}).wait(1).to({graphics:mask_1_graphics_54,x:813.7,y:493.3}).wait(1).to({graphics:mask_1_graphics_55,x:813.7,y:494.2}).wait(1).to({graphics:mask_1_graphics_56,x:813.7,y:495}).wait(1).to({graphics:mask_1_graphics_57,x:813.7,y:495.9}).wait(1).to({graphics:mask_1_graphics_58,x:813.7,y:496.8}).wait(1).to({graphics:mask_1_graphics_59,x:813.7,y:497.7}).wait(1).to({graphics:mask_1_graphics_60,x:813.7,y:498.5}).wait(1).to({graphics:mask_1_graphics_61,x:813.7,y:499.4}).wait(1).to({graphics:mask_1_graphics_62,x:813.7,y:500.3}).wait(1).to({graphics:mask_1_graphics_63,x:813.7,y:470.1}).wait(1).to({graphics:mask_1_graphics_64,x:813.7,y:502}).wait(1).to({graphics:mask_1_graphics_65,x:813.7,y:502.9}).wait(1).to({graphics:mask_1_graphics_66,x:813.7,y:503.8}).wait(1).to({graphics:mask_1_graphics_67,x:813.7,y:504.6}).wait(1).to({graphics:mask_1_graphics_68,x:813.7,y:505.5}).wait(1).to({graphics:mask_1_graphics_69,x:813.7,y:506.4}).wait(1).to({graphics:mask_1_graphics_70,x:813.7,y:507.3}).wait(1).to({graphics:mask_1_graphics_71,x:813.7,y:508.1}).wait(1).to({graphics:mask_1_graphics_72,x:813.7,y:509}).wait(1).to({graphics:mask_1_graphics_73,x:813.7,y:509.9}).wait(1).to({graphics:mask_1_graphics_74,x:813.7,y:510.8}).wait(1).to({graphics:mask_1_graphics_75,x:813.7,y:511.6}).wait(1).to({graphics:mask_1_graphics_76,x:813.7,y:512.5}).wait(1).to({graphics:mask_1_graphics_77,x:813.7,y:513.4}).wait(1).to({graphics:mask_1_graphics_78,x:813.7,y:514.3}).wait(1).to({graphics:mask_1_graphics_79,x:813.7,y:515.1}).wait(2));

	// comida
	this.shape_5 = new lib.comida();
	
	this.shape_5.setTransform(757,401);

	

	this.shape_5.mask =  mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).wait(80));


	// Capa 14
	this.instance_3 = new lib._20peces();
	this.instance_3.setTransform(403.5,450.1,1,1,0,0,0,112,45.6);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({alpha:1},45).wait(36));

	// Capa 15
	this.instance_4 = new lib._20peces();
	this.instance_4.setTransform(242.5,444.1,1,1,0,0,0,112,45.6);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).to({alpha:1},60).wait(2));

	// Capa 16
	this.instance_5 = new lib._20peces();
	this.instance_5.setTransform(538.1,444.2,1,1,0,0,0,112,45.6);
	this.instance_5.alpha = 0.988;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).wait(81));

	// pez
	this.instance_6 = new lib.pez2();
	this.instance_6.setTransform(324.8,456.3,0.3,0.295,0,0,0,75.8,89.9);

	this.instance_7 = new lib.pez2();
	this.instance_7.setTransform(299.2,479.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_8 = new lib.pez2();
	this.instance_8.setTransform(227.4,434.3,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_9 = new lib.pez1();
	this.instance_9.setTransform(143.8,453.9,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_10 = new lib.pez1();
	this.instance_10.setTransform(229.9,441.9,0.297,0.377,0,0,0,150.2,90);

	this.instance_11 = new lib.pez2();
	this.instance_11.setTransform(192.7,463.4,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_12 = new lib.pez2();
	this.instance_12.setTransform(255.6,469.5,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_13 = new lib.pez2();
	this.instance_13.setTransform(228.2,481,0.264,0.295,0,0,0,75.9,89.9);

	this.instance_14 = new lib.pez2();
	this.instance_14.setTransform(263.5,485.6,0.09,0.115,0,0,180,75.8,89.9);

	this.instance_15 = new lib.pez1();
	this.instance_15.setTransform(289.4,452.6,0.297,0.377,0,0,0,150.2,90);

	this.instance_16 = new lib.pez1();
	this.instance_16.setTransform(244.1,428.8,0.297,0.377,0,0,180,150.2,90);

	this.instance_17 = new lib.pez1();
	this.instance_17.setTransform(307.3,466.3,0.297,0.377,0,0,0,150.1,90);

	this.instance_18 = new lib.pez1();
	this.instance_18.setTransform(262.1,442.4,0.297,0.377,0,0,180,150.1,90);

	this.instance_19 = new lib.pez2();
	this.instance_19.setTransform(139.8,473.4,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_20 = new lib.pez2();
	this.instance_20.setTransform(174.5,484.9,0.335,0.295,0,0,180,75.9,89.9);

	this.instance_21 = new lib.pez2();
	this.instance_21.setTransform(129.7,489.5,0.115,0.115,0,0,0,75.9,89.9);

	this.instance_22 = new lib.pez1();
	this.instance_22.setTransform(96.9,456.5,0.377,0.377,0,0,180,150.1,90);

	this.instance_23 = new lib.pez1();
	this.instance_23.setTransform(154.4,432.7,0.377,0.377,0,0,0,150.1,90);

	this.instance_24 = new lib.pez1();
	this.instance_24.setTransform(74.1,470.2,0.377,0.377,0,0,180,150.1,90);

	this.instance_25 = new lib.pez1();
	this.instance_25.setTransform(131.6,446.3,0.377,0.377,0,0,0,150.1,90);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]}).wait(81));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(50,50.4,829.4,506.9);

(lib.peces5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// puntos
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1,1,1).p("ABNAAQAAAfgXAXQgXAXgfAAQgeAAgYgXQgWgXAAgfQAAgeAWgYQAYgWAeAAQAfAAAXAWQAXAYAAAeg");
	this.shape.setTransform(332,354.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag2A2QgWgWAAggQAAgfAWgWQAYgXAeAAQAgAAAWAXQAXAWAAAfQAAAggXAWQgWAXggAAQgeAAgYgXg");
	this.shape_1.setTransform(332,354.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FF0000").ss(1,1,1).p("AmemPQgXAXggAAQgfAAgYgXQgWgXAAggQAAgfAWgYQAYgWAfAAQAgAAAXAWQAXAYAAAfQAAAggXAXgAGfGQQAXgXAgAAQAfAAAXAXQAXAXAAAgQAAAfgXAXQgXAXgfAAQggAAgXgXQgXgXAAgfQAAggAXgXg");
	this.shape_2.setTransform(379,399.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AGfH9QgXgXAAggQAAgfAXgXQAWgXAhAAQAgAAAWAXQAXAXAAAfQAAAggXAXQgWAXggAAQghAAgWgXgAoMmPQgWgWAAggQAAghAWgWQAYgXAfAAQAhAAAWAXQAXAWAAAhQAAAggXAWQgWAXghAAQgfAAgYgXg");
	this.shape_3.setTransform(379,399.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FF0000").ss(1,1,1).p("A2ApPQggAAgXgXQgXgXAAggQAAgfAXgYQAXgWAgAAQAgAAAWAWQAXAYAAAfQAAAggXAXQgWAXggAAgAWBJQQAgAAAWAXQAYAXAAAgQAAAfgYAXQgWAXggAAQggAAgXgXQgWgXAAgfQAAggAWgXQAXgXAgAAgAnUCiQAgAAAWAXQAYAXAAAgQAAAfgYAXQgWAXggAAQggAAgXgXQgWgXAAgfQAAggAWgXQAXgXAgAAg");
	this.shape_4.setTransform(472.9,421.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AVKLUQgWgWgBggQABghAWgWQAXgXAgAAQAgAAAWAXQAYAWAAAhQAAAggYAWQgWAXggAAQggAAgXgXgAoLEmQgWgXAAggQAAgfAWgXQAXgXAgAAQAgAAAWAXQAYAXAAAfQAAAggYAXQgWAXggAAQggAAgXgXgA23pmQgWgWgBggQABghAWgWQAXgXAgAAQAgAAAXAXQAXAWgBAhQABAggXAWQgXAXggAAQggAAgXgXg");
	this.shape_5.setTransform(472.9,421.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},14).to({state:[{t:this.shape_3},{t:this.shape_2}]},29).to({state:[{t:this.shape_5},{t:this.shape_4}]},36).wait(1));

	// linea
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF0000").ss(3,1,1).p("AhiheIDFC9");
	this.shape_6.setTransform(340.9,363.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FF0000").ss(3,1,1).p("AjhjXIHDGv");
	this.shape_7.setTransform(353.6,375.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FF0000").ss(3,1,1).p("AlLk9IKXJ7");
	this.shape_8.setTransform(364.2,385.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FF0000").ss(3,1,1).p("AnZnFIOzOL");
	this.shape_9.setTransform(378.4,399.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FF0000").ss(3,1,1).p("ApMnfIO0OMIDlA0");
	this.shape_10.setTransform(389.9,402.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FF0000").ss(3,1,1).p("AspoRIO1OMIKeCY");
	this.shape_11.setTransform(412,407.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FF0000").ss(3,1,1).p("AyUpkIO2OMIVzE9");
	this.shape_12.setTransform(448.3,415.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF0000").ss(3,1,1).p("A2LqcIO2OMIdhGt");
	this.shape_13.setTransform(473,421);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6}]},14).to({state:[{t:this.shape_7}]},10).to({state:[{t:this.shape_8}]},8).to({state:[{t:this.shape_9}]},11).to({state:[{t:this.shape_10}]},10).to({state:[{t:this.shape_11}]},8).to({state:[{t:this.shape_12}]},9).to({state:[{t:this.shape_13}]},9).wait(1));

	// tabla2
	this.text = new cjs.Text(" días", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 100;
	this.text.setTransform(136.9,400.7);

	this.text_1 = new cjs.Text("15", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 96;
	this.text_1.setTransform(741.2,261.9);

	this.text_2 = new cjs.Text("80", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 95;
	this.text_2.setTransform(741.7,209.9);

	this.text_3 = new cjs.Text("30", "20px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 94;
	this.text_3.setTransform(641.1,261.9);

	this.text_4 = new cjs.Text("40", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 22;
	this.text_4.lineWidth = 97;
	this.text_4.setTransform(640.6,209.9);

	this.text_5 = new cjs.Text("60", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 22;
	this.text_5.lineWidth = 93;
	this.text_5.setTransform(540.6,261.9);

	this.text_6 = new cjs.Text("20", "20px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 22;
	this.text_6.lineWidth = 95;
	this.text_6.setTransform(540.6,209.9);

	this.text_7 = new cjs.Text("duración de la comida (días)", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 22;
	this.text_7.lineWidth = 324;
	this.text_7.setTransform(327.1,259.8);

	this.text_8 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 22;
	this.text_8.lineWidth = 324;
	this.text_8.setTransform(327,209.9);

	this.instance = new lib.Símbolo11();
	this.instance.setTransform(520,249.8,1,1,0,0,0,274.9,51);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2).p("EArCAH5MhV5AAAIAAv7");
	this.shape_14.setTransform(439.5,250.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.instance},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(80));

	// txt
	this.text_9 = new cjs.Text(txt['tit2'], "40px Georgia");
	this.text_9.lineHeight = 42;
	this.text_9.lineWidth = 554;
	this.text_9.setTransform(110,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_9}]}).wait(80));

	// extras
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(2).p("AHRgXIAAAgAWEgXIAAAgA2DgXIAAAuAnWgSIAAAg");
	this.shape_15.setTransform(472.9,537.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15}]}).wait(80));

	// Capa 8
	this.text_10 = new cjs.Text("120", "15px Verdana");
	this.text_10.lineHeight = 17;
	this.text_10.setTransform(778.9,546.8,0.903,0.903);

	this.text_11 = new cjs.Text("100", "15px Verdana");
	this.text_11.lineHeight = 17;
	this.text_11.setTransform(683.2,546.8,0.903,0.903);

	this.text_12 = new cjs.Text("80", "15px Verdana");
	this.text_12.lineHeight = 17;
	this.text_12.setTransform(602.6,546.8,0.903,0.903);

	this.text_13 = new cjs.Text("60", "15px Verdana");
	this.text_13.lineHeight = 17;
	this.text_13.setTransform(508.5,546.8,0.903,0.903);

	this.text_14 = new cjs.Text("40", "15px Verdana");
	this.text_14.lineHeight = 17;
	this.text_14.setTransform(414.6,546.7,0.903,0.903);

	this.text_15 = new cjs.Text("20", "15px Verdana");
	this.text_15.lineHeight = 17;
	this.text_15.setTransform(320.6,546.7,0.903,0.903);

	this.text_16 = new cjs.Text("0", "15px Verdana");
	this.text_16.lineHeight = 17;
	this.text_16.setTransform(231.5,546.7,0.903,0.903);

	this.text_17 = new cjs.Text("70", "15px Verdana");
	this.text_17.lineHeight = 17;
	this.text_17.setTransform(213.5,315.2,0.903,0.903);

	this.text_18 = new cjs.Text("60", "15px Verdana");
	this.text_18.lineHeight = 17;
	this.text_18.setTransform(213.5,342.7,0.903,0.903);

	this.text_19 = new cjs.Text("50", "15px Verdana");
	this.text_19.lineHeight = 17;
	this.text_19.setTransform(213.8,373,0.903,0.903);

	this.text_20 = new cjs.Text("40", "15px Verdana");
	this.text_20.lineHeight = 17;
	this.text_20.setTransform(213.8,405.2,0.903,0.903);

	this.text_21 = new cjs.Text("30", "15px Verdana");
	this.text_21.lineHeight = 17;
	this.text_21.setTransform(213.5,433.5,0.903,0.903);

	this.text_22 = new cjs.Text("20", "15px Verdana");
	this.text_22.lineHeight = 17;
	this.text_22.setTransform(214,463.5,0.903,0.903);

	this.text_23 = new cjs.Text("10", "15px Verdana");
	this.text_23.lineHeight = 17;
	this.text_23.setTransform(213.5,493.2,0.903,0.903);

	this.text_24 = new cjs.Text("0", "15px Verdana");
	this.text_24.lineHeight = 17;
	this.text_24.setTransform(214,523.7,0.903,0.903);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#666666").ss(2).p("EArWALsMhWrAAAEgrVAQXIACAAMBWpAAAEgrVgQWMBWrAAAEgrVAHBMBWrAAAEArWgHAMhWrAAAEgrVgLxMBWrAAAEArWACbMhWrAAAEArWgCUMhWrAAA");
	this.shape_16.setTransform(516.6,428.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(2).p("EArTALRIAGAAIAA8CAckQCIAAAwEgrYALRIAAErEArZALRIAAErEArZAP/IAAAwEgrYACAIAAkvIAAksIAAkxIAAklEgrYACAIgGAAEgrYAGmIgGAAEgrYACAIAAEmEgrYALRIgGAAEgrWAP8IAAAvEgrYALRIAAkr");
	this.shape_17.setTransform(516.9,431.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B9FFFF").s().p("EgrTAQXIgCAAIAAkrMBWrAAAIAAErgEgrVALsIAAkrMBWrAAAMhWrAAAIAAkmIAAkvIAAksIAAkxIAAklMBWrAAAIAAElMhWrAAAMBWrAAAIAAExMhWrAAAMBWrAAAIAAEsMhWrAAAMBWrAAAIAAEvMhWrAAAMBWrAAAIAAEmIAAErgEArWgLxg");
	this.shape_18.setTransform(516.6,428.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.text_24},{t:this.text_23},{t:this.text_22},{t:this.text_21},{t:this.text_20},{t:this.text_19},{t:this.text_18},{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10}]}).wait(80));

	// ff-back
	this.text_25 = new cjs.Text("nº de peces", "20px Verdana");
	this.text_25.lineHeight = 22;
	this.text_25.setTransform(805.3,515.6);


	this.text_26 = new cjs.Text("Al representar una relación de proporcionalidad inversa gráficamente, \nsiempre se obtiene una línea decreciente.", "22px Verdana");
	this.text_26.lineHeight = 24;
	this.text_26.setTransform(50.9,120.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_26},{t:this.text_25}]}).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,50.4,884.6,516.6);
(lib.peces6 = function() {
	this.initialize();

	// Capa 12
	this.instance = new lib.Símbolo7();
	this.instance.setTransform(482.1,415.2,0.972,0.972,0,0,0,407.4,82);

	// txt
	this.text = new cjs.Text(txt['tit2'], "40px Georgia");
	this.text.lineHeight = 42;
	this.text.lineWidth = 554;
	this.text.setTransform(110,50.4);

	// ff-back
		// rewind
	this.text_1 = new cjs.Text("- Una relación de proporcionalidad inversa siempre tiene productos \n  constantes y se representa gráficamente con una línea decreciente.", "22px Verdana");
	this.text_1.lineHeight = 24;
	this.text_1.lineWidth = 846;
	this.text_1.setTransform(50.6,234.9);


	this.text_2 = new cjs.Text("- La relación de proporcionalidad es inversa.\n     · Al aumentar el número de peces, disminuye en proporción la duración\n       de la comida.", "22px Verdana");
	this.text_2.lineHeight = 24;
	this.text_2.lineWidth = 846;
	this.text_2.setTransform(50.9,120.9);

	this.addChild(this.text_2,this.text_1,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(44,50.4,857,511.4);


   (lib._1056718412 = function() {
	this.initialize(img._1056718412);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,180);


(lib._105671841 = function() {
	this.initialize(img._105671841);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,102);


(lib._57283753 = function() {
	this.initialize(img._57283753);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,608,608);


(lib.garbanzo = function() {
	this.initialize(img.garbanzo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,100,85);


(lib.pez = function() {
	this.initialize(img.pez);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,371,459);


(lib.taza_bascula = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("AAzjpIAAHTIhkAAIAAnTg");
	this.shape.setTransform(147.7,91);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#57554E").s().p("AgyDqIAAnTIBkAAIAAHTg");
	this.shape_1.setTransform(147.7,91);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2).p("AAyjpIAAHTIhjAAIAAnTg");
	this.shape_2.setTransform(82.8,91);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#57554E").s().p("AgxDqIAAnTIBjAAIAAHTg");
	this.shape_3.setTransform(82.8,91);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").p("AJVAAQAAALivAIQiuAIj4AAQj3AAiugIQivgIAAgLQAAgKCvgIQCwgID1AAQD2AACwAIQCvAIAAAKg");
	this.shape_4.setTransform(115.3,64.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#85838C").s().p("AmlATQivgIAAgLQAAgKCvgIQCvgID2AAQD2AACwAIQCvAIAAAKQAAALivAIQiuAIj4AAQj3AAiugIg");
	this.shape_5.setTransform(115.3,64.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#999999").p("AUEiWQqFADp/ABQ0DAEADgGIgDAAQAEA9BmA4QBjA0CxAqQF3BYIOAAQIRAAF3hZQCygqBig0QBmg4ACg+g");
	this.shape_6.setTransform(111.5,49.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],70.4,4.5,0,70.4,4.5,46.9).s().p("AuFA/Qixgphjg0Qhmg4gEg+IADAAQgDAGUDgEIUEgEQgCA+hmA4QhiA0iyAqQl3BZoRAAQoOAAl3hYg");
	this.shape_7.setTransform(111.5,49.9);

	this.addChild(this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-16.9,34.8,257,79.7);


(lib.cuerpo_balanza = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").p("AAApUQD2AACwCvQCvCwAAD1QAAD3ivCvQiwCvj2AAQj2AAivivQivivAAj3QAAj1CviwQCvivD2AAg");
	this.shape.setTransform(79.3,76.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E8FFFF").s().p("AmlGmQivivAAj3QAAj2CvivQCvivD2AAQD2AACwCvQCvCvAAD2QAAD3ivCvQiwCvj2AAQj2AAivivg");
	this.shape_1.setTransform(79.3,76.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").p("AkprAQCPg8CaAAQCbAACPA8QCJA7BqBpQBqBqA6CJQA8CPAACaQAACbg8CPQg6CJhqBqQhqBpiJA7QiPA8ibAAQiaAAiPg8QiJg7hqhpQhphqg7iJQg8iPAAibQAAiaA8iPQA7iJBphqQBqhpCJg7g");
	this.shape_2.setTransform(79.3,76.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFFFF","#0099CC","#0542F0"],[0,0.345,1],0,0,0,0,0,76.5).s().p("AkoLBQiJg6hqhqQhqhrg7iIQg7iPAAibQAAiaA7iOQA7iKBqhpQBqhqCJg7QCOg7CaAAQCbAACPA7QCIA7BrBqQBqBpA5CKQA9COAACaQAACbg9CPQg5CIhqBrQhrBqiIA6QiPA7ibABQiagBiOg7g");
	this.shape_3.setTransform(79.3,76.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").p("AryD3QBjhmAyhvQBijViDjMQgQgaDJgOQCwgNEQgBQEGgBC8ALQDNAMgKATQhuDjBGDCQAjBiA4A1IAWASQAZAXATAcQA7BZgeBgQhMAFhKACQiUAFAGgMQBIiGhDhAQgYgXgmgKQgdgIgVACQilAPkZgHQlBgIgKAAQiYADADB1QACA7AfA6QjiAKgkgKQgigVAJg/QAIg4Afgrg");
	this.shape_4.setTransform(79.7,157.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#57554E").s().p("AHuGuQBIiGhDhAQgYgXgmgKQgdgIgVACQilAPkZgHQlBgIgKAAQiYADADB1QACA7AfA6QjiAKgkgKQgigVAJg/QAIg4AfgrQBjhmAyhvQBijViDjMQgQgaDJgOQCwgNEQgBQEGgBC8ALQDNAMgKATQhuDjBGDCQAjBiA4A1IAWASQAZAXATAcQA7BZgeBgQhMAFhKACIhIABQhKAAAEgIg");
	this.shape_5.setTransform(79.7,157.7);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,159.4,201.6);


(lib.Símbolo11 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2).p("EAxNAAAIvyAAIAAn9IPyAAIAAH9IAAH+IvyAAIAAn+ACLAAIPeAAIAAH+IveAAIAAn+IAAn9IPeAAIAAH9IPyAAEAhbAH+IvyAAARpn9IPyAAACLAAMgzXAAAIAAn9MAzXAAAACIH+MgzUAAAIAAn+");
	this.shape.setTransform(235,51);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-79.9,0,630,102);


(lib.Símbolo10 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("¿Y si llego a tener 80 peces?", "22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.setTransform(-103.3,0);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-261.4,0,320.1,30.7);


(lib.Símbolo8 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Un balde de comida permite mantener un acuario con 20 peces durante\n60 días.", "22px Verdana");
	this.text.lineHeight = 24;
	this.text.setTransform(-17.9,0);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-17.9,0,789.6,59.4);


(lib.Símbolo5 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.6).p("AhDhQQBrglBRAUQARADANAGAhDhQQAbBihAA5QgTARgcANQAAAAAAABAhoBLIgvAe");
	this.shape.setTransform(135.3,115.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(0.1).p("AB8hOIAAABAB8hOIgBAAIj2Ce");
	this.shape_1.setTransform(138.1,114.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(5,2).p("ALYAAI2vAA");
	this.shape_2.setTransform(75.3,2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#010001").ss(0.6,2).p("ALwG0IABABIAAgBAG/J4IyvAAIAAzvALxp3IAAQr");
	this.shape_3.setTransform(75.3,63.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00CCFF").s().p("AG+J3IyuAAIAAzuIXgAAIAAQrIgBAAQgNgGgQgDQhSgVhsAmQAaBkg/A5IgwAeIAAAAgALYpjI2vAAg");
	this.shape_4.setTransform(75.3,63.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCFF00").s().p("AiXBhIAvgeQgTARgcANQAcgNATgRQBAg5gbhjQASA1gRAvQgJAbgUAXQgNAPgRAOIAIgCIgKADIAAABIgBAAIABgCIgMAEIgMADIAAAAgACYhgIAAAAIAAAAgACYhgIgBAAIABAAIAAAAg");
	this.shape_5.setTransform(135.3,116.6);

	this.addChild(this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,150.6,126.4);


(lib.Símbolo4 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.garbanzo();
	this.instance.setTransform(23,19.6,0.54,0.54);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(23,19.6,54,45.9);


(lib.Símbolo2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,153,153,0.31)").s("#999999").rr(-139.05,-150.6,278.1,301.2,32.5);
	this.shape.setTransform(77.2,107.7,0.52,0.52);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#999999").p("AHBCMQjyAPjigOQkXgRiqAIQgeACgbADQg4AEghAIIgXAHIh6jOIgNgXIAGgJQADgDAEgDQAIgIAMgHQA4ggBrgGQA0gDA4gDQDegJEfAAQDGAABlACQB9ADBzAJQBmAHA4AeQAbAOAIAOQgdBBghA7QhBB7gVgTQgRgOgqgCQgaAAhbAFg");
	this.shape_1.setTransform(77.4,15.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(153,153,153,0.31)").s().p("Ar3gyIgNgWIAGgKIAHgGQAIgIAMgHQA4gfBrgHIBsgFQDegKEfAAQDGAABlADQB9ADBzAIQBmAIA4AdQAbAPAIANQgdBBghA8QhBB7gVgTQgRgPgqgBQgagBhbAGQjyAPjigOQkXgSiqAJIg5AEQg4AFghAIIgXAHg");
	this.shape_2.setTransform(77.4,15.7);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,154.8,186.1);


(lib.pez1int = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib._1056718412();
	this.instance.setTransform(2,53.8,0.403,0.403);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(2,53.8,120.8,72.5);


(lib.numeros = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// dias
	this.text = new cjs.Text("1", "bold 34px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 36;
	this.text.setTransform(362.3,-44.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{text:"1",x:362.3,lineWidth:24}}]}).to({state:[{t:this.text,p:{text:"2",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"3",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"4",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"5",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"6",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"7",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"8",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"9",x:362.3,lineWidth:24}}]},1).to({state:[{t:this.text,p:{text:"10",x:362.4,lineWidth:49}}]},1).to({state:[{t:this.text,p:{text:"11",x:362.4,lineWidth:49}}]},1).to({state:[{t:this.text,p:{text:"12",x:362.4,lineWidth:49}}]},2).to({state:[{t:this.text,p:{text:"13",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"14",x:362.4,lineWidth:49}}]},3).to({state:[{t:this.text,p:{text:"15",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"16",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"17",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"18",x:362.4,lineWidth:49}}]},5).to({state:[{t:this.text,p:{text:"30",x:362.4,lineWidth:49}}]},6).to({state:[{t:this.text,p:{text:"34",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"38",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"41",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"45",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"52",x:362.4,lineWidth:49}}]},5).to({state:[{t:this.text,p:{text:"55",x:362.4,lineWidth:49}}]},5).to({state:[{t:this.text,p:{text:"56",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"57",x:362.4,lineWidth:49}}]},4).to({state:[{t:this.text,p:{text:"60",x:362.4,lineWidth:49}}]},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(350.2,-44.5,28.3,45.4);


(lib.burbuja = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("AMbAAQAAFJjqDoQjoDqlJAAQlIAAjpjqQjpjoAAlJQAAlIDpjpQDpjpFIAAQFJAADoDpQDqDpAAFIg");
	this.shape.setTransform(108.6,108.6,0.633,0.633);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,255,0.31)").s().p("AoxIyQjpjpAAlJQAAlIDpjpQDpjpFIAAQFJAADpDpQDpDpAAFIQAAFJjpDpQjpDplJAAQlIAAjpjpg");
	this.shape_1.setTransform(108.6,108.6,0.633,0.633);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(58.3,58.3,100.7,100.7);


(lib.btn_cuales = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape.setTransform(134,28.9,1,1.204);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_1.setTransform(134,28.9,1,1.204);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_2.setTransform(134,28.9,1,1.204);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,268,57.8);


(lib.home = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAWBNIAAhTIgqAAIAABTIguAAIAAhYIggAAIBihBIBjBBIgeAAIAABYg");
	this.shape.setTransform(15.3,15.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaBeIAAhmIgyAAIAABmIg5AAIAAhsIgmAAIB3hPIB4BPIglAAIAABsg");
	this.shape_1.setTransform(15.3,15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[]},1).wait(1));

	// Capa 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AhzjEQhHAAAABMIAADyQAABLBHAAIDnAAQBHAAAAhLIAAjyQAAhMhHAAg");
	this.shape_4.setTransform(15.1,15.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhyDEQhIAAAAhKIAAjyQAAhMBIAAIDmAAQBHAAAABMIAADyQAABKhHAAg");
	this.shape_5.setTransform(15.1,15.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,31.8);


(lib.btnadelanteatras = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ABeidIi6AAQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(15.1,15.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhZAAIAAAAIB/hlIAAAnIA1AAIAAB9Ig1AAIAAAlIABAAIAAACg");
	this.shape_1.setTransform(13.2,15.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAhsAAIAAAAICABmIAAgCIgBAAIAAglIA1AAIAAh9Ig1AAIAAgng");
	this.shape_2.setTransform(15.1,15.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AhzjEQhHAAAABMIAADyQAABLBHAAIDnAAQBHAAAAhLIAAjyQAAhMhHAAg");
	this.shape_3.setTransform(15.1,15.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ah+AAIC1iNIAAAtIBIAAIAAC/IhIAAIAAAvg");
	this.shape_4.setTransform(12.7,17.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AhyDEQhIAAAAhKIAAjyQAAhMBIAAIDmAAQBHAAAABMIAADyQAABKhHAAgAiWAOIC1CPIAAgwIBIAAIAAi+IhIAAIAAgtg");
	this.shape_5.setTransform(15.1,15.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_6.setTransform(15.1,15.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAgAh4ALICRBzIAAgmIA6AAIAAiZIg6AAIAAglg");
	this.shape_7.setTransform(15.1,15.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhlAAICRhxIAAAkIA6AAIAACZIg6AAIAAAmg");
	this.shape_8.setTransform(13.2,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_6},{t:this.shape},{t:this.shape_1}]},1).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30.2,31.8);


(lib.balanza = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AAAm8QC4AACCCDQCDCCAAC3QAAC4iDCCQiCCDi4AAQi2AAiDiDQiCiCAAi4QAAi3CCiCQCDiDC2AAg");
	this.shape.setTransform(115.7,168,0.925,0.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ak5E6QiDiDAAi3QAAi3CDiCQCDiDC2AAQC4AACCCDQCDCCgBC3QABC3iDCDQiCCDi4AAQi2AAiDiDg");
	this.shape_1.setTransform(115.7,168,0.925,0.925);

	// cuerpo
	this.instance = new lib.cuerpo_balanza();
	this.instance.setTransform(115.7,191.2,0.925,0.925,0,0,0,79.7,100.8);

	this.addChild(this.instance,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(42,98,147.4,186.5);


(lib.Símbolo3 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Símbolo5();
	this.instance.setTransform(73.8,107.5,0.969,1,0,0,0,75.3,61.7);

	this.text = new cjs.Text("Días", "30px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 42;
	this.text.lineWidth = 149;
	this.text.setTransform(74.4,2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.1).p("AAOANIAFAEQACABABABIAGAFIgQgFAgjgaIACACIAXATIAYASAgqggIADADIAGAFIAXAhIATAIAAJATIADAAAAPATIgGgCAAcAYIgNgFAgKAMIgjgLIAGgeAgKAMIATAH");
	this.shape.setTransform(151.1,50.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().rs(["#FF0000","#000000"],[0,1],1,0.8,0,1,0.8,4.5).ss(0.1).p("AAEAEIAPAMAgOgLIgEgEAgOgLIASAP");
	this.shape_1.setTransform(149.5,48.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#010001").ss(1,2).p("AgkkAIBYBdIAAGiIgyghIgFgFAgxDQIAUgLAgVDMIABAAAgRDOIAAABAgxDQIAcgEAgNDSIAEAD");
	this.shape_2.setTransform(149,26.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2).p("ArQDjIAAnIIWaAFIAHHG");
	this.shape_3.setTransform(73.8,23);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#010001").ss(0.6,2).p("ALUqFIAAACAL/poIAATuI29AAAq+J3IgWAAArUJpIgVAAArpJRIgVAAALUqCIAAgBALUqCIAAAQIAAADArUJpIWoAAIAAzY");
	this.shape_4.setTransform(77.6,113.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("Aq+KSIAAgPIgWAAIAAgOIgVAAIAAgYIgVAAIAAzuIWVAEIAcgEIAEADIgHAgIAkALIAATYI2oAAIWoAAIAAzYIAVAGIAAABIACAAIARAFIgGgFIAJAAIAATug");
	this.shape_5.setTransform(77.6,112.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ALrEBIgGgCIgVgIIAAgRIAZAUIAGAFIADACIAGAFgALQD6IAAgDIAVAIIAAABgALJDeIgBgBIgHgEIgFgEIAAAAIgEgDIAEADIAUARIAPAMIAGAFIAEADIgZgUIAAAAIAAAAIgXgSIgCgCIgEgEIAAAAIgDgCIAAAAIgdAEIAVgLIgInFIAIHFI2igCIAAnIIWaAFIBbBdIAAGigAKtDvIAGggIAGAFIAXASIAAARIgXgjIAXAjIAAADgALQD3gALQDmg");
	this.shape_6.setTransform(77.9,26.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCFF00").s().p("AATAYIAEAAIANAFgAALAJIAGAAIAAAEgAgXgSIAGADIAHAFIAIAGIAAADgAgRgPIAHAFIAAAAgAgXgSIgEgEIAEADIAAABgAgfgZIgEgDIABAAIADADIAAAAIAEADIABACg");
	this.shape_7.setTransform(150.4,49.6);

	this.addChild(this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,154.3,178.5);


(lib.Símbolo1 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Símbolo4("synched",0);
	this.instance.setTransform(33.2,-14);

	this.instance_1 = new lib.Símbolo4("synched",0);
	this.instance_1.setTransform(5.2,-8.1);

	this.instance_2 = new lib.Símbolo4("synched",0);
	this.instance_2.setTransform(-22.9,1.5);

	this.instance_3 = new lib.Símbolo4("synched",0);
	this.instance_3.setTransform(-4.9,12);

	this.instance_4 = new lib.Símbolo4("synched",0);
	this.instance_4.setTransform(49.1,-5.2);

	this.addChild(this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,5.5,126.1,72);


(lib.pez2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.instance = new lib.burbuja();
	this.instance.setTransform(7.4,57,0.119,0.119,0,0,0,79.5,79.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:20.2,alpha:0},42).wait(59));

	// Capa 1
	this.instance_1 = new lib.pez1int();
	this.instance_1.setTransform(150,90,1,1,0,0,0,150,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(17).to({scaleX:0.76},13).to({scaleX:1},19).wait(1).to({scaleX:0.76},19).to({scaleX:1},13).wait(19));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2,53.8,120.8,72.5);


(lib.pez1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.instance = new lib.burbuja();
	this.instance.setTransform(7.4,57,0.119,0.119,0,0,0,79.5,79.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:20.2,alpha:0},100).wait(1));

	// Capa 1
	this.instance_1 = new lib.pez1int();
	this.instance_1.setTransform(150,90,1,1,0,0,0,150,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:150.1,regY:89.4,scaleX:0.8,rotation:-8.5,y:106.4},25).to({regX:150,regY:90,scaleX:1,rotation:0,y:90},24).to({scaleX:0.76},25).wait(1).to({scaleX:1},25).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2,53.8,120.8,72.5);


(lib._20peces = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.pez1();
	this.instance.setTransform(227.6,11.9,0.326,0.326,0,0,0,150.3,90.1);

	this.instance_1 = new lib.pez2();
	this.instance_1.setTransform(137.5,14.4,0.399,0.399,0,0,180,75.9,89.8);

	this.instance_2 = new lib.pez1();
	this.instance_2.setTransform(108.9,43.4,0.326,0.326,0,0,0,150.3,90.1);

	this.instance_3 = new lib.pez2();
	this.instance_3.setTransform(18.8,46,0.399,0.399,0,0,180,75.9,89.8);

	this.instance_4 = new lib.pez1();
	this.instance_4.setTransform(127.7,19.8,0.326,0.326,0,0,0,150.3,90.1);

	this.instance_5 = new lib.pez2();
	this.instance_5.setTransform(37.5,22.3,0.399,0.399,0,0,180,75.9,89.8);

	this.instance_6 = new lib.pez1();
	this.instance_6.setTransform(217.8,40.8,0.326,0.326,0,0,0,150.3,90.1);

	this.instance_7 = new lib.pez2();
	this.instance_7.setTransform(127.7,43.4,0.399,0.399,0,0,180,75.9,89.8);

	this.instance_8 = new lib.pez1();
	this.instance_8.setTransform(156.3,31.6,0.326,0.326,0,0,0,150.3,90.1);

	this.instance_9 = new lib.pez2();
	this.instance_9.setTransform(66.1,34.2,0.399,0.399,0,0,180,75.9,89.8);

	this.instance_10 = new lib.pez1();
	this.instance_10.setTransform(-3.5,42.6,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_11 = new lib.pez2();
	this.instance_11.setTransform(86.6,45.2,0.399,0.399,0,0,0,75.9,89.8);

	this.instance_12 = new lib.pez1();
	this.instance_12.setTransform(115.1,74.2,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_13 = new lib.pez2();
	this.instance_13.setTransform(205.3,76.7,0.399,0.399,0,0,0,75.9,89.8);

	this.instance_14 = new lib.pez1();
	this.instance_14.setTransform(96.4,50.5,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_15 = new lib.pez2();
	this.instance_15.setTransform(186.5,53.1,0.399,0.399,0,0,0,75.9,89.8);

	this.instance_16 = new lib.pez1();
	this.instance_16.setTransform(6.2,71.6,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_17 = new lib.pez2();
	this.instance_17.setTransform(96.4,74.1,0.399,0.399,0,0,0,75.9,89.8);

	this.instance_18 = new lib.pez1();
	this.instance_18.setTransform(67.8,62.4,0.326,0.326,0,0,180,150.3,90.1);

	this.instance_19 = new lib.pez2();
	this.instance_19.setTransform(157.9,64.9,0.399,0.399,0,0,0,75.9,89.8);

	this.addChild(this.instance_19,this.instance_18,this.instance_17,this.instance_16,this.instance_15,this.instance_14,this.instance_13,this.instance_12,this.instance_11,this.instance_10,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,224,91.3);


(lib.Símbolo7 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Símbolo2();
	this.instance.setTransform(757.5,93.5,0.742,0.752,0,0,0,77.5,93);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").p("EgyngIOIAAjhMBlPgAJIAADeEgyngIOIAAUHMAwGgACMA1JgAEIAA0N");
	this.shape.setTransform(324,86.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],269.6,13,0,269.6,13,274.9).s().p("AABAAIABAAIgDABIACgBg");
	this.shape_1.setTransform(641.1,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,255,0.114)").s().p("EgyngJ9MBlPgAMIAAUMMg1JAAFMgwGAACg");
	this.shape_2.setTransform(324,98);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(255,255,255,0)","rgba(204,204,204,0.298)"],[0,1],2.6,27.2,0,2.6,27.2,275).s().p("EgyngBqMBlPgAJIAADcMhlPAALg");
	this.shape_3.setTransform(324,22.4);

	this.instance_1 = new lib._20peces();
	this.instance_1.setTransform(352.4,112,1,1,0,0,0,112,45.6);

	this.instance_2 = new lib._20peces();
	this.instance_2.setTransform(191.4,106,1,1,0,0,0,112,45.6);

	this.instance_3 = new lib._20peces();
	this.instance_3.setTransform(525.5,108.8,1,1,0,0,0,112,45.6);

	this.shape_5 = new lib.comida();
	
	this.shape_5.setTransform(703,62);

	

	

	this.addChild(this.instance_3,this.instance_2,this.instance_1,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance,this.shape_5);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,814.8,163.5);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}