(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titulo']);
this.instance = new lib.imagen1();
	this.instance.setTransform(672.4,329.5,1,1,0,0,0,233,196.5);

	this.instance_1 = new lib.btn2();
	this.instance_1.setTransform(128.2,379.7);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn2(), 3);

	this.instance_2 = new lib.btn1();
	this.instance_2.setTransform(128.2,276.7);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.btn1(), 3);
   this.instance_2.on("click", function (evt) {
        putStage(new lib.frame3());
    });
    this.instance_1.on("click", function (evt) {
        putStage(new lib.frame4());
    });
	   this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame2());
    });
    
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.practica,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
        titulo2(this, txt['tit1'],"23px");
        
        this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(596,384.7);

	this.text_1 = new cjs.Text("54\n27", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(639.4,371.7);

	this.text_2 = new cjs.Text("72\n45", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(571.4,371.7);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.lineHeight = 32;
	this.text_3.setTransform(596,234.7);

	this.text_4 = new cjs.Text("61\n47", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 32;
	this.text_4.setTransform(639.4,221.7);

	this.text_5 = new cjs.Text("33\n19", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 32;
	this.text_5.setTransform(571.4,221.7);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 32;
	this.text_6.setTransform(266,384.7);

	this.text_7 = new cjs.Text("63\n27", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 32;
	this.text_7.setTransform(309.4,371.7);

	this.text_8 = new cjs.Text("21\n9", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 32;
	this.text_8.setTransform(241.4,371.7);

	this.text_9 = new cjs.Text("=", "20px Verdana");
	this.text_9.lineHeight = 32;
	this.text_9.setTransform(266,234.7);

	this.text_10 = new cjs.Text("28\n35", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 32;
	this.text_10.setTransform(309.4,221.7);

	this.text_11 = new cjs.Text("4\n5", "20px Verdana");
	this.text_11.lineHeight = 32;
	this.text_11.setTransform(235,221.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ASSrtIEdAAEghRgLtIEdAAEghRALuIEdAAASSLuIEdAAA2uLuIEdAAA2urtIEdAAAc1LuIEdAAAc1rtIEdAA");
	this.shape.setTransform(442.5,326.3-incremento);
        
 this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame2_1());
    });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.practica,this.shape,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit1'],"23px");
        
        this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(596,384.7);

	this.text_1 = new cjs.Text("54\n27", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(639.4,371.7);

	this.text_2 = new cjs.Text("72\n45", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(571.4,371.7);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.lineHeight = 32;
	this.text_3.setTransform(596,234.7);

	this.text_4 = new cjs.Text("61\n47", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 32;
	this.text_4.setTransform(639.4,221.7);

	this.text_5 = new cjs.Text("33\n19", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 32;
	this.text_5.setTransform(571.4,221.7);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 32;
	this.text_6.setTransform(266,384.7);

	this.text_7 = new cjs.Text("63\n27", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 32;
	this.text_7.setTransform(309.4,371.7);

	this.text_8 = new cjs.Text("21\n9", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 32;
	this.text_8.setTransform(241.4,371.7);

	this.text_9 = new cjs.Text("=", "20px Verdana");
	this.text_9.lineHeight = 32;
	this.text_9.setTransform(266,234.7);

	this.text_10 = new cjs.Text("28\n35", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 32;
	this.text_10.setTransform(309.4,221.7);

	this.text_11 = new cjs.Text("4\n5", "20px Verdana");
	this.text_11.lineHeight = 32;
	this.text_11.setTransform(235,221.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ASSrtIEdAAEghRgLtIEdAAEghRALuIEdAAASSLuIEdAAA2uLuIEdAAA2urtIEdAAAc1LuIEdAAAc1rtIEdAA");
	this.shape.setTransform(442.5,326.3-incremento);
        
 	this.instance = new lib.Path();
	this.instance.setTransform(1088.6,489.8,0.5,0.5,0,0,0,873.5,284.5);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.instance_1 = new lib.Path_1();
	this.instance_1.setTransform(378,398.4,0.484,0.484,0,0,0,98,103.8);
	this.instance_1.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.instance_2 = new lib.Path_1();
	this.instance_2.setTransform(378,248.4,0.484,0.484,0,0,0,98,103.8);
	this.instance_2.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);

	this.instance_3 = new lib.Path();
	this.instance_3.setTransform(1088.6,339.8,0.5,0.5,0,0,0,873.5,284.5);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.706)",7,7,15);
       
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.practica,this.shape,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
        titulo2(this, txt['tit2'],"23px");
        
       	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(335.5,454.7);

	this.text_1 = new cjs.Text("a\n17", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(379,441.7);

	this.text_2 = new cjs.Text("18\n51", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(311,441.7);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.lineHeight = 32;
	this.text_3.setTransform(335.5,364.7);

	this.text_4 = new cjs.Text("4\na", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 32;
	this.text_4.setTransform(379,351.7);

	this.text_5 = new cjs.Text("a\n64", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 32;
	this.text_5.setTransform(311,351.7);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 32;
	this.text_6.setTransform(335.5,274.7);

	this.text_7 = new cjs.Text("36\n15", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 32;
	this.text_7.setTransform(379,261.7);

	this.text_8 = new cjs.Text("24\na", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 32;
	this.text_8.setTransform(311.3,261.7);

	this.text_9 = new cjs.Text("=", "20px Verdana");
	this.text_9.lineHeight = 32;
	this.text_9.setTransform(335.5,184.7);

	this.text_10 = new cjs.Text("a\n9", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 32;
	this.text_10.setTransform(379,171.7);

	this.text_11 = new cjs.Text("4\na", "20px Verdana");
	this.text_11.lineHeight = 32;
	this.text_11.setTransform(304.5,171.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADD1FIEdAAADDnBIEdAAADDHCIEdAAADDVGIEdAAAnf1FIEdAAAnfnBIEdAAAnfHCIEdAAAnfVGIEdAA");
	this.shape.setTransform(347,336.3-incremento);
        
 this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame2_3());
    });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior,this.practica,this.shape,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit2'],"23px");
        
       	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(335.5,454.7);

	this.text_1 = new cjs.Text("a\n17", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(379,441.7);

	this.text_2 = new cjs.Text("18\n51", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(311,441.7);

	this.text_3 = new cjs.Text("=", "20px Verdana");
	this.text_3.lineHeight = 32;
	this.text_3.setTransform(335.5,364.7);

	this.text_4 = new cjs.Text("4\na", "20px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 32;
	this.text_4.setTransform(379,351.7);

	this.text_5 = new cjs.Text("a\n64", "20px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 32;
	this.text_5.setTransform(311,351.7);

	this.text_6 = new cjs.Text("=", "20px Verdana");
	this.text_6.lineHeight = 32;
	this.text_6.setTransform(335.5,274.7);

	this.text_7 = new cjs.Text("36\n15", "20px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 32;
	this.text_7.setTransform(379,261.7);

	this.text_8 = new cjs.Text("24\na", "20px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 32;
	this.text_8.setTransform(311.3,261.7);

	this.text_9 = new cjs.Text("=", "20px Verdana");
	this.text_9.lineHeight = 32;
	this.text_9.setTransform(335.5,184.7);

	this.text_10 = new cjs.Text("a\n9", "20px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 32;
	this.text_10.setTransform(379,171.7);

	this.text_11 = new cjs.Text("4\na", "20px Verdana");
	this.text_11.lineHeight = 32;
	this.text_11.setTransform(304.5,171.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADD1FIEdAAADDnBIEdAAADDHCIEdAAADDVGIEdAAAnf1FIEdAAAnfnBIEdAAAnfHCIEdAAAnfVGIEdAA");
	this.shape.setTransform(347,336.3-incremento);
	this.textb = new cjs.Text("a = 6", "20px Verdana");
	this.textb.lineHeight = 26;
	this.textb.setTransform(522.4,452.9);

	this.text_1b = new cjs.Text("a = 16", "20px Verdana");
	this.text_1b.lineHeight = 26;
	this.text_1b.setTransform(522.4,362.9);

	this.text_2b = new cjs.Text("a = 10", "20px Verdana");
	this.text_2b.lineHeight = 26;
	this.text_2b.setTransform(522.4,272.9);

	this.text_3b = new cjs.Text("a = 6", "20px Verdana");
	this.text_3b.lineHeight = 26;
	this.text_3b.setTransform(522.4,182.9);
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.siguiente,this.practica,this.shape,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.text_3b,this.text_2b,this.text_1b,this.textb);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
   
    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3'],"23px");
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#339900").s().p("AAWg1IAyBUIiPAXg");
	this.shape.setTransform(441.6,242.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#339900").s().p("AhHg1ICPAWIgyBVg");
	this.shape_1.setTransform(441.6,220);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#339900").s().p("AhHAfIAyhUIBdBrg");
	this.shape_2.setTransform(491.9,242.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#339900").s().p("AhHgfICPgWIhdBrg");
	this.shape_3.setTransform(491.9,220);

	this.text = new cjs.Text("=", "25px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 33;
	this.text.setTransform(465.3,211.1+incremento);

	this.text_1 = new cjs.Text("c\nd", "25px Verdana", "#CC0000");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 33;
	this.text_1.setTransform(513,192.9+incremento);

	this.text_2 = new cjs.Text("a\nb", "25px Verdana", "#0066FF");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 33;
	this.text_2.setTransform(413,192.9+incremento);

	this.instance = new lib.btn12();
	this.instance.setTransform(636,388.5,1,1,0,0,0,79,45.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn12(), 3);

	this.instance_1 = new lib.btn11();
	this.instance_1.setTransform(296,388.5,1,1,0,0,0,79,45.5);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn11(), 3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#339900").ss(1,1,1).p("AkkCRIEkiRIkkiQAEliQIklCQIElCR");
	this.shape_4.setTransform(467.1,231);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#CC0000").ss(1,1,1).p("AikAAIFJAA");
	this.shape_5.setTransform(515.5,228);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#0066FF").ss(1,1,1).p("AiVAAIErAA");
	this.shape_6.setTransform(416,228);
        
        this.instance_1.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.instance.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.shape_6,this.shape_5,this.shape_4,this.instance_1,this.instance,this.text_2,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      this.instance = new lib.animacion1();
	this.instance.setTransform(483.9,321.8,1,1,0,0,0,403.9,101.6);


         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente, this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      this.instance = new lib.animacion2();
	this.instance.setTransform(483.9,321.8,1,1,0,0,0,403.9,101.6);


         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente, this.instance );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit4']);
this.instance = new lib.pizarra();
	this.instance.setTransform(440.8,168.5,0.614,0.614);

	this.instance_1 = new lib.btn22();
	this.instance_1.setTransform(165.2,323.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn22(), 3);

	this.instance_2 = new lib.btn23();
	this.instance_2.setTransform(165.2,412.4);
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.btn23(), 3);

	this.instance_3 = new lib.btn21();
	this.instance_3.setTransform(165.2,235.5);
	new cjs.ButtonHelper(this.instance_3, 0, 1, 2, false, new lib.btn21(), 3);
         this.instance_3.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
         this.instance_2.on("click", function (evt) {
            putStage(new lib.frame4_2());
        });
         this.instance_1.on("click", function (evt) {
            putStage(new lib.frame4_3());
        });

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.instance_3,this.instance_2,this.instance_1,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 1);
        	this.instance = new lib.animacion31();
	this.instance.setTransform(81,71.9);

        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame4_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 1);
        	this.instance = new lib.animacion33();
	this.instance.setTransform(81,71.9);

        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame4_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 1);
        	this.instance = new lib.animacion32();
	this.instance.setTransform(81,71.9);

        
         this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4());
        });

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.cerrar,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._01_OPT = function() {
	this.initialize(img._01_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,600);


(lib.foto_entrada_opt = function() {
	this.initialize(img.foto_entrada_opt);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,525,582);




(lib.pizarra = function() {
	this.initialize(img.pizarra);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,709,546);


(lib.texto33 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Cálculo de la media proporcional\n\nCuando se conocen dos de los valores de una proporción y los valores que faltan están repetidos, se habla de calcular la media proporcional.\n\nSe procede a su cálculo, aplicando la propiedad fundamental de las proporciones:", "bold 20px Verdana");
	this.text.lineHeight = 32;
	this.text.lineWidth = 789;
var html = createDiv(txt['text5'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, -608);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,793,210.1);


(lib.texto32 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Cálculo de la tercera proporcional\n\nCuando se conocen todos los valores de una proporción, excepto uno y además dos de los valores conocidos son iguales, se habla de calcular la tercera proporcional.\n\nSe procede a su cálculo aplicando la propiedad fundamental de las proporciones:", "bold 20px Verdana");
	this.text.lineHeight = 32;
	this.text.lineWidth = 789;
var html = createDiv(txt['text4'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, -608);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,793,240.4);


(lib.texto31 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Cálculo de la cuarta proporcional\n\nCuando se conocen todos los valores de una proporción, excepto uno, se habla de calcular la cuarta proporcional a los valores conocidos.\n\nSe procede a su cálculo aplicando la propiedad fundamental de las proporciones, según la cual el producto de medios es igual al producto de extremos:", "bold 23px Verdana");
	this.text.lineHeight = 29;
	this.text.lineWidth = 789;
var html = createDiv(txt['text3'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, -608);
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,793,244.1);


(lib.solucion = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("SOLUCIÓN", "bold 15px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 228;
	this.text.setTransform(114,6.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape.setTransform(115.7,17,0.6,0.707,0,0,0,-0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_1.setTransform(115.7,17,0.6,0.707);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_2.setTransform(115.7,17,0.6,0.707,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,232,34);


(lib.practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("PRACTICA", "bold 15px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 228;
	this.text.setTransform(114,6.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape.setTransform(115.7,17,0.6,0.707,0,0,0,-0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_1.setTransform(115.7,17,0.6,0.707);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-134,-24,268,48,6.3);
	this.shape_2.setTransform(115.7,17,0.6,0.707,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,232,34);


(lib.objeto334 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(37.5,13);

	this.text_1 = new cjs.Text("12\n24", "bold 20px Verdana", "#FF6600");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("6\n12", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(13.3,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,0,99.3,58.6);


(lib.objeto331 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("a\n24", "bold 20px Verdana", "#FF6600");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("6\na", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96.8,58.6);


(lib.objeto324 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("9\n27", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("3\n9", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(13.3,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,98.3,58.6);


(lib.objeto321 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("9\na", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("3\n9", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96,58.6);




(lib.objeto22 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("3 · 14 ≠ 6 · 12", "20px Verdana");
	this.text.lineHeight = 32;

	
	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,153.7,28.3);


(lib.objeto21 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("12\n14", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("3\n6", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6-incremento);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96.8,58.6);


(lib.objeto12 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("5 · 24 = 6 · 20 = 120", "20px Verdana");
	this.text.lineHeight = 32;

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,222.2,28.3);


(lib.objeto11 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("20\n24", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("5\n6", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6-incremento);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96.8,58.6);


(lib.imagen1 = function() {
	this.initialize();

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8jesMAAAg9XMA5HAAAMAAAA9Xg");
	mask.setTransform(283.1,196.5);

	// Capa 2
	this.instance = new lib.foto_entrada_opt();
	this.instance.setTransform(102.3,-4.4,0.692,0.692);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(102.3,-4.4,363.5,403);


(lib.frase2 = function() {
	this.initialize();

	// Capa 1
	

	this.text_2 = new cjs.Text("El producto de medios no es igual al producto de extremos,        y        no\n\nforman una proporción, no son fracciones equivalentes.", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 804;
	this.text_2.setTransform(0,12.7);
 var html = createDiv(txt['text2'], "Verdana", "20px", '810px', '40px', "20px", "185px", "left");
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(0, 13-608);
	this.addChild(this.text_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,808,101.6);


(lib.frase1 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("El producto de medios es igual al producto de extremos,       y       forman una\n\nproporción de razón de 120, son fracciones equivalentes.", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.lineWidth = 804;
	this.text.setTransform(0,12.7);
  var html = createDiv(txt['text1'], "Verdana", "20px", '810px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(0, 13-608);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,808,101.6);


(lib.flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAcA/IBYg0IkuAAIAAgVIEuAAIhYg0IA1AAIBqA+IhqA/g");
	this.shape.setTransform(18.7,6.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.4,12.7);


(lib.Path = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F09122","#DF081F"],[0,1],22.6,52.5,-22,-52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
	this.shape.setTransform(102.6,102.6,1,1,0,0,0,0.8,-0.3);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(57.5,58.2,88.7,89.5);


(lib.Path_1 = function() {
	this.initialize();

	// Capa 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#0B6635","#95C030"],[0,1],34.5,77.7,-16.7,-68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
	this.shape_1.setTransform(97.9,103.7,0.5,0.5);

	this.addChild(this.shape_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(53.3,56.2,89.4,95.1);


(lib.btn12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape.setTransform(77.6,45.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape_1.setTransform(77.6,45.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).to({state:[]},1).wait(1));

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(66.1,28.9+incremento);

	this.text_1 = new cjs.Text("12\n14", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(109.5,16+incremento);

	this.text_2 = new cjs.Text("3\n6", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(35.1,16+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_2,p:{color:"#000000"}},{t:this.text_1,p:{color:"#000000"}},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text_2,p:{color:"#FFFFFF"}},{t:this.text_1,p:{color:"#FFFFFF"}},{t:this.text,p:{color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));

	// Capa 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AKynGI1jAAQhkAAAABkIAALFQAABkBkAAIVjAAQBkAAAAhkIAArFQAAhkhkAAg");
	this.shape_2.setTransform(79,45.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_3.setTransform(79,45.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_4.setTransform(79,45.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_5.setTransform(79,45.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_4},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,158,91);


(lib.btn11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(66.1,28.9+incremento);

	this.text_1 = new cjs.Text("20\n24", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(109.5,16+incremento);

	this.text_2 = new cjs.Text("5\n6", "20px Verdana");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(35.1,16+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape.setTransform(77.6,45.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape_1.setTransform(77.6,45.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text_2,p:{color:"#000000"}},{t:this.text_1,p:{color:"#000000"}},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text_2,p:{color:"#FFFFFF"}},{t:this.text_1,p:{color:"#FFFFFF"}},{t:this.text,p:{color:"#FFFFFF"}}]},2).to({state:[]},1).wait(1));

	// Capa 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AKynGI1jAAQhkAAAABkIAALFQAABkBkAAIVjAAQBkAAAAhkIAArFQAAhkhkAAg");
	this.shape_2.setTransform(79,45.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_3.setTransform(79,45.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_4.setTransform(79,45.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AqxHGQhjAAgBhjIAArFQABhjBjgBIViAAQBlABAABjIAALFQAABjhlAAg");
	this.shape_5.setTransform(79,45.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_4},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,158,91);


(lib.btn23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Cálculo de la media proporcional", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Cálculo de la tercera proporcional", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Cálculo de la cuarta proporcional", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 234;
	this.text.setTransform(35,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(36.3,10,1,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(36.3,10,1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(36.3,10,1,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.6,-13.9,242,48);


(lib.btn2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Encontrar el término desconocido de una proporción", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 290;
	this.text.setTransform(63,-12.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(64.8,10,1.235,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(64.8,10,1.235,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(64.8,10,1.235,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.5,-13.9,298.7,48);


(lib.btn1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.text = new cjs.Text("Comprobar una proporción", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 282;
	this.text.setTransform(63,-2.3+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape.setTransform(64.8,10,1.235,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_1.setTransform(64.8,10,1.235,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#000000").ss(1,1,1).rr(-121,-15,242,30,6);
	this.shape_2.setTransform(64.8,10,1.235,1.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.5,-13.9,298.7,48);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-6,-16.6,1.247,1.197);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AhcidQg6AAAAA8IAADDQAAA8A6AAIC6AAQA5AAAAg8IAAjDQAAg8g5AAg");
	this.shape.setTransform(0,5.2,1.247,1.197);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhcCeQg5AAgBg8IAAjDQABg8A5AAIC5AAQA5AAABA8IAADDQgBA8g5AAg");
	this.shape_1.setTransform(0,5.2,1.247,1.197);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.shape,p:{scaleX:1.412,scaleY:1.356,y:5.3}},{t:this.text,p:{scaleX:1.412,scaleY:1.356,x:-8.5,y:-19.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.shape,p:{scaleX:1.247,scaleY:1.197,y:5.2}},{t:this.text,p:{scaleX:1.247,scaleY:1.197,x:-6,y:-16.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.5,-16.7,38.7,40.9);


(lib.btn_anterior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.objeto333 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("144 = 12", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(105.2,13);

	this.text_1 = new cjs.Text("a =", "bold 20px Verdana", "#FF6600");
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(54.2,13);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,28.7,1,1,0,0,0,18.7,6.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Aj/AvIA2CBIAZlfIGwAA");
	this.shape.setTransform(123.3,23);

	this.addChild(this.shape,this.instance,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,5.4,206.4,35.9);


(lib.objeto332 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("6 · 24 = a2", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(55.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,172,28.3);


(lib.objeto323 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("= 27", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(181.2,13);

	this.text_1 = new cjs.Text("9 · 9\n3", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 32;
	this.text_1.setTransform(135.7,0);

	this.text_2 = new cjs.Text("a =", "bold 20px Verdana", "#FF6600");
	this.text_2.lineHeight = 32;
	this.text_2.setTransform(54.2,13);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,28.7,1,1,0,0,0,18.7,6.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AlpAAILTAA");
	this.shape.setTransform(140,29.6);

	this.addChild(this.shape,this.instance,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,237,58.6);


(lib.objeto322 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("3 · a = 9 · 9", "20px Verdana");
	this.text.lineHeight = 32;
	this.text.setTransform(55.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,184.1,28.3);



(lib.objeto315 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("4\n12", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("7\n21", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(13.3,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,0,97.8,58.6);


(lib.objeto311 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("4\n12", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("7\na", "20px Verdana");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96.8,58.6);


(lib.flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAcA/IBYg0IkuAAIAAgVIEuAAIhYg0IA1AAIBqA+IhqA/g");
	this.shape.setTransform(18.7,6.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.4,12.7);


(lib.objeto314 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("a = 21", "bold 20px Verdana", "#FF6600");
	this.text.lineHeight = 26;
	this.text.setTransform(54.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,130.6,28.3);


(lib.objeto313 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("= 21", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(181.2,13);

	this.text_1 = new cjs.Text("7 · 12\n4", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(135.7,0);

	this.text_2 = new cjs.Text("a =", "bold 20px Verdana", "#FF6600");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(54.2,13);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,28.7,1,1,0,0,0,18.7,6.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AlpAAILTAA");
	this.shape.setTransform(140,29.6);

	this.addChild(this.shape,this.instance,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,234.2,58.6);


(lib.objeto312 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("12 · 7 = 4 · a", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(55.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,196.8,28.3);

(lib.animacion33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 5
	this.instance = new lib.texto33();
	this.instance.setTransform(396.4,122,1,1,0,0,0,396.4,122);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},24).wait(147));

	// Capa 4
	this.instance_1 = new lib.objeto331();
	this.instance_1.setTransform(204.1,302.1,1,1,0,0,0,48.1,29.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(36).to({_off:false},0).to({alpha:1},23).wait(116));

	// Capa 3
	this.instance_2 = new lib.objeto332();
	this.instance_2.setTransform(374,300,1,1,0,0,0,97.7,14.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(70).to({_off:false},0).to({alpha:1},24).wait(81));

	// Capa 2
	this.instance_3 = new lib.objeto333();
	this.instance_3.setTransform(579.4,302.1,1,1,0,0,0,117.1,29.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(107).to({_off:false},0).to({alpha:1},26).wait(42));

	// Capa 6
	this.instance_4 = new lib.objeto334();
	this.instance_4.setTransform(394.1,382.1,1,1,0,0,0,48.1,29.3);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(146).to({_off:false},0).to({alpha:1},28).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 5
	this.instance = new lib.texto32();
	this.instance.setTransform(396.4,122,1,1,0,0,0,396.4,122);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({alpha:1},17).wait(124));

	// Capa 4
	this.instance_1 = new lib.objeto321();
	this.instance_1.setTransform(184.1,302.1,1,1,0,0,0,48.1,29.3);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30).to({_off:false},0).to({alpha:1},18).wait(96));

	// Capa 3
	this.instance_2 = new lib.objeto322();
	this.instance_2.setTransform(354,300,1,1,0,0,0,97.7,14.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(57).to({_off:false},0).to({alpha:1},18).wait(69));

	// Capa 2
	this.instance_3 = new lib.objeto323();
	this.instance_3.setTransform(589.4,302.1,1,1,0,0,0,117.1,29.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(86).to({_off:false},0).to({alpha:1},19).wait(39));

	// Capa 6
	this.instance_4 = new lib.objeto324();
	this.instance_4.setTransform(394.1,382.1,1,1,0,0,0,48.1,29.3);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(116).to({_off:false},0).to({alpha:1},18).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.texto31();
	this.instance.setTransform(396.4,122,1,1,0,0,0,396.4,122);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({alpha:1},14).wait(137));

	// Capa 4
	this.instance_1 = new lib.objeto311();
	this.instance_1.setTransform(84.1,302.1,1,1,0,0,0,48.1,29.3);
	this.instance_1.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AneAAIEdAAADDAAIEdAA");
	this.shape.setTransform(84,302.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AgrAwQgKgKAAgPQAAgMAFgHQAFgGAKgFQAKgEAOgCIAcgDIAAAAQAAgJgHgDQgHgEgNAAQgJAAgJADIgPAEIgDAAIAAgaIASgDQANgDAMABQAcAAAOAJQANAJAAAUIAABIIgjAAIAAgLIgHAFIgIAFIgIAEIgNABQgPAAgLgKgAAEAFIgLACQgFACgDADQgDADAAAFIABAFIADAFIAFADIAJABQAEgBAGgBQAFgCAEgEIAAgXIgPACg");
	this.shape_1.setTransform(49.8,319.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AFDDgIAAgVIAVgRIATgSQASgSAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgKADQgLADgJAHIgBAAIAAgVQAHgDALgDQAMgDALAAQAWAAANALQAMALAAASQAAAJgCAHQgCAHgEAGQgEAHgFAFIgMANIgWAUIgVASIBOAAIAAARgADPDgIAAgPIAfAAIAAhiIgfAAIAAgNIAOgBQAHgBADgCQAFgCACgEQADgEAAgGIAPAAIAACDIAeAAIAAAPgAhlAPIAAgPIBxAAIAAAPgAhlgYIAAgQIBxAAIAAAQgAFBhNIAAgpIhGAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAApgAEJiGIA4AAIAAhBgAmXhNIBGiBIhTAAIAAgRIBjAAIAAAWIhCB8g");
	this.shape_2.setTransform(87.1,302.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},30).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},14).wait(113));

	// Capa 3
	this.instance_2 = new lib.objeto312();
	this.instance_2.setTransform(254,300,1,1,0,0,0,97.7,14.2);
	this.instance_2.alpha = 0;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("AgrAwQgKgKAAgPQAAgMAFgHQAFgGAKgEQAKgFAOgCIAcgCIAAgBQAAgJgHgEQgHgDgNAAQgJAAgJADIgPAFIgDAAIAAgbIASgDQANgCAMgBQAcAAAOAKQANAJAAAUIAABJIgjAAIAAgMIgHAFIgIAFIgIAEIgNABQgPAAgLgKgAAEAFIgLACQgFACgDADQgDADAAAFIABAFIADAFIAFACIAJABQAEAAAGgCQAFgCAEgDIAAgXIgPACg");
	this.shape_3.setTransform(343.8,302.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AKyBKIAAgpIhGAAIAAgXIBHhQIASAAIAABXIAVAAIAAAQIgVAAIAAApgAJ5ARIA5AAIAAg/gADRBKIBGh/IhTAAIAAgRIBkAAIAAAWIhCB6gAiPBKIAAgVIAVgRIATgSQATgSAHgJQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgKADQgLADgJAHIgCAAIAAgVQAIgDALgDQALgDALAAQAXAAANALQAMALAAASQAAAJgCAHQgCAHgFAGQgDAFgFAFIgMANIgWAUIgVASIBOAAIAAARgAkCBKIAAgPIAfAAIAAhgIgfAAIAAgNIAOgBQAGgBAEgCQAFgCACgEQACgEABgGIAPAAIAACBIAeAAIAAAPgAqBBJIBXg0IkvAAIAAgVIEvAAIhXg0IA0AAIBqA+IhqA/gAGTAmIAAgPIBzAAIAAAPgANDAYIAAgaIAXAAIAAAagAA+AYIAAgaIAYAAIAAAagAGTgBIAAgPIBzAAIAAAPg");
	this.shape_4.setTransform(242.1,300.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},54).to({state:[{t:this.shape_4},{t:this.shape_3}]},15).wait(88));

	// Capa 2
	this.instance_3 = new lib.objeto313();
	this.instance_3.setTransform(489.4,302.1,1,1,0,0,0,117.1,29.3);
	this.instance_3.alpha = 0;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AlpAAILTAA");
	this.shape_5.setTransform(512.2,302.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF6600").s().p("AgrAwQgKgKAAgPQAAgMAFgHQAFgGAKgEQAKgFAOgCIAcgCIAAgBQAAgJgHgEQgHgDgNAAQgJAAgJADIgPAFIgDAAIAAgbIASgDQANgCAMgBQAcAAAOAKQANAJAAAUIAABJIgjAAIAAgMIgHAFIgIAFIgIAEIgNABQgPAAgLgKgAAEAFIgLACQgFACgDADQgDADAAAFIABAFIADAFIAFACIAJABQAEAAAGgCQAFgCAEgDIAAgXIgPACg");
	this.shape_6.setTransform(434.8,302.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("ADwDhIAAgpIhGAAIAAgWIBHhSIASAAIAABZIAWAAIAAAPIgWAAIAAApgAC4CpIA4AAIAAhCgAQuA0IAAgPIAfAAIAAhgIgfAAIAAgNIAOgBQAGgBAEgCQAFgCACgEQACgEABgGIAPAAIAACBIAeAAIAAAPgAOkA0IAAgVIAUgRIATgQQATgSAHgLQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgKADQgLADgKAHIgBAAIAAgVQAIgDALgDQAMgDALAAQAWAAANALQAMALAAASQAAAJgCAHQgCAHgFAGQgDAHgFAFIgMANIgXASIgUASIBOAAIAAARgAukAzIBXgzIkvAAIAAgVIEvAAIhXg1IA0AAIBqBAIhqA9gALCAQIAAgPIB0AAIAAAPgAlmAQIAAgPIBzAAIAAAPgALCgXIAAgPIB0AAIAAAPgAlmgXIAAgPIBzAAIAAAPgAGchMIAAgUIAWgSIATgRQASgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAGgEAMgCQALgDALAAQAXAAAMALQANAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgNANIgVAUIgVASIBOAAIAAAQgAEphMIAAgPIAfAAIAAhhIgfAAIAAgNIAOgBQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACDIAeAAIAAAPgAgphMIBEiAIhRAAIAAgRIBhAAIAAAWIg/B7gACXh+IAAgbIAYAAIAAAbg");
	this.shape_7.setTransform(487.2,302.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},77).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},16).wait(64));

	// Capa 7
	this.instance_4 = new lib.objeto314();
	this.instance_4.setTransform(685.4,300,1,1,0,0,0,63.1,14.2);
	this.instance_4.alpha = 0;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF6600").s().p("AlPBBQgLgJAAgPQAAgNAGgHQAFgIAKgEQAKgFAOgCIAegCIAAAAQAAgIgHgDQgIgDgOgBQgJAAgKAEIgOAEIgDAAIAAgbIASgCQAMgDANAAQAeAAANAKQAOAIAAAVIAABIIgjAAIAAgLIgHAEIgIAGIgLADIgMABQgQAAgKgKgAkfAWIgMADQgGABgCADQgDAEAAAEIAAAGIADAEIAGADIAKABQAFAAAFgCQAGgCAEgDIAAgYIgQACgAD6BIIAAgaIAeAAIAAhKIgeAAIAAgYIANgBQAHgBAEgBQAFgDADgEQACgEAAgGIAhAAIAAB2IAeAAIAAAagABkBIIAAgYIAagUIAVgTQAMgJAFgIQAFgJAAgIQAAgKgGgGQgHgFgMAAQgJAAgKADQgKAEgIAGIgDAAIAAggQAHgDANgDQAOgDANAAQAcAAAOAMQAOALAAAUQAAAOgHANQgHAKgOANIgSAQIgMAJIBBAAIAAAcg");
	this.shape_8.setTransform(714,300.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AjsA/IBYg0IkvAAIAAgVIEvAAIhYg0IA1AAIBqA+IhqA/gAFRAcIAAgPIBzAAIAAAPgAFRgLIAAgQIBzAAIAAAQg");
	this.shape_9.setTransform(667.5,301.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},104).to({state:[{t:this.shape_9},{t:this.shape_8}]},16).wait(37));

	// Capa 6
	this.instance_5 = new lib.objeto315();
	this.instance_5.setTransform(394.1,382.1,1,1,0,0,0,48.1,29.3);
	this.instance_5.alpha = 0;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape_10.setTransform(394,382.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF6600").s().p("AAaBJIAAgZIAfAAIAAhKIgfAAIAAgZIAOgBQAGAAAEgCQAGgDACgEQADgEgBgFIAhAAIAAB2IAeAAIAAAZgAh6BJIAAgXIAbgVIAVgSQALgLAFgHQAFgIAAgJQAAgKgGgFQgHgFgLAAQgKAAgKADQgJAEgJAFIgDAAIAAgfQAHgDANgEQAOgCANAAQAcAAAOALQAPALAAAVQgBAOgGANQgIAKgOANIgSAPIgMAJIBBAAIAAAcg");
	this.shape_11.setTransform(361.2,397.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AE8DgIAAgVIAUgRIATgSQATgSAHgLQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgLADQgKADgKAHIgBAAIAAgVQAIgDALgDQAMgDALAAQAVAAAOALQAMALAAASQAAAJgCAHQgCAHgEAGQgEAHgFAFIgMANIgXAUIgUASIBOAAIAAARgADIDgIAAgPIAeAAIAAhiIgeAAIAAgNIANgBQAIgBADgCQAFgCACgEQACgEABgGIAPAAIAACDIAeAAIAAAPgAhtAPIAAgPIByAAIAAAPgAhtgYIAAgQIByAAIAAAQgAE5hNIAAgpIhFAAIAAgXIBHhSIASAAIAABZIAVAAIAAAQIgVAAIAAApgAEBiGIA4AAIAAhBgAmQhNIBGiBIhTAAIAAgRIBkAAIAAAWIhDB8g");
	this.shape_12.setTransform(397.9,382.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},130).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]},20).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);

(lib.animacion2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.objeto21();
	this.instance.setTransform(248.7,29.3,1,1,0,0,0,48.1,29.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({alpha:1},17).wait(87));

	// Capa 4
	this.instance_1 = new lib.flecha();
	this.instance_1.setTransform(349.3,27.1,1,1,0,0,0,18.7,6.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(33).to({_off:false},0).to({alpha:1},10).wait(68));

	// Capa 3
	this.instance_2 = new lib.objeto22();
	this.instance_2.setTransform(508.2,27.2,1,1,0,0,0,111.1,14.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(53).to({_off:false},0).to({alpha:1},13).wait(45));

	// Capa 2
	this.instance_3 = new lib.frase2();
	this.instance_3.setTransform(403.9,167.6,1,1,0,0,0,403.9,35.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(80).to({_off:false},0).to({alpha:1},24).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.animacion1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.objeto11();
	this.instance.setTransform(248.7,29.3,1,1,0,0,0,48.1,29.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({alpha:1},17).wait(87));

	// Capa 4
	this.instance_1 = new lib.flecha();
	this.instance_1.setTransform(349.3,27.1,1,1,0,0,0,18.7,6.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(33).to({_off:false},0).to({alpha:1},10).wait(68));

	// Capa 3
	this.instance_2 = new lib.objeto12();
	this.instance_2.setTransform(508.2,27.2,1,1,0,0,0,111.1,14.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(53).to({_off:false},0).to({alpha:1},13).wait(45));

	// Capa 2
	this.instance_3 = new lib.frase1();
	this.instance_3.setTransform(403.9,167.6,1,1,0,0,0,403.9,35.6);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(80).to({_off:false},0).to({alpha:1},24).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);

(lib.objeto324 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("9\n27", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("3\n9", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(13.3,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,98.3,58.6);


(lib.objeto321 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("9\na", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("3\n9", "20px Verdana");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96,58.6);


(lib.flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAcA/IBYg0IkuAAIAAgVIEuAAIhYg0IA1AAIBqA+IhqA/g");
	this.shape.setTransform(18.7,6.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.4,12.7);


(lib.objeto323 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("= 27", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(181.2,13);

	this.text_1 = new cjs.Text("9 · 9\n3", "20px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(135.7,0);

	this.text_2 = new cjs.Text("a =", "bold 20px Verdana", "#FF6600");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(54.2,13);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,28.7,1,1,0,0,0,18.7,6.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AlpAAILTAA");
	this.shape.setTransform(140,29.6);

	this.addChild(this.shape,this.instance,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,237,58.6);


(lib.objeto322 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("3 · a = 9 · 9", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(55.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,184.1,28.3);


(lib.animacion32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.texto32();
	this.instance.setTransform(396.4,122,1,1,0,0,0,396.4,122);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({alpha:1},17).wait(124));

	// Capa 4
	this.instance_1 = new lib.objeto321();
	this.instance_1.setTransform(184.1,302.1,1,1,0,0,0,48.1,29.3);
	this.instance_1.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape.setTransform(184,302.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AgrAwQgKgKAAgPQAAgMAFgHQAFgGAKgFQAKgEAOgCIAcgDIAAAAQAAgJgHgDQgHgEgNAAQgJAAgJADIgPAEIgDAAIAAgaIASgDQANgDAMABQAcAAAOAJQANAJAAAUIAABIIgjAAIAAgLIgHAFIgIAFIgIAEIgNABQgPAAgLgKgAAEAFIgLACQgFACgDADQgDADAAAFIABAFIADAFIAFADIAJABQAEgBAGgBQAFgCAEgEIAAgXIgPACg");
	this.shape_1.setTransform(217.5,319.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AlwDiIgIgCIAAgSIABAAIAIADIALABQAWAAAMgNQAMgNACgXQgJAGgIACQgIACgKAAQgIAAgHgBQgIgCgHgFQgJgGgEgJQgEgKgBgMQAAgXAPgOQAPgOAVAAQAKAAAKAEQAJADAGAGQAIAJAFAMQAFANAAAUQAAATgFAQQgEAPgJALQgJALgOAHQgNAGgRAAIgKgBgAlrBkQgHAJgBAQQAAAJADAGQADAGAGAEQAEADAGABIALABQAIAAAIgCQAHgCAHgEIAAgEIAAgFQAAgPgCgJQgDgJgGgFQgFgFgFgCQgFgCgGAAQgOAAgJAJgAhEAPIAAgPIByAAIAAAPgAhEgYIAAgQIByAAIAAAQgAE2hLIgIgCIAAgSIABAAIAIADIAMABQAWAAAMgNQANgNABgXQgJAGgIACQgIACgKAAQgJAAgHgBQgHgCgHgFQgJgGgEgJQgFgKABgMQAAgXAOgOQAPgOAVAAQALAAAJAEQAIADAHAGQAIAJAFAMQAFANgBAUQABATgFAQQgEAPgJALQgJALgNAHQgNAGgTAAIgKgBgAE9jJQgJAJAAAQQABAJACAGQACAGAHAEQAEADAFABIANABQAHAAAHgCQAIgCAHgEIAAgEIAAgFQAAgPgCgJQgEgJgFgFQgEgFgGgCQgFgCgHAAQgOAAgHAJgAluhNQgMgDgHgDIAAgVIACAAQAHAGAMADQALAEAKAAQAGAAAIgCQAGgCAFgEQAFgFACgFQABgFAAgIQABgIgDgFQgDgFgEgDQgEgDgGgBQgHgBgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgHAAgMQAAgFgCgEQgDgEgDgCIgJgEIgLgBQgKAAgLAEQgKADgJAGIgBAAIAAgVIASgGQAMgDALAAQAKAAAJACQAIACAGAFQAIAEADAHQADAGAAAJQAAAMgIAKQgJAJgLACIAAABIALAEQAFACAFAEQAFAEACAGQADAHAAAKQABAKgEAIQgDAIgHAGQgHAHgKAEQgLADgLAAQgMAAgMgDg");
	this.shape_2.setTransform(183.8,302.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},30).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},18).wait(96));

	// Capa 3
	this.instance_2 = new lib.objeto322();
	this.instance_2.setTransform(354,300,1,1,0,0,0,97.7,14.2);
	this.instance_2.alpha = 0;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("AgrAwQgKgKAAgPQAAgMAFgHQAFgGAKgEQAKgFAOgCIAcgCIAAgBQAAgJgHgEQgHgDgNAAQgJAAgJADIgPAFIgDAAIAAgbIASgDQANgCAMgBQAcAAAOAKQANAJAAAUIAABJIgjAAIAAgMIgHAFIgIAFIgIAEIgNABQgPAAgLgKgAAEAFIgLACQgFACgDADQgDADAAAFIABAFIADAFIAFACIAJABQAEAAAGgCQAFgCAEgDIAAgXIgPACg");
	this.shape_3.setTransform(353.9,302.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AM2BLIgJgCIAAgTIABAAIAJADIALABQAWAAAMgNQAMgNADgWQgKAFgIACQgIADgJAAQgJAAgIgCQgHgCgHgFQgJgGgEgHQgFgJAAgNQAAgWAPgOQAPgOAVAAQALAAAIADQAKADAGAHQAJAIAEANQAEANABAUQgBARgEAPQgEAQgJALQgJALgOAGQgNAGgSAAIgJAAgAM8gxQgIAIAAAQQAAAKACAFQADAGAGAEQAFACAEABIAMABQAIAAAIgCQAIgCAHgCIAAgEIAAgFQAAgQgEgJQgDgJgFgFQgEgEgGgCQgFgCgHAAQgOAAgHAJgAHgBLIgIgCIAAgTIABAAIAIADIAMABQAWAAAMgNQANgNACgWQgKAFgIACQgIADgJAAQgJAAgIgCQgHgCgHgFQgJgGgEgHQgFgJABgNQAAgWAOgOQAPgOAVAAQAKAAAJADQAJADAHAHQAJAIAEANQAEANAAAUQAAARgEAPQgEAQgJALQgJALgNAGQgOAGgSAAIgKAAgAHngxQgJAIABAQQgBAKADAFQACAGAHAEQAFACAEABIAMABQAIAAAHgCQAIgCAIgCIAAgEIAAgFQAAgQgEgJQgDgJgFgFQgFgEgFgCQgFgCgHAAQgOAAgHAJgAkmBIQgLgCgIgEIAAgUIACAAQAIAFALAEQALADAKAAQAGAAAIgCQAGgCAFgEQAFgEACgFQACgFgBgIQAAgIgCgFQgDgFgEgDQgEgDgGgBQgHgCgHAAIgJAAIAAgOIAHAAQAPAAAJgGQAJgGAAgMQAAgFgDgEQgCgEgDgDIgJgDIgLgBQgKAAgLADQgJADgKAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAJACQAIACAGAEQAIAFADAGQADAHABAJQAAAMgJAJQgIAJgMACIAAACIALADQAFACAFACQAFAEADAHQACAGAAAKQABAKgEAIQgDAJgHAGQgHAHgKADQgKADgMAAQgMAAgMgDgAquBIIBYg1IkwAAIAAgUIEwAAIhYg0IA1AAIBqA9IhqBAgADuAlIAAgQIBzAAIAAAQgAKdAWIAAgZIAYAAIAAAZgAhsAWIAAgZIAYAAIAAAZgADugCIAAgQIBzAAIAAAQg");
	this.shape_4.setTransform(346.6,300.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},57).to({state:[{t:this.shape_4},{t:this.shape_3}]},18).wait(69));

	// Capa 2
	this.instance_3 = new lib.objeto323();
	this.instance_3.setTransform(589.4,302.1,1,1,0,0,0,117.1,29.3);
	this.instance_3.alpha = 0;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AlpAAILTAA");
	this.shape_5.setTransform(612.2,302.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF6600").s().p("AtmBBQgLgJAAgPQAAgNAGgHQAFgIAKgEQAKgFAOgCIAegCIAAAAQAAgIgHgDQgIgDgOgBQgJAAgKAEIgOAEIgDAAIAAgbIASgCQAMgDANAAQAeAAANAKQAOAIAAAVIAABIIgjAAIAAgLIgHAEIgIAGIgLADIgMABQgQAAgKgKgAs2AWIgMADQgGABgCADQgDAEAAAEIAAAGIADAEIAGADIAKABQAFAAAFgCQAGgCAEgDIAAgYIgQACgAMGBIIBFhzIhLAAIAAgcIByAAIAAAcIhCBzgAJ1BIIAAgYIAagUIAVgTQAMgJAFgIQAFgJAAgIQAAgKgGgGQgHgFgMAAQgJAAgKADQgKAEgIAGIgDAAIAAggQAHgDANgDQAOgDANAAQAcAAAOAMQAOALAAAUQAAAOgHANQgHAKgOANIgSAQIgMAJIBBAAIAAAcg");
	this.shape_6.setTransform(617.5,300.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AFqDgQgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKADgKAGIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAKQgIAJgMACIAAABIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDgAsBAyIBYgzIkvAAIAAgWIEvAAIhYg0IA1AAIBqA/IhqA+gANmAPIAAgPIBzAAIAAAPgAjCAPIAAgPIBzAAIAAAPgANmgYIAAgQIBzAAIAAAQgAjCgYIAAgQIBzAAIAAAQgAIShLIgIgCIAAgSIABAAIAIADIAMABQAWAAAMgNQAMgNACgXQgJAGgIACQgIACgKAAQgJAAgHgBQgHgCgHgFQgJgGgEgJQgFgKAAgMQAAgXAPgOQAPgOAVAAQAKAAAJAEQAJADAHAGQAIAJAFAMQAEANAAAUQAAATgEAQQgEAPgJALQgJALgOAHQgNAGgSAAIgKgBgAIYjJQgIAJAAAQQAAAJADAGQACAGAHAEQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgPgDgJQgDgJgFgFQgFgFgFgCQgFgCgHAAQgOAAgIAJgAC9hLIgIgCIAAgSIABAAIAIADIAMABQAWAAAMgNQAMgNACgXQgJAGgIACQgIACgKAAQgJAAgHgBQgHgCgHgFQgJgGgEgJQgFgKAAgMQAAgXAPgOQAPgOAVAAQAKAAAJAEQAJADAHAGQAIAJAFAMQAEANAAAUQAAATgEAQQgEAPgJALQgJALgOAHQgNAGgSAAIgKgBgADDjJQgIAJAAAQQAAAJADAGQACAGAHAEQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgPgDgJQgDgJgFgFQgFgFgFgCQgFgCgHAAQgOAAgIAJgAF6h/IAAgcIAYAAIAAAcg");
	this.shape_7.setTransform(570.8,302.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},86).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},19).wait(39));

	// Capa 6
	this.instance_4 = new lib.objeto324();
	this.instance_4.setTransform(394.1,382.1,1,1,0,0,0,48.1,29.3);
	this.instance_4.alpha = 0;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape_8.setTransform(394,382.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("AASBJIBFhzIhLAAIAAgcIByAAIAAAdIhBBygAh9BJIAAgXIAagVIAVgSQAMgLAFgHQAFgIAAgJQAAgKgGgFQgHgFgMAAQgJAAgKADQgKAEgIAFIgDAAIAAgfQAHgDAOgEQANgCAOAAQAbAAAOALQAOALAAAVQABAOgIANQgGAKgPANIgSAPIgMAJIBBAAIAAAcg");
	this.shape_9.setTransform(428.2,397.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AlpDiIgIgCIAAgSIABAAIAIADIALABQAWAAAMgNQANgNACgXQgKAGgIACQgIACgJAAQgJAAgHgBQgIgCgHgFQgJgGgEgJQgEgKAAgMQAAgXAOgOQAPgOAVAAQALAAAJAEQAJADAGAGQAJAJAEAMQAFANAAAUQAAATgFAQQgEAPgJALQgJALgNAHQgNAGgSAAIgKgBgAljBkQgIAJAAAQQAAAJACAGQADAGAGAEQAFADAFABIAMABQAHAAAIgCQAIgCAHgEIAAgEIAAgFQAAgPgDgJQgDgJgGgFQgEgFgGgCQgFgCgGAAQgOAAgIAJgAhLAPIAAgPIByAAIAAAPgAhLgYIAAgQIByAAIAAAQgAEvhLIgIgCIAAgSIABAAIAIADIAMABQAWAAAMgNQAMgNACgXQgJAGgIACQgIACgKAAQgJAAgHgBQgHgCgHgFQgJgGgEgJQgFgKAAgMQAAgXAPgOQAPgOAVAAQAKAAAJAEQAJADAHAGQAIAJAFAMQAEANAAAUQAAATgEAQQgEAPgJALQgJALgOAHQgNAGgSAAIgKgBgAE1jJQgIAJAAAQQAAAJADAGQACAGAHAEQAEADAFABIAMABQAIAAAHgCQAIgCAHgEIAAgEIAAgFQAAgPgDgJQgDgJgFgFQgFgFgFgCQgFgCgHAAQgOAAgIAJgAlnhNQgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKADgKAGIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAKQgIAJgMACIAAABIALAEQAGACAEAEQAFAEADAGQADAHAAAKQAAAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDg");
	this.shape_10.setTransform(394.5,382.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},116).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},18).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);

(lib.objeto334 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(37.5,13);

	this.text_1 = new cjs.Text("12\n24", "bold 20px Verdana", "#FF6600");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("6\n12", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(13.3,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,0,99.3,58.6);


(lib.objeto331 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("=", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(36.5,13);

	this.text_1 = new cjs.Text("a\n24", "bold 20px Verdana", "#FF6600");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(80,0);

	this.text_2 = new cjs.Text("6\na", "20px Verdana");
	this.text_2.lineHeight = 26;
	this.text_2.setTransform(5.5,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape.setTransform(48,29.6);

	this.addChild(this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,96.8,58.6);


(lib.flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAcA/IBYg0IkuAAIAAgVIEuAAIhYg0IA1AAIBqA+IhqA/g");
	this.shape.setTransform(18.7,6.4);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,37.4,12.7);


(lib.objeto333 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("144 = 12", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(105.2,13);

	this.text_1 = new cjs.Text("a =", "bold 20px Verdana", "#FF6600");
	this.text_1.lineHeight = 26;
	this.text_1.setTransform(54.2,13);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,28.7,1,1,0,0,0,18.7,6.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Aj/AvIA2CBIAZlfIGwAA");
	this.shape.setTransform(123.3,23);

	this.addChild(this.shape,this.instance,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,5.4,206.4,35.9);


(lib.objeto332 = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("6 · 24 = a2", "20px Verdana");
	this.text.lineHeight = 26;
	this.text.setTransform(55.2,0);

	this.instance = new lib.flecha();
	this.instance.setTransform(18.7,15.8,1,1,0,0,0,18.7,6.4);

	this.addChild(this.instance,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,172,28.3);


(lib.animacion33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 5
	this.instance = new lib.texto33();
	this.instance.setTransform(396.4,122,1,1,0,0,0,396.4,122);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},24).wait(147));

	// Capa 4
	this.instance_1 = new lib.objeto331();
	this.instance_1.setTransform(204.1,302.1,1,1,0,0,0,48.1,29.3);
	this.instance_1.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ADDAAIEdAAAnfAAIEdAA");
	this.shape.setTransform(204,302.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("Al+DHQgKgKAAgPQAAgMAGgHQAFgHAJgFQALgFANgCIAegCIAAAAQAAgKgGgDQgIgDgPAAQgJgBgJADIgPAFIgDAAIAAgaIASgDQANgDANAAQAdAAAOAJQANAJAAAVIAABKIgjAAIAAgLIgGAEIgIAGIgLADIgNABQgPAAgLgKgAlNCcIgNADQgFABgDADQgDAEAAAEIABAGIADAEIAFADIAKABQAFAAAGgCQAFgCAEgDIAAgYIgPACgAEmhmQgLgJAAgPQAAgMAGgIQAFgIAKgEQAKgEAOgDIAegCIAAgBQAAgJgHgDQgHgEgPAAQgJAAgKAEIgOAEIgDAAIAAgbIASgCQANgDAMAAQAeAAANAKQAOAIAAAVIAABKIgjAAIAAgLIgHAEIgIAFIgKAEIgNABQgPAAgLgKgAFXiRIgNADQgFABgDADQgDAEAAAEIAAAGIAEAEIAFADIAKABQAFAAAGgCQAFgCAEgEIAAgXIgPACg");
	this.shape_1.setTransform(203.7,304.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AF/DhIAAgpIhFAAIAAgWIBGhSIASAAIAABZIAWAAIAAAPIgWAAIAAApgAFHCpIA4AAIAAhCgADDDhIAAgUIAVgSIATgRQASgTAHgLQAHgKAAgMQAAgLgHgHQgIgGgNgBQgJAAgKAEQgLADgJAGIgBAAIAAgVQAHgDALgCQAMgEALAAQAWAAANAMQAMAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAFIgMAOIgWAUIgVARIBOAAIAAARgAhmAQIAAgPIBxAAIAAAPgAhmgXIAAgQIBxAAIAAAQgAmGhNQgJgDgGgGQgJgIgEgNQgFgOAAgTQAAgTAEgPQAEgPAKgMQAIgKAOgHQANgGASAAIAKABIAIABIAAATIgBAAIgIgDQgGgBgGAAQgVAAgMANQgNANgCAWQAJgEAIgDQAHgDALAAQAJAAAHACQAHABAIAGQAIAFAFAKQAEAJAAANQAAAWgOAOQgPAOgVAAQgLAAgJgEgAmEiXQgHACgIAEIAAAEIAAAGQAAAPADAIQADAKAGAFQAEAEAGACQAFACAGAAQAOAAAIgIQAIgJAAgQQAAgKgCgGQgDgFgGgFQgFgDgFgBIgMgBQgIAAgHACg");
	this.shape_2.setTransform(207.2,302.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},36).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},23).wait(116));

	// Capa 3
	this.instance_2 = new lib.objeto332();
	this.instance_2.setTransform(374,300,1,1,0,0,0,97.7,14.2);
	this.instance_2.alpha = 0;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("AhdBLQgLgKAAgPQAAgMAFgHQAFgIALgEQAJgFAOgCIAfgCIAAgBQgBgJgGgCQgIgDgPAAQgIAAgKADIgOADIgEAAIAAgZIASgDQANgCAMgBQAeAAAOAKQAMAJAAASIAABLIghAAIAAgMIgHAFIgJAFIgKAEIgNABQgPAAgKgKgAgtAgIgMACQgGACgCADQgEADAAAFIABAFIADAFIAFACIAKABQAGAAAFgCQAGgCAEgDIAAgXIgQACgAAfALIAAgNIARgNIANgNQAIgHADgFQADgGABgFQgBgHgEgEQgEgDgHAAQgHAAgGACIgMAHIgCAAIAAgVIANgFQAJgCAJAAQASABAJAHQAJAIAAANQABAJgFAIQgEAIgKAJIgLAKIgJAGIArAAIAAAQg");
	this.shape_3.setTransform(434.8,299.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhEBIQgJgDgHgHQgJgIgEgNQgEgOgBgTQAAgRAEgPQAFgPAJgLQAJgLANgHQAOgGASAAIAJABIAIABIAAATIgBAAIgIgDQgFgBgGAAQgWAAgMANQgNANgCAXQAJgFAIgDQAHgDALAAQAJAAAIACQAGACAIAFQAJAGAEAHQADAJAAANQAAAWgNAOQgPAOgVAAQgLAAgIgDgAhDgBQgHABgIADIAAAFIAAAFQAAAPAEAJQADAJAFAFQAEAEAGACQAFACAGAAQAPAAAHgIQAJgJgBgQQABgJgDgGQgDgGgGgFQgEgBgGgBIgLgBQgIAAgIACgAGsBIIAAgpIhGAAIAAgWIBHhQIASAAIAABXIAWAAIAAAPIgWAAIAAApgAF0AQIA4AAIAAhAgADvBIIAAgUIAVgSIAUgRQASgRAHgKQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAGgEAMgCQALgDALAAQAXAAANALQAMAKAAATQAAAIgCAHQgCAIgFAGQgDAFgFAFIgNANIgVAUIgVASIBOAAIAAAQgAnXBIIBYg1IkwAAIAAgUIEwAAIhYg0IA1AAIBpA9IhpBAgAI8AlIAAgQIB0AAIAAAQgABpAWIAAgZIAYAAIAAAZgAI8gCIAAgQIB0AAIAAAQg");
	this.shape_4.setTransform(345.1,300.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},70).to({state:[{t:this.shape_4},{t:this.shape_3}]},24).wait(81));

	// Capa 2
	this.instance_3 = new lib.objeto333();
	this.instance_3.setTransform(579.4,302.1,1,1,0,0,0,117.1,29.3);
	this.instance_3.alpha = 0;

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("Aj/AvIA2CBIAZlfIGwAA");
	this.shape_5.setTransform(585.5,295.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF6600").s().p("ArOBBQgLgJAAgPQAAgNAFgHQAFgIALgEQAJgFAOgCIAfgCIAAAAQgBgIgHgDQgHgDgOgBQgJAAgKAEIgOAEIgDAAIAAgbIASgCQAMgDAMAAQAfAAANAKQAOAIAAAVIAABIIgjAAIAAgLIgIAEIgIAGIgKADIgMABQgQAAgKgKgAqeAWIgMADQgGABgCADQgDAEgBAEIABAGIADAEIAFADIALABQAFAAAFgCQAFgCAFgDIAAgYIgQACgAJoBIIAAgYIAagUIAVgTQAMgJAFgIQAFgJAAgIQAAgKgGgGQgHgFgMAAQgJAAgKADQgKAEgIAGIgDAAIAAggQAHgDAOgDQANgDAOAAQAbAAAOAMQAOALAAAUQABAOgIANQgGAKgOANIgTAQIgMAJIBBAAIAAAcgAHiBIIAAgaIAfAAIAAhKIgfAAIAAgYIAOgBQAGgBAEgBQAGgDACgEQADgEgBgGIAhAAIAAB2IAeAAIAAAag");
	this.shape_6.setTransform(592.4,300.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AI7BJIAAgqIhFAAIAAgWIBGhQIASAAIAABXIAVAAIAAAPIgVAAIAAAqgAIDAQIA4AAIAAhAgAG8BJIAAgqIhFAAIAAgWIBGhQIASAAIAABXIAWAAIAAAPIgWAAIAAAqgAGEAQIA4AAIAAhAgAELBJIAAgPIAeAAIAAhgIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQADgEAAgHIAPAAIAACCIAeAAIAAAPgApmBIIBXg0IkvAAIAAgVIEvAAIhXg0IA0AAIBqA9IhqBAgALMAlIAAgPIBzAAIAAAPgAgoAlIAAgPIBxAAIAAAPgALMgCIAAgQIBzAAIAAAQgAgogCIAAgQIBxAAIAAAQg");
	this.shape_7.setTransform(545.4,300.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},107).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},26).wait(42));

	// Capa 6
	this.instance_4 = new lib.objeto334();
	this.instance_4.setTransform(394.1,382.1,1,1,0,0,0,48.1,29.3);
	this.instance_4.alpha = 0;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("AnfAAIEdAAADDAAIEdAA");
	this.shape_8.setTransform(394,382.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF6600").s().p("AlCDhIAAgYIAbgUIAVgSQALgMAFgIQAFgJAAgIQAAgKgGgFQgGgGgMAAQgJAAgKAEQgKAEgJAFIgDAAIAAggQAHgDAOgDQANgDAOAAQAbAAAOAMQAPAKAAAVQAAAPgHAMQgHAMgOAOIgSAPIgNAJIBBAAIAAAcgAnIDhIAAgZIAfAAIAAhNIgfAAIAAgYIAOgBQAGgBAEgCQAGgCACgEQADgEAAgGIAgAAIAAB5IAeAAIAAAZgAFXhMIAAgYIAagUIAVgTQAMgLAFgIQAFgJAAgIQAAgKgGgGQgHgFgMAAQgJAAgKADQgKAEgIAGIgDAAIAAggQAHgDANgDQAOgDANAAQAcAAAOAMQAOALAAAUQAAAOgHANQgHAMgOANIgSAQIgMAJIBBAAIAAAcgADRhMIAAgaIAeAAIAAhMIgeAAIAAgYIANgBQAHgBAEgBQAFgDADgEQACgEAAgGIAhAAIAAB4IAeAAIAAAag");
	this.shape_9.setTransform(395.4,382.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AF4DhIAAgpIhFAAIAAgWIBGhSIASAAIAABYIAVAAIAAAQIgVAAIAAApgAFACoIA4AAIAAhBgAC8DhIAAgVIAVgRIATgRQASgTAHgLQAHgKAAgMQAAgLgHgHQgIgGgNgBQgJAAgLADQgKAEgKAGIgBAAIAAgVQAIgDALgCQALgEAMAAQAVABANAKQANALAAATQAAAIgCAHQgCAHgEAHQgEAGgFAFIgMAOIgXAUIgUASIBOAAIAAAQgAhkAQIAAgPIByAAIAAAPgAhkgXIAAgQIByAAIAAAQgAl/hMQgJgDgGgHQgIgIgFgNQgFgOAAgTQAAgTAFgPQADgPAKgMQAIgLAOgGQAOgGARAAIAKABIAIABIAAATIgBAAIgIgDQgGgCgFAAQgWAAgMAOQgMANgCAXQAIgGAIgCQAHgDALAAQAKAAAGACQAIACAHAFQAIAFAFAKQAEAJABANQAAAWgPAOQgPAOgVAAQgLAAgJgDgAl9iXQgHACgHAEIgBAFIAAAEQAAAQAEAIQADAKAFAFQAFAEAFACQAFACAGAAQAOAAAJgIQAHgJABgQQAAgJgDgHQgDgFgGgFQgFgDgFgBIgLgBQgJAAgHACg");
	this.shape_10.setTransform(398,382.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},146).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]},28).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}