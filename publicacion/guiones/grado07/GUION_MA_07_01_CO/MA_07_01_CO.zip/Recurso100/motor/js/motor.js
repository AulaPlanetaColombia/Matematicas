Motor = new function()
{
	this.fons = "";
	this.inicis = new Array();
	this.respostes = new Array();
	this.solucions = new Array();
	this.inputs = new Array();
	this.imagen = false;
	this.ampliacion = false;
	this.zoom = false;
	
	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 350;
	//final
	this.PREG_FINAL_X_PADDING = 650 ;
	
	this.RESP_HEIGHT = 25;
	this.RESP_WIDTH = 275; 
	this.RESP_INNER_HEIGHT = 58;
	this.RESP_INNER_WIDTH = 248; 
	
	//line
	this.LINE_X = 625;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	this.IMG = "data/imagenes/";
	
	this.ponerContenedor = function(contenedorMotor) {
	  //alert("Estoy caminando!");
	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			
			Motor.datosXML = new datosMotor();
			Motor.datosXML.imagen = $(xml).find('imagen').text();
			Motor.datosXML.ampliacion = $(xml).find('ampliacion').text();
			
			$(xml).find('respuesta').each(function(index) {
				//debugger;

			  	var rest = new respuesta();
				rest.text = $(this).attr('contestacion');
				rest.orden = $(this).attr('orden');
				rest.id = index;
			  	Motor.datosXML.respuestas.push(rest);

			});
			
			//console.log(Motor.datosXML);
	       	Motor.inicializarEstructura();
	       	Contenedor.crearPaginacio();

		});
	}
	this.inicializarEstructura = function(estado) {
		
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.deleteInputs();
		Motor.cargarDatos();
	}
	this.estaCompletado = function(){
	  for (key in Motor.inicis) {
			if( Motor.inicis[key].resposta == null)
			{
				return false;
			}
		}
		return true;
	};
	
	this.getEstado = function(){
		var estado = new Array();
		for( var key1 in Motor.inputs ){
		   	estado.push( $(Motor.inputs[key1].htmlElement).val().trim() );
	   	}
		
		return estado.join("|");
	}
	
	this.revisar = function(){
		if(this.estado != "")
		{
			if( this.estado.indexOf("[") >= 0 )
			{
				var datos = this.estado.substring(1, this.estado.length-1).split("][");
				Contenedor.timeRevision = datos[0];
				var estado = datos[1].split("|");
			}else{
				var estado = this.estado.split("|");
			}
			
			for(var key in estado)
			{
				if(estado[key].trim() != ""){
					$( Motor.inputs[key].htmlElement ).val( estado[key] ) ;
				}
			}
			
		}
	}
	
	this.validar = function() {
		var total = 0;
	  	for(var i = 0; i< Motor.datosXML.respuestas.length; i++){
	   		
	   		var respuestaCorrecta = Motor.datosXML.respuestas[i].text;
			var respuestaReal = $(Motor.inputs[i].htmlElement).val();

			if( Motor.compareResults( respuestaCorrecta, respuestaReal ) )
			{
				total++;
				Motor.inicis[i].correcte();
			}else{
				Motor.inicis[i].erronia();
			}
	   		
		}
		return total.toString() +  "/" + Motor.inicis.length.toString();
	};
	this.compareResults = function( textoCorrecto, textoIntroducido ){
		
		var modo = "";
				
		modo |= CorrectorTexto.MODO_CI;
		modo |= CorrectorTexto.MODO_NOPUNCT
		modo |= CorrectorTexto.MODO_NOENDPUNCT;
		
		return CorrectorTexto.esValido(textoIntroducido, textoCorrecto, modo);

	};
	this.hideDomObjects = function(){
		for (key in Motor.inputs) {
		  	// desactivem listeners de comportament dels inputs
		  	Motor.inputs[key].visible = false;
		}
	}
	this.showDomObjects = function(){
		for (key in Motor.inputs) {
		  	// desactivem listeners de comportament dels inputs
		  	Motor.inputs[key].visible = true;
		}
	}
	this.obtenerEstado = function(){
	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
		for (key in Motor.inputs) {
		  	// activem listeners de comportament dels inputs
		  	$(Motor.inputs[key].htmlElement).prop("readonly", false);
		}
	}
	this.desactivar = function() {
		for (key in Motor.inputs) {
		  	// desactivem listeners de comportament dels inputs
		  	$(Motor.inputs[key].htmlElement).prop("readonly", true);
		}
	};
	this.numPaginas = function(){
		return 1;
	};
	this.ponerPagina = function(pag) {

	};
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.recolocar();
	  	this.solucionar();
		this.desactivar();	
		
	};
	this.recolocar = function(){

	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
	  	for(var i = 0; i< Motor.datosXML.respuestas.length; i++){
	   		
			Motor.inicis[i].removeError();
	   		if(Motor.inicis[i].error) Motor.solucions[i].visible = true;
		}
	}
	this.obtenerTipoEjercicio = function() {

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		
		this.createImage();
	    this.drawNumeros();
	    this.drawInicis();
	    this.drawSolucions();
	    this.drawInputs();
	    
	    Main.stage.addChild( this.contenedor);
	    
    }
    this.createImage = function(){
	    
	    // get imagen
	    var img = new Image();
		img.onload = function () 
		{
		   	Motor.imagen = new createjs.Bitmap(this);
			Motor.imagen.x = 25;
			Motor.imagen.y = Motor.INITIAL_Y+50;
			//escalem imatges
			Motor.imagen.scaleX =  300 / this.width;
			Motor.imagen.scaleY =  300 / this.width;

			//mascara de cantonades arrodonides
			Motor.imagen.mask = new createjs.Shape();
			Motor.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 300, this.height * 300 / this.width, 10);
			Motor.imagen.mask.x = 25;
		 	Motor.imagen.mask.y =  Motor.INITIAL_Y+50;
			Motor.imagen.on("click", Motor.zooming );
			Motor.imagen.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
			Motor.imagen.on("mouseout", function(evt){ document.body.style.cursor='default'; });
			
			Motor.contenedor.addChild( Motor.imagen);
			
			// boton de ampliacion
			Motor.zoom = new createjs.Bitmap(pppPreloader.from("module", 'motor/images/ico_zoom.png'));
			Motor.zoom.x = 285;
			Motor.zoom.y = Motor.INITIAL_Y+310;
			Motor.contenedor.addChild( Motor.zoom);
			Motor.zoom.on("click", Motor.zooming );
			Motor.zoom.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
			Motor.zoom.on("mouseout", function(evt){ document.body.style.cursor='default'; });
		};
		img.src = pppPreloader.from("data", this.IMG + Motor.datosXML.imagen);//this.IMG + Motor.datosXML.imagen;
		
		// imagen ampliada
	    Motor.ampliacion = new Ampliacion();
	    Motor.ampliacion.contenedor.x = 0;
		Motor.ampliacion.contenedor.y = 0;
		Motor.ampliacion.contenedor.alpha = 0;
		Main.stage.addChild( Motor.ampliacion.contenedor);
    }
    this.zooming = function(evt){
		if( evt.primary ){
	    	Motor.hideDomObjects();
	    	Main.stage.setChildIndex ( Motor.ampliacion.contenedor, Main.stage.getNumChildren () - 1 );
	    	createjs.Tween.get(Motor.ampliacion.contenedor).to({alpha:1}, 500, createjs.Ease.circOut);
	    }
    	//Motor.ampliacion.contenedor.visible = true;
    }

    this.drawNumeros = function()
    {   
		Motor.numeros = new Array();
		var respuestas = Motor.datosXML.respuestas;
		var numresp = respuestas.length;
    	//dibuixem numeros
    	for(var i = 0 ; i < numresp; i++)
		{
			//creem numero
	       	var num = new Numero( i + 1 );
	        num.contenedor.x = 375 ;
	        num.contenedor.y = this.INITIAL_Y + ( this.RESP_HEIGHT + 20 ) * i + 75  + i * ( (this.RESP_HEIGHT  + 20) * ( 6 - respuestas.length) ) / (respuestas.length-1); 
			num.idNumero = i;
	        this.contenedor.addChild( num.contenedor );

	        //guardem marc inicial en un array per despres treballar em ells
	        Motor.numeros.push(num);
    	}
    }

    this.drawInicis = function()
    {
    	Motor.inicis = new Array();
    	var respuestas = Motor.datosXML.respuestas;
    	var numresp = respuestas.length;
    	//dibuixem caixa
    	for(var i = 0 ; i < numresp; i++)
    	{
    	
    		var inici = new BaseResposta(i,this.RESP_WIDTH, this.RESP_HEIGHT , 5);
	        inici.contenedor.x = this.PREG_X_PADDING + this.PREG_INICI_X_PADDING + 40;
	        inici.contenedor.y = this.INITIAL_Y + ( this.RESP_HEIGHT + 20 ) * i + 78+ i * ( (this.RESP_HEIGHT  + 20) * ( 6 - respuestas.length) ) / (respuestas.length-1); 
	        inici.idResposta = i;

	        this.contenedor.addChild( inici.contenedor );
	        //guardem marc inicial en un array per despres treballar em ells
	        Motor.inicis.push(inici);
    	}
    }
    
    this.drawSolucions = function()
    {
    	Motor.solucions = new Array();
    	var respuestas = Motor.datosXML.respuestas;
    	var numresp = respuestas.length;
    	//dibuixem caixa
    	for(var i = 0 ; i < numresp; i++)
    	{
    		var text = new createjs.RichText();
			text.font = (Contenedor.datosXML.plataforma.grado == 1)? "16px Arial" : "14px Arial" ;
			text.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14 ;
			text.color = "#E2011B";
			text.text = respuestas[i].text;
			text.x = this.PREG_X_PADDING + this.PREG_INICI_X_PADDING + this.RESP_WIDTH  + 50;
			text.y = this.INITIAL_Y +( this.RESP_HEIGHT + 20 ) * i  + 83+ i * ( (this.RESP_HEIGHT  + 20) * ( 6 - respuestas.length) ) / (respuestas.length-1); 
			text.lineWidth = 305;
			text.lineHeight = 22;
			text.mouseEnabled = false;
			text.visible = false;
			
	        this.contenedor.addChild( text);
	        //guardem marc inicial en un array per despres treballar em ells
	        Motor.solucions.push(text);
    	}
    }
    
    this.drawInputs = function(){
    	Motor.inputs = new Array();
    	var respuestas = Motor.datosXML.respuestas;
    	var numresp = respuestas.length;
    	//dibuixem caixa
    	for(var i = 0 ; i < numresp; i++)
    	{
	    	//$('<input type="text" id="input'+index+'"/>').appendTo($("#mediaHolder"));
			var $input = $('<input type="text" id="input'+i+'" class="input"/>');
		    //$input.tabindex = i+1;
			$("#mediaHolder").append($input);
			
			var inputDOM = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
			
			inputDOM.element_x = this.PREG_X_PADDING + this.PREG_INICI_X_PADDING + 45;
			inputDOM.element_y =  this.INITIAL_Y + ( this.RESP_HEIGHT + 20 ) * i + 81+ i * ( (this.RESP_HEIGHT  + 20) * ( 6 - respuestas.length) ) / (respuestas.length-1); ;
			inputDOM.element_width = this.RESP_WIDTH - 10;
			inputDOM.element_height = this.RESP_HEIGHT - 4;
			inputDOM.fontsize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14 ;
			
			inputDOM.x = inputDOM.element_x;
			inputDOM.y = inputDOM.element_y;
			$(inputDOM.htmlElement).css("width", inputDOM.element_width);
			$(inputDOM.htmlElement).css("height", inputDOM.element_height );
			$(inputDOM.htmlElement).click(Motor.select);
			
			var index = Main.navegador.split(' ')[0].indexOf("IE");
		    var mobil = Main.mobil;
			if(index > -1 && mobil =="Tablet"){
		       $input.focusout(function(event){ $("body").focus(); });
		      $(inputDOM.htmlElement).click(Motor.select);
		    }
			
			this.contenedor.addChild( inputDOM );
			Motor.inputs.push( inputDOM );
		}
		
	    //$("#input0").focus();
		//this.desactivar();
	
	}
	this.select = function(){
		$(this).blur().focus();
	}
    
    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}


}