function BaseResposta(_index, _width, _height, _radius) {
  
  this.resposta  = null;
  this.error = false;
  this.index = _index;
  this.width = _width;
  this.height = _height;
  this.radius = _radius;
  this.idResposta = 0;
  
  this.base = new createjs.Shape();
  
  this.contenedor = new createjs.Container();
  this.dibuixa();
}

BaseResposta.prototype.setReposta = function(_resposta){
  this.resposta = _resposta;
  this.resposta.index = this.index;
  //this.contenedor.addChild( this.resposta.contenedor );
}

BaseResposta.prototype.dibuixa = function() {
  
  this.base.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.graphics.beginStroke("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.mouseEnabled = false;
  this.contenedor.addChild( this.base );
  
}

BaseResposta.prototype.hideBounds = function() {
  
  this.base.graphics.clear();
}
BaseResposta.prototype.erronia = function(){
	this.error = true;
	this.base.graphics.clear();
	this.base.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius); 
	this.base.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);

}
BaseResposta.prototype.correcte = function(){
	this.error = false;
	this.base.graphics.clear();
	this.base.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
	this.base.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);
}
BaseResposta.prototype.removeError = function(){
	if(this.error)
	{
		this.base.graphics.clear();
		this.base.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
  		this.base.graphics.beginStroke("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
	}
}


function Numero( num ) {
	//console.log(pregunta.text);
  	this.texte = "0"+num;
  	this.index = 0;
  	this.idNumero = num;
  	
  	this.fons = new createjs.Shape();	
	this.text = new createjs.Text();	
	this.contenedor = new createjs.Container();
  	this.dibuixa();
}
Numero.prototype.dibuixa = function() {
	this.fons.graphics.beginFill("#fff").drawRoundRect( 0, 0, 32, 32, 5);
	
	this.text.font = (Contenedor.datosXML.plataforma.grado == 1)? "20px Arial" : "18px Arial" ;
	this.text.color = "#F39613";
	this.text.text = this.texte ;
	this.text.x = 5;
	this.text.y = 4 ;
	this.text.mouseEnabled = false;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.text );
}


function Ampliacion()
{
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, Main.stage_width, Main.stage_height, 5);
	this.fons.alpha = 0.60;
	
	this.contenedor = new createjs.Container();
	this.contenedor.addChild(this.fons);
	
	var img = new Image();
	var amplia = this;
	
	this.imagen = "";
	img.onload = function () {

	   	amplia.imagen = new createjs.Bitmap(this);
		
		
		amplia.imagen.scaleX =  500 / this.height;
		amplia.imagen.scaleY =  500 / this.height;
		
		amplia.imagen.x = (Main.stage_width - (this.width * 500 / this.height))/2;
		amplia.imagen.y = 50;
		
		//mascara de cantonades arrodonides
		amplia.imagen.mask = new createjs.Shape();
		amplia.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 500, this.height * 500 / this.width, 10);
		amplia.imagen.mask.x = (Main.stage_width - (this.width * 500 / this.height))/2;
	 	amplia.imagen.mask.y = 50;
		
		amplia.contenedor.addChild( amplia.imagen);
	};
	img.src = pppPreloader.from("data", Motor.IMG + Motor.datosXML.ampliacion);//Motor.IMG + Motor.datosXML.ampliacion;
		
	
	this.contenedor.on("click", this.tancar);
	this.contenedor.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.contenedor.on("mouseout", function(evt){ document.body.style.cursor='default'; });
}
Ampliacion.prototype.tancar= function(evt){
	if( evt.primary ){
		createjs.Tween.get(this).to({alpha:0}, 500, createjs.Ease.circOut);
		Motor.showDomObjects();
	}
}