(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titulo']);
	this.btn_esfera = new lib.btn_esfera();
	this.btn_esfera.setTransform(747.5,328.9,1,1,0,0,0,108,107.5);
	new cjs.ButtonHelper(this.btn_esfera, 0, 1, 1);

	this.btn_cono = new lib.btn_cono();
	this.btn_cono.setTransform(474.5,317,1,1,0,0,0,67.5,110.5);
	new cjs.ButtonHelper(this.btn_cono, 0, 1, 1);

	this.btn_cilindro = new lib.btn_cilindro();
	this.btn_cilindro.setTransform(203.5,313,1,1,0,0,0,69.5,121);
	new cjs.ButtonHelper(this.btn_cilindro, 0, 1, 1);
  this.btn_cilindro.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.btn_cono.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
    this.btn_esfera.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });
  
	this.text = new cjs.Text("Selecciona una imagen", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.lineWidth = 266;
	this.text.setTransform(473,522.7+incremento);

	this.text_1 = new cjs.Text("Esfera", "bold 16px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.lineWidth = 78;
	this.text_1.setTransform(745.4,445.9);

	this.text_2 = new cjs.Text("Cilindro", "bold 16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 17;
	this.text_2.lineWidth = 78;
	this.text_2.setTransform(201.5,445.9);

	this.text_3 = new cjs.Text("Cono", "bold 16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 17;
	this.text_3.lineWidth = 78;
	this.text_3.setTransform(473.5,445.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A1FDNIAAmZMAqKAAAIAAGZg");
	this.shape.setTransform(475.2,534.4,1,0.732);
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.shape,this.text_3,this.text_2,this.text_1,this.text,this.btn_cilindro,this.btn_cono,this.btn_esfera);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit1']);
this.btn_cilindro2 = new lib.btn_cilindro2();
	this.btn_cilindro2.setTransform(245.2,464.9,1,1,0,0,0,85,25);
	new cjs.ButtonHelper(this.btn_cilindro2, 0, 1, 2, false, new lib.btn_cilindro2(), 3);

	this.btn_cilindro1 = new lib.btn_cilindro1();
	this.btn_cilindro1.setTransform(245.2,359.1,1,1,0,0,0,85,25);
	new cjs.ButtonHelper(this.btn_cilindro1, 0, 1, 2, false, new lib.btn_cilindro1(), 3);

	this.btn_cilindro1.on("click", function (evt) {
            putStage(new lib.frame2_1_1());
        });
	this.btn_cilindro2.on("click", function (evt) {
            putStage(new lib.frame2_2_1());
        });
  var html = createDiv(txt['text1'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 152-608);
	this.instance = new lib.Cilindro();
	this.instance.setTransform(620.3,153.4);
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.text,this.btn_cilindro1,this.btn_cilindro2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1_0 = function (vuelta) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit3']);
this.instance = new lib.popup_infocilindro();
	

      
        this.cerrar.on("click", function (evt) {
            if (vuelta==1)
            putStage(new lib.frame2_1_1());
          if (vuelta==2)
            putStage(new lib.frame2_1_2());
          if (vuelta==3)
            putStage(new lib.frame2_1_3());
          if (vuelta==4)
            putStage(new lib.frame2_1_4());
          if (vuelta==5)
            putStage(new lib.frame2_1_5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 1, 1);
        titulo2(this, txt['tit2']);
this.instance = new lib.CdP_Rectangulo();
	this.instance.setTransform(475.8,341.4,1,1,0,0,0,64.5,104.5);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_1_0(1));
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit2']);
        this.instance1 = new lib.CdP_Rectangulo();
	this.instance1.setTransform(475.8,341.4,1,1,0,0,0,64.5,104.5);

	this.instance = new lib.CdP_Giro_ok_2();
	this.instance.setTransform(475.8,341.4,1,1,0,0,0,64.5,104.5);
this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_1_0(2));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit2']);
     this.instance = new lib.CdP_Cilindro_ok();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.instance_1 = new lib.CdP_Giro_ok_2();
	this.instance_1.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_1_0(3));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1_4());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit2']);
     this.instance = new lib.animcilindro();
	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_1_0(4));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1_5());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 1, 1);
        titulo2(this, txt['tit2']);
   this.instance = new lib.CdP_Txt();
	this.instance.setTransform(494.2,324,1,1,0,0,0,255.2,178.6);
this.instance = new lib.fadeElement(this.instance, 10);

	this.instance_1 = new lib.CdP_Cilindro_ok();
	this.instance_1.setTransform(634,341.4,1,1,0,0,0,64.5,104.5);

	this.instance_2 = new lib.CdP_Giro_ok_2();
	this.instance_2.setTransform(343.4,341.4,1,1,0,0,0,64.5,104.5);

	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_1_0(5));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1_4());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.instance_2,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2_0 = function (vuelta) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit5']);
this.instance = new lib.popup_infocilindro2();
	

      
        this.cerrar.on("click", function (evt) {
            if (vuelta==1)
            putStage(new lib.frame2_2_1());
          if (vuelta==2)
            putStage(new lib.frame2_2_2());
          if (vuelta==3)
            putStage(new lib.frame2_2_3());
          if (vuelta==4)
            putStage(new lib.frame2_2_4());
          if (vuelta==5)
            putStage(new lib.frame2_2_5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 1, 1);
        titulo2(this, txt['tit4']);
	this.instance = new lib.CdP_Cilindro2();
	this.instance.setTransform(474.9,336.3,1,1,0,0,0,87.5,151.5);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_2_0(1));
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit4']);
       this.instance = new lib.CdP_Cilindro2Obert_ok();
	this.instance.setTransform(474.9,336.3,1,1,0,0,0,87.5,151.5);

	this.instance_1 = new lib.CdP_Cilindro2();
	this.instance_1.setTransform(474.9,336.3,1,1,0,0,0,87.5,151.5);

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_2_0(2));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 1, 1);
        titulo2(this, txt['tit4']);
  	this.instance = new lib.CdP_CilindroDesple();
	this.instance.setTransform(473.7,343.8,1,1,0,0,0,253.2,200.6);

	this.instance_1 = new lib.CdP_Cilindro2Obert_ok();
	this.instance_1.setTransform(474.9,336.3,1,1,0,0,0,87.5,151.5);
	this.instance = new lib.fadeElement(this.instance, 10);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_2_0(3));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2_2());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.instance_1,this.instance_2,this.cerrar,  this.anterior, this.siguiente,this.instance,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit6']);
	this.btn_cono2 = new lib.btn_cono2();
	this.btn_cono2.setTransform(244.7,464.9,1,1,0,0,0,85,25);
	new cjs.ButtonHelper(this.btn_cono2, 0, 1, 2, false, new lib.btn_cono2(), 3);

	this.btn_cono1 = new lib.btn_cono1();
	this.btn_cono1.setTransform(244.7,359.1,1,1,0,0,0,85,25);
	new cjs.ButtonHelper(this.btn_cono1, 0, 1, 2, false, new lib.btn_cono1(), 3);
	this.btn_cono1.on("click", function (evt) {
            putStage(new lib.frame3_1_1());
        });
	this.btn_cono2.on("click", function (evt) {
            putStage(new lib.frame3_2_1());
        });
  var html = createDiv(txt['text4'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 152-608);
	this.instance = new lib.Cono();
	this.instance.setTransform(597.9,150.8);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.text,this.btn_cono1,this.btn_cono2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1_0 = function (vuelta) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit8']);
this.instance = new lib.popup_infocono();
	

      
        this.cerrar.on("click", function (evt) {
            if (vuelta==1)
            putStage(new lib.frame3_1_1());
          if (vuelta==2)
            putStage(new lib.frame3_1_2());
          if (vuelta==3)
            putStage(new lib.frame3_1_3());
          if (vuelta==4)
            putStage(new lib.frame3_1_4());
          if (vuelta==5)
            putStage(new lib.frame3_1_5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 1, 1);
        titulo2(this, txt['tit7']);
this.instance = new lib.CdP_triangulo();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_1_0(1));
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit7']);
        this.instance1 = new lib.CdP_triangulo();
	this.instance1.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.instance = new lib.CdP_Giro_ok_1();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_1_0(2));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit7']);
   	this.instance = new lib.CdP_Cono_ok();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.instance_1 = new lib.CdP_Giro_ok_1();
	this.instance_1.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);


this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_1_0(3));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1_4());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit7']);
     this.instance = new lib.animcono();
	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_1_0(4));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1_5());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 1, 1);
        titulo2(this, txt['tit7']);
   this.instance = new lib.CdP_Txt_Cono();
	this.instance.setTransform(494.2,324,1,1,0,0,0,255.2,178.6);

	this.instance_1 = new lib.CdP_Cono_ok();
	this.instance_1.setTransform(646.9,341.4,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);

	
	this.instance_2 = new lib.CdP_Giro_ok_1();
	this.instance_2.setTransform(343.4,341.4,1,1,0,0,0,64.5,104.5);

	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_1_0(5));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1_4());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.instance_2,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2_0 = function (vuelta) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit10']);
this.instance = new lib.popup_infocono2();
	

      
        this.cerrar.on("click", function (evt) {
            if (vuelta==1)
            putStage(new lib.frame3_2_1());
          if (vuelta==2)
            putStage(new lib.frame3_2_2());
          if (vuelta==3)
            putStage(new lib.frame3_2_3());
          if (vuelta==4)
            putStage(new lib.frame3_2_4());
          if (vuelta==5)
            putStage(new lib.frame3_2_5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 1, 1);
        titulo2(this, txt['tit9']);
	this.instance = new lib.CdP_Cono2();
	this.instance.setTransform(474.9,292.4,0.77,0.77,0,0,0,87.5,151.5);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_2_0(1));
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit9']);
        	this.instance = new lib.CdP_ConoObert2_ok();
	this.instance.setTransform(474.9,292.3,0.77,0.77,0,0,0,87.5,151.3);

	this.instance_1 = new lib.CdP_Cono2();
	this.instance_1.setTransform(474.9,292.4,0.77,0.77,0,0,0,87.5,151.5);

	

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_2_0(2));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 1, 1);
        titulo2(this, txt['tit9']);
  		this.instance = new lib.CdP_ConoDesple();
	this.instance.setTransform(479.3,338.2,1,1,0,0,0,253.2,200.6);

	this.instance_1 = new lib.CdP_ConoObert2_ok();
	this.instance_1.setTransform(474.9,292.3,0.77,0.77,0,0,0,87.5,151.3);

	
	this.instance = new lib.fadeElement(this.instance, 10);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_2_0(3));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2_2());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.instance_1,this.instance_2,this.cerrar,  this.anterior, this.siguiente,this.instance,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit11']);
this.btn_esfera1 = new lib.btn_esfera1();
	this.btn_esfera1.setTransform(244.7,404.5,1,1,0,0,0,85,25);
	new cjs.ButtonHelper(this.btn_esfera1, 0, 1, 2, false, new lib.btn_esfera1(), 3);

	
	this.btn_esfera1.on("click", function (evt) {
            putStage(new lib.frame4_1_1());
        });
  var html = createDiv(txt['text7'], "Verdana", "20px", '460px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(90, 152-608);
this.instance = new lib.Esfera();
	this.instance.setTransform(556.8,157.4);
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.text,this.btn_esfera1,this.btn_cilindro2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1_0 = function (vuelta) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['tit12']);
this.instance = new lib.popup_infoesfera();
	

      
        this.cerrar.on("click", function (evt) {
            if (vuelta==1)
            putStage(new lib.frame4_1_1());
          if (vuelta==2)
            putStage(new lib.frame4_1_2());
          if (vuelta==3)
            putStage(new lib.frame4_1_3());
          if (vuelta==4)
            putStage(new lib.frame4_1_4());
          if (vuelta==5)
            putStage(new lib.frame4_1_5());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4_1_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 1, 1);
        titulo2(this, txt['tit13']);
	this.instance = new lib.CdP_Semicirculo();
	this.instance.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_1_0(1));
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit13']);
     	this.instance1 = new lib.CdP_Semicirculo();
	this.instance1.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

		this.instance = new lib.CdP_Giro_ok();
	this.instance.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_1_0(2));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1_3());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit13']);
    	this.instance = new lib.CdP_Esfera_ok();
	this.instance.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

	this.instance_1 = new lib.CdP_Giro_ok();
	this.instance_1.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_1_0(3));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1_4());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame4_1_4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 1, 1, 1);
        titulo2(this, txt['tit13']);
     this.instance = new lib.animesfera();
	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_1_0(4));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4_1_5());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame4_1_5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 1, 1);
        titulo2(this, txt['tit13']);
   this.instance = new lib.CdP_Txt_Esfera();
	this.instance.setTransform(455.1,324,1,1,0,0,0,255.2,178.6);

	this.instance_1 = new lib.CdP_Esfera_ok();
	this.instance_1.setTransform(646.9,317.1,1,1,0,0,0,64.5,104.5);

	this.instance_2 = new lib.CdP_Giro_ok();
	this.instance_2.setTransform(352.5,317.1,1,1,0,0,0,64.5,104.5);

this.instance = new lib.fadeElement(this.instance, 10);

	
	
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame4_1_0(5));
        });
       this.anterior.on("click", function (evt) {
            putStage(new lib.frame4_1_4());
        });
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

        this.addChild(this.logo, this.titulo, this.home,this.informacion,this.instance_1,this.instance_2,this.cerrar,  this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib.animesfera = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{h3:0});

	// Cilindro
	this.instance = new lib.CdP_Esfera_ok();
	this.instance.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:42.9,regY:125.5,x:482.7,y:338.1},0).wait(1).to({x:489.8},0).wait(1).to({x:496.9},0).wait(1).to({x:504.1},0).wait(1).to({x:511.2},0).wait(1).to({x:518.3},0).wait(1).to({x:525.4},0).wait(1).to({x:532.6},0).wait(1).to({x:539.7},0).wait(1).to({x:546.8},0).wait(1).to({x:554},0).wait(1).to({x:561.1},0).wait(1).to({x:568.2},0).wait(1).to({x:575.3},0).wait(1).to({x:582.5},0).wait(1).to({x:589.6},0).wait(1).to({x:596.7},0).wait(1).to({x:603.9},0).wait(1).to({x:611},0).wait(1).to({x:618.1},0).wait(1).to({x:625.3},0).wait(69));

	// Giro
	this.instance_1 = new lib.CdP_Giro_ok();
	this.instance_1.setTransform(497.2,317.1,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:-8.8,regY:117.6,x:416.9,y:330.2},0).wait(1).to({x:410},0).wait(1).to({x:403.1},0).wait(1).to({x:396.2},0).wait(1).to({x:389.3},0).wait(1).to({x:382.4},0).wait(1).to({x:375.5},0).wait(1).to({x:368.6},0).wait(1).to({x:361.7},0).wait(1).to({x:354.8},0).wait(1).to({x:348},0).wait(1).to({x:341.1},0).wait(1).to({x:334.2},0).wait(1).to({x:327.3},0).wait(1).to({x:320.4},0).wait(1).to({x:313.5},0).wait(1).to({x:306.6},0).wait(1).to({x:299.7},0).wait(1).to({x:292.8},0).wait(1).to({x:285.9},0).wait(1).to({x:279.1},0).wait(69));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(216.2,122.7,444.9,415);


   (lib.animcono = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{f3:0});

	// Cilindro
	this.instance = new lib.CdP_Cono_ok();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:61.2,regY:112.2,x:480.2,y:349.1},0).wait(1).to({x:488.3},0).wait(1).to({x:496.5},0).wait(1).to({x:504.7},0).wait(1).to({x:512.9},0).wait(1).to({x:521},0).wait(1).to({x:529.2},0).wait(1).to({x:537.4},0).wait(1).to({x:545.5},0).wait(1).to({x:553.7},0).wait(1).to({x:561.9},0).wait(1).to({x:570.1},0).wait(1).to({x:578.2},0).wait(1).to({x:586.4},0).wait(1).to({x:594.6},0).wait(1).to({x:602.7},0).wait(1).to({x:610.9},0).wait(1).to({x:619.1},0).wait(1).to({x:627.3},0).wait(1).to({x:635.4},0).wait(1).to({x:643.6},0).wait(79));

	// Giro
	this.instance_1 = new lib.CdP_Giro_ok_1();
	this.instance_1.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:31.7,regY:112.2,x:436.3,y:349.1},0).wait(1).to({x:430.2},0).wait(1).to({x:424},0).wait(1).to({x:417.8},0).wait(1).to({x:411.7},0).wait(1).to({x:405.5},0).wait(1).to({x:399.3},0).wait(1).to({x:393.2},0).wait(1).to({x:387},0).wait(1).to({x:380.8},0).wait(1).to({x:374.7},0).wait(1).to({x:368.5},0).wait(1).to({x:362.3},0).wait(1).to({x:356.2},0).wait(1).to({x:350},0).wait(1).to({x:343.8},0).wait(1).to({x:337.7},0).wait(1).to({x:331.5},0).wait(1).to({x:325.3},0).wait(1).to({x:319.2},0).wait(1).to({x:313},0).wait(79));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(249,155.6,416.6,387);

   (lib.animcilindro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{p3:0});

	
	// Cilindro
	this.instance = new lib.CdP_Cilindro_ok();
	this.instance.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:57.7,regY:105.6,x:476.1,y:342.5},0).wait(1).to({x:483.6},0).wait(1).to({x:491.2},0).wait(1).to({x:498.7},0).wait(1).to({x:506.3},0).wait(1).to({x:513.8},0).wait(1).to({x:521.4},0).wait(1).to({x:529},0).wait(1).to({x:536.5},0).wait(1).to({x:544.1},0).wait(1).to({x:551.6},0).wait(1).to({x:559.2},0).wait(1).to({x:566.7},0).wait(1).to({x:574.3},0).wait(1).to({x:581.9},0).wait(1).to({x:589.4},0).wait(1).to({x:597},0).wait(1).to({x:604.5},0).wait(1).to({x:612.1},0).wait(1).to({x:619.6},0).wait(1).to({x:627.2},0).wait(2));

	// Giro
	this.instance_1 = new lib.CdP_Giro_ok_2();
	this.instance_1.setTransform(475.3,341.4,1,1,0,0,0,64.5,104.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:45.6,regY:107.1,x:450.1,y:344},0).wait(1).to({x:443.8},0).wait(1).to({x:437.6},0).wait(1).to({x:431.3},0).wait(1).to({x:425},0).wait(1).to({x:418.7},0).wait(1).to({x:412.4},0).wait(1).to({x:406.2},0).wait(1).to({x:399.9},0).wait(1).to({x:393.6},0).wait(1).to({x:387.3},0).wait(1).to({x:381},0).wait(1).to({x:374.7},0).wait(1).to({x:368.5},0).wait(1).to({x:362.2},0).wait(1).to({x:355.9},0).wait(1).to({x:349.6},0).wait(1).to({x:343.3},0).wait(1).to({x:337.1},0).wait(1).to({x:330.8},0).wait(1).to({x:324.5},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(44,41.2,863.2,545.2);


   (lib.Cilindro = function() {
	this.initialize(img.Cilindro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,193,338);


(lib.Cilindro_1 = function() {
	this.initialize(img.Cilindro_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,132,344);


(lib.Cilindro_2 = function() {
	this.initialize(img.Cilindro_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,293,291);


(lib.Cilindro_Intro = function() {
	this.initialize(img.Cilindro_Intro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,139,242);


(lib.cilindro1A = function() {
	this.initialize(img.cilindro1A);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,430,998);


(lib.cilindro1B = function() {
	this.initialize(img.cilindro1B);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,413,1000);


(lib.cilindro1C = function() {
	this.initialize(img.cilindro1C);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,518,1072);


(lib.cilindro2A = function() {
	this.initialize(img.cilindro2A);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cilindro2B = function() {
	this.initialize(img.cilindro2B);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.cilindro2C = function() {
	this.initialize(img.cilindro2C);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cono = function() {
	this.initialize(img.cono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,171,366);


(lib.Cono = function() {
	this.initialize(img.Cono);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,345);


(lib.Cono_1 = function() {
	this.initialize(img.Cono_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,361,355);


(lib.Cono_Intro = function() {
	this.initialize(img.Cono_Intro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,135,221);


(lib.cono1A = function() {
	this.initialize(img.cono1A);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1000,1000);


(lib.cono1B = function() {
	this.initialize(img.cono1B);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cono1C = function() {
	this.initialize(img.cono1C);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cono1D = function() {
	this.initialize(img.cono1D);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Cono2 = function() {
	this.initialize(img.Cono2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,135,221);


(lib.cono2A = function() {
	this.initialize(img.cono2A);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cono2B = function() {
	this.initialize(img.cono2B);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.cono2C = function() {
	this.initialize(img.cono2C);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.ConoDesple = function() {
	this.initialize(img.ConoDesple);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,263,316);


(lib.ConoObert = function() {
	this.initialize(img.ConoObert);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,138,298);


(lib.esfera = function() {
	this.initialize(img.esfera);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,395,302);
(lib.esferas = function() {
	this.initialize(img.esferas);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,395,302);


(lib.Esfera = function() {
	this.initialize(img.Esfera);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,274,274);


(lib.Esfera_1 = function() {
	this.initialize(img.Esfera_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,216,287);


(lib.Esfera_Intro = function() {
	this.initialize(img.Esfera_Intro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,216,215);


(lib.esferaA = function() {
	this.initialize(img.esferaA);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.esferaB = function() {
	this.initialize(img.esferaB);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.esferaC = function() {
	this.initialize(img.esferaC);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,500);


(lib.Giro = function() {
	this.initialize(img.Giro);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,72,343);


(lib.Giro_1 = function() {
	this.initialize(img.Giro_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,72,343);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.semicirculo = function() {
	this.initialize(img.semicirculo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,210);


(lib.triangulo = function() {
	this.initialize(img.triangulo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,85,244);


(lib.TxtConoDesple = function() {
	this.initialize(img.TxtConoDesple);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,239,185);


(lib.btn_siguiente = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.6,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(-6.4,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:-7.1}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:3.9}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:-6.4}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.6}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_info = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("i", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 8;
	this.text.setTransform(13.1,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape.setTransform(15,15.9,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(15,15.9,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:12.5,y:-1}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}},{t:this.text,p:{scaleX:1,scaleY:1,x:13.1,y:0.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.5,30,30.7);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_anteriorcopia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(-3.5,0,0.673,0.673,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
	this.shape_1.setTransform(6.5,0.1,0.673,0.673,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
	this.shape_2.setTransform(0,0,0.673,0.673,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
	this.shape_3.setTransform(0,0,0.673,0.673,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]}).to({state:[{t:this.shape_3,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_2,p:{scaleX:0.741,scaleY:0.741}},{t:this.shape_1,p:{scaleX:0.741,scaleY:0.741,x:7.2}},{t:this.shape,p:{scaleX:0.741,scaleY:0.741,x:-3.8}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).to({state:[{t:this.shape_3,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,x:6.5}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:-3.5}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.CdP_ConoObert2_ok = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.cono2B();
	this.instance.setTransform(-161.8,-37);

	// Capa 1
	this.instance_1 = new lib.cono2A();
	this.instance_1.setTransform(-87.2,-32.1,0.7,0.7);

	this.addChild(this.instance_1,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-161.8,-37,500,500);


(lib.CdP_ConoDesple = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cono2C();
	this.instance.setTransform(124.1,-14.7,0.82,0.82);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(124.1,-14.7,410,410);


(lib.CdP_Cono2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cono2A();
	this.instance.setTransform(-87.2,-32.1,0.7,0.7);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-87.2,-32.1,350,350);


(lib.CdP_CilindroDesple = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cilindro2C();
	this.instance.setTransform(13.7,-44.4,0.963,0.963);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgniAfVMAAAg+pMBPFAAAMAAAA+pg");
	this.shape.setTransform(253.2,200.6);

	this.addChild(this.shape,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-44.4,506.4,481.6);


(lib.CdP_Cilindro2Obert_ok = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.cilindro2B();
	this.instance.setTransform(-86.8,-21.3,0.352,0.35);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-86.8,-21.3,352.5,350);


(lib.CdP_Cilindro2 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cilindro2A();
	this.instance.setTransform(-86.9,-21.1,0.7,0.7);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-86.9,-21.1,350,350);


(lib.CdP_Txt_Esfera = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("circunferencia\nmáxima", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(223.2,295.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape.setTransform(380.3,269.6,1.841,1.841,-165.9,0,0,-0.3,-0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_1.setTransform(346.2,282.9,1.215,1.215,-165.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape_2.setTransform(340.9,230.2,1.842,1.842,148.8,0,0,-0.2,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_3.setTransform(326.7,263.8,1.216,1.216,148.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape_4.setTransform(527.1,175,1.842,1.842,-21.3,0,0,0,-0.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_5.setTransform(553.2,127.2,1.762,1.942,-21.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape_6.setTransform(434.1,195.2,1.984,1.977,0,180,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#1D1D1C").ss(.7,0,0,3.9).p("ADkiuInHFd");
	this.shape_7.setTransform(511.1,253.5,3.198,3.187,0,180,0);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AAAgHQgQgFgRgHIAAAnQALgFAWgHQATgHAPgBQgNAAgVgHg");
	this.shape_8.setTransform(411,52.2,1.543,1.216);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AgggTQAQAHAQAFQAVAHAMAAQgOABgTAHQgWAHgKAFg");
	this.shape_9.setTransform(411,52.2,1.543,1.216);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(2,1,1).p("AABAIQAOAEASAIIAAgnQgSAIgOAEQgVAHgMAAQAOABATAHg");
	this.shape_10.setTransform(145.2,52.2,1.543,1.216);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AABAIQgTgHgOgBQAMAAAVgHQAOgEASgIIAAAnQgSgIgOgEg");
	this.shape_11.setTransform(145.2,52.2,1.543,1.216);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ANJAAI6RAA");
	this.shape_12.setTransform(278,52.2,1.543,1.216);

	this.text_1 = new cjs.Text("radio", "18px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(553.8,55.8);

	this.text_2 = new cjs.Text("centro", "18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(554.2,305.7);

	this.text_3 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 279;
	this.text_3.setTransform(275.5,20.8);

	this.addChild(this.text_3,this.text_2,this.text_1,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(136.2,20.8,479.4,324.9);


(lib.CdP_Semicirculo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.esferaA();
	this.instance.setTransform(116.5,-18.9,0.55,0.55,0,0,180);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-158.4,-18.9,275,275);


(lib.CdP_Giro_ok = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.esferaB();
	this.instance.setTransform(198.5,-89.8,0.83,0.83,0,0,180);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-216.4,-89.8,415,415);


(lib.CdP_Esfera_ok = function() {
	this.initialize();

	// Capa 3
	this.instance = new lib.esferaC();
	this.instance.setTransform(-142.6,-60,0.742,0.742);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-142.6,-60,371.2,371.2);


(lib.CdP_Txt_Cono = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("g", "20px Verdana", "#1D1D1C");
	this.text.lineHeight = 23;
	this.text.lineWidth = 13;
	this.text.setTransform(335.4,188.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape.setTransform(443.2,313.4,1.843,1.843,0,180,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_1.setTransform(472.2,335.2,1.216,1.216,0,180,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AAAgHQgQgFgRgHIAAAnQALgFAWgHQATgHAPgBQgNAAgVgHg");
	this.shape_2.setTransform(386.1,48.2,1.543,1.216);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D1D1C").s().p("AgggTQAQAHAQAFQAVAHAMAAQgOABgTAHQgWAHgKAFg");
	this.shape_3.setTransform(386.1,48.2,1.543,1.216);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AABAIQAOAEASAIIAAgnQgSAIgOAEQgVAHgMAAQAOABATAHg");
	this.shape_4.setTransform(120.3,48.2,1.543,1.216);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1C").s().p("AABAIQgTgHgOgBQAMAAAVgHQAOgEASgIIAAAnQgSgIgOgEg");
	this.shape_5.setTransform(120.3,48.2,1.543,1.216);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ANJAAI6RAA");
	this.shape_6.setTransform(253.1,48.2,1.543,1.216);

	this.text_1 = new cjs.Text("r", "20px Verdana", "#1D1D1C");
	this.text_1.lineHeight = 23;
	this.text_1.lineWidth = 9;
	this.text_1.setTransform(356.1,284.6);

	this.text_2 = new cjs.Text("h", "20px Verdana", "#1D1D1C");
	this.text_2.lineHeight = 23;
	this.text_2.lineWidth = 13;
	this.text_2.setTransform(404.7,200.7);

	this.text_3 = new cjs.Text("generatriz", "18px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(16.5,228.4,1,1,-70.6);

	this.text_4 = new cjs.Text("altura", "18px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(102.8,217.4,1,1,-89.9);

	this.text_5 = new cjs.Text("radio", "18px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(21.6,310.8);

	this.text_6 = new cjs.Text("base", "18px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(501.5,343.3);

	this.text_7 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 279;
	this.text_7.setTransform(251.2,17.5);

	this.addChild(this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(16.5,17.5,531.3,351.7);


(lib.CdP_triangulo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cono1A();
	this.instance.setTransform(-110.2,-33.6,0.26,0.26);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-110.2,-33.6,260,260);


(lib.CdP_Giro_ok_1 = function() {
	this.initialize();

	// Capa 2
	this.instance_1 = new lib.cono1B();
	this.instance_1.setTransform(-161.7,-81.2,0.774,0.774);

	this.addChild(this.instance_1);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-161.7,-81.2,387,387);


(lib.CdP_Cono_ok = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.cono1C();
	this.instance.setTransform(-132.2,-81.2,0.774,0.774);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-132.2,-81.2,387,387);


(lib.CdP_Txt = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape.setTransform(424.7,308,1.843,1.843,0,180,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_1.setTransform(453.7,329.8,1.216,1.216,0,180,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AAAgHQgQgFgRgHIAAAnQALgFAWgHQATgHAPgBQgNAAgVgHg");
	this.shape_2.setTransform(380.7,61.1,1.543,1.216);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D1D1C").s().p("AgggTQAQAHAQAFQAVAHAMAAQgOABgTAHQgWAHgKAFg");
	this.shape_3.setTransform(380.7,61.1,1.543,1.216);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AABAIQAOAEASAIIAAgnQgSAIgOAEQgVAHgMAAQAOABATAHg");
	this.shape_4.setTransform(114.9,61.1,1.543,1.216);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1C").s().p("AABAIQgTgHgOgBQAMAAAVgHQAOgEASgIIAAAnQgSgIgOgEg");
	this.shape_5.setTransform(114.9,61.1,1.543,1.216);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ANJAAI6RAA");
	this.shape_6.setTransform(247.8,61.1,1.543,1.216);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AgJAAQAMgRAFgKIAYAeIggAKQgUAIgLAHQALgLALgRg");
	this.shape_7.setTransform(424.7,92.7,1.843,1.843);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1D1D1C").ss(2,0,0,3.9).p("ADkiuInHFd");
	this.shape_8.setTransform(453.7,71,1.216,1.216);

	this.text = new cjs.Text("r", "20px Verdana", "#1D1D1C");
	this.text.lineHeight = 23;
	this.text.lineWidth = 9;
	this.text.setTransform(352.1,280.1);

	this.text_1 = new cjs.Text("h", "20px Verdana", "#1D1D1C");
	this.text_1.lineHeight = 23;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(395.9,192.2);

	this.text_2 = new cjs.Text("generatriz", "18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(14,255.8,1,1,-89.9);

	this.text_3 = new cjs.Text("altura", "18px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(100.9,239.3,1,1,-89.9);

	this.text_4 = new cjs.Text("radio", "18px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(24.8,305.4);

	this.text_5 = new cjs.Text("base", "18px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(482.9,337.3);

	this.text_6 = new cjs.Text("base", "18px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(482.9,30.5);

	this.text_7 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 279;
	this.text_7.setTransform(247.6,31.7);

	this.addChild(this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(14,30.5,515.2,332.7);


(lib.CdP_Rectangulo = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.cilindro1A();
	this.instance.setTransform(-30.4,-67.8,0.35,0.35);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-30.4,-67.8,150.5,349.3);


(lib.CdP_Giro_ok_2 = function() {
	this.initialize();

	// Capa 1
	this.instance_2 = new lib.cilindro1B();
	this.instance_2.setTransform(-26.6,-67.8,0.35,0.35);

	this.addChild(this.instance_2);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-26.6,-67.8,144.6,350);


(lib.CdP_Cilindro_ok = function() {
	this.initialize();

	// Capa 2
	this.instance = new lib.cilindro1C();
	this.instance.setTransform(-23.4,-61.8,0.313,0.312);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-23.4,-61.8,162.3,334.9);


(lib.btn_esfera1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Obtención de\nla esfera", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 163;
	this.text.setTransform(82.7,2.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape.setTransform(85,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_1.setTransform(85,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_2.setTransform(85,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,50);


(lib.btn_esfera = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Esfera();
	this.instance.setTransform(-1.5,-4.8,0.8,0.8);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1.5,-4.8,219.2,219.2);


(lib.btn_cono2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Desarrollo plano\ndel cono", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 164;
	this.text.setTransform(82.7,3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape.setTransform(85,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_1.setTransform(85,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_2.setTransform(85,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,50);


(lib.btn_cono1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Obtención\ndel cono", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 163;
	this.text.setTransform(82.7,2.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape.setTransform(85,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_1.setTransform(85,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_2.setTransform(85,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,50);


(lib.btn_cono = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Cono();
	this.instance.setTransform(-7.1,-20.6,0.72,0.72);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-7.1,-20.6,151.2,248.4);


(lib.btn_cilindro2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Desarrollo plano\ndel cilindro", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 164;
	this.text.setTransform(82.7,3+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape.setTransform(85,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_1.setTransform(85,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_2.setTransform(85,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,50);


(lib.btn_cilindro1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Obtención\ndel cilindro", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 163;
	this.text.setTransform(82.7,2.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape.setTransform(85,25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_1.setTransform(85,25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-85,-25,170,50,6);
	this.shape_2.setTransform(85,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,170,50);


(lib.btn_cilindro = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Cilindro();
	this.instance.setTransform(0.2,-1,0.72,0.72);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0.2,-1,139,243.4);


(lib.popup_infoesfera = function() {
	this.initialize();

	// FlashAICB
	this.text = new cjs.Text("circunferencia\nmáxima", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(541.2,460);

	this.text_1 = new cjs.Text("centro", "18px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(826.2,448);

	this.text_2 = new cjs.Text("radio", "18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(808.2,245.1);

	this.text_3 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 231;
	this.text_3.setTransform(593.5,176.1);

	
	this.text_4 = new cjs.Text("Elementos de la esfera\n\n\n• Eje: Diámetro sobre el que gira\nel semicírculo.\n\n• Centro: Centro del semicírculo\n\n• Radio: Radio del semicírculo.", "bold 23px Verdana");
	this.text_4.lineHeight = 25;
	this.text_4.lineWidth = 356;
	this.text_4.setTransform(82.7,44.6);
 var html = createDiv(txt['text8'], "Verdana", "20px", '360px', '40px', "20px", "185px", "left");
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(80, 95-608);

	this.instance = new lib.esferas();
	this.instance.setTransform(452.5,203.9);

	
	this.addChild(this.instance,this.text_4,this.btn_salir,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_infocono2 = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.cono2C();
	this.instance.setTransform(515,167,0.7,0.7);

	
	this.text = new cjs.Text("Desarrollo plano del cono\n\n\nEl desarrollo de un cono está formado por un sector circular y un círculo.\n\n• La longitud del arco del sector es 2πr\n(siendo r el radio del cono), ya que es la longitud de la circunferencia de la base.\n\n• El radio del sector circular es la\ngeneratriz, g.", "bold 23px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 431;
	this.text.setTransform(82.7,44.6);
var html = createDiv(txt['text6'], "Verdana", "20px", '440px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(80, 115-608);


	this.addChild(this.text,this.btn_salir,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_infocono = function() {
	this.initialize();

	// FlashAICB
	this.text = new cjs.Text("g", "20px Verdana", "#1D1D1C");
	this.text.lineHeight = 23;
	this.text.lineWidth = 13;
	this.text.setTransform(683.7,304.1);

	this.text_1 = new cjs.Text("r", "18px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(715.6,386);

	this.text_2 = new cjs.Text("h", "18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(756.7,293.8);

	this.text_3 = new cjs.Text("generatriz", "18px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(493,382.8,1,1,-71.2);

	this.text_4 = new cjs.Text("altura", "18px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(562.6,341.9,1,1,-89.9);

	this.text_5 = new cjs.Text("radio", "18px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(490.2,410+incremento);

	this.text_6 = new cjs.Text("base", "18px Verdana");
	this.text_6.lineHeight = 20;
	this.text_6.setTransform(825.2,433);

	this.text_7 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 20;
	this.text_7.lineWidth = 185;
	this.text_7.setTransform(657.8,103.1);

	
	this.text_8 = new cjs.Text("Elementos del cono\n\n\n• Eje: Cateto sobre el que gira el\ntriángulo.\n\n• Altura: Longitud del eje.\n\n• Generatriz: Longitud de la\nhipotenusa del triángulo.\n\n• Base: Círculo generado al girar\nel cateto perpendicular al eje.\n\n• Radio: Longitud del cateto\nperpendicular al eje.", "bold 23px Verdana");
	this.text_8.lineHeight = 25;
	this.text_8.lineWidth = 356;
	this.text_8.setTransform(82.7,44.6);
  var html = createDiv(txt['text5'], "Verdana", "20px", '370px', '40px', "20px", "185px", "left");
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(80, 95-608);
	this.instance = new lib.Cono_1();
	this.instance.setTransform(484.7,129.5);

	// FonsBlanc
	
	this.addChild(this.instance,this.text_8,this.btn_salir,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_infocilindro2 = function() {
	this.initialize();

	// FlashAICB
	this.instance = new lib.cilindro2C();
	this.instance.setTransform(480.1,152.9,0.8,0.8);

	
	this.text = new cjs.Text("Desarrollo plano del cilindro\n\n\nEl desarrollo de un cilindro está formado por un rectángulo y dos círculos iguales, que son las bases.\n \n• La longitud de la circunferencia de\nla base es la base del rectángulo.\n\n• La generatriz del cilindro es la\naltura del rectángulo.", "bold 23px Verdana");
	this.text.lineHeight = 25;
	this.text.lineWidth = 369;
	this.text.setTransform(82.7,44.6);
  var html = createDiv(txt['text3'], "Verdana", "20px", '370px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(80, 115-608);
	
	this.addChild(this.text,this.btn_salir,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_infocilindro = function() {
	this.initialize();

	// FlashAICB
	this.text = new cjs.Text("generatriz", "18px Verdana");
	this.text.lineHeight = 20;
	this.text.setTransform(503.4,392.4,1,1,-89.9);

	this.text_1 = new cjs.Text("altura", "18px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(587.4,372.9,1,1,-89.9);

	this.text_2 = new cjs.Text("radio", "18px Verdana");
	this.text_2.lineHeight = 20;
	this.text_2.setTransform(532,460);

	this.text_3 = new cjs.Text("base", "18px Verdana");
	this.text_3.lineHeight = 20;
	this.text_3.setTransform(808,462);

	this.text_4 = new cjs.Text("base", "18px Verdana");
	this.text_4.lineHeight = 20;
	this.text_4.setTransform(808,202);

	this.text_5 = new cjs.Text("eje de giro", "18px Verdana");
	this.text_5.lineHeight = 20;
	this.text_5.setTransform(616,170);

	this.instance = new lib.Cilindro_2();
	this.instance.setTransform(530.5,196.5);

	
	this.text_6 = new cjs.Text("Elementos del cilindro\n\n\n• Eje: Lado sobre el que gira el\nrectángulo que genera el cilindro.\n\n• Altura: Longitud del eje.\n\n• Generatriz: Longitud del lado\nopuesto al eje.\n\n• Bases: Dos círculos iguales y\nparalelos que se generan al girar los lados perpendiculares.\n\n• Radio: Longitud de los lados\nperpendiculares al eje.", "bold 23px Verdana");
	this.text_6.lineHeight = 25;
	this.text_6.lineWidth = 341;
	this.text_6.setTransform(82.7,44.6);
  var html = createDiv(txt['text2'], "Verdana", "20px", '360px', '40px', "20px", "185px", "left");
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(80, 95-608);
	// FonsBlanc
	
	this.addChild(this.text_6,this.btn_salir,this.instance,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}