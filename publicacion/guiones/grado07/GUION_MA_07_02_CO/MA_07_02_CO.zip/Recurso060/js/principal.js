(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,0,0,0,0);
        titulo1(this,txt['titulo']);
        	this.btn_resta = new lib.btn_resta();
	this.btn_resta.setTransform(280.1,435,1,1,0,0,0,130,15);
	new cjs.ButtonHelper(this.btn_resta, 0, 1, 2, false, new lib.btn_resta(), 3);

	this.btn_suma = new lib.btn_suma();
	this.btn_suma.setTransform(280.1,246.5,1,1,0,0,0,130,15);
	new cjs.ButtonHelper(this.btn_suma, 0, 1, 2, false, new lib.btn_suma(), 3);
 this.btn_suma.on("click", function (evt) {
            putStage(new lib.frame2());
        });
   this.btn_resta.on("click", function (evt) {
            putStage(new lib.frame3());
        });
	this.instance = new lib.Mapadebits1();
	this.instance.setTransform(544.2,139.7);
   
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.instance,this.btn_suma,this.btn_resta);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
        titulo2(this, txt['tit1']);
this.btn_sumarpositivos = new lib.btn_sumarpositivos();
	this.btn_sumarpositivos.setTransform(277.5,440.2,1,1,0,0,0,101.1,24.8);
	new cjs.ButtonHelper(this.btn_sumarpositivos, 0, 1, 2, false, new lib.btn_sumarpositivos(), 3);

	this.btn_sumarnegativos = new lib.btn_sumarnegativos();
	this.btn_sumarnegativos.setTransform(673.4,440.2,1,1,0,0,0,101.1,24.8);
	new cjs.ButtonHelper(this.btn_sumarnegativos, 0, 1, 2, false, new lib.btn_sumarnegativos(), 3);

this.btn_sumarpositivos.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.btn_sumarnegativos.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAUQgMgGgDgOQgEgPAPgGQAOgGAMARQALAMgGALQgDAFgFADQgFADgFAAQgEAAgFgEg");
	this.shape.setTransform(324.4,234.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgFQgGgLALgMQAMgRAOAGQAPAGgDAPQgEAOgLAGQgGAEgEAAQgFAAgFgDg");
	this.shape_1.setTransform(315.3,233.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAfAOQgPgLgIgDQgGgDgGAGQgKAMgWABQgZABgKgRQgJgRAJAAQACAAACAHQADAKALAEQAMAIASgHQAMgFAHgFQAJgLARAQQASAQAXgLQAGgDgDgIIgDgLQAaASgZAMQgJAFgJAAQgHAAgIgEg");
	this.shape_2.setTransform(319.6,251.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgFAQQgHgFgGgGQgMgKAGgHQAIgJAWADQAYAEgDAOQgDANgNAFQgFACgDAAQgEAAgEgEg");
	this.shape_3.setTransform(319.4,246.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AA5AfQgOgVgNgKQgSgLgZgFQgWgEgJAPQgJANgDAAQgFAAAAgIQAAgIAHgJQAQgYAjAJQAhAJATAaQAKAOADAMQAAAGgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBgBgBg");
	this.shape_4.setTransform(307.2,239.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag9AdIANgaQATgaAhgJQAkgJAQAZQAGAIAAAIQAAAIgFAAQgDAAgJgNQgJgOgWAEQgZAFgSAKQgOALgNAUQgCAEgBAAQgCAAAAgGg");
	this.shape_5.setTransform(333.1,239.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVBRQgtgHgegRQgfgTACgXQAEgtAzggQAwgeAlAJQAuALAmAnQAsAsgbAqQgWAhhAAAQgYAAgbgFg");
	this.shape_6.setTransform(319.7,251.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D06F1A").s().p("AkgAHQgGhlBbgxQBLgpCAAAQB8AABOAsQBbAygEBeQgDBchkAyQhPAnhmAAQkbAAgKiyg");
	this.shape_7.setTransform(319.9,244.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgSAcQgKgLgGgPQgKgdAZgUQATgPAlALQAEAzgUA4QgTgGgUgWg");
	this.shape_8.setTransform(367.3,242);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AglAPQgHgIgCgJQgGgVATgMQAWgPAjAaQAlAYgTAUQgTAVgTAAQgUAAgVgag");
	this.shape_9.setTransform(348.4,263.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgxAnQgdADgYANQgCgiAOgXQASgjAugPQA+gVAnAuQAjAngIAwQg9gdhaAIg");
	this.shape_10.setTransform(333.6,268.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D06F1A").s().p("Aj9EKQgcgXArg3QAXgdAEgIQAKgSgNgHQgNgIgYAOIgrAhQg1ApgKgoQgMguBVgwQAqgYAtgPQBwgwBlABQBaABBQAmQAjgPAPgqQAJgZAEgvIAGhOQAKhaAwgBQAcgBAMAoQAMAmgKA3QgXCKhqA0QA6AqAUA3QATA1giARQgbANghg6QgRgfgGgHQgNgPgKAIQgQALATAZQAgAnAHAUQAOAogkAKQgkALgOgpQgQgrg4gXQg8gahVAIQhAAGg5BEQgZAfgIAGQgIAGgIAAQgJAAgKgIg");
	this.shape_11.setTransform(335.1,257.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAjA8QgLgFgXgXQgSgTgMgDQgSgEgQAWIgYgRIAVglQAcgmAigBQAogBAiAzQAjAxgfAaQgKAGgKAAQgKAAgJgGg");
	this.shape_12.setTransform(347.9,229.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhJA8QgfgaAjgxQAigzAoABQAiABAcAmQAOAUAHARIgYARQgQgWgSAEQgMACgSAUQgYAXgKAFQgKAGgJAAQgKAAgKgGg");
	this.shape_13.setTransform(290.2,229.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ai0FAQgWgSAAgZQAAgfAnguIADgEIgTAPQgdAWgNAHQgXAMgSgHQgXgHgIggQgCgKAAgHQAAgyBHgtQhQgZgng2QgegpgEg6IAAgNQAAgrAQgiQgVARgRAFQgZAHgXgPIgDgCQgRgOgEgVQgEgWAJgYQANgjAfgaQAigdAiABQA2AAAmBBQBOgkB4AAQBqAABOAgQAng9AzAAQAigBAiAdQAfAaANAjQAJAYgEAWQgEAVgRAOIgBABIgCABQgfAUgggSQALAdAAAiIAAAHQgDA5ghApQAbAHAfAOQAUgNAIgYQAJgZAFhIQAFhKAMggQATg1AxgBQAbgBATAVQAWAZAEAxIABAOIgBAdIgFAeQgFAZgHAVQgeBXhEAxQAfAdASAiQASAiAAAdIgBAIQgDAlggAQQgYALgWgMIAAABQAAAVgOARQgKAMgQAGQgQAFgQgDQgmgHgOgoQgLgegqgUIgOgFIgGgCIgBgBIgGgBIgBgBIgQgEIgagEIgQgBIgDAAIgeAAIguAGIgCABIgCABIgOAGQgdAPgiAsQgSAVgKAJQgPANgRACIgEAAQgSAAgRgNg");
	this.shape_14.setTransform(326.3,253.6);

	this.text = new cjs.Text("7", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(832,327+incremento);

	this.text_1 = new cjs.Text("6", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(759,327+incremento);

	this.text_2 = new cjs.Text("5", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(687,327+incremento);

	this.text_3 = new cjs.Text("4", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(613,327+incremento);

	this.text_4 = new cjs.Text("3", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(541,327+incremento);

	this.text_5 = new cjs.Text("2", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(467,327+incremento);

	this.text_6 = new cjs.Text("1", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(394,327+incremento);

	this.text_7 = new cjs.Text("0", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(320,327+incremento);

	this.text_8 = new cjs.Text("-1", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(240,327+incremento);

	this.text_9 = new cjs.Text("-2", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(166,327+incremento);

	this.text_10 = new cjs.Text("-3", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(94,327+incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_15.setTransform(767.5,304.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_16.setTransform(695,304.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_17.setTransform(622,304.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_18.setTransform(549,304.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_19.setTransform(476,304.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_20.setTransform(403,304.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_21.setTransform(329.5,304.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_22.setTransform(257,304.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_23.setTransform(183.5,304.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_24.setTransform(840.5,304.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_25.setTransform(111,304.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_26.setTransform(475.5,304.8);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.btn_sumarnegativos,this.btn_sumarpositivos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
       this.text = new cjs.Text(txt['tit2'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_SumarPositivos("single",0);
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_1b());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_1b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
       this.text = new cjs.Text(txt['tit2'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_SumarPositivos();
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
       this.text = new cjs.Text(txt['tit3'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_SumarNegativos("single",0);
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2b());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame2_2b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
       this.text = new cjs.Text(txt['tit3'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_SumarNegativos();
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame2_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      titulo2(this, txt['tit4'],"20px");
     texto(this,txt['text5'],0,-50);
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
   (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 1, 0);
        titulo2(this, txt['tit5']);
this.btn_restarpositivos = new lib.btn_restarpositivos();
	this.btn_restarpositivos.setTransform(277.5,440.2,1,1,0,0,0,101.1,24.8);
	new cjs.ButtonHelper(this.btn_restarpositivos, 0, 1, 2, false, new lib.btn_restarpositivos(), 3);

	this.btn_restarnegativos = new lib.btn_restarnegativos();
	this.btn_restarnegativos.setTransform(673.4,440.2,1,1,0,0,0,101.1,24.8);
	new cjs.ButtonHelper(this.btn_restarnegativos, 0, 1, 2, false, new lib.btn_restarnegativos(), 3);
this.btn_restarpositivos.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.btn_restarnegativos.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogTgFQgfgIgFgWQgFgVAQgbIANgXQAEgJgDgIIAigBQgCARAlAeQAYAUgQAaQgSAdAMAVQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape.setTransform(463.7,241.6,0.333,0.277,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9661F").s().p("AgBBwQgYgMAPgqQAMgngUgGQgegHgFgWQgFgVAQgbQANgXACgFQACgKgIgLIAtgEQgJALAFANQAHANAaAVQAYAUgQAbQgTAcANAWQAVAjgQAbQgLASgRAAQgLAAgKgGg");
	this.shape_1.setTransform(457,241.4,0.333,0.277,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogUgFQgegIgFgWQgFgVAQgbIANgYQAEgJgDgIIAiABQgBAQAkAeQAYAUgQAaQgTAcANAWQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_2.setTransform(470,241.6,0.333,0.277,0,0,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E9661F").s().p("AhwAwQgYgQgRAKQgGAEgJADIgEgvQAKADADgNQAIghAggEQAdgEAQAWQAQAWAMgBQAQgBAbghQASgZAaAQQAfATAWgNQAjgVAbAQQAcARgRAgQgLAYgqgOQgogMgFATQgIAfgYAFQgVAEgYgQQgbgPgHAAQgLAAgVAVQgIAIgJAAQgKAAgLgIg");
	this.shape_3.setTransform(490.3,251.3,0.333,0.277,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E9661F").s().p("AhwA3IgXgOQgNgggMgoQAPgQAYACQAXABAMARQAPAWANgBQAPgCAcghQASgYAaAQQAeASAWgNQAjgUAcAQQAbAQgQAhQgMAYgqgPQgngMgGATQgHAfgYAFQgVAFgZgQQgbgQgHAAQgKAAgVAVQgJAJgKAAIgHgBg");
	this.shape_4.setTransform(489.9,256.6,0.333,0.277,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9661F").s().p("AgnAxQgfgSgWANQgjAVgbgRQgcgQARghQALgYAqAPQAoAMAFgTQAIgfAYgFQAVgEAYAPQAbAQAHAAQALAAAVgVQAPgQAXAQQAYAQARgLQAIgFAKgCQgKAqgTArQgQAMgVgDQgVgCgKgQQgQgWgMABQgQACgbAhQgLAPgOAAQgJAAgKgHg");
	this.shape_5.setTransform(438,256.4,0.333,0.277,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9661F").s().p("AgyAyQgfgTgWANQgjAVgbgQQgbgRAQggQALgYAqAOQAoAMAFgTQAIgfAYgFQAVgEAZAQQAaAPAHAAQALAAAVgVQAPgPAXAPQAYAQARgKQATgMAUAGIAAAPQAAAWgCAVQgZgbgGAZQgIAhggAEQgdAEgQgWQgQgWgMABQgQABgZAhQgMAPgOAAQgKAAgKgGg");
	this.shape_6.setTransform(437.7,251.2,0.333,0.277,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AjSAsQg0gaAUgpQAHgPAMgMQAMgLAEACQACABgLAjQgKAgAUAKQBNAkA5g3QA5g5AhAkQAXAVApAQQA6AXApgYQAkgTAJgfQAGgYAHAAQAJAAAAATQAAAUgKAUQgfA5hTgEQhHgEgjglQgQgPgCgCQgJgGgRAJQgvAjgdAPQgYAMgZAAQgcAAgfgQg");
	this.shape_7.setTransform(463.8,258.2,0.333,0.277,0,0,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AglA8QgpgQgKguQgKgxBQgMQAegEAdAFQAfAGALAOQAUAYgoAkIgrAiQgMAOgRAAQgMAAgQgGg");
	this.shape_8.setTransform(463.5,254,0.333,0.277,0,0,180);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AjMBhQADgKAGgQQANgfAUgdQBAhZBvgdQB2geA2BRQATAcABAcQAAAbgQABQgOABgJgQQgKgUgHgMQgcgwhLANQhWAQg6ApQgtAigtBEQgDAHgEADIgDABQgFAAgBgTg");
	this.shape_9.setTransform(450.2,247.1,0.333,0.277,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("ADFBzIgHgLQgthEgughQg5gphXgQQhKgNgdAwIgRAgQgJAQgNgBQgRgBAAgbQABgcAUgdQA2hQB1AeQBvAdBABZQAhAuAJAoQgBATgFAAIgCgBg");
	this.shape_10.setTransform(478.5,247.5,0.333,0.277,0,0,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjFEOQiIgYgwhIQhZiHCRiVQA6g7BQgvQBLgrA/gPQA6gOBOATQBNATBHAsQCnBpANCXQAHBNhoA+QhgA4iUAYQhLAMhGAAQhCAAg8gLg");
	this.shape_11.setTransform(463.9,258.4,0.333,0.277,0,0,180);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F6AF17").s().p("AiCL9QkZgdjshvQjYhmhIjqQg6i/AqkEQAhjQBVjIQBKivApgXQAfgRAaAjQARAXAcBKQAiBaATAlQAkBJArAkQBVBIFkgHQCYgDFvgfQCQgNA7iTQAHgRAehjQATg/AVgWQAagdAlA1QAlA1AiBxQBQEQAAFjQAAEEilCvQiVCekFBEQimAri5AAQhUAAhagJg");
	this.shape_12.setTransform(463.9,248.3,0.333,0.277,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E9661F").s().p("AhTgYQAMgLAbALQAcALARgQQAggaAdAMQAeAMgLAjQgHAZgsgIQgngHgCAVIgDANQgkghghgng");
	this.shape_13.setTransform(510.2,263.5,0.333,0.277,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E9661F").s().p("AhEA5QgTgggMgYQAKgJALgSQAQgbAcALQAhAOASgQQAfgaAeAMQAeAMgLAkQgIAYgsgIQgpgGgCAUQgCAfgUAJQgIADgKAAQgOAAgQgGg");
	this.shape_14.setTransform(513.2,258.3,0.333,0.277,0,0,180);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E9661F").s().p("AhzAFQAMAIAMgHQANgGARgeQAQgbAcAMQAfAOAUgQQAfgaAeALQAeAMgLAlQgHAXgsgIQgqgFgCATQgDAggUAJQgUAHgdgLQgdgLgHABQgKABgRAXQgBgkACgag");
	this.shape_15.setTransform(516.1,245.4,0.333,0.277,0,0,180);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E9661F").s().p("AiBgRQAJAFAEAEQATASAMgEQAPgEAWgiQAQgcAcAMQAfAOAUgQQAfgaAeAMQAdAMgKAkQgIAXgrgHQgqgGgCAUQgDAfgWAJQgSAIgdgMQgdgLgHABQgLABgRAZIgDADQgMgogKgug");
	this.shape_16.setTransform(515,252,0.333,0.277,0,0,180);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F6AF17").s().p("ALRNzQgdgUhShmQhUhnhGgzQhshOiEgMQkcgZjHBUQi4BOgzCNQgWA/gyAaQgtAXgxgOQgwgOgWgqQgYgvAXg9QAUg3Apg5IBChVQAggpAFgXQAGgegggXQgjgZgpAyQgSAWg6BlQgzBagkAiQg1Ayg4gbQg3gagMg/QgMg8AdhRQBBi0C+iJQiwhZhzi4QhkihggjCQgfi0Anh+QAoiCBcACQBaADAuBXQAlBEAPCNQAJBSALCvQANCaAdBRQAzCOBzAyQEHiBEmgEQFSgEFvCkIBbAiQBsArBXAxQEWCdgmCYQgUBTg8gLQgrgIhWhDQh1hbgYgPQhNgvgqAZQgrAZAgA7QANAYBMBiQBCBUAQAyQAXBJg6AvQgfAZgfAAQgZAAgZgRg");
	this.shape_17.setTransform(480.7,263.4,0.333,0.277,0,0,180);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AJfS5Qg6gGg3gvQghgdg7hKQhThng3grQhchIhxgKQj7gXiuBGQiaA+gkBoQgYBDgwArQgwArhAAMQg7AKg3gTQg4gUglgsQgpgxgGhCQhHAehKgkQg3gagggwQgggwgGhAIgBgbQAAhhA5huQA4htBhhgQgwgmgNgNQhchVhFh1QhaiWgmi1QgVhpAAhhIABgjQAIi3BQhcQBDhOBiADQCsAFBEC0QAnBoARD+QAIB1AGA0QALBZATA2QAcBOAyAlQBHggBNgZQgagsgRgpIgRgsQgZhOgJhSIgFg0QgDgfAAgtQAAkTBvksQAuh9A1hZQAzhXAogXQAbgPAegDQAdgCAbAKQAxASAhA1QAUAiAgBUQAaBGARAgQAbA5AdAYQAMAKAgAIQA6ARBsAFIAiABQBDADBRgDIDAgJIEwgYQA+gGAfgpQAYgiAchfQARg6AKgaQASgrAagcQAbgdAlgIQAlgJAkAOQB1AuBHE3QA7EHAAErIgCAyQgDBMgTBHQgOA2gTAsQg4CEhsBmQhsBmiXBBQC6CJAACVQAAAggIAeQgbBvhVAdQg7AUhGgeQgygWhLg6QBDBlAABQQAABWhOBAQg8AwhAAAIgRAAg");
	this.shape_18.setTransform(475.8,257.6,0.333,0.277,0,0,180);

	this.text = new cjs.Text("+5", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(823.2,327.8+incremento);

	this.text_1 = new cjs.Text("+4", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(750.2,327.8+incremento);

	this.text_2 = new cjs.Text("+3", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(679,327.8+incremento);

	this.text_3 = new cjs.Text("+2", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(605,327.8+incremento);

	this.text_4 = new cjs.Text("+1", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(533,327.8+incremento);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(467,327.8+incremento);

	this.text_6 = new cjs.Text("-1", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(390,327.8+incremento);

	this.text_7 = new cjs.Text("-2", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(316,327.8+incremento);

	this.text_8 = new cjs.Text("-3", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(244.8,327.8+incremento);

	this.text_9 = new cjs.Text("-4", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(170.8,327.8+incremento);

	this.text_10 = new cjs.Text("-5", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(98.8,327.8+incremento);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_19.setTransform(767.5,305.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_20.setTransform(695,305.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_21.setTransform(622,305.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_22.setTransform(549,305.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_23.setTransform(476,305.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_24.setTransform(403,305.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_25.setTransform(329.5,305.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_26.setTransform(257,305.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_27.setTransform(183.5,305.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_28.setTransform(840.5,305.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_29.setTransform(111,305.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_30.setTransform(475.5,305.5);
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion,this.shape_30,this.shape_29,this.shape_28,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.btn_restarnegativos,this.btn_restarpositivos);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
       this.text = new cjs.Text(txt['tit6'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_RestarPositivos("single",0);
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_1b());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_1b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
       this.text = new cjs.Text(txt['tit6'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_RestarPositivos();
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 1);
       this.text = new cjs.Text(txt['tit7'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_RestarNegativos("single",0);
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2b());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame3_2b = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
       this.text = new cjs.Text(txt['tit7'], "23px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 25;
	this.text.lineWidth = 783;
	this.text.setTransform(473.5,68.3);

	this.CdP_SumarPositivos = new lib.CdP_RestarNegativos();
	this.CdP_SumarPositivos.setTransform(471.4,319,1,1,0,0,0,377.4,36.1);

     
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame3_3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
      titulo2(this, txt['tit8'],"20px");
     texto(this,txt['text6'],0,-50);
      
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame3());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.CdP_SumarPositivos,this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
  

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   
   (lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,207,399);


(lib.CdP_TextoRestarPos = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text4'], "20px Verdana");
	this.text.lineHeight = 30;
	this.text.lineWidth = 756;
	this.text.setTransform(17.5,3.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(17.5,3.8,760.4,131.5);


(lib.CdP_TextoRestarNeg = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text3'], "20px Verdana");
	this.text.lineHeight = 30;
	this.text.lineWidth = 756;
	this.text.setTransform(17.5,3.8);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(17.5,3.8,760.4,131.5);


(lib.CdP_Gato2 = function() {
	this.initialize();

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogTgFQgfgIgFgWQgFgVAQgbIANgXQAEgJgDgIIAigBQgCARAlAeQAYAUgQAaQgSAdAMAVQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape.setTransform(58.1,17.3,0.33,0.274);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9661F").s().p("AgBBwQgYgMAPgqQAMgngUgGQgegHgFgWQgFgVAQgbQANgXACgFQACgKgIgLIAtgEQgJALAFANQAHANAaAVQAYAUgQAbQgTAcANAWQAVAjgQAbQgLASgRAAQgLAAgKgGg");
	this.shape_1.setTransform(64.7,17.1,0.33,0.274);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogUgFQgegIgFgWQgFgVAQgbIANgYQAEgJgDgIIAiABQgBAQAkAeQAYAUgQAaQgTAcANAWQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_2.setTransform(51.9,17.3,0.33,0.274);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E9661F").s().p("AhwAwQgYgQgRAKQgGAEgJADIgEgvQAKADADgNQAIghAggEQAdgEAQAWQAQAWAMgBQAQgBAbghQASgZAaAQQAfATAWgNQAjgVAbAQQAcARgRAgQgLAYgqgOQgogMgFATQgIAfgYAFQgVAEgYgQQgbgPgHAAQgLAAgVAVQgIAIgJAAQgKAAgLgIg");
	this.shape_3.setTransform(31.8,26.9,0.33,0.274);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E9661F").s().p("AhwA3IgXgOQgNgggMgoQAPgQAYACQAXABAMARQAPAWANgBQAPgCAcghQASgYAaAQQAeASAWgNQAjgUAcAQQAbAQgQAhQgMAYgqgPQgngMgGATQgHAfgYAFQgVAFgZgQQgbgQgHAAQgKAAgVAVQgJAJgKAAIgHgBg");
	this.shape_4.setTransform(32.2,32.1,0.33,0.274);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9661F").s().p("AgnAxQgfgSgWANQgjAVgbgRQgcgQARghQALgYAqAPQAoAMAFgTQAIgfAYgFQAVgEAYAPQAbAQAHAAQALAAAVgVQAPgQAXAQQAYAQARgLQAIgFAKgCQgKAqgTArQgQAMgVgDQgVgCgKgQQgQgWgMABQgQACgbAhQgLAPgOAAQgJAAgKgHg");
	this.shape_5.setTransform(83.6,31.9,0.33,0.274);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9661F").s().p("AgyAyQgfgTgWANQgjAVgbgQQgbgRAQggQALgYAqAOQAoAMAFgTQAIgfAYgFQAVgEAZAQQAaAPAHAAQALAAAVgVQAPgPAXAPQAYAQARgKQATgMAUAGIAAAPQAAAWgCAVQgZgbgGAZQgIAhggAEQgdAEgQgWQgQgWgMABQgQABgZAhQgMAPgOAAQgKAAgKgGg");
	this.shape_6.setTransform(83.9,26.8,0.33,0.274);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AjSAsQg0gaAUgpQAHgPAMgMQAMgLAEACQACABgLAjQgKAgAUAKQBNAkA5g3QA5g5AhAkQAXAVApAQQA6AXApgYQAkgTAJgfQAGgYAHAAQAJAAAAATQAAAUgKAUQgfA5hTgEQhHgEgjglQgQgPgCgCQgJgGgRAJQgvAjgdAPQgYAMgZAAQgcAAgfgQg");
	this.shape_7.setTransform(58,33.7,0.33,0.274);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AglA8QgpgQgKguQgKgxBQgMQAegEAdAFQAfAGALAOQAUAYgoAkIgrAiQgMAOgRAAQgMAAgQgGg");
	this.shape_8.setTransform(58.3,29.6,0.33,0.274);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AjMBhQADgKAGgQQANgfAUgdQBAhZBvgdQB2geA2BRQATAcABAcQAAAbgQABQgOABgJgQQgKgUgHgMQgcgwhLANQhWAQg6ApQgtAigtBEQgDAHgEADIgDABQgFAAgBgTg");
	this.shape_9.setTransform(71.5,22.8,0.33,0.274);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("ADFBzIgHgLQgthEgughQg5gphXgQQhKgNgdAwIgRAgQgJAQgNgBQgRgBAAgbQABgcAUgdQA2hQB1AeQBvAdBABZQAhAuAJAoQgBATgFAAIgCgBg");
	this.shape_10.setTransform(43.4,23.1,0.33,0.274);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjFEOQiIgYgwhIQhZiHCRiVQA6g7BQgvQBLgrA/gPQA6gOBOATQBNATBHAsQCnBpANCXQAHBNhoA+QhgA4iUAYQhLAMhGAAQhCAAg8gLg");
	this.shape_11.setTransform(57.9,33.9,0.33,0.274);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F6AF17").s().p("AiCL9QkZgdjshvQjYhmhIjqQg6i/AqkEQAhjQBVjIQBKivApgXQAfgRAaAjQARAXAcBKQAiBaATAlQAkBJArAkQBVBIFkgHQCYgDFvgfQCQgNA7iTQAHgRAehjQATg/AVgWQAagdAlA1QAlA1AiBxQBQEQAAFjQAAEEilCvQiVCekFBEQimAri5AAQhUAAhagJg");
	this.shape_12.setTransform(58,23.9,0.33,0.274);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E9661F").s().p("AhTgYQAMgLAbALQAcALARgQQAggaAdAMQAeAMgLAjQgHAZgsgIQgngHgCAVIgDANQgkghghgng");
	this.shape_13.setTransform(11.9,39,0.33,0.274);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E9661F").s().p("AhEA5QgTgggMgYQAKgJALgSQAQgbAcALQAhAOASgQQAfgaAeAMQAeAMgLAkQgIAYgsgIQgpgGgCAUQgCAfgUAJQgIADgKAAQgOAAgQgGg");
	this.shape_14.setTransform(9,33.8,0.33,0.274);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E9661F").s().p("AhzAFQAMAIAMgHQANgGARgeQAQgbAcAMQAfAOAUgQQAfgaAeALQAeAMgLAlQgHAXgsgIQgqgFgCATQgDAggUAJQgUAHgdgLQgdgLgHABQgKABgRAXQgBgkACgag");
	this.shape_15.setTransform(6.1,21.1,0.33,0.274);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E9661F").s().p("AiBgRQAJAFAEAEQATASAMgEQAPgEAWgiQAQgcAcAMQAfAOAUgQQAfgaAeAMQAdAMgKAkQgIAXgrgHQgqgGgCAUQgDAfgWAJQgSAIgdgMQgdgLgHABQgLABgRAZIgDADQgMgogKgug");
	this.shape_16.setTransform(7.2,27.5,0.33,0.274);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F6AF17").s().p("ALRNzQgdgUhShmQhUhnhGgzQhshOiEgMQkcgZjHBUQi4BOgzCNQgWA/gyAaQgtAXgxgOQgwgOgWgqQgYgvAXg9QAUg3Apg5IBChVQAggpAFgXQAGgegggXQgjgZgpAyQgSAWg6BlQgzBagkAiQg1Ayg4gbQg3gagMg/QgMg8AdhRQBBi0C+iJQiwhZhzi4QhkihggjCQgfi0Anh+QAoiCBcACQBaADAuBXQAlBEAPCNQAJBSALCvQANCaAdBRQAzCOBzAyQEHiBEmgEQFSgEFvCkIBbAiQBsArBXAxQEWCdgmCYQgUBTg8gLQgrgIhWhDQh1hbgYgPQhNgvgqAZQgrAZAgA7QANAYBMBiQBCBUAQAyQAXBJg6AvQgfAZgfAAQgZAAgZgRg");
	this.shape_17.setTransform(41.2,38.9,0.33,0.274);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AJfS5Qg6gGg3gvQghgdg7hKQhThng3grQhchIhxgKQj7gXiuBGQiaA+gkBoQgYBDgwArQgwArhAAMQg7AKg3gTQg4gUglgsQgpgxgGhCQhHAehKgkQg3gagggwQgggwgGhAIgBgbQAAhhA5huQA4htBhhgQgwgmgNgNQhchVhFh1QhaiWgmi1QgVhpAAhhIABgjQAIi3BQhcQBDhOBiADQCsAFBEC0QAnBoARD+QAIB1AGA0QALBZATA2QAcBOAyAlQBHggBNgZQgagsgRgpIgRgsQgZhOgJhSIgFg0QgDgfAAgtQAAkTBvksQAuh9A1hZQAzhXAogXQAbgPAegDQAdgCAbAKQAxASAhA1QAUAiAgBUQAaBGARAgQAbA5AdAYQAMAKAgAIQA6ARBsAFIAiABQBDADBRgDIDAgJIEwgYQA+gGAfgpQAYgiAchfQARg6AKgaQASgrAagcQAbgdAlgIQAlgJAkAOQB1AuBHE3QA7EHAAErIgCAyQgDBMgTBHQgOA2gTAsQg4CEhsBmQhsBmiXBBQC6CJAACVQAAAggIAeQgbBvhVAdQg7AUhGgeQgygWhLg6QBDBlAABQQAABWhOBAQg8AwhAAAIgRAAg");
	this.shape_18.setTransform(46.1,33.1,0.33,0.274);

	this.addChild(this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,0,94.2,66.2);


(lib.CdP_Gato = function() {
	this.initialize();

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogTgFQgfgIgFgWQgFgVAQgbIANgXQAEgJgDgIIAigBQgCARAlAeQAYAUgQAaQgSAdAMAVQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape.setTransform(34.1,17.3,0.33,0.274,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9661F").s().p("AgBBwQgYgMAPgqQAMgngUgGQgegHgFgWQgFgVAQgbQANgXACgFQACgKgIgLIAtgEQgJALAFANQAHANAaAVQAYAUgQAbQgTAcANAWQAVAjgQAbQgLASgRAAQgLAAgKgGg");
	this.shape_1.setTransform(27.5,17.1,0.33,0.274,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogUgFQgegIgFgWQgFgVAQgbIANgYQAEgJgDgIIAiABQgBAQAkAeQAYAUgQAaQgTAcANAWQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_2.setTransform(40.3,17.3,0.33,0.274,0,0,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E9661F").s().p("AhwAwQgYgQgRAKQgGAEgJADIgEgvQAKADADgNQAIghAggEQAdgEAQAWQAQAWAMgBQAQgBAbghQASgZAaAQQAfATAWgNQAjgVAbAQQAcARgRAgQgLAYgqgOQgogMgFATQgIAfgYAFQgVAEgYgQQgbgPgHAAQgLAAgVAVQgIAIgJAAQgKAAgLgIg");
	this.shape_3.setTransform(60.4,26.9,0.33,0.274,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E9661F").s().p("AhwA3IgXgOQgNgggMgoQAPgQAYACQAXABAMARQAPAWANgBQAPgCAcghQASgYAaAQQAeASAWgNQAjgUAcAQQAbAQgQAhQgMAYgqgPQgngMgGATQgHAfgYAFQgVAFgZgQQgbgQgHAAQgKAAgVAVQgJAJgKAAIgHgBg");
	this.shape_4.setTransform(60,32.1,0.33,0.274,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9661F").s().p("AgnAxQgfgSgWANQgjAVgbgRQgcgQARghQALgYAqAPQAoAMAFgTQAIgfAYgFQAVgEAYAPQAbAQAHAAQALAAAVgVQAPgQAXAQQAYAQARgLQAIgFAKgCQgKAqgTArQgQAMgVgDQgVgCgKgQQgQgWgMABQgQACgbAhQgLAPgOAAQgJAAgKgHg");
	this.shape_5.setTransform(8.6,31.9,0.33,0.274,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9661F").s().p("AgyAyQgfgTgWANQgjAVgbgQQgbgRAQggQALgYAqAOQAoAMAFgTQAIgfAYgFQAVgEAZAQQAaAPAHAAQALAAAVgVQAPgPAXAPQAYAQARgKQATgMAUAGIAAAPQAAAWgCAVQgZgbgGAZQgIAhggAEQgdAEgQgWQgQgWgMABQgQABgZAhQgMAPgOAAQgKAAgKgGg");
	this.shape_6.setTransform(8.3,26.8,0.33,0.274,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AjSAsQg0gaAUgpQAHgPAMgMQAMgLAEACQACABgLAjQgKAgAUAKQBNAkA5g3QA5g5AhAkQAXAVApAQQA6AXApgYQAkgTAJgfQAGgYAHAAQAJAAAAATQAAAUgKAUQgfA5hTgEQhHgEgjglQgQgPgCgCQgJgGgRAJQgvAjgdAPQgYAMgZAAQgcAAgfgQg");
	this.shape_7.setTransform(34.2,33.7,0.33,0.274,0,0,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AglA8QgpgQgKguQgKgxBQgMQAegEAdAFQAfAGALAOQAUAYgoAkIgrAiQgMAOgRAAQgMAAgQgGg");
	this.shape_8.setTransform(33.9,29.6,0.33,0.274,0,0,180);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AjMBhQADgKAGgQQANgfAUgdQBAhZBvgdQB2geA2BRQATAcABAcQAAAbgQABQgOABgJgQQgKgUgHgMQgcgwhLANQhWAQg6ApQgtAigtBEQgDAHgEADIgDABQgFAAgBgTg");
	this.shape_9.setTransform(20.7,22.8,0.33,0.274,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("ADFBzIgHgLQgthEgughQg5gphXgQQhKgNgdAwIgRAgQgJAQgNgBQgRgBAAgbQABgcAUgdQA2hQB1AeQBvAdBABZQAhAuAJAoQgBATgFAAIgCgBg");
	this.shape_10.setTransform(48.8,23.1,0.33,0.274,0,0,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjFEOQiIgYgwhIQhZiHCRiVQA6g7BQgvQBLgrA/gPQA6gOBOATQBNATBHAsQCnBpANCXQAHBNhoA+QhgA4iUAYQhLAMhGAAQhCAAg8gLg");
	this.shape_11.setTransform(34.3,33.9,0.33,0.274,0,0,180);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F6AF17").s().p("AiCL9QkZgdjshvQjYhmhIjqQg6i/AqkEQAhjQBVjIQBKivApgXQAfgRAaAjQARAXAcBKQAiBaATAlQAkBJArAkQBVBIFkgHQCYgDFvgfQCQgNA7iTQAHgRAehjQATg/AVgWQAagdAlA1QAlA1AiBxQBQEQAAFjQAAEEilCvQiVCekFBEQimAri5AAQhUAAhagJg");
	this.shape_12.setTransform(34.2,23.9,0.33,0.274,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E9661F").s().p("AhTgYQAMgLAbALQAcALARgQQAggaAdAMQAeAMgLAjQgHAZgsgIQgngHgCAVIgDANQgkghghgng");
	this.shape_13.setTransform(80.3,39,0.33,0.274,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E9661F").s().p("AhEA5QgTgggMgYQAKgJALgSQAQgbAcALQAhAOASgQQAfgaAeAMQAeAMgLAkQgIAYgsgIQgpgGgCAUQgCAfgUAJQgIADgKAAQgOAAgQgGg");
	this.shape_14.setTransform(83.2,33.8,0.33,0.274,0,0,180);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#E9661F").s().p("AhzAFQAMAIAMgHQANgGARgeQAQgbAcAMQAfAOAUgQQAfgaAeALQAeAMgLAlQgHAXgsgIQgqgFgCATQgDAggUAJQgUAHgdgLQgdgLgHABQgKABgRAXQgBgkACgag");
	this.shape_15.setTransform(86.1,21.1,0.33,0.274,0,0,180);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E9661F").s().p("AiBgRQAJAFAEAEQATASAMgEQAPgEAWgiQAQgcAcAMQAfAOAUgQQAfgaAeAMQAdAMgKAkQgIAXgrgHQgqgGgCAUQgDAfgWAJQgSAIgdgMQgdgLgHABQgLABgRAZIgDADQgMgogKgug");
	this.shape_16.setTransform(85,27.5,0.33,0.274,0,0,180);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F6AF17").s().p("ALRNzQgdgUhShmQhUhnhGgzQhshOiEgMQkcgZjHBUQi4BOgzCNQgWA/gyAaQgtAXgxgOQgwgOgWgqQgYgvAXg9QAUg3Apg5IBChVQAggpAFgXQAGgegggXQgjgZgpAyQgSAWg6BlQgzBagkAiQg1Ayg4gbQg3gagMg/QgMg8AdhRQBBi0C+iJQiwhZhzi4QhkihggjCQgfi0Anh+QAoiCBcACQBaADAuBXQAlBEAPCNQAJBSALCvQANCaAdBRQAzCOBzAyQEHiBEmgEQFSgEFvCkIBbAiQBsArBXAxQEWCdgmCYQgUBTg8gLQgrgIhWhDQh1hbgYgPQhNgvgqAZQgrAZAgA7QANAYBMBiQBCBUAQAyQAXBJg6AvQgfAZgfAAQgZAAgZgRg");
	this.shape_17.setTransform(51,38.9,0.33,0.274,0,0,180);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AJfS5Qg6gGg3gvQghgdg7hKQhThng3grQhchIhxgKQj7gXiuBGQiaA+gkBoQgYBDgwArQgwArhAAMQg7AKg3gTQg4gUglgsQgpgxgGhCQhHAehKgkQg3gagggwQgggwgGhAIgBgbQAAhhA5huQA4htBhhgQgwgmgNgNQhchVhFh1QhaiWgmi1QgVhpAAhhIABgjQAIi3BQhcQBDhOBiADQCsAFBEC0QAnBoARD+QAIB1AGA0QALBZATA2QAcBOAyAlQBHggBNgZQgagsgRgpIgRgsQgZhOgJhSIgFg0QgDgfAAgtQAAkTBvksQAuh9A1hZQAzhXAogXQAbgPAegDQAdgCAbAKQAxASAhA1QAUAiAgBUQAaBGARAgQAbA5AdAYQAMAKAgAIQA6ARBsAFIAiABQBDADBRgDIDAgJIEwgYQA+gGAfgpQAYgiAchfQARg6AKgaQASgrAagcQAbgdAlgIQAlgJAkAOQB1AuBHE3QA7EHAAErIgCAyQgDBMgTBHQgOA2gTAsQg4CEhsBmQhsBmiXBBQC6CJAACVQAAAggIAeQgbBvhVAdQg7AUhGgeQgygWhLg6QBDBlAABQQAABWhOBAQg8AwhAAAIgRAAg");
	this.shape_18.setTransform(46.1,33.1,0.33,0.274,0,0,180);

	this.addChild(this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-0.9,0,94.2,66.2);


(lib.btn_restarpositivos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("La resta de\nnúmeros positivos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 196;
	this.text.setTransform(98.6,1.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape.setTransform(101.1,24.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_1.setTransform(101.1,24.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_2.setTransform(101.1,24.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.1,49.5);


(lib.btn_restarnegativos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("La resta de\nnúmeros negativos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 197;
	this.text.setTransform(99,2.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape.setTransform(101.1,24.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_1.setTransform(101.1,24.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_2.setTransform(101.1,24.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.1,49.5);


(lib.CdP_TextoSumar = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text('Para sumar (+3) + (+2), hay que partir del cero (0) y recorrer la distancia hasta el +3. Luego, avanzar dos unidades a la derecha, hasta el +5. \nEste será el resultado de la suma.', "20px Verdana");
	this.text.lineHeight = 32;
	this.text.lineWidth = 780;
	this.text.setTransform(15.2,0);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(15.2,0,783.8,79.9);


(lib.CdP_TextoRestar = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text(txt['text2'], "20px Verdana");
	this.text.lineHeight = 32;
	this.text.lineWidth = 737;
	this.text.setTransform(23.2,0);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(23.2,0,740.6,79.9);


(lib.CdP_Perro2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAUQgMgGgDgOQgEgPAPgGQAOgGAMARQALAMgGALQgDAFgFADQgFADgFAAQgEAAgFgEg");
	this.shape.setTransform(45.5,14.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgFQgGgLALgMQAMgRAOAGQAPAGgDAPQgEAOgLAGQgGAEgEAAQgFAAgFgDg");
	this.shape_1.setTransform(36.4,13.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAfAOQgPgLgIgDQgGgDgGAGQgKAMgWABQgZABgKgRQgJgRAJAAQACAAACAHQADAKALAEQAMAIASgHQAMgFAHgFQAJgLARAQQASAQAXgLQAGgDgDgIIgDgLQAaASgZAMQgJAFgJAAQgHAAgIgEg");
	this.shape_2.setTransform(40.7,31);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgFAQQgHgFgGgGQgMgKAGgHQAIgJAWADQAYAEgDAOQgDANgNAFQgFACgDAAQgEAAgEgEg");
	this.shape_3.setTransform(40.5,26.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AA5AfQgOgVgNgKQgSgLgZgFQgWgEgJAPQgJANgDAAQgFAAAAgIQAAgIAHgJQAQgYAjAJQAhAJATAaQAKAOADAMQAAAGgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBgBgBg");
	this.shape_4.setTransform(28.3,18.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag9AdIANgaQATgaAhgJQAkgJAQAZQAGAIAAAIQAAAIgFAAQgDAAgJgNQgJgOgWAEQgZAFgSAKQgOALgNAUQgCAEgBAAQgCAAAAgGg");
	this.shape_5.setTransform(54.2,19.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVBRQgtgHgegRQgfgTACgXQAEgtAzggQAwgeAlAJQAuALAmAnQAsAsgbAqQgWAhhAAAQgYAAgbgFg");
	this.shape_6.setTransform(40.8,31.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D06F1A").s().p("AkgAHQgGhlBbgxQBLgpCAAAQB8AABOAsQBbAygEBeQgDBchkAyQhPAnhmAAQkbAAgKiyg");
	this.shape_7.setTransform(41,24);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgSAcQgKgLgGgPQgKgdAZgUQATgPAlALQAEAzgUA4QgTgGgUgWg");
	this.shape_8.setTransform(88.4,21.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AglAPQgHgIgCgJQgGgVATgMQAWgPAjAaQAlAYgTAUQgTAVgTAAQgUAAgVgag");
	this.shape_9.setTransform(69.5,43.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgxAnQgdADgYANQgCgiAOgXQASgjAugPQA+gVAnAuQAjAngIAwQg9gdhaAIg");
	this.shape_10.setTransform(54.7,48.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D06F1A").s().p("Aj9EKQgcgXArg3QAXgdAEgIQAKgSgNgHQgNgIgYAOIgrAhQg1ApgKgoQgMguBVgwQAqgYAtgPQBwgwBlABQBaABBQAmQAjgPAPgqQAJgZAEgvIAGhOQAKhaAwgBQAcgBAMAoQAMAmgKA3QgXCKhqA0QA6AqAUA3QATA1giARQgbANghg6QgRgfgGgHQgNgPgKAIQgQALATAZQAgAnAHAUQAOAogkAKQgkALgOgpQgQgrg4gXQg8gahVAIQhAAGg5BEQgZAfgIAGQgIAGgIAAQgJAAgKgIg");
	this.shape_11.setTransform(56.2,36.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAjA8QgLgFgXgXQgSgTgMgDQgSgEgQAWIgYgRIAVglQAcgmAigBQAogBAiAzQAjAxgfAaQgKAGgKAAQgKAAgJgGg");
	this.shape_12.setTransform(69,9.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhJA8QgfgaAjgxQAigzAoABQAiABAcAmQAOAUAHARIgYARQgQgWgSAEQgMACgSAUQgYAXgKAFQgKAGgJAAQgKAAgKgGg");
	this.shape_13.setTransform(11.3,9.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ai0FAQgWgSAAgZQAAgfAnguIADgEIgTAPQgdAWgNAHQgXAMgSgHQgXgHgIggQgCgKAAgHQAAgyBHgtQhQgZgng2QgegpgEg6IAAgNQAAgrAQgiQgVARgRAFQgZAHgXgPIgDgCQgRgOgEgVQgEgWAJgYQANgjAfgaQAigdAiABQA2AAAmBBQBOgkB4AAQBqAABOAgQAng9AzAAQAigBAiAdQAfAaANAjQAJAYgEAWQgEAVgRAOIgBABIgCABQgfAUgggSQALAdAAAiIAAAHQgDA5ghApQAbAHAfAOQAUgNAIgYQAJgZAFhIQAFhKAMggQATg1AxgBQAbgBATAVQAWAZAEAxIABAOIgBAdIgFAeQgFAZgHAVQgeBXhEAxQAfAdASAiQASAiAAAdIgBAIQgDAlggAQQgYALgWgMIAAABQAAAVgOARQgKAMgQAGQgQAFgQgDQgmgHgOgoQgLgegqgUIgOgFIgGgCIgBgBIgGgBIgBgBIgQgEIgagEIgQgBIgDAAIgeAAIguAGIgCABIgCABIgOAGQgdAPgiAsQgSAVgKAJQgPANgRACIgEAAQgSAAgRgNg");
	this.shape_14.setTransform(47.4,33.4);

	this.addChild(this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,94.7,66.7);


(lib.CdP_Perro = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAUQgMgGgDgOQgEgPAPgGQAOgGAMARQALAMgGALQgDAFgFADQgFADgFAAQgEAAgFgEg");
	this.shape.setTransform(49.2,14.1,1,1,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgFQgGgLALgMQAMgRAOAGQAPAGgDAPQgEAOgLAGQgGAEgEAAQgFAAgFgDg");
	this.shape_1.setTransform(58.3,13.6,1,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAfAOQgPgLgIgDQgGgDgGAGQgKAMgWABQgZABgKgRQgJgRAJAAQACAAACAHQADAKALAEQAMAIASgHQAMgFAHgFQAJgLARAQQASAQAXgLQAGgDgDgIIgDgLQAaASgZAMQgJAFgJAAQgHAAgIgEg");
	this.shape_2.setTransform(54,31,1,1,0,0,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgFAQQgHgFgGgGQgMgKAGgHQAIgJAWADQAYAEgDAOQgDANgNAFQgFACgDAAQgEAAgEgEg");
	this.shape_3.setTransform(54.2,26.5,1,1,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AA5AfQgOgVgNgKQgSgLgZgFQgWgEgJAPQgJANgDAAQgFAAAAgIQAAgIAHgJQAQgYAjAJQAhAJATAaQAKAOADAMQAAAGgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBgBgBg");
	this.shape_4.setTransform(66.5,18.9,1,1,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag9AdIANgaQATgaAhgJQAkgJAQAZQAGAIAAAIQAAAIgFAAQgDAAgJgNQgJgOgWAEQgZAFgSAKQgOALgNAUQgCAEgBAAQgCAAAAgGg");
	this.shape_5.setTransform(40.5,19.3,1,1,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgVBRQgtgHgegRQgfgTACgXQAEgtAzggQAwgeAlAJQAuALAmAnQAsAsgbAqQgWAhhAAAQgYAAgbgFg");
	this.shape_6.setTransform(53.9,31.3,1,1,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D06F1A").s().p("AkgAHQgGhlBbgxQBLgpCAAAQB8AABOAsQBbAygEBeQgDBchkAyQhPAnhmAAQkbAAgKiyg");
	this.shape_7.setTransform(53.7,24,1,1,0,0,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgSAcQgKgLgGgPQgKgdAZgUQATgPAlALQAEAzgUA4QgTgGgUgWg");
	this.shape_8.setTransform(6.3,21.8,1,1,0,0,180);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AglAPQgHgIgCgJQgGgVATgMQAWgPAjAaQAlAYgTAUQgTAVgTAAQgUAAgVgag");
	this.shape_9.setTransform(25.2,43.4,1,1,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgxAnQgdADgYANQgCgiAOgXQASgjAugPQA+gVAnAuQAjAngIAwQg9gdhaAIg");
	this.shape_10.setTransform(40,48.6,1,1,0,0,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#D06F1A").s().p("Aj9EKQgcgXArg3QAXgdAEgIQAKgSgNgHQgNgIgYAOIgrAhQg1ApgKgoQgMguBVgwQAqgYAtgPQBwgwBlABQBaABBQAmQAjgPAPgqQAJgZAEgvIAGhOQAKhaAwgBQAcgBAMAoQAMAmgKA3QgXCKhqA0QA6AqAUA3QATA1giARQgbANghg6QgRgfgGgHQgNgPgKAIQgQALATAZQAgAnAHAUQAOAogkAKQgkALgOgpQgQgrg4gXQg8gahVAIQhAAGg5BEQgZAfgIAGQgIAGgIAAQgJAAgKgIg");
	this.shape_11.setTransform(38.5,36.8,1,1,0,0,180);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAjA8QgLgFgXgXQgSgTgMgDQgSgEgQAWIgYgRIAVglQAcgmAigBQAogBAiAzQAjAxgfAaQgKAGgKAAQgKAAgJgGg");
	this.shape_12.setTransform(25.7,9.1,1,1,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhJA8QgfgaAjgxQAigzAoABQAiABAcAmQAOAUAHARIgYARQgQgWgSAEQgMACgSAUQgYAXgKAFQgKAGgJAAQgKAAgKgGg");
	this.shape_13.setTransform(83.4,9.1,1,1,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ai0FAQgWgSAAgZQAAgfAnguIADgEIgTAPQgdAWgNAHQgXAMgSgHQgXgHgIggQgCgKAAgHQAAgyBHgtQhQgZgng2QgegpgEg6IAAgNQAAgrAQgiQgVARgRAFQgZAHgXgPIgDgCQgRgOgEgVQgEgWAJgYQANgjAfgaQAigdAiABQA2AAAmBBQBOgkB4AAQBqAABOAgQAng9AzAAQAigBAiAdQAfAaANAjQAJAYgEAWQgEAVgRAOIgBABIgCABQgfAUgggSQALAdAAAiIAAAHQgDA5ghApQAbAHAfAOQAUgNAIgYQAJgZAFhIQAFhKAMggQATg1AxgBQAbgBATAVQAWAZAEAxIABAOIgBAdIgFAeQgFAZgHAVQgeBXhEAxQAfAdASAiQASAiAAAdIgBAIQgDAlggAQQgYALgWgMIAAABQAAAVgOARQgKAMgQAGQgQAFgQgDQgmgHgOgoQgLgegqgUIgOgFIgGgCIgBgBIgGgBIgBgBIgQgEIgagEIgQgBIgDAAIgeAAIguAGIgCABIgCABIgOAGQgdAPgiAsQgSAVgKAJQgPANgRACIgEAAQgSAAgRgNg");
	this.shape_14.setTransform(47.3,33.4,1,1,0,0,180);

	this.addChild(this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,94.7,66.7);


(lib.CdP_FlechaVerde2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#339933").ss(4).p("Ag8g3IB5Bv");
	this.shape.setTransform(94.7,6.7,1,1,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#339933").ss(4).p("AAyhEIhjCK");
	this.shape_1.setTransform(104.1,7,1,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#339933").ss(4).p("Ah1DqQA5AOA8AAQDPAACSiXQCTiWAAjWAlsBVQAGAGAGAGQBnBqCEAfAnzkLQAADOCHCS");
	this.shape_2.setTransform(50,27.5);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,52.3);


(lib.CdP_FlechaVerde = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#339933").ss(4).p("Ag8g3IB5Bv");
	this.shape.setTransform(14.4,6.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#339933").ss(4).p("AAyhEIhjCK");
	this.shape_1.setTransform(5,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#339933").ss(4).p("AH0kLQAADWiTCWQiSCXjPAAQjNAAiTiXQiSiWAAjW");
	this.shape_2.setTransform(59.1,27.5);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,52.3);


(lib.CdP_FlechaRoja2 = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(4).p("Ag8g3IB5Bv");
	this.shape.setTransform(94.7,6.7,1,1,0,0,180);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(4).p("AAyhEIhjCK");
	this.shape_1.setTransform(104.1,7,1,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(4).p("AH0kLQAADWiTCWQiSCXjPAAQjNAAiTiXQiSiWAAjW");
	this.shape_2.setTransform(50,27.5,1,1,0,0,180);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,52.3);


(lib.CdP_FlechaRoja = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(4).p("Ag8g3IB5Bv");
	this.shape.setTransform(14.4,6.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(4).p("AAyhEIhjCK");
	this.shape_1.setTransform(5,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(4).p("AH0kLQAADWiTCWQiSCXjPAAQjNAAiTiXQiSiWAAjW");
	this.shape_2.setTransform(59.1,27.5);

	this.addChild(this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,109.1,52.3);


(lib.btn_sumarpositivos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("La suma de\nnúmeros positivos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 196;
	this.text.setTransform(98.6,1.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape.setTransform(101.1,24.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_1.setTransform(101.1,24.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_2.setTransform(101.1,24.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.1,49.5);


(lib.btn_sumarnegativos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("La resta de\nnúmeros negativos", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 197;
	this.text.setTransform(99,2.6+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape.setTransform(101.1,24.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_1.setTransform(101.1,24.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-101.05,-24.75,202.1,49.5,6);
	this.shape_2.setTransform(101.1,24.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.1,49.5);


(lib.btn_suma = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Suma de números enteros", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 255;
	this.text.setTransform(127.8,2.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-130,-15,260,30,6);
	this.shape.setTransform(130,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-130,-15,260,30,6);
	this.shape_1.setTransform(130,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-130,-15,260,30,6);
	this.shape_2.setTransform(130,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,30);


(lib.btn_resta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("Resta de números enteros", "bold 16px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 255;
	this.text.setTransform(127.7,3.2+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#1D1D1B").rr(-130,-15,260,30,6);
	this.shape.setTransform(130,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#1D1D1B").rr(-130,-15,260,30,6);
	this.shape_1.setTransform(130,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").rr(-130,-15,260,30,6);
	this.shape_2.setTransform(130,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.shape_1},{t:this.text,p:{color:"#000000"}}]},1).to({state:[{t:this.shape_2},{t:this.text,p:{color:"#FFFFFF"}}]},1).to({state:[{t:this.shape},{t:this.text,p:{color:"#000000"}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,260,30);


(lib.CdP_RestarPositivos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	
	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(2.5).p("AAUAAIgnAA");
	this.shape.setTransform(525.9,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(2.5).p("AgnAAIBPAA");
	this.shape_1.setTransform(524,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(2.5).p("Ag6AAIB1AA");
	this.shape_2.setTransform(522,22.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D91729").ss(2.5).p("AhNAAICbAA");
	this.shape_3.setTransform(520.1,22.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D91729").ss(2.5).p("AhhAAIDDAA");
	this.shape_4.setTransform(518.2,22.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D91729").ss(2.5).p("Ah0AAIDpAA");
	this.shape_5.setTransform(516.2,22.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D91729").ss(2.5).p("AiIAAIERAA");
	this.shape_6.setTransform(514.3,22.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D91729").ss(2.5).p("AibAAIE3AA");
	this.shape_7.setTransform(512.3,22.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D91729").ss(2.5).p("AiuAAIFdAA");
	this.shape_8.setTransform(510.4,22.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D91729").ss(2.5).p("AjCAAIGFAA");
	this.shape_9.setTransform(508.5,22.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D91729").ss(2.5).p("AjVAAIGrAA");
	this.shape_10.setTransform(506.5,22.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D91729").ss(2.5).p("AjpAAIHTAA");
	this.shape_11.setTransform(504.6,22.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D91729").ss(2.5).p("Aj8AAIH5AA");
	this.shape_12.setTransform(502.6,22.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D91729").ss(2.5).p("AkPAAIIfAA");
	this.shape_13.setTransform(500.7,22.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D91729").ss(2.5).p("AkjAAIJHAA");
	this.shape_14.setTransform(498.8,22.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D91729").ss(2.5).p("Ak2AAIJtAA");
	this.shape_15.setTransform(496.8,22.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D91729").ss(2.5).p("AlKAAIKVAA");
	this.shape_16.setTransform(494.9,22.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D91729").ss(2.5).p("AldAAIK7AA");
	this.shape_17.setTransform(492.9,22.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D91729").ss(2.5).p("AFyAAIrjAA");
	this.shape_18.setTransform(491,22.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D91729").ss(2.5).p("AmFAAIMLAA");
	this.shape_19.setTransform(489,22.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D91729").ss(2.5).p("AmZAAIMzAA");
	this.shape_20.setTransform(486.9,22.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D91729").ss(2.5).p("AmtAAINbAA");
	this.shape_21.setTransform(484.9,22.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D91729").ss(2.5).p("AnCAAIOFAA");
	this.shape_22.setTransform(482.9,22.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D91729").ss(2.5).p("AnWAAIOtAA");
	this.shape_23.setTransform(480.9,22.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D91729").ss(2.5).p("AnqAAIPVAA");
	this.shape_24.setTransform(478.8,22.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D91729").ss(2.5).p("An+AAIP9AA");
	this.shape_25.setTransform(476.8,22.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D91729").ss(2.5).p("AoTAAIQnAA");
	this.shape_26.setTransform(474.8,22.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D91729").ss(2.5).p("AonAAIRPAA");
	this.shape_27.setTransform(472.8,22.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D91729").ss(2.5).p("Ao7AAIR3AA");
	this.shape_28.setTransform(470.7,22.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D91729").ss(2.5).p("ApQAAIShAA");
	this.shape_29.setTransform(468.7,22.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D91729").ss(2.5).p("ApkAAITJAA");
	this.shape_30.setTransform(466.7,22.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D91729").ss(2.5).p("Ap4AAITxAA");
	this.shape_31.setTransform(464.6,22.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D91729").ss(2.5).p("AqMAAIUZAA");
	this.shape_32.setTransform(462.6,22.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D91729").ss(2.5).p("AqhAAIVDAA");
	this.shape_33.setTransform(460.6,22.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D91729").ss(2.5).p("Aq1AAIVrAA");
	this.shape_34.setTransform(458.6,22.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D91729").ss(2.5).p("ArJAAIWTAA");
	this.shape_35.setTransform(456.5,22.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D91729").ss(2.5).p("ALfAAI29AA");
	this.shape_36.setTransform(454.5,22.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#D91729").ss(2.5).p("AryAAIXlAA");
	this.shape_37.setTransform(452.5,22.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#D91729").ss(2.5).p("AsGAAIYNAA");
	this.shape_38.setTransform(450.4,22.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#D91729").ss(2.5).p("AsaAAIY1AA");
	this.shape_39.setTransform(448.4,22.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#D91729").ss(2.5).p("AsvAAIZfAA");
	this.shape_40.setTransform(446.4,22.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#D91729").ss(2.5).p("AtDAAIaHAA");
	this.shape_41.setTransform(444.4,22.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#D91729").ss(2.5).p("AtXAAIavAA");
	this.shape_42.setTransform(442.3,22.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#D91729").ss(2.5).p("AtrAAIbXAA");
	this.shape_43.setTransform(440.3,22.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#D91729").ss(2.5).p("AuAAAIcBAA");
	this.shape_44.setTransform(438.3,22.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D91729").ss(2.5).p("AuUAAIcpAA");
	this.shape_45.setTransform(436.3,22.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D91729").ss(2.5).p("AuoAAIdRAA");
	this.shape_46.setTransform(434.2,22.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#D91729").ss(2.5).p("Au9AAId7AA");
	this.shape_47.setTransform(432.2,22.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#D91729").ss(2.5).p("AvRAAIejAA");
	this.shape_48.setTransform(430.2,22.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#D91729").ss(2.5).p("AvlAAIfLAA");
	this.shape_49.setTransform(428.1,22.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#D91729").ss(2.5).p("Av5AAIfzAA");
	this.shape_50.setTransform(426.1,22.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#D91729").ss(2.5).p("AwOAAMAgdAAA");
	this.shape_51.setTransform(424.1,22.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#D91729").ss(2.5).p("AwiAAMAhFAAA");
	this.shape_52.setTransform(422.1,22.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#D91729").ss(2.5).p("Aw2AAMAhtAAA");
	this.shape_53.setTransform(420,22.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#D91729").ss(2.5).p("ARMAAMgiXAAA");
	this.shape_54.setTransform(418,22.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#D91729").ss(2.5).p("AxfAAMAi/AAA");
	this.shape_55.setTransform(416,22.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#D91729").ss(2.5).p("AxzAAMAjnAAA");
	this.shape_56.setTransform(414,22.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#D91729").ss(2.5).p("AyHAAMAkPAAA");
	this.shape_57.setTransform(411.9,22.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#D91729").ss(2.5).p("AybAAMAk3AAA");
	this.shape_58.setTransform(409.9,22.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#D91729").ss(2.5).p("AywAAMAlhAAA");
	this.shape_59.setTransform(407.9,22.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#D91729").ss(2.5).p("AzEAAMAmJAAA");
	this.shape_60.setTransform(405.9,22.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#D91729").ss(2.5).p("AzYAAMAmxAAA");
	this.shape_61.setTransform(403.9,22.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#D91729").ss(2.5).p("AzsAAMAnZAAA");
	this.shape_62.setTransform(401.8,22.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#D91729").ss(2.5).p("A0AAAMAoBAAA");
	this.shape_63.setTransform(399.8,22.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#D91729").ss(2.5).p("A0VAAMAorAAA");
	this.shape_64.setTransform(397.8,22.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#D91729").ss(2.5).p("A0pAAMApTAAA");
	this.shape_65.setTransform(395.8,22.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#D91729").ss(2.5).p("A09AAMAp7AAA");
	this.shape_66.setTransform(393.8,22.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#D91729").ss(2.5).p("A1RAAMAqjAAA");
	this.shape_67.setTransform(391.7,22.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#D91729").ss(2.5).p("A1lAAMArLAAA");
	this.shape_68.setTransform(389.7,22.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#D91729").ss(2.5).p("A16AAMAr1AAA");
	this.shape_69.setTransform(387.7,22.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#D91729").ss(2.5).p("A2OAAMAsdAAA");
	this.shape_70.setTransform(385.7,22.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#D91729").ss(2.5).p("A2iAAMAtFAAA");
	this.shape_71.setTransform(383.6,22.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#D91729").ss(2.5).p("AW3AAMgttAAA");
	this.shape_72.setTransform(381.6,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},50).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_18}]},6).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},6).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_54}]},7).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).wait(25));

	// Capa 6
	this.instance = new lib.CdP_TextoRestarPos();
	this.instance.setTransform(379.9,144.8,1,1,0,0,0,391.9,39.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(148).to({_off:false},0).wait(1).to({regX:397.6,regY:68.8,x:385.6,y:174.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

	// Flechas
	this.instance_1 = new lib.CdP_FlechaRoja2();
	this.instance_1.setTransform(493.7,-107.6,0.706,0.706,180,0,0,54.5,26.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).wait(1).to({regX:54.4,regY:26.6,rotation:180.1,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(6).to({regX:54.5,regY:26.2,rotation:180,x:416.6,y:-107.5,_off:false},0).wait(1).to({regX:54.4,regY:26.6,rotation:180.1,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(6).to({regX:54.5,regY:26.1,rotation:180,x:343.2,y:-107.4,_off:false},0).wait(1).to({regX:54.4,regY:26.6,rotation:180.1,y:-107.7,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(7).to({regX:54.5,regY:26.1,rotation:180,x:270.6,y:-107.4,_off:false},0).wait(1).to({regX:54.4,regY:26.6,rotation:180.1,y:-107.7,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(25));

	// FlashAICB
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogTgFQgfgIgFgWQgFgVAQgbIANgXQAEgJgDgIIAigBQgCARAlAeQAYAUgQAaQgSAdAMAVQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_73.setTransform(489.1,-45.2,0.354,0.296,0,0,180);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#E9661F").s().p("AgBBwQgYgMAPgqQAMgngUgGQgegHgFgWQgFgVAQgbQANgXACgFQACgKgIgLIAtgEQgJALAFANQAHANAaAVQAYAUgQAbQgTAcANAWQAVAjgQAbQgLASgRAAQgLAAgKgGg");
	this.shape_74.setTransform(482,-45.4,0.354,0.296,0,0,180);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogUgFQgegIgFgWQgFgVAQgbIANgYQAEgJgDgIIAiABQgBAQAkAeQAYAUgQAaQgTAcANAWQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_75.setTransform(495.8,-45.2,0.354,0.296,0,0,180);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#E9661F").s().p("AhwAwQgYgQgRAKQgGAEgJADIgEgvQAKADADgNQAIghAggEQAdgEAQAWQAQAWAMgBQAQgBAbghQASgZAaAQQAfATAWgNQAjgVAbAQQAcARgRAgQgLAYgqgOQgogMgFATQgIAfgYAFQgVAEgYgQQgbgPgHAAQgLAAgVAVQgIAIgJAAQgKAAgLgIg");
	this.shape_76.setTransform(517.4,-34.8,0.354,0.296,0,0,180);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#E9661F").s().p("AhwA3IgXgOQgNgggMgoQAPgQAYACQAXABAMARQAPAWANgBQAPgCAcghQASgYAaAQQAeASAWgNQAjgUAcAQQAbAQgQAhQgMAYgqgPQgngMgGATQgHAfgYAFQgVAFgZgQQgbgQgHAAQgKAAgVAVQgJAJgKAAIgHgBg");
	this.shape_77.setTransform(516.9,-29.2,0.354,0.296,0,0,180);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#E9661F").s().p("AgnAxQgfgSgWANQgjAVgbgRQgcgQARghQALgYAqAPQAoAMAFgTQAIgfAYgFQAVgEAYAPQAbAQAHAAQALAAAVgVQAPgQAXAQQAYAQARgLQAIgFAKgCQgKAqgTArQgQAMgVgDQgVgCgKgQQgQgWgMABQgQACgbAhQgLAPgOAAQgJAAgKgHg");
	this.shape_78.setTransform(461.8,-29.4,0.354,0.296,0,0,180);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#E9661F").s().p("AgyAyQgfgTgWANQgjAVgbgQQgbgRAQggQALgYAqAOQAoAMAFgTQAIgfAYgFQAVgEAZAQQAaAPAHAAQALAAAVgVQAPgPAXAPQAYAQARgKQATgMAUAGIAAAPQAAAWgCAVQgZgbgGAZQgIAhggAEQgdAEgQgWQgQgWgMABQgQABgZAhQgMAPgOAAQgKAAgKgGg");
	this.shape_79.setTransform(461.4,-34.9,0.354,0.296,0,0,180);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#1D1D1C").s().p("AjSAsQg0gaAUgpQAHgPAMgMQAMgLAEACQACABgLAjQgKAgAUAKQBNAkA5g3QA5g5AhAkQAXAVApAQQA6AXApgYQAkgTAJgfQAGgYAHAAQAJAAAAATQAAAUgKAUQgfA5hTgEQhHgEgjglQgQgPgCgCQgJgGgRAJQgvAjgdAPQgYAMgZAAQgcAAgfgQg");
	this.shape_80.setTransform(489.2,-27.5,0.354,0.296,0,0,180);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#1D1D1C").s().p("AglA8QgpgQgKguQgKgxBQgMQAegEAdAFQAfAGALAOQAUAYgoAkIgrAiQgMAOgRAAQgMAAgQgGg");
	this.shape_81.setTransform(488.9,-31.9,0.354,0.296,0,0,180);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#1D1D1C").s().p("AjMBhQADgKAGgQQANgfAUgdQBAhZBvgdQB2geA2BRQATAcABAcQAAAbgQABQgOABgJgQQgKgUgHgMQgcgwhLANQhWAQg6ApQgtAigtBEQgDAHgEADIgDABQgFAAgBgTg");
	this.shape_82.setTransform(474.7,-39.3,0.354,0.296,0,0,180);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#1D1D1C").s().p("ADFBzIgHgLQgthEgughQg5gphXgQQhKgNgdAwIgRAgQgJAQgNgBQgRgBAAgbQABgcAUgdQA2hQB1AeQBvAdBABZQAhAuAJAoQgBATgFAAIgCgBg");
	this.shape_83.setTransform(504.9,-38.9,0.354,0.296,0,0,180);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AjFEOQiIgYgwhIQhZiHCRiVQA6g7BQgvQBLgrA/gPQA6gOBOATQBNATBHAsQCnBpANCXQAHBNhoA+QhgA4iUAYQhLAMhGAAQhCAAg8gLg");
	this.shape_84.setTransform(489.3,-27.2,0.354,0.296,0,0,180);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#F6AF17").s().p("AiCL9QkZgdjshvQjYhmhIjqQg6i/AqkEQAhjQBVjIQBKivApgXQAfgRAaAjQARAXAcBKQAiBaATAlQAkBJArAkQBVBIFkgHQCYgDFvgfQCQgNA7iTQAHgRAehjQATg/AVgWQAagdAlA1QAlA1AiBxQBQEQAAFjQAAEEilCvQiVCekFBEQimAri5AAQhUAAhagJg");
	this.shape_85.setTransform(489.3,-38,0.354,0.296,0,0,180);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#E9661F").s().p("AhTgYQAMgLAbALQAcALARgQQAggaAdAMQAeAMgLAjQgHAZgsgIQgngHgCAVIgDANQgkghghgng");
	this.shape_86.setTransform(538.6,-21.8,0.354,0.296,0,0,180);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#E9661F").s().p("AhEA5QgTgggMgYQAKgJALgSQAQgbAcALQAhAOASgQQAfgaAeAMQAeAMgLAkQgIAYgsgIQgpgGgCAUQgCAfgUAJQgIADgKAAQgOAAgQgGg");
	this.shape_87.setTransform(541.8,-27.4,0.354,0.296,0,0,180);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#E9661F").s().p("AhzAFQAMAIAMgHQANgGARgeQAQgbAcAMQAfAOAUgQQAfgaAeALQAeAMgLAlQgHAXgsgIQgqgFgCATQgDAggUAJQgUAHgdgLQgdgLgHABQgKABgRAXQgBgkACgag");
	this.shape_88.setTransform(544.9,-41.1,0.354,0.296,0,0,180);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#E9661F").s().p("AiBgRQAJAFAEAEQATASAMgEQAPgEAWgiQAQgcAcAMQAfAOAUgQQAfgaAeAMQAdAMgKAkQgIAXgrgHQgqgGgCAUQgDAfgWAJQgSAIgdgMQgdgLgHABQgLABgRAZIgDADQgMgogKgug");
	this.shape_89.setTransform(543.8,-34.1,0.354,0.296,0,0,180);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#F6AF17").s().p("AI4OHQhBgeAFhBQAAgNAghuQAVhLgaglQglg0iHgMQk5gchWAoQg1AYgIAzQgHAzAkBYQAZA+gUAiQgRAfgrgDQgqgDgmgkQgqgogNg/QgUhhAXg4QAGgRgEgIQgFgKghgYQgjgZAFA6QACATAXB8QATBlgFApQgIA7g4gaQg4gbgthKQguhLgMhbQgOhlAfhXQAlhkBbhCQkTg5iwi+QiTihg1jiQgujGApidQApicBfADQBbADAuBXQAkBEAPCNQAJBSALCvQAOCaAcBRQAzCOBzAyQEHiBElgEQFTgEFvCkIAgAMQAnASAiAdQBtBdAXCnQAHAzgjBQQgTAtgoBTQguBugWAkQgjA5grAFQhVAJAGhTQAEg+A5h7QBAiEASgsQAehHgpAYQgNAHgaAkQgZAigaAOQg0AcgeBOQgSAygQBhQgQBhgKAZQgOAjgXAAQgIAAgKgFg");
	this.shape_90.setTransform(512.4,-21.6,0.354,0.296,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_90,p:{x:512.4}},{t:this.shape_89,p:{x:543.8}},{t:this.shape_88,p:{x:544.9}},{t:this.shape_87,p:{x:541.8}},{t:this.shape_86,p:{x:538.6}},{t:this.shape_85,p:{x:489.3}},{t:this.shape_84,p:{x:489.3}},{t:this.shape_83,p:{x:504.9}},{t:this.shape_82,p:{x:474.7}},{t:this.shape_81,p:{x:488.9}},{t:this.shape_80,p:{x:489.2}},{t:this.shape_79,p:{x:461.4}},{t:this.shape_78,p:{x:461.8}},{t:this.shape_77,p:{x:516.9}},{t:this.shape_76,p:{x:517.4}},{t:this.shape_75,p:{x:495.8}},{t:this.shape_74,p:{x:482}},{t:this.shape_73,p:{x:489.1}}]},50).to({state:[]},7).to({state:[{t:this.shape_90,p:{x:439.7}},{t:this.shape_89,p:{x:471}},{t:this.shape_88,p:{x:472.1}},{t:this.shape_87,p:{x:469}},{t:this.shape_86,p:{x:465.9}},{t:this.shape_85,p:{x:416.5}},{t:this.shape_84,p:{x:416.6}},{t:this.shape_83,p:{x:432.2}},{t:this.shape_82,p:{x:402}},{t:this.shape_81,p:{x:416.2}},{t:this.shape_80,p:{x:416.4}},{t:this.shape_79,p:{x:388.7}},{t:this.shape_78,p:{x:389.1}},{t:this.shape_77,p:{x:444.2}},{t:this.shape_76,p:{x:444.6}},{t:this.shape_75,p:{x:423.1}},{t:this.shape_74,p:{x:409.3}},{t:this.shape_73,p:{x:416.4}}]},17).to({state:[]},7).to({state:[{t:this.shape_90,p:{x:366.2}},{t:this.shape_89,p:{x:397.5}},{t:this.shape_88,p:{x:398.6}},{t:this.shape_87,p:{x:395.5}},{t:this.shape_86,p:{x:392.4}},{t:this.shape_85,p:{x:343}},{t:this.shape_84,p:{x:343.1}},{t:this.shape_83,p:{x:358.7}},{t:this.shape_82,p:{x:328.5}},{t:this.shape_81,p:{x:342.7}},{t:this.shape_80,p:{x:342.9}},{t:this.shape_79,p:{x:315.2}},{t:this.shape_78,p:{x:315.6}},{t:this.shape_77,p:{x:370.7}},{t:this.shape_76,p:{x:371.1}},{t:this.shape_75,p:{x:349.6}},{t:this.shape_74,p:{x:335.8}},{t:this.shape_73,p:{x:342.9}}]},17).to({state:[]},7).to({state:[]},11).to({state:[{t:this.shape_90,p:{x:292.7}},{t:this.shape_89,p:{x:324}},{t:this.shape_88,p:{x:325.1}},{t:this.shape_87,p:{x:322}},{t:this.shape_86,p:{x:318.9}},{t:this.shape_85,p:{x:269.5}},{t:this.shape_84,p:{x:269.6}},{t:this.shape_83,p:{x:285.2}},{t:this.shape_82,p:{x:255}},{t:this.shape_81,p:{x:269.2}},{t:this.shape_80,p:{x:269.4}},{t:this.shape_79,p:{x:241.7}},{t:this.shape_78,p:{x:242.1}},{t:this.shape_77,p:{x:297.2}},{t:this.shape_76,p:{x:297.6}},{t:this.shape_75,p:{x:276.1}},{t:this.shape_74,p:{x:262.3}},{t:this.shape_73,p:{x:269.4}}]},7).to({state:[]},7).to({state:[]},18).wait(18));

	// Perro1
	this.instance_2 = new lib.CdP_Gato();
	this.instance_2.setTransform(528.1,-27.7,1,1,0,0,0,47.4,33.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({_off:false},0).wait(1).to({regX:46.1,regY:33.1,x:526.8,y:-27.9,alpha:0.077},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:1},0).wait(13).to({_off:true},1).wait(7).to({regX:47.4,regY:33.4,x:456.3,y:-27.7,_off:false},0).to({_off:true},17).wait(7).to({x:380.8,y:-27.6,_off:false},0).to({_off:true},17).wait(7).to({x:309.9,y:-27.7,_off:false},0).to({_off:true},18).wait(7).to({x:236.8,_off:false},0).wait(36));

	// RectaNumerica
	this.text = new cjs.Text("+5", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(729,44.1+incremento);

	this.text_1 = new cjs.Text("+4", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(656,44.1+incremento);

	this.text_2 = new cjs.Text("+3", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(584.8,44.1+incremento);

	this.text_3 = new cjs.Text("+2", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(510.8,44.1+incremento);

	this.text_4 = new cjs.Text("+1", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(438.8,44.1+incremento);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(374.3,44.1+incremento);

	this.text_6 = new cjs.Text("-1", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(295.7,44.1+incremento);

	this.text_7 = new cjs.Text("-2", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(221.7,44.1+incremento);

	this.text_8 = new cjs.Text("-3", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(150.5,44.1+incremento);

	this.text_9 = new cjs.Text("-4", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(76.5,44.1+incremento);

	this.text_10 = new cjs.Text("-5", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(4.6,44.1+incremento);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_91.setTransform(673.5,22.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_92.setTransform(601,22.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_93.setTransform(528,22.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_94.setTransform(455,22.3);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_95.setTransform(382,22.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_96.setTransform(309,22.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_97.setTransform(235.5,22.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_98.setTransform(163,22.3);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_99.setTransform(89.5,22.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_100.setTransform(746.5,22.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_101.setTransform(17,22.3);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_102.setTransform(381.5,22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(166));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.7,0,811,303);


(lib.CdP_RestarNegativos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	
	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(2.5).p("AgLAAIAXAA");
	this.shape.setTransform(236.3,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(2.5).p("AgfAAIA/AA");
	this.shape_1.setTransform(238.3,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(2.5).p("AgzAAIBnAA");
	this.shape_2.setTransform(240.3,22.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D91729").ss(2.5).p("AhHAAICPAA");
	this.shape_3.setTransform(242.3,22.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D91729").ss(2.5).p("AhbAAIC3AA");
	this.shape_4.setTransform(244.3,22.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D91729").ss(2.5).p("AhvAAIDfAA");
	this.shape_5.setTransform(246.3,22.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D91729").ss(2.5).p("AiDAAIEHAA");
	this.shape_6.setTransform(248.3,22.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D91729").ss(2.5).p("AiXAAIEvAA");
	this.shape_7.setTransform(250.3,22.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D91729").ss(2.5).p("AirAAIFXAA");
	this.shape_8.setTransform(252.3,22.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D91729").ss(2.5).p("Ai/AAIF/AA");
	this.shape_9.setTransform(254.3,22.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D91729").ss(2.5).p("AjTAAIGnAA");
	this.shape_10.setTransform(256.2,22.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D91729").ss(2.5).p("AjnAAIHPAA");
	this.shape_11.setTransform(258.2,22.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D91729").ss(2.5).p("Aj7AAIH3AA");
	this.shape_12.setTransform(260.2,22.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D91729").ss(2.5).p("AkPAAIIfAA");
	this.shape_13.setTransform(262.2,22.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D91729").ss(2.5).p("AkjAAIJHAA");
	this.shape_14.setTransform(264.2,22.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D91729").ss(2.5).p("Ak3AAIJvAA");
	this.shape_15.setTransform(266.2,22.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D91729").ss(2.5).p("AlLAAIKXAA");
	this.shape_16.setTransform(268.2,22.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D91729").ss(2.5).p("AlfAAIK/AA");
	this.shape_17.setTransform(270.2,22.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D91729").ss(2.5).p("AlzAAILnAA");
	this.shape_18.setTransform(272.2,22.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D91729").ss(2.5).p("AmHAAIMPAA");
	this.shape_19.setTransform(274.3,22.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D91729").ss(2.5).p("AmbAAIM3AA");
	this.shape_20.setTransform(276.3,22.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D91729").ss(2.5).p("AmwAAINhAA");
	this.shape_21.setTransform(278.3,22.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D91729").ss(2.5).p("AnEAAIOJAA");
	this.shape_22.setTransform(280.4,22.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D91729").ss(2.5).p("AnYAAIOxAA");
	this.shape_23.setTransform(282.4,22.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D91729").ss(2.5).p("AntAAIPbAA");
	this.shape_24.setTransform(284.4,22.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D91729").ss(2.5).p("AoBAAIQDAA");
	this.shape_25.setTransform(286.5,22.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D91729").ss(2.5).p("AoWAAIQtAA");
	this.shape_26.setTransform(288.5,22.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D91729").ss(2.5).p("AoqAAIRVAA");
	this.shape_27.setTransform(290.5,22.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D91729").ss(2.5).p("Ao+AAIR9AA");
	this.shape_28.setTransform(292.6,22.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D91729").ss(2.5).p("ApTAAISnAA");
	this.shape_29.setTransform(294.6,22.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D91729").ss(2.5).p("ApnAAITPAA");
	this.shape_30.setTransform(296.6,22.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D91729").ss(2.5).p("Ap7AAIT3AA");
	this.shape_31.setTransform(298.7,22.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D91729").ss(2.5).p("AqQAAIUhAA");
	this.shape_32.setTransform(300.7,22.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D91729").ss(2.5).p("AqkAAIVJAA");
	this.shape_33.setTransform(302.7,22.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D91729").ss(2.5).p("Aq4AAIVxAA");
	this.shape_34.setTransform(304.8,22.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D91729").ss(2.5).p("ArNAAIWbAA");
	this.shape_35.setTransform(306.8,22.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D91729").ss(2.5).p("ArhAAIXDAA");
	this.shape_36.setTransform(308.9,22.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#D91729").ss(2.5).p("Ar1AAIXrAA");
	this.shape_37.setTransform(310.9,22.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#D91729").ss(2.5).p("AsJAAIYTAA");
	this.shape_38.setTransform(312.9,22.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#D91729").ss(2.5).p("AseAAIY9AA");
	this.shape_39.setTransform(314.9,22.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#D91729").ss(2.5).p("AsyAAIZlAA");
	this.shape_40.setTransform(316.9,22.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#D91729").ss(2.5).p("AtGAAIaNAA");
	this.shape_41.setTransform(319,22.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#D91729").ss(2.5).p("AtaAAIa1AA");
	this.shape_42.setTransform(321,22.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#D91729").ss(2.5).p("AtvAAIbfAA");
	this.shape_43.setTransform(323,22.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#D91729").ss(2.5).p("AuDAAIcHAA");
	this.shape_44.setTransform(325,22.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#D91729").ss(2.5).p("AuXAAIcvAA");
	this.shape_45.setTransform(327.1,22.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#D91729").ss(2.5).p("AurAAIdXAA");
	this.shape_46.setTransform(329.1,22.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#D91729").ss(2.5).p("Au/AAId/AA");
	this.shape_47.setTransform(331.1,22.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#D91729").ss(2.5).p("AvUAAIepAA");
	this.shape_48.setTransform(333.1,22.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#D91729").ss(2.5).p("AvoAAIfRAA");
	this.shape_49.setTransform(335.1,22.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#D91729").ss(2.5).p("Av8AAIf5AA");
	this.shape_50.setTransform(337.2,22.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#D91729").ss(2.5).p("AwQAAMAghAAA");
	this.shape_51.setTransform(339.2,22.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#D91729").ss(2.5).p("AwlAAMAhLAAA");
	this.shape_52.setTransform(341.2,22.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#D91729").ss(2.5).p("Aw5AAMAhzAAA");
	this.shape_53.setTransform(343.2,22.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#D91729").ss(2.5).p("AxNAAMAibAAA");
	this.shape_54.setTransform(345.3,22.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#D91729").ss(2.5).p("AxhAAMAjDAAA");
	this.shape_55.setTransform(347.3,22.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#D91729").ss(2.5).p("Ax2AAMAjtAAA");
	this.shape_56.setTransform(349.3,22.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#D91729").ss(2.5).p("AyKAAMAkVAAA");
	this.shape_57.setTransform(351.4,22.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#D91729").ss(2.5).p("AyeAAMAk9AAA");
	this.shape_58.setTransform(353.4,22.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#D91729").ss(2.5).p("AyzAAMAlnAAA");
	this.shape_59.setTransform(355.4,22.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#D91729").ss(2.5).p("AzHAAMAmPAAA");
	this.shape_60.setTransform(357.5,22.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#D91729").ss(2.5).p("AzcAAMAm5AAA");
	this.shape_61.setTransform(359.5,22.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#D91729").ss(2.5).p("AzwAAMAnhAAA");
	this.shape_62.setTransform(361.5,22.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#D91729").ss(2.5).p("A0EAAMAoJAAA");
	this.shape_63.setTransform(363.6,22.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#D91729").ss(2.5).p("A0ZAAMAozAAA");
	this.shape_64.setTransform(365.6,22.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#D91729").ss(2.5).p("A0tAAMApbAAA");
	this.shape_65.setTransform(367.6,22.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#D91729").ss(2.5).p("A1BAAMAqDAAA");
	this.shape_66.setTransform(369.7,22.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#D91729").ss(2.5).p("A1WAAMAqtAAA");
	this.shape_67.setTransform(371.7,22.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#D91729").ss(2.5).p("A1qAAMArVAAA");
	this.shape_68.setTransform(373.8,22.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#D91729").ss(2.5).p("A1+AAMAr9AAA");
	this.shape_69.setTransform(375.8,22.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#D91729").ss(2.5).p("A2TAAMAsnAAA");
	this.shape_70.setTransform(377.8,22.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#D91729").ss(2.5).p("A2nAAMAtPAAA");
	this.shape_71.setTransform(379.9,22.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#D91729").ss(2.5).p("A27AAMAt3AAA");
	this.shape_72.setTransform(381.9,22.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#D91729").ss(2.5).p("A3QAAMAuhAAA");
	this.shape_73.setTransform(383.9,22.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#D91729").ss(2.5).p("A3kAAMAvJAAA");
	this.shape_74.setTransform(386,22.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#D91729").ss(2.5).p("A34AAMAvxAAA");
	this.shape_75.setTransform(388,22.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#D91729").ss(2.5).p("A4NAAMAwbAAA");
	this.shape_76.setTransform(390,22.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#D91729").ss(2.5).p("A4hAAMAxDAAA");
	this.shape_77.setTransform(392,22.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#D91729").ss(2.5).p("A41AAMAxrAAA");
	this.shape_78.setTransform(394.1,22.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#D91729").ss(2.5).p("A5JAAMAyTAAA");
	this.shape_79.setTransform(396.1,22.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#D91729").ss(2.5).p("A5eAAMAy9AAA");
	this.shape_80.setTransform(398.1,22.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#D91729").ss(2.5).p("A5yAAMAzlAAA");
	this.shape_81.setTransform(400.1,22.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#D91729").ss(2.5).p("A6GAAMA0NAAA");
	this.shape_82.setTransform(402.2,22.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#D91729").ss(2.5).p("A6aAAMA01AAA");
	this.shape_83.setTransform(404.2,22.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#D91729").ss(2.5).p("A6vAAMA1fAAA");
	this.shape_84.setTransform(406.2,22.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#D91729").ss(2.5).p("A7DAAMA2HAAA");
	this.shape_85.setTransform(408.2,22.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#D91729").ss(2.5).p("A7XAAMA2vAAA");
	this.shape_86.setTransform(410.3,22.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#D91729").ss(2.5).p("A7rAAMA3XAAA");
	this.shape_87.setTransform(412.3,22.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#D91729").ss(2.5).p("A8AAAMA4AAAA");
	this.shape_88.setTransform(414.3,22.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#D91729").ss(2.5).p("A8UAAMA4pAAA");
	this.shape_89.setTransform(416.3,22.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#D91729").ss(2.5).p("A8oAAMA5RAAA");
	this.shape_90.setTransform(418.4,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},50).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_18}]},6).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_36}]},6).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_54}]},7).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_72}]},7).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).wait(18));

	// Capa 6
	this.instance = new lib.CdP_TextoRestarNeg();
	this.instance.setTransform(379.9,144.8,1,1,0,0,0,391.9,39.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(166).to({_off:false},0).wait(1).to({regX:397.6,regY:68.8,x:385.6,y:174.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

	// Flechas
	this.instance_1 = new lib.CdP_FlechaRoja();
	this.instance_1.setTransform(273.8,-107.6,0.706,0.706,180,0,0,54.5,26.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).wait(1).to({regX:54.7,regY:26.6,rotation:180.1,x:273.6,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(6).to({regX:54.5,regY:26.2,rotation:180,x:347.4,y:-107.5,_off:false},0).wait(1).to({regX:54.7,regY:26.6,rotation:180.1,x:347.3,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(6).to({regX:54.5,regY:26.2,rotation:180,x:420.8,y:-107.5,_off:false},0).wait(1).to({regX:54.7,regY:26.6,rotation:180.1,x:420.6,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(7).to({regX:54.5,regY:26.2,rotation:180,x:493.3,y:-107.5,_off:false},0).wait(1).to({regX:54.7,regY:26.6,rotation:180.1,x:493.1,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(7).to({regX:54.5,regY:26.2,rotation:180,x:566.2,y:-107.5,_off:false},0).wait(1).to({regX:54.7,regY:26.6,rotation:180.1,x:566,y:-107.8,alpha:0.167},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.833},0).wait(1).to({alpha:1},0).wait(1).to({alpha:0.909},0).wait(1).to({alpha:0.818},0).wait(1).to({alpha:0.727},0).wait(1).to({alpha:0.636},0).wait(1).to({alpha:0.545},0).wait(1).to({alpha:0.455},0).wait(1).to({alpha:0.364},0).wait(1).to({alpha:0.273},0).wait(1).to({alpha:0.182},0).wait(1).to({alpha:0.091},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(18));

	// FlashAICB
	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogTgFQgfgIgFgWQgFgVAQgbIANgXQAEgJgDgIIAigBQgCARAlAeQAYAUgQAaQgSAdAMAVQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_91.setTransform(274.8,-45.2,0.354,0.296);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#E9661F").s().p("AgBBwQgYgMAPgqQAMgngUgGQgegHgFgWQgFgVAQgbQANgXACgFQACgKgIgLIAtgEQgJALAFANQAHANAaAVQAYAUgQAbQgTAcANAWQAVAjgQAbQgLASgRAAQgLAAgKgGg");
	this.shape_92.setTransform(281.9,-45.4,0.354,0.296);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#E9661F").s().p("AgBBqQgYgLAPgqQAMgogUgFQgegIgFgWQgFgVAQgbIANgYQAEgJgDgIIAiABQgBAQAkAeQAYAUgQAaQgTAcANAWQAVAkgQAbQgLARgRAAQgLAAgKgGg");
	this.shape_93.setTransform(268.1,-45.2,0.354,0.296);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#E9661F").s().p("AhwAwQgYgQgRAKQgGAEgJADIgEgvQAKADADgNQAIghAggEQAdgEAQAWQAQAWAMgBQAQgBAbghQASgZAaAQQAfATAWgNQAjgVAbAQQAcARgRAgQgLAYgqgOQgogMgFATQgIAfgYAFQgVAEgYgQQgbgPgHAAQgLAAgVAVQgIAIgJAAQgKAAgLgIg");
	this.shape_94.setTransform(246.5,-34.8,0.354,0.296);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#E9661F").s().p("AhwA3IgXgOQgNgggMgoQAPgQAYACQAXABAMARQAPAWANgBQAPgCAcghQASgYAaAQQAeASAWgNQAjgUAcAQQAbAQgQAhQgMAYgqgPQgngMgGATQgHAfgYAFQgVAFgZgQQgbgQgHAAQgKAAgVAVQgJAJgKAAIgHgBg");
	this.shape_95.setTransform(247,-29.2,0.354,0.296);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#E9661F").s().p("AgnAxQgfgSgWANQgjAVgbgRQgcgQARghQALgYAqAPQAoAMAFgTQAIgfAYgFQAVgEAYAPQAbAQAHAAQALAAAVgVQAPgQAXAQQAYAQARgLQAIgFAKgCQgKAqgTArQgQAMgVgDQgVgCgKgQQgQgWgMABQgQACgbAhQgLAPgOAAQgJAAgKgHg");
	this.shape_96.setTransform(302.1,-29.4,0.354,0.296);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#E9661F").s().p("AgyAyQgfgTgWANQgjAVgbgQQgbgRAQggQALgYAqAOQAoAMAFgTQAIgfAYgFQAVgEAZAQQAaAPAHAAQALAAAVgVQAPgPAXAPQAYAQARgKQATgMAUAGIAAAPQAAAWgCAVQgZgbgGAZQgIAhggAEQgdAEgQgWQgQgWgMABQgQABgZAhQgMAPgOAAQgKAAgKgGg");
	this.shape_97.setTransform(302.5,-35,0.354,0.296);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#1D1D1C").s().p("AjSAsQg0gaAUgpQAHgPAMgMQAMgLAEACQACABgLAjQgKAgAUAKQBNAkA5g3QA5g5AhAkQAXAVApAQQA6AXApgYQAkgTAJgfQAGgYAHAAQAJAAAAATQAAAUgKAUQgfA5hTgEQhHgEgjglQgQgPgCgCQgJgGgRAJQgvAjgdAPQgYAMgZAAQgcAAgfgQg");
	this.shape_98.setTransform(274.7,-27.5,0.354,0.296);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#1D1D1C").s().p("AglA8QgpgQgKguQgKgxBQgMQAegEAdAFQAfAGALAOQAUAYgoAkIgrAiQgMAOgRAAQgMAAgQgGg");
	this.shape_99.setTransform(275,-31.9,0.354,0.296);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#1D1D1C").s().p("AjMBhQADgKAGgQQANgfAUgdQBAhZBvgdQB2geA2BRQATAcABAcQAAAbgQABQgOABgJgQQgKgUgHgMQgcgwhLANQhWAQg6ApQgtAigtBEQgDAHgEADIgDABQgFAAgBgTg");
	this.shape_100.setTransform(289.2,-39.3,0.354,0.296);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#1D1D1C").s().p("ADFBzIgHgLQgthEgughQg5gphXgQQhKgNgdAwIgRAgQgJAQgNgBQgRgBAAgbQABgcAUgdQA2hQB1AeQBvAdBABZQAhAuAJAoQgBATgFAAIgCgBg");
	this.shape_101.setTransform(259,-38.9,0.354,0.296);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AjFEOQiIgYgwhIQhZiHCRiVQA6g7BQgvQBLgrA/gPQA6gOBOATQBNATBHAsQCnBpANCXQAHBNhoA+QhgA4iUAYQhLAMhGAAQhCAAg8gLg");
	this.shape_102.setTransform(274.6,-27.2,0.354,0.296);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#F6AF17").s().p("AiCL9QkZgdjshvQjYhmhIjqQg6i/AqkEQAhjQBVjIQBKivApgXQAfgRAaAjQARAXAcBKQAiBaATAlQAkBJArAkQBVBIFkgHQCYgDFvgfQCQgNA7iTQAHgRAehjQATg/AVgWQAagdAlA1QAlA1AiBxQBQEQAAFjQAAEEilCvQiVCekFBEQimAri5AAQhUAAhagJg");
	this.shape_103.setTransform(274.6,-38.1,0.354,0.296);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#E9661F").s().p("AhTgYQAMgLAbALQAcALARgQQAggaAdAMQAeAMgLAjQgHAZgsgIQgngHgCAVIgDANQgkghghgng");
	this.shape_104.setTransform(225.3,-21.8,0.354,0.296);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#E9661F").s().p("AhEA5QgTgggMgYQAKgJALgSQAQgbAcALQAhAOASgQQAfgaAeAMQAeAMgLAkQgIAYgsgIQgpgGgCAUQgCAfgUAJQgIADgKAAQgOAAgQgGg");
	this.shape_105.setTransform(222.1,-27.4,0.354,0.296);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#E9661F").s().p("AhzAFQAMAIAMgHQANgGARgeQAQgbAcAMQAfAOAUgQQAfgaAeALQAeAMgLAlQgHAXgsgIQgqgFgCATQgDAggUAJQgUAHgdgLQgdgLgHABQgKABgRAXQgBgkACgag");
	this.shape_106.setTransform(219,-41.1,0.354,0.296);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#E9661F").s().p("AiBgRQAJAFAEAEQATASAMgEQAPgEAWgiQAQgcAcAMQAfAOAUgQQAfgaAeAMQAdAMgKAkQgIAXgrgHQgqgGgCAUQgDAfgWAJQgSAIgdgMQgdgLgHABQgLABgRAZIgDADQgMgogKgug");
	this.shape_107.setTransform(220.1,-34.1,0.354,0.296);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#F6AF17").s().p("AI4OHQhBgeAFhBQAAgNAghuQAVhLgaglQglg0iHgMQk5gchWAoQg1AYgIAzQgHAzAkBYQAZA+gUAiQgRAfgrgDQgqgDgmgkQgqgogNg/QgUhhAXg4QAGgRgEgIQgFgKghgYQgjgZAFA6QACATAXB8QATBlgFApQgIA7g4gaQg4gbgthKQguhLgMhbQgOhlAfhXQAlhkBbhCQkTg5iwi+QiTihg1jiQgujGApidQApicBfADQBbADAuBXQAkBEAPCNQAJBSALCvQAOCaAcBRQAzCOBzAyQEHiBElgEQFTgEFvCkIAgAMQAnASAiAdQBtBdAXCnQAHAzgjBQQgTAtgoBTQguBugWAkQgjA5grAFQhVAJAGhTQAEg+A5h7QBAiEASgsQAehHgpAYQgNAHgaAkQgZAigaAOQg0AcgeBOQgSAygQBhQgQBhgKAZQgOAjgXAAQgIAAgKgFg");
	this.shape_108.setTransform(251.5,-21.7,0.354,0.296);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_108,p:{x:251.5,y:-21.7}},{t:this.shape_107,p:{x:220.1}},{t:this.shape_106,p:{x:219}},{t:this.shape_105,p:{x:222.1}},{t:this.shape_104,p:{x:225.3}},{t:this.shape_103,p:{x:274.6,y:-38.1}},{t:this.shape_102,p:{x:274.6}},{t:this.shape_101,p:{x:259}},{t:this.shape_100,p:{x:289.2}},{t:this.shape_99,p:{x:275}},{t:this.shape_98,p:{x:274.7}},{t:this.shape_97,p:{x:302.5,y:-35}},{t:this.shape_96,p:{x:302.1}},{t:this.shape_95,p:{x:247}},{t:this.shape_94,p:{x:246.5}},{t:this.shape_93,p:{x:268.1}},{t:this.shape_92,p:{x:281.9}},{t:this.shape_91,p:{x:274.8}}]},50).to({state:[]},7).to({state:[{t:this.shape_108,p:{x:324.2,y:-21.6}},{t:this.shape_107,p:{x:292.8}},{t:this.shape_106,p:{x:291.7}},{t:this.shape_105,p:{x:294.8}},{t:this.shape_104,p:{x:298}},{t:this.shape_103,p:{x:347.3,y:-38}},{t:this.shape_102,p:{x:347.3}},{t:this.shape_101,p:{x:331.7}},{t:this.shape_100,p:{x:361.9}},{t:this.shape_99,p:{x:347.7}},{t:this.shape_98,p:{x:347.4}},{t:this.shape_97,p:{x:375.2,y:-34.9}},{t:this.shape_96,p:{x:374.8}},{t:this.shape_95,p:{x:319.7}},{t:this.shape_94,p:{x:319.2}},{t:this.shape_93,p:{x:340.8}},{t:this.shape_92,p:{x:354.6}},{t:this.shape_91,p:{x:347.5}}]},17).to({state:[]},7).to({state:[{t:this.shape_108,p:{x:397.5,y:-21.6}},{t:this.shape_107,p:{x:366.2}},{t:this.shape_106,p:{x:365.1}},{t:this.shape_105,p:{x:368.2}},{t:this.shape_104,p:{x:371.3}},{t:this.shape_103,p:{x:420.7,y:-38}},{t:this.shape_102,p:{x:420.6}},{t:this.shape_101,p:{x:405}},{t:this.shape_100,p:{x:435.2}},{t:this.shape_99,p:{x:421}},{t:this.shape_98,p:{x:420.8}},{t:this.shape_97,p:{x:448.5,y:-34.9}},{t:this.shape_96,p:{x:448.1}},{t:this.shape_95,p:{x:393}},{t:this.shape_94,p:{x:392.6}},{t:this.shape_93,p:{x:414.1}},{t:this.shape_92,p:{x:427.9}},{t:this.shape_91,p:{x:420.8}}]},17).to({state:[]},7).to({state:[]},11).to({state:[{t:this.shape_108,p:{x:470.6,y:-21.6}},{t:this.shape_107,p:{x:439.3}},{t:this.shape_106,p:{x:438.2}},{t:this.shape_105,p:{x:441.3}},{t:this.shape_104,p:{x:444.4}},{t:this.shape_103,p:{x:493.8,y:-38}},{t:this.shape_102,p:{x:493.7}},{t:this.shape_101,p:{x:478.1}},{t:this.shape_100,p:{x:508.3}},{t:this.shape_99,p:{x:494.1}},{t:this.shape_98,p:{x:493.9}},{t:this.shape_97,p:{x:521.6,y:-34.9}},{t:this.shape_96,p:{x:521.2}},{t:this.shape_95,p:{x:466.1}},{t:this.shape_94,p:{x:465.7}},{t:this.shape_93,p:{x:487.2}},{t:this.shape_92,p:{x:501}},{t:this.shape_91,p:{x:493.9}}]},7).to({state:[]},7).to({state:[{t:this.shape_108,p:{x:543.4,y:-21.6}},{t:this.shape_107,p:{x:512}},{t:this.shape_106,p:{x:510.9}},{t:this.shape_105,p:{x:514}},{t:this.shape_104,p:{x:517.2}},{t:this.shape_103,p:{x:566.5,y:-38}},{t:this.shape_102,p:{x:566.5}},{t:this.shape_101,p:{x:550.9}},{t:this.shape_100,p:{x:581.1}},{t:this.shape_99,p:{x:566.9}},{t:this.shape_98,p:{x:566.6}},{t:this.shape_97,p:{x:594.4,y:-34.9}},{t:this.shape_96,p:{x:594}},{t:this.shape_95,p:{x:538.9}},{t:this.shape_94,p:{x:538.4}},{t:this.shape_93,p:{x:560}},{t:this.shape_92,p:{x:573.8}},{t:this.shape_91,p:{x:566.7}}]},18).to({state:[]},7).to({state:[]},11).wait(18));

	// Perro1
	this.instance_2 = new lib.CdP_Gato2();
	this.instance_2.setTransform(235.7,-27.7,1,1,0,0,0,47.4,33.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({_off:false},0).wait(1).to({regX:46.1,regY:33.1,x:234.4,y:-27.9,alpha:0.077},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:1},0).wait(13).to({_off:true},1).wait(7).to({regX:47.4,regY:33.4,x:309.6,y:-27.7,_off:false},0).to({_off:true},17).wait(7).to({x:380.8,y:-27.6,_off:false},0).to({_off:true},17).wait(7).to({x:456.3,y:-27.7,_off:false},0).to({_off:true},18).wait(7).to({x:527.8,y:-27.8,_off:false},0).to({_off:true},18).wait(7).to({x:601.3,_off:false},0).wait(29));

	// RectaNumerica
	this.text = new cjs.Text("+5", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(729,44.1+incremento);

	this.text_1 = new cjs.Text("+4", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(656,44.1+incremento);

	this.text_2 = new cjs.Text("+3", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(584.8,44.1+incremento);

	this.text_3 = new cjs.Text("+2", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(510.8,44.1+incremento);

	this.text_4 = new cjs.Text("+1", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(438.8,44.1+incremento);

	this.text_5 = new cjs.Text("0", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(374.3,44.1+incremento);

	this.text_6 = new cjs.Text("-1", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(295.7,44.1+incremento);

	this.text_7 = new cjs.Text("-2", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(221.7,44.1+incremento);

	this.text_8 = new cjs.Text("-3", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(150.5,44.1+incremento);

	this.text_9 = new cjs.Text("-4", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(76.5,44.1+incremento);

	this.text_10 = new cjs.Text("-5", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(4.6,44.1+incremento);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_109.setTransform(673.5,22.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_110.setTransform(601,22.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_111.setTransform(528,22.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_112.setTransform(455,22.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_113.setTransform(382,22.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_114.setTransform(309,22.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_115.setTransform(235.5,22.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_116.setTransform(163,22.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_117.setTransform(89.5,22.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_118.setTransform(746.5,22.3);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_119.setTransform(17,22.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_120.setTransform(381.5,22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(184));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.7,0,811,303);


(lib.CdP_SumarPositivos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// BotoPlay
	
	// LineaCrece2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(2.5).p("AgLAAIAXAA");
	this.shape.setTransform(456.3,22.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(2.5).p("AgeAAIA9AA");
	this.shape_1.setTransform(458.2,22.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(2.5).p("AgyAAIBlAA");
	this.shape_2.setTransform(460.2,22.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D91729").ss(2.5).p("AhGAAICNAA");
	this.shape_3.setTransform(462.2,22.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D91729").ss(2.5).p("AhZAAICzAA");
	this.shape_4.setTransform(464.1,22.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D91729").ss(2.5).p("AhtAAIDbAA");
	this.shape_5.setTransform(466.1,22.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D91729").ss(2.5).p("AiAAAIEBAA");
	this.shape_6.setTransform(468,22.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D91729").ss(2.5).p("AiUAAIEpAA");
	this.shape_7.setTransform(470,22.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D91729").ss(2.5).p("AioAAIFRAA");
	this.shape_8.setTransform(472,22.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D91729").ss(2.5).p("Ai7AAIF3AA");
	this.shape_9.setTransform(473.9,22.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D91729").ss(2.5).p("AjPAAIGfAA");
	this.shape_10.setTransform(475.9,22.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D91729").ss(2.5).p("AjiAAIHFAA");
	this.shape_11.setTransform(477.8,22.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D91729").ss(2.5).p("Aj2AAIHtAA");
	this.shape_12.setTransform(479.8,22.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D91729").ss(2.5).p("AkKAAIIVAA");
	this.shape_13.setTransform(481.8,22.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D91729").ss(2.5).p("AkdAAII7AA");
	this.shape_14.setTransform(483.7,22.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D91729").ss(2.5).p("AkxAAIJjAA");
	this.shape_15.setTransform(485.7,22.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D91729").ss(2.5).p("AlEAAIKJAA");
	this.shape_16.setTransform(487.6,22.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D91729").ss(2.5).p("AlYAAIKxAA");
	this.shape_17.setTransform(489.6,22.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D91729").ss(2.5).p("AlrAAILYAA");
	this.shape_18.setTransform(491.6,22.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D91729").ss(2.5).p("AmAAAIMBAA");
	this.shape_19.setTransform(493.6,22.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D91729").ss(2.5).p("AmUAAIMpAA");
	this.shape_20.setTransform(495.6,22.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D91729").ss(2.5).p("AmoAAINRAA");
	this.shape_21.setTransform(497.6,22.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D91729").ss(2.5).p("Am9AAIN7AA");
	this.shape_22.setTransform(499.7,22.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D91729").ss(2.5).p("AnRAAIOjAA");
	this.shape_23.setTransform(501.7,22.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D91729").ss(2.5).p("AnlAAIPLAA");
	this.shape_24.setTransform(503.7,22.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D91729").ss(2.5).p("An6AAIP1AA");
	this.shape_25.setTransform(505.8,22.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D91729").ss(2.5).p("AoOAAIQdAA");
	this.shape_26.setTransform(507.8,22.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D91729").ss(2.5).p("AoiAAIRFAA");
	this.shape_27.setTransform(509.8,22.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D91729").ss(2.5).p("Ao3AAIRvAA");
	this.shape_28.setTransform(511.9,22.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D91729").ss(2.5).p("ApLAAISXAA");
	this.shape_29.setTransform(513.9,22.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D91729").ss(2.5).p("ApfAAIS/AA");
	this.shape_30.setTransform(515.9,22.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D91729").ss(2.5).p("Ap0AAITpAA");
	this.shape_31.setTransform(518,22.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D91729").ss(2.5).p("AqIAAIURAA");
	this.shape_32.setTransform(520,22.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D91729").ss(2.5).p("AqcAAIU5AA");
	this.shape_33.setTransform(522,22.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D91729").ss(2.5).p("AqxAAIVjAA");
	this.shape_34.setTransform(524.1,22.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D91729").ss(2.5).p("ArFAAIWLAA");
	this.shape_35.setTransform(526.1,22.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D91729").ss(2.5).p("ArZAAIWzAA");
	this.shape_36.setTransform(528.1,22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},123).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_18}]},7).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).wait(18));

	// LineaCrece
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#339933").ss(2.5).p("AgtAAIBbAA");
	this.shape_37.setTransform(240.1,22.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#339933").ss(2.5).p("Ag/AAIB/AA");
	this.shape_38.setTransform(241.9,22.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#339933").ss(2.5).p("AhRAAICjAA");
	this.shape_39.setTransform(243.7,22.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#339933").ss(2.5).p("AhiAAIDFAA");
	this.shape_40.setTransform(245.4,22.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#339933").ss(2.5).p("Ah0AAIDpAA");
	this.shape_41.setTransform(247.2,22.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#339933").ss(2.5).p("AiGAAIENAA");
	this.shape_42.setTransform(249,22.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#339933").ss(2.5).p("AiYAAIExAA");
	this.shape_43.setTransform(250.8,22.6);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#339933").ss(2.5).p("AiqAAIFVAA");
	this.shape_44.setTransform(252.6,22.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#339933").ss(2.5).p("Ai8AAIF5AA");
	this.shape_45.setTransform(254.4,22.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#339933").ss(2.5).p("AjNAAIGbAA");
	this.shape_46.setTransform(256.1,22.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#339933").ss(2.5).p("AjfAAIG/AA");
	this.shape_47.setTransform(257.9,22.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#339933").ss(2.5).p("AjxAAIHjAA");
	this.shape_48.setTransform(259.7,22.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#339933").ss(2.5).p("AkDAAIIHAA");
	this.shape_49.setTransform(261.5,22.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#339933").ss(2.5).p("AkVAAIIrAA");
	this.shape_50.setTransform(263.3,22.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#339933").ss(2.5).p("AkmAAIJNAA");
	this.shape_51.setTransform(265,22.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#339933").ss(2.5).p("Ak4AAIJxAA");
	this.shape_52.setTransform(266.8,22.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#339933").ss(2.5).p("AlKAAIKVAA");
	this.shape_53.setTransform(268.6,22.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#339933").ss(2.5).p("AlcAAIK5AA");
	this.shape_54.setTransform(270.4,22.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#339933").ss(2.5).p("AluAAILdAA");
	this.shape_55.setTransform(272.2,22.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#339933").ss(2.5).p("AmCAAIMFAA");
	this.shape_56.setTransform(274.2,22.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#339933").ss(2.5).p("AmWAAIMtAA");
	this.shape_57.setTransform(276.2,22.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#339933").ss(2.5).p("AmrAAINXAA");
	this.shape_58.setTransform(278.3,22.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#339933").ss(2.5).p("Am/AAIN/AA");
	this.shape_59.setTransform(280.3,22.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#339933").ss(2.5).p("AnTAAIOnAA");
	this.shape_60.setTransform(282.3,22.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#339933").ss(2.5).p("AnoAAIPRAA");
	this.shape_61.setTransform(284.4,22.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#339933").ss(2.5).p("An8AAIP5AA");
	this.shape_62.setTransform(286.4,22.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#339933").ss(2.5).p("AoQAAIQhAA");
	this.shape_63.setTransform(288.4,22.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#339933").ss(2.5).p("AolAAIRLAA");
	this.shape_64.setTransform(290.5,22.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#339933").ss(2.5).p("Ao5AAIRzAA");
	this.shape_65.setTransform(292.5,22.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#339933").ss(2.5).p("ApNAAISbAA");
	this.shape_66.setTransform(294.5,22.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#339933").ss(2.5).p("ApiAAITFAA");
	this.shape_67.setTransform(296.6,22.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#339933").ss(2.5).p("Ap2AAITtAA");
	this.shape_68.setTransform(298.6,22.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#339933").ss(2.5).p("AqKAAIUVAA");
	this.shape_69.setTransform(300.6,22.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#339933").ss(2.5).p("AqfAAIU/AA");
	this.shape_70.setTransform(302.7,22.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#339933").ss(2.5).p("AqzAAIVnAA");
	this.shape_71.setTransform(304.7,22.5);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#339933").ss(2.5).p("ArHAAIWPAA");
	this.shape_72.setTransform(306.7,22.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#339933").ss(2.5).p("ArcAAIW5AA");
	this.shape_73.setTransform(308.8,22.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#339933").ss(2.5).p("ArwAAIXhAA");
	this.shape_74.setTransform(310.8,22.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#339933").ss(2.5).p("AsEAAIYJAA");
	this.shape_75.setTransform(312.8,22.5);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#339933").ss(2.5).p("AsYAAIYxAA");
	this.shape_76.setTransform(314.8,22.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#339933").ss(2.5).p("AstAAIZbAA");
	this.shape_77.setTransform(316.9,22.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#339933").ss(2.5).p("AtBAAIaDAA");
	this.shape_78.setTransform(318.9,22.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#339933").ss(2.5).p("AtVAAIarAA");
	this.shape_79.setTransform(320.9,22.5);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#339933").ss(2.5).p("AtpAAIbTAA");
	this.shape_80.setTransform(322.9,22.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#339933").ss(2.5).p("At+AAIb9AA");
	this.shape_81.setTransform(325,22.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#339933").ss(2.5).p("AuSAAIclAA");
	this.shape_82.setTransform(327,22.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#339933").ss(2.5).p("AumAAIdNAA");
	this.shape_83.setTransform(329,22.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#339933").ss(2.5).p("Au6AAId1AA");
	this.shape_84.setTransform(331,22.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#339933").ss(2.5).p("AvPAAIefAA");
	this.shape_85.setTransform(333.1,22.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#339933").ss(2.5).p("AvjAAIfHAA");
	this.shape_86.setTransform(335.1,22.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#339933").ss(2.5).p("Av3AAIfvAA");
	this.shape_87.setTransform(337.1,22.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#339933").ss(2.5).p("AwLAAMAgXAAA");
	this.shape_88.setTransform(339.1,22.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#339933").ss(2.5).p("AwgAAMAhBAAA");
	this.shape_89.setTransform(341.2,22.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#339933").ss(2.5).p("Aw0AAMAhpAAA");
	this.shape_90.setTransform(343.2,22.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#339933").ss(2.5).p("AxIAAMAiRAAA");
	this.shape_91.setTransform(345.2,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_37}]},50).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_55}]},6).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_73}]},6).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).wait(68));

	// Capa 6
	this.instance = new lib.CdP_TextoSumar();
	this.instance.setTransform(379.9,144.8,1,1,0,0,0,391.9,39.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(166).to({_off:false},0).wait(1).to({regX:407.1,x:395.1,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

	// Flechas
	this.instance_1 = new lib.CdP_FlechaVerde();
	this.instance_1.setTransform(274.9,-107.5,0.706,0.706,180,0,0,54.5,26.1);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.CdP_FlechaRoja();
	this.instance_2.setTransform(494.4,-107.5,0.706,0.706,180,0,0,54.5,26.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:274.9,y:-107.5,alpha:0}}]},50).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:274.8,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:348.1,y:-107.5,alpha:0}}]},6).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:347.9,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:418.4,y:-107.5,alpha:0}}]},6).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.7,regY:26.6,rotation:-179.9,x:418.2,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_2,p:{regX:54.5,regY:26.1,rotation:180,x:494.4,y:-107.5,alpha:0}}]},7).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:494.2,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_2,p:{regX:54.5,regY:26.1,rotation:180,x:566.6,y:-107.5,alpha:0}}]},7).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_2,p:{regX:54.7,regY:26.6,rotation:-179.9,x:566.4,y:-107.8,alpha:0}}]},1).to({state:[]},1).wait(18));

	// Perro2
	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgGAUQgMgGgDgOQgEgPAPgGQAOgGAMARQALAMgGALQgDAFgFADQgFADgFAAQgEAAgFgEg");
	this.shape_92.setTransform(275.5,-45.5,1,1,0,0,180);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgFQgGgLALgMQAMgRAOAGQAPAGgDAPQgEAOgLAGQgGAEgEAAQgFAAgFgDg");
	this.shape_93.setTransform(284.6,-46,1,1,0,0,180);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AAfAOQgPgLgIgDQgGgDgGAGQgKAMgWABQgZABgKgRQgJgRAJAAQACAAACAHQADAKALAEQAMAIASgHQAMgFAHgFQAJgLARAQQASAQAXgLQAGgDgDgIIgDgLQAaASgZAMQgJAFgJAAQgHAAgIgEg");
	this.shape_94.setTransform(280.4,-28.6,1,1,0,0,180);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgFAQQgHgFgGgGQgMgKAGgHQAIgJAWADQAYAEgDAOQgDANgNAFQgFACgDAAQgEAAgEgEg");
	this.shape_95.setTransform(280.6,-33.2,1,1,0,0,180);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AA5AfQgOgVgNgKQgSgLgZgFQgWgEgJAPQgJANgDAAQgFAAAAgIQAAgIAHgJQAQgYAjAJQAhAJATAaQAKAOADAMQAAAGgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBgBgBg");
	this.shape_96.setTransform(292.8,-40.7,1,1,0,0,180);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("Ag9AdIANgaQATgaAhgJQAkgJAQAZQAGAIAAAIQAAAIgFAAQgDAAgJgNQgJgOgWAEQgZAFgSAKQgOALgNAUQgCAEgBAAQgCAAAAgGg");
	this.shape_97.setTransform(266.8,-40.4,1,1,0,0,180);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgVBRQgtgHgegRQgfgTACgXQAEgtAzggQAwgeAlAJQAuALAmAnQAsAsgbAqQgWAhhAAAQgYAAgbgFg");
	this.shape_98.setTransform(280.2,-28.3,1,1,0,0,180);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D06F1A").s().p("AkgAHQgGhlBbgxQBLgpCAAAQB8AABOAsQBbAygEBeQgDBchkAyQhPAnhmAAQkbAAgKiyg");
	this.shape_99.setTransform(280,-35.7,1,1,0,0,180);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgSAcQgKgLgGgPQgKgdAZgUQATgPAlALQAEAzgUA4QgTgGgUgWg");
	this.shape_100.setTransform(232.7,-37.9,1,1,0,0,180);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AglAPQgHgIgCgJQgGgVATgMQAWgPAjAaQAlAYgTAUQgTAVgTAAQgUAAgVgag");
	this.shape_101.setTransform(251.6,-16.3,1,1,0,0,180);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgxAnQgdADgYANQgCgiAOgXQASgjAugPQA+gVAnAuQAjAngIAwQg9gdhaAIg");
	this.shape_102.setTransform(266.4,-11.1,1,1,0,0,180);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#D06F1A").s().p("AjUESQg1gigjhEQglhHAcgcQAdgeBHgMQAkgGAeAAQBQgMBYgPQA8gGA/AeQAkgPAPgqQAJgZAEgvIAGhOQAKhaAvgBQAcgBAMAoQAMAmgJA3QgYCKhpA0QA0AmgsBSQgnBHgvAWQgcAOAnhSQAkhOgNAKQhAAvgGBFQgFAogngFQgPgCgEgJQgEgLAPgNQA4g1gsgWQglgThkAJQgpAEgGAKQgEAHAOASQASAXADALQAGAWgUASQgcAbgjhJIgcg7QgQgggNgHQgSgLAqBaQAkBLgNAAQgDAAgEgDg");
	this.shape_103.setTransform(261.1,-22.5,1,1,0,0,180);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AAjA8QgLgFgXgXQgSgTgMgDQgSgEgQAWIgYgRIAVglQAcgmAigBQAogBAiAzQAjAxgfAaQgKAGgKAAQgKAAgJgGg");
	this.shape_104.setTransform(252.1,-50.5,1,1,0,0,180);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AhJA8QgfgaAjgxQAigzAoABQAiABAcAmQAOAUAHARIgYARQgQgWgSAEQgMACgSAUQgYAXgKAFQgKAGgJAAQgKAAgKgGg");
	this.shape_105.setTransform(309.8,-50.5,1,1,0,0,180);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("Ai0FAQgWgSAAgZQAAgfAnguIADgEIgTAPQgdAWgNAHQgXAMgSgHQgXgHgIggQgCgKAAgHQAAgyBHgtQhQgZgng2QgegpgEg6IAAgNQAAgrAQgiQgVARgRAFQgZAHgXgPIgDgCQgRgOgEgVQgEgWAJgYQANgjAfgaQAigdAiABQA2AAAmBBQBOgkB4AAQBqAABOAgQAng9AzAAQAigBAiAdQAfAaANAjQAJAYgEAWQgEAVgRAOIgBABIgCABQgfAUgggSQALAdAAAiIAAAHQgDA5ghApQAbAHAfAOQAUgNAIgYQAJgZAFhIQAFhKAMggQATg1AxgBQAbgBATAVQAWAZAEAxIABAOIgBAdIgFAeQgFAZgHAVQgeBXhEAxQAfAdASAiQASAiAAAdIgBAIQgDAlggAQQgYALgWgMIAAABQAAAVgOARQgKAMgQAGQgQAFgQgDQgmgHgOgoQgLgegqgUIgOgFIgGgCIgBgBIgGgBIgBgBIgQgEIgagEIgQgBIgDAAIgeAAIguAGIgCABIgCABIgOAGQgdAPgiAsQgSAVgKAJQgPANgRACIgEAAQgSAAgRgNg");
	this.shape_106.setTransform(273.7,-26.3,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_106,p:{x:273.7}},{t:this.shape_105,p:{x:309.8}},{t:this.shape_104,p:{x:252.1}},{t:this.shape_103,p:{x:261.1}},{t:this.shape_102,p:{x:266.4}},{t:this.shape_101,p:{x:251.6}},{t:this.shape_100,p:{x:232.7}},{t:this.shape_99,p:{x:280}},{t:this.shape_98,p:{x:280.2}},{t:this.shape_97,p:{x:266.8}},{t:this.shape_96,p:{x:292.8}},{t:this.shape_95,p:{x:280.6}},{t:this.shape_94,p:{x:280.4}},{t:this.shape_93,p:{x:284.6}},{t:this.shape_92,p:{x:275.5}}]},50).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:344}},{t:this.shape_105,p:{x:380.1}},{t:this.shape_104,p:{x:322.4}},{t:this.shape_103,p:{x:331.4}},{t:this.shape_102,p:{x:336.7}},{t:this.shape_101,p:{x:321.9}},{t:this.shape_100,p:{x:303}},{t:this.shape_99,p:{x:350.3}},{t:this.shape_98,p:{x:350.5}},{t:this.shape_97,p:{x:337.1}},{t:this.shape_96,p:{x:363.1}},{t:this.shape_95,p:{x:350.9}},{t:this.shape_94,p:{x:350.7}},{t:this.shape_93,p:{x:354.9}},{t:this.shape_92,p:{x:345.8}}]},17).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:418.1}},{t:this.shape_105,p:{x:454.2}},{t:this.shape_104,p:{x:396.5}},{t:this.shape_103,p:{x:405.5}},{t:this.shape_102,p:{x:410.8}},{t:this.shape_101,p:{x:396}},{t:this.shape_100,p:{x:377.1}},{t:this.shape_99,p:{x:424.4}},{t:this.shape_98,p:{x:424.6}},{t:this.shape_97,p:{x:411.2}},{t:this.shape_96,p:{x:437.2}},{t:this.shape_95,p:{x:425}},{t:this.shape_94,p:{x:424.8}},{t:this.shape_93,p:{x:429}},{t:this.shape_92,p:{x:419.9}}]},17).to({state:[]},7).to({state:[]},11).to({state:[{t:this.shape_106,p:{x:492.2}},{t:this.shape_105,p:{x:528.3}},{t:this.shape_104,p:{x:470.6}},{t:this.shape_103,p:{x:479.6}},{t:this.shape_102,p:{x:484.9}},{t:this.shape_101,p:{x:470.1}},{t:this.shape_100,p:{x:451.2}},{t:this.shape_99,p:{x:498.5}},{t:this.shape_98,p:{x:498.7}},{t:this.shape_97,p:{x:485.3}},{t:this.shape_96,p:{x:511.3}},{t:this.shape_95,p:{x:499.1}},{t:this.shape_94,p:{x:498.9}},{t:this.shape_93,p:{x:503.1}},{t:this.shape_92,p:{x:494}}]},7).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:564.4}},{t:this.shape_105,p:{x:600.5}},{t:this.shape_104,p:{x:542.8}},{t:this.shape_103,p:{x:551.8}},{t:this.shape_102,p:{x:557.1}},{t:this.shape_101,p:{x:542.3}},{t:this.shape_100,p:{x:523.4}},{t:this.shape_99,p:{x:570.7}},{t:this.shape_98,p:{x:570.9}},{t:this.shape_97,p:{x:557.5}},{t:this.shape_96,p:{x:583.5}},{t:this.shape_95,p:{x:571.3}},{t:this.shape_94,p:{x:571.1}},{t:this.shape_93,p:{x:575.3}},{t:this.shape_92,p:{x:566.2}}]},18).to({state:[]},7).wait(29));

	// Perro1
	this.instance_3 = new lib.CdP_Perro();
	this.instance_3.setTransform(236.4,-26.2,1,1,0,0,0,47.4,33.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({_off:false},0).wait(1).to({regX:47.3,x:236.3,alpha:0.077},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:1},0).wait(13).to({_off:true},1).wait(7).to({regX:47.4,x:310.5,_off:false},0).to({_off:true},17).wait(7).to({x:380.8,_off:false},0).to({_off:true},17).wait(7).to({x:455.9,_off:false},0).to({_off:true},18).wait(7).to({x:527.1,_off:false},0).to({_off:true},18).wait(7).to({x:601.2,_off:false},0).wait(29));

	// RectaNumerica
	this.text = new cjs.Text("+7", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(730.4,44.8+incremento);

	this.text_1 = new cjs.Text("+6", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(657.4,44.8+incremento);

	this.text_2 = new cjs.Text("+5", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(585.4,44.8+incremento);

	this.text_3 = new cjs.Text("+4", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(511.4,44.8+incremento);

	this.text_4 = new cjs.Text("+3", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(439.4,44.8+incremento);

	this.text_5 = new cjs.Text("+2", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(365.4,44.8+incremento);

	this.text_6 = new cjs.Text("+1", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(292.4,44.8+incremento);

	this.text_7 = new cjs.Text("0", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(226,44.8+incremento);

	this.text_8 = new cjs.Text("-1", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(146,44.8+incremento);

	this.text_9 = new cjs.Text("-2", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(72,44.8+incremento);

	this.text_10 = new cjs.Text("-3", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(0,44.8+incremento);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_107.setTransform(673.5,22.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_108.setTransform(601,22.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_109.setTransform(528,22.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_110.setTransform(455,22.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_111.setTransform(382,22.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_112.setTransform(309,22.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_113.setTransform(235.5,22.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_114.setTransform(163,22.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_115.setTransform(89.5,22.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_116.setTransform(746.5,22.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_117.setTransform(17,22.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_118.setTransform(381.5,22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(184));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.7,0,812.4,303);


(lib.CdP_SumarNegativos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	
	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D91729").ss(2.5).p("AANAAIgYAA");
	this.shape.setTransform(233.7,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D91729").ss(2.5).p("AgfAAIA/AA");
	this.shape_1.setTransform(231.8,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D91729").ss(2.5).p("AgyAAIBlAA");
	this.shape_2.setTransform(229.8,22.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#D91729").ss(2.5).p("AhFAAICLAA");
	this.shape_3.setTransform(227.9,22.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#D91729").ss(2.5).p("AhZAAICzAA");
	this.shape_4.setTransform(226,22.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#D91729").ss(2.5).p("AhsAAIDZAA");
	this.shape_5.setTransform(224.1,22.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D91729").ss(2.5).p("Ah/AAID/AA");
	this.shape_6.setTransform(222.1,22.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#D91729").ss(2.5).p("AiSAAIElAA");
	this.shape_7.setTransform(220.2,22.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#D91729").ss(2.5).p("AimAAIFNAA");
	this.shape_8.setTransform(218.3,22.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#D91729").ss(2.5).p("Ai5AAIFzAA");
	this.shape_9.setTransform(216.4,22.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#D91729").ss(2.5).p("AjMAAIGZAA");
	this.shape_10.setTransform(214.4,22.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#D91729").ss(2.5).p("AjgAAIHBAA");
	this.shape_11.setTransform(212.5,22.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#D91729").ss(2.5).p("AjzAAIHnAA");
	this.shape_12.setTransform(210.6,22.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#D91729").ss(2.5).p("AkGAAIINAA");
	this.shape_13.setTransform(208.6,22.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#D91729").ss(2.5).p("AkZAAIIzAA");
	this.shape_14.setTransform(206.7,22.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#D91729").ss(2.5).p("AktAAIJbAA");
	this.shape_15.setTransform(204.8,22.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#D91729").ss(2.5).p("AlAAAIKBAA");
	this.shape_16.setTransform(202.9,22.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#D91729").ss(2.5).p("AlTAAIKnAA");
	this.shape_17.setTransform(200.9,22.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#D91729").ss(2.5).p("AFoAAIrPAA");
	this.shape_18.setTransform(199,22.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#D91729").ss(2.5).p("Al7AAIL3AA");
	this.shape_19.setTransform(197,22.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#D91729").ss(2.5).p("AmPAAIMfAA");
	this.shape_20.setTransform(194.9,22.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#D91729").ss(2.5).p("AmkAAINJAA");
	this.shape_21.setTransform(192.9,22.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#D91729").ss(2.5).p("Am4AAINxAA");
	this.shape_22.setTransform(190.8,22.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#D91729").ss(2.5).p("AnMAAIOZAA");
	this.shape_23.setTransform(188.8,22.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#D91729").ss(2.5).p("AnhAAIPDAA");
	this.shape_24.setTransform(186.8,22.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#D91729").ss(2.5).p("An1AAIPrAA");
	this.shape_25.setTransform(184.7,22.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#D91729").ss(2.5).p("AoKAAIQVAA");
	this.shape_26.setTransform(182.7,22.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#D91729").ss(2.5).p("AoeAAIQ9AA");
	this.shape_27.setTransform(180.7,22.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#D91729").ss(2.5).p("AoyAAIRlAA");
	this.shape_28.setTransform(178.6,22.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#D91729").ss(2.5).p("ApHAAISPAA");
	this.shape_29.setTransform(176.6,22.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#D91729").ss(2.5).p("ApbAAIS3AA");
	this.shape_30.setTransform(174.5,22.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#D91729").ss(2.5).p("ApwAAIThAA");
	this.shape_31.setTransform(172.5,22.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#D91729").ss(2.5).p("AqEAAIUJAA");
	this.shape_32.setTransform(170.5,22.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#D91729").ss(2.5).p("AqYAAIUxAA");
	this.shape_33.setTransform(168.4,22.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#D91729").ss(2.5).p("AqtAAIVbAA");
	this.shape_34.setTransform(166.4,22.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#D91729").ss(2.5).p("ArBAAIWDAA");
	this.shape_35.setTransform(164.3,22.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#D91729").ss(2.5).p("ALWAAI2sAA");
	this.shape_36.setTransform(162.3,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},123).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_18}]},7).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).wait(18));

	// Capa 3
	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#339933").ss(2.5).p("AAHAAIgNAA");
	this.shape_37.setTransform(454.5,22.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#339933").ss(2.5).p("AgaAAIA1AA");
	this.shape_38.setTransform(452.5,22.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#339933").ss(2.5).p("AguAAIBdAA");
	this.shape_39.setTransform(450.5,22.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#339933").ss(2.5).p("AhCAAICFAA");
	this.shape_40.setTransform(448.5,22.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#339933").ss(2.5).p("AhWAAICtAA");
	this.shape_41.setTransform(446.5,22.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#339933").ss(2.5).p("AhqAAIDVAA");
	this.shape_42.setTransform(444.5,22.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#339933").ss(2.5).p("Ah+AAID9AA");
	this.shape_43.setTransform(442.5,22.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#339933").ss(2.5).p("AiSAAIElAA");
	this.shape_44.setTransform(440.5,22.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#339933").ss(2.5).p("AimAAIFNAA");
	this.shape_45.setTransform(438.5,22.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#339933").ss(2.5).p("Ai6AAIF1AA");
	this.shape_46.setTransform(436.5,22.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#339933").ss(2.5).p("AjOAAIGdAA");
	this.shape_47.setTransform(434.5,22.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#339933").ss(2.5).p("AjiAAIHFAA");
	this.shape_48.setTransform(432.5,22.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#339933").ss(2.5).p("Aj2AAIHtAA");
	this.shape_49.setTransform(430.5,22.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#339933").ss(2.5).p("AkKAAIIVAA");
	this.shape_50.setTransform(428.5,22.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#339933").ss(2.5).p("AkeAAII9AA");
	this.shape_51.setTransform(426.5,22.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#339933").ss(2.5).p("AkyAAIJlAA");
	this.shape_52.setTransform(424.5,22.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#339933").ss(2.5).p("AlGAAIKNAA");
	this.shape_53.setTransform(422.5,22.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#339933").ss(2.5).p("AlaAAIK1AA");
	this.shape_54.setTransform(420.5,22.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#339933").ss(2.5).p("AFwAAIrfAA");
	this.shape_55.setTransform(418.5,22.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#339933").ss(2.5).p("AmDAAIMHAA");
	this.shape_56.setTransform(416.4,22.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#339933").ss(2.5).p("AmXAAIMvAA");
	this.shape_57.setTransform(414.4,22.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#339933").ss(2.5).p("AmrAAINXAA");
	this.shape_58.setTransform(412.4,22.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#339933").ss(2.5).p("AnAAAIOBAA");
	this.shape_59.setTransform(410.3,22.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#339933").ss(2.5).p("AnUAAIOpAA");
	this.shape_60.setTransform(408.3,22.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#339933").ss(2.5).p("AnoAAIPRAA");
	this.shape_61.setTransform(406.3,22.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#339933").ss(2.5).p("An8AAIP5AA");
	this.shape_62.setTransform(404.3,22.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#339933").ss(2.5).p("AoRAAIQjAA");
	this.shape_63.setTransform(402.2,22.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#339933").ss(2.5).p("AolAAIRLAA");
	this.shape_64.setTransform(400.2,22.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#339933").ss(2.5).p("Ao5AAIRzAA");
	this.shape_65.setTransform(398.2,22.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#339933").ss(2.5).p("ApNAAISbAA");
	this.shape_66.setTransform(396.2,22.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#339933").ss(2.5).p("ApiAAITFAA");
	this.shape_67.setTransform(394.1,22.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#339933").ss(2.5).p("Ap2AAITtAA");
	this.shape_68.setTransform(392.1,22.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#339933").ss(2.5).p("AqKAAIUVAA");
	this.shape_69.setTransform(390.1,22.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#339933").ss(2.5).p("AqeAAIU9AA");
	this.shape_70.setTransform(388.1,22.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#339933").ss(2.5).p("AqzAAIVnAA");
	this.shape_71.setTransform(386,22.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#339933").ss(2.5).p("ArHAAIWPAA");
	this.shape_72.setTransform(384,22.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#339933").ss(2.5).p("ALcAAI23AA");
	this.shape_73.setTransform(382,22.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#339933").ss(2.5).p("ArwAAIXhAA");
	this.shape_74.setTransform(379.9,22.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#339933").ss(2.5).p("AsEAAIYJAA");
	this.shape_75.setTransform(377.9,22.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#339933").ss(2.5).p("AsZAAIYzAA");
	this.shape_76.setTransform(375.8,22.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#339933").ss(2.5).p("AstAAIZbAA");
	this.shape_77.setTransform(373.8,22.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#339933").ss(2.5).p("AtCAAIaFAA");
	this.shape_78.setTransform(371.7,22.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#339933").ss(2.5).p("AtXAAIavAA");
	this.shape_79.setTransform(369.6,22.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#339933").ss(2.5).p("AtrAAIbXAA");
	this.shape_80.setTransform(367.6,22.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#339933").ss(2.5).p("AuAAAIcBAA");
	this.shape_81.setTransform(365.5,22.5);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#339933").ss(2.5).p("AuUAAIcpAA");
	this.shape_82.setTransform(363.5,22.5);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#339933").ss(2.5).p("AupAAIdTAA");
	this.shape_83.setTransform(361.4,22.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#339933").ss(2.5).p("Au9AAId7AA");
	this.shape_84.setTransform(359.4,22.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#339933").ss(2.5).p("AvSAAIelAA");
	this.shape_85.setTransform(357.3,22.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#339933").ss(2.5).p("AvmAAIfNAA");
	this.shape_86.setTransform(355.3,22.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#339933").ss(2.5).p("Av7AAIf3AA");
	this.shape_87.setTransform(353.2,22.5);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#339933").ss(2.5).p("AwQAAMAghAAA");
	this.shape_88.setTransform(351.1,22.5);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#339933").ss(2.5).p("AwkAAMAhJAAA");
	this.shape_89.setTransform(349.1,22.5);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#339933").ss(2.5).p("Aw5AAMAhzAAA");
	this.shape_90.setTransform(347,22.5);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#339933").ss(2.5).p("AROAAMgibAAA");
	this.shape_91.setTransform(345,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_37}]},50).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_55}]},6).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_73}]},6).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).wait(68));

	// Capa 6
	this.instance = new lib.CdP_TextoRestar();
	this.instance.setTransform(379.9,144.8,1,1,0,0,0,391.9,39.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(166).to({_off:false},0).wait(1).to({regX:393.5,x:381.5,alpha:0.059},0).wait(1).to({alpha:0.118},0).wait(1).to({alpha:0.176},0).wait(1).to({alpha:0.235},0).wait(1).to({alpha:0.294},0).wait(1).to({alpha:0.353},0).wait(1).to({alpha:0.412},0).wait(1).to({alpha:0.471},0).wait(1).to({alpha:0.529},0).wait(1).to({alpha:0.588},0).wait(1).to({alpha:0.647},0).wait(1).to({alpha:0.706},0).wait(1).to({alpha:0.765},0).wait(1).to({alpha:0.824},0).wait(1).to({alpha:0.882},0).wait(1).to({alpha:0.941},0).wait(1).to({alpha:1},0).wait(1));

	// Flechas
	this.instance_1 = new lib.CdP_FlechaVerde2();
	this.instance_1.setTransform(415.7,-107.5,0.706,0.706,180,0,0,54.5,26.1);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.CdP_FlechaRoja2();
	this.instance_2.setTransform(197,-107.5,0.706,0.706,180,0,0,54.5,26.1);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:415.7,y:-107.5,alpha:0}}]},50).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:415.8,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:342.5,y:-107.5,alpha:0}}]},6).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:342.5,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_1,p:{regX:54.5,regY:26.1,rotation:180,x:271.2,y:-107.5,alpha:0}}]},6).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_1,p:{regX:54.4,regY:26.6,rotation:-179.9,x:271.2,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_2,p:{regX:54.5,regY:26.1,rotation:180,x:197,y:-107.5,alpha:0}}]},7).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.167}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.333}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.5}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.667}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.833}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:1}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.909}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.818}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.727}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.636}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.545}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.455}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.364}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.273}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.182}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0.091}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:197.1,y:-107.8,alpha:0}}]},1).to({state:[]},1).to({state:[{t:this.instance_2,p:{regX:54.5,regY:26.2,rotation:180,x:125.1,y:-107.8,alpha:0}}]},7).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.167}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.333}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.5}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.667}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.833}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:1}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.909}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.818}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.727}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.636}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.545}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.455}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.364}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.273}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.182}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0.091}}]},1).to({state:[{t:this.instance_2,p:{regX:54.4,regY:26.6,rotation:-179.9,x:125.2,y:-108.1,alpha:0}}]},1).to({state:[]},1).wait(18));

	// Perro2
	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgGAUQgMgGgDgOQgEgPAPgGQAOgGAMARQALAMgGALQgDAFgFADQgFADgFAAQgEAAgFgEg");
	this.shape_92.setTransform(416.4,-46.3);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgMAVQgFgDgDgFQgGgLALgMQAMgRAOAGQAPAGgDAPQgEAOgLAGQgGAEgEAAQgFAAgFgDg");
	this.shape_93.setTransform(407.3,-46.8);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AAfAOQgPgLgIgDQgGgDgGAGQgKAMgWABQgZABgKgRQgJgRAJAAQACAAACAHQADAKALAEQAMAIASgHQAMgFAHgFQAJgLARAQQASAQAXgLQAGgDgDgIIgDgLQAaASgZAMQgJAFgJAAQgHAAgIgEg");
	this.shape_94.setTransform(411.5,-29.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgFAQQgHgFgGgGQgMgKAGgHQAIgJAWADQAYAEgDAOQgDANgNAFQgFACgDAAQgEAAgEgEg");
	this.shape_95.setTransform(411.3,-33.9);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AA5AfQgOgVgNgKQgSgLgZgFQgWgEgJAPQgJANgDAAQgFAAAAgIQAAgIAHgJQAQgYAjAJQAhAJATAaQAKAOADAMQAAAGgCAAQAAAAAAAAQgBAAAAgBQAAAAgBgBQAAgBgBgBg");
	this.shape_96.setTransform(399.1,-41.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("Ag9AdIANgaQATgaAhgJQAkgJAQAZQAGAIAAAIQAAAIgFAAQgDAAgJgNQgJgOgWAEQgZAFgSAKQgOALgNAUQgCAEgBAAQgCAAAAgGg");
	this.shape_97.setTransform(425.1,-41.1);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgVBRQgtgHgegRQgfgTACgXQAEgtAzggQAwgeAlAJQAuALAmAnQAsAsgbAqQgWAhhAAAQgYAAgbgFg");
	this.shape_98.setTransform(411.7,-29.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D06F1A").s().p("AkgAHQgGhlBbgxQBLgpCAAAQB8AABOAsQBbAygEBeQgDBchkAyQhPAnhmAAQkbAAgKiyg");
	this.shape_99.setTransform(411.9,-36.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AgSAcQgKgLgGgPQgKgdAZgUQATgPAlALQAEAzgUA4QgTgGgUgWg");
	this.shape_100.setTransform(459.2,-38.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AglAPQgHgIgCgJQgGgVATgMQAWgPAjAaQAlAYgTAUQgTAVgTAAQgUAAgVgag");
	this.shape_101.setTransform(440.3,-17);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgxAnQgdADgYANQgCgiAOgXQASgjAugPQA+gVAnAuQAjAngIAwQg9gdhaAIg");
	this.shape_102.setTransform(425.5,-11.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#D06F1A").s().p("AjUESQg1gigjhEQglhHAcgcQAdgeBHgMQAkgGAeAAQBQgMBYgPQA8gGA/AeQAkgPAPgqQAJgZAEgvIAGhOQAKhaAvgBQAcgBAMAoQAMAmgJA3QgYCKhpA0QA0AmgsBSQgnBHgvAWQgcAOAnhSQAkhOgNAKQhAAvgGBFQgFAogngFQgPgCgEgJQgEgLAPgNQA4g1gsgWQglgThkAJQgpAEgGAKQgEAHAOASQASAXADALQAGAWgUASQgcAbgjhJIgcg7QgQgggNgHQgSgLAqBaQAkBLgNAAQgDAAgEgDg");
	this.shape_103.setTransform(430.8,-23.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AAjA8QgLgFgXgXQgSgTgMgDQgSgEgQAWIgYgRIAVglQAcgmAigBQAogBAiAzQAjAxgfAaQgKAGgKAAQgKAAgJgGg");
	this.shape_104.setTransform(439.8,-51.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AhJA8QgfgaAjgxQAigzAoABQAiABAcAmQAOAUAHARIgYARQgQgWgSAEQgMACgSAUQgYAXgKAFQgKAGgJAAQgKAAgKgGg");
	this.shape_105.setTransform(382.1,-51.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("Ai0FAQgWgSAAgZQAAgfAnguIADgEIgTAPQgdAWgNAHQgXAMgSgHQgXgHgIggQgCgKAAgHQAAgyBHgtQhQgZgng2QgegpgEg6IAAgNQAAgrAQgiQgVARgRAFQgZAHgXgPIgDgCQgRgOgEgVQgEgWAJgYQANgjAfgaQAigdAiABQA2AAAmBBQBOgkB4AAQBqAABOAgQAng9AzAAQAigBAiAdQAfAaANAjQAJAYgEAWQgEAVgRAOIgBABIgCABQgfAUgggSQALAdAAAiIAAAHQgDA5ghApQAbAHAfAOQAUgNAIgYQAJgZAFhIQAFhKAMggQATg1AxgBQAbgBATAVQAWAZAEAxIABAOIgBAdIgFAeQgFAZgHAVQgeBXhEAxQAfAdASAiQASAiAAAdIgBAIQgDAlggAQQgYALgWgMIAAABQAAAVgOARQgKAMgQAGQgQAFgQgDQgmgHgOgoQgLgegqgUIgOgFIgGgCIgBgBIgGgBIgBgBIgQgEIgagEIgQgBIgDAAIgeAAIguAGIgCABIgCABIgOAGQgdAPgiAsQgSAVgKAJQgPANgRACIgEAAQgSAAgRgNg");
	this.shape_106.setTransform(418.2,-27);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_106,p:{x:418.2,y:-27}},{t:this.shape_105,p:{x:382.1,y:-51.3}},{t:this.shape_104,p:{x:439.8,y:-51.3}},{t:this.shape_103,p:{x:430.8,y:-23.3}},{t:this.shape_102,p:{x:425.5,y:-11.8}},{t:this.shape_101,p:{x:440.3,y:-17}},{t:this.shape_100,p:{x:459.2,y:-38.6}},{t:this.shape_99,p:{x:411.9,y:-36.4}},{t:this.shape_98,p:{x:411.7,y:-29.1}},{t:this.shape_97,p:{x:425.1,y:-41.1}},{t:this.shape_96,p:{x:399.1,y:-41.5}},{t:this.shape_95,p:{x:411.3,y:-33.9}},{t:this.shape_94,p:{x:411.5,y:-29.4}},{t:this.shape_93,p:{x:407.3,y:-46.8}},{t:this.shape_92,p:{x:416.4,y:-46.3}}]},50).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:344,y:-26.3}},{t:this.shape_105,p:{x:307.9,y:-50.5}},{t:this.shape_104,p:{x:365.6,y:-50.5}},{t:this.shape_103,p:{x:356.6,y:-22.5}},{t:this.shape_102,p:{x:351.3,y:-11.1}},{t:this.shape_101,p:{x:366.1,y:-16.3}},{t:this.shape_100,p:{x:385,y:-37.9}},{t:this.shape_99,p:{x:337.7,y:-35.7}},{t:this.shape_98,p:{x:337.5,y:-28.3}},{t:this.shape_97,p:{x:350.9,y:-40.4}},{t:this.shape_96,p:{x:324.9,y:-40.7}},{t:this.shape_95,p:{x:337.1,y:-33.2}},{t:this.shape_94,p:{x:337.3,y:-28.6}},{t:this.shape_93,p:{x:333.1,y:-46}},{t:this.shape_92,p:{x:342.2,y:-45.5}}]},17).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:271.3,y:-27}},{t:this.shape_105,p:{x:235.2,y:-51.3}},{t:this.shape_104,p:{x:292.9,y:-51.3}},{t:this.shape_103,p:{x:283.9,y:-23.3}},{t:this.shape_102,p:{x:278.6,y:-11.8}},{t:this.shape_101,p:{x:293.4,y:-17}},{t:this.shape_100,p:{x:312.3,y:-38.6}},{t:this.shape_99,p:{x:265,y:-36.4}},{t:this.shape_98,p:{x:264.8,y:-29.1}},{t:this.shape_97,p:{x:278.2,y:-41.1}},{t:this.shape_96,p:{x:252.2,y:-41.5}},{t:this.shape_95,p:{x:264.4,y:-33.9}},{t:this.shape_94,p:{x:264.6,y:-29.4}},{t:this.shape_93,p:{x:260.4,y:-46.8}},{t:this.shape_92,p:{x:269.5,y:-46.3}}]},17).to({state:[]},7).to({state:[]},11).to({state:[{t:this.shape_106,p:{x:198.1,y:-27}},{t:this.shape_105,p:{x:162,y:-51.3}},{t:this.shape_104,p:{x:219.7,y:-51.3}},{t:this.shape_103,p:{x:210.7,y:-23.3}},{t:this.shape_102,p:{x:205.4,y:-11.8}},{t:this.shape_101,p:{x:220.2,y:-17}},{t:this.shape_100,p:{x:239.1,y:-38.6}},{t:this.shape_99,p:{x:191.8,y:-36.4}},{t:this.shape_98,p:{x:191.6,y:-29.1}},{t:this.shape_97,p:{x:205,y:-41.1}},{t:this.shape_96,p:{x:179,y:-41.5}},{t:this.shape_95,p:{x:191.2,y:-33.9}},{t:this.shape_94,p:{x:191.4,y:-29.4}},{t:this.shape_93,p:{x:187.2,y:-46.8}},{t:this.shape_92,p:{x:196.3,y:-46.3}}]},7).to({state:[]},7).to({state:[{t:this.shape_106,p:{x:123.8,y:-27.1}},{t:this.shape_105,p:{x:87.7,y:-51.3}},{t:this.shape_104,p:{x:145.4,y:-51.3}},{t:this.shape_103,p:{x:136.4,y:-23.3}},{t:this.shape_102,p:{x:131.1,y:-11.9}},{t:this.shape_101,p:{x:145.9,y:-17.1}},{t:this.shape_100,p:{x:164.8,y:-38.7}},{t:this.shape_99,p:{x:117.4,y:-36.5}},{t:this.shape_98,p:{x:117.2,y:-29.1}},{t:this.shape_97,p:{x:130.6,y:-41.2}},{t:this.shape_96,p:{x:104.7,y:-41.5}},{t:this.shape_95,p:{x:116.9,y:-34}},{t:this.shape_94,p:{x:117.1,y:-29.4}},{t:this.shape_93,p:{x:112.8,y:-46.8}},{t:this.shape_92,p:{x:121.9,y:-46.3}}]},18).to({state:[]},7).wait(29));

	// Perro1
	this.instance_3 = new lib.CdP_Perro2();
	this.instance_3.setTransform(454,-27,1,1,0,0,0,47.4,33.4);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({_off:false},0).wait(1).to({alpha:0.077},0).wait(1).to({alpha:0.154},0).wait(1).to({alpha:0.231},0).wait(1).to({alpha:0.308},0).wait(1).to({alpha:0.385},0).wait(1).to({alpha:0.462},0).wait(1).to({alpha:0.538},0).wait(1).to({alpha:0.615},0).wait(1).to({alpha:0.692},0).wait(1).to({alpha:0.769},0).wait(1).to({alpha:0.846},0).wait(1).to({alpha:0.923},0).wait(1).to({alpha:1},0).wait(13).to({_off:true},1).wait(7).to({x:380.9,_off:false},0).to({_off:true},17).wait(7).to({x:312,_off:false},0).to({_off:true},17).wait(7).to({x:236,_off:false},0).to({_off:true},18).wait(7).to({x:163.3,_off:false},0).to({_off:true},18).wait(7).to({x:91.5,y:-27,_off:false},0).wait(29));

	// RectaNumerica
	this.text = new cjs.Text("+4", "20px Verdana");
	this.text.lineHeight = 22;
	this.text.setTransform(730.4,44.8+incremento);

	this.text_1 = new cjs.Text("+3", "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.setTransform(657.4,44.8+incremento);

	this.text_2 = new cjs.Text("+2", "20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.setTransform(585.4,44.8+incremento);

	this.text_3 = new cjs.Text("+1", "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.setTransform(511.4,44.8+incremento);

	this.text_4 = new cjs.Text("0", "20px Verdana");
	this.text_4.lineHeight = 22;
	this.text_4.setTransform(447.1,44.8+incremento);

	this.text_5 = new cjs.Text("-1", "20px Verdana");
	this.text_5.lineHeight = 22;
	this.text_5.setTransform(368.7,44.8+incremento);

	this.text_6 = new cjs.Text("-2", "20px Verdana");
	this.text_6.lineHeight = 22;
	this.text_6.setTransform(296.2,44.8+incremento);

	this.text_7 = new cjs.Text("-3", "20px Verdana");
	this.text_7.lineHeight = 22;
	this.text_7.setTransform(222.7,44.8+incremento);

	this.text_8 = new cjs.Text("-4", "20px Verdana");
	this.text_8.lineHeight = 22;
	this.text_8.setTransform(150.4,44.8+incremento);

	this.text_9 = new cjs.Text("-5", "20px Verdana");
	this.text_9.lineHeight = 22;
	this.text_9.setTransform(76.4,44.8+incremento);

	this.text_10 = new cjs.Text("-6", "20px Verdana");
	this.text_10.lineHeight = 22;
	this.text_10.setTransform(4.4,44.8+incremento);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_107.setTransform(673.5,22.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_108.setTransform(601,22.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_109.setTransform(528,22.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_110.setTransform(455,22.3);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_111.setTransform(382,22.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_112.setTransform(309,22.3);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_113.setTransform(235.5,22.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_114.setTransform(163,22.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#000000").ss(1,0,0,4).p("AAAh+IAAD9");
	this.shape_115.setTransform(89.5,22.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_116.setTransform(746.5,22.3);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#000000").ss(1,0,0,4).p("AAAjdIAAG7");
	this.shape_117.setTransform(17,22.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#000000").ss(1,0,0,4).p("Eg5AAAAMByBAAA");
	this.shape_118.setTransform(381.5,22.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text}]}).wait(184));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.7,0,812.4,303);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
(lib.crossFadeElement = function (elemento1,elemento2, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, false, {});
        elemento1.alpha = 1;
        elemento2.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento1).wait(espera).to({alpha: 0}, delay).wait(1));
        this.timeline.addTween(cjs.Tween.get(elemento2).wait(espera).to({alpha: 1}, delay).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

