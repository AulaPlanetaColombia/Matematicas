function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciadoParseado;//pregunta.enunciado;
    //this.video = pregunta.video;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;


    

	this.validacio = true;
	//this.figura = operacio.figura;
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.addLine( 0, 350, 300 - 118, operacio.pregunta[0], "", operacio.respuestaString[0]);
    
    //this.contenedor.addChild( operacio.figura ); 
    
   	//this.addLine( 0, 350, 400 - 118, "P = ", operacio.tipoUnidad , operacio.respuestaString[0]  );
	//this.addLine( 1, 350, 460 - 118, "A = ", operacio.tipoUnidad+"<sp>2<n>", operacio.respuestaString[1]);

	this.correctoK = operacio.respuestaString[0]; 
    this.K = "";
}

Pagina.prototype.addLine = function( index, x, y, _text, unitat, resposta){
	
	this["text"+index] = new createjs.RichText();
	this["text"+index].text = _text + "  =";
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
	this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
	this["text"+index].color = "#0D3158";
	this["text"+index].x = 490;
	this["text"+index].y = y + 8;
	this["text"+index].textAlign = "right";
	
	this.contenedor.addChild( this["text"+index] );

    this["cajaX"+index] = new CajaTexto();
	this["cajaX"+index] .contenedor.x = x;
	this["cajaX"+index] .contenedor.y = y;

	this.contenedor.addChild( this["cajaX"+index].contenedor  );
		
	this["valor"+index] = new createjs.RichText();
	this["valor"+index].text = resposta;
    this["valor"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Verdana" : "16px Verdana" ;
	this["valor"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 18 : 16 ;
	this["valor"+index].color = "#E1001A";
	this["valor"+index].x = 650;
	this["valor"+index].y = y + 90;
	this["valor"+index].textAlign = "right";
	this["valor"+index].alpha = 0;
	
	this.contenedor.addChild( this["valor"+index]  );
	

}

function PuntoP( color )
{
	color =  color || "#000";
	this.contenedor = new createjs.Container();
	this.punto = new createjs.Shape();
	
	this.punto.graphics.beginFill(color).drawCircle(0,0,5);
	
	this.contenedor.addChild( this.punto );
}
function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 250, 40, 10);
	this.fons.x=150;
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 250, 40, 10);
    this.marc.x = 150;
	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	this.area.addChild( this.texte );
	
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 250, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 250, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 250, 40, 10);
}
