Generador = new function()
{
    this.nOp;
    
    //var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
    //var this.lTiposVariaciones:Array=[3];
        
    this.lVariaciones = new Array();

    this.lPreguntas=new Array();
    this.lRespuestas=new Array();
    this.lRespuestasString=new Array();
    this.lFiguras=new Array();

    
    //this.listAux=new Array();
    this.enun = "";
    this.co_respuestas=new createjs.Sprite();
    this.lTiposVariaciones=new Array();
    
    this.plano = "";
    this.co_pizarra = "";
    //////nuevo faase 2////
    //var hayPista=false;
    
    this.generarSerie = function(semilla)
    {
        EA._formatoBase=["Arial",20,"#000000",false];
        Random.init(semilla,100);
        
        this.lVariaciones = new Array();
        this.lPreguntas=new Array();
        this.lRespuestas=new Array();
        this.lRespuestasString=new Array();
        this.lFiguras=new Array();
        this.plano = "";
        this.co_pizarra = "";
        
        
        this.lVariaciones = new Array();
        for (var op1 = 0; op1 < Motor.qOperaciones; op1++) {
            var indice = op1 % Motor.datosXML.variaciones.length;
            //console.log(indice);
            this.lVariaciones[op1]=Motor.datosXML.variaciones[indice];
        }
        for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
            //enunciar(this.nOp,0);
            
            this.enunciar();

            //console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
        }
        
    }
    
    this.enunciar = function()
    {
        
        var enunciado;
        var tipoOp=['suma','resta','multi','divi','comb'][this.lVariaciones[this.nOp].id];
        var A,B,C,D,R;
        var tira;
        var valorPAR,valorPAR2;
        var lOp;
        var parentesis;
        var qDA,qDB,qDC,qDD;
        var AS,BS,CS,DS,RS;
        
        var lPregNUM = new Array();
        var lPregSTR = new Array();
        var lRespNUM = new Array();
        var lRespSTR = new Array();
        var lPreguntasVar = new Array();
        var lSignos = new Array();
        if(Motor.primaria==false){
            lSignos=['+','−','·',':'];
        }else{
            lSignos = ['+','−','x',':']
        }
        var lSignosR=['+','−','x',':'];
        if(Motor.primaria==false){
            lSignosR=['+','−','·',':'];
        }
        
        var valMax = 999;

        //var prueba = 'D';
        //console.log(Motor.campo);
        //console.log(tipoOp);
        switch(Motor.campo){
        //switch(prueba){
            case 'N':
                this.enun= Motor.datosXML.enunciados[0].enunciado;
                switch(tipoOp){
                    case 'suma'://suma de naturales:
                        if(Motor.primaria){
                            A=Random.integer(1,999);
                            B=Random.integer(1,999);
                        }else{
                            var qDigitos = Random.integer(3,7);
                            valMax=[999,9999,99999,999999,9999999][qDigitos-3];
                            A=Random.integer(1,valMax);
                            B=Random.integer(1,valMax);
                        }
                        lPregSTR.push(JL.num2str(A)+' + '+JL.num2str(B));
                        lRespNUM.push(A+B);
                        lRespSTR.push(JL.num2str(A+B));
                        break;
                    case 'resta'://resta de naturales:
                        if(Motor.primaria){
                            A=Random.integer(1,999);
                            B=Random.integer(1,999);
                        }else{
                            qDigitos=Random.integer(3,7);
                            valMax=[999,9999,99999,999999,9999999][qDigitos-3];
                            A=Random.integer(1,valMax);
                            B=Random.integer(1,valMax);
                        }
                        if(B>A){
                            var temp = A;
                            A=B;
                            B=temp;
                        }
                        lPregSTR.push(JL.num2str(A)+' − '+JL.num2str(B));
                        lRespNUM.push(A-B);
                        lRespSTR.push(JL.num2str(A-B));
                    break;
                    case 'multi'://multiplicación de naturales:
                        while(true){
                            A=Random.integer(1,999);
                            B=Random.integer(1,999);
                            if(A*B<100000){break;}
                        }
                        //comprobar si primaria es true
                        if(Motor.primaria){
                            lPregSTR.push(JL.num2str(A)+' x '+JL.num2str(B));
                        }else{
                            lPregSTR.push(JL.num2str(A)+' · '+JL.num2str(B));
                        }
                        lRespNUM.push(A*B);
                        lRespSTR.push(JL.num2str(A*B));
                        break;
                    case 'divi'://división de naturales:
                        var azar = Random.integer(100);
                        if(azar<50){
                            A=Random.integer(2,99);
                        }else if(azar<80){
                            A=Random.integer(2,999);
                        }else{
                            A=Random.integer(2,9);
                        }
                        B=Random.integer(2,99);
                        var P = A*B;
                        lPregSTR.push(JL.num2str(P)+' : '+JL.num2str(A));
                        lRespNUM.push(B);
                        lRespSTR.push(JL.num2str(B));
                        break;
                    case 'comb'://combinada de naturales:
                        //decide distribución de paréntesis:
                        //console.log("parentesis : " + Random.integer(12));
                        parentesis=[0,0,0,1,1,2,2,3,3,4,5,5][Random.integer(11)];
                        //parentesis=5;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        //decide distribución de operaciones:
                        lOp=[Random.integer(3),Random.integer(3),Random.integer(3)];
                        //console.log(parentesis);
                        switch(parentesis){
                            case 0://N*N*N*N
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    lOp=[Random.integer(3),Random.integer(3),Random.integer(3)];
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    //console.log(A + ", " + lSignos[lOp[0]] + ", " + B,lSignos[lOp[1]] + ", " + C + ", " + lSignos[lOp[2]] + ", " + D);
                                    var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    //R=VN.valor(A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D);
                                    R=VN.valor(array);
                                    //trace('negs:',VN2.tieneNEGS(A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D));
                                    var array2 =[A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    if(this.esNatural(R)&&(!VN2.tieneNEGS(array2))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+' '+lSignos[lOp[1]]+' '+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 1://N*N*(N*N)
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    //console.log(A + ", " + lSignos[lOp[0]] + ", " + B,lSignos[lOp[1]] + ", ( , " + lSignos[lOp[2]] + ", " + D);
                                    //R=VN.valor(A,lSignos[lOp[0]],B,lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')');
                                    var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                    R=VN.valor(array);
                                    var array2 = [C,lSignos[lOp[2]],D];
                                    valorPAR=VN.valor(array2);
                                    //if(esNatural(R)&&esNatural(valorPAR)){
                                        var array3 = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    if(this.esNatural(R)&&this.esNatural(valorPAR)&&(!VN2.tieneNEGS(array3))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+' '+lSignos[lOp[1]]+' ('+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 2://N*(N*N)*N
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    //console.log(A + ", " + lSignos[lOp[0]] + ", " + B,lSignos[lOp[1]] + ", " + C + ", " + lSignos[lOp[2]] + ", " + D);
                                    var array = [A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,')',lSignos[lOp[2]],D];
                                    R=VN.valor(array);
                                    var array2 = [B,lSignos[lOp[1]],C];
                                    valorPAR=VN.valor(array2);
                                    var array3 = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    //if(esNatural(R)&&esNatural(valorPAR)){
                                    if(this.esNatural(R)&&this.esNatural(valorPAR)&&(!VN2.tieneNEGS(array3))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' ('+JL.num2str(B)+' '+lSignos[lOp[1]]+' '+JL.num2str(C)+')'+lSignos[lOp[2]]+' '+JL.num2str(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 3://(N*N)*N*N
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    //console.log(A + ", " + lSignos[lOp[0]] + ", " + B,lSignos[lOp[1]] + ", " + C + ", " + lSignos[lOp[2]] + ", " + D);
                                    var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    R=VN.valor(array);
                                    var array2 = [A,lSignos[lOp[0]],B];
                                    valorPAR=VN.valor(array2);
                                    //if(esNatural(R)&&esNatural(valorPAR)){
                                    var array3 = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    if(this.esNatural(R)&&this.esNatural(valorPAR)&&(!VN2.tieneNEGS(array3))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira='('+JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+') '+lSignos[lOp[1]]+' '+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 4://N*(N*N*N)
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    //console.log(A + ", " + lSignos[lOp[0]] + ", (, " + B + ", " + lSignos[lOp[1]] + ", " + C + ", " + lSignos[lOp[2]] + ", " + D + ", )");
                                    var array=[A, lSignos[lOp[0]],'(', B, lSignos[lOp[1]], C, lSignos[lOp[2]], D, ')'];
                                    //R=VN.valor(A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,lSignos[lOp[2]],D,')');
                                    R=VN.valor(array);
                                    var array2 = [B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    valorPAR=VN.valor(array2);
                                    //valorPAR=VN.valor(B,lSignos[lOp[1]],C,lSignos[lOp[2]],D);
                                    //if(esNatural(R)&&esNatural(valorPAR)){
                                        var array3 = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    if(this.esNatural(R)&&this.esNatural(valorPAR)&&(!VN2.tieneNEGS(array3))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' ('+JL.num2str(B)+' '+lSignos[lOp[1]]+' '+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 5://(N*N)*(N*N)
                                //busca set de valores que den natural y no pasen por parcial negativo:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                    R=VN.valor(array);
                                    var array2 = [A,lSignos[lOp[0]],B];
                                    valorPAR=VN.valor(array2);
                                    var array3 =[C,lSignos[lOp[2]],D];
                                    valorPAR2=VN.valor(array3);
                                    //if(esNatural(R)&&esNatural(valorPAR)){
                                    var array4 = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    if(this.esNatural(R)&&this.esNatural(valorPAR)&&(!VN2.tieneNEGS(array4))){
                                        break;
                                    }
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira='('+JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+') '+lSignos[lOp[1]]+' ('+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                        }
                        break;
                }
            break;
           case 'E':
                this.enun=Motor.datosXML.enunciados[0].enunciado;
                switch(tipoOp){
                    case 'suma'://suma de enteros:
                        if(Motor.primaria){
                            valMax=999;
                        }else{
                            qDigitos=Random.integer(4,7);
                            valMax=parseInt(Math.pow(10,qDigitos))-1;
                        }
                        A=Random.integer(-valMax,valMax,[0]);
                        B=Random.integer(-valMax,valMax,[0]);
                        lPregNUM.push([A,B]);
                        lRespNUM.push(A+B);
                        tira=JL.num2str(A)+' + '+this.envolver(B);
                        lPregSTR.push(tira);
                        lRespSTR.push(JL.num2str(A+B));
                        break;
                    case 'resta'://resta de enteros:
                        A=Random.integer(-valMax,valMax,[0]);
                        B=Random.integer(-valMax,valMax,[0]);
                        lPregNUM.push([A,B]);
                        lRespNUM.push(A-B);
                        tira=JL.num2str(A)+' − '+this.envolver(B);
                        lPregSTR.push(tira);
                        lRespSTR.push(JL.num2str(A-B));
                        break;
                    case 'multi'://multiplicación de enteros:
                        while(true){
                            A=Random.integer(-valMax,valMax,[0]);
                            B=Random.integer(-valMax,valMax,[0]);
                            if(Math.abs(A*B)<100000){break;}
                        }
                        lPregNUM.push([A,B]);
                        lRespNUM.push(A*B);
                        if(Motor.primaria){
                            tira=JL.num2str(A)+' x '+this.envolver(B);
                        }else{
                            tira=JL.num2str(A)+' · '+this.envolver(B);
                        }
                        lPregSTR.push(tira);
                        lRespSTR.push(JL.num2str(A*B));
                        break;
                    case 'divi'://división de enteros:
                        azar=Random.integer(100);
                        if(azar<50){
                            A=Random.integer(-99,99,[-1,0,1]);
                        }else if(azar<80){
                            A=Random.integer(-999,999,[-1,0,1]);
                        }else{
                            A=Random.integer(-9,9,[-1,0,1]);
                        }
                        B=Random.integer(-99,99,[-1,0,1]);
                        P=A*B;
                        lPregNUM.push([P,A]);
                        lPregSTR.push(JL.num2str(P)+' : '+this.envolver(A));
                        lRespNUM.push(B);
                        tira=(B>0)?'+':'';
                        lRespSTR.push(tira+JL.num2str(B));
                        break;
                    case 'comb'://combinada de enteros:
                        //decide distribución de paréntesis:
                        parentesis=[0,0,0,1,1,2,2,3,3,4,4,5,5][Random.integer(12)];
                        //parentesis=5;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        //decide distribución de operaciones:
                        lOp=[Random.integer(3),Random.integer(3),Random.integer(3)];
                        switch(parentesis){
                            case 0://N*N*N*N
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(-9,9,[0]);
                                    B=Random.integer(-9,9,[0]);
                                    C=Random.integer(-9,9,[0]);
                                    D=Random.integer(-9,9,[0]);
                                    var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    R=VN.valor(array);
                                    if(this.esEntero(R)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' '+this.envolverNEG(B)+' '+lSignos[lOp[1]]+' '+this.envolverNEG(C)+' '+lSignos[lOp[2]]+' '+this.envolverNEG(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(String(R));
                                break;
                            case 1://N*N*(N*N)
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(-9,9,[0]);
                                    B=Random.integer(-9,9,[0]);
                                    C=Random.integer(-9,9,[0]);
                                    D=Random.integer(-9,9,[0]);
                                    var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                    R=VN.valor(array);
                                    var array2 = [C,lSignos[lOp[2]],D];
                                    valorPAR=VN.valor(array2);
                                    if(this.esEntero(R)&&this.esEntero(valorPAR)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' '+this.envolverNEG(B)+' '+lSignos[lOp[1]]+' ('+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+this.envolverNEG(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 2://N*(N*N)*N
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    var array = [A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,')',lSignos[lOp[2]],D];
                                    R=VN.valor(array);
                                    var array2 = [B,lSignos[lOp[1]],C];
                                    valorPAR=VN.valor(array2);
                                    if(this.esEntero(R)&&this.esEntero(valorPAR)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' ('+JL.num2str(B)+' '+lSignos[lOp[1]]+' '+JL.num2str(C)+')'+lSignos[lOp[2]]+' '+JL.num2str(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 3://(N*N)*N*N
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    R=VN.valor(array);
                                    var array2 = [A,lSignos[lOp[0]],B];
                                    valorPAR=VN.valor(array2);
                                    if(this.esEntero(R)&&this.esEntero(valorPAR)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira='('+JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+') '+lSignos[lOp[1]]+' '+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D);
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 4://N*(N*N*N)
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    var array = [A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,lSignos[lOp[2]],D,')'];
                                    R=VN.valor(array);
                                    var array2 = [B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                    valorPAR=VN.valor(array2);
                                    if(this.esEntero(R)&&this.esEntero(valorPAR)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira=JL.num2str(A)+' '+lSignos[lOp[0]]+' ('+JL.num2str(B)+' '+lSignos[lOp[1]]+' '+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                            case 5://(N*N)*(N*N)
                                //busca set de valores que den entero:
                                while(true){
                                    A=Random.integer(1,9);
                                    B=Random.integer(1,9);
                                    C=Random.integer(1,9);
                                    D=Random.integer(1,9);
                                    var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                    R=VN.valor(array);
                                    var array2 = [A,lSignos[lOp[0]],B];
                                    valorPAR=VN.valor(array2);
                                    var array3 = [C,lSignos[lOp[2]],D];
                                    valorPAR2=VN.valor(array3);
                                    if(this.esEntero(R)&&this.esEntero(valorPAR)&&this.esEntero(valorPAR2)){break;}
                                }
                                //compone la respuesta y la tira de pregunta:
                                lRespNUM.push(R);
                                tira='('+JL.num2str(A)+' '+lSignos[lOp[0]]+' '+JL.num2str(B)+') '+lSignos[lOp[1]]+' ('+JL.num2str(C)+' '+lSignos[lOp[2]]+' '+JL.num2str(D)+')';
                                lPregSTR.push(tira);
                                lRespSTR.push(R.toString());
                                break;
                        }
                        break;
                }
                break;
                case 'D':
                    this.enun=Motor.datosXML.enunciados2[0].enunciado;
                    
                    switch(tipoOp){
                        case 'suma'://suma de decimales:
                            if(Motor.primaria){
                                A=Random.integer(0,19)+Random.random();
                                B=Random.integer(0,19)+Random.random();
                                qDA=Random.integer(1,3);
                                qDB=Random.integer(1,3);
                            }else{
                                A=Random.integer(0,49)+Random.random();
                                B=Random.integer(0,49)+Random.random();
                                qDA=Random.integer(1,5);
                                qDB=Random.integer(1,5);
                            }
                            AS=JL.num2str(A,qDA);
                            BS=JL.num2str(B,qDB);
                            var maxD = Math.max(qDA,qDB);
                            A=JL.str2num(AS);
                            B=JL.str2num(BS);
                            RS=JL.num2str(A+B,2);
                            R=JL.str2num(RS);
                            lPregSTR.push(AS+' + '+BS);
                            lRespNUM.push(R);
                            lRespSTR.push(RS);
                        break;
                        case 'resta'://resta de decimales:
                            while(true){
                                if(Motor.primaria){
                                    A=Random.integer(0,19)+Random.random();
                                    B=Random.integer(0,19)+Random.random();
                                }else{
                                    A=Random.integer(0,49)+Random.random();
                                    B=Random.integer(0,49)+Random.random();
                                }
                                if(A>B){break;}
                            }
                            if(Motor.primaria){
                                qDA=Random.integer(1,3);
                                qDB=Random.integer(1,3);
                            }else{
                                qDA=Random.integer(1,5);
                                qDB=Random.integer(1,5);
                            }
                            AS=JL.num2str(A,qDA);
                            BS=JL.num2str(B,qDB);
                            maxD=Math.max(qDA,qDB);
                            A=JL.str2num(AS);
                            B=JL.str2num(BS);
                            RS=JL.num2str(A-B,2);
                            R=JL.str2num(RS);
                            lPregNUM.push([A,B]);
                            lPregSTR.push(AS+' − '+BS);
                            lRespNUM.push(R);
                            lRespSTR.push(RS);
                            break;
                        case 'multi'://multiplicación de decimales:
                            A=Random.integer(0,19)+Random.random();
                            B=Random.integer(0,19)+Random.random();
                            while(true){
                                qDA=Random.integer(1,5);
                                qDB=Random.integer(1,5);
                                if(qDA+qDB<8){break;}
                            }
                            AS=JL.num2str(A,qDA);
                            BS=JL.num2str(B,qDB);
                            maxD=qDA+qDB;
                            A=JL.str2num(AS);
                            B=JL.str2num(BS);
                            RS=JL.num2str(A*B,2);
                            R=JL.str2num(RS);
                            if(Motor.primaria){
                                lPregSTR.push(AS+' x '+BS);
                            }else{
                                lPregSTR.push(AS+' · '+BS);
                            }
                            lRespNUM.push(R);
                            lRespSTR.push(RS);
                            break;
                        case 'divi'://división de decimales:
                            A=Random.integer(0,19)+Random.random();
                            B=Random.integer(0,19)+Random.random();
                            while(true){
                                qDA=Random.integer(1,4);
                                qDB=Random.integer(1,4);
                                if(qDA+qDB<5){break;}
                            }
                            AS=JL.num2str(A,qDA);
                            BS=JL.num2str(B,qDB);
                            A=JL.str2num(AS);
                            B=JL.str2num(BS);
                            RS=JL.num2str(B,2);
                            R=B;
                            var PN = A*B;
                            var PNS = JL.num2str(PN,qDA+qDB);
                            lPregSTR.push(PNS+' : '+AS);
                            lRespNUM.push(R);
                            lRespSTR.push(RS);
                            break;
                        case 'comb'://combinada de decimales:
                            //decide distribución de paréntesis:
                            parentesis=[0,0,0,1,1,2,2,3,3,4,5,5][Random.integer(12)];
                            //parentesis=0;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                            //decide distribución de operaciones:
                            lOp=[Random.integer(3),Random.integer(3),Random.integer(3)];
                            
                            switch(parentesis){
                                case 0://N*N*N*N
                                    //busca set de valores que den decimal:
                                    while(true){
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                        R=VN.valor(array);
                                        //if(R!=0){break;}
                                        if(Math.abs(R)>0.5){break;}
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    
                                    lRespNUM.push(R);
                                    tira=JL.num2str(A)+' '+lSignosR[lOp[0]]+' '+this.envolverDEC(B)+' '+lSignosR[lOp[1]]+' '+this.envolverDEC(C)+' '+lSignosR[lOp[2]]+' '+this.envolverDEC(D);
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                                case 1://N*N*(N*N)
                                    //busca set de valores que den decimal:
                                    while(true){
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = [A,lSignos[lOp[0]],B,lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                        R=VN.valor(array);
                                        var array2 = [C,lSignos[lOp[2]],D];
                                        valorPAR=VN.valor(array2);
                                        if((R!=0)&&(Math.abs(valorPAR)<Infinity)){break;}
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    lRespNUM.push(R);
                                    tira=JL.num2str(A)+' '+lSignosR[lOp[0]]+' '+this.envolverDEC(B)+' '+lSignosR[lOp[1]]+' ('+JL.num2str(C)+' '+lSignosR[lOp[2]]+' '+this.envolverDEC(D)+')';
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                                case 2://N*(N*N)*N
                                    //busca set de valores que den decimal:
                                    while(true){
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = [A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,')',lSignos[lOp[2]],D];
                                        R=VN.valor(array);
                                        var array2 = [B,lSignos[lOp[1]],C];
                                        valorPAR=VN.valor(array2);
                                        if((R!=0)&&(Math.abs(valorPAR)<Infinity)){break;}
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    lRespNUM.push(R);
                                    tira=this.envolverDEC(A)+' '+lSignosR[lOp[0]]+' ('+JL.num2str(B)+' '+lSignosR[lOp[1]]+' '+this.envolverDEC(C)+') '+lSignosR[lOp[2]]+' '+this.envolverDEC(D);
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                                case 3://(N*N)*N*N
                                    //busca set de valores que den decimal:
                                    while(true){
              
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                        R=VN.valor(array);
                                        var array2 = [A,lSignos[lOp[0]],B];
                                        valorPAR=VN.valor(array2);
                                        
                                        if((R!=0)&&(Math.abs(valorPAR)<Infinity)){break;}
                                        /*if( (R!=0) && (Math.abs(valorPAR) != null) ){
                                            break;
                                        }*/
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    lRespNUM.push(R);
                                    tira='('+JL.num2str(A)+' '+lSignosR[lOp[0]]+' '+this.envolverDEC(B)+') '+lSignosR[lOp[1]]+' '+this.envolverDEC(C)+' '+lSignosR[lOp[2]]+' '+this.envolverDEC(D);
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                                case 4://N*(N*N*N)
                                    //busca set de valores que den decimal:
                                    while(true){
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = [A,lSignos[lOp[0]],'(',B,lSignos[lOp[1]],C,lSignos[lOp[2]],D,')'];
                                        R=VN.valor(array);
                                        var array2 = [B,lSignos[lOp[1]],C,lSignos[lOp[2]],D];
                                        valorPAR=VN.valor(array2);
                                        if((R!=0)&&(Math.abs(valorPAR)<Infinity)){break;}
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    lRespNUM.push(R);
                                    tira=this.envolverDEC(A)+' '+lSignosR[lOp[0]]+' ('+JL.num2str(B)+' '+lSignosR[lOp[1]]+' '+this.envolverDEC(C)+' '+lSignosR[lOp[2]]+' '+this.envolverDEC(D)+')';
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                                case 5://(N*N)*(N*N)
                                    //busca set de valores que den entero:
                                    while(true){
                                        A=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        B=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        C=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        D=JL.str2num(JL.num2str(Random.float(-9,9),Random.integer(1,3)));
                                        var array = ['(',A,lSignos[lOp[0]],B,')',lSignos[lOp[1]],'(',C,lSignos[lOp[2]],D,')'];
                                        R=VN.valor(array);
                                        var array2 = [A,lSignos[lOp[0]],B];
                                        valorPAR=VN.valor(array2);
                                        var array3 = [C,lSignos[lOp[2]],D];
                                        valorPAR2=VN.valor(array3);
                                        if((R!=0)&&(Math.abs(valorPAR)<Infinity)&&(Math.abs(valorPAR2)<Infinity)){
                                            break;
                                        }
                                    }
                                    //compone la respuesta y la tira de pregunta:
                                    lRespNUM.push(R);
                                    tira='('+JL.num2str(A)+' '+lSignosR[lOp[0]]+' '+this.envolverDEC(B)+') '+lSignosR[lOp[1]]+' ('+JL.num2str(C)+' '+lSignosR[lOp[2]]+' '+this.envolverDEC(D)+')';
                                    lPregSTR.push(tira);
                                    lRespSTR.push(JL.num2str(JL.str2num(JL.num2str(R,2))));
                                    break;
                            }
                            break;
                    }
                    break;
           
           
           
           
            
        }
        
        Motor.lOperaciones[this.nOp]=new Object();
        Motor.lOperaciones[this.nOp].pregunta=lPregSTR;
        Motor.lOperaciones[this.nOp].respuesta=lRespNUM;
        Motor.lOperaciones[this.nOp].respuestaString=lRespSTR;
        Motor.lOperaciones[this.nOp].entrada="";
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;
        Motor.lOperaciones[this.nOp].enunciadoParseado=this.enun;

        //console.log(Motor.lOperaciones[this.nOp]);

        //console.log(Motor.lOperaciones[this.nOp]);

        /*Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
        Motor.lOperaciones[this.nOp].preguntaSprite.y=90;
        Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
        Motor.lOperaciones[this.nOp].entrada=0;
        Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;*/
        
        
        //console.log("El campo es : " + campoNum);
        
        
        
        
        
    
    
    
    }
    this.limpiarDEC = function(vv,dd){
        dd = dd || 8;
        return JL.num2str(JL.str2num(JL.num2str(vv,dd)));
    };
    this.esNatural = function(vv){
        if((vv>0)&&(Math.floor(vv)==vv)&&(Math.abs(vv)<Infinity)){
            return true;
        }else{
            return false;
        }
    };
    this.envolver = function(vv){
        var tira = '(';
        tira+=(vv>0)?'+':'−';
        tira+=JL.num2str(Math.abs(vv),0)+')';
        return tira;
    };
    this.envolverNEG = function(vv){
        if(vv<0){
            var tira = '(';
            tira+=(vv>0)?'+':'−';
            tira+=Math.abs(vv)+')';
            return tira;
        }else{
            return vv.toString().replace('-','−');
        }
    };
    this.envolverDEC = function(vv){
        var tira = vv.toString().replace('.',',');
        if(vv<0){
            tira='('+tira+')';
        }
        return tira.replace('-','−');;
    };
    this.esEntero = function(vv){
        if((vv!=0)&&(Math.floor(vv)==vv)&&(Math.abs(vv)<Infinity)){
            return true;
        }else{
            return false;
        }
    };

}