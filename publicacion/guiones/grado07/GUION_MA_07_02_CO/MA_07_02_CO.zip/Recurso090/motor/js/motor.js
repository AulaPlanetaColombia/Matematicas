Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();

	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 235 ;
	//final
	this.PREG_FINAL_X_PADDING = 585 ;
	
	this.RESP_HEIGHT = 82;
	this.RESP_WIDTH = 322; 
	this.RESP_INNER_HEIGHT = 78;
	this.RESP_INNER_WIDTH = 320; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.IMG = "data/imagenes/";
	
	//GUINARDO
	this.lEnunciados=new Array();
	this.qEnunciados = 0;
	this.listAux= new Array();
	this.qOperaciones;
	this.lOperaciones = new Array();
	this.co_pizarra;
	
	this.ponerContenedor = function(contenedorMotor) {

	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('qOperaciones').text();
				        
	        var seed = $(xml).find('seed');
	        Motor.datosXML.seed = seed.text();
			
			var nivel = $(xml).find('nivel');
			Motor.datosXML.nivel = nivel.text();
			
			var curso = $(xml).find('curso');
            Motor.datosXML.curso = curso.text();
			
			Motor.datosXML.enunciados = new Array();
			
			$(xml).find('enunciado').each(function(index){
				//debugger;
				this.preg = new enunciado();
				this.preg.id = index;
				this.preg.enunciado = $(this).text();
			  	Motor.datosXML.enunciados.push(this.preg);
			});
			
			$(xml).find('enunciado2').each(function(index){
                this.preg = new enunciado();
                this.preg.id = index;
                this.preg.enunciado = $(this).text();
                Motor.datosXML.enunciados2.push(this.preg);
            });
			
			$(xml).find('tipoNumeros').children().each(function(index){
                //debugger;
                this.tipoNum = new tipoNumeros();
                this.tipoNum.id = index;
                this.tipoNum.text = $(this).text();
                this.tipoNum.tag = this.tagName;
                Motor.datosXML.tipoNumeros.push(this.tipoNum);
            });
			
			//Motor.datosXML.variaciones = new Array();
			$(xml).find('variaciones').children().each(function(index){
				//debugger;
				this.varia = new variaciones();
				this.varia.id = index;
				this.varia.text = $(this).text();
				this.varia.tag = this.tagName;
				if(this.varia.text=="1")
			  		Motor.datosXML.variaciones.push(this.varia);
			  	
			});

	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
		});
	}
	this.inicializarEstructura = function(estado) {

		this.initGenerador();
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
		this.currentPag.K = $(this.inputDOM0.htmlElement).val();
		
	  	for(key1 in Motor.pagines){
	   		if ( Motor.pagines[key1].K == "") 
	   			return false;
		}
		
		return true;
		
	};
	
	this.getEstado = function(){
        var estado = new Array();
        
        var respuesta = "";
        
        for(key1 in Motor.pagines)
        {
            respuesta = respuesta + "AAA" + Motor.pagines[key1].K;
        }
        return respuesta;
    };
	
	this.revisar = function(){
        if(this.estado != "")
        {
            var lRespuestas=this.estado.split("AAA");
            lRespuestas.splice(0,1);
            for(var i = 0; i < this.qOperaciones; i ++){
                Motor.pagines[i].K = lRespuestas[i];
            }
            //para actualizar el valor de los campos de la primera pagina
            $(this["inputDOM0"].htmlElement).val(this.currentPag.K);
            
        }
    };
	
	this.validar = function() {
		
		this.currentPag.K = $(this.inputDOM0.htmlElement).val();
		
		var total = 0;
	  	for(key1 in Motor.pagines){
	  		var correcte = true;

	  		//if( parseFloat( Motor.pagines[key1].K.toString().replace(".","").replace(",",".") ) != parseFloat( Motor.pagines[key1].correctoK ) ){
	  		if( JL.str2num(Motor.pagines[key1].K) != JL.str2num(Motor.pagines[key1].correctoK) ){
	  			Motor.pagines[key1].cajaX0.error();
	  			//Motor.pagines[key1].valor_1_0.alpha=1;
	  			correcte = false;
	  		}else{
	  			Motor.pagines[key1].cajaX0.correct();
	  		}
	  		
	  		if( correcte ){
	  			total++;
	  		}else{
	  			Motor.pagines[key1].validacio = false;
	  		}
		}
		return total.toString() + "/" + Motor.pagines.length.toString();
		
	};
	this.hideDomObjects = function(){
        $(this["inputDOM0"].htmlElement).css("display" , 'none');
	}
	this.showDomObjects = function(){
        $(this["inputDOM0"].htmlElement).css("display" , 'inline');
	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
        $(this["inputDOM0"].htmlElement).prop("readonly" , false);
	}
	this.desactivar = function() {
        $(this["inputDOM0"].htmlElement).prop("readonly" , true);
	};
	this.numPaginas = function(){
		return Motor.datosXML.cantidad;
	};
	this.ponerPagina = function(pag) {
		
		this.currentPag.K = $(this.inputDOM0.htmlElement).val();

		this.contenedor.removeChild( this.currentPag.contenedor );
		this.currentNumPag = pag - 1;
	    this.currentPag = this.pagines[this.currentNumPag];
	    this.contenedor.addChild( this.currentPag.contenedor );
	    
	    var navegador = Main.navegador;
        var navegadorSplit = navegador.split(' ');
        var mobil = Main.mobil
        var index = navegadorSplit[0].indexOf("Safari");
        var version = navegadorSplit[1];
	    
	    if(index > -1 && mobil =="Android"){
            $(this["inputDOM0"].htmlElement).focus().blur();
        }
	    $(this.inputDOM0.htmlElement).val(this.currentPag.K);
	    

	};
	
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		
	};
	this.deseleccionar = function(){
		/*for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			Motor.pagines[key1].respostes[key2].desactivar();
	   			Motor.pagines[key1].respostes[key2].clear();
			}
		}*/
	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
	  	for(key1 in Motor.pagines){
            
	  		//if( parseFloat( Motor.pagines[key1].K.toString().replace(".","").replace(",",".") ) != parseFloat( Motor.pagines[key1].correctoK ) )
	  		if( JL.str2num(Motor.pagines[key1].K) != JL.str2num(Motor.pagines[key1].correctoK) )
	  			Motor.pagines[key1].valor0.alpha=1;
		}
	}
	this.obtenerTipoEjercicio = function(){

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		this.pagines = new Array();

        //console.log(Motor.datosXML.enunciados);

	    for(var i=0; i < Motor.datosXML.cantidad; i++)
    	{
    	    //console.log("campoNum : " + Motor.campoNum);
	    	//var index = i % Motor.datosXML.enunciados.lenght;
	    	var index = 0;
	    	//var index = Motor.campoNum;
			var enunciado = Motor.datosXML.enunciados[index];
			//console.log(enunciado);
			
	    	this.addPagina( enunciado, i , index);
	    }
	    this.contenedor.addChild( this.pagines[0].contenedor );
	    this.currentPag = this.pagines[0] ;
	    this.currentNumPag = 0;
	    
	    Main.stage.addChild( this.contenedor );
	    
	    this.deleteInputs();
	    this.initIntroTexto();
	    
    }
    
    this.addPagina = function( enunciado, numpagina , idPregunta)
    {
    	var pagina = new Pagina( enunciado, numpagina, Motor.lOperaciones[numpagina]);
    	pagina.contenedor.y = this.INITIAL_Y;
    	this.pagines.push( pagina );
    	
    }
    
    this.initGenerador = function()
    {
    	var seed = Motor.datosXML.seed;

		this.lEnunciados = new Array();
		this.qEnunciados = 0;
		this.listAux= new Array();
		this.lOperaciones = new Array();

		//for(var key in  Motor.datosXML.enunciados)
		//{
			var ss = Motor.datosXML.enunciados[0].enunciado.toString();
			ss = JL.reemplazar(ss, 'NNN', '\n');
			this.lEnunciados.push( ss );
		//}
		//console.log( this.lEnunciados);
		this.qEnunciados = this.lEnunciados.length;

		/////extrar qOperaciones
		this.qOperaciones = Motor.datosXML.cantidad;
		
		this.campo = "";
        this.campoNum = 0;
        var lCampos = ['N','E','D'];
        
        for(var i=1;i<4;i++){
            if(Motor.datosXML.tipoNumeros[i-1].text=="1"){
                 this.campo=lCampos[i-1];//puede ser 'N'---'E'---'D'
                 this.campoNum=i-1; 
            }
        }
		
		if(Motor.datosXML.curso==0){
            this.primaria=true;
        }else{
            this.primaria=false;
        }
		
		
		if(Scorm.modo == Scorm.MODO_EXPONER){
			Generador.generarSerie(JL.iRandom(1,100));
		}else{
			Generador.generarSerie(seed);
		}
		//console.log(Motor.lOperaciones);
    }
    
    this.initIntroTexto = function()
    {
    	for(var i = 0; i < 1; i++)
    	{
			var $input = $('<input type="text" id="input_'+i+'"  maxlength="20" onkeyup="Motor.filtrarText(event);" class="input"/>');
			
			$("#mediaHolder").append($input);

			this["inputDOM"+i] = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
			
			this["inputDOM"+i].element_x = 540;
			this["inputDOM"+i].element_y = 304;
			this["inputDOM"+i].element_width = 170;
			this["inputDOM"+i].element_height = 35;
			this["inputDOM"+i].fontsize = 20;
			
			this["inputDOM"+i].x = this["inputDOM"+i].element_x ;
			this["inputDOM"+i].y = this["inputDOM"+i].element_y ;
			$(this["inputDOM"+i].htmlElement).css("width", this["inputDOM"+i].element_width);
			$(this["inputDOM"+i].htmlElement).css("height", this["inputDOM"+i].element_height);
			
			this.contenedor.addChild(this["inputDOM"+i]);
			
			var navegador = Main.navegador;
	        var navegadorSplit = navegador.split(' ');
	        var mobil = Main.mobil
	        var index = navegadorSplit[0].indexOf("IE");
	        var version = navegadorSplit[1];

	        if(index > -1 && mobil =="Tablet"){
	            $input.focusout(function(event){ $("body").focus(); });
	            $(this["inputDOM"+i].htmlElement).click(Motor.select);
	        }
            //$(this["inputDOM"+i].htmlElement).focus();
		}
	
    };

    this.filtrarText = function(e){
    	var id = e.target.id;
    	if( $("#" + id).val().length ){
    		Contenedor.checkPagina();
    	}
    };
    
    this.select = function(){
        $(this).blur().focus();
    };
    
    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}

}
