

//TIPO 1
function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    this.idPregunta = _numpagina;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;//pregunta.enunciado;
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;
	this.validacio = true;
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    this.contenedorRespuesta = new createjs.Container();
    this.contenedorRespuesta.x = 478;
    this.contenedorRespuesta.y = 320;
        
    this.addText(0, 255, 227, operacio.pregunta[0], "#000", 1);
    this.addText(1, 325, 205, operacio.pregunta[1],"#000", 1);
    this.addText(2, 325, 255, operacio.pregunta[2], "#000", 1);
    this.addRaya(0, 275, 241, 110, "#0D3158");
    this.addText(3, 395, 226, " = ", "#0D3158" , 1);
    this.addRaya(1, 435, 241, 110, "#0D3158");
    
    this.addLine(0, 457, 190);
    this.addLine(1, 457, 250);
    
    this.addRespuesta(0, 0, 0, 45, operacio.respuesta, "#E1001A" , 0);
     
	this.valor = [operacio.respuesta[0], operacio.respuesta[1]];
	this.respuesta = ["", ""];
}

Pagina.prototype.addText = function( index, x, y, _text, color, alpha){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x;
    this["text"+index].y = y;
    this["text"+index].alpha = alpha;
    this["text"+index].textAlign = "center";
    this.contenedor.addChild( this["text"+index] );
}

Pagina.prototype.addRespuesta = function( index, x, y, ancho, _text, color, alpha){
    
    this.contenedorRespuesta.alpha = alpha;
    this.contenedor.addChild(this.contenedorRespuesta);
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text[0].toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x + 15;
    this["text"+index].y = y + 5;
    this["text"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text"+index] );
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x - 15, y + 35);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho, y + 35);
    this.contenedorRespuesta.addChild( this["line"+index] );
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = _text[1].toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text1"+index].color = color;
    this["text1"+index].x = x + 15;
    this["text1"+index].y = y + 37;
    this["text1"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text1"+index] );   
}

Pagina.prototype.addRaya = function( index, x, y, ancho, color){
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x, y);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho - 5, y);
    this.contenedor.addChild( this["line"+index] );
}

Pagina.prototype.addLine = function( index, x, y){

    this["cajaX"+index] = new CajaTexto();
	this["cajaX"+index] .contenedor.x = x;
	this["cajaX"+index] .contenedor.y = y;
	this["positionX"+index] = x;
	this["positionY"+index] = y;

	this.contenedor.addChild( this["cajaX"+index].contenedor  );
}

Pagina.prototype.getParam = function(){
    //[num, den]
    Motor.currentPag.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val()];
};

Pagina.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.respuesta[1]);
    
    
    Motor["inputDOM0"].element_x = this.positionX0 + 3;
    Motor["inputDOM0"].element_y = this.positionY0 + 124;
    
    Motor["inputDOM1"].element_x = this.positionX1 + 3;
    Motor["inputDOM1"].element_y = this.positionY1 + 124;
    
    $(Motor["inputDOM2"].htmlElement).css("display","none");
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    
};


Pagina.prototype.completado = function(){
    //this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina.prototype.isCompletado = function(){
    for( var i in this.respuesta ){
        if( this.respuesta[i] == ""){
            return false;
        }else{
            return true;
        }
    }
};

Pagina.prototype.isValidado = function(){
    
    var correcto = true;
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this["cajaX" + i].error();
            correcto = false;
        }else{
            this["cajaX" + i].correct();
        }
     }
     
    return correcto;
};
Pagina.prototype.verSolucion = function(){
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
           this.contenedorRespuesta.alpha = 1;
        }
     }
};


//TIPO 2
function Pagina2( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    this.idPregunta = _numpagina;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;//pregunta.enunciado;
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;
    this.validacio = true;
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    this.contenedorRespuesta = new createjs.Container();
    this.contenedorRespuesta.x = 450;
    this.contenedorRespuesta.y = 320;
    //this.addText(0, 250, 230, operacio.pregunta[0], "#000", 1);
    this.addText(1, 320, 205, operacio.pregunta[0],"#000", 1);
    this.addText(2, 320, 255, operacio.pregunta[1], "#000", 1);
    this.addRaya(0, 275, 241, 110, "#0D3158");
    this.addText(3, 395, 226, " = ", "#0D3158" , 1);
    this.addRaya(1, 505, 241, 110, "#0D3158");
    
    this.addLine(0, 430, 220);
    this.addLine(1, 520, 190);
    this.addLine(2, 520, 250);
    
    
    this.addRespuesta(0, 0, 0, 65, operacio.respuesta, "#E1001A" , 0);
     
    this.valor = [operacio.respuesta[0], operacio.respuesta[1], operacio.respuesta[2]];
    this.respuesta = ["", "", ""];
}

Pagina2.prototype.addText = function( index, x, y, _text, color, alpha){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x;
    this["text"+index].y = y;
    this["text"+index].alpha = alpha;
    this.contenedor.addChild( this["text"+index] );
}

Pagina2.prototype.addRespuesta = function( index, x, y, ancho, _text, color, alpha){
    
    this.contenedorRespuesta.alpha = alpha;
    this.contenedor.addChild(this.contenedorRespuesta);
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text[0].toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x + 15;
    this["text"+index].y = y + 20;
    this["text"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text"+index] );
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x + 68, y + 35);
    this["line"+index].graphics.beginStroke(color).lineTo(x + 68 + ancho, y + 35);
    this.contenedorRespuesta.addChild( this["line"+index] );
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = _text[1].toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text1"+index].color = color;
    this["text1"+index].x = x + 100;
    this["text1"+index].y = y + 5;
    this["text1"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text1"+index] );
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = _text[2].toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text1"+index].color = color;
    this["text1"+index].x = x + 100;
    this["text1"+index].y = y + 37;
    this["text1"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text1"+index] );   
}

Pagina2.prototype.addRaya = function( index, x, y, ancho, color){
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x, y);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho, y);
    this.contenedor.addChild( this["line"+index] );
}

Pagina2.prototype.addLine = function( index, x, y){

    this["cajaX"+index] = new CajaTexto();
    this["cajaX"+index] .contenedor.x = x;
    this["cajaX"+index] .contenedor.y = y;
    this["positionX"+index] = x;
    this["positionY"+index] = y;

    this.contenedor.addChild( this["cajaX"+index].contenedor  );
}

Pagina2.prototype.getParam = function(){
    //[entero, num, den]
    Motor.currentPag.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val(), $(Motor.inputDOM2.htmlElement).val()];
};

Pagina2.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.respuesta[1]);
    $(Motor.inputDOM2.htmlElement).val(Motor.currentPag.respuesta[2]);
    
    
    Motor["inputDOM0"].element_x = this.positionX0 + 3;
    Motor["inputDOM0"].element_y = this.positionY0 + 124;
    
    Motor["inputDOM1"].element_x = this.positionX1 + 3;
    Motor["inputDOM1"].element_y = this.positionY1 + 124;
    
    Motor["inputDOM2"].element_x = this.positionX2 + 3;
    Motor["inputDOM2"].element_y = this.positionY2 + 124;
    
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    $(Motor["inputDOM2"].htmlElement).css("display","inline");
    
};

Pagina2.prototype.completado = function(){
    //this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina2.prototype.isCompletado = function(){
    for( var i in this.respuesta ){
        if( this.respuesta[i] == ""){
            return false;
        }else{
            return true;
        }
     }
};

Pagina2.prototype.isValidado = function(){
    
    var correcto = true;
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this["cajaX" + i].error();
            correcto = false;
        }else{
            this["cajaX" + i].correct();
        }
     }
     
     return correcto;
};
Pagina2.prototype.verSolucion = function(){
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
           this.contenedorRespuesta.alpha = 1;
        }
     }
};


//TIPO 3
function Pagina3( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    this.idPregunta = _numpagina;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;//pregunta.enunciado;
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;
    this.validacio = true;
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    this.contenedorRespuesta = new createjs.Container();
    this.contenedorRespuesta.x = 448;
    this.contenedorRespuesta.y = 320;
        
    //this.addText(0, 255, 227, operacio.pregunta[0], "#000", 1);
    this.addText(1, 295, 205, operacio.pregunta[0],"#000", 1);
    this.addText(2, 295, 255, operacio.pregunta[1], "#000", 1);
    this.addRaya(0, 245, 241, 110, "#0D3158");
    this.addText(3, 375, 226, " = ", "#0D3158" , 1);
    this.addRaya(1, 405, 241, 110, "#0D3158");
    
    this.addLine(0, 425, 190);
    this.addLine(1, 425, 250);
    
    this.addRespuesta(0, 0, 0, 45, operacio.respuesta, "#E1001A" , 0);
     
    this.valor = [operacio.respuesta[0], operacio.respuesta[1]];
    this.respuesta = ["", ""];
}

Pagina3.prototype.addText = function( index, x, y, _text, color, alpha){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x;
    this["text"+index].y = y;
    this["text"+index].alpha = alpha;
    this["text"+index].textAlign = "center";
    this.contenedor.addChild( this["text"+index] );
}

Pagina3.prototype.addRespuesta = function( index, x, y, ancho, _text, color, alpha){
    
    this.contenedorRespuesta.alpha = alpha;
    this.contenedor.addChild(this.contenedorRespuesta);
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text[0].toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x + 15;
    this["text"+index].y = y + 5;
    this["text"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text"+index] );
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x - 15, y + 35);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho, y + 35);
    this.contenedorRespuesta.addChild( this["line"+index] );
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = _text[1].toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text1"+index].color = color;
    this["text1"+index].x = x + 15;
    this["text1"+index].y = y + 37;
    this["text1"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text1"+index] );   
}

Pagina3.prototype.addRaya = function( index, x, y, ancho, color){
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x, y);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho - 5, y);
    this.contenedor.addChild( this["line"+index] );
}

Pagina3.prototype.addLine = function( index, x, y){

    this["cajaX"+index] = new CajaTexto();
    this["cajaX"+index] .contenedor.x = x;
    this["cajaX"+index] .contenedor.y = y;
    this["positionX"+index] = x;
    this["positionY"+index] = y;

    this.contenedor.addChild( this["cajaX"+index].contenedor  );
}

Pagina3.prototype.getParam = function(){
    //[num, den]
    Motor.currentPag.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val()];
};

Pagina3.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.respuesta[1]);
    
    
    Motor["inputDOM0"].element_x = this.positionX0 + 3;
    Motor["inputDOM0"].element_y = this.positionY0 + 124;
    
    Motor["inputDOM1"].element_x = this.positionX1 + 3;
    Motor["inputDOM1"].element_y = this.positionY1 + 124;
    
    $(Motor["inputDOM2"].htmlElement).css("display","none");
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    
};


Pagina3.prototype.completado = function(){
    //this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina3.prototype.isCompletado = function(){
    for( var i in this.respuesta ){
        if( this.respuesta[i] == ""){
            return false;
        }else{
            return true;
        }
    }
};

Pagina3.prototype.isValidado = function(){
    
    var correcto = true;
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
            this["cajaX" + i].error();
            correcto = false;
        }else{
            this["cajaX" + i].correct();
        }
     }
     
    return correcto;
};

Pagina3.prototype.verSolucion = function(){
    for( var i in this.respuesta ){
        if( JL.str2num(this.respuesta[i]) != this.valor[i]){
           this.contenedorRespuesta.alpha = 1;
        }
     }
};



//TIPO 4
function Pagina4( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    this.idPregunta = _numpagina;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = operacio.enunciado;//pregunta.enunciado;
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;
    this.validacio = true;
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    this.contenedorRespuesta = new createjs.Container();
    this.contenedorRespuesta.x = 448;
    this.contenedorRespuesta.y = 320;
        
    //this.addText(0, 255, 227, operacio.pregunta[0], "#000", 1);
    this.addText(1, 295, 205, operacio.pregunta[0],"#000", 1);
    this.addText(2, 295, 255, operacio.pregunta[1], "#000", 1);
    this.addRaya(0, 245, 241, 110, "#0D3158");
    this.addText(3, 375, 226, " = ", "#0D3158" , 1);
    this.addRaya(1, 405, 241, 110, "#0D3158");
    
    this.addLine(0, 425, 190);
    this.addLine(1, 425, 250);
    
    this.addRespuesta(0, 0, 0, 45, operacio.pregunta, "#E1001A" , 0);
     
    this.valor = [operacio.respuesta[0]];
    this.respuesta = ["", ""];
}

Pagina4.prototype.addText = function( index, x, y, _text, color, alpha){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text.toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x;
    this["text"+index].y = y;
    this["text"+index].alpha = alpha;
    this["text"+index].textAlign = "center";
    this.contenedor.addChild( this["text"+index] );
}

Pagina4.prototype.addRespuesta = function( index, x, y, ancho, _text, color, alpha){
    
    this.contenedorRespuesta.alpha = alpha;
    this.contenedor.addChild(this.contenedorRespuesta);
    
    var num = Math.floor(Math.random()*6)+2;
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = (_text[0]*num).toString();
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text"+index].color = color;
    this["text"+index].x = x + 15;
    this["text"+index].y = y + 5;
    this["text"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text"+index] );
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x - 15, y + 35);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho, y + 35);
    this.contenedorRespuesta.addChild( this["line"+index] );
    
    this["text1"+index] = new createjs.RichText();
    this["text1"+index].text = (_text[1]*num).toString();
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "24px Verdana" : "2px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 24 : 22 ;
    this["text1"+index].color = color;
    this["text1"+index].x = x + 15;
    this["text1"+index].y = y + 37;
    this["text1"+index].textAlign = "center";
    this.contenedorRespuesta.addChild( this["text1"+index] );   
}

Pagina4.prototype.addRaya = function( index, x, y, ancho, color){
    
    this["line"+index] = new createjs.Shape();
    this["line"+index].graphics.moveTo(x, y);
    this["line"+index].graphics.beginStroke(color).lineTo(x + ancho - 5, y);
    this.contenedor.addChild( this["line"+index] );
}

Pagina4.prototype.addLine = function( index, x, y){

    this["cajaX"+index] = new CajaTexto();
    this["cajaX"+index] .contenedor.x = x;
    this["cajaX"+index] .contenedor.y = y;
    this["positionX"+index] = x;
    this["positionY"+index] = y;

    this.contenedor.addChild( this["cajaX"+index].contenedor  );
}

Pagina4.prototype.getParam = function(){
    //[num, den]
    Motor.currentPag.respuesta = [$(Motor.inputDOM0.htmlElement).val(), $(Motor.inputDOM1.htmlElement).val()];
};

Pagina4.prototype.setParam = function(){
    
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.respuesta[0]);
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.respuesta[1]);
    
    
    Motor["inputDOM0"].element_x = this.positionX0 + 3;
    Motor["inputDOM0"].element_y = this.positionY0 + 124;
    
    Motor["inputDOM1"].element_x = this.positionX1 + 3;
    Motor["inputDOM1"].element_y = this.positionY1 + 124;
    
    $(Motor["inputDOM2"].htmlElement).css("display","none");
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    
};


Pagina4.prototype.completado = function(){
    //this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina4.prototype.isCompletado = function(){
    for( var i in this.respuesta ){
        if( this.respuesta[i] == ""){
            return false;
        }else{
            return true;
        }
    }
};

Pagina4.prototype.isValidado = function(){
    
    var correcto = true;
    var numero = JL.str2num(this.respuesta[0])/JL.str2num(this.respuesta[1]);
    if( numero != this.valor[0] ){
        correcto = false;
        this["cajaX0"].error();
        this["cajaX1"].error();
    }else{
        this["cajaX0"].correct();
        this["cajaX1"].correct();
    }
     
    return correcto;
};

Pagina4.prototype.verSolucion = function(){
    var numero = JL.str2num(this.respuesta[0])/JL.str2num(this.respuesta[1]);
    if( numero != this.valor[0] ){
       this.contenedorRespuesta.alpha = 1;
    }
};





//funciones comunes
function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 65, 40, 5);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 5);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 65, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 65, 40, 10);
}
