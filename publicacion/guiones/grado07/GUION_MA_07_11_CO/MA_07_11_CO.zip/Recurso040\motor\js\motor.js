Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();

	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	//this.PREG_INICI_X_PADDING = 235 ;
	this.PREG_INICI_X_PADDING = 130 ;
	//final
	this.PREG_FINAL_X_PADDING = 450 ;
	
	this.RESP_HEIGHT = 22;
	this.RESP_WIDTH = 240; 
	this.RESP_INNER_HEIGHT = 20;
	this.RESP_INNER_WIDTH = 238; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.IMG = "data/imagenes/";
	
	//GUINARDO
	this.lEnunciados=new Array();
	this.qEnunciados = 0;
	this.listAux= new Array();
	this.qOperaciones;
	this.lOperaciones = new Array();
	this.co_pizarra;
	this.enunciadoJ = "";
	this.inicis = new Array();
	this.dup_array = new Array();
	
    this.mutex = false; //para no coger 2 elementos a la
    this.currentElement = null;

	this.ponerContenedor = function(contenedorMotor) {

	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('qElementos').text();
				        
	        var seed = $(xml).find('seed');
	        Motor.datosXML.seed = seed.text();
			
			var nivel = $(xml).find('nivel');
			Motor.datosXML.nivel = nivel.text();
			
			var curso = $(xml).find('curso');
            Motor.datosXML.nivel = curso.text();
            
            var orden = $(xml).find('orden');
            Motor.datosXML.orden = orden.text();
			
			Motor.datosXML.enunciados = new Array();
			
			$(xml).find('enunciado').each(function(index){
				//debugger;
				this.preg = new enunciado();
				this.preg.id = index;
				this.preg.enunciado = $(this).text();
			  	Motor.datosXML.enunciados.push(this.preg);
			});
			
			$(xml).find('unidades').each(function(index){
                this.unidad = new unidades();
                this.unidad.id = index;
                this.unidad.text = $(this).text();
                Motor.datosXML.unidades.push(this.unidad);
            });
				
			//Motor.datosXML.variaciones = new Array();
			$(xml).find('variaciones').children().each(function(index){
				//debugger;
				this.varia = new variaciones();
				this.varia.id = index;
				this.varia.text = $(this).text();
				this.varia.tag = this.tagName;
			  	Motor.datosXML.variaciones.push(this.varia);
			});

	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
		});
	}
	this.inicializarEstructura = function(estado) {

		this.initGenerador();
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
	    
	    for (key in Motor.inicis) {
            if( Motor.inicis[key].resposta == null)
            {
                return false;
            }else{
                return true;
            }
        }		
	};
	
	this.getEstado = function(){
	    
	    var estado = "";
	    
	    for(var i=0; i < Motor.inicis.length ; i++){
	        estado+="AAA";
            estado+=Motor.inicis[i].contenedor.x;
            estado+="AAA";
            estado+=Motor.inicis[i].contenedor.y;
	    }
	    
	     estado+="AAA";
         for(var i=0; i < Motor.inicis.length ; i++){
            estado+="BBB";
            if( Motor.inicis[i].resposta != null ){
                estado+=Motor.inicis[i].resposta.idResposta;
            }
        }
        
        estado+="BBB";
        estado+="DDD";
        for(var i=0; i < Motor.inicis.length ; i++){
            estado+="CCC";
            if( Motor.inicis[i].resposta != null ){
                estado+="true";
            }else{
                estado+="false";
            }
        }
	    
	    return estado;
	}
	
	this.revisar = function(){
		if(this.estado != "")
		{
		    var respuesta = this.estado;
			var lRespuestas=respuesta.split("AAA");
            lRespuestas.splice(0,1);//posiciones x
            var ind=lRespuestas.indexOf("BBB");
            lRespuestas=lRespuestas.slice(0,ind);
            var lRespuestas2=respuesta.split("BBB");
            lRespuestas2.splice(0,1);//orden de respuestas
            var ind2=lRespuestas2.indexOf("CCC");
            lRespuestas2=lRespuestas2.slice(0,ind2);
            var lRespuestas3=respuesta.split("CCC");
            lRespuestas3.splice(0,1);
                        
            for( var i=0;i<this.qOperaciones;i++){
                for (key2 in Motor.finals) {
                    if( lRespuestas2[i] != "" && Motor.finals[key2].resposta.idResposta == lRespuestas2[i] )
                    { 
                        Motor.inicis[ i ].setReposta( Motor.finals[key2].resposta);
                        Motor.contenedor.setChildIndex ( Motor.finals[key2].resposta.contenedor,  Motor.contenedor.getNumChildren () - 1 );
                        Motor.finals[key2].resposta.contenedor.x = Motor.inicis[i].contenedor.x + 1;
                        Motor.finals[key2].resposta.contenedor.y = Motor.inicis[i].contenedor.y + 1;
                        break;
                    }
                }
                
            }
            
		}
	}
	
	this.validar = function() {
		
		var total = 0;
		
		for ( key1 in Motor.inicis){
		    if( Motor.inicis[key1].resposta == null)
            {
                //return false;
            }
            else
            {
                //if(Motor.inicis[key1].resposta.idRespuestaCorrecta == Motor.inicis[key1].idPregunta)
                if(Motor.inicis[key1].resposta.idRespuestaCorrecta == key1)
                {
                    total++;
                    Motor.inicis[key1].resposta.correcte();
                
                }
                else
                {
                    Motor.inicis[key1].resposta.erronia();  
                } 
            }
		}
        for (key2 in Motor.finals){
            var trobat= false;
            for ( key1 in Motor.inicis){
                if( Motor.inicis[key1].resposta == Motor.finals[key2].resposta ){
                   trobat = true;
                }
            }
            if(!trobat){
                Motor.finals[key2].resposta.erronia();
            }
        }
        
        //console.log(Motor.inicis);
        //console.log(Motor.finals);
        
        return total.toString() +  "/" + Motor.inicis.length.toString();
		
	};
	this.hideDomObjects = function(){

	}
	this.showDomObjects = function(){

	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
        for (key in Motor.respostes) {
             // activem listeners de comportament de les respostes
            Motor.respostes[key].contenedor.on("mousedown", Motor.preDragAndDrop, null, false, {resposta: Motor.respostes[key]});
            Motor.respostes[key].contenedor.on("pressmove", Motor.dragAndDrop, null, false, {resposta: Motor.respostes[key]});
            Motor.respostes[key].contenedor.on("pressup", Motor.dropResposta, null, false, {resposta: Motor.respostes[key]});
        }
    }
    this.desactivar = function() {
        for (key in Motor.respostes) {
              // desactivem listeners de comportament de les respostes
             Motor.respostes[key].contenedor.removeAllEventListeners ("mousedown");
             Motor.respostes[key].contenedor.removeAllEventListeners ("pressmove");
             Motor.respostes[key].contenedor.removeAllEventListeners ("pressup");
        }
    }; 
	this.numPaginas = function(){
		return Motor.pagines.lenght;
	};
	this.ponerPagina = function(pag) {
		
		this.currentPag.K = $(this.inputDOM0.htmlElement).val();

		this.contenedor.removeChild( this.currentPag.contenedor );
		this.currentNumPag = pag - 1;
	    this.currentPag = this.pagines[this.currentNumPag];
	    this.contenedor.addChild( this.currentPag.contenedor );
	    
	    $(this.inputDOM0.htmlElement).val(this.currentPag.K);
	    

	};
	
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		
	};
	this.deseleccionar = function(){

	};
	
	this.solucionar = function(){
		var total = 0;
        this.solucion = false;
                
        var encontrado = false;
        for(key1 in Motor.inicis){
            encontrado = false;
           // for(key2 in Motor.finals){
                if( Motor.inicis[key1].resposta != null && ( Motor.inicis[key1].idPregunta ==  Motor.inicis[key1].resposta.idRespuestaCorrecta ) ){
                    encontrado = true;
                    //para saber si sigue en la posicion inicial o se ha movido a motors inicis| si se ha movido no se elimina
                    if(Motor.finals[Motor.inicis[key1].idPregunta].resposta.contenedor.x == (Motor.finals[Motor.inicis[key1].idPregunta].contenedor.x+1)
                        && Motor.finals[Motor.inicis[key1].idPregunta].resposta.contenedor.y == (Motor.finals[Motor.inicis[key1].idPregunta].contenedor.y+1))
                         this.contenedor.removeChild(Motor.finals[Motor.inicis[key1].idPregunta].resposta.contenedor);

                }
           // }

            if(!encontrado){
                for( var key3 in Motor.finals){

                    if( Motor.finals[key3].resposta.idRespuestaCorrecta == Motor.inicis[key1].idPregunta ){
                        var dataResp = Motor.finals[key3];
                        var resp = new Resposta( dataResp.resposta.texte, this.RESP_INNER_WIDTH, this.RESP_INNER_HEIGHT, 5) ;
                        resp.contenedor.x = this.PREG_X_PADDING + this.PREG_FINAL_X_PADDING + 1;
                        resp.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT * key1 + 15 * key1 + 20 ;
                        resp.erronia();
                        resp.idRespuestaCorrecta = dataResp.respuesta;                    
                        this.contenedor.addChild( resp.contenedor );
                    }
                }
            }
        }  
	}
	this.obtenerTipoEjercicio = function(){

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
        
        //console.log(Motor.lOperaciones);
        
		this.contenedor = new createjs.Container();
        //this.drawPreguntes();
        this.enunciarMotor();
        this.drawInicis();
        //this.drawLine();
        this.drawFinals();
        
        Main.stage.addChild( this.contenedor);
	    
    }
    this.enunciarMotor = function(){
        this.enunciat = new createjs.RichText();
        //this.enunciat.text = operacio.enunciadoParseado ;//pregunta.enunciado;
        this.enunciat.text = this.enunciadoJ;
        this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
        this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
        this.enunciat.color = "#0D3158";
        this.enunciat.x = 15;
        this.enunciat.y = 65 ;
        this.enunciat.lineWidth = 900;
        this.enunciat.lineHeight = 22;
        this.enunciat.mouseEnabled = false;  
        this.contenedor.addChild(this.enunciat);
    };
    
        this.drawFons = function()
    {
        this.fons = new createjs.Shape();
        this.fons.graphics.beginFill("#fde8c2").drawRect(0, 0, 950, 440);
        this.fons.x = 0;
        this.fons.y = this.INITIAL_Y;
        
        this.contenedor.addChild( this.fons);
    }
    this.drawPreguntes = function()
    {   
        this.preguntes = new Array();
        var questions = Motor.lOperaciones;
        for(i=0; i < Motor.qOperaciones; i++)
        {
            var quest = questions[i];
            //questions.splice(0,1);
            
            //creem pregunta
            //console.log(quest);
            var pregunta = new Pregunta(quest.pregunta, this.RESP_WIDTH, this.RESP_HEIGHT);
            pregunta.contenedor.x = this.PREG_X_PADDING ;
            pregunta.contenedor.y =  this.INITIAL_Y + this.PREG_Y_PADDING * i + this.PREG_Y_PADDING/1.5 ;
            pregunta.idPregunta = i;
            //pregunta.idRespuestaCorrecta = quest.respuesta;
            
            this.contenedor.addChild( pregunta.contenedor );

            //guardem marc inicial en un array per despres treballar em ells
            Motor.preguntes.push(pregunta);
        
        }
        
    }
    this.ponerFlecha =function(x ,y){
        var texto = new createjs.RichText();
        texto.font = "20px Arial";
        texto.fontSize= 20;
        texto.x = x;
        texto.y = y;
        if( Motor.creciente ){
            texto.text = "{{lt}}";
        }else{
            texto.text = "{{lg}}"; 
        }
        texto.color ="#000";
        texto.textAlign ="center";
        this.contenedor.addChild( texto );
    };
    this.drawInicis = function()
    {
        Motor.inicis = new Array();
        // dibuixem marcs de cabuda de resposta
        for(i=0; i < Motor.lOperaciones.length; i++)
        {
            var inici = new BaseResposta(i,this.RESP_WIDTH, this.RESP_HEIGHT , 5);
            inici.contenedor.x = this.PREG_X_PADDING + this.PREG_INICI_X_PADDING ;
            //inici.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT  * i + 20 * i + 30;
            inici.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT  * i + 15 * i + 20;
            inici.idPregunta = i;
            inici.idRespuestaCorrecta = Motor.lOperaciones[i].respuesta;
            
            this.contenedor.addChild( inici.contenedor );
            if( i < Motor.lOperaciones.length - 1){
                Motor.ponerFlecha(inici.contenedor.x + 120, inici.contenedor.y + 20);
            }
            
            //guardem marc inicial en un array per despres treballar em ells
            Motor.inicis.push(inici);
        }
    }
    this.drawLine = function()
    {
        //dibuixem linia descontinua de separació
        this.separator =  new createjs.Shape();
        this.separator.graphics.beginStroke("#0D3158").setStrokeStyle(2);
        this.separator = Utils.dashedLineTo(this.separator, 
                                            this.PREG_X_PADDING + this.LINE_X, 
                                            this.INITIAL_Y + this.LINE_Y_MIN, 
                                            this.PREG_X_PADDING + this.LINE_X, this.LINE_Y_MAX, this.LINE_SIZE );
        this.contenedor.addChild(this.separator);
    }
    this.drawFinals = function()
    {
        Motor.respostes = new Array();
        Motor.finals = new Array();
        Motor.dup_array = new Array();
       
        for(var i = 0; i < Motor.lOperaciones.lenght; i++){
            Motor.dup_array[i] = Motor.lOperaciones[i];
        }
           
        var responses = Motor.lOperaciones;
        //console.log(responses);
        for(i=0; i < Motor.qOperaciones; i++)
        {
            // creem random o no.
            var index = 0;
            //var index = Math.floor( Math.random()*responses.length);
            var dataResp = responses[index];
                        
            // creem marc resposta
            var finali = new BaseResposta(i,this.RESP_WIDTH, this.RESP_HEIGHT , 5);
            finali.contenedor.x = this.PREG_X_PADDING + this.PREG_FINAL_X_PADDING ;
            //finali.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT * i + 20 * i + 30  ;
            finali.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT * i + 15 * i + 20  ;
            finali.idPregunta = index;
            //debugger;
            // creem caixa resposta
            //console.log(dataResp.pregunta);
            var resp = new Resposta( dataResp.pregunta, this.RESP_INNER_WIDTH, this.RESP_INNER_HEIGHT, 5) ;
            resp.contenedor.x = this.PREG_X_PADDING + this.PREG_FINAL_X_PADDING + 1;
            //resp.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT * i + 20 * i + 31 ;
            resp.contenedor.y = this.INITIAL_Y + this.RESP_HEIGHT * i + 15 * i + 21 ;
            resp.idResposta = i;
            //resp.index = i;
            
            resp.idRespuestaCorrecta = dataResp.respuesta;

            

            responses.splice(index,1);

            //guardem resposta dins marc
            finali.setReposta(resp);
            Motor.respostes.push(resp);

            //guardem marc i resposta en un array per despres treballar em ells
            Motor.finals.push(finali);
            
            this.contenedor.addChild( finali.contenedor );
            this.contenedor.addChild( resp.contenedor );
            
            // activem listeners de comportament de les respostes
            resp.contenedor.on("mousedown", this.preDragAndDrop, null, false, {resposta:resp});
            resp.contenedor.on("pressmove", this.dragAndDrop, null, false, {resposta:resp});
            resp.contenedor.on("pressup", this.dropResposta, null, false, {resposta:resp});
            resp.contenedor.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
            resp.contenedor.on("mouseout", function(evt){ document.body.style.cursor='default'; });
        }
    }
    
    
    this.addPagina = function( enunciado, numpagina , idPregunta)
    {
    	var pagina = new Pagina( enunciado, numpagina, Motor.lOperaciones[numpagina]);
    	pagina.contenedor.y = this.INITIAL_Y;
    	this.pagines.push( pagina );
    	
    }
    
    this.initGenerador = function()
    {
    	var seed = Motor.datosXML.seed;

		this.lEnunciados = new Array();
		this.lUnidades = new Array();
		this.qEnunciados = 0;
		this.listAux= new Array();
		this.lOperaciones = new Array();
		this.potencia = -1;
		this.magnitud = -1;
		this.creciente = -1;
		this.orden = -1;

		for(var key in  Motor.datosXML.enunciados)
		{
			var ss = Motor.datosXML.enunciados[key].enunciado.toString();
			//ss = JL.reemplazar(ss, 'NNN', '\n');
			this.lEnunciados.push( ss );
		}
		
		for (var unidad in Motor.datosXML.unidades){
		    var ss = Motor.datosXML.unidades[unidad].text.toString();
            this.lUnidades.push( ss );
            
        }
		
		//console.log( this.lEnunciados);
		this.qEnunciados = this.lEnunciados.length;

		/////extrar qOperaciones
		this.qOperaciones = Motor.datosXML.cantidad;
		
		//leer variables xml//
        if(Motor.datosXML.variaciones.tag == "v1" && Motor.datosXML.variaciones.text == "1"){
            this.magnitud=0;
            this.potencia=null;
        }
        
        if(Motor.datosXML.orden == 0){
            this.creciente=true;
            this.orden=0;
        }else{
            this.creciente=false;
            this.orden=1;
        }
        
        for ( var key in Motor.datosXML.variaciones){
            
            if(Motor.datosXML.variaciones[key].tag == "v1" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=0;
                this.potencia=null;
            }
            
            if(Motor.datosXML.variaciones[key].tag == "v2" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=1;
                this.potencia=null;
            }
            if(Motor.datosXML.variaciones[key].tag == "v3" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=2;
                this.potencia=2;
            }
            if(Motor.datosXML.variaciones[key].tag == "v4" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=3;
                this.potencia=3;
            }
            if(Motor.datosXML.variaciones[key].tag == "v5" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=4;
                this.potencia=null;
            }
            if(Motor.datosXML.variaciones[key].tag == "v6" && Motor.datosXML.variaciones[key].text == "1"){
                this.magnitud=5;
                this.potencia=null;
            }
        }
        
		if(Scorm.modo == Scorm.MODO_EXPONER){
			Generador.generarSerie(JL.iRandom(1,100));
		}else{
			Generador.generarSerie(seed);
		}
		//console.log(Motor.lOperaciones);
    }
    
    this.initIntroTexto = function()
    {
    	for(var i = 0; i < 1; i++)
    	{
			var $input = $('<input type="text" id="input_'+i+'"  maxlength="20" class="input"/>');
			
			$input.focusout(function(event){ $("body").focus(); });
			
			$("#mediaHolder").append($input);

			this["inputDOM"+i] = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
			
			this["inputDOM"+i].element_x = 440;
			this["inputDOM"+i].element_y = 304;
			this["inputDOM"+i].element_width = 170;
			this["inputDOM"+i].element_height = 35;
			this["inputDOM"+i].fontsize = 20;
			
			this["inputDOM"+i].x = this["inputDOM"+i].element_x ;
			this["inputDOM"+i].y = this["inputDOM"+i].element_y ;
			$(this["inputDOM"+i].htmlElement).css("width", this["inputDOM"+i].element_width);
			$(this["inputDOM"+i].htmlElement).css("height", this["inputDOM"+i].element_height);
			
			this.contenedor.addChild(this["inputDOM"+i]);
			
			$(this["inputDOM"+i].htmlElement).click(Motor.select);
            $(this["inputDOM"+i].htmlElement).focus();
		}
	
    };
    
    this.select = function(){
        $(this).focus();
    };
    
    this.preDragAndDrop = function(evt, data)
    {
        if(!Motor.mutex && Motor.currentElement == null){
            Motor.currentElement = data.resposta;
            // capturem punt de click dins la resposta
            Motor.itemX = evt.stageX/Main.scale - evt.target.parent.x ;
            Motor.itemY = evt.stageY/Main.scale - evt.target.parent.y ;
            // coloquem reposta al davant
            Motor.contenedor.setChildIndex ( evt.target.parent,  Motor.contenedor.getNumChildren () - 1 );
            //activem color seleccio i sombra de la resposta
            data.resposta.lightResponse();
            
            for (key in Motor.inicis) {
                if( Motor.inicis[key].resposta != null && 
                    Motor.inicis[key].resposta.contenedor.id == evt.target.parent.id)
                {
                    //netegem la resposta quan la treiem del final
                    Motor.inicis[key].resposta = null;
                }
            }
        }
    }
    
    this.dragAndDrop = function(evt, data)
    {
        if(!Motor.mutex && Motor.currentElement == data.resposta){
            evt.target.parent.x = evt.stageX/Main.scale - Motor.itemX;
            evt.target.parent.y = evt.stageY/Main.scale - Motor.itemY;
        }
    }
    
    this.dropResposta = function(evt, data)
    {
        if(!Motor.mutex && Motor.currentElement == data.resposta){
            Motor.mutex = true;
            //desactivem color seleccio i sombra de la resposta
            data.resposta.unlightResponse();
            
            var trobat = false;
            for (key in Motor.inicis) {
                var pt = Motor.inicis[key].contenedor.globalToLocal( (evt.target.parent.x + 120) * Main.scale, (evt.target.parent.y + 10) * Main.scale );
               
                // si colisiona amb una casella final
                if ( evt.target.parent.children[0].hitTest( pt.x , pt.y )) {
                    if(Motor.inicis[key].resposta == null) {
                        //coloquem la resposta a la casella corresponent
                        createjs.Tween.get(evt.target.parent).to({x:Motor.inicis[key].contenedor.x+1}, 750, createjs.Ease.circOut).call( function(){  Motor.mutex = false;});
                        createjs.Tween.get(evt.target.parent).to({y:Motor.inicis[key].contenedor.y+1}, 750, createjs.Ease.circOut);
                        data.resposta.situado = true;
                        Motor.inicis[key].setReposta( data.resposta );
                        trobat = true;
                    }
                }
            }
            if(!trobat)  // no ha colisionat amb cap casella final
            {
                for (key in Motor.finals) {
                    if(Motor.finals[key].resposta.contenedor.id == data.resposta.contenedor.id)
                    {
                        //tornem la resposta a la casella inicial
                        createjs.Tween.get(evt.target.parent).to({x:Motor.finals[key].contenedor.x+1}, 750, createjs.Ease.circOut).call( function(){  Motor.mutex = false;});
                        createjs.Tween.get(evt.target.parent).to({y:Motor.finals[key].contenedor.y+1}, 750, createjs.Ease.circOut);

                    }
                }
            }
            Motor.currentElement = null;
        }

    }
    
    
    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}

}
