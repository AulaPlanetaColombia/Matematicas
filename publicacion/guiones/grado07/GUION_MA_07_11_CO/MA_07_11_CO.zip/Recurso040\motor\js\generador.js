Generador = new function()
{
    this.nOp;
    
    //var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
    //var this.lTiposVariaciones:Array=[3];
        
    this.lVariaciones = new Array();

    this.lPreguntas=new Array();
    this.lRespuestas=new Array();
    this.lRespuestasString=new Array();
    this.lFiguras=new Array();

    
    //this.listAux=new Array();
    this.enun = "";
    this.co_respuestas=new createjs.Sprite();
    this.lTiposVariaciones=new Array();
    
    this.plano = "";
    this.co_pizarra = "";
    //////nuevo faase 2////
    //var hayPista=false;
    
    this.generarSerie = function(semilla)
    {
        EA._formatoBase=["Arial",20,"#000000",false];
        Random.init(semilla,100);
        
        this.lVariaciones = new Array();
        this.lPreguntas=new Array();
        this.lRespuestas=new Array();
        this.lRespuestasString=new Array();
        this.lFiguras=new Array();
        this.plano = "";
        this.co_pizarra = "";
        
        
        this.lIndicesRESP = new Array();
        this.lPreguntasVar = new Array();
        this.lValoresReales = new Array();
        this.lPotencias = new Array();
        

        var ordenS = ( Motor.orden == 0 ) ? 'creciente' : 'decreciente';
        var magnitudS = ['longitud','masa o peso','superficie','volumen o capacidad','tiempo o ángulo',''][Motor.magnitud];

        for( this.nMedida = 0; this.nMedida < Motor.qOperaciones; this.nMedida++ ) {
            this.enunciar();
        }
        this.lIndicesRESP=this.montaIndicesCreciente(this.lValoresReales);

        if( !Motor.creciente ){
            this.lIndicesRESP.reverse();
        }
        for(var j=0;j<Motor.qOperaciones;j++){
            Motor.lOperaciones[j]=new Object();

            if(this.lPotencias[j] != null){

                Motor.lOperaciones[j].pregunta=this.lPreguntas[j] + "{{sup}}" + this.lPotencias[j] + "{{normal}}";
            }else{
                Motor.lOperaciones[j].pregunta=this.lPreguntas[j];
            }
            Motor.lOperaciones[j].respuesta=this.lIndicesRESP.indexOf(j);
        }
        

        Motor.enunciadoJ = Motor.lEnunciados[Motor.orden] + ' ' + magnitudS;
    }
    
    this.enunciar = function()
    {
        var A,B,C,D,R;        
        var lPregNUM = new Array();
        var lPregSTR = new Array();
        var lRespNUM = new Array();
        var lRespSTR = new Array();
        var lPreguntasVar = new Array();

        switch(Motor.magnitud){
            case 0://longitud
            case 1://masa
                var qDigitos = Random.integer(1,5);
                var lCifras = [Random.integer(1,9)];
                for(var i = 1; i < qDigitos; i++){
                    lCifras.push(Random.integer(0,9));
                }
                var qEnteros = Random.integer(-3,qDigitos+1);
                var numeroPresentado = this.representar(lCifras,qEnteros);

                var unidad = Random.integer(0,6);
                this.lPreguntas.push(numeroPresentado+' '+['m','c','d','','da','h','k'][unidad]+['m','g'][Motor.magnitud]);
                var valorReal = JL.str2num(numeroPresentado)*Math.pow(10,unidad);
                this.lValoresReales.push(valorReal);
                this.lPotencias[this.nMedida]=null;
                Motor.potencia=null;
                break;
            case 2://superficie
                var qDigitos=Random.integer(1,5);
                var lCifras=[Random.integer(1,9)];
                for(i=1;i<qDigitos;i++){
                    lCifras.push(Random.integer(0,9));
                }
                while(true){
                    var qEnteros=Random.integer(-2,qDigitos+1);
                    var numeroPresentado=this.representar(lCifras,qEnteros);
                    var unidad=Random.integer(0,6);
                    var valorReal=JL.str2num(numeroPresentado)*Math.pow(10,2*unidad);
                    if((valorReal>1e-6)&&(valorReal<1e7)){
                        this.lPreguntas.push(numeroPresentado+' '+['mm','cm','dm','m','dam','hm','km'][unidad]);
                        this.lValoresReales.push(valorReal);
                        break;
                    }
                }
                this.lPotencias[this.nMedida]=2;
                Motor.potencia=null;
                break;
            case 3://volumen o capacidad
                if(Random.integer(1)==0){
                    //volumen
                    var qDigitos=Random.integer(1,5);
                    var lCifras=[Random.integer(1,9)];
                    for(i=1;i<qDigitos;i++){
                        lCifras.push(Random.integer(0,9));
                    }
                    while(true){
                        var qEnteros=Random.integer(-2,qDigitos+1);

                        var numeroPresentado=this.representar(lCifras,qEnteros);
                        var unidad=Random.integer(0,6);
                        
                        //console.log(numeroPresentado);
                        
                        var valorReal=JL.str2num(numeroPresentado)*Math.pow(10,3*unidad);

                        //console.log(valorReal);

                        if((valorReal>1e-6)&&(valorReal<1e7)){
                            this.lPreguntas.push(numeroPresentado+' '+['mm','cm','dm','m','dam','hm','km'][unidad]);
                            this.lValoresReales.push(valorReal);
                            break;
                        }
                    }
                    this.lPotencias[this.nMedida]=3;
                    potencia=3;
                }else{
                    //capacidad
                    var qDigitos=Random.integer(1,5);
                    var lCifras=[Random.integer(1,9)];
                    for(i=1;i<qDigitos;i++){
                        lCifras.push(Random.integer(0,9));
                    }
                    var qEnteros=Random.integer(-3,qDigitos+1);
                    var numeroPresentado=this.representar(lCifras,qEnteros);
                    var unidad=Random.integer(0,6);
                    this.lPreguntas.push(numeroPresentado+' '+['m','c','d','','da','h','k'][unidad]+'l');
                    var valorReal=JL.str2num(numeroPresentado)*Math.pow(10,unidad+3);
                    this.lValoresReales.push(valorReal);
                    this.lPotencias[this.nMedida]=null;
                    Motor.potencia=null;
                }
                break;
            case 4://ángulos
            case 5://tiempo
                this.lPotencias[this.nMedida]=null;
                Motor.potencia=null;
                var uniGH = ['º','h'][Motor.magnitud-4];
                while(true){
                    var grad = Random.integer(0,12);
                    var min = Random.integer(0,59);
                    var seg = Random.integer(0,59);
                    var valorReal=3600*grad+60*min+seg;
                    if(this.lValoresReales.indexOf(valorReal)==-1){
                        this.lValoresReales.push(valorReal);
                        break;
                    }
                }
                //decide formato de presentación de la pregunta:
                if(Random.random()<0.5){
                    //forma compleja:
                    var grados = grad.toString()+uniGH+' '+min.toString()+"' "+seg.toString()+'"';
                    this.lPreguntas.push(grados);
                }else{
                    //forma incompleja o decimal:
                    var valorPresentado;
                    var auxUnidad = Random.integer(0,2);
                    if(auxUnidad==0){
                        valorPresentado=grad+min/60+seg/3600;
                    }else if(auxUnidad==1){
                        valorPresentado=grad*60+min+seg/60;
                    }else{
                        valorPresentado=grad*3600+min*60+seg;
                    }
                    var grados = JL.num2str(valorPresentado,[4,3,0][auxUnidad], -1)+[uniGH,"'",'"'][auxUnidad];
                    this.lPreguntas.push(grados);
                }
                break;
        }
    }
    this.montaIndicesCreciente = function(lista){
        var lValores = lista.slice();
        var lResp = new Array();
        //console.log(lista);
        for(var i = 0;i<lista.length;i++){
            var min = JL.getMinimo(lValores);
           // console.log("valor minimo : " + min);
            var ind = lValores.indexOf(min);
            //console.log("indentificador : " + ind);
            lResp.push(ind);
            lValores[ind]=Infinity;
        }
        return lResp;
    };
    this.representar = function(li,om){
        var lR = li.slice();
        var lo = lR.length;

        //console.log("lo : " + lo);
        //console.log("om : " + om);

        if(om>=lo){
            for(var i = 0;i<om-lo;i++){
                lR.push('0');
            }
        }else if(om>0){
            lR.splice(om,0,'.');
        }else{
            for(i=0;i<Math.abs(om);i++){
                lR.unshift('0');
            }
            lR.unshift('0.');
        }
        //console.log(lR.join(""));
        //console.log( JL.num2str(lR.join("")) );
        //return JL.num2str(parseInt(lR.join("")));
        return JL.num2str( lR.join("") );
    }
    this.esEntero = function(vv){
        if((vv!=0)&&(Math.floor(vv)==vv)&&(Math.abs(vv)<Infinity)){
            return true;
        }else{
            return false;
        }
    };

}