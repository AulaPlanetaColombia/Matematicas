Generador = new function()
{
	this.nOp;
	this.enun = "";
	this.lPregsSTR = new Array();
    this.lRespsNUM = new Array();
    this.lRespsSTR = new Array();
    //this.lTiposVarMagnitud = Motor.datosXML.variaciones;
    this.lVarMagnitud = new Array();
	
	//this.listAux=new Array();
	this.enun = "";
	this.co_respuestas=new createjs.Sprite();
	
	this.plano = "";
	this.co_pizarra = "";
	this.base ="";
	//////nuevo faase 2////
	//var hayPista=false;
	
	this.generarSerie = function(semilla)
	{
		EA._formatoBase = ["Arial",36,"#0D3158",false];
		Random.init(semilla,100);
		
		this.lVarMagnitud = new Array();
		var lTiposVarMagnitud = Motor.lTiposVariaciones;//vienen "1-based". Luego lo trabajamos "0-based"
        //----------------------------------------------------------------------------------
        //console.log(lTiposVarMagnitud);
        var lVarMagnitud = new Array();
        for (var i = 0; i<Motor.qOperaciones;i++) {
            var indice = i % lTiposVarMagnitud.length;
            this.lVarMagnitud[i] = lTiposVarMagnitud[indice];
            
        }
		//console.log(this.lVarMagnitud);
		
		this.lPreguntas = new Array();
        this.lRespuestas = new Array();
        this.lRespuestasString = new Array();
        this.lUnidadesRespuestas = new Array();
        this.lIndicesRESP = new Array();
        this.lPreguntasVar = new Array();
        this.lValoresReales = new Array();
		this.co_pizarra = "";

		for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
			//enunciar(this.nOp,0);
			
			this.enunciar();
			//console.log( Motor.lOperaciones[this.nOp]);

		}
	
	}
	
	this.enunciar = function()
	{
	    
	    //this.enun = Motor.datosXML.enunciados[0].enunciado;
        var nMAG = this.lVarMagnitud[this.nOp];
        //nMAG hasta aquí: 0-->longitud   1-->masa   2-->superficie   3-->volumen   4-->ángulos   5-->tiempo
        if(nMAG>3){
            nMAG++;
        }
        if(nMAG==3){
            if(Random.integer(1)==0){
                nMAG=3;//se confirma volumen
            }else{
                nMAG=4;//cambia a capacidad
            }
        }
        //nMAG desde aquí: 0->longitud  1-->masa  2->superficie  3->volumen  4->capacidad  5->ángulos  6->tiempo
        
        var dimension = [1,1,2,3,1,0,0][nMAG];
        //console.log("dimension : " + dimension);
        var tiraPregA;
        var tiraPregB;
        if(nMAG<5){//magnitud decimal (0,1,2,3,4)
            while(true){
                while(true){
                    var uA = Random.integer(6);
                    var uB = Random.integer(6);
                    var uT = Random.integer(6);
                    var difMax = Math.max(uA,uB,uT)-Math.min(uA,uB,uT);
                    //if(difMax<[7,5,3][dimension-1]){
                    if(difMax<[4,3,2][dimension-1]){
                        break;
                    }
                }
                //var qDA:int=r.integer(1,4);
                var qDA = Random.integer(1,3);
                var lDA = [Random.integer(1,9)];
                for(var i = 1; i <qDA; i++){
                    lDA.push(Random.integer(0,9));
                }
                //var qEA:int=r.integer(-2,qDA+1);
                var qEA = Random.integer(-1,qDA+0);
                //var qDB:int=r.integer(1,4);
                var qDB = Random.integer(1,3);
                var lDB = [Random.integer(1,9)];
                for(i=1;i<qDB;i++){
                    lDB.push(Random.integer(0,9));
                }
                //var qEB:int=r.integer(-2,qDB+1);
                var qEB = Random.integer(-2,qDB+0);
                var uRef = Math.min(uA+qEA-qDA,uB+qEB-qDB);
                var uTS = ['m','c','d','','da','h','k'][uT];
                
                uTS+=['m','g','m','m','l'][nMAG];
                
                this.lUnidadesRespuestas.push(uTS);
                var vA_ref = JL.medida2valor([lDA,qEA,uA],uRef,dimension);
                var vB_ref = JL.medida2valor([lDB,qEB,uB],uRef,dimension);
                var tipoOP = Random.integer(1);
                if(tipoOP==1){
                    if(vB_ref>vA_ref){
                        //permuta todas las características de las dos medidas:
                        var broker = qDA;
                        qDA=qDB;
                        qDB=broker;
                        broker=qEA;
                        qEA=qEB;
                        qEB=broker;
                        broker=uA;
                        uA=uB;
                        uB=broker;
                        broker=vA_ref;
                        vA_ref=vB_ref;
                        vB_ref=broker;
                        var brokerARR = lDA.slice();
                        lDA=lDB.slice();
                        lDB=brokerARR.slice();
                    }
                    var vRespRef = vA_ref-vB_ref;
                }else{
                    vRespRef=vA_ref+vB_ref;
                }
                break;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            }
            //transformación de vRespRef en respN (Number):
            var respN = vRespRef*Math.pow(10,(uRef-uT)*dimension);
            this.lRespuestas.push(respN);
            //transformación de vRespRef en respS (String):
            var vRespRef_split = String(vRespRef).split('');
            var pos = vRespRef_split.indexOf('.');
            if(pos==-1){
                pos=vRespRef_split.length;
            }
            var arraySinPunto = vRespRef_split.slice();
            arraySinPunto.splice(pos,1);
            var salto = (uRef-uT)*dimension;
            var posF = pos+salto;
            var respS = this.representar(arraySinPunto,posF);
            
            this.lRespuestasString.push(respS);
            //montaje de los strings pregunta:
            var factorAS = this.representar(lDA,qEA);
            var unidadS = ['m','c','d','','da','h','k'][uA];
            unidadS+=['m','g','m','m','l'][nMAG];
            tiraPregA=factorAS+' '+unidadS;
            var factorBS = this.representar(lDB,qEB);
            unidadS=['m','c','d','','da','h','k'][uB];
            unidadS+=['m','g','m','m','l'][nMAG];
            tiraPregB=['+','−'][tipoOP]+' '+factorBS+' '+unidadS;
            this.lPreguntas.push([tiraPregA,tiraPregB]);
        }else{//magnitud sexagesimal
            var uniGH=['º','h'][nMAG-5];
            tipoOP=Random.integer(1);
            var gradA = Random.integer(1,35);
            var minA = Random.integer(0,59);
            var segA = Random.integer(0,59);
            var valorRealSA = gradA*3600+minA*60+segA;
            var gradB = Random.integer(1,35);
            var minB = Random.integer(0,59);
            var segB = Random.integer(0,59);
            var valorRealSB = gradB*3600+minB*60+segB;
            if(tipoOP==0){//suma
                this.lPreguntas.push([[String(gradA)+uniGH+' '+String(minA)+"' "+String(segA)+'" '],[' +   '+String(gradB)+uniGH+' '+String(minB)+"' "+String(segB)+'"']]);
                this.lRespuestas.push(JL.seg2sex(valorRealSA+valorRealSB));
                this.lRespuestasString.push(JL.seg2sex(valorRealSA+valorRealSB));
            }else{//resta
                var dif = valorRealSA-valorRealSB;
                if(dif<0){
                    var temp = gradA;
                    gradA=gradB;
                    gradB=temp;
                    temp=minA;minA=minB;minB=temp;
                    temp=segA;segA=segB;segB=temp;
                    dif=-dif;
                }
                this.lPreguntas.push([[String(gradA)+uniGH+' '+String(minA)+"' "+String(segA)+'" '],[' −   '+String(gradB)+uniGH+' '+String(minB)+"' "+String(segB)+'"']]);
                this.lRespuestas.push(JL.seg2sex(dif));
                this.lRespuestasString.push(JL.seg2sex(dif));
                
            }
            this.lUnidadesRespuestas.push(uniGH);
        }
        //////comprobamos q potencia llevara esta operacion
        //nPotencia=[void,void,2,3,void,void,void][nMAG];
        //nPotencia=[void,void,2,3,void,0,0][nMAG]
        this.nPotencia=['','',2,3,'','','',0][nMAG];

        //
        ///A PARTIR DE AQUI LLENO MI ARRAY DE OPERACIONES; CON LOS VALORES DE LAS ARRAYS DE PREGUNTAS, RESPUESTAS, TIPO DE RESPUESTA en cada paso de nPreg
         
        Motor.lOperaciones[this.nOp] = new Object();
        Motor.lOperaciones[this.nOp].pregunta0 = this.lPreguntas[this.nOp][0];
        Motor.lOperaciones[this.nOp].pregunta1 = this.lPreguntas[this.nOp][1];
        Motor.lOperaciones[this.nOp].respuesta = this.lRespuestas[this.nOp];
        Motor.lOperaciones[this.nOp].respuestaString = this.lRespuestasString[this.nOp];
        Motor.lOperaciones[this.nOp].tipoUnidad = this.lUnidadesRespuestas[this.nOp];
        Motor.lOperaciones[this.nOp].in_respuesta = "";
        Motor.lOperaciones[this.nOp].estaListo = false;
        Motor.lOperaciones[this.nOp].correcto = false;
        Motor.lOperaciones[this.nOp].variacion = this.lVarMagnitud[this.nOp];
        Motor.lOperaciones[this.nOp].potencia = this.nPotencia;
        Motor.lOperaciones[this.nOp].enunciado = this.enun;
        Motor.lOperaciones[this.nOp].magnitud = nMAG;
        //Motor.lOperaciones[this.nOp].rotulos = this.lRotulos;
        
        
	};
	this.representar = function(li,om){
    var lR = li.slice();
    var long = lR.length;
    if(om>=long){
        for(var i = 0; i < om-long;i++){
            lR.push('0');
        }
    }else if(om>0){
        lR.splice(om,0,'.');
    }else{
        for(i=0;i<Math.abs(om);i++){
            lR.unshift('0');
        }
        lR.unshift('0.');
    }
    return JL.num2str(Number(lR.join("")));
}
	

}