Motor = new function()
{
	this.fons = "";
	this.pagines = new Array();

	this.contenedor = "";

	this.INITIAL_Y = 118;
	this.PREG_Y_PADDING = 87;
	this.PREG_X_PADDING = 25;
	
	//inici
	this.PREG_INICI_X_PADDING = 235 ;
	//final
	this.PREG_FINAL_X_PADDING = 585 ;
	
	this.RESP_HEIGHT = 82;
	this.RESP_WIDTH = 322; 
	this.RESP_INNER_HEIGHT = 78;
	this.RESP_INNER_WIDTH = 320; 
	
	//line
	this.LINE_X = 570;
	this.LINE_Y_MIN = 20;
	this.LINE_Y_MAX = 535;
	this.LINE_SIZE = 3;
	
	this.itemX= 0;
	this.itemY= 0;
	
	this.separator = ""; 
	
	this.datosXML = "";
	this.solucion = false;
	
	this.video ="";	
	this.currentPag = "";
	this.currentNumPag =0;
	this.IMG = "data/imagenes/";
	
	//GUINARDO
	this.lEnunciados=new Array();
	this.qEnunciados = 0;
	this.listAux= new Array();
	this.qOperaciones;
	this.lOperaciones = new Array();
	this.co_pizarra;
	this.lPreguntas = new Array();
	
	this.ponerContenedor = function(contenedorMotor) {

	};
	
	this.cargarDatos = function()
	{
		$.get(pppPreloader.from("data", "data/datos.xml" + "?time=" + new Date().getTime()), function (xml) {

			//debugger;
			Motor.datosXML = new datosMotor();
			Motor.datosXML.cantidad = $(xml).find('qOperaciones').text();
				        
	        var seed = $(xml).find('seed');
	        Motor.datosXML.seed = seed.text();
	        
	        var curso = $(xml).find('curso');
            Motor.datosXML.curso = curso.text();
            
			this.preg = new enunciado();
            this.preg.id = 0;
            this.preg.enunciado = $(xml).find('enunciado').text();
            Motor.datosXML.enunciados.push(this.preg);
			
            Motor.datosXML.variaciones = new Array();
            $(xml).find('variaciones').children().each(function(index){
                //debugger;
                this.preg = new variaciones();
                this.preg.id = index;
                this.preg.text = $(this).text();
                this.preg.tag = this.tagName;
                Motor.datosXML.variaciones.push(this.preg);
            });
            
	       	Motor.inicializarEstructura();
			Contenedor.crearPaginacio();
		});
	}
	this.inicializarEstructura = function(estado) {

		this.initGenerador();
	 	this.init();

	};
	this.reinicializarEstructuraMotor = function()
	{
		Main.stage.removeChild(Motor.contenedor);
		Motor.cargarDatos();
		
	}
	this.estaCompletado = function(){
		
		this.currentPag.completado();
		
		for(key1 in Motor.pagines){
		    if(!Motor.pagines[key1].isCompletado()){
		        return false
		    }
		}
		return true;
	};
	
	this.getEstado = function(){
        var estado = new Array();
        //console.log(Motor.pagines);
        var respuesta = "";
        
        for(key1 in Motor.pagines)
        {
            respuesta = respuesta + "AAA";
            if( !Motor.pagines[key1].compleja){
                respuesta = respuesta + Motor.pagines[key1].correcte0;
            }else{
                respuesta = respuesta + "BBB";
                respuesta = respuesta + Motor.pagines[key1].correcte1;
                respuesta = respuesta + "BBB";
                respuesta = respuesta + Motor.pagines[key1].correcte2;
                respuesta = respuesta + "BBB";
                respuesta = respuesta + Motor.pagines[key1].correcte3;
            }      
        }
        return respuesta;
    };
	
	this.revisar = function(){
        if(this.estado != "")
        {
            var lRespuestas=this.estado.split("AAA");
            lRespuestas.splice(0,1);
            for(var i = 0; i < this.qOperaciones; i++){
                if( Motor.pagines[i].compleja == false ){
                    Motor.pagines[i].correcte0 = lRespuestas[i];
                }else{
                    var lRespuestasAux = lRespuestas[i].split("BBB");
                    lRespuestasAux.splice(0,1);
                    Motor.pagines[i].correcte1 = lRespuestasAux[0];
                    Motor.pagines[i].correcte2 =lRespuestasAux[1];
                    Motor.pagines[i].correcte3 = lRespuestasAux[2];
                }
            }
            //para actualizar el valor de los campos de la primera pagina
            $(this["inputDOM0"].htmlElement).val(this.currentPag.correcte0);
        }
    };
	
	this.validar = function() {

		this.currentPag.completado();
		var total = 0;
	  	for(key1 in Motor.pagines){
            var correcte = true;
            if( !Motor.pagines[key1].isValidado() ){
               correcte = false; 
            }       
            
            if( correcte ){
                total++;
                Motor.pagines[key1].validacio = true;
            }else{
                Motor.pagines[key1].validacio = false;
            }
            
            
        }
            
            /*if(this.lOperaciones[key1].compleja==false){
                if(this.lOperaciones[key1].variacion<5){///no hay respuestaNumerica, comparar string como antes
                    //if(JL.esEntryCorrecta(Motor.pagines[key1].K,this.lOperaciones[key1].respuesta[0],0.5)){
                    if(JL.str2numJL.num2str((Motor.pagines[key1].correcte0)), JL.str2num(Motor.pagines[key1].correctoK)){
                        Motor.pagines[key1].caja00.correct();
                        this.lOperaciones[key1].correcto=true;
                        total++;
                    }else{
                        Motor.pagines[key1].caja00.error();
                        Motor.pagines[key1].validacio = false;
                    }
                }else{//es el caso conflictivo-> comparar Numerico
                    //if(JL.esEntryCorrecta(Motor.pagines[key1].K,this.lOperaciones[key1].respuestaNum,0.5)){
                    if(JL.num2str(JL.str2num(Motor.pagines[key1].correcte0)), JL.num2str(Motor.pagines[key1].correctoK)){
                        Motor.pagines[key1].caja00.correct();
                        this.lOperaciones[key1].correcto=true;
                        total++;
                    }else{
                        Motor.pagines[key1].caja00.error();
                        Motor.pagines[key1].validacio = false;
                    }
                }
            }else{
                ///comprobar las 3 lRespuestas
                var respCorrecta = true;
                if(JL.esEntryCorrecta(Motor.pagines[key1].correcte1,this.lOperaciones[key1].respuesta[0],0.5)){
                }else{
                    respCorrecta=false;
                }
                if(JL.esEntryCorrecta(Motor.pagines[key1].correcte2,this.lOperaciones[key1].respuesta[1],0.5)){
                }else{
                    respCorrecta=false;
                }
                if(JL.esEntryCorrecta(Motor.pagines[key1].correcte3,this.lOperaciones[key1].respuesta[2],0.5)){
                }else{
                    respCorrecta=false;
                }
                
                if(respCorrecta==true){
                    Motor.pagines[key1].caja00.correct();
                    Motor.pagines[key1].caja10.correct();
                    Motor.pagines[key1].caja20.correct();
                    this.lOperaciones[key1].correcto=true;
                    total++;
                }else{
                    Motor.pagines[key1].caja00.error();
                    Motor.pagines[key1].caja10.error();
                    Motor.pagines[key1].caja20.error();
                }
            }*/

        //}
			
		return total.toString() + "/" + Motor.pagines.length.toString();
		
	};
	this.hideDomObjects = function(){

		this.currentPag.desactiva();
        /*$(this.inputDOM0.htmlElement).css('display', 'none');
        $(this.inputDOM1.htmlElement).css('display', 'none');
        $(this.inputDOM2.htmlElement).css('display', 'none');
        $(this.inputDOM3.htmlElement).css('display', 'none');*/
	}
	this.showDomObjects = function(){
		this.currentPag.activa();
        /*$(this.inputDOM0.htmlElement).css('display', 'inline');
        $(this.inputDOM1.htmlElement).css('display', 'inline');
        $(this.inputDOM2.htmlElement).css('display', 'inline');
        $(this.inputDOM3.htmlElement).css('display', 'inline');*/
	}
	this.obtenerEstado = function(){

	  //alert("Hola, Soy" + this.primerNombre);
	};
	this.reiniciar = function() {
	  //alert("Estoy caminando!");
	};
	this.activar = function(){
        $(this.inputDOM0.htmlElement).prop('readonly', false);
        $(this.inputDOM1.htmlElement).prop('readonly', false);
        $(this.inputDOM2.htmlElement).prop('readonly', false);
        $(this.inputDOM3.htmlElement).prop('readonly', false);
    }
    this.desactivar = function() {
        $(this.inputDOM0.htmlElement).prop('readonly', true);
        $(this.inputDOM1.htmlElement).prop('readonly', true);
        $(this.inputDOM2.htmlElement).prop('readonly', true);
        $(this.inputDOM3.htmlElement).prop('readonly', true);

    };
	this.numPaginas = function(){
		return Motor.datosXML.cantidad;
	};
	this.ponerPagina = function(pag) {
		
		this.currentPag.getParam();

		this.contenedor.removeChild( this.currentPag.contenedor );
		this.currentNumPag = pag - 1;
	    this.currentPag = this.pagines[this.currentNumPag];
	    this.contenedor.addChild( this.currentPag.contenedor );
	    
	    
	    var navegador = Main.navegador;
        var navegadorSplit = navegador.split(' ');
        var mobil = Main.mobil
        var index = navegadorSplit[0].indexOf("Safari");
        var version = navegadorSplit[1];
	    
	    if(index > -1 && mobil =="Android"){
            $(this["inputDOM0"].htmlElement).focus().blur();
            $(this["inputDOM1"].htmlElement).focus().blur();
            $(this["inputDOM2"].htmlElement).focus().blur();
            $(this["inputDOM3"].htmlElement).focus().blur();
        }
	    
	   this.currentPag.setParam();
	    
	    /*if(  this.currentPag.validacio == "" ){ }
	    else if( this.currentPag.validacio == false)
			$(this["inputDOM0"].htmlElement).css("color","#E1001A");
		else if(this.currentPag.validacio == true)
			$(this["inputDOM0"].htmlElement).css("color","#41A62A");*/
	    
	};
	
	this.obtenerPaginaActual = function(pag){

	};
	this.verSolucion = function(conEfecto){
	  
	  	this.deseleccionar();
	  	this.solucionar();
		
	};
	this.deseleccionar = function(){
		/*for(key1 in Motor.pagines){
	   		for (key2 in Motor.pagines[key1].respostes) 
	   		{
	   			Motor.pagines[key1].respostes[key2].desactivar();
	   			Motor.pagines[key1].respostes[key2].clear();
			}
		}*/
	}
	this.solucionar = function(){
		var total = 0;
		this.solucion = false;
		
		for(key1 in Motor.pagines){
            Motor.pagines[key1].verSolucion();
        }
		
	};
	this.obtenerTipoEjercicio = function(){

	};
	this.obtenerVersion = function(){

	};
	
    this.init = function()
    {
		this.contenedor = new createjs.Container();
		this.pagines = new Array();

	    for(var i=0; i < Motor.datosXML.cantidad; i++)
    	{
	    	var index = 0;
	    	//console.log(Motor.lOperaciones[i].enunciadoJ);
	    	var enunciado = Motor.datosXML.enunciados[0];	
			//var enunciado = Motor.lOperaciones[i].enunciadoJ;
	    	this.addPagina( enunciado, i , index);
	    }
	    
	    this.deleteInputs();
        this.initIntroTexto();
        
	    this.contenedor.addChild( this.pagines[0].contenedor );
        this.currentPag = this.pagines[0] ;
        this.currentNumPag = 0;
        this.currentPag.setParam();
	    
	    Main.stage.addChild( this.contenedor );
    }
    
    this.addPagina = function( enunciado, numpagina , idPregunta)
    {

    	if( Motor.lOperaciones[numpagina].compleja == false){
           var pagina = new Pagina( enunciado, numpagina, Motor.lOperaciones[numpagina]);
        }else{
            var pagina = new Pagina3( enunciado, numpagina, Motor.lOperaciones[numpagina]);
        }
       

        
    	pagina.contenedor.y = this.INITIAL_Y;
    	this.pagines.push( pagina );
    	
    }
    
    this.initGenerador = function()
    {
    	var seed = Motor.datosXML.seed;

		this.lEnunciados = new Array();
		this.qEnunciados = 0;
		this.listAux= new Array();
		this.lOperaciones = new Array();
		this.lVariaciones = new Array();
		this.lTiposVariaciones = new Array();
        var indice;
		//for(var key in  Motor.datosXML.enunciados)
		//{
			var ss = Motor.datosXML.enunciados[0].enunciado.toString();
			ss = JL.reemplazar(ss, 'NNN', '\n');
			this.lEnunciados.push( ss );
		//}
		//console.log( this.lEnunciados);
		this.qEnunciados = this.lEnunciados.length;

		/////extrar qOperaciones
		this.qOperaciones = Motor.datosXML.cantidad;
		
		
		for(var i=1;i<7;i++){
            if(Motor.datosXML.variaciones[i-1].text == "1"){
                this.lTiposVariaciones.push(i);
            }
        }
		//console.log(this.lTiposVariaciones);
		
        for (var op = 0; op < this.qOperaciones; op++) {
            indice = op % this.lTiposVariaciones.length;
            this.lVariaciones[op] = this.lTiposVariaciones[indice];
        }
		
		
		if(Scorm.modo == Scorm.MODO_EXPONER){
			Generador.generarSerie(JL.iRandom(1,100));
		}else{
			Generador.generarSerie(seed);
		}
		//console.log(Motor.lOperaciones);
    }
    
    this.initIntroTexto = function(){        
        var navegador = Main.navegador;
        var navegadorSplit = navegador.split(' ');
        var mobil = Main.mobil
        var index = navegadorSplit[0].indexOf("IE");
        var version = navegadorSplit[1];

        for(var i = 0; i < 4; i++)
        {
            var $input = $('<input type="text" id="input_'+ i +'"  onkeyup="Motor.filtrarText(event);" class="input"/>');
	        
	        if(index > -1 && mobil =="Tablet"){
            	$input.focusout(function(event){ $("body").focus(); });
            }
            
            $("#mediaHolder").append($input);

            this["inputDOM"+i] = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
            
            this["inputDOM"+i].element_x = (i==0)? 262 : 296 + i*120;
            //this["inputDOM"+i].element_x = 1000 + i*120;
            this["inputDOM"+i].element_y = 313;
            //this["inputDOM"+i].element_y = 1000;
            this["inputDOM"+i].element_width =(i==0)? 220 : 80;
            this["inputDOM"+i].element_height = 25;
            this["inputDOM"+i].fontsize = 20;
            
            this["inputDOM"+i].x = this["inputDOM"+i].element_x ;
            this["inputDOM"+i].y = this["inputDOM"+i].element_y ;
            $(this["inputDOM"+i].htmlElement).css("width", this["inputDOM"+i].element_width);
            $(this["inputDOM"+i].htmlElement).css("height", this["inputDOM"+i].element_height);
            $(this["inputDOM"+i].htmlElement).hide();
            $(this["inputDOM"+i].htmlElement).css("color","#0D3158");
            //this["inputDOM"+i].alpha = 0;
            
            this.contenedor.addChild(this["inputDOM"+i]);
            
            if(index > -1 && mobil =="Tablet"){
            	$input.focusout(function(event){ $("body").focus(); });
            	$(this["inputDOM"+i].htmlElement).click(Motor.select);
            }
            
        }   
    };

    this.filtrarText = function(e){
    	var id = e.target.id;
    	if( $("#" + id).val().length ){
    		Contenedor.checkPagina();
    	}
    };
    
    this.select = function(){
        $(this).blur().focus();
        //Main.windowResize();
    };

    this.deleteInputs = function()
	{
		$( "input" ).each(function() {
		  $( this ).remove();
		});
	}

}
