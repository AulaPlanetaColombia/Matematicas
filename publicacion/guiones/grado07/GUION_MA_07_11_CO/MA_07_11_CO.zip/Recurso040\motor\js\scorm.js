Scorm = new function()
{

	this.modo = "";
	this.suspend_data = "";
	this.completed = "";
	this.connected = false;
	
	this.MODO_EXPONER = "browse";
	this.MODO_REVISAR = "review";
	this.MODO_REVISARALUMNO = "areview";
	this.MODO_EXAMEN = "exam";
	
	this.init = function( data )
	{
		this.modo = data.mode;
		this.suspend_data = data.suspend_data;
		this.completed = data.completed;
		this.connected = data.connected;
		
		/****  HARDCODED DATA  ****
		this.modo = this.MODO_EXAMEN;
		this.suspend_data = "AAA155AAA138AAA155AAA175AAA155AAA212AAA155AAA249AAA155AAA286AAA155AAA323AAA155AAA360AAA155AAA397AAA155AAA434AAA155AAA471AAABBB7BBB5BBB2BBB0BBBBBBBBBBBBBBB4BBB3BBBDDDCCCtrueCCCtrueCCCtrueCCCtrueCCCfalseCCCfalseCCCfalseCCCfalseCCCtrueCCCtrue";
		this.completed = "completed";
		this.connected = true;
		**/
	}
	
}