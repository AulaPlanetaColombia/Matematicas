Generador = new function()
{
    this.nOp;
    
    //var this.lTiposVariaciones:Array=[1,2,3,4];//1-prismas   2-pirámides   3-cilindro   4-esfera
    //var this.lTiposVariaciones:Array=[3];
        
    this.lVariaciones = new Array();

    this.lPreguntas=new Array();
    this.lRespuestas=new Array();
    this.lRespuestasString=new Array();
    this.lFiguras=new Array();

    
    //this.listAux=new Array();
    this.enun = "";
    this.co_respuestas=new createjs.Sprite();
    this.lTiposVariaciones=new Array();
    
    this.plano = "";
    this.co_pizarra = "";
    //////nuevo faase 2////
    //var hayPista=false;
    
    this.generarSerie = function(semilla)
    {
        EA._formatoBase=["Arial",20,"#000000",false];
        Random.init(semilla,100);
        
        this.lVariaciones = new Array();
        this.lPreguntas=new Array();
        this.lRespuestas=new Array();
        this.lRespuestasString=new Array();
        this.lFiguras=new Array();
        this.plano = "";
        this.co_pizarra = "";
        
        
        this.lVariaciones = new Array();
        for (var op = 0; op < Motor.qOperaciones; op++) {
            var indice = op % Motor.lTiposVariaciones.length;
            //console.log(indice);
            this.lVariaciones[op]=Motor.lTiposVariaciones[indice];
        }
      
        for( this.nOp = 0; this.nOp < Motor.qOperaciones; this.nOp++ ) {
            //enunciar(this.nOp,0);
            
            this.enunciar();

            //console.log(this.nOp+"----"+Motor.lOperaciones[this.nOp].solucion);
        }
        
    }
    
    this.enunciar = function()
    {
        
        var enunciado;
        //var tipoOp=['suma','resta','multi','divi','comb'][this.lVariaciones[this.nOp].id];
        var A,B,C,D,R;
        var tira;
        var valorPAR,valorPAR2;
        var lOp;
        var parentesis;
        var qDA,qDB,qDC,qDD;
        var AS,BS,CS,DS,RS;
        var nPotencia=null;
        var compleja=false;
        var nVariacion = this.lVariaciones[this.nOp];
        var respuNum=0;
        var tipoSexa ="";
        
        var lPregNUM = new Array();
        var lPregSTR = new Array();
        var lRespNUM = new Array();
        var lRespSTR = new Array();
        var lPreguntasVar = new Array();
        var lSignos = new Array();
        var lPregs_med = new Array();
        var lPregs_uni = new Array();
        var lRespuestas = new Array();
        var lRespuestasNUM = new Array();
        
        if(Motor.primaria==false){
            lSignos=['+','−','·',':'];
        }else{
            lSignos = ['+','−','x',':']
        }
        var lSignosR=['+','−','x',':'];
        if(Motor.primaria==false){
            lSignosR=['+','−','·',':'];
        }
        
        switch(nVariacion) {
            case 1://longitud:
                var qDigitos = Random.integer(1,5);
                var lCifras = [Random.integer(1,9)];
                for(var i = 1; i < qDigitos;i++){
                    lCifras.push(Random.integer(0,9));
                }
                while(true){
                    var unidad = Random.integer(0,6);
                    var om = Random.integer(-3,qDigitos);
                    var unidadT = Random.integer(0,6,[unidad]);
                    var salto = unidadT-unidad;
                    var omNew = om-salto;
                    if((omNew>-5)&&(omNew<qDigitos+6)){
                        break;
                    }
                }
                var unidadS = ['mm','cm','dm','m','dam','hm','km'][unidad];
                var unidadTS = ['mm','cm','dm','m','dam','hm','km'][unidadT];
                lPregs_med.push(this.representar(lCifras,om)+' '+unidadS);
                lPregs_uni.push(unidadTS);
                lRespuestas.push(this.representar(lCifras,om-salto));
                nPotencia=null;
                compleja=false;
                break;
            
            case 2://masa:
                qDigitos=Random.integer(1,5);
                lCifras=[Random.integer(1,9)];
                for(i=1;i<qDigitos;i++){
                    lCifras.push(Random.integer(0,9));
                }
                while(true){
                    unidad=Random.integer(0,6);
                    om=Random.integer(-3,qDigitos);
                    unidadT=Random.integer(0,6,[unidad]);
                    salto=unidadT-unidad;
                    omNew=om-salto;
                    if((omNew>-5)&&(omNew<qDigitos+6)){
                        break;
                    }
                }
                unidadS=['mg','cg','dg','g','dag','hg','kg'][unidad];
                unidadTS=['mg','cg','dg','g','dag','hg','kg'][unidadT];
                lPregs_med.push(this.representar(lCifras,om)+' '+unidadS);
                lPregs_uni.push(unidadTS);
                lRespuestas.push(this.representar(lCifras,om-salto));
                nPotencia=null;
                compleja=false;
                break;
            case 3://superficie:
                qDigitos=Random.integer(1,5);
                lCifras=[Random.integer(1,9)];
                for(i=1;i<qDigitos;i++){
                    lCifras.push(Random.integer(0,9));
                }
                while(true){
                    unidad=Random.integer(0,6);
                    om=Random.integer(-3,qDigitos);
                    unidadT=Random.integer(0,6,[unidad]);
                    salto=2*(unidadT-unidad);
                    omNew=om-salto;
                    //if((omNew>-5)&&(omNew<qDigitos+6)){
                    if((omNew>-5)&&(omNew<qDigitos+6)&&(Math.abs(unidad-unidadT)<4)){
                        break;
                    }
                }
                unidadS=['mm','cm','dm','m','dam','hm','km'][unidad];
                unidadTS=['mm','cm','dm','m','dam','hm','km'][unidadT];
                lPregs_med.push(this.representar(lCifras,om)+' '+unidadS);
                lPregs_uni.push(unidadTS);
                lRespuestas.push(this.representar(lCifras,om-salto));
                nPotencia=2;
                compleja=false;
            break;
            case 4://volumen o capacidad:
                if(Random.integer(1)==0){
                    //volumen:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    qDigitos=Random.integer(1,5);
                    lCifras=[Random.integer(1,9)];
                    for(i=1;i<qDigitos;i++){
                        lCifras.push(Random.integer(0,9));
                    }
                    while(true){
                        unidad=Random.integer(0,6);
                        om=Random.integer(-3,qDigitos);
                        unidadT=Random.integer(0,6,[unidad]);
                        salto=3*(unidadT-unidad);
                        omNew=om-salto;
                        //if((omNew>-5)&&(omNew<qDigitos+6)){
                        if((omNew>-5)&&(omNew<qDigitos+6)&&(Math.abs(unidad-unidadT)<3)){
                            break;
                        }
                    }
                    unidadS=['mm','cm','dm','m','dam','hm','km'][unidad];
                    unidadTS=['mm','cm','dm','m','dam','hm','km'][unidadT];
                    lPregs_med.push(this.representar(lCifras,om)+' '+unidadS);
                    lPregs_uni.push(unidadTS);
                    lRespuestas.push(this.representar(lCifras,om-salto));
                    
                    nPotencia=3;
                    compleja=false;
                }else{
                    //capacidad:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    qDigitos=Random.integer(1,5);
                    lCifras=[Random.integer(1,9)];
                    for(i=1;i<qDigitos;i++){
                        lCifras.push(Random.integer(0,9));
                    }
                    while(true){
                        unidad=Random.integer(0,6);
                        om=Random.integer(-3,qDigitos);
                        unidadT=Random.integer(0,6,[unidad]);
                        salto=unidadT-unidad;
                        omNew=om-salto;
                        if((omNew>-5)&&(omNew<qDigitos+6)){
                            break;
                        }
                    }
                    unidadS=['ml','cl','dl','l','dal','hl','kl'][unidad];
                    unidadTS=['ml','cl','dl','l','dal','hl','kl'][unidadT];
                    lPregs_med.push(this.representar(lCifras,om)+' '+unidadS);
                    lPregs_uni.push(unidadTS);
                    lRespuestas.push(this.representar(lCifras,om-salto));
                    
                    nPotencia=null;
                    compleja=false;
                }//finnnnnnnnnnnnnnnnnnnnnn
                break;
            case 5://ángulos:
            case 6://tiempo:
                nPotencia=null;
                var uniGH = ['º','h'][nVariacion-5];
                tipoSexa=uniGH;
                if(Random.random()<0.5){//conversión complejo--->decimal:
                    var grad = Random.integer(0,59);
                    var min = Random.integer(0,59);
                    var seg = Random.integer(0,59);
                    lPregs_med.push(String(grad)+uniGH+' '+String(min)+"'"+' '+String(seg)+'"');
                    unidadT=Random.integer(0,2);
                    //unidadT=0;//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    lPregs_uni.push([uniGH,"'",'"'][unidadT]);
                    switch(unidadT){
                        case 0://se pide en grados/horas:
                            var auxResp = grad+min/60+seg/3600;
                            lRespuestas.push(JL.num2str(auxResp,2));
                            break;
                        case 1://se pide en minutos:
                            auxResp=grad*60+min+seg/60;
                            lRespuestas.push(JL.num2str(auxResp,2));;
                            break;
                        case 2://se pide en segundos:
                            auxResp=grad*3600+min*60+seg;
                            lRespuestas.push(JL.num2str(auxResp,0));
                            break;
                }
                lRespuestasNUM.push(auxResp);
                respuNum=auxResp;
                compleja=false;
                }else{//conversión decimal--->complejo:
                    grad=Random.integer(0,6);
                    min=Random.integer(0,59);
                    seg=Random.integer(0,59);
                    lRespuestas.push([grad,min,seg]);
                    unidad=Random.integer(0,2);
                    switch(unidad){
                        case 0://si se da en grados/horas:
                            lPregs_med.push(JL.num2str(grad+min/60+seg/3600,4)+" "+uniGH);
                            lPregs_uni.push(uniGH);
                            
                            break;
                        case 1://si se da en minutos:
                            lPregs_med.push(JL.num2str(grad*60+min+seg/60,3)+" '");
                            lPregs_uni.push("'");
                            break;
                        case 2://si se da en segundos:
                            lPregs_med.push(JL.num2str(grad*3600+min*60+seg)+" ''");
                            lPregs_uni.push('"');
                            break;
                }
                compleja=true;
            }
            break;
        }

        
        Motor.lOperaciones[this.nOp]=new Object();
        Motor.lOperaciones[this.nOp].pregunta=lPregs_med;
        Motor.lOperaciones[this.nOp].respuesta=lRespuestas;
        Motor.lOperaciones[this.nOp].respuestaNum=respuNum;
        Motor.lOperaciones[this.nOp].respuestaString=lRespuestas;
        Motor.lOperaciones[this.nOp].entrada="";
        Motor.lOperaciones[this.nOp].tipoUnidad=lPregs_uni;
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;
        Motor.lOperaciones[this.nOp].variacion=nVariacion;
        Motor.lOperaciones[this.nOp].potencia=nPotencia;
        Motor.lOperaciones[this.nOp].compleja=compleja;
        Motor.lOperaciones[this.nOp].tipoSexa=tipoSexa;
        Motor.lOperaciones[this.nOp].l_respuesta=new Array();
        Motor.lOperaciones[this.nOp].l_respuesta=["","",""];
        Motor.lOperaciones[this.nOp].enunciadoParseado=this.enun;

        //console.log(Motor.lOperaciones[this.nOp]);

        //console.log(Motor.lOperaciones[this.nOp]);

        /*Motor.lOperaciones[this.nOp].preguntaSprite.x=400;
        Motor.lOperaciones[this.nOp].preguntaSprite.y=90;
        Motor.co_pizarra.addChild(this.lEnunciados_SPRITE[this.nOp]);
        Motor.lOperaciones[this.nOp].entrada=0;
        Motor.lOperaciones[this.nOp].solucion=this.lIndicesOK_INT[this.nOp];
        Motor.lOperaciones[this.nOp].estaListo=false;
        Motor.lOperaciones[this.nOp].correcto=false;*/

    }
    
    this.representar = function(li, om){
        var lR = li.slice();
        var long = lR.length;
        if(om>=long){
            for(var i = 0;i<om-long;i++){
                lR.push('0');
            }
        }else if(om>0){
            lR.splice(om,0,'.');
        }else{
            for(i=0;i<Math.abs(om);i++){
                lR.unshift('0');
            }
            lR.unshift('0.');
        }
        return JL.num2str(Number(lR.join("")));
    }


}