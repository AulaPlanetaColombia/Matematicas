function Pagina( pregunta, _numpagina, operacio) {

    //console.log(operacio);

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
    //debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    //this.video = pregunta.video;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;

    this.validacio = true;
    //this.figura = operacio.figura;
  
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    this.addLine( 0, 250, 300 - 118, operacio.pregunta[0], "", operacio.respuestaString[0], operacio.tipoUnidad[0], operacio.potencia);
    
    //this.contenedor.addChild( operacio.figura ); 
    
    //this.addLine( 0, 350, 400 - 118, "P = ", operacio.tipoUnidad , operacio.respuestaString[0]  );
    //this.addLine( 1, 350, 460 - 118, "A = ", operacio.tipoUnidad+"<sp>2<n>", operacio.respuestaString[1]);
    this.compleja = operacio.compleja;
    this.correctoK = operacio.respuestaString[0]; 
    this.K = "";
    this.correcte0 = "";
}

Pagina.prototype.addLine = function( index, x, y, _text, unitat, resposta, tipoUnidad, potencia){
    
    
    this["text"+index] = new createjs.RichText();
    if( potencia == null){
        this["text"+index].text = _text + "  =";
    }else{
        this["text"+index].text = _text + "{{sup}}" + potencia + "{{normal}}" + "  =";
    }
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this["text"+index].color = "#0D3158";
    this["text"+index].x = x;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    
    //console.log(this["text"+index].getMeasuredWidth());
    
    this.contenedor.addChild( this["text"+index] );

    this["caja0"+index] = new CajaTexto();
    this["caja0"+index] .contenedor.x = x + this["text"+index].getMeasuredWidth();
    this["caja0"+index] .contenedor.y = y;
    this.posicion = x + this["text"+index].getMeasuredWidth() + 220;
    this.contenedor.addChild( this["caja0"+index].contenedor  );
        
    this["valor"+index] = new createjs.RichText();
    this["valor"+index].text = resposta;
    this["valor"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Verdana" : "16px Verdana" ;
    this["valor"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 18 : 16 ;
    this["valor"+index].color = "#E1001A";
    this["valor"+index].x = 550;
    this["valor"+index].y = y + 90;
    this["valor"+index].textAlign = "right";
    this["valor"+index].alpha = 0;
    
    this.contenedor.addChild( this["valor"+index]  );
    
    this["text1"+index] = new createjs.RichText();
    
    if( potencia == null ){
        this["text1"+index].text = tipoUnidad;
    }else{
        this["text1"+index].text = tipoUnidad + "{{sup}}" + potencia + "{{normal}}";
    }
    this["text1"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "18px Verdana" ;
    this["text1"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 18 ;
    this["text1"+index].color = "#0D3158";
    this["text1"+index].x = x + this["text"+index].getMeasuredWidth() + 270;
    this["text1"+index].y = y + 8;
    this["text1"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text1"+index] );
    

}

function Pagina3( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
    //debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;

    this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
        
    //this.addLine( 0, 110, 190, operacio.pregunta0 + '<sp>' + operacio.potencia +  '<n>' + ' ' + operacio.pregunta1 + '<sp>' + operacio.potencia +  '<n>', operacio.tipoUnidad + '<sp>' + operacio.potencia +  '<n>', operacio.respuestaString );
    this.addLine( 0, 250, 300 - 118, operacio.pregunta, operacio.tipoUnidad, operacio.respuestaString, operacio.potencia, operacio.tipoSexa);
    
    this.correcte1= "";
    this.correcte2= "";
    this.correcte3= "";
    this.respuesta1Str = operacio.respuestaString[0];
    this.respuesta1Num = operacio.respuesta[0];
    this.respuesta2Str = operacio.respuestaString[1];
    this.respuesta2Num = operacio.respuesta[1];
    this.respuesta3Str = operacio.respuestaString[2];
    this.respuesta3Num = operacio.respuesta[2];
    this.compleja = operacio.compleja;
    this.variacion = operacio.variacion;
    
}

Pagina.prototype.getParam = function(){
    Motor.currentPag.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina.prototype.setParam = function(){
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.correcte0);
    Motor["inputDOM0"].element_x = this.posicion - 218;

    $(Motor["inputDOM1"].htmlElement).hide();
    $(Motor["inputDOM2"].htmlElement).hide();
    $(Motor["inputDOM3"].htmlElement).hide();
    $(Motor["inputDOM0"].htmlElement).show();

    var mobil = Main.mobil;
    var index = Main.navegador.split(' ')[0].indexOf("IE");

    if(index > -1 && mobil =="Tablet"){
         //$(Motor["inputDOM0"].htmlElement).focus();
     }
    
};

Pagina.prototype.activa = function(){ 
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    
};

Pagina.prototype.desactiva = function(){ 
    $(Motor["inputDOM0"].htmlElement).css("display","none");
    
};

Pagina.prototype.completado = function(){
    this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina.prototype.isCompletado = function(){
    if( this.correcte0 == ""){
        return false;
    }else{
        return true;
    }
};

Pagina.prototype.isValidado = function(){
    //if( JL.num2str(this.correcte0) != JL.num2str(this.respuesta0Num)){
    if( !JL.esEntryCorrecta( JL.num2str(JL.str2num(this.correcte0)), JL.str2num( this.correctoK ), 0.5 ) ){
        
    //if( JL.str2num(JL.num2str( this.correcte0) ), JL.str2num(JL.num2str( this.correctoK ) ) ){
        this.caja00.error();
        return false;
    }else{
        this.caja00.correct();
        return true;
    }
};

Pagina.prototype.verSolucion = function(){
    //if( JL.str2num(this.correcte0) != this.respuesta0Num){
    //if( !JL.esEntryCorrecta( this.correcte0, this.correctoK ) ){
    if( !JL.esEntryCorrecta( JL.num2str(JL.str2num(this.correcte0)), JL.str2num( this.correctoK ), 0.5 ) ){
        this.valor0.alpha=1;
    }
};

Pagina3.prototype.addLine = function(index, x, y, _text, _text2, valors, potencia, tipoSexa){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text + '  =';
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text"+index].color = "#0D3158";
    this["text"+index].x = x - 20;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja0"+index] = new CajaTexto2();
    this["caja0"+index] .contenedor.x = x + this["text"+index].getMeasuredWidth() - 10;
    this["caja0"+index] .contenedor.y = y;
    this.posicion1 = x + this["text"+index].getMeasuredWidth() - 10;

    this.contenedor.addChild( this["caja0"+index].contenedor  );
      
    this["valor_0_"+index] = new createjs.RichText();
    this["valor_0_"+index].text = valors[0][0].toString();
    this["valor_0_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_0_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_0_"+index].color = "#E1001A";
    this["valor_0_"+index].x = x + this["text"+index].getMeasuredWidth() + 70;
    this["valor_0_"+index].y = y + 60;
    this["valor_0_"+index].alpha = 0;
    this["valor_0_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_0_"+index]  );
    
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = tipoSexa;
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text2"+index].color = "#0D3158";
    this["text2"+index].x = x + this["text"+index].getMeasuredWidth() + 90;
    this["text2"+index].y = y + 8;
    
    this.contenedor.addChild( this["text2"+index]  );
    
    this["caja1"+index] = new CajaTexto2();
    this["caja1"+index] .contenedor.x = x + 100 + this["text"+index].getMeasuredWidth() + 10;
    this["caja1"+index] .contenedor.y = y;
    this.posicion2 = x + 100 + this["text"+index].getMeasuredWidth() + 10;
    
    this.contenedor.addChild( this["caja1"+index].contenedor  );
    
    this["valor_1_"+index] = new createjs.RichText();
    this["valor_1_"+index].text = valors[0][1].toString();
    this["valor_1_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_1_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_1_"+index].color = "#E1001A";
    this["valor_1_"+index].x = x + this["text"+index].getMeasuredWidth() + 190;
    this["valor_1_"+index].y = y + 60;
    this["valor_1_"+index].alpha = 0;
    this["valor_1_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_1_"+index]  );
    
    
    this["text3"+index] = new createjs.RichText();
    this["text3"+index].text = "'";
    this["text3"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text3"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text3"+index].color = "#0D3158";
    this["text3"+index].x = x + this["text"+index].getMeasuredWidth() + 212;
    this["text3"+index].y = y + 8;
    
    this.contenedor.addChild( this["text3"+index]  );
    
    this["caja2"+index] = new CajaTexto2();
    this["caja2"+index] .contenedor.x = x + 220 + this["text"+index].getMeasuredWidth() + 10;
    this["caja2"+index] .contenedor.y = y;
    this.posicion3 = x + 220 + this["text"+index].getMeasuredWidth() + 10;
    
    this.contenedor.addChild( this["caja2"+index].contenedor  );
    
    this["valor_2_"+index] = new createjs.RichText();
    this["valor_2_"+index].text = valors[0][2].toString();
    this["valor_2_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_2_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_2_"+index].color = "#E1001A";
    this["valor_2_"+index].x = x + this["text"+index].getMeasuredWidth() + 310;
    this["valor_2_"+index].y = y + 60;
    this["valor_2_"+index].alpha = 0;
    this["valor_2_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_2_"+index]  );
    
    this["text4"+index] = new createjs.RichText();
    this["text4"+index].text = '"';
    this["text4"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text4"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text4"+index].color = "#0D3158";
    this["text4"+index].x = x + this["text"+index].getMeasuredWidth() + 328;
    this["text4"+index].y = y + 8;
    
    this.contenedor.addChild( this["text4"+index]  );
    
    
};

Pagina3.prototype.getParam = function(){
    Motor.currentPag.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    Motor.currentPag.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    Motor.currentPag.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina3.prototype.completado = function(){
    this.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    this.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    this.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina3.prototype.isCompletado = function(){
    if( this.correcte1 == "" && this.correcte1 == "" && this.correcte3 == ""){
        return false;
    }else{
        return true;
    }
};

Pagina3.prototype.isValidado = function(){
    var valido = true;
    //console.log("correcte1 : " + JL.str2num(this.correcte1) + " respuesta : " + this.respuesta1);
   if( (JL.str2num(this.correcte1) != this.respuesta1Num[0] ) || ( JL.str2num(this.correcte2) != this.respuesta1Num[1] ) || ( JL.str2num(this.correcte3) != this.respuesta1Num[2] ) ){
        valido = false;
        this.caja00.error();
        this.caja10.error();
        this.caja20.error();
    }else{
        this.caja00.correct();
        this.caja10.correct();
        this.caja20.correct();
    }
    
    if( valido ){
        return true;
    }else{
        return false;
    }
    
};

Pagina3.prototype.verSolucion = function(){
    

    //if( (JL.str2num(this.correcte1) != this.respuesta1Num ) || ( JL.str2num(this.correcte2) != this.respuesta2Num ) || ( JL.str2num(this.correcte3) != this.respuesta3Num ) ){
    if( (JL.str2num(this.correcte1) != this.respuesta1Num[0] ) || ( JL.str2num(this.correcte2) != this.respuesta1Num[1] ) || ( JL.str2num(this.correcte3) != this.respuesta1Num[2] ) ){
        this.valor_0_0.alpha=1;
        this.valor_1_0.alpha=1;
        this.valor_2_0.alpha=1;
    }
};

Pagina3.prototype.setParam = function(){
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.correcte1);
    $(Motor.inputDOM2.htmlElement).val(Motor.currentPag.correcte2);
    $(Motor.inputDOM3.htmlElement).val(Motor.currentPag.correcte3);
    Motor["inputDOM1"].element_x = this.posicion1 + 5;
    Motor["inputDOM2"].element_x = this.posicion2 + 5;
    Motor["inputDOM3"].element_x = this.posicion3 + 5;
    $(Motor["inputDOM1"].htmlElement).show();
    $(Motor["inputDOM2"].htmlElement).show();
    $(Motor["inputDOM3"].htmlElement).show();
    $(Motor["inputDOM0"].htmlElement).hide();

    var mobil = Main.mobil
    var index = Main.navegador.split(' ')[0].indexOf("IE");

    if(index > -1 && mobil =="Tablet"){
         //$(Motor["inputDOM1"].htmlElement).focus();
     }

};

Pagina3.prototype.activa = function(){
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    $(Motor["inputDOM2"].htmlElement).css("display","inline");
    $(Motor["inputDOM3"].htmlElement).css("display","inline");
};

Pagina3.prototype.desactiva = function(){
    $(Motor["inputDOM1"].htmlElement).css("display","none");
    $(Motor["inputDOM2"].htmlElement).css("display","none");
    $(Motor["inputDOM3"].htmlElement).css("display","none");
};

function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 245, 40, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 245, 40, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}

function CajaTexto2()
{
    this.contenedor = new createjs.Container();
    this.area = new createjs.Container();
    
    this.fons = new createjs.Shape();
    this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 90, 40, 10);
    
    this.marc = new createjs.Shape();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);

    this.area.addChild( this.fons );
    this.area.addChild( this.marc );
    
    this.contenedor.addChild( this.area );
}


CajaTexto2.prototype.clear = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);
}
CajaTexto2.prototype.error = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}

CajaTexto2.prototype.correct = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 245, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 245, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 245, 40, 10);
}
