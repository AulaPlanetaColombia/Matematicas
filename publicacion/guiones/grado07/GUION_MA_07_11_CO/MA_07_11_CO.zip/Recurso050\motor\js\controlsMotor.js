function Pagina( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
	//debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
	this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
	this.enunciat.color = "#0D3158";
	this.enunciat.x = 15;
	this.enunciat.y = -60;
	this.enunciat.lineWidth = 900;
	this.enunciat.lineHeight = 22;
	this.enunciat.mouseEnabled = false;

	this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
    
    
    //this.subEnunciado(operacio);
    
    this.addLine( 0, 110, 190, operacio.pregunta0 + '{{sup}}' + operacio.potencia +  '{{normal}}' + ' ' + operacio.pregunta1 + '{{sup}}' + operacio.potencia +  '{{normal}}', operacio.tipoUnidad + '{{sup}}' + operacio.potencia +  '{{sup}}', operacio.respuestaString );
    
   
    
   	//this.addLine( operacio  );
   	 

	//this.valorNum = operacio.respuestaNum; 
	//this.valorStr = operacio.respuestaString; 

	this.correcte0= "";
	this.respuesta0Str = operacio.respuestaString;
	this.respuesta0Num = operacio.respuesta;
	
	this.variacion = operacio.variacion;
	
}

function Pagina3( pregunta, _numpagina, operacio) {

    this.numpagina  = _numpagina;
    //console.log(pregunta);
    this.idPregunta = _numpagina;
    //debugger;
    this.enunciat = new createjs.RichText();
    this.enunciat.text = pregunta.enunciado;
    
    this.enunciat.font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Arial" : "17px Arial" ;
    this.enunciat.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 17 ;
    this.enunciat.color = "#0D3158";
    this.enunciat.x = 15;
    this.enunciat.y = -60;
    this.enunciat.lineWidth = 900;
    this.enunciat.lineHeight = 22;
    this.enunciat.mouseEnabled = false;

    this.validacio = "";
    this.contenedor = new createjs.Container();
    this.contenedor.addChild( this.enunciat );
        
    this.addLine( 0, 110, 190, operacio.pregunta0 + '{{sup}}' + operacio.potencia +  '{{normal}}' + ' ' + operacio.pregunta1 + '{{sup}}' + operacio.potencia +  '{{normal}}', operacio.tipoUnidad + '{{sup}}' + operacio.potencia +  '{{normal}}', operacio.respuestaString );
    
    this.correcte1= "";
    this.correcte2= "";
    this.correcte3= "";
    this.respuesta1Str = operacio.respuestaString[0];
    this.respuesta1Num = operacio.respuesta[0];
    this.respuesta2Str = operacio.respuestaString[1];
    this.respuesta2Num = operacio.respuesta[1];
    this.respuesta3Str = operacio.respuestaString[2];
    this.respuesta3Num = operacio.respuesta[2];
    
    this.variacion = operacio.variacion;
    
}

Pagina.prototype.addLine = function(index, x, y, _text, _text2, valors){
	
	this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text + '  =';
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text"+index].color = "#0D3158";
    this["text"+index].x = x - 20;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja0"+index] = new CajaTexto();
    this["caja0"+index] .contenedor.x = x + this["text"+index].getMeasuredWidth() - 10;
    this["caja0"+index] .contenedor.y = y;

    this.contenedor.addChild( this["caja0"+index].contenedor  );
      
    this["valor_1_"+index] = new createjs.RichText();
    this["valor_1_"+index].text = valors.toString();
    this["valor_1_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_1_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_1_"+index].color = "#E1001A";
    this["valor_1_"+index].x = x + this["text"+index].getMeasuredWidth() + 220;
    this["valor_1_"+index].y = y + 60;
    this["valor_1_"+index].alpha = 0;
    this["valor_1_"+index].textAlign = "right";
    this.posicion = x + this["text"+index].getMeasuredWidth() + 220;
    
    this.contenedor.addChild( this["valor_1_"+index]  );
    
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = _text2.toString();
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text2"+index].color = "#0D3158";
    this["text2"+index].x = x + this["text"+index].getMeasuredWidth() + 250;
    this["text2"+index].y = y + 8;
    
    this.contenedor.addChild( this["text2"+index]  );
}


Pagina.prototype.getParam = function(){
    Motor.currentPag.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina.prototype.setParam = function(){
    $(Motor.inputDOM0.htmlElement).val(Motor.currentPag.correcte0);
    Motor["inputDOM0"].element_x = this.posicion - 218;

    $(Motor["inputDOM1"].htmlElement).hide();
    $(Motor["inputDOM2"].htmlElement).hide();
    $(Motor["inputDOM3"].htmlElement).hide();
    $(Motor["inputDOM0"].htmlElement).show();

    var mobil = Main.mobil;
    var index = Main.navegador.split(' ')[0].indexOf("IE");

    if(index > -1 && mobil =="Tablet"){
         //$(Motor["inputDOM0"].htmlElement).focus();
     }
    
};

Pagina.prototype.activa = function(){ 
    $(Motor["inputDOM0"].htmlElement).css("display","inline");
    
};

Pagina.prototype.desactiva = function(){ 
    $(Motor["inputDOM0"].htmlElement).css("display","none");
    
};

Pagina.prototype.completado = function(){
    this.correcte0 = $(Motor.inputDOM0.htmlElement).val();
};

Pagina.prototype.isCompletado = function(){
    if( this.correcte0 == ""){
        return false;
    }else{
        return true;
    }
};

Pagina.prototype.isValidado = function(){
    console.log(JL.esEntryCorrecta( JL.num2str(this.correcte0), JL.num2str(this.respuesta0Num )));
    //if( JL.num2str(this.correcte0) != JL.num2str(this.respuesta0Num)){
    if( !JL.esEntryCorrecta( this.correcte0, this.respuesta0Num ) ){
        this.caja00.error();
        return false;
    }else{
        this.caja00.correct();
        return true;
    }
};

Pagina.prototype.verSolucion = function(){
    //if( JL.str2num(this.correcte0) != this.respuesta0Num){
    if( !JL.esEntryCorrecta( this.correcte0, this.respuesta0Num ) ){
        this.valor_1_0.alpha=1;
    }
};

Pagina3.prototype.addLine = function(index, x, y, _text, _text2, valors){
    
    this["text"+index] = new createjs.RichText();
    this["text"+index].text = _text + '  =';
    this["text"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text"+index].color = "#0D3158";
    this["text"+index].x = x - 20;
    this["text"+index].y = y + 8;
    this["text"+index].textAlign = "left";
    
    this.contenedor.addChild( this["text"+index]  );
    
    this["caja0"+index] = new CajaTexto2();
    this["caja0"+index] .contenedor.x = x + this["text"+index].getMeasuredWidth() - 10;
    this["caja0"+index] .contenedor.y = y;
    this.posicion1 = x + this["text"+index].getMeasuredWidth() - 10;

    this.contenedor.addChild( this["caja0"+index].contenedor  );
      
    this["valor_0_"+index] = new createjs.RichText();
    this["valor_0_"+index].text = valors[0].toString();
    this["valor_0_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_0_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_0_"+index].color = "#E1001A";
    this["valor_0_"+index].x = x + this["text"+index].getMeasuredWidth() + 70;
    this["valor_0_"+index].y = y + 60;
    this["valor_0_"+index].alpha = 0;
    this["valor_0_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_0_"+index]  );
    
    this["text2"+index] = new createjs.RichText();
    this["text2"+index].text = _text2.toString();
    this["text2"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text2"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text2"+index].color = "#0D3158";
    this["text2"+index].x = x + this["text"+index].getMeasuredWidth() + 90;
    this["text2"+index].y = y + 8;
    
    this.contenedor.addChild( this["text2"+index]  );
    
    this["caja1"+index] = new CajaTexto2();
    this["caja1"+index] .contenedor.x = x + 100 + this["text"+index].getMeasuredWidth() + 10;
    this["caja1"+index] .contenedor.y = y;
    this.posicion2 = x + 100 + this["text"+index].getMeasuredWidth() + 10;
    
    this.contenedor.addChild( this["caja1"+index].contenedor  );
    
    this["valor_1_"+index] = new createjs.RichText();
    this["valor_1_"+index].text = valors[1].toString();
    this["valor_1_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_1_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_1_"+index].color = "#E1001A";
    this["valor_1_"+index].x = x + this["text"+index].getMeasuredWidth() + 190;
    this["valor_1_"+index].y = y + 60;
    this["valor_1_"+index].alpha = 0;
    this["valor_1_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_1_"+index]  );
    
    
    this["text3"+index] = new createjs.RichText();
    this["text3"+index].text = "'";
    this["text3"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text3"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text3"+index].color = "#0D3158";
    this["text3"+index].x = x + this["text"+index].getMeasuredWidth() + 212;
    this["text3"+index].y = y + 8;
    
    this.contenedor.addChild( this["text3"+index]  );
    
    this["caja2"+index] = new CajaTexto2();
    this["caja2"+index] .contenedor.x = x + 220 + this["text"+index].getMeasuredWidth() + 10;
    this["caja2"+index] .contenedor.y = y;
    this.posicion3 = x + 220 + this["text"+index].getMeasuredWidth() + 10;
    
    this.contenedor.addChild( this["caja2"+index].contenedor  );
    
    this["valor_2_"+index] = new createjs.RichText();
    this["valor_2_"+index].text = valors[2].toString();
    this["valor_2_"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "19px Verdana" : "16px Verdana" ;
    this["valor_2_"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 19 : 16 ;
    this["valor_2_"+index].color = "#E1001A";
    this["valor_2_"+index].x = x + this["text"+index].getMeasuredWidth() + 310;
    this["valor_2_"+index].y = y + 60;
    this["valor_2_"+index].alpha = 0;
    this["valor_2_"+index].textAlign = "right";
    
    this.contenedor.addChild( this["valor_2_"+index]  );
    
    this["text4"+index] = new createjs.RichText();
    this["text4"+index].text = '"';
    this["text4"+index].font = (Contenedor.datosXML.plataforma.grado == 1)? "21px Verdana" : "19px Verdana" ;
    this["text4"+index].fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 21 : 19 ;
    this["text4"+index].color = "#0D3158";
    this["text4"+index].x = x + this["text"+index].getMeasuredWidth() + 328;
    this["text4"+index].y = y + 8;
    
    this.contenedor.addChild( this["text4"+index]  );
    
    
};

Pagina3.prototype.getParam = function(){
    Motor.currentPag.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    Motor.currentPag.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    Motor.currentPag.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina3.prototype.completado = function(){
    this.correcte1 = $(Motor.inputDOM1.htmlElement).val();
    this.correcte2 = $(Motor.inputDOM2.htmlElement).val();
    this.correcte3 = $(Motor.inputDOM3.htmlElement).val();
};

Pagina3.prototype.isCompletado = function(){
    if( this.correcte1 == "" && this.correcte1 == "" && this.correcte3 == ""){
        return false;
    }else{
        return true;
    }
};

Pagina3.prototype.isValidado = function(){
    var valido = true;
    //console.log("correcte1 : " + JL.str2num(this.correcte1) + " respuesta : " + this.respuesta1);
   if( (JL.str2num(this.correcte1) != this.respuesta1Num ) || ( JL.str2num(this.correcte2) != this.respuesta2Num ) || ( JL.str2num(this.correcte3) != this.respuesta3Num ) ){
        valido = false;
        this.caja00.error();
        this.caja10.error();
        this.caja20.error();
    }else{
        this.caja00.correct();
        this.caja10.correct();
        this.caja20.correct();
    }
    
    if( valido ){
        return true;
    }else{
        return false;
    }
    
};

Pagina3.prototype.verSolucion = function(){
    

    if( (JL.str2num(this.correcte1) != this.respuesta1Num ) || ( JL.str2num(this.correcte2) != this.respuesta2Num ) || ( JL.str2num(this.correcte3) != this.respuesta3Num ) ){
        this.valor_0_0.alpha=1;
        this.valor_1_0.alpha=1;
        this.valor_2_0.alpha=1;
    }
};

Pagina3.prototype.setParam = function(){
    $(Motor.inputDOM1.htmlElement).val(Motor.currentPag.correcte1);
    $(Motor.inputDOM2.htmlElement).val(Motor.currentPag.correcte2);
    $(Motor.inputDOM3.htmlElement).val(Motor.currentPag.correcte3);
    Motor["inputDOM1"].element_x = this.posicion1 + 5;
    Motor["inputDOM2"].element_x = this.posicion2 + 5;
    Motor["inputDOM3"].element_x = this.posicion3 + 5;
    $(Motor["inputDOM1"].htmlElement).show();
    $(Motor["inputDOM2"].htmlElement).show();
    $(Motor["inputDOM3"].htmlElement).show();
    $(Motor["inputDOM0"].htmlElement).hide();

    var mobil = Main.mobil
    var index = Main.navegador.split(' ')[0].indexOf("IE");

    if(index > -1 && mobil =="Tablet"){
         //$(Motor["inputDOM1"].htmlElement).focus();
     }

};

Pagina3.prototype.activa = function(){
    $(Motor["inputDOM1"].htmlElement).css("display","inline");
    $(Motor["inputDOM2"].htmlElement).css("display","inline");
    $(Motor["inputDOM3"].htmlElement).css("display","inline");
};

Pagina3.prototype.desactiva = function(){
    $(Motor["inputDOM1"].htmlElement).css("display","none");
    $(Motor["inputDOM2"].htmlElement).css("display","none");
    $(Motor["inputDOM3"].htmlElement).css("display","none");
};

function CajaTexto()
{
	this.contenedor = new createjs.Container();
	this.area = new createjs.Container();
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 245, 40, 10);
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 245, 40, 10);

	this.area.addChild( this.fons );
	this.area.addChild( this.marc );
	
	this.contenedor.addChild( this.area );
}

function CajaTexto2()
{
    this.contenedor = new createjs.Container();
    this.area = new createjs.Container();
    
    this.fons = new createjs.Shape();
    this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, 90, 40, 10);
    
    this.marc = new createjs.Shape();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);

    this.area.addChild( this.fons );
    this.area.addChild( this.marc );
    
    this.contenedor.addChild( this.area );
}


CajaTexto2.prototype.clear = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 90, 40, 10);
}
CajaTexto2.prototype.error = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}

CajaTexto2.prototype.correct = function()
{
    this.marc.graphics.clear();
    this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 90, 40, 10);
}


CajaTexto.prototype.clear = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 245, 40, 10);
}
CajaTexto.prototype.error = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(0, 0, 245, 40, 10);
}

CajaTexto.prototype.correct = function()
{
	this.marc.graphics.clear();
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(0, 0, 245, 40, 10);
}
