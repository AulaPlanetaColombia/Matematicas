(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
      basicos(this, 0,0,1,0,0,0);
        titulo1(this,txt['titulo']);
	this.btn1 = new lib.IMG_01();
	this.btn1.setTransform(487.1,338,1,1,0,0,0,250,250);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.IMG_01(), 3);
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
       this.btn1.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior,this.home,this.informacion,this.cerrar,this.btn1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0);
      	this.txt_01_01 = new cjs.Text(txt['txt_01_01'], "20px Verdana");
	this.txt_01_01.lineHeight = 26;
	this.txt_01_01.lineWidth = 366;
	this.txt_01_01.setTransform(81.5,133.9);

	this.instance = new lib._2Shutterstock_96062198_OPT();
	this.instance.setTransform(507.8,127.4);

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente,this.instance,this.txt_01_01);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       	// Capa 1
	this.instance = new lib.textoAnimado_01();
	this.instance.setTransform(475.5,343.6,1,1,0,0,0,231.5,155.6);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.instance, this.home, this.anterior, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       this.txt_03_01 = new cjs.Text("La bajada de bandera de un taxi cuesta 2,80 euros y cada kilÃ³metro recorrido cuesta 50 cÃ©ntimos. Â¿CÃ³mo expresarÃ­as el importe de un trayecto de x kilÃ³metros?\n\nMediante una expresiÃ³n algebraica.\n\n\n\n ", "20px Verdana");
	this.txt_03_01.lineHeight = 20;
	this.txt_03_01.lineWidth = 397;
	this.txt_03_01.setTransform(81.5,133.9);
 var html = createDiv(txt['txt_03_01'], "Verdana", "20px", '400px', '40px', "20px", "185px", "left");
    this.txt_03_01 = new cjs.DOMElement(html);
    this.txt_03_01.setTransform(90, 134-608);
	this.instance = new lib.IMG_03();
	this.instance.setTransform(850.4,329.7,1,1,0,0,0,301,200.7);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance,this.txt_03_01);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       	this.instance = new lib.textoAnimado_02();
	this.instance.setTransform(475.9,313.1,1,1,0,0,0,394.4,179.2);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
       this.txt_05_01 = new cjs.Text("Si en una expresiÃ³n algebraica sustituimos cada variable por un nÃºmero, obtenemos el valor numÃ©rico que queremos conocer.\n\nÂ¿CuÃ¡l dirÃ­as que es el valor numÃ©rico de x2 + 2xy â€“ y + 3 para x = 1 e y = 2?\n ", "20px Verdana");
	this.txt_05_01.lineHeight = 20;
	this.txt_05_01.lineWidth = 826;
	this.txt_05_01.setTransform(81.5,133.9);
 var html = createDiv(txt['txt_05_01'], "Verdana", "20px", '820px', '40px', "20px", "185px", "left");
    this.txt_05_01 = new cjs.DOMElement(html);
    this.txt_05_01.setTransform(90, 134-608);
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.txt_05_01);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
      	this.grafico = new lib.txtAnimado_03();
	this.grafico.setTransform(423.4,275,1,1,0,0,0,342.9,143.1);


        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
  this.practica = new lib.btn_practica(txt['btnpractica']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame9());
    });
        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente,this.informacion,this.practica,this.grafico);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        texto(this, txt['txt_info'],0,-40);

        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });

        this.addChild(this.logo, this.texto, this.cerrar, this.anterior, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        titulo2(this, txt['txt_practica_01']);
this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape.setTransform(474.5,394);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape_1.setTransform(474.5,335);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape_2.setTransform(474.5,276);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAA06MAAAAp1");
	this.shape_3.setTransform(583,335,1,0.878);

	this.txt_practica_02 = new cjs.Text(txt['txt_practica_02'], "20px Verdana");
	this.txt_practica_02.lineHeight = 30;
	this.txt_practica_02.lineWidth = 467;
	this.txt_practica_02.setTransform(108,232.9+incremento);
//  var html = createDiv(txt['txt_practica_02'], "Verdana", "20px", '470px', '40px', "20px", "185px", "left");
//    this.txt_practica_02 = new cjs.DOMElement(html);
//    this.txt_practica_02.setTransform(108, 233-608);
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).rr(-393.5,-134,787,268,10);
	this.shape_4.setTransform(474.5,335,1,0.881);
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
 this.practica = new lib.btn_practica(txt['btnsolucion']);
        this.practica.setTransform(837, 565, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);
        this.practica.on("click", function (evt) {
        putStage(new lib.frame10());
    });
        this.addChild(this.logo, this.titulo, this.cerrar, this.practica, this.siguiente,this.shape_4,this.txt_practica_02,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  (lib.frame10 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 1, 0, 0, 1);
      this.txt_practica_02 = new cjs.Text(txt['txt_practica_02'], "20px Verdana");
	this.txt_practica_02.lineHeight = 30;
	this.txt_practica_02.lineWidth = 467;
	this.txt_practica_02.setTransform(108,232.9+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape.setTransform(474.5,394);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape_1.setTransform(474.5,335);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("Eg9dAAAMB67AAA");
	this.shape_2.setTransform(474.5,276);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("AAA06MAAAAp1");
	this.shape_3.setTransform(583,335,1,0.878);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).rr(-393.5,-134,787,268,10);
	this.shape_4.setTransform(474.5,335,1,0.881);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FF6600").ss(1,1,1).p("AlOAAIKdAA");
	this.shape_5.setTransform(733.5,306);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FF6600").ss(1,1,1).p("AhpAAIDTAA");
	this.shape_6.setTransform(760.3,421.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF6600").s().p("ADNP8IAAgUIAVgSIATgRQATgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWAUIgUASIBOAAIAAAQgAlxNjQgMgCgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgCAFgEQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgHAAIgJAAIAAgQIAHAAQAPAAAJgGQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAGAEQAHAFAEAGQADAHAAAJQAAAMgIAJQgJAJgLACIAAACIAKADQAGADAFADQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAGQgIAHgKADQgKADgLAAQgMAAgMgDgAjHNjIgWgpIgpApIgWAAIA4g3Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA2gAgPNhIAAg2Ig1AAIAAgPIA1AAIAAg1IAPAAIAAA1IA0AAIAAAPIg0AAIAAA2gAERLhIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gADvFHIAAAAQAHgHAIgKQAHgKAGgMQAGgMAEgOQADgOAAgRQAAgQgDgOQgEgPgGgMQgGgMgHgJQgHgKgIgHIAAgBIAWAAQARAUAKAYQAJAXAAAdQAAAegJAXQgKAYgRATgABvFHIAgguIgUhnIATAAIAQBRIA0hRIAUAAIhjCVgAk7FHQgRgTgKgYQgKgXAAgeQAAgdAKgXQAKgYARgUIAWAAIAAABQgIAHgHAKQgHAJgGAMQgGAMgEAPQgDAOAAAQQAAARADAOQAEAOAGAMQAGAMAHAKQAIAKAHAHIAAAAgAjHEfIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAhKDnIAAgPIBfAAIAAAPgAFFDZIAAgOIAOgLIAMgLQAMgMAFgHQAFgHAAgIQAAgHgFgFQgFgEgJAAQgGAAgGACQgHACgHAEIAAAAIAAgNQAEgCAIgCQAHgCAHAAQAPAAAIAHQAIAHAAAMIgBAKIgEAJIgGAIIgIAIIgOANIgNAMIAyAAIAAALgAgxiAIAAgUIAVgSIATgRQARgSAHgLQAHgLAAgMQAAgLgIgHQgHgGgLAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAUAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgUAUIgUASIBMAAIAAAQgACblzIAfguIgThnIATAAIAPBRIA0hRIAUAAIhiCVgAjAmbIgXgpIgoApIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg4A3IAfA2gAgEmdIAAg2Ig2AAIAAgPIA2AAIAAg1IAOAAIAAA1IA1AAIAAAPIg1AAIAAA2gADRtmQgLgDgHgDIAAgVIABAAQAIAFALAEQAKADALAAQAHAAAGgCQAHgCAFgEQAEgFACgFQACgGAAgIQAAgIgCgFQgDgFgEgDQgFgEgIgBQgHgCgJAAIgQABIgOADIAAhLIBXAAIAAARIhEAAIAAAnIAIgBIAIAAQAMAAAJACQAIACAIAFQAIAFAEAJQAEAIAAANQAAAKgDAJQgEAKgHAGQgHAHgJAEQgKADgNAAQgMAAgLgCgAiqtnIgWgpIgpApIgWAAIA4g3Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA2gAlotnIAAgUIAVgSIATgRQASgSAHgLQAHgLAAgMQAAgLgHgHQgIgGgNAAQgJAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAIgCAHQgCAIgEAGQgEAGgFAGIgMANIgWAUIgVASIBOAAIAAAQgAAMtpIAAg2IgzAAIAAgPIAzAAIAAg1IAQAAIAAA1IA1AAIAAAPIg1AAIAAA2g");
	this.shape_7.setTransform(733.7,340.2);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame9());
        });
       this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });

        this.addChild(this.logo, this.titulo, this.cerrar, this.anterior, this.siguiente,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.txt_practica_02);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame11 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo2(this, txt['titulo']);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   function basicos(escena, home, anterior, siguiente, informacion, cerrar,audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteneg();
            escena.siguiente.setTransform(170, 568,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 550,1.15,1.15);
        else
            escena.informacion.setTransform(217, 550,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
  
   //Simbolillos
   (lib._1_shutterstock_84650017_OPT = function() {
	this.initialize(img._1_shutterstock_84650017_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,450,450);


(lib._2Shutterstock_96062198_OPT = function() {
	this.initialize(img._2Shutterstock_96062198_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,400,400);


(lib._3Thinkstock_87704505_OPT = function() {
	this.initialize(img._3Thinkstock_87704505_OPT);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,600,400);


(lib.Mapadebits26 = function() {
	this.initialize(img.Mapadebits26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1256,958);


(lib.Mapadebits27 = function() {
	this.initialize(img.Mapadebits27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1256,958);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.txtAnimado_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("As6FaIAggvIgUhmIATAAIAQBRIAzhRIAVAAIhjCVgAmJEyIAAgUIAVgSIATgRQASgTAIgKQAGgLABgNQAAgLgIgGQgHgHgOAAQgIABgLADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQANAKAAASQAAAJgCAHQgDAIgEAFQgEAHgEAGIgNAMIgWAUIgUASIBNAAIAAARgAprEOIAAgPIB0AAIAAAPgAprDmIAAgQIB0AAIAAAQgAl9A/IAAgPIAeAAIAAhfIgeAAIAAgOIANgBQAIAAADgCQAFgDACgEQACgDABgHIAPAAIAACBIAeAAIAAAPgArwA/IgXgqIgoAqIgXAAIA4g3Igeg0IAUAAIAXAqIAogqIAXAAIg3A1IAeA2gApqAbIAAgPIBzAAIAAAPgApqgLIAAgQIBzAAIAAAQgAE1iKIAfgvIgThmIATAAIAQBRIA0hRIAUAAIhjCVgAhLiKIAfgvIgThmIATAAIAPBRIAzhRIATAAIhgCVgAL6iyQgLgDgIgDIAAgVIABAAQAJAGALADQALAEALAAQAGAAAGgCQAIgCAEgEQAEgEACgFQACgGAAgIQAAgHgCgFQgDgGgEgCQgEgDgHgCQgFgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgGAAgMQAAgGgCgDQgDgEgEgDIgJgDIgKgCQgKAAgKAEQgKADgKAGIgBAAIAAgUIASgGQAMgDALAAQAKAAAIACQAJACAHAEQAGAFAEAGQAEAHgBAIQAAANgIAJQgJAJgLACIAAABIAKAEQAHADAEADQAEAEADAGQADAHABAKQAAAKgEAIQgEAIgGAHQgHAGgLAEQgKADgLAAQgMAAgMgDgAh3iyIgXgqIgoAqIgXAAIA4g3Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA2gAk2iyIAAgUIAVgSIATgRQASgTAHgKQAIgLAAgNQAAgLgIgGQgHgHgNAAQgJABgLADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAASQABAJgCAHQgCAIgFAFQgEAHgFAGIgMAMIgWAUIgVASIBPAAIAAARgArwiyIgXgqIgoAqIgXAAIA4g3Igeg2IAUAAIAXAqIAogqIAXAAIg3A3IAeA2gAI2i0IAAg2Ig1AAIAAgQIA1AAIAAg1IAQAAIAAA1IA1AAIAAAQIg1AAIAAA2gAnmi0IAAg2Ig1AAIAAgQIA1AAIAAg1IAQAAIAAA1IA2AAIAAAQIg2AAIAAA2gAB6jqIAAgQIBhAAIAAAQgAq/j5IAAgNIAOgLIAMgMQANgLAEgIQAFgGAAgJQAAgGgFgFQgFgEgJAAQgFAAgHACQgHACgHAEIAAAAIAAgNQAFgDAHgBQAIgCAGAAQAPAAAJAHQAHAHABAMIgBAKIgFAJIgFAHIgIAJIgPANIgNALIAyAAIAAALg");
	this.shape.setTransform(86.3,40.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AtAFaIAggvIgUhmIATAAIAQBRIA0hRIAUAAIhjCVgAmPEyIAAgUIAVgSIATgRQATgTAHgKQAHgLAAgNQAAgLgIgGQgHgHgNAAQgJABgLADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAWAAANALQANAKAAASQAAAJgCAHQgCAIgFAFQgDAHgFAGIgNAMIgWAUIgUASIBOAAIAAARgApwEOIAAgPIBzAAIAAAPgApwDmIAAgQIBzAAIAAAQgAEviKIAggvIgUhmIATAAIAQBRIA0hRIAUAAIhjCVgAhRiKIAggvIgUhmIATAAIAQBRIAyhRIAUAAIhhCVgAL0iyQgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgEACgFQACgGAAgIQAAgHgDgFQgCgGgEgCQgFgDgGgCQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgGAAgMQAAgGgCgDQgCgEgEgDIgJgDIgLgCQgKAAgKAEQgKADgKAGIgBAAIAAgUIATgGQALgDALAAQALAAAIACQAIACAHAEQAHAFADAGQAEAHAAAIQAAANgJAJQgIAJgMACIAAABIALAEQAGADAEADQAFAEADAGQADAHAAAKQAAAKgEAIQgDAIgHAHQgHAGgKAEQgKADgMAAQgMAAgMgDgAk8iyIAAgUIAVgSIATgRQATgTAHgKQAHgLAAgNQAAgLgIgGQgHgHgNAAQgJABgLADQgKADgKAGIgBAAIAAgUQAHgEAMgCQALgDALAAQAWAAANALQANAKAAASQAAAJgCAHQgCAIgFAFQgDAHgFAGIgNAMIgWAUIgUASIBOAAIAAARgAIwi0IAAg2Ig1AAIAAgQIA1AAIAAg1IARAAIAAA1IA1AAIAAAQIg1AAIAAA2gAnsi0IAAg2Ig1AAIAAgQIA1AAIAAg1IARAAIAAA1IA1AAIAAAQIg1AAIAAA2gAB0jqIAAgQIBhAAIAAAQgArEj5IAAgNIANgLIANgMQAMgLAEgIQAFgGAAgJQAAgGgFgFQgFgEgIAAQgGAAgHACQgHACgGAEIgBAAIAAgNQAFgDAHgBQAIgCAHAAQAOAAAJAHQAIAHAAAMIgBAKIgEAJIgGAHIgIAJIgOANIgOALIAzAAIAAALg");
	this.shape_1.setTransform(86.8,40.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0000").s().p("ABKCwIAAgPIAeAAIAAhiIgeAAIAAgNIANgBQAIgBADgCQAFgDACgDQACgEABgHIAPAAIAACEIAeAAIAAAPgAknCwIgXgqIgoAqIgXAAIA4g4Igeg2IAUAAIAXAqIAogqIAXAAIg3A4IAeA2gAihCMIAAgPIBzAAIAAAPgAihBjIAAgQIBzAAIAAAQgAFQhBIgXgqIgoAqIgXAAIA4g4Igfg2IAVAAIAWAqIApgqIAXAAIg4A4IAeA2gAknhBIgXgqIgoAqIgXAAIA4g4Igeg2IAUAAIAXAqIAogqIAXAAIg3A4IAeA2g");
	this.shape_2.setTransform(40.6,28.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0033CC").s().p("ApyE9IAfgvIgThmIATAAIAPBRIA0hRIAUAAIhiCVgAjBEVIAAgUIAVgSIATgRQASgTAHgKQAHgLAAgNQAAgLgHgGQgIgHgNAAQgJABgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAASQAAAJgCAHQgCAIgEAFQgEAHgFAGIgMAMIgWAUIgVASIBOAAIAAARgAmjDxIAAgPIB0AAIAAAPgAmjDJIAAgQIB0AAIAAAQgAH9inIAfgvIgThmIATAAIAPBRIA0hRIAUAAIhiCVgAB7inIAfgvIgThmIATAAIAPBRIA0hRIAUAAIhiCVg");
	this.shape_3.setTransform(66.3,43);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AK3BSQgMgDgIgDIAAgVIACAAQAIAGAMADQALADAKAAQAGAAAHgBQAHgDAFgEQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgBgIAAIgIAAIAAgOIAHAAQAOAAAKgHQAIgGABgMQAAgFgDgEQgCgEgEgDIgJgDIgLgBQgKAAgKADQgKAEgKAFIAAAAIAAgUIASgGQAMgDAKAAQALAAAIACQAJACAGAEQAHAFADAGQAEAHAAAJQAAAMgIAJQgJAJgLABIAAABIAKADQAGADAFAEQAEAEADAGQADAHAAAKQAAAKgDAIQgEAIgGAGQgIAHgKAEQgKADgMAAQgMAAgLgDgAl6BSIAAgVIAWgSIATgRQASgSAHgJQAHgLAAgMQAAgLgIgGQgHgHgNAAQgJAAgLADQgKADgJAGIgBAAIAAgUQAGgEAMgCQALgDALAAQAXAAAMALQANALAAASQAAAJgCAGQgCAIgEAEQgEAHgFAFIgNANIgVAUIgVASIBOAAIAAARgAHzBPIAAg2Ig1AAIAAgPIA1AAIAAgzIAQAAIAAAzIA1AAIAAAPIg1AAIAAA2gAopBPIAAg2Ig1AAIAAgPIA1AAIAAgzIAQAAIAAAzIA1AAIAAAPIg1AAIAAA2gAA2AZIAAgPIBhAAIAAAPgAsCALIAAgMIANgLIANgLQAMgMAEgHQAGgHAAgIQAAgHgGgEQgEgFgJAAQgGAAgHACQgGADgHADIAAAAIAAgMQAEgDAHgCQAIgCAHABQAOgBAJAIQAIAGAAANIgBAKIgEAIIgGAIIgIAJIgOAMIgOAKIAzAAIAAALg");
	this.shape_4.setTransform(93,13.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_1}]},18).to({state:[{t:this.shape_2},{t:this.shape_4},{t:this.shape_3}]},81).wait(126));

	// Capa 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_35 = new cjs.Graphics().p("AiBKyIAAlUID5AAIAAFUg");
	var mask_graphics_36 = new cjs.Graphics().p("AiICpIAAlRIERAAIAAFRg");
	var mask_graphics_37 = new cjs.Graphics().p("AiVCpIAAlRIErAAIAAFRg");
	var mask_graphics_38 = new cjs.Graphics().p("AiiCpIAAlRIFFAAIAAFRg");
	var mask_graphics_39 = new cjs.Graphics().p("AiuCpIAAlRIFdAAIAAFRg");
	var mask_graphics_40 = new cjs.Graphics().p("Ai7CpIAAlRIF3AAIAAFRg");
	var mask_graphics_41 = new cjs.Graphics().p("AjICpIAAlRIGRAAIAAFRg");
	var mask_graphics_42 = new cjs.Graphics().p("AjVCpIAAlRIGrAAIAAFRg");
	var mask_graphics_43 = new cjs.Graphics().p("AjhCpIAAlRIHDAAIAAFRg");
	var mask_graphics_44 = new cjs.Graphics().p("AjuCpIAAlRIHdAAIAAFRg");
	var mask_graphics_45 = new cjs.Graphics().p("Aj7CpIAAlRIH3AAIAAFRg");
	var mask_graphics_46 = new cjs.Graphics().p("AkICpIAAlRIIRAAIAAFRg");
	var mask_graphics_47 = new cjs.Graphics().p("AkUCpIAAlRIIpAAIAAFRg");
	var mask_graphics_48 = new cjs.Graphics().p("AkhCpIAAlRIJDAAIAAFRg");
	var mask_graphics_49 = new cjs.Graphics().p("AkuCpIAAlRIJdAAIAAFRg");
	var mask_graphics_50 = new cjs.Graphics().p("Ak6CpIAAlRIJ1AAIAAFRg");
	var mask_graphics_51 = new cjs.Graphics().p("AlHCpIAAlRIKPAAIAAFRg");
	var mask_graphics_52 = new cjs.Graphics().p("AlUCpIAAlRIKpAAIAAFRg");
	var mask_graphics_53 = new cjs.Graphics().p("AlhCpIAAlRILDAAIAAFRg");
	var mask_graphics_54 = new cjs.Graphics().p("AltCpIAAlRILbAAIAAFRg");
	var mask_graphics_55 = new cjs.Graphics().p("Al6CpIAAlRIL1AAIAAFRg");
	var mask_graphics_56 = new cjs.Graphics().p("AmHCpIAAlRIMPAAIAAFRg");
	var mask_graphics_57 = new cjs.Graphics().p("AmUCpIAAlRIMpAAIAAFRg");
	var mask_graphics_58 = new cjs.Graphics().p("AmgCpIAAlRINBAAIAAFRg");
	var mask_graphics_59 = new cjs.Graphics().p("AmtCpIAAlRINbAAIAAFRg");
	var mask_graphics_60 = new cjs.Graphics().p("Am6CpIAAlRIN1AAIAAFRg");
	var mask_graphics_61 = new cjs.Graphics().p("AnHCpIAAlRIOPAAIAAFRg");
	var mask_graphics_62 = new cjs.Graphics().p("AnTCpIAAlRIOnAAIAAFRg");
	var mask_graphics_63 = new cjs.Graphics().p("AngCpIAAlRIPBAAIAAFRg");
	var mask_graphics_64 = new cjs.Graphics().p("AntCpIAAlRIPbAAIAAFRg");
	var mask_graphics_65 = new cjs.Graphics().p("An5CpIAAlRIPzAAIAAFRg");
	var mask_graphics_66 = new cjs.Graphics().p("AoGCpIAAlRIQNAAIAAFRg");
	var mask_graphics_67 = new cjs.Graphics().p("AoTCpIAAlRIQnAAIAAFRg");
	var mask_graphics_68 = new cjs.Graphics().p("AogCpIAAlRIRBAAIAAFRg");
	var mask_graphics_69 = new cjs.Graphics().p("AosCpIAAlRIRZAAIAAFRg");
	var mask_graphics_70 = new cjs.Graphics().p("Ao5CpIAAlRIRzAAIAAFRg");
	var mask_graphics_71 = new cjs.Graphics().p("ApGCpIAAlRISNAAIAAFRg");
	var mask_graphics_72 = new cjs.Graphics().p("ApTCpIAAlRISnAAIAAFRg");
	var mask_graphics_73 = new cjs.Graphics().p("ApfCpIAAlRIS/AAIAAFRg");
	var mask_graphics_74 = new cjs.Graphics().p("ApsCpIAAlRITZAAIAAFRg");
	var mask_graphics_75 = new cjs.Graphics().p("Ap5CpIAAlRITzAAIAAFRg");
	var mask_graphics_76 = new cjs.Graphics().p("AqGCpIAAlRIUNAAIAAFRg");
	var mask_graphics_77 = new cjs.Graphics().p("AqSKyIAAlUIUlAAIAAFUg");
	var mask_graphics_120 = new cjs.Graphics().p("AqSKyIAAlUIUlAAIAAFUg");
	var mask_graphics_121 = new cjs.Graphics().p("AqmCpIAAlRIVNAAIAAFRg");
	var mask_graphics_122 = new cjs.Graphics().p("Aq6CpIAAlRIV1AAIAAFRg");
	var mask_graphics_123 = new cjs.Graphics().p("ArOCpIAAlRIWdAAIAAFRg");
	var mask_graphics_124 = new cjs.Graphics().p("ArjCpIAAlRIXHAAIAAFRg");
	var mask_graphics_125 = new cjs.Graphics().p("Ar3CpIAAlRIXvAAIAAFRg");
	var mask_graphics_126 = new cjs.Graphics().p("AsLCpIAAlRIYXAAIAAFRg");
	var mask_graphics_127 = new cjs.Graphics().p("AsfCpIAAlRIY/AAIAAFRg");
	var mask_graphics_128 = new cjs.Graphics().p("AszCpIAAlRIZnAAIAAFRg");
	var mask_graphics_129 = new cjs.Graphics().p("AtHCpIAAlRIaPAAIAAFRg");
	var mask_graphics_130 = new cjs.Graphics().p("AtbCpIAAlRIa3AAIAAFRg");
	var mask_graphics_131 = new cjs.Graphics().p("AtvCpIAAlRIbfAAIAAFRg");
	var mask_graphics_132 = new cjs.Graphics().p("AuDCpIAAlRIcHAAIAAFRg");
	var mask_graphics_133 = new cjs.Graphics().p("AuXCpIAAlRIcvAAIAAFRg");
	var mask_graphics_134 = new cjs.Graphics().p("AurCpIAAlRIdXAAIAAFRg");
	var mask_graphics_135 = new cjs.Graphics().p("Au/CpIAAlRId/AAIAAFRg");
	var mask_graphics_136 = new cjs.Graphics().p("AvTCpIAAlRIenAAIAAFRg");
	var mask_graphics_137 = new cjs.Graphics().p("AvnCpIAAlRIfPAAIAAFRg");
	var mask_graphics_138 = new cjs.Graphics().p("Av7CpIAAlRIf3AAIAAFRg");
	var mask_graphics_139 = new cjs.Graphics().p("AwQCpIAAlRMAghAAAIAAFRg");
	var mask_graphics_140 = new cjs.Graphics().p("AwkCpIAAlRMAhJAAAIAAFRg");
	var mask_graphics_141 = new cjs.Graphics().p("Aw4CpIAAlRMAhxAAAIAAFRg");
	var mask_graphics_142 = new cjs.Graphics().p("AxMCpIAAlRMAiZAAAIAAFRg");
	var mask_graphics_143 = new cjs.Graphics().p("AxgCpIAAlRMAjBAAAIAAFRg");
	var mask_graphics_144 = new cjs.Graphics().p("Ax0CpIAAlRMAjpAAAIAAFRg");
	var mask_graphics_145 = new cjs.Graphics().p("AyICpIAAlRMAkRAAAIAAFRg");
	var mask_graphics_146 = new cjs.Graphics().p("AycCpIAAlRMAk5AAAIAAFRg");
	var mask_graphics_147 = new cjs.Graphics().p("AywCpIAAlRMAlhAAAIAAFRg");
	var mask_graphics_148 = new cjs.Graphics().p("AzECpIAAlRMAmJAAAIAAFRg");
	var mask_graphics_149 = new cjs.Graphics().p("AzYCpIAAlRMAmxAAAIAAFRg");
	var mask_graphics_150 = new cjs.Graphics().p("AzsCpIAAlRMAnZAAAIAAFRg");
	var mask_graphics_151 = new cjs.Graphics().p("A0ACpIAAlRMAoBAAAIAAFRg");
	var mask_graphics_152 = new cjs.Graphics().p("A0UCpIAAlRMAopAAAIAAFRg");
	var mask_graphics_153 = new cjs.Graphics().p("A0oCpIAAlRMApRAAAIAAFRg");
	var mask_graphics_154 = new cjs.Graphics().p("A09CpIAAlRMAp7AAAIAAFRg");
	var mask_graphics_155 = new cjs.Graphics().p("A1RCpIAAlRMAqjAAAIAAFRg");
	var mask_graphics_156 = new cjs.Graphics().p("A1lCpIAAlRMArLAAAIAAFRg");
	var mask_graphics_157 = new cjs.Graphics().p("A15CpIAAlRMArzAAAIAAFRg");
	var mask_graphics_158 = new cjs.Graphics().p("A2NCpIAAlRMAsbAAAIAAFRg");
	var mask_graphics_159 = new cjs.Graphics().p("A2hCpIAAlRMAtDAAAIAAFRg");
	var mask_graphics_160 = new cjs.Graphics().p("A21CpIAAlRMAtrAAAIAAFRg");
	var mask_graphics_161 = new cjs.Graphics().p("A3JCpIAAlRMAuTAAAIAAFRg");
	var mask_graphics_162 = new cjs.Graphics().p("A3dCpIAAlRMAu7AAAIAAFRg");
	var mask_graphics_163 = new cjs.Graphics().p("A3xCpIAAlRMAvjAAAIAAFRg");
	var mask_graphics_164 = new cjs.Graphics().p("A4FCpIAAlRMAwLAAAIAAFRg");
	var mask_graphics_165 = new cjs.Graphics().p("A4ZCpIAAlRMAwzAAAIAAFRg");
	var mask_graphics_166 = new cjs.Graphics().p("A4tCpIAAlRMAxbAAAIAAFRg");
	var mask_graphics_167 = new cjs.Graphics().p("A5BCpIAAlRMAyDAAAIAAFRg");
	var mask_graphics_168 = new cjs.Graphics().p("A5WCpIAAlRMAytAAAIAAFRg");
	var mask_graphics_169 = new cjs.Graphics().p("A5qCpIAAlRMAzVAAAIAAFRg");
	var mask_graphics_170 = new cjs.Graphics().p("A5+CpIAAlRMAz9AAAIAAFRg");
	var mask_graphics_171 = new cjs.Graphics().p("A6SCpIAAlRMA0lAAAIAAFRg");
	var mask_graphics_172 = new cjs.Graphics().p("A6mCpIAAlRMA1NAAAIAAFRg");
	var mask_graphics_173 = new cjs.Graphics().p("A66CpIAAlRMA11AAAIAAFRg");
	var mask_graphics_174 = new cjs.Graphics().p("A7OCpIAAlRMA2dAAAIAAFRg");
	var mask_graphics_175 = new cjs.Graphics().p("A7iCpIAAlRMA3FAAAIAAFRg");
	var mask_graphics_176 = new cjs.Graphics().p("A72CpIAAlRMA3tAAAIAAFRg");
	var mask_graphics_177 = new cjs.Graphics().p("A8KCpIAAlRMA4VAAAIAAFRg");
	var mask_graphics_178 = new cjs.Graphics().p("A8eCpIAAlRMA49AAAIAAFRg");
	var mask_graphics_179 = new cjs.Graphics().p("A8yCpIAAlRMA5lAAAIAAFRg");
	var mask_graphics_180 = new cjs.Graphics().p("A9GCpIAAlRMA6NAAAIAAFRg");
	var mask_graphics_181 = new cjs.Graphics().p("A9aCpIAAlRMA61AAAIAAFRg");
	var mask_graphics_182 = new cjs.Graphics().p("A9uCpIAAlRMA7dAAAIAAFRg");
	var mask_graphics_183 = new cjs.Graphics().p("A+DCpIAAlRMA8HAAAIAAFRg");
	var mask_graphics_184 = new cjs.Graphics().p("A+XCpIAAlRMA8vAAAIAAFRg");
	var mask_graphics_185 = new cjs.Graphics().p("A+rCpIAAlRMA9XAAAIAAFRg");
	var mask_graphics_186 = new cjs.Graphics().p("A+/CpIAAlRMA9/AAAIAAFRg");
	var mask_graphics_187 = new cjs.Graphics().p("A/TCpIAAlRMA+nAAAIAAFRg");
	var mask_graphics_188 = new cjs.Graphics().p("A/nCpIAAlRMA/PAAAIAAFRg");
	var mask_graphics_189 = new cjs.Graphics().p("A/7CpIAAlRMA/3AAAIAAFRg");
	var mask_graphics_190 = new cjs.Graphics().p("EggPACpIAAlRMBAfAAAIAAFRg");
	var mask_graphics_191 = new cjs.Graphics().p("EggjACpIAAlRMBBHAAAIAAFRg");
	var mask_graphics_192 = new cjs.Graphics().p("Egg3ACpIAAlRMBBvAAAIAAFRg");
	var mask_graphics_193 = new cjs.Graphics().p("EghLACpIAAlRMBCXAAAIAAFRg");
	var mask_graphics_194 = new cjs.Graphics().p("EghfACpIAAlRMBC/AAAIAAFRg");
	var mask_graphics_195 = new cjs.Graphics().p("EghzACpIAAlRMBDnAAAIAAFRg");
	var mask_graphics_196 = new cjs.Graphics().p("EgiHACpIAAlRMBEPAAAIAAFRg");
	var mask_graphics_197 = new cjs.Graphics().p("EgibACpIAAlRMBE3AAAIAAFRg");
	var mask_graphics_198 = new cjs.Graphics().p("EgiwACpIAAlRMBFhAAAIAAFRg");
	var mask_graphics_199 = new cjs.Graphics().p("EgjEACpIAAlRMBGJAAAIAAFRg");
	var mask_graphics_200 = new cjs.Graphics().p("EgjYACpIAAlRMBGxAAAIAAFRg");
	var mask_graphics_201 = new cjs.Graphics().p("EgjsAKyIAAlUMBHZAAAIAAFUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(35).to({graphics:mask_graphics_35,x:-12.9,y:69.1}).wait(1).to({graphics:mask_graphics_36,x:-12.1,y:121.1}).wait(1).to({graphics:mask_graphics_37,x:-10.9,y:121.1}).wait(1).to({graphics:mask_graphics_38,x:-9.6,y:121.1}).wait(1).to({graphics:mask_graphics_39,x:-8.3,y:121.1}).wait(1).to({graphics:mask_graphics_40,x:-7,y:121.1}).wait(1).to({graphics:mask_graphics_41,x:-5.8,y:121.1}).wait(1).to({graphics:mask_graphics_42,x:-4.5,y:121.1}).wait(1).to({graphics:mask_graphics_43,x:-3.2,y:121.1}).wait(1).to({graphics:mask_graphics_44,x:-1.9,y:121.1}).wait(1).to({graphics:mask_graphics_45,x:-0.7,y:121.1}).wait(1).to({graphics:mask_graphics_46,x:0.5,y:121.1}).wait(1).to({graphics:mask_graphics_47,x:1.8,y:121.1}).wait(1).to({graphics:mask_graphics_48,x:3.1,y:121.1}).wait(1).to({graphics:mask_graphics_49,x:4.3,y:121.1}).wait(1).to({graphics:mask_graphics_50,x:5.6,y:121.1}).wait(1).to({graphics:mask_graphics_51,x:6.9,y:121.1}).wait(1).to({graphics:mask_graphics_52,x:8.1,y:121.1}).wait(1).to({graphics:mask_graphics_53,x:9.4,y:121.1}).wait(1).to({graphics:mask_graphics_54,x:10.7,y:121.1}).wait(1).to({graphics:mask_graphics_55,x:12,y:121.1}).wait(1).to({graphics:mask_graphics_56,x:13.2,y:121.1}).wait(1).to({graphics:mask_graphics_57,x:14.5,y:121.1}).wait(1).to({graphics:mask_graphics_58,x:15.8,y:121.1}).wait(1).to({graphics:mask_graphics_59,x:17.1,y:121.1}).wait(1).to({graphics:mask_graphics_60,x:18.3,y:121.1}).wait(1).to({graphics:mask_graphics_61,x:19.6,y:121.1}).wait(1).to({graphics:mask_graphics_62,x:20.9,y:121.1}).wait(1).to({graphics:mask_graphics_63,x:22.2,y:121.1}).wait(1).to({graphics:mask_graphics_64,x:23.4,y:121.1}).wait(1).to({graphics:mask_graphics_65,x:24.7,y:121.1}).wait(1).to({graphics:mask_graphics_66,x:26,y:121.1}).wait(1).to({graphics:mask_graphics_67,x:27.2,y:121.1}).wait(1).to({graphics:mask_graphics_68,x:28.5,y:121.1}).wait(1).to({graphics:mask_graphics_69,x:29.8,y:121.1}).wait(1).to({graphics:mask_graphics_70,x:31.1,y:121.1}).wait(1).to({graphics:mask_graphics_71,x:32.3,y:121.1}).wait(1).to({graphics:mask_graphics_72,x:33.6,y:121.1}).wait(1).to({graphics:mask_graphics_73,x:34.9,y:121.1}).wait(1).to({graphics:mask_graphics_74,x:36.2,y:121.1}).wait(1).to({graphics:mask_graphics_75,x:37.4,y:121.1}).wait(1).to({graphics:mask_graphics_76,x:38.7,y:121.1}).wait(1).to({graphics:mask_graphics_77,x:40,y:69.1}).wait(43).to({graphics:mask_graphics_120,x:40,y:69.1}).wait(1).to({graphics:mask_graphics_121,x:42,y:121.1}).wait(1).to({graphics:mask_graphics_122,x:44,y:121.1}).wait(1).to({graphics:mask_graphics_123,x:46,y:121.1}).wait(1).to({graphics:mask_graphics_124,x:48,y:121.1}).wait(1).to({graphics:mask_graphics_125,x:50.1,y:121.1}).wait(1).to({graphics:mask_graphics_126,x:52.1,y:121.1}).wait(1).to({graphics:mask_graphics_127,x:54.1,y:121.1}).wait(1).to({graphics:mask_graphics_128,x:56.1,y:121.1}).wait(1).to({graphics:mask_graphics_129,x:58.1,y:121.1}).wait(1).to({graphics:mask_graphics_130,x:60.1,y:121.1}).wait(1).to({graphics:mask_graphics_131,x:62.2,y:121.1}).wait(1).to({graphics:mask_graphics_132,x:64.2,y:121.1}).wait(1).to({graphics:mask_graphics_133,x:66.2,y:121.1}).wait(1).to({graphics:mask_graphics_134,x:68.2,y:121.1}).wait(1).to({graphics:mask_graphics_135,x:70.2,y:121.1}).wait(1).to({graphics:mask_graphics_136,x:72.2,y:121.1}).wait(1).to({graphics:mask_graphics_137,x:74.2,y:121.1}).wait(1).to({graphics:mask_graphics_138,x:76.3,y:121.1}).wait(1).to({graphics:mask_graphics_139,x:78.3,y:121.1}).wait(1).to({graphics:mask_graphics_140,x:80.3,y:121.1}).wait(1).to({graphics:mask_graphics_141,x:82.3,y:121.1}).wait(1).to({graphics:mask_graphics_142,x:84.3,y:121.1}).wait(1).to({graphics:mask_graphics_143,x:86.3,y:121.1}).wait(1).to({graphics:mask_graphics_144,x:88.4,y:121.1}).wait(1).to({graphics:mask_graphics_145,x:90.4,y:121.1}).wait(1).to({graphics:mask_graphics_146,x:92.4,y:121.1}).wait(1).to({graphics:mask_graphics_147,x:94.4,y:121.1}).wait(1).to({graphics:mask_graphics_148,x:96.4,y:121.1}).wait(1).to({graphics:mask_graphics_149,x:98.4,y:121.1}).wait(1).to({graphics:mask_graphics_150,x:100.5,y:121.1}).wait(1).to({graphics:mask_graphics_151,x:102.5,y:121.1}).wait(1).to({graphics:mask_graphics_152,x:104.5,y:121.1}).wait(1).to({graphics:mask_graphics_153,x:106.5,y:121.1}).wait(1).to({graphics:mask_graphics_154,x:108.5,y:121.1}).wait(1).to({graphics:mask_graphics_155,x:110.5,y:121.1}).wait(1).to({graphics:mask_graphics_156,x:112.6,y:121.1}).wait(1).to({graphics:mask_graphics_157,x:114.6,y:121.1}).wait(1).to({graphics:mask_graphics_158,x:116.6,y:121.1}).wait(1).to({graphics:mask_graphics_159,x:118.6,y:121.1}).wait(1).to({graphics:mask_graphics_160,x:120.6,y:121.1}).wait(1).to({graphics:mask_graphics_161,x:122.6,y:121.1}).wait(1).to({graphics:mask_graphics_162,x:124.6,y:121.1}).wait(1).to({graphics:mask_graphics_163,x:126.7,y:121.1}).wait(1).to({graphics:mask_graphics_164,x:128.7,y:121.1}).wait(1).to({graphics:mask_graphics_165,x:130.7,y:121.1}).wait(1).to({graphics:mask_graphics_166,x:132.7,y:121.1}).wait(1).to({graphics:mask_graphics_167,x:134.7,y:121.1}).wait(1).to({graphics:mask_graphics_168,x:136.7,y:121.1}).wait(1).to({graphics:mask_graphics_169,x:138.8,y:121.1}).wait(1).to({graphics:mask_graphics_170,x:140.8,y:121.1}).wait(1).to({graphics:mask_graphics_171,x:142.8,y:121.1}).wait(1).to({graphics:mask_graphics_172,x:144.8,y:121.1}).wait(1).to({graphics:mask_graphics_173,x:146.8,y:121.1}).wait(1).to({graphics:mask_graphics_174,x:148.8,y:121.1}).wait(1).to({graphics:mask_graphics_175,x:150.9,y:121.1}).wait(1).to({graphics:mask_graphics_176,x:152.9,y:121.1}).wait(1).to({graphics:mask_graphics_177,x:154.9,y:121.1}).wait(1).to({graphics:mask_graphics_178,x:156.9,y:121.1}).wait(1).to({graphics:mask_graphics_179,x:158.9,y:121.1}).wait(1).to({graphics:mask_graphics_180,x:160.9,y:121.1}).wait(1).to({graphics:mask_graphics_181,x:163,y:121.1}).wait(1).to({graphics:mask_graphics_182,x:165,y:121.1}).wait(1).to({graphics:mask_graphics_183,x:167,y:121.1}).wait(1).to({graphics:mask_graphics_184,x:169,y:121.1}).wait(1).to({graphics:mask_graphics_185,x:171,y:121.1}).wait(1).to({graphics:mask_graphics_186,x:173,y:121.1}).wait(1).to({graphics:mask_graphics_187,x:175.1,y:121.1}).wait(1).to({graphics:mask_graphics_188,x:177.1,y:121.1}).wait(1).to({graphics:mask_graphics_189,x:179.1,y:121.1}).wait(1).to({graphics:mask_graphics_190,x:181.1,y:121.1}).wait(1).to({graphics:mask_graphics_191,x:183.1,y:121.1}).wait(1).to({graphics:mask_graphics_192,x:185.1,y:121.1}).wait(1).to({graphics:mask_graphics_193,x:187.1,y:121.1}).wait(1).to({graphics:mask_graphics_194,x:189.2,y:121.1}).wait(1).to({graphics:mask_graphics_195,x:191.2,y:121.1}).wait(1).to({graphics:mask_graphics_196,x:193.2,y:121.1}).wait(1).to({graphics:mask_graphics_197,x:195.2,y:121.1}).wait(1).to({graphics:mask_graphics_198,x:197.2,y:121.1}).wait(1).to({graphics:mask_graphics_199,x:199.2,y:121.1}).wait(1).to({graphics:mask_graphics_200,x:201.3,y:121.1}).wait(1).to({graphics:mask_graphics_201,x:203.3,y:69.1}).wait(24));

	// Capa 2
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Af+BRQgJgDgGgHQgJgIgFgNQgEgNAAgUQAAgRAEgOQAEgQAKgLQAIgLANgGQAOgHASAAIAKABIAHABIAAATIgBAAIgIgDQgFgBgGAAQgVAAgNANQgMANgCAWQAIgEAJgDQAHgDALAAQAJAAAHACQAHACAHAFQAJAEAFAKQAEAIAAANQAAAXgPANQgPAOgVABQgKgBgJgDgAf/AGQgGACgIAFIAAAEIAAAFQgBAPAEAJQADAJAFAFQAFAEAFADQAGACAFAAQAPgBAIgIQAIgJAAgQQAAgJgCgGQgEgGgFgFQgFgDgGgBIgLAAQgIAAgIABgAZDBRQgLgCgHgDIAAgVIABAAQAIAFALAEQALADALABQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgDgFQgCgFgEgDQgEgDgHgBQgGgBgHAAIgJAAIAAgOIAGAAQAQAAAIgHQAKgGgBgMQABgFgDgEQgCgEgEgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgCAAIAAgUIATgGQALgDAMAAQAKAAAIACQAIACAHAFQAHAEAEAGQADAHAAAJQAAAMgJAJQgIAJgMAAIAAACIALADQAGADAEAEQAFAEADAGQADAHAAAKQAAAJgEAJQgDAIgHAGQgHAHgKADQgKAEgLAAQgMAAgNgEgAhUBRQgMgCgHgDIAAgVIABAAQAIAFAMAEQALADAKABQAGAAAHgCQAIgCAEgEQAFgFABgFQADgFAAgIQAAgIgDgFQgCgFgEgDQgFgDgHgBQgFgBgIAAIgIAAIAAgOIAGAAQAPAAAJgHQAJgGAAgMQAAgFgDgEQgBgEgFgDIgJgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgUIATgGQALgDALAAQALAAAHACQAJACAHAFQAGAEAEAGQAEAHAAAJQAAAMgJAJQgJAJgLAAIAAACIALADQAGADAEAEQAFAEADAGQADAHAAAKQgBAJgDAJQgEAIgGAGQgIAHgKADQgKAEgLAAQgMAAgMgEgASABRIAAgUIAVgSIATgRQATgSAGgJQAIgKAAgNQgBgLgHgGQgIgHgMAAQgKAAgKADQgLADgJAGIgBAAIAAgUQAHgEALgCQAMgDALAAQAWAAANALQAMAKAAATQAAAJgCAGQgCAIgEAEQgDAHgGAFIgMANIgWAUIgVASIBPAAIAAAQgAMzBRIAAgoIhGAAIAAgXIBHhQIARAAIAABXIAWAAIAAAQIgWAAIAAAogAL7AZIA4AAIAAg/gAFRBRIAAgOIAfAAIAAhgIgfAAIAAgNIAOgBQAGgBAEgCQAEgDADgDQADgEAAgHIAPAAIAACCIAeAAIAAAOgAoYBRIAAgUIAWgSIATgRQASgSAHgJQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgLADQgKADgJAGIgBAAIAAgUQAGgEAMgCQALgDALAAQAXAAAMALQANAKAAATQAAAJgCAGQgCAIgEAEQgEAHgFAFIgNANIgVAUIgVASIBOAAIAAAQgAujBRIAAgUIAWgSIATgRQASgSAHgJQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgLADQgKADgJAGIgBAAIAAgUQAGgEAMgCQAMgDAKAAQAWAAANALQANAKAAATQAAAJgCAGQgCAIgEAEQgEAHgFAFIgNANIgVAUIgVASIBOAAIAAAQgAzsBRIAAgOIAeAAIAAhgIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQADgEAAgHIAPAAIAACCIAeAAIAAAOgA5MBRIAAgUIAVgSIATgRQASgSAHgJQAHgKAAgNQAAgLgHgGQgIgHgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAIgEALgCQALgDAMAAQAVAAANALQANAKAAATQAAAJgCAGQgCAIgEAEQgEAHgFAFIgMANIgXAUIgUASIBOAAIAAAQgEghDABRIAAgOIAeAAIAAhgIgeAAIAAgNIANgBQAIgBADgCQAEgDADgDQADgEAAgHIAPAAIAACCIAeAAIAAAOgAV/BPIAAg2Ig1AAIAAgPIA1AAIAAgzIARAAIAAAzIA1AAIAAAPIg1AAIAAA2gAJFBPIAAg2Ig1AAIAAgPIA1AAIAAgzIAQAAIAAAzIA1AAIAAAPIg1AAIAAA2gAkYBPIAAg2Ig1AAIAAgPIA1AAIAAgzIAQAAIAAAzIA1AAIAAAPIg1AAIAAA2gA79BPIAAg2Ig1AAIAAgPIA1AAIAAgzIARAAIAAAzIA1AAIAAAPIg1AAIAAA2gAb+AuIAAgPIBzAAIAAAPgABkAuIAAgPIB0AAIAAAPgAwpAgIAAgcIAXAAIAAAcgA1+AgIAAgcIAXAAIAAAcgAO6AZIAAgPIBhAAIAAAPgAreAZIAAgPIBiAAIAAAPgA/VALIAAgMIANgKIANgMQAMgMAFgHQAEgHAAgIQAAgHgEgEQgGgFgIAAQgGAAgGACQgIACgGAEIgBAAIAAgMQAFgDAIgCQAHgBAHAAQAPgBAIAIQAIAGAAANIgBAKIgEAJIgGAHIgIAJIgOAMIgOAKIAzAAIAAALgAb+AFIAAgOIBzAAIAAAOgABkAFIAAgOIB0AAIAAAOg");
	this.shape_5.setTransform(216.4,120.9);

	this.shape_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5}]},35).wait(190));

	// Capa 1
	this.txt_06_01 = new cjs.Text("Así, el valor numérico de la expresión x2 + 2xy - y + 3 algebraica  para x = 1 e y = 2 es 6.", "20px Verdana");
	this.txt_06_01.lineHeight = 20;
	this.txt_06_01.lineWidth = 682;
	this.txt_06_01.setTransform(0,170);
 var html = createDiv(txt['txt_06_01'], "Verdana", "20px", '690px', '40px', "20px", "185px", "left");
    this.txt_06_01 = new cjs.DOMElement(html);
    this.txt_06_01.setTransform(0, 170-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_06_01}]},224).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2.4,5.4,167.8,69.3);


(lib.textoAnimado_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EhCnAAxIAAhiMCFPAAAIAABig");
	var mask_graphics_1 = new cjs.Graphics().p("EhCnABFIAAiJMCFPAAAIAACJg");
	var mask_graphics_2 = new cjs.Graphics().p("EhCnABYIAAivMCFPAAAIAACvg");
	var mask_graphics_3 = new cjs.Graphics().p("EhCnABsIAAjXMCFPAAAIAADXg");
	var mask_graphics_4 = new cjs.Graphics().p("EhCnAB/IAAj9MCFPAAAIAAD9g");
	var mask_graphics_5 = new cjs.Graphics().p("EhCnACTIAAklMCFPAAAIAAElg");
	var mask_graphics_6 = new cjs.Graphics().p("EhCnACmIAAlLMCFPAAAIAAFLg");
	var mask_graphics_7 = new cjs.Graphics().p("EhCnAC6IAAlzMCFPAAAIAAFzg");
	var mask_graphics_8 = new cjs.Graphics().p("EhCnADNIAAmZMCFPAAAIAAGZg");
	var mask_graphics_9 = new cjs.Graphics().p("EhCnADhIAAnBMCFPAAAIAAHBg");
	var mask_graphics_10 = new cjs.Graphics().p("EhCnAD0IAAnnMCFPAAAIAAHng");
	var mask_graphics_11 = new cjs.Graphics().p("EhCnAEIIAAoPMCFPAAAIAAIPg");
	var mask_graphics_12 = new cjs.Graphics().p("EhCnAEbIAAo1MCFPAAAIAAI1g");
	var mask_graphics_13 = new cjs.Graphics().p("EhCnAEvIAApdMCFPAAAIAAJdg");
	var mask_graphics_14 = new cjs.Graphics().p("EhCnAFCIAAqDMCFPAAAIAAKDg");
	var mask_graphics_15 = new cjs.Graphics().p("EhCnAFWIAAqrMCFPAAAIAAKrg");
	var mask_graphics_16 = new cjs.Graphics().p("EhCnAFpIAArRMCFPAAAIAALRg");
	var mask_graphics_17 = new cjs.Graphics().p("EhCnAF9IAAr5MCFPAAAIAAL5g");
	var mask_graphics_18 = new cjs.Graphics().p("EhCnAGQIAAsfMCFPAAAIAAMfg");
	var mask_graphics_19 = new cjs.Graphics().p("EhCnAGkIAAtGMCFPAAAIAANGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:399.5,y:-15.8}).wait(1).to({graphics:mask_graphics_1,x:399.5,y:-13.8}).wait(1).to({graphics:mask_graphics_2,x:399.5,y:-11.9}).wait(1).to({graphics:mask_graphics_3,x:399.5,y:-9.9}).wait(1).to({graphics:mask_graphics_4,x:399.5,y:-8}).wait(1).to({graphics:mask_graphics_5,x:399.5,y:-6}).wait(1).to({graphics:mask_graphics_6,x:399.5,y:-4.1}).wait(1).to({graphics:mask_graphics_7,x:399.5,y:-2.1}).wait(1).to({graphics:mask_graphics_8,x:399.5,y:-0.2}).wait(1).to({graphics:mask_graphics_9,x:399.5,y:1.7}).wait(1).to({graphics:mask_graphics_10,x:399.5,y:3.6}).wait(1).to({graphics:mask_graphics_11,x:399.5,y:5.6}).wait(1).to({graphics:mask_graphics_12,x:399.5,y:7.5}).wait(1).to({graphics:mask_graphics_13,x:399.5,y:9.5}).wait(1).to({graphics:mask_graphics_14,x:399.5,y:11.4}).wait(1).to({graphics:mask_graphics_15,x:399.5,y:13.4}).wait(1).to({graphics:mask_graphics_16,x:399.5,y:15.3}).wait(1).to({graphics:mask_graphics_17,x:399.5,y:17.3}).wait(1).to({graphics:mask_graphics_18,x:399.5,y:19.2}).wait(1).to({graphics:mask_graphics_19,x:399.5,y:21.2}).wait(158));

	// Capa 3
	this.txt_04_01 = new cjs.Text("Una expresión algebraica es una expresión matemática que consta de números, letras y símbolos de operaciones aritméticas.", "20px Verdana");
	this.txt_04_01.lineHeight = 20;
	this.txt_04_01.lineWidth = 785;
 var html = createDiv(txt['txt_04_01'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.txt_04_01 = new cjs.DOMElement(html);
    this.txt_04_01.setTransform(0, -608);
	this.txt_04_01.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt_04_01}]}).wait(177));

	// Capa 10
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA5BeIAggvIgUhkIATAAIAQBPIA0hPIAUAAIhjCTgAicA2QgLgDgIgDIAAgVIACAAQAIAGALADQALAEALAAQAGAAAHgCQAHgCAEgEQAFgFACgFQACgFAAgIQAAgIgDgDQgCgFgEgDQgFgDgGgBQgGgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgHAAgMQAAgFgCgEQgCgEgEgCIgJgEIgLgBQgKAAgKAEQgKADgKAGIgBAAIAAgVIATgGQALgDALAAQALAAAIACQAIACAHAFQAHAEADAHQAEAGAAAJQAAAMgJAKQgIAJgMACIAAABIALAEQAGACAEAEQAFAEADAGQADAFAAAKQAAAKgEAIQgDAIgHAGQgHAHgKAEQgKADgMAAQgMAAgMgDgAANA2IgVgqIgoAqIgXAAIA4g2Igeg1IAUAAIAXApIAmgpIAXAAIg4A1IAfA2g");
	this.shape.setTransform(216.5,110.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0000").s().p("AAFBKIAgguIgUhlIATAAIAQBPIA0hPIAUAAIhjCTgAglAiIgXgnIgoAnIgXAAIA4g1Igeg2IAUAAIAXAqIAogqIAVAAIg2A3IAfA0g");
	this.shape_1.setTransform(221.7,112.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgbBIQgMgCgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAEAAAHgCQAHgCAFgEQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgFAAIgJAAIAAgOIAHAAQANAAAJgGQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgJgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAIAAAIACQAJACAGAEQAHAFAEAGQADAHAAAJQAAAMgIAJQgJAJgLACIAAACIAKADQAGACAFACQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAGQgIAHgKADQgKADgJAAQgMAAgMgDg");
	this.shape_2.setTransform(203.6,108.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0033CC").s().p("AgbBIQgMgCgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAEAAAHgCQAHgCAFgEQAEgEACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgEgDgHgBQgGgCgFAAIgJAAIAAgOIAHAAQANAAAJgGQAJgGAAgMQAAgFgDgEQgCgEgEgDIgJgDIgJgBQgJAAgLADQgKADgJAGIgBAAIAAgUIASgGQAMgDALAAQAIAAAIACQAJACAGAEQAHAFAEAGQADAHAAAJQAAAMgIAJQgJAJgLACIAAACIAKADQAGACAFACQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAGQgIAHgKADQgKADgJAAQgMAAgMgDg");
	this.shape_3.setTransform(203.6,108.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},39).to({state:[{t:this.shape_2},{t:this.shape_1}]},69).to({state:[{t:this.shape_3},{t:this.shape_1}]},54).wait(15));

	// Capa 9
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AhTAAICnAA");
	this.shape_4.setTransform(552.6,222.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgrDEQgMgDgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgCADgDQAEgFACgFQACgFAAgIQAAgIgCgFQgDgFgEgDQgCgDgHgBQgGgBgHgBIgJAAIAAgQIAHAAQAPAAAHgFQAJgHAAgMQAAgFgDgEQgCgEgEgCIgHgEIgLgBQgJAAgLAEQgKACgJAHIgBAAIAAgVIASgGQAMgDALAAQAKAAAHACQAIACAGAEQAHAFAEAHQADAGAAAJQAAAMgIAKQgJAIgLACIAAACIAKAEQAGACAFADQAEAFADAGQADAGAAAKQAAALgDAHQgEAJgGAGQgIAHgKAEQgIACgLAAQgMAAgMgCgAnXAgQgIgHAAgNQAAgMAFgIQAGgIALgGQALgGAQgCQAPgDAUgBIABgEIABgFQAAgEgCgDQgCgDgDgCQgEgCgEAAIgKAAQgJAAgKACQgLADgHADIgBAAIAEgTIAQgEIAVgBQAUAAAKAGQALAHAAANIgBAGIgBAFIgRBIIgSAAIACgLIgHAFIgJAEIgLAEQgGACgIAAQgNAAgIgIgAmpgRQgLACgIADQgIADgEAGQgEAEAAAHQAAAIAFADQAFAEAKAAQAJAAAJgEQAJgEAIgGIAHgcQgPAAgMACgAHFAkQgIgCgGgFQgGgFgDgIQgDgIAAgIQAAgQAFgMQAFgOAJgKQAIgKANgFQAMgGAPAAQAJAAAJACQAIADAGAEIgEATIgBAAIgEgDIgHgFIgJgDQgFgCgGAAQgTAAgMAQQgMAQAAAXQAAAMAHAHQAHAHANABQAGgBAGgBIALgEIAJgEIAGgFIABAAIgEAVQgJAEgJACQgKADgKAAQgKAAgIgDgApTAkIAAgUIAVgQIATgRQATgSAHgLQAHgKAAgNQAAgLgIgHQgHgGgNAAQgJAAgLADQgKADgKAGIgBAAIAAgUQAHgDAMgDQALgDALAAQAWAAANALQANAKAAATQAAAIgCAHQgCAIgFAGQgDAGgFAGIgNANIgWASIgUASIBOAAIAAAQgAECAiIAAg0Ig1AAIAAgPIA1AAIAAg1IARAAIAAA1IA1AAIAAAPIg1AAIAAA0gAkWgSIAAgPIBhAAIAAAPgAIiggIgNgEIAAgNIABAAQAGADAHACQAHADAHAAIAJgCQAEgBADgCQADgDABgEQACgDAAgFQAAgFgCgEIgEgEIgHgEIgJAAIgGAAIAAgLIAFAAQAJAAAGgDQAGgFAAgIQAAgDgCgCIgEgFIgGgCIgHAAQgGgBgGACIgNAHIgBAAIAAgOIAMgEQAIgBAHAAQAHgBAFACQAFABAEADQAFADACAEQADAFAAAFQAAAIgGAGQgFAGgIACIAAABIAHABIAHAEQADADACAEQACAFAAAGQAAAGgDAGQgCAFgEAFQgFAEgHACQgGACgIAAQgIAAgHgCgAgogtQgIgCgGgEIgCAGIgRAAIAjiZIASAAIgMA3QAJgHAIgEQAJgDAJAAQAQAAAIAKQAJAJAAASQAAAQgFAOQgFAPgJAKQgIAKgJAHQgLAFgNAAQgJAAgHgCgAgUiJQgIAEgIAGIgOA+IAMAFQAGACAIAAQAKgBAIgFQAGgEAFgIQAGgJADgKQACgKAAgMQAAgLgFgHQgFgGgJAAQgIAAgJAEg");
	this.shape_5.setTransform(554.2,223);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0000").s().p("AnuBvQgIgHAAgNQAAgMAFgJQAGgJALgGQALgGAQgCQAPgDAUAAIABgFIABgEQAAgFgCgCQgCgDgDgCQgEgCgEgBIgKAAQgJAAgKACQgLADgHADIgBAAIAEgSIAQgEIAVgCQAUABAKAFQALAHAAANIgBAGIgBAGIgRBKIgSAAIACgLIgHAEIgJAFIgLAEQgGABgIAAQgNAAgIgIgAnAA9QgLABgIADQgIAEgEAFQgEAGAAAIQAAAHAFAEQAFAEAKgBQAJAAAJgDQAJgEAIgGIAHgfQgPABgMACgAGuB0QgIgDgGgFQgGgFgDgHQgDgIAAgKQAAgQAFgNQAFgNAJgKQAIgKANgGQAMgGAPAAQAJAAAJADQAIACAGAEIgEAUIgBAAIgEgEIgHgEIgJgEQgFgBgGgBQgTABgMAQQgMAQAAAWQAAAOAHAIQAHAHANAAQAGAAAGgCIALgDIAJgFIAGgEIABAAIgEAUQgJAEgJADQgKACgKAAQgKABgIgDgAg/AhQgIgDgGgDIgCAFIgRAAIAjiWIASAAIgMA3QAJgHAIgEQAJgEALAAQAQAAAGAKQAJAJAAASQAAAQgFAPQgFAMgHAKQgIALgLAGQgLAGgNAAQgJAAgHgCgAgrg6QgIAEgIAGIgOA8IAMAGQAGABAIAAQAKAAAIgFQAIgFAFgIQAGgGADgKQACgLAAgLQAAgLgFgHQgFgGgLAAQgIAAgJADg");
	this.shape_6.setTransform(556.5,215);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgrChQgMgCgHgEIAAgUIABAAQAIAFAMAEQALADAKAAQAGAAAHgCQAHgCADgEQAEgFACgFQACgEAAgIQAAgJgCgFQgDgFgEgDQgCgCgHgBQgGgCgHAAIgJAAIAAgQIAHAAQAPAAAHgGQAJgHAAgMQAAgFgDgEQgCgDgEgDIgHgDIgLgBQgJAAgLADQgKADgJAGIgBAAIAAgVIASgGQAMgDALAAQAKABAHABQAIACAGAFQAHAFAEAGQADAGAAAKQAAAMgIAJQgJAJgLACIAAACIAKADQAGADAFADQAEAEADAHQADAGAAAKQAAAKgDAIQgEAJgGAFQgIAIgKADQgIADgLAAQgMAAgMgDgApTACIAAgSIAVgSIATgRQATgTAHgLQAHgKAAgMQAAgLgIgHQgHgGgNgBQgJAAgLAEQgKADgKAGIgBAAIAAgVQAHgDAMgCQALgEALAAQAWAAANAMQANAKAAATQAAAIgCAHQgCAIgFAFQgDAHgFAFIgNAOIgWATIgUATIBOAAIAAAOgAECAAIAAg0Ig1AAIAAgPIA1AAIAAg2IARAAIAAA2IA1AAIAAAPIg1AAIAAA0gAkWg0IAAgPIBhAAIAAAPgAIihDIgNgDIAAgOIABAAQAGAEAHACQAHACAHAAIAJgBQAEgBADgDQADgDABgDQACgEAAgEQAAgFgCgEIgEgFIgHgDIgJAAIgGAAIAAgLIAFAAQAJAAAGgEQAGgEAAgIQAAgEgCgCIgEgEIgGgCIgHgBQgGAAgGACIgNAGIgBAAIAAgNIAMgEQAIgCAHAAQAHAAAFABQAFACAEADQAFACACAFQADAEAAAGQAAAIgGAFQgFAHgIABIAAABIAHACIAHAEQADADACAEQACAEAAAHQAAAGgDAFQgCAGgEAEQgFAEgHACQgGACgIAAQgIAAgHgCg");
	this.shape_7.setTransform(554.2,226.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("ABkBSIAAg2Ig1AAIAAgPIA1AAIAAgzIAQAAIAAAzIA1AAIAAAPIg1AAIAAA2gAm0AcIAAgPIBhAAIAAAPgAGDAOIgMgEIAAgMIABAAQAFACAHACQAIADAHAAIAIgCQAFgBACgCQADgBACgEQABgDAAgFQAAgFgBgEIgFgFIgHgDIgJAAIgFAAIAAgLIAEAAQAKAAAGgEQAFgEAAgIQAAgDgBgDIgEgEIgGgCIgHgBQgGAAgHACIgNAGIAAAAIAAgNIAMgEQAHgCAHAAQAHAAAFACQAGABAEADQAEADADAEQACAEAAAGQAAAIgFAGQgGAGgIABIAAABIAHACIAHAEQADADACAEQACAEAAAHQAAAGgCAGQgDADgEAEQgFAEgGADQgGACgIAAQgIAAgIgCg");
	this.shape_8.setTransform(570,218.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0033CC").s().p("ADtCYQgMgDgHgDIAAgVIABAAQAJAGALADQALAEALAAQAFAAAHgCQAIgCAEgEQAEgFACgFQACgFABgIQAAgIgDgFQgCgFgEgDQgFgDgHgBQgFgBgIAAIgIAAIAAgQIAGAAQAPAAAJgGQAJgHAAgMQAAgFgDgEQgBgEgFgCIgJgEIgLgBQgJAAgKAEQgLADgJAGIgBAAIAAgVIATgGQALgDALAAQAKAAAIACQAJACAHAFQAGAEAEAHQADAGAAAJQABAMgJAKQgJAJgLACIAAABIAKAEQAHACAEAEQAEAEADAGQAEAHAAAKQgBAKgDAIQgEAIgGAGQgIAHgKAEQgJADgMAAQgMAAgMgDgAk5gFIAAgVIAVgRIATgSQATgSAHgLQAHgKAAgNQAAgLgIgGQgHgHgNAAQgJAAgKADQgLADgJAHIgCAAIAAgVQAIgDALgDQALgDALAAQAXAAANALQAMALAAASQAAAJgCAHQgCAHgFAGQgDAHgFAFIgMANIgWAUIgVASIBOAAIAAARg");
	this.shape_9.setTransform(526,227.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_5},{t:this.shape_4}]},50).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_4}]},58).to({state:[{t:this.shape_9},{t:this.shape_6},{t:this.shape_8},{t:this.shape_4}]},54).wait(15));

	// Capa 8
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AFpBcIAfguIgThlIATAAIAPBPIA0hPIAUAAIhiCTgAnMA1QgLgDgHgDIAAgVIABAAQAIAFALAEQAKADALAAQAHAAAGgCQAHgCAFgEQAEgFACgFQACgGAAgIQAAgGgCgFQgDgFgEgDQgFgEgIgBQgHgCgJAAIgQABIgOADIAAhLIBXAAIAAARIhEAAIAAAnIAIgBIAIAAQAMAAAJACQAIACAIAFQAIAFAEAJQAEAIAAALQAAAKgDAJQgEAKgHAGQgHAHgJAEQgKADgNAAQgMAAgLgCgAAMA0IgVgpIgoApIgXAAIA4g1Igeg2IAUAAIAXAqIAmgqIAXAAIg4A3IAfA0gADDAyIAAg0Ig1AAIAAgPIA1AAIAAg1IARAAIAAA1IA1AAIAAAPIg1AAIAAA0gAjiAyIAAg0Ig1AAIAAgPIA1AAIAAg1IARAAIAAA1IA1AAIAAAPIg1AAIAAA0g");
	this.shape_10.setTransform(370.9,148.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0000").s().p("ACeBKIAfguIgUhlIATAAIAQBPIA0hPIAUAAIhjCTgAi+AiIgWgnIgoAnIgXAAIA4g1Igfg2IAVAAIAWAqIApgqIAWAAIg3A3IAeA0g");
	this.shape_11.setTransform(391.3,150.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AlgBHQgLgCgIgEIAAgUIABAAQAIAFALADQAKAEALAAQAHAAAHgCQAGgCAFgFQAFgEACgGQABgGAAgIQABgHgDgFQgDgFgEgEQgFgDgHAAQgHgBgJAAIgRABIgOAAIAAhJIBXAAIAAARIhEAAIAAAnIAJAAIAHgBQAMAAAJACQAIACAIAFQAIAGAEAGQAFAJgBANQABAKgEAJQgEAJgGAHQgIAGgJAEQgKAEgNAAQgLAAgLgDgAEvBEIAAg1Ig2AAIAAgPIA2AAIAAg0IAQAAIAAA0IA1AAIAAAPIg1AAIAAA1gAh2BEIAAg1Ig2AAIAAgPIA2AAIAAg0IAQAAIAAA0IA1AAIAAAPIg1AAIAAA1g");
	this.shape_12.setTransform(360.2,146.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("ADLA8IAAg1Ig1AAIAAgOIA1AAIAAg1IAQAAIAAA1IA1AAIAAAOIg1AAIAAA1gAjaA8IAAg1Ig1AAIAAgOIA1AAIAAg1IAQAAIAAA1IA1AAIAAAOIg1AAIAAA1g");
	this.shape_13.setTransform(370.2,147.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0033CC").s().p("AgbBHQgLgCgIgEIAAgUIABAAQAIAFALADQALAEAKAAQAFAAAHgCQAGgCAFgFQAFgEACgGQACgGAAgIQAAgHgDgFQgCgFgFgEQgFgDgHAAQgFgBgJAAIgRABIgOAAIAAhJIBWAAIAAARIhDAAIAAAnIAJAAIAHgBQAKAAAJACQAJACAHAFQAIAGAEAGQAFAJAAANQAAAKgEAJQgEAJgGAHQgHAGgKAEQgKAEgKAAQgMAAgLgDg");
	this.shape_14.setTransform(327.7,146.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_10}]},61).to({state:[{t:this.shape_12},{t:this.shape_11}]},47).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_11}]},54).wait(15));

	// Capa 7
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("AksAAIJZAA");
	this.shape_15.setTransform(169.5,215.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("ADaDNIAAgqIhGAAIAAgWIBHhSIASAAIAABZIAWAAIAAAPIgWAAIAAAqgACiCUIA4AAIAAhCgAkNDNIACgOIBRhRIg+AAIADgOIBWAAIgDAMIhRBSIBBAAIgEAPgAgRDKIAAg1Ig1AAIAAgQIA1AAIAAg1IAQAAIAAA1IAzAAIAAAQIgzAAIAAA1gAC1ABIAfgsIgUhmIATAAIAQBRIA0hRIAUAAIhjCSgAjUglIgXgpIgpApIgWAAIA4g2Igfg2IAVAAIAWApIApgpIAWAAIg3A2IAeA2gAgFhcIAAgQIBfAAIAAAQgAijhrIAAgNIAOgMIAMgLQAMgMAEgHQAGgHAAgIQAAgHgGgFQgEgDgJAAQgGAAgHACQgGABgHAFIAAAAIAAgOQAEgCAHgBQAIgCAHgBQAOABAJAGQAIAHAAAMIgBAKIgEAJIgGAIIgIAIIgOAOIgNALIAyAAIAAALg");
	this.shape_16.setTransform(169.9,213.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("ACrDNIAAgqIhGAAIAAgWIBHhSIASAAIAABZIAVAAIAAAPIgVAAIAAAqgABzCUIA4AAIAAhCgAhBDKIAAg1Ig1AAIAAgQIA1AAIAAg1IARAAIAAA1IAzAAIAAAQIgzAAIAAA1gAg0hcIAAgQIBfAAIAAAQgAjShrIAAgNIANgMIANgLQAMgMAEgHQAFgHAAgIQAAgHgFgFQgFgDgIAAQgGAAgHACQgHABgGAFIgBAAIAAgOQAFgCAHgBQAIgCAHgBQAOABAJAGQAIAHAAAMIgBAKIgEAJIgGAIIgIAIIgOAOIgOALIAzAAIAAALg");
	this.shape_17.setTransform(174.6,213.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0000").s().p("AkNCwIACgOIBRhRIg+AAIADgOIBWAAIgDAMIhRBSIBBAAIgEAPgAC1gaIAfguIgUhmIATAAIAQBRIA0hRIAUAAIhjCUgAjUhBIgXgqIgpAqIgWAAIA4g3Igfg2IAVAAIAWApIApgpIAWAAIg3A2IAeA3g");
	this.shape_18.setTransform(169.9,216);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0033CC").s().p("AAOBIIAAgpIhEAAIAAgWIBFhQIASAAIAABXIAWAAIAAAPIgWAAIAAApgAgoAQIA2AAIAAhAg");
	this.shape_19.setTransform(190.3,226.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AASDLIAAg1IgzAAIAAgQIAzAAIAAg1IAQAAIAAA1IA1AAIAAAQIg1AAIAAA1gAAehbIAAgQIBhAAIAAAQgAh+hqIAAgNIAOgLIAMgMQAMgMAEgHQAGgHAAgIQAAgHgGgEQgEgEgJAAQgGAAgHACQgGACgHAEIAAAAIAAgNQAEgDAHgBQAIgCAHAAQAOAAAJAHQAIAHAAAMIgBAKIgEAJIgGAHIgIAJIgOANIgNALIAyAAIAAALg");
	this.shape_20.setTransform(166.2,212.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_16},{t:this.shape_15}]},71).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_15}]},37).to({state:[{t:this.shape_18},{t:this.shape_20},{t:this.shape_19},{t:this.shape_15}]},54).wait(15));

	// Capa 2
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("AkzAAIJnAA");
	this.shape_21.setTransform(625.6,129.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AggDFIBEiAIhRAAIAAgSIBiAAIAAAWIhBB8gAC+grQgIgCgFgEIgDAFIgRAAIAjiYIASAAIgMA2QAJgGAJgEQAJgEAKAAQAQAAAJAKQAIAKAAASQAAAQgFAOQgFAOgIAKQgJALgLAGQgLAGgMAAQgKAAgHgCgADSiIQgIAEgHAGIgPA+IAMAGQAGABAIAAQAKAAAJgFQAHgFAFgIQAGgJADgJQADgKAAgMQgBgMgEgGQgFgHgMABQgIAAgJADgAkDgwQgIgIAAgNQAAgNAGgIQAFgJAMgGQAKgGAQgCQAQgCATgBIACgEIAAgFQAAgEgCgEQgBgDgEgBQgDgCgFAAIgKgBQgIAAgLADQgLACgGADIgBAAIADgTIARgDIAUgBQAUAAALAFQAKAHAAAOIAAAFIgBAGIgSBKIgSAAIADgLIgIAEIgJAFIgLADQgGACgIAAQgNAAgIgHgAjVhjQgLABgHAEQgJADgDAGQgFAFAAAIQAAAHAFAEQAFAEAKAAQAJAAAJgFQAJgEAIgFIAHgeQgOAAgNACgAgHguIAAg2Ig1AAIAAgQIA1AAIAAg1IAPAAIAAA1IA1AAIAAAQIg1AAIAAA2g");
	this.shape_22.setTransform(624.1,129.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AggC3IBEiAIhRAAIAAgRIBiAAIAAAWIhAB7gAgHg8IAAg2Ig1AAIAAgPIA1AAIAAg1IAPAAIAAA1IA1AAIAAAPIg1AAIAAA2g");
	this.shape_23.setTransform(624,131.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CC0000").s().p("AC+BLQgIgCgFgEIgDAFIgRAAIAjiWIASAAIgMA2QAJgGAJgEQAJgEAKAAQAQAAAJAKQAIAKAAAQQAAAQgFAOQgFAOgIAKQgJALgLAGQgLAGgMAAQgKAAgHgCgADSgQQgIAEgHAGIgPA8IAMAGQAGABAIAAQAKAAAJgFQAHgFAFgIQAGgJADgJQADgKAAgMQgBgKgEgGQgFgHgMABQgIAAgJADgAkDBGQgIgIAAgNQAAgNAGgIQAFgJAMgGQAKgGAQgCQAQgCATgBIACgCIAAgFQAAgEgCgEQgBgDgEgBQgDgCgFAAIgKgBQgIAAgLADQgLACgGADIgBAAIADgTIARgDIAUgBQAUAAALAFQAKAHAAAOIAAAFIgBAEIgSBKIgSAAIADgLIgIAEIgJAFIgLADQgGACgIAAQgNAAgIgHgAjVATQgLABgHAEQgJADgDAGQgFAFAAAIQAAAHAFAEQAFAEAKAAQAJAAAJgFQAJgEAIgFIAHgeQgOAAgNACg");
	this.shape_24.setTransform(624.1,117.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#0033CC").s().p("AgjBIIBEh+IhRAAIAAgRIBhAAIAAAWIhAB5g");
	this.shape_25.setTransform(624.4,142.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgHA9IAAg2Ig1AAIAAgOIA1AAIAAg1IAPAAIAAA1IA1AAIAAAOIg1AAIAAA2g");
	this.shape_26.setTransform(624,118.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_22},{t:this.shape_21}]},81).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_21}]},27).to({state:[{t:this.shape_24},{t:this.shape_26},{t:this.shape_25},{t:this.shape_21}]},54).wait(15));

	// txt_02
	this.txt_04_02 = new cjs.Text("Las letras representan valores que no conocemos. Se llaman variables.", "20px Verdana");
	this.txt_04_02.lineHeight = 20;
	this.txt_04_02.lineWidth = 785;
	this.txt_04_02.setTransform(0,290);
 html = createDiv(txt['txt_04_02'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.txt_04_02 = new cjs.DOMElement(html);
    this.txt_04_02.setTransform(0, 290-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_04_02}]},95).wait(82));

	// txt_03
	this.txt_04_03 = new cjs.Text("Los números son las constantes de la expresión algebraica.", "20px Verdana");
	this.txt_04_03.lineHeight = 20;
	this.txt_04_03.lineWidth = 785;
	this.txt_04_03.setTransform(0,330);
 html = createDiv(txt['txt_04_03'], "Verdana", "20px", '790px', '40px', "20px", "185px", "left");
    this.txt_04_03 = new cjs.DOMElement(html);
    this.txt_04_03.setTransform(0, 330-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_04_03}]},149).wait(28));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,789,52.6);


(lib.textoAnimado_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 4
	this.text = new cjs.Text("b", "bold 20px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 14;
	this.text.setTransform(229,-36.6+incremento);

	this.text_1 = new cjs.Text("a", "bold 20px Verdana");
	this.text_1.lineHeight = 20;
	this.text_1.lineWidth = 13;
	this.text_1.setTransform(416,83.9+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.text_1,p:{color:"#000000"}},{t:this.text,p:{color:"#000000"}}]},20).to({state:[{t:this.text_1,p:{color:"#CC0000"}},{t:this.text,p:{color:"#000000"}}]},7).to({state:[{t:this.text_1,p:{color:"#CC0000"}},{t:this.text,p:{color:"#CC0000"}}]},13).to({state:[{t:this.text_1,p:{color:"#CC0000"}},{t:this.text,p:{color:"#CC0000"}}]},12).wait(49));

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AaVPFMg0pAAAIAA+JMA0pAAAg");
	this.shape.setTransform(64.9,96.5,0.015,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("A6UPEIAA+HMA0pAAAIAAeHg");
	this.shape_1.setTransform(64.9,96.5,0.015,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AhvvEIDfAAIAAeJIjfAAIAA+J");
	this.shape_2.setTransform(73.7,96.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("AhvPEIAA+IIDfAAIAAeIg");
	this.shape_3.setTransform(73.7,96.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AjGvEIGNAAIAAeJImNAAIAA+J");
	this.shape_4.setTransform(82.5,96.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AjGPEIAA+IIGNAAIAAeIg");
	this.shape_5.setTransform(82.5,96.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AkevEII9AAIAAeJIo9AAIAA+J");
	this.shape_6.setTransform(91.2,96.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AkePEIAA+III9AAIAAeIg");
	this.shape_7.setTransform(91.2,96.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("Al1vEILrAAIAAeJIrrAAIAA+J");
	this.shape_8.setTransform(100,96.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("Al1PEIAA+IILrAAIAAeIg");
	this.shape_9.setTransform(100,96.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AnMvEIOZAAIAAeJIuZAAIAA+J");
	this.shape_10.setTransform(108.8,96.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#999999").s().p("AnMPEIAA+IIOZAAIAAeIg");
	this.shape_11.setTransform(108.8,96.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("AokvEIRJAAIAAeJIxJAAIAA+J");
	this.shape_12.setTransform(117.5,96.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#999999").s().p("AokPEIAA+IIRJAAIAAeIg");
	this.shape_13.setTransform(117.5,96.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("Ap7vEIT3AAIAAeJIz3AAIAA+J");
	this.shape_14.setTransform(126.3,96.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("Ap7PEIAA+IIT3AAIAAeIg");
	this.shape_15.setTransform(126.3,96.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("ArSvEIWlAAIAAeJI2lAAIAA+J");
	this.shape_16.setTransform(135.1,96.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#999999").s().p("ArSPEIAA+IIWlAAIAAeIg");
	this.shape_17.setTransform(135.1,96.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("AsqvEIZVAAIAAeJI5VAAIAA+J");
	this.shape_18.setTransform(143.8,96.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#999999").s().p("AsqPEIAA+IIZVAAIAAeIg");
	this.shape_19.setTransform(143.8,96.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("AuBvEIcDAAIAAeJI8DAAIAA+J");
	this.shape_20.setTransform(152.6,96.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#999999").s().p("AuBPEIAA+IIcDAAIAAeIg");
	this.shape_21.setTransform(152.6,96.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("AvZvEIezAAIAAeJI+zAAIAA+J");
	this.shape_22.setTransform(161.3,96.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#999999").s().p("AvZPEIAA+IIezAAIAAeIg");
	this.shape_23.setTransform(161.3,96.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#000000").ss(1,1,1).p("AwwvEMAhhAAAIAAeJMghhAAAIAA+J");
	this.shape_24.setTransform(170.1,96.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#999999").s().p("AwwPEIAA+IMAhhAAAIAAeIg");
	this.shape_25.setTransform(170.1,96.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#000000").ss(1,1,1).p("AyHvEMAkPAAAIAAeJMgkPAAAIAA+J");
	this.shape_26.setTransform(178.9,96.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#999999").s().p("AyHPEIAA+IMAkPAAAIAAeIg");
	this.shape_27.setTransform(178.9,96.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1,1,1).p("AzfvEMAm/AAAIAAeJMgm/AAAIAA+J");
	this.shape_28.setTransform(187.6,96.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#999999").s().p("AzfPEIAA+IMAm/AAAIAAeIg");
	this.shape_29.setTransform(187.6,96.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#000000").ss(1,1,1).p("A02vEMAptAAAIAAeJMgptAAAIAA+J");
	this.shape_30.setTransform(196.4,96.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#999999").s().p("A02PEIAA+IMAptAAAIAAeIg");
	this.shape_31.setTransform(196.4,96.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#000000").ss(1,1,1).p("A2NvEMAsbAAAIAAeJMgsbAAAIAA+J");
	this.shape_32.setTransform(205.2,96.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#999999").s().p("A2NPEIAA+IMAsbAAAIAAeIg");
	this.shape_33.setTransform(205.2,96.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#000000").ss(1,1,1).p("A3lvEMAvLAAAIAAeJMgvLAAAIAA+J");
	this.shape_34.setTransform(213.9,96.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#999999").s().p("A3lPEIAA+IMAvLAAAIAAeIg");
	this.shape_35.setTransform(213.9,96.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#000000").ss(1,1,1).p("A48vEMAx5AAAIAAeJMgx5AAAIAA+J");
	this.shape_36.setTransform(222.7,96.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#999999").s().p("A48PEIAA+IMAx5AAAIAAeIg");
	this.shape_37.setTransform(222.7,96.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#CC0000").ss(3,1,1).p("AaVvEIAAeJA6UPFIAA+J");
	this.shape_38.setTransform(231.5,96.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1,1,1).p("AaVPFMg0pAAAA6UvEMA0pAAA");
	this.shape_39.setTransform(231.5,96.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#999999").s().p("A6UPEIAA+IMA0pAAAIAAeIg");
	this.shape_40.setTransform(231.5,96.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#CC0000").ss(3,1,1).p("AaVPFMg0pAAAIAA+JMA0pAAAg");
	this.shape_41.setTransform(231.5,96.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.015,x:64.9}},{t:this.shape,p:{scaleX:0.015,x:64.9}}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_5},{t:this.shape_4}]},1).to({state:[{t:this.shape_7},{t:this.shape_6}]},1).to({state:[{t:this.shape_9},{t:this.shape_8}]},1).to({state:[{t:this.shape_11},{t:this.shape_10}]},1).to({state:[{t:this.shape_13},{t:this.shape_12}]},1).to({state:[{t:this.shape_15},{t:this.shape_14}]},1).to({state:[{t:this.shape_17},{t:this.shape_16}]},1).to({state:[{t:this.shape_19},{t:this.shape_18}]},1).to({state:[{t:this.shape_21},{t:this.shape_20}]},1).to({state:[{t:this.shape_23},{t:this.shape_22}]},1).to({state:[{t:this.shape_25},{t:this.shape_24}]},1).to({state:[{t:this.shape_27},{t:this.shape_26}]},1).to({state:[{t:this.shape_29},{t:this.shape_28}]},1).to({state:[{t:this.shape_31},{t:this.shape_30}]},1).to({state:[{t:this.shape_33},{t:this.shape_32}]},1).to({state:[{t:this.shape_35},{t:this.shape_34}]},1).to({state:[{t:this.shape_37},{t:this.shape_36}]},1).to({state:[{t:this.shape_1,p:{scaleX:1,x:231.5}},{t:this.shape,p:{scaleX:1,x:231.5}}]},1).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38}]},8).to({state:[{t:this.shape_40},{t:this.shape_41}]},13).to({state:[{t:this.shape_40},{t:this.shape_41}]},12).wait(49));

	// Capa 2
	this.txt_02_01 = new cjs.Text(txt['txt_02_01'], "20px Verdana");
	this.txt_02_01.textAlign = "center";
	this.txt_02_01.lineHeight = 26;
	this.txt_02_01.lineWidth = 459;
	this.txt_02_01.setTransform(229.5,234.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.txt_02_01}]},52).wait(49));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(62.5,0,5,193);


(lib.IMG_03 = function() {
	this.initialize();

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A8CfUMAAAg+nMA4FAAAMAAAA+ng");
	mask.setTransform(179.5,200.5);

	// Capa 1
	this.instance = new lib._3Thinkstock_87704505_OPT();
	this.instance.setTransform(-227.9,1.4);

	this.instance.mask = mask;

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-227.9,1.4,600,400);


(lib.IMG_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.4)").s().p("Egm4AiNMAAAhEZMBNxAAAMAAABEZg");
	this.shape.setTransform(239,239,0.923,0.922);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).wait(2));

	// Capa 1
	this.instance = new lib._1_shutterstock_84650017_OPT();
	this.instance.setTransform(37,37,0.893,0.893);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(37,37,402,402);

      (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_inicioneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_anteriorneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);
  (lib.btn_siguienteneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#1E120D").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);
 (lib.btn_infoneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);
  (lib.btn_cerrarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FEFEFE").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FEFEFE").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}